Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715647030157320193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400369421332, 8.75355208880515 ]
  },
  "id_str" : "715650389077594112",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess let\u2019s see how that turns out. :D",
  "id" : 715650389077594112,
  "in_reply_to_status_id" : 715647030157320193,
  "created_at" : "2016-03-31 21:22:03 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715644993508151297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393829937884, 8.753532984418705 ]
  },
  "id_str" : "715646042281259013",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess well, I look forward to trying to cross borders with it, which I feel is a bit anarchistic too \uD83D\uDE09",
  "id" : 715646042281259013,
  "in_reply_to_status_id" : 715644993508151297,
  "created_at" : "2016-03-31 21:04:47 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 80, 93 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/3AQ3ClunEy",
      "expanded_url" : "http:\/\/www.worldservice.org\/",
      "display_url" : "worldservice.org"
    } ]
  },
  "in_reply_to_status_id_str" : "715640669105229824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393227854484, 8.753541863257986 ]
  },
  "id_str" : "715641427452116992",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess https:\/\/t.co\/3AQ3ClunEy (I was inspired by the awesome book of @atossaaraxia)",
  "id" : 715641427452116992,
  "in_reply_to_status_id" : 715640669105229824,
  "created_at" : "2016-03-31 20:46:26 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/715640203474501632\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/zpqq7XIupF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5291fWIAAkNBY.jpg",
      "id_str" : "715640195501137920",
      "id" : 715640195501137920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5291fWIAAkNBY.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/zpqq7XIupF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398389857176, 8.75346626567419 ]
  },
  "id_str" : "715640203474501632",
  "text" : "Related: my World Passport arrived today. https:\/\/t.co\/zpqq7XIupF",
  "id" : 715640203474501632,
  "created_at" : "2016-03-31 20:41:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715634620780437505",
  "geo" : { },
  "id_str" : "715635174529171457",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe thanks, that looks great!",
  "id" : 715635174529171457,
  "in_reply_to_status_id" : 715634620780437505,
  "created_at" : "2016-03-31 20:21:36 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715633763817021440",
  "text" : "Btw dear travel internet: where do you go to find cheap multi-leg\/city flights?",
  "id" : 715633763817021440,
  "created_at" : "2016-03-31 20:15:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 62, 71 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715632398260695042",
  "text" : "Just submitted our abstract for a project talk on openSNP for @OBF_BOSC. \uD83C\uDFC1",
  "id" : 715632398260695042,
  "created_at" : "2016-03-31 20:10:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715536535119114241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396251962509, 8.753490842743444 ]
  },
  "id_str" : "715576401542443009",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, too much of a waste of time. They will just laugh about me, again.",
  "id" : 715576401542443009,
  "in_reply_to_status_id" : 715536535119114241,
  "created_at" : "2016-03-31 16:28:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 8, 20 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715518720509145088",
  "geo" : { },
  "id_str" : "715518846375952385",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @ctitusbrown the problem if you\u2019re the person in the most eastwards time zone :D",
  "id" : 715518846375952385,
  "in_reply_to_status_id" : 715518720509145088,
  "created_at" : "2016-03-31 12:39:21 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715518160485490689",
  "geo" : { },
  "id_str" : "715518426815533056",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown it\u2019s one of those topics that you can literally discuss until one side falls asleep.",
  "id" : 715518426815533056,
  "in_reply_to_status_id" : 715518160485490689,
  "created_at" : "2016-03-31 12:37:41 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715486333284651008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398639175933, 8.753463587194192 ]
  },
  "id_str" : "715506180823584768",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin yes, that can be tough. \uD83D\uDE14",
  "id" : 715506180823584768,
  "in_reply_to_status_id" : 715486333284651008,
  "created_at" : "2016-03-31 11:49:01 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715476722204827649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12170017163407, 8.930004331635821 ]
  },
  "id_str" : "715485468586971136",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I know that problem. Too many interests, too little time. And doing open source already eats away a lot of spare time somehow \uD83D\uDE02",
  "id" : 715485468586971136,
  "in_reply_to_status_id" : 715476722204827649,
  "created_at" : "2016-03-31 10:26:43 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715474597311713281",
  "geo" : { },
  "id_str" : "715475981180375042",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin are you playing yourself? :)",
  "id" : 715475981180375042,
  "in_reply_to_status_id" : 715474597311713281,
  "created_at" : "2016-03-31 09:49:01 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/P5WRgnpJPF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pzeoLe6nSrU&feature=youtu.be&t=44s",
      "display_url" : "youtube.com\/watch?v=pzeoLe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715470696164433920",
  "geo" : { },
  "id_str" : "715474307439153152",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin the guitar\u2019s doing great, would never dare to break one. https:\/\/t.co\/P5WRgnpJPF ;)",
  "id" : 715474307439153152,
  "in_reply_to_status_id" : 715470696164433920,
  "created_at" : "2016-03-31 09:42:22 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715470166075703296",
  "geo" : { },
  "id_str" : "715473863493025792",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin but to be fair: there\u2019s probably a ready-made package for MacOS around :)",
  "id" : 715473863493025792,
  "in_reply_to_status_id" : 715470166075703296,
  "created_at" : "2016-03-31 09:40:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 17, 26 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715470166075703296",
  "geo" : { },
  "id_str" : "715473799345364992",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin luckily @OBF_BOSC extended the deadline, so I might have a compiled PDF by the time ;)",
  "id" : 715473799345364992,
  "in_reply_to_status_id" : 715470166075703296,
  "created_at" : "2016-03-31 09:40:21 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715470003621859328",
  "geo" : { },
  "id_str" : "715473685973377024",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy thanks, at least the last part is already true :)",
  "id" : 715473685973377024,
  "in_reply_to_status_id" : 715470003621859328,
  "created_at" : "2016-03-31 09:39:54 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715469009244827648",
  "text" : "I should have read more carefully before pressing yes. I wanted: brew install pandoc. I got: a multi-hour job of compiling Haskell.",
  "id" : 715469009244827648,
  "created_at" : "2016-03-31 09:21:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715459559024943105",
  "geo" : { },
  "id_str" : "715468747943907328",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy a cold day, hurrying back to bed to warm up, slipping while taking a turn\u2026 no clue where the puddle came from though ;)",
  "id" : 715468747943907328,
  "in_reply_to_status_id" : 715459559024943105,
  "created_at" : "2016-03-31 09:20:16 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715457079373340672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390606606172, 8.753458716272394 ]
  },
  "id_str" : "715458615121997825",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy thanks \uD83D\uDE0A and you may well ask, but beware, you might get answer. \uD83D\uDE09",
  "id" : 715458615121997825,
  "in_reply_to_status_id" : 715457079373340672,
  "created_at" : "2016-03-31 08:40:01 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/715458380312289281\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/qFrph9wiHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce3RmtOXIAEepKa.jpg",
      "id_str" : "715458378726842369",
      "id" : 715458378726842369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce3RmtOXIAEepKa.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/qFrph9wiHe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390606606172, 8.753458716272394 ]
  },
  "id_str" : "715458380312289281",
  "text" : "One of the best reasons to enter science. https:\/\/t.co\/qFrph9wiHe",
  "id" : 715458380312289281,
  "created_at" : "2016-03-31 08:39:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/kVyCX5HmSp",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/711497780330696704",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715456077433802752",
  "text" : "11 days later: my arm is finally getting better \\o\/ https:\/\/t.co\/kVyCX5HmSp",
  "id" : 715456077433802752,
  "created_at" : "2016-03-31 08:29:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715451552195063809",
  "text" : "RT @OBF_BOSC: The rumors are true: by popular demand, the #BOSC2016 abstract deadline has been extended to Monday, Apr 4! https:\/\/t.co\/h9Aa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 44, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/h9AaVH94V9",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2016",
        "display_url" : "open-bio.org\/wiki\/BOSC_2016"
      } ]
    },
    "geo" : { },
    "id_str" : "715397817187971074",
    "text" : "The rumors are true: by popular demand, the #BOSC2016 abstract deadline has been extended to Monday, Apr 4! https:\/\/t.co\/h9AaVH94V9",
    "id" : 715397817187971074,
    "created_at" : "2016-03-31 04:38:25 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 715451552195063809,
  "created_at" : "2016-03-31 08:11:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 9, 18 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 33, 45 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715443474162704384",
  "geo" : { },
  "id_str" : "715443580425338880",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @OBF_BOSC @PhilippBayer @helgerausch okay, will do that once the abstract is done :)",
  "id" : 715443580425338880,
  "in_reply_to_status_id" : 715443474162704384,
  "created_at" : "2016-03-31 07:40:16 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 9, 18 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 33, 45 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715438615116058624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398408078463, 8.753468413799206 ]
  },
  "id_str" : "715439436616622080",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @OBF_BOSC @PhilippBayer @helgerausch btw: Sent an app for a travel grant ~2 days ago, there\u2019s a way to update it to \u2018want2present\u2019?",
  "id" : 715439436616622080,
  "in_reply_to_status_id" : 715438615116058624,
  "created_at" : "2016-03-31 07:23:48 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 9, 18 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 33, 45 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715438615116058624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398408078463, 8.753468413799206 ]
  },
  "id_str" : "715439016963915777",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @OBF_BOSC @PhilippBayer @helgerausch me too, I like getting first drafts done as quick as possible.",
  "id" : 715439016963915777,
  "in_reply_to_status_id" : 715438615116058624,
  "created_at" : "2016-03-31 07:22:08 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 10, 18 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 33, 45 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715437824598753280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398408078463, 8.753468413799206 ]
  },
  "id_str" : "715438178778406912",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC @pjacock @PhilippBayer @helgerausch phew, good to hear, though now I already spent good parts of yesterday night on it \uD83D\uDE09",
  "id" : 715438178778406912,
  "in_reply_to_status_id" : 715437824598753280,
  "created_at" : "2016-03-31 07:18:48 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/98Uo3evogz",
      "expanded_url" : "https:\/\/twitter.com\/NYTScience\/status\/715297585037197312",
      "display_url" : "twitter.com\/NYTScience\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09920388362412, 8.69138070660207 ]
  },
  "id_str" : "715299773981581313",
  "text" : "Nice to see Bandage plots in the NYT. https:\/\/t.co\/98Uo3evogz",
  "id" : 715299773981581313,
  "created_at" : "2016-03-30 22:08:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 20, 35 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715281411750674434",
  "text" : "RT @shefw: WOO HOO! @MozillaScience is now accepting applications for projects and host sites for their 2016 Global Sprint! https:\/\/t.co\/m0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 9, 24 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/m0cGUd5v1o",
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/712690857409810433",
        "display_url" : "twitter.com\/MozillaScience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712691355894489088",
    "text" : "WOO HOO! @MozillaScience is now accepting applications for projects and host sites for their 2016 Global Sprint! https:\/\/t.co\/m0cGUd5v1o",
    "id" : 712691355894489088,
    "created_at" : "2016-03-23 17:23:55 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 715281411750674434,
  "created_at" : "2016-03-30 20:55:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Flying Scientist",
      "screen_name" : "ScientistFlying",
      "indices" : [ 10, 26 ],
      "id_str" : "4821230031",
      "id" : 4821230031
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 27, 42 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 43, 54 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "DNA Land",
      "screen_name" : "dl1dl1",
      "indices" : [ 55, 62 ],
      "id_str" : "3178131275",
      "id" : 3178131275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715243822205308928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09691522403185, 8.690474062419595 ]
  },
  "id_str" : "715246575925243904",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @ScientistFlying @MozillaScience @openSNPorg @dl1dl1 I guess collaborating would work nicely then :)",
  "id" : 715246575925243904,
  "in_reply_to_status_id" : 715243822205308928,
  "created_at" : "2016-03-30 18:37:26 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390806568866, 8.753524160506325 ]
  },
  "id_str" : "715219343563468800",
  "text" : "@quominus fwiw: I\u2019d see that as a huge plus if I was a PI.",
  "id" : 715219343563468800,
  "created_at" : "2016-03-30 16:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Flying Scientist",
      "screen_name" : "ScientistFlying",
      "indices" : [ 10, 26 ],
      "id_str" : "4821230031",
      "id" : 4821230031
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 27, 38 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "DNA Land",
      "screen_name" : "dl1dl1",
      "indices" : [ 39, 46 ],
      "id_str" : "3178131275",
      "id" : 3178131275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715209040108855296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10919067082006, 8.762459009893949 ]
  },
  "id_str" : "715210141172273152",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @ScientistFlying @openSNPorg @dl1dl1 yes, just need some programmatic connection to become fully symbiotic (if consent allows)",
  "id" : 715210141172273152,
  "in_reply_to_status_id" : 715209040108855296,
  "created_at" : "2016-03-30 16:12:40 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 10, 18 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 33, 45 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715203508778115072",
  "geo" : { },
  "id_str" : "715206005869686784",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC @pjacock @PhilippBayer @helgerausch yikes, just saw the deadline, but I\u2019ll try to write something up :)",
  "id" : 715206005869686784,
  "in_reply_to_status_id" : 715203508778115072,
  "created_at" : "2016-03-30 15:56:14 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 23, 35 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 36, 45 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715199092117389312",
  "geo" : { },
  "id_str" : "715205293098016769",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @PhilippBayer @helgerausch @OBF_BOSC Even includes some Docker-content by now \uD83D\uDE09",
  "id" : 715205293098016769,
  "in_reply_to_status_id" : 715199092117389312,
  "created_at" : "2016-03-30 15:53:24 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 23, 35 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715197389313806336",
  "geo" : { },
  "id_str" : "715198303596650497",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @PhilippBayer @helgerausch very little real technical changes so far, but could talk about infrastructure changes &amp; crowdfunding.",
  "id" : 715198303596650497,
  "in_reply_to_status_id" : 715197389313806336,
  "created_at" : "2016-03-30 15:25:37 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 55, 65 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/zmQunfybOM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BDlQBvlBwgq\/",
      "display_url" : "instagram.com\/p\/BDlQBvlBwgq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398372425636, 8.753468113098467 ]
  },
  "id_str" : "715197700321517569",
  "text" : "Thanks to the mailman I\u2019m now ready for my coin check, @romanmars https:\/\/t.co\/zmQunfybOM",
  "id" : 715197700321517569,
  "created_at" : "2016-03-30 15:23:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flying Scientist",
      "screen_name" : "ScientistFlying",
      "indices" : [ 0, 16 ],
      "id_str" : "4821230031",
      "id" : 4821230031
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 17, 32 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 33, 44 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "DNA Land",
      "screen_name" : "dl1dl1",
      "indices" : [ 93, 100 ],
      "id_str" : "3178131275",
      "id" : 3178131275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715194642673836032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139991313118, 8.753479917616463 ]
  },
  "id_str" : "715196536351821824",
  "in_reply_to_user_id" : 4821230031,
  "text" : "@ScientistFlying @MozillaScience @openSNPorg completely different thing, last time I checked @dl1dl1 was not open data :)",
  "id" : 715196536351821824,
  "in_reply_to_status_id" : 715194642673836032,
  "created_at" : "2016-03-30 15:18:36 +0000",
  "in_reply_to_screen_name" : "ScientistFlying",
  "in_reply_to_user_id_str" : "4821230031",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 27, 39 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/VXmFTLFJ0O",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/715192622168416256",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398851113631, 8.75347230256345 ]
  },
  "id_str" : "715196344093294593",
  "text" : "Read how I, @PhilippBayer, @helgerausch &amp; maybe even you collaborate on openSNP without relocating to San Francisco! https:\/\/t.co\/VXmFTLFJ0O",
  "id" : 715196344093294593,
  "created_at" : "2016-03-30 15:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 7, 14 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715177557277147137",
  "geo" : { },
  "id_str" : "715177642299899904",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @malech \u201Ewie der Mossad, nur mit R\u201C",
  "id" : 715177642299899904,
  "in_reply_to_status_id" : 715177557277147137,
  "created_at" : "2016-03-30 14:03:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 35, 41 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715177571873398784",
  "text" : "@malech ich h\u00E4tte an deiner Stelle @Lobot\u2019s benutzt. Zumindest nur wenig zu buchstabieren :D",
  "id" : 715177571873398784,
  "created_at" : "2016-03-30 14:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715139468928401408",
  "geo" : { },
  "id_str" : "715139708083376129",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin i meant learning German. Many of my foreign colleagues have a hard time finding ppl willing to speak DE because locals switch 2 EN.",
  "id" : 715139708083376129,
  "in_reply_to_status_id" : 715139468928401408,
  "created_at" : "2016-03-30 11:32:47 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715131444675350528",
  "geo" : { },
  "id_str" : "715137264330936321",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin yes, that might be the case. It\u2019s already hard in Germany. :)",
  "id" : 715137264330936321,
  "in_reply_to_status_id" : 715131444675350528,
  "created_at" : "2016-03-30 11:23:05 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIFRAS ISMAIL",
      "screen_name" : "nifras_tweety",
      "indices" : [ 0, 14 ],
      "id_str" : "267622931",
      "id" : 267622931
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/69GDNras9I",
      "expanded_url" : "https:\/\/gitter.im\/openSNP\/snpr",
      "display_url" : "gitter.im\/openSNP\/snpr"
    } ]
  },
  "in_reply_to_status_id_str" : "715124387029073920",
  "geo" : { },
  "id_str" : "715128596277411840",
  "in_reply_to_user_id" : 267622931,
  "text" : "@nifras_tweety @PhilippBayer and if you want to drop by for a chat we do have a gitter channel at https:\/\/t.co\/69GDNras9I",
  "id" : 715128596277411840,
  "in_reply_to_status_id" : 715124387029073920,
  "created_at" : "2016-03-30 10:48:38 +0000",
  "in_reply_to_screen_name" : "nifras_tweety",
  "in_reply_to_user_id_str" : "267622931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIFRAS ISMAIL",
      "screen_name" : "nifras_tweety",
      "indices" : [ 0, 14 ],
      "id_str" : "267622931",
      "id" : 267622931
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/EZwvV4dBE1",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/blob\/master\/ROADMAP.md",
      "display_url" : "github.com\/openSNP\/snpr\/b\u2026"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/UinCYWRRaS",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715124387029073920",
  "geo" : { },
  "id_str" : "715128516250091520",
  "in_reply_to_user_id" : 267622931,
  "text" : "@nifras_tweety @PhilippBayer there\u2019s a roadmap we have https:\/\/t.co\/EZwvV4dBE1 and lots of open issues https:\/\/t.co\/UinCYWRRaS",
  "id" : 715128516250091520,
  "in_reply_to_status_id" : 715124387029073920,
  "created_at" : "2016-03-30 10:48:19 +0000",
  "in_reply_to_screen_name" : "nifras_tweety",
  "in_reply_to_user_id_str" : "267622931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIFRAS ISMAIL",
      "screen_name" : "nifras_tweety",
      "indices" : [ 0, 14 ],
      "id_str" : "267622931",
      "id" : 267622931
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715124387029073920",
  "geo" : { },
  "id_str" : "715128338763874304",
  "in_reply_to_user_id" : 267622931,
  "text" : "@nifras_tweety @PhilippBayer sure, if you\u2019re interested in contributing outside of GSoC there are plenty of ways! :)",
  "id" : 715128338763874304,
  "in_reply_to_status_id" : 715124387029073920,
  "created_at" : "2016-03-30 10:47:37 +0000",
  "in_reply_to_screen_name" : "nifras_tweety",
  "in_reply_to_user_id_str" : "267622931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIFRAS ISMAIL",
      "screen_name" : "nifras_tweety",
      "indices" : [ 0, 14 ],
      "id_str" : "267622931",
      "id" : 267622931
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 29, 42 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715122945295794178",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17206714027577, 8.630513437100342 ]
  },
  "id_str" : "715123696290172928",
  "in_reply_to_user_id" : 267622931,
  "text" : "@nifras_tweety that would be @PhilippBayer and me in principle. But I fear you missed the GSoC deadline which was last Friday.",
  "id" : 715123696290172928,
  "in_reply_to_status_id" : 715122945295794178,
  "created_at" : "2016-03-30 10:29:10 +0000",
  "in_reply_to_screen_name" : "nifras_tweety",
  "in_reply_to_user_id_str" : "267622931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715117795978190848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17208550881107, 8.630299513436547 ]
  },
  "id_str" : "715123401543782400",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin yes, that\u2019s though. Immersion also has the benefit of having opportunities to use\/train all the time. But see your point \uD83D\uDE14",
  "id" : 715123401543782400,
  "in_reply_to_status_id" : 715117795978190848,
  "created_at" : "2016-03-30 10:27:59 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715113799972483072",
  "geo" : { },
  "id_str" : "715117137598267392",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I can imagine, never tried learning another language while immersed in the country so far though.",
  "id" : 715117137598267392,
  "in_reply_to_status_id" : 715113799972483072,
  "created_at" : "2016-03-30 10:03:06 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/dE8pTVnaKE",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/the-real-problem-with-linguistic-shirkers\/",
      "display_url" : "languageonthemove.com\/the-real-probl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715112525008871424",
  "text" : "The discourse around \u201Cintegration shirking\u201D is one of victim blaming https:\/\/t.co\/dE8pTVnaKE",
  "id" : 715112525008871424,
  "created_at" : "2016-03-30 09:44:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715111738551570434",
  "geo" : { },
  "id_str" : "715112110485807104",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik for my own data I did stick to the LCA algorithm in MEGAN so far. Can nicely divide Fungi\/Viridiplantae\/Bacteria.",
  "id" : 715112110485807104,
  "in_reply_to_status_id" : 715111738551570434,
  "created_at" : "2016-03-30 09:43:07 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715110237863288832",
  "geo" : { },
  "id_str" : "715110421024415744",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik yes, I did blobplots for mine (didn\u2019t come around to do anvi\u2019o so far) and some people asked me about how to do them after the talk.",
  "id" : 715110421024415744,
  "in_reply_to_status_id" : 715110237863288832,
  "created_at" : "2016-03-30 09:36:25 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715108173896671232",
  "geo" : { },
  "id_str" : "715109493009420288",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik btw: I think people really enjoyed your paper, just finished giving the chalk talk on it. No questions from my students :)",
  "id" : 715109493009420288,
  "in_reply_to_status_id" : 715108173896671232,
  "created_at" : "2016-03-30 09:32:43 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 8, 18 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 19, 30 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/KRTyc2m5Y3",
      "expanded_url" : "https:\/\/instagram.com\/p\/-8-M8ihwqS\/",
      "display_url" : "instagram.com\/p\/-8-M8ihwqS\/"
    } ]
  },
  "in_reply_to_status_id_str" : "715108173896671232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17898716996688, 8.62460463403598 ]
  },
  "id_str" : "715109263618781184",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @edyong209 @HopeJahren that\u2019s one I have too \uD83D\uDE09 https:\/\/t.co\/KRTyc2m5Y3",
  "id" : 715109263618781184,
  "in_reply_to_status_id" : 715108173896671232,
  "created_at" : "2016-03-30 09:31:49 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715097567936258050",
  "geo" : { },
  "id_str" : "715097630162944000",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin \uD83D\uDE0D",
  "id" : 715097630162944000,
  "in_reply_to_status_id" : 715097567936258050,
  "created_at" : "2016-03-30 08:45:35 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715096842657218560",
  "geo" : { },
  "id_str" : "715097119200264192",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin for the ninja interviews you just don\u2019t show up. And later claim you were there but your skills prevented them from seeing you.",
  "id" : 715097119200264192,
  "in_reply_to_status_id" : 715096842657218560,
  "created_at" : "2016-03-30 08:43:33 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715096510082523136",
  "geo" : { },
  "id_str" : "715096625912352769",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin ah, saw your second tweet a bit too late. Same idea :D",
  "id" : 715096625912352769,
  "in_reply_to_status_id" : 715096510082523136,
  "created_at" : "2016-03-30 08:41:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/VkH1NVhd4a",
      "expanded_url" : "http:\/\/www.pqmonthly.com\/wp-content\/uploads\/2012\/10\/39451.jpg",
      "display_url" : "pqmonthly.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715091090840371200",
  "geo" : { },
  "id_str" : "715095890265026560",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin how about https:\/\/t.co\/VkH1NVhd4a add a leather jacket &amp; a cigarette and you\u2019re good to go.",
  "id" : 715095890265026560,
  "in_reply_to_status_id" : 715091090840371200,
  "created_at" : "2016-03-30 08:38:40 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 0, 11 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/HzQWYSeDTx",
      "expanded_url" : "https:\/\/instagram.com\/p\/-9Ht9phwvv\/",
      "display_url" : "instagram.com\/p\/-9Ht9phwvv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "714959344706527232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0607660185323, 8.818741381938043 ]
  },
  "id_str" : "714968951235747840",
  "in_reply_to_user_id" : 322658299,
  "text" : "@HopeJahren can\u2019t confirm. https:\/\/t.co\/HzQWYSeDTx",
  "id" : 714968951235747840,
  "in_reply_to_status_id" : 714959344706527232,
  "created_at" : "2016-03-30 00:14:16 +0000",
  "in_reply_to_screen_name" : "HopeJahren",
  "in_reply_to_user_id_str" : "322658299",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/42CXcuKEzH",
      "expanded_url" : "https:\/\/twitter.com\/beaugunderson\/status\/714938779069353984",
      "display_url" : "twitter.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084117557744, 8.81864322124058 ]
  },
  "id_str" : "714939254799994880",
  "text" : "How I sometimes spend a day. https:\/\/t.co\/42CXcuKEzH",
  "id" : 714939254799994880,
  "created_at" : "2016-03-29 22:16:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714936485988995072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091719497932, 8.81858188659774 ]
  },
  "id_str" : "714937063028748289",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision happy to offer my limited expertise w\/ different methods for that \uD83D\uDE0A",
  "id" : 714937063028748289,
  "in_reply_to_status_id" : 714936485988995072,
  "created_at" : "2016-03-29 22:07:33 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 8, 17 ],
      "id_str" : "127003086",
      "id" : 127003086
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 100, 109 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714936387368312833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06066188341712, 8.818601989113116 ]
  },
  "id_str" : "714936795289493505",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @tjvision which both follow up papers masterfully did. Hope can convince someone to present @merenbey\u2019s at the next journal club :)",
  "id" : 714936795289493505,
  "in_reply_to_status_id" : 714936387368312833,
  "created_at" : "2016-03-29 22:06:29 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714935598637776897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086332508833, 8.818717071750218 ]
  },
  "id_str" : "714935969133236225",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision yes, spades is fantastic. Though has(\/had?) a problem with merging heterozyg. contigs, thus inflating total len.",
  "id" : 714935969133236225,
  "in_reply_to_status_id" : 714935598637776897,
  "created_at" : "2016-03-29 22:03:12 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/fGkCW0B3o2",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/714916733371473925",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "714932880586252290",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087370744613, 8.818782414619507 ]
  },
  "id_str" : "714934670102765568",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision misunderstood that tweet but should have known better :) https:\/\/t.co\/fGkCW0B3o2",
  "id" : 714934670102765568,
  "in_reply_to_status_id" : 714932880586252290,
  "created_at" : "2016-03-29 21:58:02 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714933114225758209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608453868191, 8.81881730419578 ]
  },
  "id_str" : "714933945419350017",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision both DBG as well as OLC based assemblers would split contigs if same word appeared in both, bact. &amp; eukaryote",
  "id" : 714933945419350017,
  "in_reply_to_status_id" : 714933114225758209,
  "created_at" : "2016-03-29 21:55:10 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714933114225758209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608453868191, 8.81881730419578 ]
  },
  "id_str" : "714933673359982592",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision ah, yes, then we did misunderstand each other. Perfect matches shouldn\u2019t make a diff to contiguity.",
  "id" : 714933673359982592,
  "in_reply_to_status_id" : 714933114225758209,
  "created_at" : "2016-03-29 21:54:05 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714928566190866432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608453868191, 8.81881730419578 ]
  },
  "id_str" : "714933417608101889",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik thanks, that means a lot! :)",
  "id" : 714933417608101889,
  "in_reply_to_status_id" : 714928566190866432,
  "created_at" : "2016-03-29 21:53:04 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714926357357191168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088423583084, 8.818656729987884 ]
  },
  "id_str" : "714927229877223426",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik currently working on the next paper based exclusively on real data :)",
  "id" : 714927229877223426,
  "in_reply_to_status_id" : 714926357357191168,
  "created_at" : "2016-03-29 21:28:28 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/c9mgGaJ0c2",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/suppinfo",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "714926357357191168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088423583084, 8.818656729987884 ]
  },
  "id_str" : "714927127171358720",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik absolutely, very challenging but very interesting as well. See some results here https:\/\/t.co\/c9mgGaJ0c2",
  "id" : 714927127171358720,
  "in_reply_to_status_id" : 714926357357191168,
  "created_at" : "2016-03-29 21:28:04 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084780033212, 8.818836011935666 ]
  },
  "id_str" : "714925932058947586",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik same for my real date from lichens (fungus plus alga plus community of bacteria)",
  "id" : 714925932058947586,
  "created_at" : "2016-03-29 21:23:19 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714925055017402368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091190697666, 8.81879960804444 ]
  },
  "id_str" : "714925261280657408",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik from my experience important reads used for elongating true target contigs will be thrown away as well.",
  "id" : 714925261280657408,
  "in_reply_to_status_id" : 714925055017402368,
  "created_at" : "2016-03-29 21:20:39 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 10, 17 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714924484348809216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091190697666, 8.81879960804444 ]
  },
  "id_str" : "714925100424962048",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey @sujaik glad we agree on that \uD83D\uDE09",
  "id" : 714925100424962048,
  "in_reply_to_status_id" : 714924484348809216,
  "created_at" : "2016-03-29 21:20:01 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091190697666, 8.81879960804444 ]
  },
  "id_str" : "714924927837716481",
  "text" : "\u00ABDo you think Apple ever used a pun on the word byte as a slogan?\u00BB \u2014 \u00ABYou mean something like \u2018byte power\u2019?\u00BB",
  "id" : 714924927837716481,
  "created_at" : "2016-03-29 21:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714923561912238080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091190697666, 8.81879960804444 ]
  },
  "id_str" : "714924330862395394",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey please keep going, in the worst case I\u2019ll catch up tomorrow ;-)",
  "id" : 714924330862395394,
  "in_reply_to_status_id" : 714923561912238080,
  "created_at" : "2016-03-29 21:16:57 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093123254051, 8.818740638123671 ]
  },
  "id_str" : "714922523562020864",
  "text" : "\u00ABWill you come to bed?\u00BB \u2014 \u00ABI can\u2019t, there\u2019s a de novo genome assembly discussion on Twitter!\u00BB",
  "id" : 714922523562020864,
  "created_at" : "2016-03-29 21:09:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714916733371473925",
  "geo" : { },
  "id_str" : "714920176349810693",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision so filtering can be done after assembly to catch longer contigs -&gt; more easy to identify than bact. short reads.",
  "id" : 714920176349810693,
  "in_reply_to_status_id" : 714916733371473925,
  "created_at" : "2016-03-29 21:00:27 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714916733371473925",
  "geo" : { },
  "id_str" : "714920053771251712",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision from my experience (largely based on simulations but still) chimeric contigs are rarely created by assemblers.",
  "id" : 714920053771251712,
  "in_reply_to_status_id" : 714916733371473925,
  "created_at" : "2016-03-29 20:59:58 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 18, 27 ],
      "id_str" : "127003086",
      "id" : 127003086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714916733371473925",
  "geo" : { },
  "id_str" : "714919748077805568",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tjvision problem can be too eagerly filtering \u201Ebacterial\u201C short reads that are from target -&gt; fragmented assembly.",
  "id" : 714919748077805568,
  "in_reply_to_status_id" : 714916733371473925,
  "created_at" : "2016-03-29 20:58:45 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiernan Morgan",
      "screen_name" : "tiernanbambam",
      "indices" : [ 3, 17 ],
      "id_str" : "1408204412",
      "id" : 1408204412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714917818014285824",
  "text" : "RT @tiernanbambam: RIP Joan Bates, aka Princess Joan of Sealand - obit includes a fascinating history on the Principality of Sealand https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/lcxVB05gwf",
        "expanded_url" : "http:\/\/www.telegraph.co.uk\/news\/obituaries\/12205685\/Princess-Joan-of-Sealand-obituary.html",
        "display_url" : "telegraph.co.uk\/news\/obituarie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714909538382651393",
    "text" : "RIP Joan Bates, aka Princess Joan of Sealand - obit includes a fascinating history on the Principality of Sealand https:\/\/t.co\/lcxVB05gwf",
    "id" : 714909538382651393,
    "created_at" : "2016-03-29 20:18:10 +0000",
    "user" : {
      "name" : "Tiernan Morgan",
      "screen_name" : "tiernanbambam",
      "protected" : false,
      "id_str" : "1408204412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914582998510653441\/ZZ12Gpth_normal.jpg",
      "id" : 1408204412,
      "verified" : false
    }
  },
  "id" : 714917818014285824,
  "created_at" : "2016-03-29 20:51:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Bogo",
      "screen_name" : "jenbogo",
      "indices" : [ 3, 11 ],
      "id_str" : "244276540",
      "id" : 244276540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714913118946729984",
  "text" : "RT @jenbogo: The implications of being the only girl in science camp\u2014and a culture that still reinforces science is for boys: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/SZ383y6mMs",
        "expanded_url" : "http:\/\/ow.ly\/103bTN",
        "display_url" : "ow.ly\/103bTN"
      } ]
    },
    "geo" : { },
    "id_str" : "714876061557895168",
    "text" : "The implications of being the only girl in science camp\u2014and a culture that still reinforces science is for boys: https:\/\/t.co\/SZ383y6mMs",
    "id" : 714876061557895168,
    "created_at" : "2016-03-29 18:05:09 +0000",
    "user" : {
      "name" : "Jennifer Bogo",
      "screen_name" : "jenbogo",
      "protected" : false,
      "id_str" : "244276540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1657297062\/Jen_sharks_normal.jpg",
      "id" : 244276540,
      "verified" : false
    }
  },
  "id" : 714913118946729984,
  "created_at" : "2016-03-29 20:32:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Undark Magazine",
      "screen_name" : "undarkmag",
      "indices" : [ 3, 13 ],
      "id_str" : "3883416257",
      "id" : 3883416257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/undarkmag\/status\/714847128632340488\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/laUyMF8AZH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeulrP9W8AAYAEM.jpg",
      "id_str" : "714847128305201152",
      "id" : 714847128305201152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeulrP9W8AAYAEM.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1463,
        "resize" : "fit",
        "w" : 2600
      } ],
      "display_url" : "pic.twitter.com\/laUyMF8AZH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/EclbarqXwq",
      "expanded_url" : "http:\/\/bit.ly\/1PD3r5P",
      "display_url" : "bit.ly\/1PD3r5P"
    } ]
  },
  "geo" : { },
  "id_str" : "714887659940917248",
  "text" : "RT @undarkmag: Collaboration and Tribalism in Science https:\/\/t.co\/EclbarqXwq https:\/\/t.co\/laUyMF8AZH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/undarkmag\/status\/714847128632340488\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/laUyMF8AZH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeulrP9W8AAYAEM.jpg",
        "id_str" : "714847128305201152",
        "id" : 714847128305201152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeulrP9W8AAYAEM.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1463,
          "resize" : "fit",
          "w" : 2600
        } ],
        "display_url" : "pic.twitter.com\/laUyMF8AZH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/EclbarqXwq",
        "expanded_url" : "http:\/\/bit.ly\/1PD3r5P",
        "display_url" : "bit.ly\/1PD3r5P"
      } ]
    },
    "geo" : { },
    "id_str" : "714847128632340488",
    "text" : "Collaboration and Tribalism in Science https:\/\/t.co\/EclbarqXwq https:\/\/t.co\/laUyMF8AZH",
    "id" : 714847128632340488,
    "created_at" : "2016-03-29 16:10:11 +0000",
    "user" : {
      "name" : "Undark Magazine",
      "screen_name" : "undarkmag",
      "protected" : false,
      "id_str" : "3883416257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724637778630316032\/sQSOHqwo_normal.jpg",
      "id" : 3883416257,
      "verified" : false
    }
  },
  "id" : 714887659940917248,
  "created_at" : "2016-03-29 18:51:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 3, 15 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714866534276063234",
  "text" : "RT @theWinnower: If given the opportunity to publish a non-scientist summary of your research article you would prefer to publish it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714849202870874112",
    "text" : "If given the opportunity to publish a non-scientist summary of your research article you would prefer to publish it",
    "id" : 714849202870874112,
    "created_at" : "2016-03-29 16:18:25 +0000",
    "user" : {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "protected" : false,
      "id_str" : "748018813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459467186734514177\/xIXadyix_normal.jpeg",
      "id" : 748018813,
      "verified" : false
    }
  },
  "id" : 714866534276063234,
  "created_at" : "2016-03-29 17:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714841529681100801",
  "geo" : { },
  "id_str" : "714841828843995136",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik that\u2019s very kind! If there are questions coming up I\u2019ll just note them and email them to you. Makes it easier to distribute later on",
  "id" : 714841828843995136,
  "in_reply_to_status_id" : 714841529681100801,
  "created_at" : "2016-03-29 15:49:07 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/3WPIfEHFHG",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/early\/2016\/03\/23\/1600338113.full",
      "display_url" : "pnas.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714840621471674368",
  "text" : "I\u2019ll be talking about (no!) evidence for horizontal gene transfer in tardigrade\u2019s genome in our journal club tmrw \uD83C\uDF89 https:\/\/t.co\/3WPIfEHFHG",
  "id" : 714840621471674368,
  "created_at" : "2016-03-29 15:44:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714832465895034881",
  "geo" : { },
  "id_str" : "714832648728928257",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog most of my organisms tend to be dead by the time they enter the DNA sequencer as well ;)",
  "id" : 714832648728928257,
  "in_reply_to_status_id" : 714832465895034881,
  "created_at" : "2016-03-29 15:12:39 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/BnUaMjohA7",
      "expanded_url" : "https:\/\/twitter.com\/thelabandfield\/status\/714822394272210944",
      "display_url" : "twitter.com\/thelabandfield\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714823725821140992",
  "text" : "guilty of that too. https:\/\/t.co\/BnUaMjohA7",
  "id" : 714823725821140992,
  "created_at" : "2016-03-29 14:37:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714822666079875072",
  "text" : "Sharing Spotify\u2019s Discover Weekly playlist was fun in the beginning. But I think it broke the algorithm, slowly converges into a single one.",
  "id" : 714822666079875072,
  "created_at" : "2016-03-29 14:32:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 25, 34 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerOfCode",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714795516366876672",
  "text" : "RT @biocrusoe: Attention @obf_bosc community: we have at least 2 women applications for #SummerOfCode, but all the mentors seem to be men. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BOSC",
        "screen_name" : "OBF_BOSC",
        "indices" : [ 10, 19 ],
        "id_str" : "583180584",
        "id" : 583180584
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SummerOfCode",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714793436776382464",
    "text" : "Attention @obf_bosc community: we have at least 2 women applications for #SummerOfCode, but all the mentors seem to be men. Any volunteers?",
    "id" : 714793436776382464,
    "created_at" : "2016-03-29 12:36:50 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 714795516366876672,
  "created_at" : "2016-03-29 12:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/2Na91uqp67",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Tschunk",
      "display_url" : "en.wikipedia.org\/wiki\/Tschunk"
    } ]
  },
  "in_reply_to_status_id_str" : "714789455824044032",
  "geo" : { },
  "id_str" : "714789872188448770",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs I think @Protohedgehog will only be interested in club mate once it\u2019s in Tschunk-form \uD83D\uDE1C https:\/\/t.co\/2Na91uqp67",
  "id" : 714789872188448770,
  "in_reply_to_status_id" : 714789455824044032,
  "created_at" : "2016-03-29 12:22:40 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "realscientists: Dr. Jacquelyn Gill, Paleoecologist",
      "screen_name" : "realscientists",
      "indices" : [ 0, 15 ],
      "id_str" : "1144882621",
      "id" : 1144882621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714754111355428865",
  "geo" : { },
  "id_str" : "714774355696336896",
  "in_reply_to_user_id" : 1144882621,
  "text" : "@realscientists academic w\/ tattoos, wearing pink skirts (&amp; used to have pink hair) here. Works for &amp; against one, depending on environment.",
  "id" : 714774355696336896,
  "in_reply_to_status_id" : 714754111355428865,
  "created_at" : "2016-03-29 11:21:00 +0000",
  "in_reply_to_screen_name" : "realscientists",
  "in_reply_to_user_id_str" : "1144882621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714764675901206528",
  "geo" : { },
  "id_str" : "714767539637772288",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander I\u2019m fine with that as long as I can download it easily :D",
  "id" : 714767539637772288,
  "in_reply_to_status_id" : 714764675901206528,
  "created_at" : "2016-03-29 10:53:55 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/EsFHw2pk7j",
      "expanded_url" : "http:\/\/media.tumblr.com\/2e808bbb8139d68cb491ddbfd65750fe\/tumblr_inline_mpd71nxD571qz4rgp.gif",
      "display_url" : "media.tumblr.com\/2e808bbb8139d6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714749682946277376",
  "text" : "tfw you have to reimplement other people\u2019s stuff because their paper doesn\u2019t have the code openly shared\u2026 https:\/\/t.co\/EsFHw2pk7j",
  "id" : 714749682946277376,
  "created_at" : "2016-03-29 09:42:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/714745425358663680\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/h3Yoe18EOZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CetJLRpW4AEbROs.jpg",
      "id_str" : "714745423932612609",
      "id" : 714745423932612609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CetJLRpW4AEbROs.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/h3Yoe18EOZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714744460312227840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16976607156361, 8.630723782046575 ]
  },
  "id_str" : "714745425358663680",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander allowed everything here. Let\u2019s see how that turns out :) https:\/\/t.co\/h3Yoe18EOZ",
  "id" : 714745425358663680,
  "in_reply_to_status_id" : 714744460312227840,
  "created_at" : "2016-03-29 09:26:03 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/b7VWA3mjzZ",
      "expanded_url" : "https:\/\/www.romper.com\/p\/why-im-honest-with-my-kids-about-my-open-relationship-7012",
      "display_url" : "romper.com\/p\/why-im-hones\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714743070139490304",
  "text" : "why i\u2019m honest with my kids about my open relationship https:\/\/t.co\/b7VWA3mjzZ",
  "id" : 714743070139490304,
  "created_at" : "2016-03-29 09:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714734654889336832",
  "geo" : { },
  "id_str" : "714737908729659392",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander ah, i think i got it. having gmaps isn\u2019t enough, seems you need the general google app as well.",
  "id" : 714737908729659392,
  "in_reply_to_status_id" : 714734654889336832,
  "created_at" : "2016-03-29 08:56:11 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714734654889336832",
  "geo" : { },
  "id_str" : "714735221682384897",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander that is empty ever since Latitude shut down :( Guess because I\u2019m running iOS over Android?",
  "id" : 714735221682384897,
  "in_reply_to_status_id" : 714734654889336832,
  "created_at" : "2016-03-29 08:45:30 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714733402969214977",
  "geo" : { },
  "id_str" : "714733591218024449",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander that\u2019s also a good solution. I used to get that kind of data from Google Latitude before they shut down :(",
  "id" : 714733591218024449,
  "in_reply_to_status_id" : 714733402969214977,
  "created_at" : "2016-03-29 08:39:01 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "The Conversation US",
      "screen_name" : "ConversationUS",
      "indices" : [ 121, 136 ],
      "id_str" : "2733320850",
      "id" : 2733320850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WO8R68cqWR",
      "expanded_url" : "https:\/\/theconversation.com\/if-we-dont-own-our-genes-what-protects-study-subjects-in-genetic-research-56003",
      "display_url" : "theconversation.com\/if-we-dont-own\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714729148632145920",
  "text" : "RT @EffyVayena: If we don't own our genes, what protects study subjects in genetic research? https:\/\/t.co\/WO8R68cqWR via @ConversationUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation US",
        "screen_name" : "ConversationUS",
        "indices" : [ 105, 120 ],
        "id_str" : "2733320850",
        "id" : 2733320850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/WO8R68cqWR",
        "expanded_url" : "https:\/\/theconversation.com\/if-we-dont-own-our-genes-what-protects-study-subjects-in-genetic-research-56003",
        "display_url" : "theconversation.com\/if-we-dont-own\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714688514328276993",
    "text" : "If we don't own our genes, what protects study subjects in genetic research? https:\/\/t.co\/WO8R68cqWR via @ConversationUS",
    "id" : 714688514328276993,
    "created_at" : "2016-03-29 05:39:54 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 714729148632145920,
  "created_at" : "2016-03-29 08:21:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INACTIVE JOE",
      "screen_name" : "jtotheizzoe",
      "indices" : [ 3, 15 ],
      "id_str" : "809629697193680896",
      "id" : 809629697193680896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/J2RYReqgQs",
      "expanded_url" : "http:\/\/bit.ly\/1VQP1Gw",
      "display_url" : "bit.ly\/1VQP1Gw"
    } ]
  },
  "geo" : { },
  "id_str" : "714722507484487681",
  "text" : "RT @jtotheizzoe: Who cares about the Magna Carta or Louisiana Purchase when you've got endosymbiosis? Lovin\u2026 https:\/\/t.co\/J2RYReqgQs https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jtotheizzoe\/status\/714646981319241729\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/csuMlsPFHn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CervpKDWEAIvua2.jpg",
        "id_str" : "714646981243703298",
        "id" : 714646981243703298,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CervpKDWEAIvua2.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/csuMlsPFHn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/J2RYReqgQs",
        "expanded_url" : "http:\/\/bit.ly\/1VQP1Gw",
        "display_url" : "bit.ly\/1VQP1Gw"
      } ]
    },
    "geo" : { },
    "id_str" : "714646981319241729",
    "text" : "Who cares about the Magna Carta or Louisiana Purchase when you've got endosymbiosis? Lovin\u2026 https:\/\/t.co\/J2RYReqgQs https:\/\/t.co\/csuMlsPFHn",
    "id" : 714646981319241729,
    "created_at" : "2016-03-29 02:54:52 +0000",
    "user" : {
      "name" : "Joe Hanson",
      "screen_name" : "DrJoeHanson",
      "protected" : false,
      "id_str" : "26099938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684812926205562880\/hDwHS2bt_normal.jpg",
      "id" : 26099938,
      "verified" : true
    }
  },
  "id" : 714722507484487681,
  "created_at" : "2016-03-29 07:54:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/WOF4SItgbM",
      "expanded_url" : "https:\/\/twitter.com\/darth\/status\/714644718915747840",
      "display_url" : "twitter.com\/darth\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714719844084662272",
  "text" : "and that\u2019s why I have trust-issues https:\/\/t.co\/WOF4SItgbM",
  "id" : 714719844084662272,
  "created_at" : "2016-03-29 07:44:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714718155155832832",
  "geo" : { },
  "id_str" : "714719102191943680",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander yes, or could just remove all data points from dates where you know you\u2019ve traveled. I just happened to have the GPS data :)",
  "id" : 714719102191943680,
  "in_reply_to_status_id" : 714718155155832832,
  "created_at" : "2016-03-29 07:41:27 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714686313618911235",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393566483174, 8.753533264193006 ]
  },
  "id_str" : "714690524163268608",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander (but if you don\u2019t travel too frequently you could also just use the weather at your home base)",
  "id" : 714690524163268608,
  "in_reply_to_status_id" : 714686313618911235,
  "created_at" : "2016-03-29 05:47:53 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714686313618911235",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393566483174, 8.753533264193006 ]
  },
  "id_str" : "714690374908960768",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander what I enjoyed doing was linking my step counts to weather data via my geo location as collected by Swarm.",
  "id" : 714690374908960768,
  "in_reply_to_status_id" : 714686313618911235,
  "created_at" : "2016-03-29 05:47:18 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/AmGpw8JQrn",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/714550068968341505",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714560950620266496",
  "text" : "\u00ABBeing open \u2013 unfortunately \u2013 is a privilege but not a right.\u00BB https:\/\/t.co\/AmGpw8JQrn",
  "id" : 714560950620266496,
  "created_at" : "2016-03-28 21:13:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/dfxSL67X6v",
      "expanded_url" : "https:\/\/twitter.com\/notSoJunkDNA\/status\/714541313673326592",
      "display_url" : "twitter.com\/notSoJunkDNA\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714545113721094145",
  "text" : "\u00ABSure, for shared co-authorship given that I solved a really hard problem.\u00BB https:\/\/t.co\/dfxSL67X6v",
  "id" : 714545113721094145,
  "created_at" : "2016-03-28 20:10:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 0, 9 ],
      "id_str" : "96902749",
      "id" : 96902749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714515004985200640",
  "geo" : { },
  "id_str" : "714515266596634624",
  "in_reply_to_user_id" : 96902749,
  "text" : "@sniyazov that looks fun :)",
  "id" : 714515266596634624,
  "in_reply_to_status_id" : 714515004985200640,
  "created_at" : "2016-03-28 18:11:29 +0000",
  "in_reply_to_screen_name" : "sniyazov",
  "in_reply_to_user_id_str" : "96902749",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Weigel",
      "screen_name" : "Choosy_Female",
      "indices" : [ 3, 17 ],
      "id_str" : "881369844",
      "id" : 881369844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Bsc9ZXqrlT",
      "expanded_url" : "http:\/\/buff.ly\/22TL8ma",
      "display_url" : "buff.ly\/22TL8ma"
    } ]
  },
  "geo" : { },
  "id_str" : "714514955115040768",
  "text" : "RT @Choosy_Female: I was a terrible PhD supervisor. Don't make the same mistakes I did https:\/\/t.co\/Bsc9ZXqrlT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Bsc9ZXqrlT",
        "expanded_url" : "http:\/\/buff.ly\/22TL8ma",
        "display_url" : "buff.ly\/22TL8ma"
      } ]
    },
    "geo" : { },
    "id_str" : "714512749615833088",
    "text" : "I was a terrible PhD supervisor. Don't make the same mistakes I did https:\/\/t.co\/Bsc9ZXqrlT",
    "id" : 714512749615833088,
    "created_at" : "2016-03-28 18:01:29 +0000",
    "user" : {
      "name" : "Emily Weigel",
      "screen_name" : "Choosy_Female",
      "protected" : false,
      "id_str" : "881369844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586232015260889088\/ya2-6gyI_normal.png",
      "id" : 881369844,
      "verified" : false
    }
  },
  "id" : 714514955115040768,
  "created_at" : "2016-03-28 18:10:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/1EjBbNfVSt",
      "expanded_url" : "http:\/\/ruleofthirds.de\/quantifiedself\/",
      "display_url" : "ruleofthirds.de\/quantifiedself\/"
    } ]
  },
  "in_reply_to_status_id_str" : "714493297583108096",
  "geo" : { },
  "id_str" : "714496343859929088",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander let me know if you need some inspiration for analyses :) https:\/\/t.co\/1EjBbNfVSt",
  "id" : 714496343859929088,
  "in_reply_to_status_id" : 714493297583108096,
  "created_at" : "2016-03-28 16:56:17 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    }, {
      "name" : "Moira Weigel",
      "screen_name" : "moiragweigel",
      "indices" : [ 92, 105 ],
      "id_str" : "2218124766",
      "id" : 2218124766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ZCPVXu9FbY",
      "expanded_url" : "http:\/\/gu.com\/p\/4hn4g\/stw",
      "display_url" : "gu.com\/p\/4hn4g\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "714490751145652224",
  "text" : "RT @atossaaraxia: \u2018Fitbit for your period\u2019: a terrific story on fertility tracking apps, by @moiragweigel https:\/\/t.co\/ZCPVXu9FbY  @gdnlong\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moira Weigel",
        "screen_name" : "moiragweigel",
        "indices" : [ 74, 87 ],
        "id_str" : "2218124766",
        "id" : 2218124766
      }, {
        "name" : "The Long Read",
        "screen_name" : "gdnlongread",
        "indices" : [ 113, 125 ],
        "id_str" : "2853449164",
        "id" : 2853449164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ZCPVXu9FbY",
        "expanded_url" : "http:\/\/gu.com\/p\/4hn4g\/stw",
        "display_url" : "gu.com\/p\/4hn4g\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "714489926801367042",
    "text" : "\u2018Fitbit for your period\u2019: a terrific story on fertility tracking apps, by @moiragweigel https:\/\/t.co\/ZCPVXu9FbY  @gdnlongread",
    "id" : 714489926801367042,
    "created_at" : "2016-03-28 16:30:47 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 714490751145652224,
  "created_at" : "2016-03-28 16:34:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714480080760737792",
  "geo" : { },
  "id_str" : "714481786189975552",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski you have my address, right? :D",
  "id" : 714481786189975552,
  "in_reply_to_status_id" : 714480080760737792,
  "created_at" : "2016-03-28 15:58:26 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/W9DgFF4Lcj",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/714478209824206848",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714480602502848513",
  "text" : "I still feel \u201EAn Incoherence of Philosophers\u201C would be the a great collective noun for them. https:\/\/t.co\/W9DgFF4Lcj",
  "id" : 714480602502848513,
  "created_at" : "2016-03-28 15:53:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714475493408387072",
  "geo" : { },
  "id_str" : "714477712778375168",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy probably not compatible with your version. Go back to step 1 of version hell.",
  "id" : 714477712778375168,
  "in_reply_to_status_id" : 714475493408387072,
  "created_at" : "2016-03-28 15:42:15 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caren Cooper",
      "screen_name" : "CoopSciScoop",
      "indices" : [ 0, 13 ],
      "id_str" : "622300794",
      "id" : 622300794
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 14, 30 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 31, 45 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714467828166955009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10908128698367, 8.732384573676374 ]
  },
  "id_str" : "714468082182459392",
  "in_reply_to_user_id" : 622300794,
  "text" : "@CoopSciScoop @kevinschawinski @PenguinGalaxy but academia certainly doesn\u2019t think of us as pro scientists unless the PI is involved",
  "id" : 714468082182459392,
  "in_reply_to_status_id" : 714467828166955009,
  "created_at" : "2016-03-28 15:03:59 +0000",
  "in_reply_to_screen_name" : "CoopSciScoop",
  "in_reply_to_user_id_str" : "622300794",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Caren Cooper",
      "screen_name" : "CoopSciScoop",
      "indices" : [ 17, 30 ],
      "id_str" : "622300794",
      "id" : 622300794
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 31, 45 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714465778284818433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10692722168761, 8.72484421358325 ]
  },
  "id_str" : "714466588414582784",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @CoopSciScoop @PenguinGalaxy does openSNP count as academic establishment doesn\u2019t see PhD students as scientists anyhow?",
  "id" : 714466588414582784,
  "in_reply_to_status_id" : 714465778284818433,
  "created_at" : "2016-03-28 14:58:03 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "FamiLAB",
      "screen_name" : "FamiLAB",
      "indices" : [ 65, 73 ],
      "id_str" : "71624794",
      "id" : 71624794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "CodeFest",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714460715571089408",
  "text" : "RT @OBF_BOSC: Announcing #BOSC2016 #CodeFest: 6-7 July hosted by @FamiLAB, preceding Bioinformatics Open Source Conference (BOSC) https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FamiLAB",
        "screen_name" : "FamiLAB",
        "indices" : [ 51, 59 ],
        "id_str" : "71624794",
        "id" : 71624794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 11, 20 ]
      }, {
        "text" : "CodeFest",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4cQY0ZB1GN",
        "expanded_url" : "https:\/\/wp.me\/p7fHjD-nW",
        "display_url" : "wp.me\/p7fHjD-nW"
      } ]
    },
    "geo" : { },
    "id_str" : "714453854855815168",
    "text" : "Announcing #BOSC2016 #CodeFest: 6-7 July hosted by @FamiLAB, preceding Bioinformatics Open Source Conference (BOSC) https:\/\/t.co\/4cQY0ZB1GN",
    "id" : 714453854855815168,
    "created_at" : "2016-03-28 14:07:27 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 714460715571089408,
  "created_at" : "2016-03-28 14:34:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714443015482449920",
  "text" : "RT @LGBTSTEM: Looking into finding advice for LGBT+ people travelling abroad for work (conferences, field trips, etc) Anyone know of any us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "714364687031336960",
    "text" : "Looking into finding advice for LGBT+ people travelling abroad for work (conferences, field trips, etc) Anyone know of any useful resources?",
    "id" : 714364687031336960,
    "created_at" : "2016-03-28 08:13:08 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 714443015482449920,
  "created_at" : "2016-03-28 13:24:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/714390209140535296\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/AyeBbpfJpT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGGgAWQAAa9MQ.jpg",
      "id_str" : "714390199632019456",
      "id" : 714390199632019456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGGgAWQAAa9MQ.jpg",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/AyeBbpfJpT"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/714390209140535296\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/AyeBbpfJpT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGGfuXEAEaqsX.jpg",
      "id_str" : "714390199556575233",
      "id" : 714390199556575233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGGfuXEAEaqsX.jpg",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 147,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AyeBbpfJpT"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsWhatAScientistLooksLike",
      "indices" : [ 13, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/kkTkDWU2F9",
      "expanded_url" : "http:\/\/www.isb-sib.ch\/research\/groups-and-group-leaders",
      "display_url" : "isb-sib.ch\/research\/group\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714423360508334080",
  "text" : "RT @marc_rr: #ThisIsWhatAScientistLooksLike https:\/\/t.co\/kkTkDWU2F9 :-) https:\/\/t.co\/AyeBbpfJpT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/714390209140535296\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/AyeBbpfJpT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGGgAWQAAa9MQ.jpg",
        "id_str" : "714390199632019456",
        "id" : 714390199632019456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGGgAWQAAa9MQ.jpg",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/AyeBbpfJpT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/714390209140535296\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/AyeBbpfJpT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoGGfuXEAEaqsX.jpg",
        "id_str" : "714390199556575233",
        "id" : 714390199556575233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoGGfuXEAEaqsX.jpg",
        "sizes" : [ {
          "h" : 221,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 147,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/AyeBbpfJpT"
      } ],
      "hashtags" : [ {
        "text" : "ThisIsWhatAScientistLooksLike",
        "indices" : [ 0, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/kkTkDWU2F9",
        "expanded_url" : "http:\/\/www.isb-sib.ch\/research\/groups-and-group-leaders",
        "display_url" : "isb-sib.ch\/research\/group\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714390209140535296",
    "text" : "#ThisIsWhatAScientistLooksLike https:\/\/t.co\/kkTkDWU2F9 :-) https:\/\/t.co\/AyeBbpfJpT",
    "id" : 714390209140535296,
    "created_at" : "2016-03-28 09:54:33 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 714423360508334080,
  "created_at" : "2016-03-28 12:06:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/vcb5ctJNkC",
      "expanded_url" : "https:\/\/twitter.com\/ozaed\/status\/714417949076021248",
      "display_url" : "twitter.com\/ozaed\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714418171625734144",
  "text" : "So now it\u2019s step 1: strangle a GNU with Bootstraps https:\/\/t.co\/vcb5ctJNkC",
  "id" : 714418171625734144,
  "created_at" : "2016-03-28 11:45:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie Redfield",
      "screen_name" : "RosieRedfield",
      "indices" : [ 3, 17 ],
      "id_str" : "177005581",
      "id" : 177005581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/k7dtAeoH78",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Wikipedia:Wiki_Ed\/University_of_British_Columbia\/BIOL_345_Human_Ecology_%28Term_2%29",
      "display_url" : "en.wikipedia.org\/wiki\/Wikipedia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714417276309671937",
  "text" : "RT @RosieRedfield: I am SO proud of the Wikipedia pages my Human Ecology (BIOL 345) students are creating!  https:\/\/t.co\/k7dtAeoH78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/k7dtAeoH78",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Wikipedia:Wiki_Ed\/University_of_British_Columbia\/BIOL_345_Human_Ecology_%28Term_2%29",
        "display_url" : "en.wikipedia.org\/wiki\/Wikipedia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "714148532433760257",
    "text" : "I am SO proud of the Wikipedia pages my Human Ecology (BIOL 345) students are creating!  https:\/\/t.co\/k7dtAeoH78",
    "id" : 714148532433760257,
    "created_at" : "2016-03-27 17:54:13 +0000",
    "user" : {
      "name" : "Rosie Redfield",
      "screen_name" : "RosieRedfield",
      "protected" : false,
      "id_str" : "177005581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000390438025\/545e994de2e4538aecc57abefa4620cb_normal.jpeg",
      "id" : 177005581,
      "verified" : false
    }
  },
  "id" : 714417276309671937,
  "created_at" : "2016-03-28 11:42:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/9hnBFVQzzv",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/714276896452665345",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714416576410349568",
  "text" : "Step 1: Sacrifice a chicken. https:\/\/t.co\/9hnBFVQzzv",
  "id" : 714416576410349568,
  "created_at" : "2016-03-28 11:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714411741346734081",
  "text" : "\u00ABIn fact, we\u2019re having this date because Richard Stallman reminded me of you.\u00BB The chapters of my (unwritten) autobiography name themselves.",
  "id" : 714411741346734081,
  "created_at" : "2016-03-28 11:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 14, 28 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 29, 44 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 45, 58 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 59, 68 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Open Access Button",
      "screen_name" : "OA_Button",
      "indices" : [ 69, 79 ],
      "id_str" : "1569180318",
      "id" : 1569180318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/taSipXc3Ar",
      "expanded_url" : "http:\/\/imgur.com\/R7tEQPA",
      "display_url" : "imgur.com\/R7tEQPA"
    } ]
  },
  "in_reply_to_status_id_str" : "714241076945674240",
  "geo" : { },
  "id_str" : "714243151368744960",
  "in_reply_to_user_id" : 2396006202,
  "text" : "@petergrabitz @Protohedgehog @MozillaScience @RaoOfPhysics @open_con @OA_Button encountering paywalls w\/ sci-hub: https:\/\/t.co\/taSipXc3Ar",
  "id" : 714243151368744960,
  "in_reply_to_status_id" : 714241076945674240,
  "created_at" : "2016-03-28 00:10:11 +0000",
  "in_reply_to_screen_name" : "PeterRolandG",
  "in_reply_to_user_id_str" : "2396006202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 14, 28 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 29, 44 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 45, 58 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 59, 68 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Open Access Button",
      "screen_name" : "OA_Button",
      "indices" : [ 69, 79 ],
      "id_str" : "1569180318",
      "id" : 1569180318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/89BbPniGCJ",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/DNAxrXSQSzzji\/200.gif",
      "display_url" : "media4.giphy.com\/media\/DNAxrXSQ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "714241076945674240",
  "geo" : { },
  "id_str" : "714242185592438784",
  "in_reply_to_user_id" : 2396006202,
  "text" : "@petergrabitz @Protohedgehog @MozillaScience @RaoOfPhysics @open_con @OA_Button encountering paywalls w\/o sci-hub: https:\/\/t.co\/89BbPniGCJ",
  "id" : 714242185592438784,
  "in_reply_to_status_id" : 714241076945674240,
  "created_at" : "2016-03-28 00:06:21 +0000",
  "in_reply_to_screen_name" : "PeterRolandG",
  "in_reply_to_user_id_str" : "2396006202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/uZ7r4RRtmP",
      "expanded_url" : "http:\/\/i.imgur.com\/yynZodr.gif",
      "display_url" : "i.imgur.com\/yynZodr.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "714239811813576705",
  "text" : "In which journals can you submit animated GIF figures? Asking for https:\/\/t.co\/uZ7r4RRtmP",
  "id" : 714239811813576705,
  "created_at" : "2016-03-27 23:56:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/AoLXjk9PDp",
      "expanded_url" : "http:\/\/fusion.net\/story\/281403\/bdsm-while-black\/",
      "display_url" : "fusion.net\/story\/281403\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714214266186907648",
  "text" : "When you want to be into BDSM but it\u2019s too soon because you\u2019re black https:\/\/t.co\/AoLXjk9PDp",
  "id" : 714214266186907648,
  "created_at" : "2016-03-27 22:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714161820672663552",
  "geo" : { },
  "id_str" : "714190230325170176",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc \uD83D\uDC96 I went for a supply run yesterday and cooked a mean skakshuka in the meantime. \uD83D\uDE0A",
  "id" : 714190230325170176,
  "in_reply_to_status_id" : 714161820672663552,
  "created_at" : "2016-03-27 20:39:54 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/kpOi148GnV",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/713757524864798720",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390958121287, 8.753512409672293 ]
  },
  "id_str" : "713762617597239296",
  "text" : "I\u2019ll take `False Dichotomy\u2019 for 500\u2026 https:\/\/t.co\/kpOi148GnV",
  "id" : 713762617597239296,
  "created_at" : "2016-03-26 16:20:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 0, 13 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713745334816653312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398463923295, 8.753461082903017 ]
  },
  "id_str" : "713760757440258049",
  "in_reply_to_user_id" : 1891806212,
  "text" : "@AcademicsSay couldn\u2019t just RT it, could you\u2026 \uD83D\uDE14",
  "id" : 713760757440258049,
  "in_reply_to_status_id" : 713745334816653312,
  "created_at" : "2016-03-26 16:13:20 +0000",
  "in_reply_to_screen_name" : "AcademicsSay",
  "in_reply_to_user_id_str" : "1891806212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/5V0i93cVkL",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/713727543644270593",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713731712753266697",
  "text" : "That\u2019s not an Evolutionary Stable Strategy! https:\/\/t.co\/5V0i93cVkL",
  "id" : 713731712753266697,
  "created_at" : "2016-03-26 14:17:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713725782376452097",
  "geo" : { },
  "id_str" : "713731427804835840",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine \uD83D\uDC99",
  "id" : 713731427804835840,
  "in_reply_to_status_id" : 713725782376452097,
  "created_at" : "2016-03-26 14:16:47 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Heller",
      "screen_name" : "plomlompom",
      "indices" : [ 0, 11 ],
      "id_str" : "7941582",
      "id" : 7941582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713712514727587841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11033333376992, 8.780105849736165 ]
  },
  "id_str" : "713712921415647232",
  "in_reply_to_user_id" : 7941582,
  "text" : "@plomlompom it\u2019s like Microsoft would start a party lobbying for equal rights for AI today.",
  "id" : 713712921415647232,
  "in_reply_to_status_id" : 713712514727587841,
  "created_at" : "2016-03-26 13:03:15 +0000",
  "in_reply_to_screen_name" : "plomlompom",
  "in_reply_to_user_id_str" : "7941582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ZXvmpIEC5E",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/713709845753552896",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713709845753552896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10801435452895, 8.766436474405943 ]
  },
  "id_str" : "713710520084381697",
  "in_reply_to_user_id" : 14286491,
  "text" : "Though it\u2019s somewhat fitting. The promises of de Grey are just as likely to happen as that of any other politician https:\/\/t.co\/ZXvmpIEC5E",
  "id" : 713710520084381697,
  "in_reply_to_status_id" : 713709845753552896,
  "created_at" : "2016-03-26 12:53:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10891641494828, 8.763440530755336 ]
  },
  "id_str" : "713709845753552896",
  "text" : "There is a German \u2018Party for Health Research\u2019 and Aubrey de Grey is member of the advisory council. Please kill me. \uD83D\uDE02",
  "id" : 713709845753552896,
  "created_at" : "2016-03-26 12:51:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713631475917307904",
  "geo" : { },
  "id_str" : "713684154500706304",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick \u201Ehypothetical protein\u201C :p",
  "id" : 713684154500706304,
  "in_reply_to_status_id" : 713631475917307904,
  "created_at" : "2016-03-26 11:08:56 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/VlSQFRjNtn",
      "expanded_url" : "https:\/\/twitter.com\/PaulLikeMe\/status\/713623676902588416",
      "display_url" : "twitter.com\/PaulLikeMe\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713683754527666176",
  "text" : "They grow up so quickly. https:\/\/t.co\/VlSQFRjNtn",
  "id" : 713683754527666176,
  "created_at" : "2016-03-26 11:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karen zack",
      "screen_name" : "teenybiscuit",
      "indices" : [ 3, 16 ],
      "id_str" : "50934251",
      "id" : 50934251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713682663714893824",
  "text" : "RT @teenybiscuit: the snail is the only animal emoji facing the other direction. the only one that can kiss. the universal kiss master\n\n\uD83D\uDC0C\uD83D\uDC00",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712472582713270272",
    "text" : "the snail is the only animal emoji facing the other direction. the only one that can kiss. the universal kiss master\n\n\uD83D\uDC0C\uD83D\uDC00",
    "id" : 712472582713270272,
    "created_at" : "2016-03-23 02:54:35 +0000",
    "user" : {
      "name" : "karen zack",
      "screen_name" : "teenybiscuit",
      "protected" : false,
      "id_str" : "50934251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816772500163948544\/cq7gqI8P_normal.jpg",
      "id" : 50934251,
      "verified" : false
    }
  },
  "id" : 713682663714893824,
  "created_at" : "2016-03-26 11:03:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/y2LOQijV7j",
      "expanded_url" : "http:\/\/motherboard.vice.com\/read\/how-to-make-a-not-racist-bot",
      "display_url" : "motherboard.vice.com\/read\/how-to-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713678963168645120",
  "text" : "how to make a bot that isn\u2019t racist https:\/\/t.co\/y2LOQijV7j",
  "id" : 713678963168645120,
  "created_at" : "2016-03-26 10:48:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles A. Carringto",
      "screen_name" : "SFriedScientist",
      "indices" : [ 0, 16 ],
      "id_str" : "797037928627273728",
      "id" : 797037928627273728
    }, {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 17, 25 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ozJZlASI5P",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/713452638059237377",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "713533526189219840",
  "geo" : { },
  "id_str" : "713533714488291328",
  "in_reply_to_user_id" : 19325156,
  "text" : "@SFriedScientist @JBYoder and can I list tweets as contributions done so far? https:\/\/t.co\/ozJZlASI5P",
  "id" : 713533714488291328,
  "in_reply_to_status_id" : 713533526189219840,
  "created_at" : "2016-03-26 01:11:09 +0000",
  "in_reply_to_screen_name" : "DrAndrewThaler",
  "in_reply_to_user_id_str" : "19325156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713532834355351552",
  "geo" : { },
  "id_str" : "713533316540997633",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder \u201Esorry, can\u2019t go out this weekend. I\u2019m on NDT-BS duty.\u201C",
  "id" : 713533316540997633,
  "in_reply_to_status_id" : 713532834355351552,
  "created_at" : "2016-03-26 01:09:34 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713527705879322625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11134306004509, 8.757818694775121 ]
  },
  "id_str" : "713528568958087168",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish good to know the coffee didn\u2019t inherit its fortune!",
  "id" : 713528568958087168,
  "in_reply_to_status_id" : 713527705879322625,
  "created_at" : "2016-03-26 00:50:42 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Greenspan",
      "screen_name" : "samlistens",
      "indices" : [ 0, 11 ],
      "id_str" : "31125463",
      "id" : 31125463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713514161846796289",
  "geo" : { },
  "id_str" : "713515043892150272",
  "in_reply_to_user_id" : 31125463,
  "text" : "@samlistens \uD83D\uDC4D",
  "id" : 713515043892150272,
  "in_reply_to_status_id" : 713514161846796289,
  "created_at" : "2016-03-25 23:56:57 +0000",
  "in_reply_to_screen_name" : "samlistens",
  "in_reply_to_user_id_str" : "31125463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan Booker",
      "screen_name" : "Ethan_Booker",
      "indices" : [ 3, 16 ],
      "id_str" : "19955411",
      "id" : 19955411
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Ethan_Booker\/status\/543879125648539650\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ObX0hUv863",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4w_LrwCIAAc1JK.png",
      "id_str" : "543879124960288768",
      "id" : 543879124960288768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4w_LrwCIAAc1JK.png",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 894
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 894
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 894
      } ],
      "display_url" : "pic.twitter.com\/ObX0hUv863"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713503599133925380",
  "text" : "RT @Ethan_Booker: \"When you see only one set of footprints, it was then that I carried you.\" http:\/\/t.co\/ObX0hUv863",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ethan_Booker\/status\/543879125648539650\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/ObX0hUv863",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4w_LrwCIAAc1JK.png",
        "id_str" : "543879124960288768",
        "id" : 543879124960288768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4w_LrwCIAAc1JK.png",
        "sizes" : [ {
          "h" : 491,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 894
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 894
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 894
        } ],
        "display_url" : "pic.twitter.com\/ObX0hUv863"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543879125648539650",
    "text" : "\"When you see only one set of footprints, it was then that I carried you.\" http:\/\/t.co\/ObX0hUv863",
    "id" : 543879125648539650,
    "created_at" : "2014-12-13 21:24:22 +0000",
    "user" : {
      "name" : "Ethan Booker",
      "screen_name" : "Ethan_Booker",
      "protected" : false,
      "id_str" : "19955411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925664334516244480\/L80IrSUn_normal.jpg",
      "id" : 19955411,
      "verified" : false
    }
  },
  "id" : 713503599133925380,
  "created_at" : "2016-03-25 23:11:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TysonBiologyFacts",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/98SP4BFlw6",
      "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/713447387130257408",
      "display_url" : "twitter.com\/hormiga\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713452638059237377",
  "text" : "Foie deGrasse is made using the inhumane practice of force-feeding people to many wrong factoids\u2026 #TysonBiologyFacts https:\/\/t.co\/98SP4BFlw6",
  "id" : 713452638059237377,
  "created_at" : "2016-03-25 19:48:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/YK1T2WSF0i",
      "expanded_url" : "https:\/\/twitter.com\/EdwardTufte\/status\/713438153252667392",
      "display_url" : "twitter.com\/EdwardTufte\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713446573909417988",
  "text" : "DooDooDooDoo\u2026 https:\/\/t.co\/YK1T2WSF0i",
  "id" : 713446573909417988,
  "created_at" : "2016-03-25 19:24:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Gilcher",
      "screen_name" : "Argorak",
      "indices" : [ 0, 8 ],
      "id_str" : "27227212",
      "id" : 27227212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713443589406257158",
  "geo" : { },
  "id_str" : "713444039501213701",
  "in_reply_to_user_id" : 27227212,
  "text" : "@Argorak would say it renders \u201Ecorrectly\u201C in Chrome, but ever since watching the talk I\u2019m agnostic when it comes to correct rendering :D",
  "id" : 713444039501213701,
  "in_reply_to_status_id" : 713443589406257158,
  "created_at" : "2016-03-25 19:14:48 +0000",
  "in_reply_to_screen_name" : "Argorak",
  "in_reply_to_user_id_str" : "27227212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/G4rajn4m45",
      "expanded_url" : "http:\/\/rtl.wtf\/",
      "display_url" : "rtl.wtf"
    } ]
  },
  "in_reply_to_status_id_str" : "713138221488672769",
  "geo" : { },
  "id_str" : "713442731134218241",
  "in_reply_to_user_id" : 14286491,
  "text" : "Good thing I finally watched the last 5 minutes of that talk, because https:\/\/t.co\/G4rajn4m45 is worth it.",
  "id" : 713442731134218241,
  "in_reply_to_status_id" : 713138221488672769,
  "created_at" : "2016-03-25 19:09:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frightened Rabbit",
      "screen_name" : "FRabbits",
      "indices" : [ 18, 27 ],
      "id_str" : "43200260",
      "id" : 43200260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139865130854, 8.753463463285446 ]
  },
  "id_str" : "713343807346053120",
  "text" : "Got my ticket for @FRabbits in Portland. This means giving two gigs and seeing two gigs so far! \uD83C\uDFB8\uD83D\uDCCA",
  "id" : 713343807346053120,
  "created_at" : "2016-03-25 12:36:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713267142863548416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083749511652, 8.818658304558635 ]
  },
  "id_str" : "713275723600044032",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc wow, that\u2019s even worse. All the best for your food run \uD83D\uDE0A",
  "id" : 713275723600044032,
  "in_reply_to_status_id" : 713267142863548416,
  "created_at" : "2016-03-25 08:05:59 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713179191710244864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06068617960047, 8.818776963512832 ]
  },
  "id_str" : "713179716044369920",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks have fun! I\u2019ll raise my glass and toast from afar \uD83D\uDE0A",
  "id" : 713179716044369920,
  "in_reply_to_status_id" : 713179191710244864,
  "created_at" : "2016-03-25 01:44:29 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 8, 20 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713150299465187329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087452723487, 8.818525989362923 ]
  },
  "id_str" : "713151871100301313",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @3rdreviewer thanks! \uD83D\uDE0A",
  "id" : 713151871100301313,
  "in_reply_to_status_id" : 713150299465187329,
  "created_at" : "2016-03-24 23:53:50 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713141675053461504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06019757869901, 8.81825822530178 ]
  },
  "id_str" : "713143994402934784",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik yeah. I wouldn\u2019t have bought the middle ground myself. Especially given your evidence.",
  "id" : 713143994402934784,
  "in_reply_to_status_id" : 713141675053461504,
  "created_at" : "2016-03-24 23:22:32 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/713138221488672769\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/eizp2imOBV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeWTbmpXEAAe1sM.jpg",
      "id_str" : "713138218447867904",
      "id" : 713138218447867904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeWTbmpXEAAe1sM.jpg",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/eizp2imOBV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/oeY91Jfn19",
      "expanded_url" : "https:\/\/opensource.com\/life\/16\/3\/twisted-road-right-left-language-support",
      "display_url" : "opensource.com\/life\/16\/3\/twis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713138221488672769",
  "text" : "The twisted road through right-to-left language support https:\/\/t.co\/oeY91Jfn19 https:\/\/t.co\/eizp2imOBV",
  "id" : 713138221488672769,
  "created_at" : "2016-03-24 22:59:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713136260064415744",
  "geo" : { },
  "id_str" : "713136607302402049",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik I can only imagine. Even better you managed it :)",
  "id" : 713136607302402049,
  "in_reply_to_status_id" : 713136260064415744,
  "created_at" : "2016-03-24 22:53:11 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriploidTree",
      "screen_name" : "TriploidTree",
      "indices" : [ 0, 13 ],
      "id_str" : "14165662",
      "id" : 14165662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713124438406000640",
  "geo" : { },
  "id_str" : "713125281985388544",
  "in_reply_to_user_id" : 14165662,
  "text" : "@TriploidTree yes, i think once they got the idea of \u201Eharness\u201C == \u201Eclippers\u201C the benefit\u2019s gone.  ;)",
  "id" : 713125281985388544,
  "in_reply_to_status_id" : 713124438406000640,
  "created_at" : "2016-03-24 22:08:11 +0000",
  "in_reply_to_screen_name" : "TriploidTree",
  "in_reply_to_user_id_str" : "14165662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/GMcjOdQmcF",
      "expanded_url" : "https:\/\/twitter.com\/mariskreizman\/status\/713111810732376065",
      "display_url" : "twitter.com\/mariskreizman\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713122180184350720",
  "text" : "\u00ABA restraining device that fits in a door frame to keep\u2026\u00BB sex toy or dog toy, now on Kickstarter as well. https:\/\/t.co\/GMcjOdQmcF",
  "id" : 713122180184350720,
  "created_at" : "2016-03-24 21:55:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713099847394598912",
  "geo" : { },
  "id_str" : "713117834692399104",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik congrats!",
  "id" : 713117834692399104,
  "in_reply_to_status_id" : 713099847394598912,
  "created_at" : "2016-03-24 21:38:35 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713090265796517888",
  "geo" : { },
  "id_str" : "713116744982900737",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess *hugsifwanted*",
  "id" : 713116744982900737,
  "in_reply_to_status_id" : 713090265796517888,
  "created_at" : "2016-03-24 21:34:15 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenn-bit art",
      "screen_name" : "jennschiffer",
      "indices" : [ 3, 16 ],
      "id_str" : "12524622",
      "id" : 12524622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713100274194325510",
  "text" : "RT @jennschiffer: re: npm drama &amp; how guys are responding, i'd like to bring to your attn the infinite times women in tech are told they're\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712654385071923200",
    "text" : "re: npm drama &amp; how guys are responding, i'd like to bring to your attn the infinite times women in tech are told they're being \"emotional\"",
    "id" : 712654385071923200,
    "created_at" : "2016-03-23 14:57:00 +0000",
    "user" : {
      "name" : "jenn-bit art",
      "screen_name" : "jennschiffer",
      "protected" : false,
      "id_str" : "12524622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926283541050249216\/h6jyhl08_normal.jpg",
      "id" : 12524622,
      "verified" : false
    }
  },
  "id" : 713100274194325510,
  "created_at" : "2016-03-24 20:28:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10406064211206, 8.74940991346127 ]
  },
  "id_str" : "713088765363941376",
  "text" : "I guess my lent starts now, as I forgot that everything\u2019s closed down by 8pm today and there isn\u2019t even Ramen in the house. \uD83D\uDC4D",
  "id" : 713088765363941376,
  "created_at" : "2016-03-24 19:43:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713024983107301376",
  "geo" : { },
  "id_str" : "713034384115236865",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna \uD83D\uDC4D\uD83D\uDCDA",
  "id" : 713034384115236865,
  "in_reply_to_status_id" : 713024983107301376,
  "created_at" : "2016-03-24 16:06:59 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Vicente",
      "screen_name" : "Pablo_1990",
      "indices" : [ 0, 11 ],
      "id_str" : "37391225",
      "id" : 37391225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713018043329355778",
  "geo" : { },
  "id_str" : "713018093572923392",
  "in_reply_to_user_id" : 37391225,
  "text" : "@Pablo_1990 thanks!",
  "id" : 713018093572923392,
  "in_reply_to_status_id" : 713018043329355778,
  "created_at" : "2016-03-24 15:02:15 +0000",
  "in_reply_to_screen_name" : "Pablo_1990",
  "in_reply_to_user_id_str" : "37391225",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Vicente",
      "screen_name" : "Pablo_1990",
      "indices" : [ 0, 11 ],
      "id_str" : "37391225",
      "id" : 37391225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713017153868406785",
  "geo" : { },
  "id_str" : "713017470378983424",
  "in_reply_to_user_id" : 37391225,
  "text" : "@Pablo_1990 only briefly and couldn\u2019t find an easy way to do it on first glance.",
  "id" : 713017470378983424,
  "in_reply_to_status_id" : 713017153868406785,
  "created_at" : "2016-03-24 14:59:46 +0000",
  "in_reply_to_screen_name" : "Pablo_1990",
  "in_reply_to_user_id_str" : "37391225",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "713013468429877248",
  "geo" : { },
  "id_str" : "713013682754744320",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology sure, bgreshake@gmail.com happy to try to extend the blogpost\/do a second w\/ more languages &amp; heatmaps :)",
  "id" : 713013682754744320,
  "in_reply_to_status_id" : 713013468429877248,
  "created_at" : "2016-03-24 14:44:43 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 5, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713011693308215296",
  "text" : "lazy #bioinformatics twitter: is there an easy\/free way to get the in\/out degree\/centrality for each node in all KEGG pathways?",
  "id" : 713011693308215296,
  "created_at" : "2016-03-24 14:36:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/X1HJPWeeqU",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/3\/24\/11294674\/cameron-esposito-marriage-material-interview-review",
      "display_url" : "vox.com\/2016\/3\/24\/1129\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713005601320730625",
  "text" : "why period jokes should be the new dick jokes https:\/\/t.co\/X1HJPWeeqU",
  "id" : 713005601320730625,
  "created_at" : "2016-03-24 14:12:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 60, 72 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/4l4zbmSujR",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/03\/24\/crazed-heavy-metal-drummer-acc.html",
      "display_url" : "boingboing.net\/2016\/03\/24\/cra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712998857978810368",
  "text" : "everything can be made heavy metal if you only want to! \/cc @froggleston  https:\/\/t.co\/4l4zbmSujR",
  "id" : 712998857978810368,
  "created_at" : "2016-03-24 13:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712985254307446785",
  "geo" : { },
  "id_str" : "712986021001052160",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju it just works!",
  "id" : 712986021001052160,
  "in_reply_to_status_id" : 712985254307446785,
  "created_at" : "2016-03-24 12:54:48 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 0, 10 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 11, 23 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 24, 37 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712971774716149760",
  "geo" : { },
  "id_str" : "712980141627023360",
  "in_reply_to_user_id" : 147949965,
  "text" : "@abellogin @rosettacode @neuroecology thanks, that\u2019s a cool idea!",
  "id" : 712980141627023360,
  "in_reply_to_status_id" : 712971774716149760,
  "created_at" : "2016-03-24 12:31:26 +0000",
  "in_reply_to_screen_name" : "abellogin",
  "in_reply_to_user_id_str" : "147949965",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712967451198275584",
  "geo" : { },
  "id_str" : "712971655283351553",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam i see, just to make sure that this will be part of the training as well :)",
  "id" : 712971655283351553,
  "in_reply_to_status_id" : 712967451198275584,
  "created_at" : "2016-03-24 11:57:43 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/5S2eJBJF0s",
      "expanded_url" : "https:\/\/twitter.com\/haldaume3\/status\/712794259448066048",
      "display_url" : "twitter.com\/haldaume3\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712952587654402049",
  "text" : "Oh yes! https:\/\/t.co\/5S2eJBJF0s",
  "id" : 712952587654402049,
  "created_at" : "2016-03-24 10:41:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712945441629872128",
  "geo" : { },
  "id_str" : "712946511664062464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice :D",
  "id" : 712946511664062464,
  "in_reply_to_status_id" : 712945441629872128,
  "created_at" : "2016-03-24 10:17:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712942424088256512",
  "geo" : { },
  "id_str" : "712946083828264960",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam more like \u201EI like my content to be inaccessible for many, so I systematically shut out screen readers and automatic translation\u201C.",
  "id" : 712946083828264960,
  "in_reply_to_status_id" : 712942424088256512,
  "created_at" : "2016-03-24 10:16:06 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Dilworth PhD",
      "screen_name" : "PolycrystalhD",
      "indices" : [ 3, 17 ],
      "id_str" : "963401670",
      "id" : 963401670
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 48, 59 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TearsofBlonde",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712942488667992065",
  "text" : "RT @PolycrystalhD: PS: in case you've missed it @HopeJahren is sharing \"male privilege is a hell of a drug\" stories using #TearsofBlonde",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hope Jahren",
        "screen_name" : "HopeJahren",
        "indices" : [ 29, 40 ],
        "id_str" : "322658299",
        "id" : 322658299
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TearsofBlonde",
        "indices" : [ 103, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712796737119760385",
    "text" : "PS: in case you've missed it @HopeJahren is sharing \"male privilege is a hell of a drug\" stories using #TearsofBlonde",
    "id" : 712796737119760385,
    "created_at" : "2016-03-24 00:22:39 +0000",
    "user" : {
      "name" : "Crystal Dilworth PhD",
      "screen_name" : "PolycrystalhD",
      "protected" : false,
      "id_str" : "963401670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906412680558161920\/gPhEAFW7_normal.jpg",
      "id" : 963401670,
      "verified" : true
    }
  },
  "id" : 712942488667992065,
  "created_at" : "2016-03-24 10:01:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712925747548135425",
  "text" : "Wow, I'm amazed by the awesome Summer of Code proposals we\u2019ve received for openSNP so far, especially given how late we\u2019re to the party.",
  "id" : 712925747548135425,
  "created_at" : "2016-03-24 08:55:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712872281068974081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06074860372548, 8.818796961596917 ]
  },
  "id_str" : "712901150664695808",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err wow, thanks a lot. It\u2019s always nice to know that people find it useful! \uD83D\uDE0D",
  "id" : 712901150664695808,
  "in_reply_to_status_id" : 712872281068974081,
  "created_at" : "2016-03-24 07:17:34 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712751218867716097",
  "geo" : { },
  "id_str" : "712753910839185410",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach well, actually\u2026 :P",
  "id" : 712753910839185410,
  "in_reply_to_status_id" : 712751218867716097,
  "created_at" : "2016-03-23 21:32:29 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Inger Mewburn",
      "screen_name" : "thesiswhisperer",
      "indices" : [ 3, 19 ],
      "id_str" : "38630406",
      "id" : 38630406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/0QhVNOaEiY",
      "expanded_url" : "http:\/\/buff.ly\/22uYGrF",
      "display_url" : "buff.ly\/22uYGrF"
    } ]
  },
  "geo" : { },
  "id_str" : "712730201248149504",
  "text" : "RT @thesiswhisperer: How to email your supervisor (or, the tyranny of tiny tasks and what you can do about it) https:\/\/t.co\/0QhVNOaEiY #phd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phdchat",
        "indices" : [ 114, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/0QhVNOaEiY",
        "expanded_url" : "http:\/\/buff.ly\/22uYGrF",
        "display_url" : "buff.ly\/22uYGrF"
      } ]
    },
    "geo" : { },
    "id_str" : "712459518429495297",
    "text" : "How to email your supervisor (or, the tyranny of tiny tasks and what you can do about it) https:\/\/t.co\/0QhVNOaEiY #phdchat",
    "id" : 712459518429495297,
    "created_at" : "2016-03-23 02:02:40 +0000",
    "user" : {
      "name" : "Dr Inger Mewburn",
      "screen_name" : "thesiswhisperer",
      "protected" : false,
      "id_str" : "38630406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000773111630\/18ad08196ed4c244b3de6baba5e0a0e9_normal.png",
      "id" : 38630406,
      "verified" : false
    }
  },
  "id" : 712730201248149504,
  "created_at" : "2016-03-23 19:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/fvL26BTcGP",
      "expanded_url" : "https:\/\/medium.com\/@zaksmith_\/james-deen-cookie-monster-c05490730609#.6ws1jkd84",
      "display_url" : "medium.com\/@zaksmith_\/jam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712688783217569792",
  "text" : "\u00ABthe media\u2019s assessment of James Deen was still a failure of WMD-in-Iraq proportions.\u00BB https:\/\/t.co\/fvL26BTcGP",
  "id" : 712688783217569792,
  "created_at" : "2016-03-23 17:13:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Wbf52Na8gk",
      "expanded_url" : "http:\/\/fusion.net\/story\/283181\/rural-tinder-online-dating\/?utm_campaign=ThisIsFusion&utm_source=Twitter&utm_medium=social",
      "display_url" : "fusion.net\/story\/283181\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712675191718088704",
  "text" : "What it\u2019s like to play Tinder in rural\u00A0America https:\/\/t.co\/Wbf52Na8gk",
  "id" : 712675191718088704,
  "created_at" : "2016-03-23 16:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 3, 11 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/pJtW5eSP3P",
      "expanded_url" : "http:\/\/ecologybits.com\/index.php\/2016\/03\/23\/i-am-unwilling-to-relocate-again-and-it-will-probably-cost-me-my-academic-career\/",
      "display_url" : "ecologybits.com\/index.php\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712674431638839296",
  "text" : "RT @cbahlai: I am unwilling to relocate again (and it will probably cost me my academic \"career\") https:\/\/t.co\/pJtW5eSP3P via @margaretkosm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Margaret Kosmala",
        "screen_name" : "margaretkosmala",
        "indices" : [ 113, 129 ],
        "id_str" : "580216612",
        "id" : 580216612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/pJtW5eSP3P",
        "expanded_url" : "http:\/\/ecologybits.com\/index.php\/2016\/03\/23\/i-am-unwilling-to-relocate-again-and-it-will-probably-cost-me-my-academic-career\/",
        "display_url" : "ecologybits.com\/index.php\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712656289151717377",
    "text" : "I am unwilling to relocate again (and it will probably cost me my academic \"career\") https:\/\/t.co\/pJtW5eSP3P via @margaretkosmala",
    "id" : 712656289151717377,
    "created_at" : "2016-03-23 15:04:34 +0000",
    "user" : {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "protected" : false,
      "id_str" : "958649520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705843854973530112\/S992pAjY_normal.jpg",
      "id" : 958649520,
      "verified" : false
    }
  },
  "id" : 712674431638839296,
  "created_at" : "2016-03-23 16:16:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/HocZCnDC2e",
      "expanded_url" : "https:\/\/www.techinasia.com\/awkward-moment-apple-mocked-good-hardware-poor-people",
      "display_url" : "techinasia.com\/awkward-moment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712654873603473408",
  "text" : "That awkward moment when Apple mocked good hardware and poor people https:\/\/t.co\/HocZCnDC2e",
  "id" : 712654873603473408,
  "created_at" : "2016-03-23 14:58:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/xGtNF7NrGp",
      "expanded_url" : "https:\/\/31.media.tumblr.com\/a611df6b2a5063dd240a7fd442c04b5c\/tumblr_nvrkbiQhJx1qeckplo1_r1_400.gif",
      "display_url" : "31.media.tumblr.com\/a611df6b2a5063\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712639476279984129",
  "geo" : { },
  "id_str" : "712651500686811136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/xGtNF7NrGp",
  "id" : 712651500686811136,
  "in_reply_to_status_id" : 712639476279984129,
  "created_at" : "2016-03-23 14:45:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/g26nVWf9N3",
      "expanded_url" : "http:\/\/bmcgenomics.biomedcentral.com\/articles\/10.1186\/s12864-015-1973-7",
      "display_url" : "bmcgenomics.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712650547086671872",
  "text" : "Guess which paper was 2nd most influential in BMC Genomics in 2015 according to Altmetric? \uD83C\uDF89 https:\/\/t.co\/g26nVWf9N3",
  "id" : 712650547086671872,
  "created_at" : "2016-03-23 14:41:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 7, 14 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712633121917808641",
  "geo" : { },
  "id_str" : "712633226267910144",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed @lsanoj which I don\u2019t really get :D",
  "id" : 712633226267910144,
  "in_reply_to_status_id" : 712633121917808641,
  "created_at" : "2016-03-23 13:32:55 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Ou9rouyLo7",
      "expanded_url" : "http:\/\/l.aunch.us\/w2WDe",
      "display_url" : "l.aunch.us\/w2WDe"
    } ]
  },
  "geo" : { },
  "id_str" : "712631818453913600",
  "text" : "lazyweb, is there any cross-platform messenger system around except for the signal beta? https:\/\/t.co\/Ou9rouyLo7",
  "id" : 712631818453913600,
  "created_at" : "2016-03-23 13:27:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712629168631099392",
  "geo" : { },
  "id_str" : "712630059593547776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot pendelst du damit bald zur Arbeit? :D",
  "id" : 712630059593547776,
  "in_reply_to_status_id" : 712629168631099392,
  "created_at" : "2016-03-23 13:20:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712624018776592385",
  "geo" : { },
  "id_str" : "712625199527669760",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist thanks for sharing \uD83D\uDE00",
  "id" : 712625199527669760,
  "in_reply_to_status_id" : 712624018776592385,
  "created_at" : "2016-03-23 13:01:02 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712624606725713920",
  "text" : "\u00ABWhat\u2019s your plan for after finishing your degree?\u00BB \u2013 \u00ABGoing home, crying, drinking myself to sleep.\u00BB",
  "id" : 712624606725713920,
  "created_at" : "2016-03-23 12:58:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712612947680444416",
  "geo" : { },
  "id_str" : "712624150121226241",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim sorry to hear that. Best of luck for the next proposal!",
  "id" : 712624150121226241,
  "in_reply_to_status_id" : 712612947680444416,
  "created_at" : "2016-03-23 12:56:51 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712622471070027776",
  "geo" : { },
  "id_str" : "712622722669494272",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr Ah, thought it\u2019s \u201Ewe all can just pretend he\u2019s dead so we don\u2019t have to take notice any longer\u201C :)",
  "id" : 712622722669494272,
  "in_reply_to_status_id" : 712622471070027776,
  "created_at" : "2016-03-23 12:51:11 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712610111978663936",
  "geo" : { },
  "id_str" : "712621986401398786",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr uh, that\u2019s a joke right? :D",
  "id" : 712621986401398786,
  "in_reply_to_status_id" : 712610111978663936,
  "created_at" : "2016-03-23 12:48:16 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712608229897801728",
  "geo" : { },
  "id_str" : "712621211948355584",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish @Lobot I swear that was unrelated to your latest travel plans :p",
  "id" : 712621211948355584,
  "in_reply_to_status_id" : 712608229897801728,
  "created_at" : "2016-03-23 12:45:11 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712616122852491264",
  "text" : "\u00ABI have a very simple gold standard for my cooking: I haven\u2019t killed anyone with it, so far.\u00BB",
  "id" : 712616122852491264,
  "created_at" : "2016-03-23 12:24:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/hyRsVFWt94",
      "expanded_url" : "https:\/\/twitter.com\/HopeJahren\/status\/712580151201046528",
      "display_url" : "twitter.com\/HopeJahren\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712590804708171780",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC34 https:\/\/t.co\/hyRsVFWt94",
  "id" : 712590804708171780,
  "created_at" : "2016-03-23 10:44:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712581509916540928",
  "geo" : { },
  "id_str" : "712585035602386944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot there\u2019s a support act, so who knows? :D",
  "id" : 712585035602386944,
  "in_reply_to_status_id" : 712581509916540928,
  "created_at" : "2016-03-23 10:21:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 30, 41 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/LYKt9sApZx",
      "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/#opensnp",
      "display_url" : "obf.github.io\/GSoC\/ideas\/#op\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712582774339805184",
  "text" : "RT @beaugunderson: very cool, @openSNPorg is looking for students for paid Summer of Code projects: https:\/\/t.co\/LYKt9sApZx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 11, 22 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/LYKt9sApZx",
        "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/#opensnp",
        "display_url" : "obf.github.io\/GSoC\/ideas\/#op\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712048051444129792",
    "text" : "very cool, @openSNPorg is looking for students for paid Summer of Code projects: https:\/\/t.co\/LYKt9sApZx",
    "id" : 712048051444129792,
    "created_at" : "2016-03-21 22:47:39 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 712582774339805184,
  "created_at" : "2016-03-23 10:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "__crusoe",
      "indices" : [ 0, 9 ],
      "id_str" : "1613383471",
      "id" : 1613383471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712551059210768384",
  "geo" : { },
  "id_str" : "712578143710744577",
  "in_reply_to_user_id" : 1613383471,
  "text" : "@__crusoe \uD83E\uDD16\uD83D\uDC96",
  "id" : 712578143710744577,
  "in_reply_to_status_id" : 712551059210768384,
  "created_at" : "2016-03-23 09:54:03 +0000",
  "in_reply_to_screen_name" : "__crusoe",
  "in_reply_to_user_id_str" : "1613383471",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712561423579267072",
  "text" : "Sometimes automatically added calendar items are weird: \u00ABTicket: Contemporary folk band from Oakland playing with Americana\/roots group\u00BB",
  "id" : 712561423579267072,
  "created_at" : "2016-03-23 08:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 44, 56 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/4VSPaNp29t",
      "expanded_url" : "https:\/\/github.com\/thewinnower\/terrier",
      "display_url" : "github.com\/thewinnower\/te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712552944462405632",
  "text" : "Another pull request merged into terrier by @theWinnower \uD83D\uDE0D https:\/\/t.co\/4VSPaNp29t",
  "id" : 712552944462405632,
  "created_at" : "2016-03-23 08:13:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712407811754340353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077714863755, 8.81861303334007 ]
  },
  "id_str" : "712414964628201474",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson \uD83D\uDC4D",
  "id" : 712414964628201474,
  "in_reply_to_status_id" : 712407811754340353,
  "created_at" : "2016-03-22 23:05:38 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/GdGpfxTYqq",
      "expanded_url" : "https:\/\/twitter.com\/DOAJplus\/status\/712283880980684800",
      "display_url" : "twitter.com\/DOAJplus\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712397097706921984",
  "text" : "RT @iaravps: #opencon folks, have you seen this? https:\/\/t.co\/GdGpfxTYqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/GdGpfxTYqq",
        "expanded_url" : "https:\/\/twitter.com\/DOAJplus\/status\/712283880980684800",
        "display_url" : "twitter.com\/DOAJplus\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712382701689511936",
    "text" : "#opencon folks, have you seen this? https:\/\/t.co\/GdGpfxTYqq",
    "id" : 712382701689511936,
    "created_at" : "2016-03-22 20:57:26 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 712397097706921984,
  "created_at" : "2016-03-22 21:54:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat McKitten",
      "screen_name" : "yuiofthesun",
      "indices" : [ 0, 12 ],
      "id_str" : "513049579",
      "id" : 513049579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712329363904196609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17658004590497, 8.630073181689752 ]
  },
  "id_str" : "712329733502062593",
  "in_reply_to_user_id" : 513049579,
  "text" : "@yuiofthesun yes, so much :)",
  "id" : 712329733502062593,
  "in_reply_to_status_id" : 712329363904196609,
  "created_at" : "2016-03-22 17:26:57 +0000",
  "in_reply_to_screen_name" : "yuiofthesun",
  "in_reply_to_user_id_str" : "513049579",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712318938256957441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17659456749534, 8.630149520416767 ]
  },
  "id_str" : "712327292643631105",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick do you remember the 8.8.8.8 so you can finally use DNS? :D",
  "id" : 712327292643631105,
  "in_reply_to_status_id" : 712318938256957441,
  "created_at" : "2016-03-22 17:17:15 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712304767633121280",
  "geo" : { },
  "id_str" : "712306099295285250",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr aye, well maybe we\u2019ll at least find some time after the event :)",
  "id" : 712306099295285250,
  "in_reply_to_status_id" : 712304767633121280,
  "created_at" : "2016-03-22 15:53:02 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712303847734005760",
  "geo" : { },
  "id_str" : "712303997185630209",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr hope to see you there :)",
  "id" : 712303997185630209,
  "in_reply_to_status_id" : 712303847734005760,
  "created_at" : "2016-03-22 15:44:41 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/pOR8nvJPu4",
      "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/712297575492263936",
      "display_url" : "twitter.com\/brembs\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712298596113248256",
  "text" : "\u00ABhe is to announce sainthood for supporters of Open Access publication &amp; those who make code available on GitHub.\u00BB https:\/\/t.co\/pOR8nvJPu4",
  "id" : 712298596113248256,
  "created_at" : "2016-03-22 15:23:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike T\u24D0ylor",
      "screen_name" : "MikeTaylor",
      "indices" : [ 3, 14 ],
      "id_str" : "278930750",
      "id" : 278930750
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 120, 136 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/DNyyBCKLWw",
      "expanded_url" : "http:\/\/ruleofthirds.de\/open-science-policy-platform\/",
      "display_url" : "ruleofthirds.de\/open-science-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712291823595745281",
  "text" : "RT @MikeTaylor: A citizen-science-oriented candidate for the EC's Open Science Policy Platform: https:\/\/t.co\/DNyyBCKLWw\n@gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 104, 120 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/DNyyBCKLWw",
        "expanded_url" : "http:\/\/ruleofthirds.de\/open-science-policy-platform\/",
        "display_url" : "ruleofthirds.de\/open-science-p\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "712278218154381312",
    "geo" : { },
    "id_str" : "712291711033221121",
    "in_reply_to_user_id" : 278930750,
    "text" : "A citizen-science-oriented candidate for the EC's Open Science Policy Platform: https:\/\/t.co\/DNyyBCKLWw\n@gedankenstuecke",
    "id" : 712291711033221121,
    "in_reply_to_status_id" : 712278218154381312,
    "created_at" : "2016-03-22 14:55:52 +0000",
    "in_reply_to_screen_name" : "MikeTaylor",
    "in_reply_to_user_id_str" : "278930750",
    "user" : {
      "name" : "Mike T\u24D0ylor",
      "screen_name" : "MikeTaylor",
      "protected" : false,
      "id_str" : "278930750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848114058884677632\/rNy8yBvj_normal.jpg",
      "id" : 278930750,
      "verified" : false
    }
  },
  "id" : 712291823595745281,
  "created_at" : "2016-03-22 14:56:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/S5HgNvpRFp",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/125",
      "display_url" : "existentialcomics.com\/comic\/125"
    } ]
  },
  "geo" : { },
  "id_str" : "712265528639885312",
  "text" : "The hard drugs teenagers use these days\u2026 https:\/\/t.co\/S5HgNvpRFp",
  "id" : 712265528639885312,
  "created_at" : "2016-03-22 13:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/GFkxBSjNqQ",
      "expanded_url" : "https:\/\/twitter.com\/menstrupedia\/status\/712242130975133700",
      "display_url" : "twitter.com\/menstrupedia\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712258355868344320",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/GFkxBSjNqQ",
  "id" : 712258355868344320,
  "created_at" : "2016-03-22 12:43:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceOpen",
      "screen_name" : "Science_Open",
      "indices" : [ 0, 13 ],
      "id_str" : "1246397209",
      "id" : 1246397209
    }, {
      "name" : "Mike T\u24D0ylor",
      "screen_name" : "MikeTaylor",
      "indices" : [ 34, 45 ],
      "id_str" : "278930750",
      "id" : 278930750
    }, {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 46, 53 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/3STuJRnlGR",
      "expanded_url" : "http:\/\/ruleofthirds.de\/open-science-policy-platform\/",
      "display_url" : "ruleofthirds.de\/open-science-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712257043512619008",
  "geo" : { },
  "id_str" : "712257201566576641",
  "in_reply_to_user_id" : 1246397209,
  "text" : "@Science_Open oh, right, see here @MikeTaylor @brembs &amp; co https:\/\/t.co\/3STuJRnlGR",
  "id" : 712257201566576641,
  "in_reply_to_status_id" : 712257043512619008,
  "created_at" : "2016-03-22 12:38:44 +0000",
  "in_reply_to_screen_name" : "Science_Open",
  "in_reply_to_user_id_str" : "1246397209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 3, 15 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OA",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712240791918387200",
  "text" : "RT @froggleston: This is gold. The argument that traditional publishing (\"trad shite\") has more rigour than #OA is null and void. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OA",
        "indices" : [ 91, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/WXfzbOq5zC",
        "expanded_url" : "https:\/\/twitter.com\/Neuro_Skeptic\/status\/711970614685409280",
        "display_url" : "twitter.com\/Neuro_Skeptic\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712229209331073024",
    "text" : "This is gold. The argument that traditional publishing (\"trad shite\") has more rigour than #OA is null and void. https:\/\/t.co\/WXfzbOq5zC",
    "id" : 712229209331073024,
    "created_at" : "2016-03-22 10:47:30 +0000",
    "user" : {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "protected" : false,
      "id_str" : "53893339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742344707469086720\/UP8kTNU-_normal.jpg",
      "id" : 53893339,
      "verified" : false
    }
  },
  "id" : 712240791918387200,
  "created_at" : "2016-03-22 11:33:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/3STuJRnlGR",
      "expanded_url" : "http:\/\/ruleofthirds.de\/open-science-policy-platform\/",
      "display_url" : "ruleofthirds.de\/open-science-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712219311230812160",
  "text" : "btw: i also applied to join the European #openscience policy platform, see here: https:\/\/t.co\/3STuJRnlGR",
  "id" : 712219311230812160,
  "created_at" : "2016-03-22 10:08:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/4xxqh78MV9",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2016\/mar\/21\/death-by-gentrification-the-killing-that-shamed-san-francisco?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/us-news\/2016\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712215791400325120",
  "text" : "Death by gentrification: the killing that shamed San Francisco https:\/\/t.co\/4xxqh78MV9",
  "id" : 712215791400325120,
  "created_at" : "2016-03-22 09:54:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/GshmMHKhh6",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/712180042231578625",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712210782101053440",
  "text" : "See you in Geneva in September! https:\/\/t.co\/GshmMHKhh6",
  "id" : 712210782101053440,
  "created_at" : "2016-03-22 09:34:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/JXuPAeQshz",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/noti",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712156751865520128",
  "geo" : { },
  "id_str" : "712209790454386688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i\u2019m using https:\/\/t.co\/JXuPAeQshz for that end.",
  "id" : 712209790454386688,
  "in_reply_to_status_id" : 712156751865520128,
  "created_at" : "2016-03-22 09:30:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712062172935880705",
  "geo" : { },
  "id_str" : "712062415458967552",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon nope, in that case some undergrad would loose the arm while PI Jones wins the Nobel.",
  "id" : 712062415458967552,
  "in_reply_to_status_id" : 712062172935880705,
  "created_at" : "2016-03-21 23:44:43 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/HC0TRJyDI4",
      "expanded_url" : "http:\/\/i.imgur.com\/oRGJk.gif",
      "display_url" : "i.imgur.com\/oRGJk.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "712061504888160256",
  "text" : "How Indiana Jones manages deadlines is the best evidence he\u2019s a true academic. https:\/\/t.co\/HC0TRJyDI4",
  "id" : 712061504888160256,
  "created_at" : "2016-03-21 23:41:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712050802857086976",
  "geo" : { },
  "id_str" : "712052508781371392",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez thanks, some people got forward, hope they will all apply! :)",
  "id" : 712052508781371392,
  "in_reply_to_status_id" : 712050802857086976,
  "created_at" : "2016-03-21 23:05:22 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712050301772038144",
  "geo" : { },
  "id_str" : "712050396722810881",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @beaugunderson you two are the best! :)",
  "id" : 712050396722810881,
  "in_reply_to_status_id" : 712050301772038144,
  "created_at" : "2016-03-21 22:56:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "712019886998827009",
  "geo" : { },
  "id_str" : "712020046831288322",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap personally I fully support the idea quoted in the article: As long as the bias is \u00B1 consistent it doesn\u2019t even matter.",
  "id" : 712020046831288322,
  "in_reply_to_status_id" : 712019886998827009,
  "created_at" : "2016-03-21 20:56:22 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/3zjtU2eF2t",
      "expanded_url" : "http:\/\/cardiobrief.org\/2016\/03\/21\/new-evidence-fitness-trackers-dont-actually-track-fitness\/",
      "display_url" : "cardiobrief.org\/2016\/03\/21\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "712019346734915584",
  "text" : "Surprise, consumer products are not 100% accurate: \u00ABNew Evidence Fitness Trackers Don\u2019t Actually Track Fitness\u00BB https:\/\/t.co\/3zjtU2eF2t",
  "id" : 712019346734915584,
  "created_at" : "2016-03-21 20:53:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711982873977425920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17658090937991, 8.630060047550703 ]
  },
  "id_str" : "711982996996411392",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ich wei\u00DF genau was du meinst, keine Sorge \uD83D\uDE18",
  "id" : 711982996996411392,
  "in_reply_to_status_id" : 711982873977425920,
  "created_at" : "2016-03-21 18:29:09 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711978296267898881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17657437361188, 8.630106689481174 ]
  },
  "id_str" : "711978462664388608",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen na gut, winzigen H\u00E4nde. \uD83D\uDC4C",
  "id" : 711978462664388608,
  "in_reply_to_status_id" : 711978296267898881,
  "created_at" : "2016-03-21 18:11:08 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711970556330057730",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17657327677091, 8.630111659962871 ]
  },
  "id_str" : "711977644649086976",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen viel wichtiger: endlich wieder ein Ger\u00E4t was in meine zarten H\u00E4nde passt \uD83D\uDC96",
  "id" : 711977644649086976,
  "in_reply_to_status_id" : 711970556330057730,
  "created_at" : "2016-03-21 18:07:53 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/FIfzb3hm7z",
      "expanded_url" : "http:\/\/i276.photobucket.com\/albums\/kk3\/jasonvoytek\/procrastination.gif",
      "display_url" : "i276.photobucket.com\/albums\/kk3\/jas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "711886204992671744",
  "geo" : { },
  "id_str" : "711893818497503232",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna hanging above my bed for a couple of years :D https:\/\/t.co\/FIfzb3hm7z",
  "id" : 711893818497503232,
  "in_reply_to_status_id" : 711886204992671744,
  "created_at" : "2016-03-21 12:34:47 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/lXfS2Hgaw6",
      "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/#opensnp",
      "display_url" : "obf.github.io\/GSoC\/ideas\/#op\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711890270221180928",
  "text" : "Once more: Friday\u2019s the last call for becoming a Google Summer of Code student, possibly with openSNP! Details: https:\/\/t.co\/lXfS2Hgaw6",
  "id" : 711890270221180928,
  "created_at" : "2016-03-21 12:20:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711885502014693376",
  "geo" : { },
  "id_str" : "711889841395515392",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch i nearly died on my coffee when I saw it :D",
  "id" : 711889841395515392,
  "in_reply_to_status_id" : 711885502014693376,
  "created_at" : "2016-03-21 12:18:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 15, 29 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711880363103100928",
  "geo" : { },
  "id_str" : "711883183336378368",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @annakrystalli oh, and I think i\u2019ll actually be in Leipzig at 26th or so, could easily come over to Berlin then. :)",
  "id" : 711883183336378368,
  "in_reply_to_status_id" : 711880363103100928,
  "created_at" : "2016-03-21 11:52:31 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 15, 29 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711874541291761665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16735395879796, 8.624031819484237 ]
  },
  "id_str" : "711876090508218368",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @Protohedgehog I\u2019ll be in Portland from 16th to 23rd but otherwise I\u2019m game. :)",
  "id" : 711876090508218368,
  "in_reply_to_status_id" : 711874541291761665,
  "created_at" : "2016-03-21 11:24:20 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711871838494859264",
  "geo" : { },
  "id_str" : "711872716995952640",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli oh no, we again missed each other in Berlin by just a few days!",
  "id" : 711872716995952640,
  "in_reply_to_status_id" : 711871838494859264,
  "created_at" : "2016-03-21 11:10:56 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyra Schwarz",
      "screen_name" : "kyra_schwarz",
      "indices" : [ 3, 16 ],
      "id_str" : "4131950894",
      "id" : 4131950894
    }, {
      "name" : "realscientists: Dr. Lisa Buckley, Palaeontologist",
      "screen_name" : "realscientists",
      "indices" : [ 18, 33 ],
      "id_str" : "1144882621",
      "id" : 1144882621
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademicSelfCare",
      "indices" : [ 109, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711869692156243968",
  "text" : "RT @kyra_schwarz: @realscientists a self care cheat sheet can be a great starting point for help when stuck  #AcademicSelfCare https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "realscientists: Dr. Lisa Buckley, Palaeontologist",
        "screen_name" : "realscientists",
        "indices" : [ 0, 15 ],
        "id_str" : "1144882621",
        "id" : 1144882621
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kyra_schwarz\/status\/711718674973888512\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/HLMmuQlGYF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeCIXM0UkAAlXyi.jpg",
        "id_str" : "711718673283584000",
        "id" : 711718673283584000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeCIXM0UkAAlXyi.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 849
        }, {
          "h" : 1753,
          "resize" : "fit",
          "w" : 1240
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1753,
          "resize" : "fit",
          "w" : 1240
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 481
        } ],
        "display_url" : "pic.twitter.com\/HLMmuQlGYF"
      } ],
      "hashtags" : [ {
        "text" : "AcademicSelfCare",
        "indices" : [ 91, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711718674973888512",
    "in_reply_to_user_id" : 1144882621,
    "text" : "@realscientists a self care cheat sheet can be a great starting point for help when stuck  #AcademicSelfCare https:\/\/t.co\/HLMmuQlGYF",
    "id" : 711718674973888512,
    "created_at" : "2016-03-21 00:58:49 +0000",
    "in_reply_to_screen_name" : "realscientists",
    "in_reply_to_user_id_str" : "1144882621",
    "user" : {
      "name" : "Kyra Schwarz",
      "screen_name" : "kyra_schwarz",
      "protected" : false,
      "id_str" : "4131950894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662157037929824256\/OFDitdIz_normal.png",
      "id" : 4131950894,
      "verified" : false
    }
  },
  "id" : 711869692156243968,
  "created_at" : "2016-03-21 10:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711850206371913728",
  "geo" : { },
  "id_str" : "711868187164467200",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute soon they\u2019ll dispatch a self-driving towing truck :P",
  "id" : 711868187164467200,
  "in_reply_to_status_id" : 711850206371913728,
  "created_at" : "2016-03-21 10:52:56 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 17, 29 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/LWJh8Moph8",
      "expanded_url" : "https:\/\/www.facebook.com\/sam.kalidi\/videos\/vb.582911621\/10153724797521622",
      "display_url" : "facebook.com\/sam.kalidi\/vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711866102079483904",
  "text" : "Got tagged here. @helgerausch really knows me! https:\/\/t.co\/LWJh8Moph8",
  "id" : 711866102079483904,
  "created_at" : "2016-03-21 10:44:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711860999092101121",
  "geo" : { },
  "id_str" : "711861642120859649",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen hallo, es ist ja wohl total wichtig als erstes im Flugzeug zu sitzen um dann darauf zu warten das alle anderen einsteigen",
  "id" : 711861642120859649,
  "in_reply_to_status_id" : 711860999092101121,
  "created_at" : "2016-03-21 10:26:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711859038741516288",
  "geo" : { },
  "id_str" : "711859367604314112",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @Lobot auch wenn mir nicht ganz klar ist was f\u00FCr ein Statement es ist :D",
  "id" : 711859367604314112,
  "in_reply_to_status_id" : 711859038741516288,
  "created_at" : "2016-03-21 10:17:53 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711858044955656192",
  "geo" : { },
  "id_str" : "711858696087801856",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @Lobot den Anblick kann man glaube ich sogar tats\u00E4chlich gerade 1:1 im WG-K\u00FChlschrank bekommen \uD83D\uDE02",
  "id" : 711858696087801856,
  "in_reply_to_status_id" : 711858044955656192,
  "created_at" : "2016-03-21 10:15:13 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711856123343736832",
  "geo" : { },
  "id_str" : "711856449329209344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i could easily grow real ones at home. So: nope :D",
  "id" : 711856449329209344,
  "in_reply_to_status_id" : 711856123343736832,
  "created_at" : "2016-03-21 10:06:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711805545007554560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247369593694, 8.627568929790083 ]
  },
  "id_str" : "711840121771917312",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds great, looking forward to meet you there! It\u2019s been a while!",
  "id" : 711840121771917312,
  "in_reply_to_status_id" : 711805545007554560,
  "created_at" : "2016-03-21 09:01:25 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711709793463967745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395768548108, 8.753527710541949 ]
  },
  "id_str" : "711712354891919360",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds happy norouz!",
  "id" : 711712354891919360,
  "in_reply_to_status_id" : 711709793463967745,
  "created_at" : "2016-03-21 00:33:43 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/IPqr0CrQ20",
      "expanded_url" : "https:\/\/twitter.com\/DaliaHatuqa\/status\/711682578223374337",
      "display_url" : "twitter.com\/DaliaHatuqa\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399616218348, 8.753451614158616 ]
  },
  "id_str" : "711711086387585024",
  "text" : "Flies pretty well for a lame duck. https:\/\/t.co\/IPqr0CrQ20",
  "id" : 711711086387585024,
  "created_at" : "2016-03-21 00:28:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 13, 25 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711688423732596737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392528712832, 8.753507035434602 ]
  },
  "id_str" : "711689533591592961",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @billymeinke I\u2019ll be there, hoping for coffee at your room!",
  "id" : 711689533591592961,
  "in_reply_to_status_id" : 711688423732596737,
  "created_at" : "2016-03-20 23:03:02 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 13, 22 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 23, 33 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 34, 46 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Dan Whaley",
      "screen_name" : "dwhly",
      "indices" : [ 47, 53 ],
      "id_str" : "287387396",
      "id" : 287387396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711688253624229889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392528712832, 8.753507035434602 ]
  },
  "id_str" : "711689446115172352",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @abbycabs @_inundata @billymeinke @dwhly noooo! \uD83D\uDE31",
  "id" : 711689446115172352,
  "in_reply_to_status_id" : 711688253624229889,
  "created_at" : "2016-03-20 23:02:41 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Zaltzman",
      "screen_name" : "HelenZaltzman",
      "indices" : [ 0, 14 ],
      "id_str" : "20689378",
      "id" : 20689378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711688029015056384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392528712832, 8.753507035434602 ]
  },
  "id_str" : "711689392767770625",
  "in_reply_to_user_id" : 20689378,
  "text" : "@helenzaltzman Cockfosters connoisseurs unite!",
  "id" : 711689392767770625,
  "in_reply_to_status_id" : 711688029015056384,
  "created_at" : "2016-03-20 23:02:28 +0000",
  "in_reply_to_screen_name" : "HelenZaltzman",
  "in_reply_to_user_id_str" : "20689378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Zaltzman",
      "screen_name" : "HelenZaltzman",
      "indices" : [ 3, 17 ],
      "id_str" : "20689378",
      "id" : 20689378
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711689171019112448",
  "text" : "RT @helenzaltzman: @gedankenstuecke the residents of Cockfosters must be so tired of other people's amusement. I will never tire.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "711634679124856832",
    "geo" : { },
    "id_str" : "711688029015056384",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke the residents of Cockfosters must be so tired of other people's amusement. I will never tire.",
    "id" : 711688029015056384,
    "in_reply_to_status_id" : 711634679124856832,
    "created_at" : "2016-03-20 22:57:03 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Helen Zaltzman",
      "screen_name" : "HelenZaltzman",
      "protected" : false,
      "id_str" : "20689378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878000737367842816\/UsaLt4SV_normal.jpg",
      "id" : 20689378,
      "verified" : false
    }
  },
  "id" : 711689171019112448,
  "created_at" : "2016-03-20 23:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711654878200930304",
  "text" : "@malech in welche Richtung denn? :)",
  "id" : 711654878200930304,
  "created_at" : "2016-03-20 20:45:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Zaltzman",
      "screen_name" : "HelenZaltzman",
      "indices" : [ 7, 21 ],
      "id_str" : "20689378",
      "id" : 20689378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/y4YiXkWjuB",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/soho",
      "display_url" : "theallusionist.org\/allusionist\/so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711634679124856832",
  "text" : "Thanks @helenzaltzman for letting me keep the childish giggles while hearing \u201ECockfosters\u201C on the tube. https:\/\/t.co\/y4YiXkWjuB",
  "id" : 711634679124856832,
  "created_at" : "2016-03-20 19:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Kevin \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "killerswan",
      "indices" : [ 9, 20 ],
      "id_str" : "14367955",
      "id" : 14367955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711603077862674433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17657360533234, 8.630112181276743 ]
  },
  "id_str" : "711614803668766720",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder @killerswan that\u2019s what I\u2019d go for too!",
  "id" : 711614803668766720,
  "in_reply_to_status_id" : 711603077862674433,
  "created_at" : "2016-03-20 18:06:05 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711543215346864128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095115335516, 8.818516072267256 ]
  },
  "id_str" : "711564782009249793",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo send greetings!",
  "id" : 711564782009249793,
  "in_reply_to_status_id" : 711543215346864128,
  "created_at" : "2016-03-20 14:47:18 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711504081412554752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083935151085, 8.818673737835105 ]
  },
  "id_str" : "711515335699075072",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen \uD83D\uDC96 und ganz viele hugs zur\u00FCck.",
  "id" : 711515335699075072,
  "in_reply_to_status_id" : 711504081412554752,
  "created_at" : "2016-03-20 11:30:50 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711500260477161472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084044099905, 8.818768853916312 ]
  },
  "id_str" : "711502534519758848",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen all the best for that \u262F",
  "id" : 711502534519758848,
  "in_reply_to_status_id" : 711500260477161472,
  "created_at" : "2016-03-20 10:39:57 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugene Borukhovich",
      "screen_name" : "HealthEugene",
      "indices" : [ 3, 16 ],
      "id_str" : "16139549",
      "id" : 16139549
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HealthEugene\/status\/711461604873916418\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/eQ5Knsjvv8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd-ejcnWEAET7fE.jpg",
      "id_str" : "711461597961654273",
      "id" : 711461597961654273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd-ejcnWEAET7fE.jpg",
      "sizes" : [ {
        "h" : 606,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/eQ5Knsjvv8"
    } ],
    "hashtags" : [ {
      "text" : "DNA",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "genome",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711501998114402304",
  "text" : "RT @HealthEugene: Walter Gilbert was one smart dude.. Almost there (well minus the compact disk) #DNA #genome https:\/\/t.co\/eQ5Knsjvv8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthEugene\/status\/711461604873916418\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/eQ5Knsjvv8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd-ejcnWEAET7fE.jpg",
        "id_str" : "711461597961654273",
        "id" : 711461597961654273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd-ejcnWEAET7fE.jpg",
        "sizes" : [ {
          "h" : 606,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 606,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/eQ5Knsjvv8"
      } ],
      "hashtags" : [ {
        "text" : "DNA",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "genome",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711461604873916418",
    "text" : "Walter Gilbert was one smart dude.. Almost there (well minus the compact disk) #DNA #genome https:\/\/t.co\/eQ5Knsjvv8",
    "id" : 711461604873916418,
    "created_at" : "2016-03-20 07:57:19 +0000",
    "user" : {
      "name" : "Eugene Borukhovich",
      "screen_name" : "HealthEugene",
      "protected" : false,
      "id_str" : "16139549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562945641140068352\/L9NG5MXg_normal.jpeg",
      "id" : 16139549,
      "verified" : false
    }
  },
  "id" : 711501998114402304,
  "created_at" : "2016-03-20 10:37:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711498271290761217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082343331657, 8.818763005322777 ]
  },
  "id_str" : "711498664175341568",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen both are unbroken, I\u2019m a very balanced rockstar ;)",
  "id" : 711498664175341568,
  "in_reply_to_status_id" : 711498271290761217,
  "created_at" : "2016-03-20 10:24:35 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094995549722, 8.818795462272083 ]
  },
  "id_str" : "711497780330696704",
  "text" : "Slipping on a puddle of lube, nearly breaking an arm and the guitar\u2019s neck. That\u2019s the rockstar life, right?",
  "id" : 711497780330696704,
  "created_at" : "2016-03-20 10:21:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/qgZXzu9TxC",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/originals\/19\/ef\/9a\/19ef9a4820f70eca4ff93e11f6f3d608.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/originals\/19\/e\u2026"
    }, {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/Ry8RyGVluK",
      "expanded_url" : "https:\/\/twitter.com\/23andMe\/status\/711410191363743748",
      "display_url" : "twitter.com\/23andMe\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711470912109830144",
  "text" : "https:\/\/t.co\/qgZXzu9TxC https:\/\/t.co\/Ry8RyGVluK",
  "id" : 711470912109830144,
  "created_at" : "2016-03-20 08:34:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711356252656259076",
  "geo" : { },
  "id_str" : "711467190969618432",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy the follow up to #yolo?",
  "id" : 711467190969618432,
  "in_reply_to_status_id" : 711356252656259076,
  "created_at" : "2016-03-20 08:19:31 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/lI3dOHn4oA",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/13B1WmJg7HwjGU\/200.gif",
      "display_url" : "media2.giphy.com\/media\/13B1WmJg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "711277743338553344",
  "geo" : { },
  "id_str" : "711294469375664128",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC one million calories! https:\/\/t.co\/lI3dOHn4oA",
  "id" : 711294469375664128,
  "in_reply_to_status_id" : 711277743338553344,
  "created_at" : "2016-03-19 20:53:11 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711263937543737344",
  "text" : "Today in my timeline: people rediscover that all scientific journals kinda suck.",
  "id" : 711263937543737344,
  "created_at" : "2016-03-19 18:51:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711249121504440320",
  "geo" : { },
  "id_str" : "711250220911337472",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke perfect :)",
  "id" : 711250220911337472,
  "in_reply_to_status_id" : 711249121504440320,
  "created_at" : "2016-03-19 17:57:21 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/0QWImwI4VJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/711233987096780806",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "711233987096780806",
  "geo" : { },
  "id_str" : "711234253737091072",
  "in_reply_to_user_id" : 14286491,
  "text" : "@billymeinke up for any of that? :D https:\/\/t.co\/0QWImwI4VJ",
  "id" : 711234253737091072,
  "in_reply_to_status_id" : 711233987096780806,
  "created_at" : "2016-03-19 16:53:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711233987096780806",
  "text" : "Frightened Rabbit, Courtney Barnett &amp; The Show Ponies will play while I\u2019m in Portland! \uD83D\uDE31\uD83D\uDE0D\uD83C\uDFB8",
  "id" : 711233987096780806,
  "created_at" : "2016-03-19 16:52:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/oBjtrgbpDF",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/711220233806155776",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711229696571281410",
  "text" : "if some rights holders had their say cretaceous commons would be time it takes for things to enter the public domain https:\/\/t.co\/oBjtrgbpDF",
  "id" : 711229696571281410,
  "created_at" : "2016-03-19 16:35:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 60, 71 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/hMW27I2zIv",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/708953715898769408",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711152756543918081",
  "text" : "RT @Lobot: Who wants to join the Summer of Code and support @openSNPorg while being funded by Google? https:\/\/t.co\/hMW27I2zIv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 49, 60 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/hMW27I2zIv",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/708953715898769408",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708976993459683328",
    "text" : "Who wants to join the Summer of Code and support @openSNPorg while being funded by Google? https:\/\/t.co\/hMW27I2zIv",
    "id" : 708976993459683328,
    "created_at" : "2016-03-13 11:24:22 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 711152756543918081,
  "created_at" : "2016-03-19 11:30:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/AHwc4pUy3A",
      "expanded_url" : "https:\/\/twitter.com\/rmathematicus\/status\/711097878123585536",
      "display_url" : "twitter.com\/rmathematicus\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086229351354, 8.81854089909123 ]
  },
  "id_str" : "711141149000536064",
  "text" : "The things that happen if you think you Fucking Love Science  https:\/\/t.co\/AHwc4pUy3A",
  "id" : 711141149000536064,
  "created_at" : "2016-03-19 10:43:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711092220254793729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093400270171, 8.818916734530507 ]
  },
  "id_str" : "711093156650024960",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston same here, missed you guys!",
  "id" : 711093156650024960,
  "in_reply_to_status_id" : 711092220254793729,
  "created_at" : "2016-03-19 07:33:14 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711090329844211713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078423030087, 8.818557644648576 ]
  },
  "id_str" : "711091459554938881",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston i hope we can bring the band back together :)",
  "id" : 711091459554938881,
  "in_reply_to_status_id" : 711090329844211713,
  "created_at" : "2016-03-19 07:26:30 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 33, 45 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711088360224260096",
  "geo" : { },
  "id_str" : "711090060679094272",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke btw. will you bring @froggleston? :D",
  "id" : 711090060679094272,
  "in_reply_to_status_id" : 711088360224260096,
  "created_at" : "2016-03-19 07:20:56 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711088360224260096",
  "geo" : { },
  "id_str" : "711088746310070272",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke absolutely, \uD83C\uDF5C and \uD83C\uDF7A \u263A\uFE0F",
  "id" : 711088746310070272,
  "in_reply_to_status_id" : 711088360224260096,
  "created_at" : "2016-03-19 07:15:43 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710992970699251712",
  "geo" : { },
  "id_str" : "711087849085530116",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke same here! \uD83D\uDE0D",
  "id" : 711087849085530116,
  "in_reply_to_status_id" : 710992970699251712,
  "created_at" : "2016-03-19 07:12:09 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 3, 15 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710969049023422464",
  "text" : "RT @ConnerHabib: At a foundational level, gender is fluid and changing.\nMy new blog on the origins of sex: The Orgy Against Identity\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9DT9QL7uH9",
        "expanded_url" : "https:\/\/connerhabib.wordpress.com\/2016\/03\/18\/the-orgy-against-identity-life-superlives-on-the-origins-of-sex-part-2\/",
        "display_url" : "connerhabib.wordpress.com\/2016\/03\/18\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710967053688016896",
    "text" : "At a foundational level, gender is fluid and changing.\nMy new blog on the origins of sex: The Orgy Against Identity\nhttps:\/\/t.co\/9DT9QL7uH9",
    "id" : 710967053688016896,
    "created_at" : "2016-03-18 23:12:09 +0000",
    "user" : {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "protected" : false,
      "id_str" : "27513314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921495228984332289\/LhDY3muU_normal.jpg",
      "id" : 27513314,
      "verified" : true
    }
  },
  "id" : 710969049023422464,
  "created_at" : "2016-03-18 23:20:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710944986590789637",
  "geo" : { },
  "id_str" : "710945940883030017",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna wenn man nur so wenige lokale K\u00FCnstler hat kennt man sie alle :p",
  "id" : 710945940883030017,
  "in_reply_to_status_id" : 710944986590789637,
  "created_at" : "2016-03-18 21:48:15 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/SUvElSIW4B",
      "expanded_url" : "http:\/\/bestanimations.com\/Music\/Instruments\/Guitars\/Acoustic\/acoustic-guitar-animated-gif-3.gif",
      "display_url" : "bestanimations.com\/Music\/Instrume\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710941541380939777",
  "geo" : { },
  "id_str" : "710944944018595842",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson more https:\/\/t.co\/SUvElSIW4B :D",
  "id" : 710944944018595842,
  "in_reply_to_status_id" : 710941541380939777,
  "created_at" : "2016-03-18 21:44:18 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710941793823670272",
  "geo" : { },
  "id_str" : "710944348238692352",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna ja, alle Todos f\u00FCr heute sind geschafft :)",
  "id" : 710944348238692352,
  "in_reply_to_status_id" : 710941793823670272,
  "created_at" : "2016-03-18 21:41:55 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710938981823807488",
  "geo" : { },
  "id_str" : "710944290730602496",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna die kommen aus der gleichen Stadt wie ich :)",
  "id" : 710944290730602496,
  "in_reply_to_status_id" : 710938981823807488,
  "created_at" : "2016-03-18 21:41:42 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710936258642616320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608880678658, 8.818563111134635 ]
  },
  "id_str" : "710938628038533120",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna der Name alleine bringt mich zur\u00FCck in meinen Geburtsort :D",
  "id" : 710938628038533120,
  "in_reply_to_status_id" : 710936258642616320,
  "created_at" : "2016-03-18 21:19:12 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/binkTzOKE5",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/yoJC2QXvTp1xrc9V5e\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/yoJC2QXv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710936318222721024",
  "text" : "today\u2019s multitasking feels like https:\/\/t.co\/binkTzOKE5",
  "id" : 710936318222721024,
  "created_at" : "2016-03-18 21:10:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710862882506993667",
  "text" : "Flights for #FORCE2016 \u2708\uFE0F\u2714\uFE0F",
  "id" : 710862882506993667,
  "created_at" : "2016-03-18 16:18:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/KQ9xpN3PoS",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371%2Fjournal.pbio.1002417",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710838209572413440",
  "text" : "\u00ABUsing Sex to Cure the Genome\u00BB Worst pick-up line ever. https:\/\/t.co\/KQ9xpN3PoS",
  "id" : 710838209572413440,
  "created_at" : "2016-03-18 14:40:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 9, 19 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710816602187558912",
  "geo" : { },
  "id_str" : "710818471504945152",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @biocrusoe sounds like a good idea, why not starting out with CITATION(.md) to set an example?",
  "id" : 710818471504945152,
  "in_reply_to_status_id" : 710816602187558912,
  "created_at" : "2016-03-18 13:21:44 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/EwHXRQVd0C",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2016\/03\/pacbios-big-splash.html",
      "display_url" : "omicsomics.blogspot.de\/2016\/03\/pacbio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710813072819154944",
  "text" : "\u00ABin the Q&amp;A their presenter executed a jig, tango, waltz &amp; rumba when asked [about error rates]\u00BB PacBio\u2019s big splash https:\/\/t.co\/EwHXRQVd0C",
  "id" : 710813072819154944,
  "created_at" : "2016-03-18 13:00:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 88, 94 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/vKabjo8EMO",
      "expanded_url" : "http:\/\/glacierhub.org\/2016\/03\/17\/assembling-stories-of-a-volcanic-eruption-in-iceland-in-2010\/",
      "display_url" : "glacierhub.org\/2016\/03\/17\/ass\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710810282378055680",
  "text" : "Assembling Stories of the 2010 Volcanic Eruption in Iceland https:\/\/t.co\/vKabjo8EMO \/cc @Lobot",
  "id" : 710810282378055680,
  "created_at" : "2016-03-18 12:49:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/aPnBTpLYLX",
      "expanded_url" : "https:\/\/juliareda.eu\/job-offer-communications-trainee\/",
      "display_url" : "juliareda.eu\/job-offer-comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710774726365421568",
  "text" : "RT @Senficon: Want to become an intern in my Brussels office, working on communications? Apply now! https:\/\/t.co\/aPnBTpLYLX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/aPnBTpLYLX",
        "expanded_url" : "https:\/\/juliareda.eu\/job-offer-communications-trainee\/",
        "display_url" : "juliareda.eu\/job-offer-comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "710774499730432002",
    "text" : "Want to become an intern in my Brussels office, working on communications? Apply now! https:\/\/t.co\/aPnBTpLYLX",
    "id" : 710774499730432002,
    "created_at" : "2016-03-18 10:27:00 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 710774726365421568,
  "created_at" : "2016-03-18 10:27:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710771298700492800",
  "text" : "@stopifnot more fitting for Crosby et al. :D",
  "id" : 710771298700492800,
  "created_at" : "2016-03-18 10:14:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademiaABandName",
      "indices" : [ 37, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710770706586476544",
  "text" : "Me First Author and the Gimme Gimmes #AcademiaABandName",
  "id" : 710770706586476544,
  "created_at" : "2016-03-18 10:11:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710749634772213760",
  "geo" : { },
  "id_str" : "710752121889689600",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin check IP submitting the jobs?",
  "id" : 710752121889689600,
  "in_reply_to_status_id" : 710749634772213760,
  "created_at" : "2016-03-18 08:58:05 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710622195702169600",
  "geo" : { },
  "id_str" : "710622431224995840",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna awww, the Triceratops is lovely \uD83D\uDC96",
  "id" : 710622431224995840,
  "in_reply_to_status_id" : 710622195702169600,
  "created_at" : "2016-03-18 00:22:44 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/CaNcX0hjDB",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/e41beabb259888bbaa2933a4ab4fbb4b\/tumblr_mogxocylkD1ruz7vmo1_500.gif",
      "display_url" : "24.media.tumblr.com\/e41beabb259888\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710618055794171906",
  "geo" : { },
  "id_str" : "710618837088133120",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna no need to! https:\/\/t.co\/CaNcX0hjDB",
  "id" : 710618837088133120,
  "in_reply_to_status_id" : 710618055794171906,
  "created_at" : "2016-03-18 00:08:28 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710615599056076801",
  "geo" : { },
  "id_str" : "710617774872268801",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC one could somehow fit a bit more science into it to make it a perfect match maybe :D",
  "id" : 710617774872268801,
  "in_reply_to_status_id" : 710615599056076801,
  "created_at" : "2016-03-18 00:04:14 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710616972833263620",
  "geo" : { },
  "id_str" : "710617193776603136",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna that\u2019s heavy crocheting\/knitting myth busting here! :)",
  "id" : 710617193776603136,
  "in_reply_to_status_id" : 710616972833263620,
  "created_at" : "2016-03-18 00:01:56 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710614875794497537",
  "geo" : { },
  "id_str" : "710615259065786368",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and I guess the combination of topics is hard to beat . :)",
  "id" : 710615259065786368,
  "in_reply_to_status_id" : 710614875794497537,
  "created_at" : "2016-03-17 23:54:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710611549145190404",
  "geo" : { },
  "id_str" : "710615126769049600",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna oh damn, man kann nicht mal mehr \u201Elikes dogs, has cats\u201C angeben!",
  "id" : 710615126769049600,
  "in_reply_to_status_id" : 710611549145190404,
  "created_at" : "2016-03-17 23:53:43 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710613866561015809",
  "geo" : { },
  "id_str" : "710614206152839168",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i knew I would make at least one person happy with it :)",
  "id" : 710614206152839168,
  "in_reply_to_status_id" : 710613866561015809,
  "created_at" : "2016-03-17 23:50:03 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XYIvzoQrKX",
      "expanded_url" : "http:\/\/www.jjcrochet.com\/blog\/top-8-reason-why-crocheting-is-better-than-knitting\/",
      "display_url" : "jjcrochet.com\/blog\/top-8-rea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710612736116445185",
  "geo" : { },
  "id_str" : "710613464839032832",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna my first google hit for \u201Ecrocheting vs knitting\u201C I know nothing about both,just want a miniature dinosaur :D https:\/\/t.co\/XYIvzoQrKX",
  "id" : 710613464839032832,
  "in_reply_to_status_id" : 710612736116445185,
  "created_at" : "2016-03-17 23:47:07 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710611549145190404",
  "geo" : { },
  "id_str" : "710612549658677248",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna und die \u201Emostly\u201C Optionen (e.g. \u201Emostly vegan\u201C) wurden auch gestrichen seh ich gerade. Stattdessen wurde ich einfach zum Veganer \uD83D\uDE29",
  "id" : 710612549658677248,
  "in_reply_to_status_id" : 710611549145190404,
  "created_at" : "2016-03-17 23:43:29 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710611549145190404",
  "geo" : { },
  "id_str" : "710612299292254208",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna und das wo sie so viele \u201Emore options\u201C haben wo es ganz klar keinen Sinn macht \u201Einclude me in\u201C ausw\u00E4hlen zu m\u00FCssen. \u2639\uFE0F",
  "id" : 710612299292254208,
  "in_reply_to_status_id" : 710611549145190404,
  "created_at" : "2016-03-17 23:42:29 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/zajNNdyzTX",
      "expanded_url" : "https:\/\/twitter.com\/beaugunderson\/status\/710606005134995456",
      "display_url" : "twitter.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710611055295262720",
  "text" : "\u00ABThe medicine that rock climbing provides is for all of us, and its name is feminism.\u00BB https:\/\/t.co\/zajNNdyzTX",
  "id" : 710611055295262720,
  "created_at" : "2016-03-17 23:37:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Tree Genome",
      "screen_name" : "JTGenome",
      "indices" : [ 16, 25 ],
      "id_str" : "3975923112",
      "id" : 3975923112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/UNTj3do4NT",
      "expanded_url" : "https:\/\/experiment.com\/projects\/the-joshua-tree-genome-project",
      "display_url" : "experiment.com\/projects\/the-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710605891272364032",
  "text" : "Congrats to the @JTGenome project! https:\/\/t.co\/UNTj3do4NT",
  "id" : 710605891272364032,
  "created_at" : "2016-03-17 23:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/WvZyTBNRc9",
      "expanded_url" : "https:\/\/twitter.com\/domino_joyce\/status\/710589718442991616",
      "display_url" : "twitter.com\/domino_joyce\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710598505019121669",
  "text" : "Now I _really_ wanna take up crocheting https:\/\/t.co\/WvZyTBNRc9",
  "id" : 710598505019121669,
  "created_at" : "2016-03-17 22:47:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710587914418307072",
  "geo" : { },
  "id_str" : "710589152937578496",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna mir war gar nicht aufgefallen das man die Option per Standard sogar nicht mal bekommt\uD83D\uDE15Ich hab in den sauren \uD83C\uDF4E gebissen &amp; was gew\u00E4hlt.",
  "id" : 710589152937578496,
  "in_reply_to_status_id" : 710587914418307072,
  "created_at" : "2016-03-17 22:10:30 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/oF28cWfZE7",
      "expanded_url" : "https:\/\/awkwardbotany.com\/2016\/03\/16\/president-obamas-lichen",
      "display_url" : "awkwardbotany.com\/2016\/03\/16\/pre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710576690917974016",
  "text" : "President Obama\u2019s Lichen https:\/\/t.co\/oF28cWfZE7",
  "id" : 710576690917974016,
  "created_at" : "2016-03-17 21:20:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Cwej8cHbDB",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/should-academics-be-paid-for-peer-review",
      "display_url" : "timeshighereducation.com\/news\/should-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710569167154450433",
  "text" : "Academia, a system where you actually have to write pieces about whether people should get paid for their work\u2026 https:\/\/t.co\/Cwej8cHbDB",
  "id" : 710569167154450433,
  "created_at" : "2016-03-17 20:51:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademiaABandName",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399061338629, 8.753443697286954 ]
  },
  "id_str" : "710557984145985537",
  "text" : "Mixed Model Army #AcademiaABandName",
  "id" : 710557984145985537,
  "created_at" : "2016-03-17 20:06:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademiaABandName",
      "indices" : [ 27, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400377250836, 8.753460648316086 ]
  },
  "id_str" : "710556352100343808",
  "text" : "Method(ological Error) Man #AcademiaABandName",
  "id" : 710556352100343808,
  "created_at" : "2016-03-17 20:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademiaABandName",
      "indices" : [ 24, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400377250836, 8.753460648316086 ]
  },
  "id_str" : "710555850021195783",
  "text" : "Hypothesis Test Dummies #AcademiaABandName",
  "id" : 710555850021195783,
  "created_at" : "2016-03-17 19:58:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Ddaphh0xCH",
      "expanded_url" : "https:\/\/twitter.com\/mikeash\/status\/645014517005570048",
      "display_url" : "twitter.com\/mikeash\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385814742231, 8.753455538982575 ]
  },
  "id_str" : "710550117955272704",
  "text" : "Is that counting from zero or one? https:\/\/t.co\/Ddaphh0xCH",
  "id" : 710550117955272704,
  "created_at" : "2016-03-17 19:35:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710510258075136002",
  "geo" : { },
  "id_str" : "710510467559657472",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @Lobot nah, I found this dead squirrel (right) while doing garden work one day. The rat (left) was brought by a student. :D",
  "id" : 710510467559657472,
  "in_reply_to_status_id" : 710510258075136002,
  "created_at" : "2016-03-17 16:57:50 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/710499871392997376\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/7r6v13tdnd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdwz3dzXIAE_SEV.jpg",
      "id_str" : "710499869203570689",
      "id" : 710499869203570689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdwz3dzXIAE_SEV.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7r6v13tdnd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710499426872258564",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16997135947977, 8.62472968269882 ]
  },
  "id_str" : "710499871392997376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ohai \uD83D\uDC3F https:\/\/t.co\/7r6v13tdnd",
  "id" : 710499871392997376,
  "in_reply_to_status_id" : 710499426872258564,
  "created_at" : "2016-03-17 16:15:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/h1NdiUBQ0e",
      "expanded_url" : "https:\/\/twitter.com\/AcademicPain\/status\/710469532331188224",
      "display_url" : "twitter.com\/AcademicPain\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710498180723576834",
  "text" : "What used to be the reaction when people looked into my freezer at home. https:\/\/t.co\/h1NdiUBQ0e",
  "id" : 710498180723576834,
  "created_at" : "2016-03-17 16:09:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710474766482808833",
  "geo" : { },
  "id_str" : "710474881733955586",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin ouch, I see, that sucks. Would be really evil if that happens while running one of our DB migrations.",
  "id" : 710474881733955586,
  "in_reply_to_status_id" : 710474766482808833,
  "created_at" : "2016-03-17 14:36:26 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710474146841493504",
  "geo" : { },
  "id_str" : "710474447770292224",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin that doesn\u2019t sound good, what bad happens? just so i don\u2019t f**k up openSNP by accident :D",
  "id" : 710474447770292224,
  "in_reply_to_status_id" : 710474146841493504,
  "created_at" : "2016-03-17 14:34:42 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/0ars6Dmxq2",
      "expanded_url" : "https:\/\/twitter.com\/ejwillingham\/status\/710466675628322817",
      "display_url" : "twitter.com\/ejwillingham\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710469548454060032",
  "text" : "There is a man who has a Twitter account\u2026 https:\/\/t.co\/0ars6Dmxq2",
  "id" : 710469548454060032,
  "created_at" : "2016-03-17 14:15:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710419403360378884",
  "geo" : { },
  "id_str" : "710421115626242048",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it was only women who told me not to go into biology. go figure\u2026",
  "id" : 710421115626242048,
  "in_reply_to_status_id" : 710419403360378884,
  "created_at" : "2016-03-17 11:02:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/C222OAKdvW",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/710391223765360640",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710411343724220420",
  "text" : "The best thing Nature has ever made: https:\/\/t.co\/C222OAKdvW",
  "id" : 710411343724220420,
  "created_at" : "2016-03-17 10:23:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/rYzp68h0Eg",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/141151752176\/the-presumed-lineage-of-all-great-scientists",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/141151752\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710408505929367552",
  "text" : "That\u2019s not true for biology. Every biologist I ever spoke to before starting out gave \u201Edon\u2019t do it!\u201C as advice. https:\/\/t.co\/rYzp68h0Eg",
  "id" : 710408505929367552,
  "created_at" : "2016-03-17 10:12:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710315126587457536",
  "geo" : { },
  "id_str" : "710401109899288577",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder \uD83D\uDC96",
  "id" : 710401109899288577,
  "in_reply_to_status_id" : 710315126587457536,
  "created_at" : "2016-03-17 09:43:17 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/710393634617737217\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/49Y6DeiZsS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdvTPqkWwAAUKJW.jpg",
      "id_str" : "710393632319258624",
      "id" : 710393632319258624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdvTPqkWwAAUKJW.jpg",
      "sizes" : [ {
        "h" : 75,
        "resize" : "fit",
        "w" : 140
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 140
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 140
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 140
      }, {
        "h" : 75,
        "resize" : "crop",
        "w" : 75
      } ],
      "display_url" : "pic.twitter.com\/49Y6DeiZsS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710393634617737217",
  "text" : "mhkay! https:\/\/t.co\/49Y6DeiZsS",
  "id" : 710393634617737217,
  "created_at" : "2016-03-17 09:13:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/92pPZN9vgg",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/582\/when-the-beasts-come-marching-in?act=0#play",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710389263297335296",
  "text" : "\u00ABDick overthinks everything. And the bird doesn\u2019t think anything at all. The bird doesn\u2019t care.\u00BB https:\/\/t.co\/92pPZN9vgg",
  "id" : 710389263297335296,
  "created_at" : "2016-03-17 08:56:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 62, 73 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710385978465259520",
  "text" : "RT @PhilippBayer: We're still looking for students working on @openSNPorg or other OBF projects during the Google Summer of Code! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 44, 55 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/K4Qr5kxFzm",
        "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/",
        "display_url" : "obf.github.io\/GSoC\/ideas\/"
      } ]
    },
    "geo" : { },
    "id_str" : "710383273491300352",
    "text" : "We're still looking for students working on @openSNPorg or other OBF projects during the Google Summer of Code! https:\/\/t.co\/K4Qr5kxFzm",
    "id" : 710383273491300352,
    "created_at" : "2016-03-17 08:32:25 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 710385978465259520,
  "created_at" : "2016-03-17 08:43:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710248891271258112",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon Alles gute! \uD83C\uDF89",
  "id" : 710248891271258112,
  "created_at" : "2016-03-16 23:38:26 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/A2A0Oo3GOR",
      "expanded_url" : "http:\/\/i.imgur.com\/M5ruHHv.gifv",
      "display_url" : "i.imgur.com\/M5ruHHv.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "710248097499258881",
  "text" : "they see me rollin\u2019\u2026 https:\/\/t.co\/A2A0Oo3GOR",
  "id" : 710248097499258881,
  "created_at" : "2016-03-16 23:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710240166900834304",
  "geo" : { },
  "id_str" : "710244000456941569",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 ganz ohne \uD83D\uDD37 \uD83D\uDE02",
  "id" : 710244000456941569,
  "in_reply_to_status_id" : 710240166900834304,
  "created_at" : "2016-03-16 23:19:00 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/710236580275945473\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/HPXvxeTu0o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdtEZ7lWEAAPnqg.jpg",
      "id_str" : "710236578522730496",
      "id" : 710236578522730496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdtEZ7lWEAAPnqg.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/HPXvxeTu0o"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05769040385077, 8.8188244086093 ]
  },
  "id_str" : "710236580275945473",
  "text" : "Yesterday I discussed #quantifiedself and talked \u2018higher, further, faster\u2019. Today that\u2019s the result. https:\/\/t.co\/HPXvxeTu0o",
  "id" : 710236580275945473,
  "created_at" : "2016-03-16 22:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 0, 12 ],
      "id_str" : "19355816",
      "id" : 19355816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710230254229528576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06108226668611, 8.818774259154207 ]
  },
  "id_str" : "710231515100270592",
  "in_reply_to_user_id" : 19355816,
  "text" : "@davidweisss thanks, I think it\u2019s just that network effects kick in after a while, word of mouth spreads more easily :)",
  "id" : 710231515100270592,
  "in_reply_to_status_id" : 710230254229528576,
  "created_at" : "2016-03-16 22:29:23 +0000",
  "in_reply_to_screen_name" : "davidweisss",
  "in_reply_to_user_id_str" : "19355816",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/pfh4D2U2YU",
      "expanded_url" : "https:\/\/opensnp.org\/statistics",
      "display_url" : "opensnp.org\/statistics"
    }, {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/bvbFzXGjBh",
      "expanded_url" : "https:\/\/twitter.com\/fiedawn\/status\/710212992491720704",
      "display_url" : "twitter.com\/fiedawn\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710224640975708160",
  "text" : "You can now also see our growth with openSNP at https:\/\/t.co\/pfh4D2U2YU https:\/\/t.co\/bvbFzXGjBh",
  "id" : 710224640975708160,
  "created_at" : "2016-03-16 22:02:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rupi",
      "screen_name" : "bernd_rupp",
      "indices" : [ 0, 11 ],
      "id_str" : "4274152301",
      "id" : 4274152301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710122131196145665",
  "geo" : { },
  "id_str" : "710122352701513728",
  "in_reply_to_user_id" : 4274152301,
  "text" : "@bernd_rupp the quartet is always a good reminder to have a look at your data instead of only looking at the summary statistics.",
  "id" : 710122352701513728,
  "in_reply_to_status_id" : 710122131196145665,
  "created_at" : "2016-03-16 15:15:36 +0000",
  "in_reply_to_screen_name" : "bernd_rupp",
  "in_reply_to_user_id_str" : "4274152301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Leipzig",
      "screen_name" : "jermdemo",
      "indices" : [ 0, 9 ],
      "id_str" : "16656236",
      "id" : 16656236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710114747149131776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17266535990004, 8.627294940051442 ]
  },
  "id_str" : "710115166436909057",
  "in_reply_to_user_id" : 16656236,
  "text" : "@jermdemo that's awesome! Great to read how people are using the resource!",
  "id" : 710115166436909057,
  "in_reply_to_status_id" : 710114747149131776,
  "created_at" : "2016-03-16 14:47:03 +0000",
  "in_reply_to_screen_name" : "jermdemo",
  "in_reply_to_user_id_str" : "16656236",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 44, 52 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Egb3EQPDLC",
      "expanded_url" : "https:\/\/twitter.com\/rstevens\/status\/710098601414885377",
      "display_url" : "twitter.com\/rstevens\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17256343843196, 8.627423995911206 ]
  },
  "id_str" : "710104093214253056",
  "text" : "Just what I need today. Thanks for sharing, @glyn_dk  https:\/\/t.co\/Egb3EQPDLC",
  "id" : 710104093214253056,
  "created_at" : "2016-03-16 14:03:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/8lOk6UNIoJ",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/709404058373599232",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710086363039842304",
  "text" : "\u2026on Wednesday he began to wonder if the struggle to survive alone was enough to justify existence\u2026 https:\/\/t.co\/8lOk6UNIoJ",
  "id" : 710086363039842304,
  "created_at" : "2016-03-16 12:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710076810327941120",
  "geo" : { },
  "id_str" : "710079500525158400",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin still a shame we\u2019ll miss each other.",
  "id" : 710079500525158400,
  "in_reply_to_status_id" : 710076810327941120,
  "created_at" : "2016-03-16 12:25:20 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gernot J. Abel",
      "screen_name" : "gernotJabel",
      "indices" : [ 0, 12 ],
      "id_str" : "1912181796",
      "id" : 1912181796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/W6ctCzwlKr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Anscombe%27s_quartet",
      "display_url" : "en.wikipedia.org\/wiki\/Anscombe%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "710076568551424000",
  "geo" : { },
  "id_str" : "710076725493948417",
  "in_reply_to_user_id" : 1912181796,
  "text" : "@gernotJabel just in case you didn\u2019t know it already :) https:\/\/t.co\/W6ctCzwlKr",
  "id" : 710076725493948417,
  "in_reply_to_status_id" : 710076568551424000,
  "created_at" : "2016-03-16 12:14:18 +0000",
  "in_reply_to_screen_name" : "gernotJabel",
  "in_reply_to_user_id_str" : "1912181796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710000084579127296",
  "geo" : { },
  "id_str" : "710074478806618113",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin sorry, that won\u2019t work out today! Maybe next time you come through FRA :(",
  "id" : 710074478806618113,
  "in_reply_to_status_id" : 710000084579127296,
  "created_at" : "2016-03-16 12:05:22 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710043844361003008",
  "geo" : { },
  "id_str" : "710056083180625920",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson a future reviewer #3",
  "id" : 710056083180625920,
  "in_reply_to_status_id" : 710043844361003008,
  "created_at" : "2016-03-16 10:52:17 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/710043109263069184\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/51UQcv7WxW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdqUbnvXIAAlKP-.jpg",
      "id_str" : "710043093509283840",
      "id" : 710043093509283840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdqUbnvXIAAlKP-.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/51UQcv7WxW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399089005931, 8.753444336053676 ]
  },
  "id_str" : "710043109263069184",
  "text" : "What waited in the mail when I got home! \uD83D\uDC96 https:\/\/t.co\/51UQcv7WxW",
  "id" : 710043109263069184,
  "created_at" : "2016-03-16 10:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Fruehwald",
      "screen_name" : "JoFrhwld",
      "indices" : [ 3, 12 ],
      "id_str" : "14730367",
      "id" : 14730367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/D9zJhzaAGY",
      "expanded_url" : "http:\/\/jofrhwld.github.io\/papers\/knitting.pdf",
      "display_url" : "jofrhwld.github.io\/papers\/knittin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710035379076866048",
  "text" : "RT @JoFrhwld: The slides from my talk today \"Prolegomena to a Grammar of Knitting\" https:\/\/t.co\/D9zJhzaAGY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/D9zJhzaAGY",
        "expanded_url" : "http:\/\/jofrhwld.github.io\/papers\/knitting.pdf",
        "display_url" : "jofrhwld.github.io\/papers\/knittin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708331679325286400",
    "text" : "The slides from my talk today \"Prolegomena to a Grammar of Knitting\" https:\/\/t.co\/D9zJhzaAGY",
    "id" : 708331679325286400,
    "created_at" : "2016-03-11 16:40:07 +0000",
    "user" : {
      "name" : "Josef Fruehwald",
      "screen_name" : "JoFrhwld",
      "protected" : false,
      "id_str" : "14730367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897379629887107073\/fmH5PnYA_normal.jpg",
      "id" : 14730367,
      "verified" : false
    }
  },
  "id" : 710035379076866048,
  "created_at" : "2016-03-16 09:30:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "710018237157810176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04500298015924, 8.562450786658868 ]
  },
  "id_str" : "710026614298517504",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther it\u2019s not a good preparation for a 45 minute flight that doesn\u2019t even cross a single time zone ;)",
  "id" : 710026614298517504,
  "in_reply_to_status_id" : 710018237157810176,
  "created_at" : "2016-03-16 08:55:11 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Wachter-Boettcher",
      "screen_name" : "sara_ann_marie",
      "indices" : [ 3, 18 ],
      "id_str" : "14424551",
      "id" : 14424551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "710008996502106112",
  "text" : "RT @sara_ann_marie: Whenever I write about treating users with kindness, someone tells me I'm being too sensitive. My new response: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/yMx9YJd6lT",
        "expanded_url" : "https:\/\/medium.com\/@sara_ann_marie\/too-sensitive-9752a86a8382#.a4nykuj0a",
        "display_url" : "medium.com\/@sara_ann_mari\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705483856082821120",
    "text" : "Whenever I write about treating users with kindness, someone tells me I'm being too sensitive. My new response: https:\/\/t.co\/yMx9YJd6lT",
    "id" : 705483856082821120,
    "created_at" : "2016-03-03 20:03:53 +0000",
    "user" : {
      "name" : "Sara Wachter-Boettcher",
      "screen_name" : "sara_ann_marie",
      "protected" : false,
      "id_str" : "14424551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539406496144977920\/Z7ibQxu8_normal.jpeg",
      "id" : 14424551,
      "verified" : false
    }
  },
  "id" : 710008996502106112,
  "created_at" : "2016-03-16 07:45:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/tZpIKh83VM",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/with-yourself-express-zJ8ldRaGLnHTa",
      "display_url" : "giphy.com\/gifs\/with-your\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.554154, 13.289205 ]
  },
  "id_str" : "709993131874377728",
  "text" : "The simple guide to turn any flight into a red-eye flight: just don't go to sleep the night before  https:\/\/t.co\/tZpIKh83VM",
  "id" : 709993131874377728,
  "created_at" : "2016-03-16 06:42:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709988585416630272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55449742674703, 13.28954863392491 ]
  },
  "id_str" : "709990128912097280",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin but I\u2019ll try my best, will let you know once I made it back to Frankfurt. :)",
  "id" : 709990128912097280,
  "in_reply_to_status_id" : 709988585416630272,
  "created_at" : "2016-03-16 06:30:12 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709988585416630272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55425253989331, 13.2896155581564 ]
  },
  "id_str" : "709990035702091777",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin ok, I\u2019m not 100% sure whether I can make it. Forgot that a meeting was rescheduled for this afternoon from this morning. :(",
  "id" : 709990035702091777,
  "in_reply_to_status_id" : 709988585416630272,
  "created_at" : "2016-03-16 06:29:50 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/FpQOKDrkLm",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/708953715898769408",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "708953715898769408",
  "geo" : { },
  "id_str" : "709859294590738432",
  "in_reply_to_user_id" : 14286491,
  "text" : "Dear US-timeline, let me spam this one last time: We\u2019d really appreciate students joining us! \u263A\uFE0F https:\/\/t.co\/FpQOKDrkLm",
  "id" : 709859294590738432,
  "in_reply_to_status_id" : 708953715898769408,
  "created_at" : "2016-03-15 21:50:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/u24hzltxlv",
      "expanded_url" : "https:\/\/img.shields.io\/badge\/%F0%9F%90%BAwow-approved-brightgreen.svg",
      "display_url" : "img.shields.io\/badge\/%F0%9F%9\u2026"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/txfOO2E7zS",
      "expanded_url" : "https:\/\/twitter.com\/betatim\/status\/709853052841361408",
      "display_url" : "twitter.com\/betatim\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709853382966689792",
  "text" : "Well done! https:\/\/t.co\/u24hzltxlv https:\/\/t.co\/txfOO2E7zS",
  "id" : 709853382966689792,
  "created_at" : "2016-03-15 21:26:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Jason Bobe",
      "screen_name" : "jasonbobe",
      "indices" : [ 15, 25 ],
      "id_str" : "820582",
      "id" : 820582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709850840316583936",
  "geo" : { },
  "id_str" : "709851394375884800",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @jasonbobe let me do my puppy eyes! \uD83D\uDC36\uD83D\uDC40",
  "id" : 709851394375884800,
  "in_reply_to_status_id" : 709850840316583936,
  "created_at" : "2016-03-15 21:18:55 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709850673014124545",
  "geo" : { },
  "id_str" : "709850751724609540",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson there probably aren\u2019t any travel grants, are there? :(",
  "id" : 709850751724609540,
  "in_reply_to_status_id" : 709850673014124545,
  "created_at" : "2016-03-15 21:16:22 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GET Conference",
      "screen_name" : "attendGET",
      "indices" : [ 57, 67 ],
      "id_str" : "3349342414",
      "id" : 3349342414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709848979106865152",
  "text" : "The more I read about it the more I really want to go to @attendGET. \uD83D\uDE2D",
  "id" : 709848979106865152,
  "created_at" : "2016-03-15 21:09:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmholtz",
      "screen_name" : "helmholtz_de",
      "indices" : [ 7, 20 ],
      "id_str" : "95856748",
      "id" : 95856748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FokusHelmholtz",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/PrjP9DZ61E",
      "expanded_url" : "https:\/\/twitter.com\/gerrit_brand\/status\/709806069388877824",
      "display_url" : "twitter.com\/gerrit_brand\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709846731899412480",
  "text" : "Thanks @helmholtz_de for a great panel discussion, one of the best I ever attended. #FokusHelmholtz  https:\/\/t.co\/PrjP9DZ61E",
  "id" : 709846731899412480,
  "created_at" : "2016-03-15 21:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 7, 15 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709793833270296580",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.52046774561508, 13.40142099782616 ]
  },
  "id_str" : "709795164760494080",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @punkish not hipster enough to be vintage? :3",
  "id" : 709795164760494080,
  "in_reply_to_status_id" : 709793833270296580,
  "created_at" : "2016-03-15 17:35:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709764986298621952",
  "geo" : { },
  "id_str" : "709766340379336704",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick abusing cell background color to convey important information. \uD83D\uDE31",
  "id" : 709766340379336704,
  "in_reply_to_status_id" : 709764986298621952,
  "created_at" : "2016-03-15 15:40:57 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709746401220141056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55660933447308, 13.2914752140765 ]
  },
  "id_str" : "709746659538894852",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish that sounds less like me ;)",
  "id" : 709746659538894852,
  "in_reply_to_status_id" : 709746401220141056,
  "created_at" : "2016-03-15 14:22:44 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709736385540964352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55664805886573, 13.29272822478161 ]
  },
  "id_str" : "709746115005030400",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish for once it's not Bastien, that's progress!",
  "id" : 709746115005030400,
  "in_reply_to_status_id" : 709736385540964352,
  "created_at" : "2016-03-15 14:20:34 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/kvG54NXYPu",
      "expanded_url" : "http:\/\/dogenSNP.org",
      "display_url" : "dogenSNP.org"
    }, {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/bJPVHTIWuS",
      "expanded_url" : "https:\/\/twitter.com\/ArielleDRoss\/status\/709722715356323840",
      "display_url" : "twitter.com\/ArielleDRoss\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04787043050243, 8.569543622904552 ]
  },
  "id_str" : "709728167225856000",
  "text" : "Time to register https:\/\/t.co\/kvG54NXYPu  https:\/\/t.co\/bJPVHTIWuS",
  "id" : 709728167225856000,
  "created_at" : "2016-03-15 13:09:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Heard",
      "screen_name" : "StephenBHeard",
      "indices" : [ 0, 14 ],
      "id_str" : "2862441010",
      "id" : 2862441010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709709264672202752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04772813855438, 8.5688914389155 ]
  },
  "id_str" : "709709616075120640",
  "in_reply_to_user_id" : 2862441010,
  "text" : "@StephenBHeard agree, the printing is stressful to me, getting it to printer in time, crossing fingers file works, looks like expected, etc.",
  "id" : 709709616075120640,
  "in_reply_to_status_id" : 709709264672202752,
  "created_at" : "2016-03-15 11:55:32 +0000",
  "in_reply_to_screen_name" : "StephenBHeard",
  "in_reply_to_user_id_str" : "2862441010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709705990447472640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.047782500892, 8.569035389799184 ]
  },
  "id_str" : "709706234895736832",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier yes, arrival Berlin 3pm today, back in Frankfurt tomorrow morning at 9ish I think.",
  "id" : 709706234895736832,
  "in_reply_to_status_id" : 709705990447472640,
  "created_at" : "2016-03-15 11:42:06 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Heard",
      "screen_name" : "StephenBHeard",
      "indices" : [ 0, 14 ],
      "id_str" : "2862441010",
      "id" : 2862441010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709703496250040320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04772670866012, 8.568842265083727 ]
  },
  "id_str" : "709705318616453120",
  "in_reply_to_user_id" : 2862441010,
  "text" : "@StephenBHeard having said that, as rule of thumb I try to not touch the slides once the plane wheels-down at conference location.",
  "id" : 709705318616453120,
  "in_reply_to_status_id" : 709703496250040320,
  "created_at" : "2016-03-15 11:38:28 +0000",
  "in_reply_to_screen_name" : "StephenBHeard",
  "in_reply_to_user_id_str" : "2862441010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Heard",
      "screen_name" : "StephenBHeard",
      "indices" : [ 0, 14 ],
      "id_str" : "2862441010",
      "id" : 2862441010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709703496250040320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04767888712412, 8.56878624741656 ]
  },
  "id_str" : "709704803576893440",
  "in_reply_to_user_id" : 2862441010,
  "text" : "@StephenBHeard thanks,nice write-up! personally still feel last-minuteish talk edits are easier on my mind than last-minute poster prints :)",
  "id" : 709704803576893440,
  "in_reply_to_status_id" : 709703496250040320,
  "created_at" : "2016-03-15 11:36:25 +0000",
  "in_reply_to_screen_name" : "StephenBHeard",
  "in_reply_to_user_id_str" : "2862441010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0477601255219, 8.56901934702257 ]
  },
  "id_str" : "709703933246185472",
  "text" : "Today's suspicious items at the airport security check: Pen Type-A &amp; Apple Watch charger.",
  "id" : 709703933246185472,
  "created_at" : "2016-03-15 11:32:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmholtz",
      "screen_name" : "helmholtz_de",
      "indices" : [ 0, 13 ],
      "id_str" : "95856748",
      "id" : 95856748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709695883198251008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0478926533647, 8.569064497121282 ]
  },
  "id_str" : "709700870544498689",
  "in_reply_to_user_id" : 95856748,
  "text" : "@helmholtz_de bis nachher! :)",
  "id" : 709700870544498689,
  "in_reply_to_status_id" : 709695883198251008,
  "created_at" : "2016-03-15 11:20:47 +0000",
  "in_reply_to_screen_name" : "helmholtz_de",
  "in_reply_to_user_id_str" : "95856748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmholtz",
      "screen_name" : "helmholtz_de",
      "indices" : [ 44, 57 ],
      "id_str" : "95856748",
      "id" : 95856748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1022210270615, 8.748904552038736 ]
  },
  "id_str" : "709689686789332992",
  "text" : "Off to Berlin to discuss #QuantifiedSelf at @helmholtz_de. A stay so short that I had layovers that were longer than this trip.",
  "id" : 709689686789332992,
  "created_at" : "2016-03-15 10:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 7, 20 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709667347016060929",
  "geo" : { },
  "id_str" : "709668280202559488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Unsichtbarer \uD83D\uDC4D",
  "id" : 709668280202559488,
  "in_reply_to_status_id" : 709667347016060929,
  "created_at" : "2016-03-15 09:11:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Rieger",
      "screen_name" : "frank_rieger",
      "indices" : [ 11, 24 ],
      "id_str" : "53016156",
      "id" : 53016156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/WWkIodr2hf",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/SehiYaKy6W04U\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/SehiYaKy\u2026"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/APA4E6bWFs",
      "expanded_url" : "https:\/\/twitter.com\/BIODeutschland\/status\/709665638428442624",
      "display_url" : "twitter.com\/BIODeutschland\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709668238737727488",
  "text" : "See me and @frank_rieger discuss Big Data at the German Biotechnology Days https:\/\/t.co\/WWkIodr2hf \uD83D\uDE02 https:\/\/t.co\/APA4E6bWFs",
  "id" : 709668238737727488,
  "created_at" : "2016-03-15 09:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 7, 20 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709667013476622336",
  "geo" : { },
  "id_str" : "709667104165912576",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Unsichtbarer ja, dann passt es. Wobei auch \u201E\u201C als Antwort dabei ist, also nix geklickt?",
  "id" : 709667104165912576,
  "in_reply_to_status_id" : 709667013476622336,
  "created_at" : "2016-03-15 09:06:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 7, 20 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709666633049047041",
  "geo" : { },
  "id_str" : "709666691941330944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Unsichtbarer ok, war verwirrt weil es in den Daten anders aussieht?",
  "id" : 709666691941330944,
  "in_reply_to_status_id" : 709666633049047041,
  "created_at" : "2016-03-15 09:04:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 7, 20 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709666129602547712",
  "geo" : { },
  "id_str" : "709666394233819136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Unsichtbarer waren die letzten beiden wirklich getrennte Antwort-Optionen? Oder ist \u201Ekeine Antwort\u201C einfach \u201Enichts ausgew\u00E4hlt\u201C?",
  "id" : 709666394233819136,
  "in_reply_to_status_id" : 709666129602547712,
  "created_at" : "2016-03-15 09:03:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shayda Kashef",
      "screen_name" : "shayda_k",
      "indices" : [ 3, 12 ],
      "id_str" : "27086206",
      "id" : 27086206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "political",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "feminism",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "womeninbusiness",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Ky4MgpWvAI",
      "expanded_url" : "http:\/\/bit.ly\/21liNmm",
      "display_url" : "bit.ly\/21liNmm"
    } ]
  },
  "geo" : { },
  "id_str" : "709501184588029953",
  "text" : "RT @shayda_k: Artist photoshopped men out of #political images to show why we need #feminism https:\/\/t.co\/Ky4MgpWvAI #womeninbusiness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "political",
        "indices" : [ 31, 41 ]
      }, {
        "text" : "feminism",
        "indices" : [ 69, 78 ]
      }, {
        "text" : "womeninbusiness",
        "indices" : [ 103, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/Ky4MgpWvAI",
        "expanded_url" : "http:\/\/bit.ly\/21liNmm",
        "display_url" : "bit.ly\/21liNmm"
      } ]
    },
    "geo" : { },
    "id_str" : "709493405844422656",
    "text" : "Artist photoshopped men out of #political images to show why we need #feminism https:\/\/t.co\/Ky4MgpWvAI #womeninbusiness",
    "id" : 709493405844422656,
    "created_at" : "2016-03-14 21:36:24 +0000",
    "user" : {
      "name" : "Shayda Kashef",
      "screen_name" : "shayda_k",
      "protected" : false,
      "id_str" : "27086206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905153247425552385\/ldkcfdiE_normal.jpg",
      "id" : 27086206,
      "verified" : false
    }
  },
  "id" : 709501184588029953,
  "created_at" : "2016-03-14 22:07:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709478263727525889",
  "geo" : { },
  "id_str" : "709478774023258114",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s irgendwann \u00FCber einem Tee ;)",
  "id" : 709478774023258114,
  "in_reply_to_status_id" : 709478263727525889,
  "created_at" : "2016-03-14 20:38:15 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709478277992333312",
  "geo" : { },
  "id_str" : "709478575225905152",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer @Lobot yep, \u201Enone\u201C \/ NA ging auch iirc, zumindest sehen die Daten so aus.",
  "id" : 709478575225905152,
  "in_reply_to_status_id" : 709478277992333312,
  "created_at" : "2016-03-14 20:37:28 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709477993673068544",
  "geo" : { },
  "id_str" : "709478149826994176",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s stille Wasser sind\u2026 oh, nevermind. :p",
  "id" : 709478149826994176,
  "in_reply_to_status_id" : 709477993673068544,
  "created_at" : "2016-03-14 20:35:47 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709477729155031040",
  "geo" : { },
  "id_str" : "709477800747655169",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s wenn du sonst nicht mehr lesen kannst bestimmt nicht mehr lang? :3",
  "id" : 709477800747655169,
  "in_reply_to_status_id" : 709477729155031040,
  "created_at" : "2016-03-14 20:34:23 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709476958208397312",
  "geo" : { },
  "id_str" : "709477676638191616",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s wir k\u00F6nnten uns abwechseln. Wer gerade nicht strampelt muss vorlesen.",
  "id" : 709477676638191616,
  "in_reply_to_status_id" : 709476958208397312,
  "created_at" : "2016-03-14 20:33:54 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Bl3HE9oCez",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dGXCTUmT9FE",
      "display_url" : "youtube.com\/watch?v=dGXCTU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709477505778974721",
  "text" : "On Twitter: \u00ABa beautiful line but if I hear it one more time, I swear to god I'm just gonna have to shoot someone\u00BB https:\/\/t.co\/Bl3HE9oCez",
  "id" : 709477505778974721,
  "created_at" : "2016-03-14 20:33:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709476758865715200",
  "geo" : { },
  "id_str" : "709476844089827328",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s hoffentlich, ich steh ja eigentlich auf eBooks, aber das l\u00E4uft nur wenn es da Strom gibt. ;)",
  "id" : 709476844089827328,
  "in_reply_to_status_id" : 709476758865715200,
  "created_at" : "2016-03-14 20:30:35 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709476242190426112",
  "geo" : { },
  "id_str" : "709476671934636033",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s du und ich und eine einsame Insel? \uD83C\uDFDD",
  "id" : 709476671934636033,
  "in_reply_to_status_id" : 709476242190426112,
  "created_at" : "2016-03-14 20:29:54 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709474652599484417",
  "geo" : { },
  "id_str" : "709476126649876480",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich sollte wohl Eremit werden f\u00FCr mein eigenes Seelenheil ;)",
  "id" : 709476126649876480,
  "in_reply_to_status_id" : 709474652599484417,
  "created_at" : "2016-03-14 20:27:44 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709472221987782656",
  "geo" : { },
  "id_str" : "709474438006366209",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer @Lobot allerdings designed vor 1+ Jahr iirc, vielleicht also nicht mehr best practice mittlerweile. :)",
  "id" : 709474438006366209,
  "in_reply_to_status_id" : 709472221987782656,
  "created_at" : "2016-03-14 20:21:02 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709472221987782656",
  "geo" : { },
  "id_str" : "709474312001069057",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer @Lobot mir ist eingefallen: ich hab ja die Ergebnisse m) \u201Em\u00E4nnlich\u201C, \u201Eweiblich\u201C, \u201Etrifft beides nicht zu\/keine Angabe\u201C",
  "id" : 709474312001069057,
  "in_reply_to_status_id" : 709472221987782656,
  "created_at" : "2016-03-14 20:20:32 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 55, 61 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709469839094583297",
  "geo" : { },
  "id_str" : "709469983785545728",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer fair enough w\u00FCrde ich sagen. :D Frag mal @Lobot, ich hab vergessen wie wir das in ihrer Umfrage gel\u00F6st haben. :)",
  "id" : 709469983785545728,
  "in_reply_to_status_id" : 709469839094583297,
  "created_at" : "2016-03-14 20:03:20 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709420181576163329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11287938006927, 8.754217792223832 ]
  },
  "id_str" : "709468521470816256",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer musst du \u00FCberhaupt fragen oder soll es nur zweifelhafte Subgruppen-Analysen erlauben? :D",
  "id" : 709468521470816256,
  "in_reply_to_status_id" : 709420181576163329,
  "created_at" : "2016-03-14 19:57:31 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/p0ZYSYbhIS",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/kellyoakes\/this-student-adds-a-woman-in-science-to-wikipedia-every-time#.mkZO26Zle",
      "display_url" : "buzzfeed.com\/kellyoakes\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709384400623034368",
  "text" : "For every harassing email she receives, Emily Temple-Wood creates a Wikipedia page for a woman in science. https:\/\/t.co\/p0ZYSYbhIS",
  "id" : 709384400623034368,
  "created_at" : "2016-03-14 14:23:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 3, 16 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709339208456994817",
  "text" : "RT @repositiveio: You\u2019re a student, want money &amp; contrib. to open source? Contribute to openSNP in the Summer of Code https:\/\/t.co\/4eYcIjyH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/4eYcIjyHPh",
        "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/#opensnp",
        "display_url" : "obf.github.io\/GSoC\/ideas\/#op\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709295268752187392",
    "text" : "You\u2019re a student, want money &amp; contrib. to open source? Contribute to openSNP in the Summer of Code https:\/\/t.co\/4eYcIjyHPh",
    "id" : 709295268752187392,
    "created_at" : "2016-03-14 08:29:04 +0000",
    "user" : {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "protected" : false,
      "id_str" : "3059929578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661114195753230336\/N89yr0lj_normal.png",
      "id" : 3059929578,
      "verified" : false
    }
  },
  "id" : 709339208456994817,
  "created_at" : "2016-03-14 11:23:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/R5lgbGilf2",
      "expanded_url" : "http:\/\/i.imgur.com\/Yi8E3.gif",
      "display_url" : "i.imgur.com\/Yi8E3.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "709329736082833408",
  "text" : "installing packages, regardless of the programming language you use. https:\/\/t.co\/R5lgbGilf2",
  "id" : 709329736082833408,
  "created_at" : "2016-03-14 10:46:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/FpQOKDrkLm",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/708953715898769408",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "708953715898769408",
  "geo" : { },
  "id_str" : "709306971569135616",
  "in_reply_to_user_id" : 14286491,
  "text" : "For those just back to the office: openSNP is looking for students to join us for the Summer of Code. Get in touch! https:\/\/t.co\/FpQOKDrkLm",
  "id" : 709306971569135616,
  "in_reply_to_status_id" : 708953715898769408,
  "created_at" : "2016-03-14 09:15:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709304570682413056",
  "text" : "RT @lexnederbragt: Exploratory analysis and error modeling of a sequencing technology: submitted 2007, never published, now as preprint htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5IGc9fJTN0",
        "expanded_url" : "http:\/\/biorxiv.org\/cgi\/content\/short\/043042v2?rss=1",
        "display_url" : "biorxiv.org\/cgi\/content\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "709271407029559296",
    "text" : "Exploratory analysis and error modeling of a sequencing technology: submitted 2007, never published, now as preprint https:\/\/t.co\/5IGc9fJTN0",
    "id" : 709271407029559296,
    "created_at" : "2016-03-14 06:54:15 +0000",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 709304570682413056,
  "created_at" : "2016-03-14 09:06:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/zntqsnwixf",
      "expanded_url" : "https:\/\/twitter.com\/pookleblinky\/status\/709233981821198337",
      "display_url" : "twitter.com\/pookleblinky\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709297542174023680",
  "text" : "I feel they are much more likely to be each others arch enemy, engaging in epic \u201Ewell, actually\u2026\u201C-fights https:\/\/t.co\/zntqsnwixf",
  "id" : 709297542174023680,
  "created_at" : "2016-03-14 08:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 9, 19 ],
      "id_str" : "62183077",
      "id" : 62183077
    }, {
      "name" : "David Steen, Ph.D.",
      "screen_name" : "AlongsideWild",
      "indices" : [ 20, 34 ],
      "id_str" : "636586551",
      "id" : 636586551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709087572895670273",
  "geo" : { },
  "id_str" : "709091215535378432",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder @vsbuffalo @AlongsideWild The worst thing: Dawkins is still doing it\u2026",
  "id" : 709091215535378432,
  "in_reply_to_status_id" : 709087572895670273,
  "created_at" : "2016-03-13 18:58:14 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inhale exhale repeat",
      "screen_name" : "C_Holler",
      "indices" : [ 0, 9 ],
      "id_str" : "65671142",
      "id" : 65671142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/IdFZ07j4wW",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/File:Lancaster_over_Hamburg.jpg",
      "display_url" : "en.wikipedia.org\/wiki\/File:Lanc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709075962143576064",
  "geo" : { },
  "id_str" : "709087723303399429",
  "in_reply_to_user_id" : 65671142,
  "text" : "@C_Holler Lichterketten die dem letzten Appeasement folgten: https:\/\/t.co\/IdFZ07j4wW",
  "id" : 709087723303399429,
  "in_reply_to_status_id" : 709075962143576064,
  "created_at" : "2016-03-13 18:44:22 +0000",
  "in_reply_to_screen_name" : "C_Holler",
  "in_reply_to_user_id_str" : "65671142",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/qIyvdQqnas",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/7-28-2014\/AnSME7.gif",
      "display_url" : "cdn.makeagif.com\/media\/7-28-201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "709086143116091392",
  "geo" : { },
  "id_str" : "709086597002690561",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch be water my friend! https:\/\/t.co\/qIyvdQqnas",
  "id" : 709086597002690561,
  "in_reply_to_status_id" : 709086143116091392,
  "created_at" : "2016-03-13 18:39:53 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/wAC1CsKX6i",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/G0P9tJmcUOFwI\/200.gif",
      "display_url" : "media2.giphy.com\/media\/G0P9tJmc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709066796477902848",
  "text" : "tl;dr of today\u2019s state elections in Germany\u2026 https:\/\/t.co\/wAC1CsKX6i",
  "id" : 709066796477902848,
  "created_at" : "2016-03-13 17:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/mPzi5MYvII",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/4bWWKmUnn5E4\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/4bWWKmUn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "709063294766727168",
  "text" : "Me every time I have to login into the openSNP production systems. https:\/\/t.co\/mPzi5MYvII",
  "id" : 709063294766727168,
  "created_at" : "2016-03-13 17:07:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709003221143035905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10691263717609, 8.694372978069534 ]
  },
  "id_str" : "709006078676172801",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin \uD83D\uDC4D",
  "id" : 709006078676172801,
  "in_reply_to_status_id" : 709003221143035905,
  "created_at" : "2016-03-13 13:19:56 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708990595088445440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10305099564417, 8.690986681929683 ]
  },
  "id_str" : "708992099861987328",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin ok, late afternoon should work for me. I guess I could be at the airport by 5pm-ish, give or take.",
  "id" : 708992099861987328,
  "in_reply_to_status_id" : 708990595088445440,
  "created_at" : "2016-03-13 12:24:23 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708990031785029633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10305099564417, 8.690986681929683 ]
  },
  "id_str" : "708991964167933952",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin yes, but catching the right exit still confuses me after all those years.",
  "id" : 708991964167933952,
  "in_reply_to_status_id" : 708990031785029633,
  "created_at" : "2016-03-13 12:23:51 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708989185215111168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102919743452, 8.691026334376808 ]
  },
  "id_str" : "708989702125326336",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin and congrats on making the connection, FRA can be confusing when it comes to that.",
  "id" : 708989702125326336,
  "in_reply_to_status_id" : 708989185215111168,
  "created_at" : "2016-03-13 12:14:52 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708989185215111168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1030400392628, 8.690951265847147 ]
  },
  "id_str" : "708989529030594560",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin sure, depends on when you\u2019re coming through Frankfurt. I\u2019ll come back from Berlin by \u2708\uFE0F on Wednesday morning.",
  "id" : 708989529030594560,
  "in_reply_to_status_id" : 708989185215111168,
  "created_at" : "2016-03-13 12:14:10 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 67, 76 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/lXfS2Hgaw6",
      "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/#opensnp",
      "display_url" : "obf.github.io\/GSoC\/ideas\/#op\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708953715898769408",
  "text" : "You\u2019re a student, want money &amp; contrib. to open source? Thx to @obf_news openSNP has projects in the Summer of Code https:\/\/t.co\/lXfS2Hgaw6",
  "id" : 708953715898769408,
  "created_at" : "2016-03-13 09:51:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708945959997218816",
  "geo" : { },
  "id_str" : "708948441146195968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I hoped to see how you implemented the MC, but that\u2019s just too lazy. \uD83D\uDE02",
  "id" : 708948441146195968,
  "in_reply_to_status_id" : 708945959997218816,
  "created_at" : "2016-03-13 09:30:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708942037131862016",
  "geo" : { },
  "id_str" : "708947053460721664",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin wanna grab a coffee if your connection allows it?",
  "id" : 708947053460721664,
  "in_reply_to_status_id" : 708942037131862016,
  "created_at" : "2016-03-13 09:25:23 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 11, 19 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/aY1vDQ3iLQ",
      "expanded_url" : "http:\/\/qz.com\/627989\/why-are-so-many-smart-people-such-idiots-about-philosophy\/",
      "display_url" : "qz.com\/627989\/why-are\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "708823992749182976",
  "geo" : { },
  "id_str" : "708942519564951556",
  "in_reply_to_user_id" : 519830368,
  "text" : "@CeltThulu @JBYoder I have bad news https:\/\/t.co\/aY1vDQ3iLQ",
  "id" : 708942519564951556,
  "in_reply_to_status_id" : 708823992749182976,
  "created_at" : "2016-03-13 09:07:22 +0000",
  "in_reply_to_screen_name" : "CeltThulhu",
  "in_reply_to_user_id_str" : "519830368",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/mUtsmRLoJU",
      "expanded_url" : "https:\/\/twitter.com\/csoghoian\/status\/708853253761589252",
      "display_url" : "twitter.com\/csoghoian\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708940832682995712",
  "text" : "PGP usability anno 1780. And not a thing has changed. https:\/\/t.co\/mUtsmRLoJU",
  "id" : 708940832682995712,
  "created_at" : "2016-03-13 09:00:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708785504360202241",
  "geo" : { },
  "id_str" : "708787903338520576",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon sure, why would you act responsible if 5 million (give or take) people think of you as a science role model\u2026",
  "id" : 708787903338520576,
  "in_reply_to_status_id" : 708785504360202241,
  "created_at" : "2016-03-12 22:52:59 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BiologistSpaceFacts",
      "indices" : [ 18, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/EEXDpq1DbM",
      "expanded_url" : "http:\/\/theweek.com\/articles\/610948\/why-many-scientists-are-ignorant",
      "display_url" : "theweek.com\/articles\/61094\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708702277524127744",
  "text" : "Fitting the whole #BiologistSpaceFacts thing: Why so many scientists are so ignorant https:\/\/t.co\/EEXDpq1DbM",
  "id" : 708702277524127744,
  "created_at" : "2016-03-12 17:12:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 98, 108 ],
      "id_str" : "12192142",
      "id" : 12192142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AGTy5lt9h3",
      "expanded_url" : "http:\/\/www.wolproject.com\/",
      "display_url" : "wolproject.com"
    } ]
  },
  "geo" : { },
  "id_str" : "708677674714210304",
  "text" : "What if famous movies (eg. Dr. Strangelove) would end playing the Dire Straits\u2019 Walk of Life? \/ht @hdsjulian https:\/\/t.co\/AGTy5lt9h3",
  "id" : 708677674714210304,
  "created_at" : "2016-03-12 15:34:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/vjuCsRj9Up",
      "expanded_url" : "https:\/\/twitter.com\/neiltyson\/status\/708427052433678336",
      "display_url" : "twitter.com\/neiltyson\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608697431218, 8.818599106916999 ]
  },
  "id_str" : "708555516096724992",
  "text" : "I present you: the Richard Dawkins of Astrophysics. https:\/\/t.co\/vjuCsRj9Up",
  "id" : 708555516096724992,
  "created_at" : "2016-03-12 07:29:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/UNTj3do4NT",
      "expanded_url" : "https:\/\/experiment.com\/projects\/the-joshua-tree-genome-project",
      "display_url" : "experiment.com\/projects\/the-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708395793389060096",
  "text" : "I just did my part to help fund the Joshua Tree Genome Project: https:\/\/t.co\/UNTj3do4NT",
  "id" : 708395793389060096,
  "created_at" : "2016-03-11 20:54:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/6d5byiBNFA",
      "expanded_url" : "http:\/\/m.imgur.com\/H4r2V8r?r",
      "display_url" : "m.imgur.com\/H4r2V8r?r"
    } ]
  },
  "geo" : { },
  "id_str" : "708350625021599746",
  "text" : "omg, his face is already burnt by the sun! https:\/\/t.co\/6d5byiBNFA",
  "id" : 708350625021599746,
  "created_at" : "2016-03-11 17:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708338247085264896",
  "geo" : { },
  "id_str" : "708338742646476800",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe oh well, who doesn\u2019t have their past allegiances they\u2019re now embarrassed by? \uD83D\uDE09",
  "id" : 708338742646476800,
  "in_reply_to_status_id" : 708338247085264896,
  "created_at" : "2016-03-11 17:08:11 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vZW3PXZ8Qv",
      "expanded_url" : "http:\/\/michael-balter.blogspot.de\/2016\/03\/why-did-sciencemagazine-terminate-me.html?m=1",
      "display_url" : "michael-balter.blogspot.de\/2016\/03\/why-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708324050221867008",
  "text" : "I\u2019m just amazed how Science manages to become even more dislikable, basically by the week. https:\/\/t.co\/vZW3PXZ8Qv",
  "id" : 708324050221867008,
  "created_at" : "2016-03-11 16:09:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708320731420041217",
  "geo" : { },
  "id_str" : "708323463153491969",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb at first I read \u201Eeating 1000+ guilt-free donuts\u201C. Was really convinced I too should take up cycling to work!",
  "id" : 708323463153491969,
  "in_reply_to_status_id" : 708320731420041217,
  "created_at" : "2016-03-11 16:07:28 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/x4IhNXqYaY",
      "expanded_url" : "https:\/\/i.imgur.com\/hdV1zXJ.gifv",
      "display_url" : "i.imgur.com\/hdV1zXJ.gifv"
    } ]
  },
  "geo" : { },
  "id_str" : "708307149957505024",
  "text" : "when you just try to read this one paywalled paper https:\/\/t.co\/x4IhNXqYaY",
  "id" : 708307149957505024,
  "created_at" : "2016-03-11 15:02:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/X8DxBWF3Zw",
      "expanded_url" : "http:\/\/shitmyreviewerssay.tumblr.com\/post\/140509498082\/unless-the-authors-performed-some-clever-pagan",
      "display_url" : "shitmyreviewerssay.tumblr.com\/post\/140509498\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708289442524614656",
  "text" : "\uD83D\uDD2E\uD83D\uDCFF https:\/\/t.co\/X8DxBWF3Zw",
  "id" : 708289442524614656,
  "created_at" : "2016-03-11 13:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fleischman",
      "screen_name" : "C_Golgi",
      "indices" : [ 3, 11 ],
      "id_str" : "147584365",
      "id" : 147584365
    }, {
      "name" : "ASCB",
      "screen_name" : "ASCBiology",
      "indices" : [ 87, 98 ],
      "id_str" : "111584424",
      "id" : 111584424
    }, {
      "name" : "NIGMS",
      "screen_name" : "NIGMS",
      "indices" : [ 99, 105 ],
      "id_str" : "71061891",
      "id" : 71061891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/kguy1iKDPP",
      "expanded_url" : "http:\/\/www.ascb.org\/lost-paper-gregor-mendel-patron-saint-low-impact-scientific-publishing\/",
      "display_url" : "ascb.org\/lost-paper-gre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708286425834393600",
  "text" : "RT @C_Golgi: Gregor Mendel's \"lost\" peas paper throws light on origins of Reviewer #3. @ASCBiology @NIGMS https:\/\/t.co\/kguy1iKDPP https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ASCB",
        "screen_name" : "ASCBiology",
        "indices" : [ 74, 85 ],
        "id_str" : "111584424",
        "id" : 111584424
      }, {
        "name" : "NIGMS",
        "screen_name" : "NIGMS",
        "indices" : [ 86, 92 ],
        "id_str" : "71061891",
        "id" : 71061891
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/C_Golgi\/status\/707953960871657473\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/eWm9GXDA5H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdMoYDbWEAAkSME.jpg",
        "id_str" : "707953960129269760",
        "id" : 707953960129269760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdMoYDbWEAAkSME.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/eWm9GXDA5H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/kguy1iKDPP",
        "expanded_url" : "http:\/\/www.ascb.org\/lost-paper-gregor-mendel-patron-saint-low-impact-scientific-publishing\/",
        "display_url" : "ascb.org\/lost-paper-gre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707953960871657473",
    "text" : "Gregor Mendel's \"lost\" peas paper throws light on origins of Reviewer #3. @ASCBiology @NIGMS https:\/\/t.co\/kguy1iKDPP https:\/\/t.co\/eWm9GXDA5H",
    "id" : 707953960871657473,
    "created_at" : "2016-03-10 15:39:12 +0000",
    "user" : {
      "name" : "John Fleischman",
      "screen_name" : "C_Golgi",
      "protected" : false,
      "id_str" : "147584365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2999227054\/e0137ad50a760cf6938770c60510d430_normal.jpeg",
      "id" : 147584365,
      "verified" : false
    }
  },
  "id" : 708286425834393600,
  "created_at" : "2016-03-11 13:40:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LyYSpkWmHU",
      "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/2016\/03\/one-of-the-greatest-art-heists-of-our-time-was-actually-a-data-hack\/",
      "display_url" : "arstechnica.com\/tech-policy\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708280888807788544",
  "text" : "Time to re-read \u201EThe Work of Art in the Age of Mechanical Reproduction\u201C I\u2019d say. https:\/\/t.co\/LyYSpkWmHU",
  "id" : 708280888807788544,
  "created_at" : "2016-03-11 13:18:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Abagond",
      "screen_name" : "JulianAbagond",
      "indices" : [ 3, 17 ],
      "id_str" : "855933949",
      "id" : 855933949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0eLr60QeLB",
      "expanded_url" : "http:\/\/africasacountry.com\/2014\/02\/chimamanda-adichie-lines-up-the-homophobic-arguments-and-knocks-them-down-one-by-one\/",
      "display_url" : "africasacountry.com\/2014\/02\/chimam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708277480591925248",
  "text" : "RT @JulianAbagond: Chimamanda Adichie lines up the homophobic arguments and knocks them down one by one https:\/\/t.co\/0eLr60QeLB via @africa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AFRICA IS A COUNTRY",
        "screen_name" : "africasacountry",
        "indices" : [ 113, 129 ],
        "id_str" : "399156475",
        "id" : 399156475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/0eLr60QeLB",
        "expanded_url" : "http:\/\/africasacountry.com\/2014\/02\/chimamanda-adichie-lines-up-the-homophobic-arguments-and-knocks-them-down-one-by-one\/",
        "display_url" : "africasacountry.com\/2014\/02\/chimam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "708269718751330304",
    "text" : "Chimamanda Adichie lines up the homophobic arguments and knocks them down one by one https:\/\/t.co\/0eLr60QeLB via @africasacountry",
    "id" : 708269718751330304,
    "created_at" : "2016-03-11 12:33:54 +0000",
    "user" : {
      "name" : "Julian Abagond",
      "screen_name" : "JulianAbagond",
      "protected" : false,
      "id_str" : "855933949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2668694137\/d1ba8333e1a08685ae3c4965cd061dd3_normal.png",
      "id" : 855933949,
      "verified" : false
    }
  },
  "id" : 708277480591925248,
  "created_at" : "2016-03-11 13:04:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 74, 84 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "708232994386001920",
  "text" : "Misread the news as \u2018doping scandal involving Melodium\u2019 and wondered what @romanmars got himself into now.",
  "id" : 708232994386001920,
  "created_at" : "2016-03-11 10:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/S1aGtPytXO",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/708178445604225024",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708229601957421056",
  "text" : "Just watch out you don\u2019t end up in a weird recursion. https:\/\/t.co\/S1aGtPytXO",
  "id" : 708229601957421056,
  "created_at" : "2016-03-11 09:54:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/bNHKI6xDra",
      "expanded_url" : "https:\/\/memecrunch.com\/meme\/164I0\/i-ve-heard-it-both-ways\/image.png?w=400&c=1",
      "display_url" : "memecrunch.com\/meme\/164I0\/i-v\u2026"
    }, {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/v3fKKf8MBj",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/708176744465870848",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "708227406646087680",
  "text" : "Only possible comment: https:\/\/t.co\/bNHKI6xDra https:\/\/t.co\/v3fKKf8MBj",
  "id" : 708227406646087680,
  "created_at" : "2016-03-11 09:45:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "708007886308446209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080081709559, 8.818570303227464 ]
  },
  "id_str" : "708044491173793793",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime nice! :)",
  "id" : 708044491173793793,
  "in_reply_to_status_id" : 708007886308446209,
  "created_at" : "2016-03-10 21:38:56 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/PZb5RMYIei",
      "expanded_url" : "https:\/\/twitter.com\/ollie\/status\/707980228539318272",
      "display_url" : "twitter.com\/ollie\/status\/7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17655783831022, 8.630152989410176 ]
  },
  "id_str" : "707988965022896129",
  "text" : "tl;dr: more research is clearly needed. https:\/\/t.co\/PZb5RMYIei",
  "id" : 707988965022896129,
  "created_at" : "2016-03-10 17:58:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/SP3MKBzdf8",
      "expanded_url" : "https:\/\/aeon.co\/essays\/how-the-internet-flips-elections-and-alters-our-thoughts",
      "display_url" : "aeon.co\/essays\/how-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707974434611658752",
  "text" : "\u00ABI calculated that Google now has the power to flip upwards of 25 per cent of the national elections in the world\u00BB https:\/\/t.co\/SP3MKBzdf8",
  "id" : 707974434611658752,
  "created_at" : "2016-03-10 17:00:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/VigMWbi3T3",
      "expanded_url" : "https:\/\/twitter.com\/usuallyawake\/status\/705598710135132160",
      "display_url" : "twitter.com\/usuallyawake\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707948273588428801",
  "text" : "I didn\u2019t know this was a thing. I might rethink my career! https:\/\/t.co\/VigMWbi3T3",
  "id" : 707948273588428801,
  "created_at" : "2016-03-10 15:16:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707914335239200768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17215155057431, 8.62771255962603 ]
  },
  "id_str" : "707914773569146880",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil \u263A\uFE0F such skill!",
  "id" : 707914773569146880,
  "in_reply_to_status_id" : 707914335239200768,
  "created_at" : "2016-03-10 13:03:29 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/oWlg7V8AZh",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/4908490\/lotr-battle2-o.gif",
      "display_url" : "stream1.gifsoup.com\/view2\/4908490\/\u2026"
    }, {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ONxRU5Pzsv",
      "expanded_url" : "https:\/\/twitter.com\/kventil\/status\/707913519992315904",
      "display_url" : "twitter.com\/kventil\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707913662825144320",
  "text" : "multi-processor jobs on our cluster be like: https:\/\/t.co\/oWlg7V8AZh https:\/\/t.co\/ONxRU5Pzsv",
  "id" : 707913662825144320,
  "created_at" : "2016-03-10 12:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6hNoFiS06D",
      "expanded_url" : "http:\/\/www.strangevehicles.com\/images\/content\/192358.gif",
      "display_url" : "strangevehicles.com\/images\/content\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707913028763852800",
  "text" : "our cluster queue right now https:\/\/t.co\/6hNoFiS06D",
  "id" : 707913028763852800,
  "created_at" : "2016-03-10 12:56:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707892663366905856",
  "geo" : { },
  "id_str" : "707907783933476864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u201Enur zu Dekorationszwecken\u201C. Anstelle von was?! \uD83D\uDE31\uD83D\uDE15",
  "id" : 707907783933476864,
  "in_reply_to_status_id" : 707892663366905856,
  "created_at" : "2016-03-10 12:35:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707889598530232321",
  "geo" : { },
  "id_str" : "707906902441791488",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna same here :D",
  "id" : 707906902441791488,
  "in_reply_to_status_id" : 707889598530232321,
  "created_at" : "2016-03-10 12:32:12 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707875125702598657",
  "text" : "@malech wird der n\u00E4chste es dann mit einem Auftragskiller f\u00FCr die unkompliziertere Scheidung versuchen?",
  "id" : 707875125702598657,
  "created_at" : "2016-03-10 10:25:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707872002217021440",
  "geo" : { },
  "id_str" : "707873094879289344",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce maybe picture in picture could work there as well? There\u2019s plenty of space in the Atlantic :p",
  "id" : 707873094879289344,
  "in_reply_to_status_id" : 707872002217021440,
  "created_at" : "2016-03-10 10:17:52 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707871167907045376",
  "geo" : { },
  "id_str" : "707871698230624256",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce would love to see the results once you\u2019ve done it. Might come in handy for me one day :D",
  "id" : 707871698230624256,
  "in_reply_to_status_id" : 707871167907045376,
  "created_at" : "2016-03-10 10:12:19 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/koBQjx3mPm",
      "expanded_url" : "http:\/\/www.r-bloggers.com\/moving-the-earth-well-alaska-hawaii-with-r\/",
      "display_url" : "r-bloggers.com\/moving-the-ear\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707869461274107904",
  "geo" : { },
  "id_str" : "707869996244996096",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce should work too, see https:\/\/t.co\/koBQjx3mPm",
  "id" : 707869996244996096,
  "in_reply_to_status_id" : 707869461274107904,
  "created_at" : "2016-03-10 10:05:33 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/C0pJ6Rz2Q2",
      "expanded_url" : "http:\/\/ruleofthirds.de\/visualize-geolocations\/",
      "display_url" : "ruleofthirds.de\/visualize-geol\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707868633356173312",
  "geo" : { },
  "id_str" : "707868983744139264",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce used ggplot2 so far, see https:\/\/t.co\/C0pJ6Rz2Q2",
  "id" : 707868983744139264,
  "in_reply_to_status_id" : 707868633356173312,
  "created_at" : "2016-03-10 10:01:31 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/SVeyzn2p53",
      "expanded_url" : "https:\/\/twitter.com\/SynFutures\/status\/707867168147374080",
      "display_url" : "twitter.com\/SynFutures\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707867831300448256",
  "text" : "\u00ABNature bias does not track harm. Heroin is a natural substance: it derives from the poppy.\u00BB https:\/\/t.co\/SVeyzn2p53",
  "id" : 707867831300448256,
  "created_at" : "2016-03-10 09:56:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 8, 15 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707867271457148929",
  "geo" : { },
  "id_str" : "707867487619182592",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @foxeen yep, wieso die .de Variante nicht ging weiss ich nicht.",
  "id" : 707867487619182592,
  "in_reply_to_status_id" : 707867271457148929,
  "created_at" : "2016-03-10 09:55:35 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 8, 15 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/sRS7ycYPkx",
      "expanded_url" : "http:\/\/blog.flickr.net\/en\/2016\/03\/08\/changes-to-flickr-pro-and-coupon-for-30-off-annual-rate\/",
      "display_url" : "blog.flickr.net\/en\/2016\/03\/08\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707866226484224001",
  "geo" : { },
  "id_str" : "707866869936603136",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen @Evo2Me dieser? https:\/\/t.co\/sRS7ycYPkx",
  "id" : 707866869936603136,
  "in_reply_to_status_id" : 707866226484224001,
  "created_at" : "2016-03-10 09:53:07 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 3, 16 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Electron",
      "screen_name" : "electronjs",
      "indices" : [ 22, 33 ],
      "id_str" : "3169354657",
      "id" : 3169354657
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 65, 74 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "openscience",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/9xOFS4uIUH",
      "expanded_url" : "https:\/\/github.com\/joeyklee\/climate-bc-downloader\/issues\/1",
      "display_url" : "github.com\/joeyklee\/clima\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707859199166976001",
  "text" : "RT @RaoOfPhysics: Any @electronjs wizards out there who can help @leejoeyk with this issue? https:\/\/t.co\/9xOFS4uIUH #nodejs #openscience",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Electron",
        "screen_name" : "electronjs",
        "indices" : [ 4, 15 ],
        "id_str" : "3169354657",
        "id" : 3169354657
      }, {
        "name" : "Joey  Lee",
        "screen_name" : "leejoeyk",
        "indices" : [ 47, 56 ],
        "id_str" : "575961466",
        "id" : 575961466
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "openscience",
        "indices" : [ 106, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/9xOFS4uIUH",
        "expanded_url" : "https:\/\/github.com\/joeyklee\/climate-bc-downloader\/issues\/1",
        "display_url" : "github.com\/joeyklee\/clima\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707849850843500544",
    "text" : "Any @electronjs wizards out there who can help @leejoeyk with this issue? https:\/\/t.co\/9xOFS4uIUH #nodejs #openscience",
    "id" : 707849850843500544,
    "created_at" : "2016-03-10 08:45:30 +0000",
    "user" : {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "protected" : false,
      "id_str" : "67529128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925102556090683399\/lwyWTMw0_normal.jpg",
      "id" : 67529128,
      "verified" : false
    }
  },
  "id" : 707859199166976001,
  "created_at" : "2016-03-10 09:22:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707692633691279360",
  "geo" : { },
  "id_str" : "707694158618763264",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy if BART was to host platypuses I\u2019d use it much more during my visits!",
  "id" : 707694158618763264,
  "in_reply_to_status_id" : 707692633691279360,
  "created_at" : "2016-03-09 22:26:50 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/bF0T3MZ0br",
      "expanded_url" : "https:\/\/medium.com\/hh-design\/the-world-is-designed-for-men-d06640654491#.geailjnz5",
      "display_url" : "medium.com\/hh-design\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707685408381992961",
  "text" : "male design bias: \u00ABCould the stereotype that women are less \u201Chandy\u201D be designed into the very tools of the trade?\u00BB https:\/\/t.co\/bF0T3MZ0br",
  "id" : 707685408381992961,
  "created_at" : "2016-03-09 21:52:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Hcsbw9ox0I",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/707672401987768320",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707673527533608960",
  "text" : "Germany, where people build glorified tinfoil hats for their penises. https:\/\/t.co\/Hcsbw9ox0I",
  "id" : 707673527533608960,
  "created_at" : "2016-03-09 21:04:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KkWOiXfCU8",
      "expanded_url" : "https:\/\/twitter.com\/r343l\/status\/707641432056549377",
      "display_url" : "twitter.com\/r343l\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707653092112789505",
  "text" : "\u00ABseriously considered terminating the Dean\u201D but had decided not to because \u201Cit would ruin the Dean\u2019s career.\u201D\u00BB WTF?! https:\/\/t.co\/KkWOiXfCU8",
  "id" : 707653092112789505,
  "created_at" : "2016-03-09 19:43:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/JdlC44diXc",
      "expanded_url" : "http:\/\/blog.salathe.com\/jack-of-all-trades",
      "display_url" : "blog.salathe.com\/jack-of-all-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707652109068591104",
  "text" : "The magic (and curse) of working interdisciplinary. Looking at my ragtag collection of papers, I fully agree. https:\/\/t.co\/JdlC44diXc",
  "id" : 707652109068591104,
  "created_at" : "2016-03-09 19:39:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707624033639112704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17658039631039, 8.629963728571138 ]
  },
  "id_str" : "707624556840800257",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \uD83D\uDC96",
  "id" : 707624556840800257,
  "in_reply_to_status_id" : 707624033639112704,
  "created_at" : "2016-03-09 17:50:16 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/3Oc3IWjbJq",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/wes-anderson-moonrise-kingdom-igrSs5Prw7AEo",
      "display_url" : "giphy.com\/gifs\/wes-ander\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707623049932185600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17654661571082, 8.629985226908982 ]
  },
  "id_str" : "707623403658854401",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s know-it-all! https:\/\/t.co\/3Oc3IWjbJq",
  "id" : 707623403658854401,
  "in_reply_to_status_id" : 707623049932185600,
  "created_at" : "2016-03-09 17:45:41 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/gVlxMXTP4i",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/cute-dogs-wd79ADnC13qla",
      "display_url" : "giphy.com\/gifs\/cute-dogs\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707622231036268545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17655900534137, 8.63014381619988 ]
  },
  "id_str" : "707622702845136896",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s https:\/\/t.co\/gVlxMXTP4i ;)",
  "id" : 707622702845136896,
  "in_reply_to_status_id" : 707622231036268545,
  "created_at" : "2016-03-09 17:42:54 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707621622392430592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17656438597747, 8.630094042006684 ]
  },
  "id_str" : "707621765061722112",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s so wird das mit der Ehe nix ;)",
  "id" : 707621765061722112,
  "in_reply_to_status_id" : 707621622392430592,
  "created_at" : "2016-03-09 17:39:10 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707619999427510272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17656174062483, 8.630122803530249 ]
  },
  "id_str" : "707620310548348929",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s das w\u00FCrde ich gerne h\u00E4ufiger h\u00F6ren :D",
  "id" : 707620310548348929,
  "in_reply_to_status_id" : 707619999427510272,
  "created_at" : "2016-03-09 17:33:23 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707619220973101056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1765586536217, 8.630145892109732 ]
  },
  "id_str" : "707619881236209665",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s omg, kannst du dir eine Ehe zwischen zwei Klugscheissern wie uns vorstellen? Nach maximal einer Woche gehen wir uns an die Kehle.",
  "id" : 707619881236209665,
  "in_reply_to_status_id" : 707619220973101056,
  "created_at" : "2016-03-09 17:31:41 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dagmar Waltemath",
      "screen_name" : "dagmarwaltemath",
      "indices" : [ 3, 19 ],
      "id_str" : "64958499",
      "id" : 64958499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BIH",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kFB2NyqkNP",
      "expanded_url" : "https:\/\/www.bihealth.org\/en\/article\/bih-award-for-early-career-women-scientists-in-bioinformatics-404\/",
      "display_url" : "bihealth.org\/en\/article\/bih\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707618718810034176",
  "text" : "RT @dagmarwaltemath: Award for early career female scientists in Bioinformatics. Apply here https:\/\/t.co\/kFB2NyqkNP #BIH #bioinformatics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BIH",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/kFB2NyqkNP",
        "expanded_url" : "https:\/\/www.bihealth.org\/en\/article\/bih-award-for-early-career-women-scientists-in-bioinformatics-404\/",
        "display_url" : "bihealth.org\/en\/article\/bih\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707512822499024897",
    "text" : "Award for early career female scientists in Bioinformatics. Apply here https:\/\/t.co\/kFB2NyqkNP #BIH #bioinformatics",
    "id" : 707512822499024897,
    "created_at" : "2016-03-09 10:26:16 +0000",
    "user" : {
      "name" : "Dagmar Waltemath",
      "screen_name" : "dagmarwaltemath",
      "protected" : false,
      "id_str" : "64958499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674972730\/twitter_normal.png",
      "id" : 64958499,
      "verified" : false
    }
  },
  "id" : 707618718810034176,
  "created_at" : "2016-03-09 17:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707606157410639873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17656251365622, 8.63011682835313 ]
  },
  "id_str" : "707617989374447616",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s meine meinte immer \u2018nicht verzagen, Basti fragen\u2019. Und nun? ;)",
  "id" : 707617989374447616,
  "in_reply_to_status_id" : 707606157410639873,
  "created_at" : "2016-03-09 17:24:10 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vtGT7Ork9v",
      "expanded_url" : "https:\/\/github.com\/sanger-pathogens\/circlator\/releases",
      "display_url" : "github.com\/sanger-pathoge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707586921011269633",
  "text" : "Gotta love open source. My contributions to circlator bumped it up to version 1.2.0 today. https:\/\/t.co\/vtGT7Ork9v",
  "id" : 707586921011269633,
  "created_at" : "2016-03-09 15:20:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/iIw5odIQyH",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1862",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707563402659565568",
  "text" : "academic business casual https:\/\/t.co\/iIw5odIQyH",
  "id" : 707563402659565568,
  "created_at" : "2016-03-09 13:47:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive G. Brown",
      "screen_name" : "Clive_G_Brown",
      "indices" : [ 3, 17 ],
      "id_str" : "1949299478",
      "id" : 1949299478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/FDouH4zReT",
      "expanded_url" : "https:\/\/github.com\/lmmx\/talk-transcripts\/blob\/master\/Nanopore\/NoThanksIveAlreadyGotOne.md",
      "display_url" : "github.com\/lmmx\/talk-tran\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707560842083094528",
  "text" : "RT @Clive_G_Brown: talk-transcripts\/NoThanksIveAlreadyGotOne.md at master \u00B7 lmmx\/talk-transcripts \u00B7 GitHub https:\/\/t.co\/FDouH4zReT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/FDouH4zReT",
        "expanded_url" : "https:\/\/github.com\/lmmx\/talk-transcripts\/blob\/master\/Nanopore\/NoThanksIveAlreadyGotOne.md",
        "display_url" : "github.com\/lmmx\/talk-tran\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707554571971858433",
    "text" : "talk-transcripts\/NoThanksIveAlreadyGotOne.md at master \u00B7 lmmx\/talk-transcripts \u00B7 GitHub https:\/\/t.co\/FDouH4zReT",
    "id" : 707554571971858433,
    "created_at" : "2016-03-09 13:12:10 +0000",
    "user" : {
      "name" : "Clive G. Brown",
      "screen_name" : "Clive_G_Brown",
      "protected" : false,
      "id_str" : "1949299478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481334922603286528\/VBdJ_-kC_normal.jpeg",
      "id" : 1949299478,
      "verified" : false
    }
  },
  "id" : 707560842083094528,
  "created_at" : "2016-03-09 13:37:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707546173616345088",
  "geo" : { },
  "id_str" : "707549556217679872",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc i like the idea. But then having summary statistics isn\u2019t really the same as having the raw data. :)",
  "id" : 707549556217679872,
  "in_reply_to_status_id" : 707546173616345088,
  "created_at" : "2016-03-09 12:52:14 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    }, {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 17, 29 ],
      "id_str" : "114142293",
      "id" : 114142293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707520030158692352",
  "geo" : { },
  "id_str" : "707520187961049092",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner @aloraine205 somehow missed that it\u2019s taking place. :( Have fun, looks great following the hashtag :)",
  "id" : 707520187961049092,
  "in_reply_to_status_id" : 707520030158692352,
  "created_at" : "2016-03-09 10:55:32 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    }, {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 17, 29 ],
      "id_str" : "114142293",
      "id" : 114142293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707519634337992704",
  "geo" : { },
  "id_str" : "707519794732519424",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner @aloraine205 damn, wish I\u2019d be there!",
  "id" : 707519794732519424,
  "in_reply_to_status_id" : 707519634337992704,
  "created_at" : "2016-03-09 10:53:58 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707461444271476736",
  "geo" : { },
  "id_str" : "707506024702484480",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch that\u2019s how I feel about watching go all the time :D",
  "id" : 707506024702484480,
  "in_reply_to_status_id" : 707461444271476736,
  "created_at" : "2016-03-09 09:59:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tom jamieson",
      "screen_name" : "jamiesont",
      "indices" : [ 3, 13 ],
      "id_str" : "36941760",
      "id" : 36941760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707504551578968065",
  "text" : "RT @jamiesont: Lead software engineer of the Apollo Project stands next to printout of tweets asking when's International Men's Day https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jamiesont\/status\/707197010714214400\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/jL26tShguY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdB37eVWwAAo15J.jpg",
        "id_str" : "707197005135790080",
        "id" : 707197005135790080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdB37eVWwAAo15J.jpg",
        "sizes" : [ {
          "h" : 665,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 494
        } ],
        "display_url" : "pic.twitter.com\/jL26tShguY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707197010714214400",
    "text" : "Lead software engineer of the Apollo Project stands next to printout of tweets asking when's International Men's Day https:\/\/t.co\/jL26tShguY",
    "id" : 707197010714214400,
    "created_at" : "2016-03-08 13:31:21 +0000",
    "user" : {
      "name" : "tom jamieson",
      "screen_name" : "jamiesont",
      "protected" : false,
      "id_str" : "36941760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870527146837626880\/FqZA_c-S_normal.jpg",
      "id" : 36941760,
      "verified" : false
    }
  },
  "id" : 707504551578968065,
  "created_at" : "2016-03-09 09:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/S8ukDFHhH6",
      "expanded_url" : "http:\/\/juliasilge.com\/blog\/You-Must-Allow-Me\/",
      "display_url" : "juliasilge.com\/blog\/You-Must-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707503659110817792",
  "text" : "How to use R to do a lovely sentiment analysis of Pride &amp; Prejudice https:\/\/t.co\/S8ukDFHhH6",
  "id" : 707503659110817792,
  "created_at" : "2016-03-09 09:49:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707491207417561088",
  "geo" : { },
  "id_str" : "707491262719508481",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg best gospel ever!",
  "id" : 707491262719508481,
  "in_reply_to_status_id" : 707491207417561088,
  "created_at" : "2016-03-09 09:00:36 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13867944267891, 8.622198783278463 ]
  },
  "id_str" : "707489479850909696",
  "text" : "So, someone enrolled me in a Gospel preaching WhatsApp spam that tells me to repent my sins or I\u2019d go to hell. Interesting\u2026 \uD83D\uDD25",
  "id" : 707489479850909696,
  "created_at" : "2016-03-09 08:53:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/4eiG6OPxP8",
      "expanded_url" : "https:\/\/twitter.com\/ftrain\/status\/707267797424930816",
      "display_url" : "twitter.com\/ftrain\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072149004639, 8.818575384488135 ]
  },
  "id_str" : "707316334099619840",
  "text" : "Ever wondered what Facebook is written in? Yes, that\u2019s right! https:\/\/t.co\/4eiG6OPxP8",
  "id" : 707316334099619840,
  "created_at" : "2016-03-08 21:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 3, 14 ],
      "id_str" : "322658299",
      "id" : 322658299
    }, {
      "name" : "running water",
      "screen_name" : "portmantina",
      "indices" : [ 38, 50 ],
      "id_str" : "808843823107473409",
      "id" : 808843823107473409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707300415096954881",
  "text" : "RT @HopeJahren: Please read this now \"@portmantina: The troubling overlap between \"cool\" teachers and sexual harassment:\nhttps:\/\/t.co\/RFezT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "running water",
        "screen_name" : "portmantina",
        "indices" : [ 22, 34 ],
        "id_str" : "808843823107473409",
        "id" : 808843823107473409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/RFezTXLMN1",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/doublex\/2016\/03\/classroom_sexual_harassment_often_comes_from_cool_teachers_and_professors.html",
        "display_url" : "slate.com\/articles\/life\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "707220682740994048",
    "geo" : { },
    "id_str" : "707255628150878208",
    "in_reply_to_user_id" : 105290832,
    "text" : "Please read this now \"@portmantina: The troubling overlap between \"cool\" teachers and sexual harassment:\nhttps:\/\/t.co\/RFezTXLMN1\u201D",
    "id" : 707255628150878208,
    "in_reply_to_status_id" : 707220682740994048,
    "created_at" : "2016-03-08 17:24:16 +0000",
    "in_reply_to_screen_name" : "c_cauterucci",
    "in_reply_to_user_id_str" : "105290832",
    "user" : {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "protected" : false,
      "id_str" : "322658299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690405901019254784\/Lf4mdZrR_normal.jpg",
      "id" : 322658299,
      "verified" : true
    }
  },
  "id" : 707300415096954881,
  "created_at" : "2016-03-08 20:22:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707237412204892161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072704097646, 8.81850881762711 ]
  },
  "id_str" : "707264581199142912",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe c.f. my Twitter bio :)",
  "id" : 707264581199142912,
  "in_reply_to_status_id" : 707237412204892161,
  "created_at" : "2016-03-08 17:59:51 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707242987516993536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17647890233182, 8.630407069462107 ]
  },
  "id_str" : "707246885468291072",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia and now I\u2019m super thirsty \uD83D\uDE02",
  "id" : 707246885468291072,
  "in_reply_to_status_id" : 707242987516993536,
  "created_at" : "2016-03-08 16:49:32 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 21, 30 ],
      "id_str" : "575961466",
      "id" : 575961466
    }, {
      "name" : "Benedikt Gro\u00DF",
      "screen_name" : "bndktgrs",
      "indices" : [ 37, 46 ],
      "id_str" : "84572266",
      "id" : 84572266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AerialBold",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4XaK07myGH",
      "expanded_url" : "http:\/\/type.aerial-bold.com\/tw\/",
      "display_url" : "type.aerial-bold.com\/tw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "707235557194260480",
  "text" : "RT @abbycabs: Thx to @leejoeyk &amp; @bndktgrs, I can say \"Hello world\" in satellite images! https:\/\/t.co\/4XaK07myGH #AerialBold https:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey  Lee",
        "screen_name" : "leejoeyk",
        "indices" : [ 7, 16 ],
        "id_str" : "575961466",
        "id" : 575961466
      }, {
        "name" : "Benedikt Gro\u00DF",
        "screen_name" : "bndktgrs",
        "indices" : [ 23, 32 ],
        "id_str" : "84572266",
        "id" : 84572266
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/707230130045902848\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ok2ewFSXbI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CdCWDi0UMAAW4ge.jpg",
        "id_str" : "707230129127174144",
        "id" : 707230129127174144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdCWDi0UMAAW4ge.jpg",
        "sizes" : [ {
          "h" : 371,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ok2ewFSXbI"
      } ],
      "hashtags" : [ {
        "text" : "AerialBold",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/4XaK07myGH",
        "expanded_url" : "http:\/\/type.aerial-bold.com\/tw\/",
        "display_url" : "type.aerial-bold.com\/tw\/"
      } ]
    },
    "geo" : { },
    "id_str" : "707230130045902848",
    "text" : "Thx to @leejoeyk &amp; @bndktgrs, I can say \"Hello world\" in satellite images! https:\/\/t.co\/4XaK07myGH #AerialBold https:\/\/t.co\/ok2ewFSXbI",
    "id" : 707230130045902848,
    "created_at" : "2016-03-08 15:42:57 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 707235557194260480,
  "created_at" : "2016-03-08 16:04:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/9SKXZKFU4X",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/133rd60nMOUezK\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/133rd60n\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707217363943424000",
  "geo" : { },
  "id_str" : "707217864156176384",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia awesome typo \uD83C\uDF77 https:\/\/t.co\/9SKXZKFU4X",
  "id" : 707217864156176384,
  "in_reply_to_status_id" : 707217363943424000,
  "created_at" : "2016-03-08 14:54:12 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "indices" : [ 3, 14 ],
      "id_str" : "33773592",
      "id" : 33773592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707206123082948608",
  "text" : "RT @AstroKatie: \"What am I supposed to do, stop asking women out at work because it makes them uncomfortable?\"\n\"Yes. You're at work\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PVvKblHfSl",
        "expanded_url" : "https:\/\/twitter.com\/kateclancy\/status\/702227473572954112",
        "display_url" : "twitter.com\/kateclancy\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702234402584023040",
    "text" : "\"What am I supposed to do, stop asking women out at work because it makes them uncomfortable?\"\n\"Yes. You're at work\" https:\/\/t.co\/PVvKblHfSl",
    "id" : 702234402584023040,
    "created_at" : "2016-02-23 20:51:43 +0000",
    "user" : {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "protected" : false,
      "id_str" : "33773592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2818477708\/0ef050189a11bb7f9cf56306f5d171bf_normal.png",
      "id" : 33773592,
      "verified" : true
    }
  },
  "id" : 707206123082948608,
  "created_at" : "2016-03-08 14:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victoria Bateman",
      "screen_name" : "vnbateman",
      "indices" : [ 3, 13 ],
      "id_str" : "3719889197",
      "id" : 3719889197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9COGyPvpSY",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/blog\/academia-desperate-need-workplace-revolution",
      "display_url" : "timeshighereducation.com\/blog\/academia-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707201745563328512",
  "text" : "RT @vnbateman: My blog for Times Higher on gender and the need for an academic workplace revolution: https:\/\/t.co\/9COGyPvpSY #International\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InternationalWomensDay",
        "indices" : [ 110, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/9COGyPvpSY",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/blog\/academia-desperate-need-workplace-revolution",
        "display_url" : "timeshighereducation.com\/blog\/academia-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "707159572130217984",
    "text" : "My blog for Times Higher on gender and the need for an academic workplace revolution: https:\/\/t.co\/9COGyPvpSY #InternationalWomensDay",
    "id" : 707159572130217984,
    "created_at" : "2016-03-08 11:02:35 +0000",
    "user" : {
      "name" : "Victoria Bateman",
      "screen_name" : "vnbateman",
      "protected" : false,
      "id_str" : "3719889197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645924779887841280\/njhfS3KQ_normal.jpg",
      "id" : 3719889197,
      "verified" : false
    }
  },
  "id" : 707201745563328512,
  "created_at" : "2016-03-08 13:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/707193977724919808\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/KvtH9T8QHH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdB1LMyUsAAZqP8.jpg",
      "id_str" : "707193976768475136",
      "id" : 707193976768475136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdB1LMyUsAAZqP8.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/KvtH9T8QHH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707193222611730434",
  "geo" : { },
  "id_str" : "707193977724919808",
  "in_reply_to_user_id" : 14286491,
  "text" : "Damn, found an even better gif for that! https:\/\/t.co\/KvtH9T8QHH",
  "id" : 707193977724919808,
  "in_reply_to_status_id" : 707193222611730434,
  "created_at" : "2016-03-08 13:19:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/707193222611730434\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/9Zwlt6Gmgx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CdB0IOmUUAA4dde.jpg",
      "id_str" : "707192826203754496",
      "id" : 707192826203754496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CdB0IOmUUAA4dde.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 466
      } ],
      "display_url" : "pic.twitter.com\/9Zwlt6Gmgx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707193222611730434",
  "text" : "Rolling out the buzzwords for official applications. \"Big Open Data\", aka \"Gaping Data\". https:\/\/t.co\/9Zwlt6Gmgx",
  "id" : 707193222611730434,
  "created_at" : "2016-03-08 13:16:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/x9UxUSinyu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=V92OBNsQgxU",
      "display_url" : "youtube.com\/watch?v=V92OBN\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "707154874186735616",
  "geo" : { },
  "id_str" : "707155003581005825",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb https:\/\/t.co\/x9UxUSinyu :3",
  "id" : 707155003581005825,
  "in_reply_to_status_id" : 707154874186735616,
  "created_at" : "2016-03-08 10:44:25 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/6xjCgv27g4",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ExNLPEyEbMI",
      "display_url" : "youtube.com\/watch?v=ExNLPE\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707139170809028608",
  "text" : "This fair land that you call yours, I do not give a damn. https:\/\/t.co\/6xjCgv27g4",
  "id" : 707139170809028608,
  "created_at" : "2016-03-08 09:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/707122429043351552\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Ubq2tBFadA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CdA0GboUMAE16PE.jpg",
      "id_str" : "707122426597879809",
      "id" : 707122426597879809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CdA0GboUMAE16PE.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 311
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 311
      } ],
      "display_url" : "pic.twitter.com\/Ubq2tBFadA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/NrIOWQutRM",
      "expanded_url" : "https:\/\/twitter.com\/cyrillerossant\/status\/706913618692931585",
      "display_url" : "twitter.com\/cyrillerossant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707122429043351552",
  "text" : "And here\u2019s the bioinformatics guide to choosing a file format  https:\/\/t.co\/NrIOWQutRM https:\/\/t.co\/Ubq2tBFadA",
  "id" : 707122429043351552,
  "created_at" : "2016-03-08 08:34:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Primitives Element",
      "screen_name" : "drseilzug",
      "indices" : [ 0, 10 ],
      "id_str" : "243633845",
      "id" : 243633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "707115779108552704",
  "geo" : { },
  "id_str" : "707116267992432640",
  "in_reply_to_user_id" : 243633845,
  "text" : "@drseilzug that\u2019s the \u201Ehe can\u2019t be serious\u201C-guy\u2026",
  "id" : 707116267992432640,
  "in_reply_to_status_id" : 707115779108552704,
  "created_at" : "2016-03-08 08:10:30 +0000",
  "in_reply_to_screen_name" : "drseilzug",
  "in_reply_to_user_id_str" : "243633845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ChLWkf0OkD",
      "expanded_url" : "https:\/\/twitter.com\/Molossoidea\/status\/706952624088682501",
      "display_url" : "twitter.com\/Molossoidea\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707113647047364608",
  "text" : "\u00ABi could even argue that blood on your penis is kinda fun sometimes.\u00BB https:\/\/t.co\/ChLWkf0OkD",
  "id" : 707113647047364608,
  "created_at" : "2016-03-08 08:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "indices" : [ 3, 18 ],
      "id_str" : "4825733537",
      "id" : 4825733537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706984384633692160",
  "text" : "RT @TheBloodVoyage: Pteropoda, Crustacea, and Radiata, and with this feeling, I was anxious to reach them. This Angel Trias who was ill tim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.github.com\/gedankenstuecke\/\" rel=\"nofollow\"\u003EBloodMeridian\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706977084007178241",
    "text" : "Pteropoda, Crustacea, and Radiata, and with this feeling, I was anxious to reach them. This Angel Trias who was ill timed for the night.",
    "id" : 706977084007178241,
    "created_at" : "2016-03-07 22:57:26 +0000",
    "user" : {
      "name" : "Cormac R. McDarwin",
      "screen_name" : "TheBloodVoyage",
      "protected" : false,
      "id_str" : "4825733537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689413531142217728\/O05elrRt_normal.jpg",
      "id" : 4825733537,
      "verified" : false
    }
  },
  "id" : 706984384633692160,
  "created_at" : "2016-03-07 23:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/9zAP7szGXA",
      "expanded_url" : "https:\/\/twitter.com\/iddux\/status\/706923380730044417",
      "display_url" : "twitter.com\/iddux\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706940425911803904",
  "text" : "and its evil twin: $ grep -c &gt; file.fa https:\/\/t.co\/9zAP7szGXA",
  "id" : 706940425911803904,
  "created_at" : "2016-03-07 20:31:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/U5wuKKCFRj",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/cover_story\/2016\/03\/ego_depletion_an_influential_theory_in_psychology_may_have_just_been_debunked.single.html?utm_content=buffera4470&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706937933199179776",
  "text" : "\u00ABA whole field of psychology research may be bunk\u00BB And they are not talking evolutionary psychology! https:\/\/t.co\/U5wuKKCFRj",
  "id" : 706937933199179776,
  "created_at" : "2016-03-07 20:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0vYba8lWtN",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/706886981322719233",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706888185620652033",
  "text" : "The ASA manages to get a \u201Ep-value policy\u201C piece out w\/o paywall. And it even says at least something. See that, NIH? https:\/\/t.co\/0vYba8lWtN",
  "id" : 706888185620652033,
  "created_at" : "2016-03-07 17:04:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 3, 11 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lichen",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "biohacking",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706874402571460609",
  "text" : "RT @Seplute: Chapter 1 of our #lichen #biohacking adventure covered @technariumas blog. Hope to make it to @CitSciAssoc conf too! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cit Sci Association",
        "screen_name" : "CitSciAssoc",
        "indices" : [ 94, 106 ],
        "id_str" : "2598620564",
        "id" : 2598620564
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lichen",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "biohacking",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/RzBMt3s5pB",
        "expanded_url" : "http:\/\/blog.technariumas.lt\/post\/140081910826\/biohacking",
        "display_url" : "blog.technariumas.lt\/post\/140081910\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706872282505945088",
    "text" : "Chapter 1 of our #lichen #biohacking adventure covered @technariumas blog. Hope to make it to @CitSciAssoc conf too! https:\/\/t.co\/RzBMt3s5pB",
    "id" : 706872282505945088,
    "created_at" : "2016-03-07 16:00:59 +0000",
    "user" : {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "protected" : false,
      "id_str" : "188833865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733429172165574656\/JFlTQmja_normal.jpg",
      "id" : 188833865,
      "verified" : false
    }
  },
  "id" : 706874402571460609,
  "created_at" : "2016-03-07 16:09:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706790988308750336",
  "geo" : { },
  "id_str" : "706791038321610754",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes nope, that\u2019s horrible!",
  "id" : 706791038321610754,
  "in_reply_to_status_id" : 706790988308750336,
  "created_at" : "2016-03-07 10:38:09 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ThIK6q6Kuo",
      "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/706750210932801536",
      "display_url" : "twitter.com\/phylogenomics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706790858620805120",
  "text" : "Doesn\u2019t even offer any suggestions on how to end sex. harassment, boils down to \u201Emore research is clearly needed\u201C\u2026 https:\/\/t.co\/ThIK6q6Kuo",
  "id" : 706790858620805120,
  "created_at" : "2016-03-07 10:37:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maude Lachaine",
      "screen_name" : "Maude_LL",
      "indices" : [ 3, 12 ],
      "id_str" : "936516247",
      "id" : 936516247
    }, {
      "name" : "Hilary Parker",
      "screen_name" : "hspter",
      "indices" : [ 15, 22 ],
      "id_str" : "24228154",
      "id" : 24228154
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maude_LL\/status\/706332823976747008\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/PPzXsjNjgr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc1l9e0UMAA5ikb.jpg",
      "id_str" : "706332823485952000",
      "id" : 706332823485952000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc1l9e0UMAA5ikb.jpg",
      "sizes" : [ {
        "h" : 434,
        "resize" : "fit",
        "w" : 1938
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 1938
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/PPzXsjNjgr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706777152365207552",
  "text" : "RT @Maude_LL: .@hspter. My new favourite R package: mansplainr. The best. https:\/\/t.co\/PPzXsjNjgr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hilary Parker",
        "screen_name" : "hspter",
        "indices" : [ 1, 8 ],
        "id_str" : "24228154",
        "id" : 24228154
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maude_LL\/status\/706332823976747008\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/PPzXsjNjgr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc1l9e0UMAA5ikb.jpg",
        "id_str" : "706332823485952000",
        "id" : 706332823485952000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc1l9e0UMAA5ikb.jpg",
        "sizes" : [ {
          "h" : 434,
          "resize" : "fit",
          "w" : 1938
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 1938
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/PPzXsjNjgr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706332823976747008",
    "text" : ".@hspter. My new favourite R package: mansplainr. The best. https:\/\/t.co\/PPzXsjNjgr",
    "id" : 706332823976747008,
    "created_at" : "2016-03-06 04:17:22 +0000",
    "user" : {
      "name" : "Maude Lachaine",
      "screen_name" : "Maude_LL",
      "protected" : false,
      "id_str" : "936516247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825572483734441985\/_M10jtdf_normal.jpg",
      "id" : 936516247,
      "verified" : false
    }
  },
  "id" : 706777152365207552,
  "created_at" : "2016-03-07 09:42:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091954270117, 8.81848959602852 ]
  },
  "id_str" : "706614675560079360",
  "text" : "\u00ABThis isn't fun any longer\u2026\u00BB \u2013 \u00ABYour iPad game?\u00BB \u2013 \u00ABNo, Germany\u2026\u00BB",
  "id" : 706614675560079360,
  "created_at" : "2016-03-06 22:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Heard",
      "screen_name" : "StephenBHeard",
      "indices" : [ 0, 14 ],
      "id_str" : "2862441010",
      "id" : 2862441010
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 15, 29 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706610184651722752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06058026091066, 8.818439796511177 ]
  },
  "id_str" : "706610943447474181",
  "in_reply_to_user_id" : 2862441010,
  "text" : "@StephenBHeard @NazeefaFatima agree, i don't like last minute preps myself, but you are much more flexible with a talk in any case.",
  "id" : 706610943447474181,
  "in_reply_to_status_id" : 706610184651722752,
  "created_at" : "2016-03-06 22:42:31 +0000",
  "in_reply_to_screen_name" : "StephenBHeard",
  "in_reply_to_user_id_str" : "2862441010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Heard",
      "screen_name" : "StephenBHeard",
      "indices" : [ 0, 14 ],
      "id_str" : "2862441010",
      "id" : 2862441010
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 15, 29 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706542060824829952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099541267834, 8.81881157572287 ]
  },
  "id_str" : "706601568439771136",
  "in_reply_to_user_id" : 2862441010,
  "text" : "@StephenBHeard @NazeefaFatima talks. You can prepare them on the plane to the conference ;)",
  "id" : 706601568439771136,
  "in_reply_to_status_id" : 706542060824829952,
  "created_at" : "2016-03-06 22:05:16 +0000",
  "in_reply_to_screen_name" : "StephenBHeard",
  "in_reply_to_user_id_str" : "2862441010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 88, 99 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706574427148980224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06123782782546, 8.818683132002727 ]
  },
  "id_str" : "706582869230153728",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr would be interesting to see, I guess there might be some data on it out there. @EffyVayena do you have any pointers?",
  "id" : 706582869230153728,
  "in_reply_to_status_id" : 706574427148980224,
  "created_at" : "2016-03-06 20:50:58 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706574278842564609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06116032745633, 8.818808445425919 ]
  },
  "id_str" : "706582459677331456",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr that\u2019s a general scientific question I guess ;)",
  "id" : 706582459677331456,
  "in_reply_to_status_id" : 706574278842564609,
  "created_at" : "2016-03-06 20:49:20 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706573321278775298",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086274540837, 8.818603891905743 ]
  },
  "id_str" : "706573587453485057",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr my anecdotal sample is that even there it\u2019s not much better. At least as soon as their personal truths are at stake.",
  "id" : 706573587453485057,
  "in_reply_to_status_id" : 706573321278775298,
  "created_at" : "2016-03-06 20:14:05 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706571983002202112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100683454479, 8.818737197627096 ]
  },
  "id_str" : "706572752434675713",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr you\u2019d guess. But we both know that this is only an ideal to strive to\u2026 :\/",
  "id" : 706572752434675713,
  "in_reply_to_status_id" : 706571983002202112,
  "created_at" : "2016-03-06 20:10:46 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706571484207128576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06118965414366, 8.818583746674333 ]
  },
  "id_str" : "706571728944828417",
  "in_reply_to_user_id" : 14286491,
  "text" : "Don\u2019t let anyone tell you that scientists are behaving more ethical than the general population\u2026",
  "id" : 706571728944828417,
  "in_reply_to_status_id" : 706571484207128576,
  "created_at" : "2016-03-06 20:06:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/zq3SNWAv2U",
      "expanded_url" : "https:\/\/twitter.com\/HopeJahren\/status\/706560463924899840",
      "display_url" : "twitter.com\/HopeJahren\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111201999548, 8.818582347870098 ]
  },
  "id_str" : "706571484207128576",
  "text" : "Mind you: This is from the same group of people claiming that ethical oversight of science is unnecessary\u2026 https:\/\/t.co\/zq3SNWAv2U",
  "id" : 706571484207128576,
  "created_at" : "2016-03-06 20:05:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 0, 10 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 11, 25 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706518888909901824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082611194085, 8.818518867913419 ]
  },
  "id_str" : "706528886566346752",
  "in_reply_to_user_id" : 267256091,
  "text" : "@_inundata @phylogenomics so depends on the kind of conference you\u2019re doing whether it\u2019s a good\/bad thing.",
  "id" : 706528886566346752,
  "in_reply_to_status_id" : 706518888909901824,
  "created_at" : "2016-03-06 17:16:27 +0000",
  "in_reply_to_screen_name" : "_inundata",
  "in_reply_to_user_id_str" : "267256091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 0, 10 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 11, 25 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706518888909901824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076985215331, 8.818621553525677 ]
  },
  "id_str" : "706528787358490625",
  "in_reply_to_user_id" : 267256091,
  "text" : "@_inundata @phylogenomics though on the other hand on weekdays only people who can claim it\u2019s work can show up w\/o taking vacation days.",
  "id" : 706528787358490625,
  "in_reply_to_status_id" : 706518888909901824,
  "created_at" : "2016-03-06 17:16:04 +0000",
  "in_reply_to_screen_name" : "_inundata",
  "in_reply_to_user_id_str" : "267256091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706517376595054592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072938936615, 8.81869818761746 ]
  },
  "id_str" : "706517918813650949",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen on the contrary. There were quite a few. It\u2019s Offenbach after all, the city w\/ the largest relative migrant population in DE :)",
  "id" : 706517918813650949,
  "in_reply_to_status_id" : 706517376595054592,
  "created_at" : "2016-03-06 16:32:52 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10039092740778, 8.751490417314486 ]
  },
  "id_str" : "706505477719461888",
  "text" : "My voting strategy in the local election today: giving all my votes to non-white women.",
  "id" : 706505477719461888,
  "created_at" : "2016-03-06 15:43:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706382832122273792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06107878777741, 8.818475581215463 ]
  },
  "id_str" : "706424589799317504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ouch, good luck! \u2615\uFE0F\uD83C\uDF7A",
  "id" : 706424589799317504,
  "in_reply_to_status_id" : 706382832122273792,
  "created_at" : "2016-03-06 10:22:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 3, 14 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706276184267595776",
  "text" : "RT @HopeJahren: Srsly my email: Women- I read ur piece. I am going to do X. Men- I read ur piece. You should do X. And Y. And Z. And then r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706269764524453888",
    "text" : "Srsly my email: Women- I read ur piece. I am going to do X. Men- I read ur piece. You should do X. And Y. And Z. And then report back to me.",
    "id" : 706269764524453888,
    "created_at" : "2016-03-06 00:06:48 +0000",
    "user" : {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "protected" : false,
      "id_str" : "322658299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690405901019254784\/Lf4mdZrR_normal.jpg",
      "id" : 322658299,
      "verified" : true
    }
  },
  "id" : 706276184267595776,
  "created_at" : "2016-03-06 00:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 0, 15 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706211551041028096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076208646775, 8.81851127059899 ]
  },
  "id_str" : "706212794945900545",
  "in_reply_to_user_id" : 1428575976,
  "text" : "@MozillaScience would love me some of that DNA, they are so cute \uD83D\uDC96",
  "id" : 706212794945900545,
  "in_reply_to_status_id" : 706211551041028096,
  "created_at" : "2016-03-05 20:20:25 +0000",
  "in_reply_to_screen_name" : "MozillaScience",
  "in_reply_to_user_id_str" : "1428575976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 0, 15 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706208150324531200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06069631701042, 8.818579804903441 ]
  },
  "id_str" : "706211127412334594",
  "in_reply_to_user_id" : 1428575976,
  "text" : "@MozillaScience there are temp tattoos?! I want one! :D",
  "id" : 706211127412334594,
  "in_reply_to_status_id" : 706208150324531200,
  "created_at" : "2016-03-05 20:13:48 +0000",
  "in_reply_to_screen_name" : "MozillaScience",
  "in_reply_to_user_id_str" : "1428575976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "706196783257534464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06105555732842, 8.818596052973675 ]
  },
  "id_str" : "706197882064478213",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch ich komm leider auch erst morgen wieder zu einem echten Internetanschluss, sorry \uD83D\uDE14",
  "id" : 706197882064478213,
  "in_reply_to_status_id" : 706196783257534464,
  "created_at" : "2016-03-05 19:21:10 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/G3mG5IviX0",
      "expanded_url" : "http:\/\/sci-hub.io",
      "display_url" : "sci-hub.io"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06115591828222, 8.818715355553145 ]
  },
  "id_str" : "706195432230264834",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch https:\/\/t.co\/G3mG5IviX0 schon probiert?",
  "id" : 706195432230264834,
  "created_at" : "2016-03-05 19:11:26 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Devers \u24BA",
      "screen_name" : "dotmacro",
      "indices" : [ 3, 12 ],
      "id_str" : "2211949592",
      "id" : 2211949592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicincome",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rrEgTRani5",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/opinions\/free-money-might-be-the-best-way-to-end-poverty\/2013\/12\/29\/679c8344-5ec8-11e3-95c2-13623eb2b0e1_story.html",
      "display_url" : "washingtonpost.com\/opinions\/free-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706195251984211969",
  "text" : "RT @dotmacro: What happens when you hand homeless men \u00A33,000 (~$4500), no strings attached?\nhttps:\/\/t.co\/rrEgTRani5 #basicincome https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dotmacro\/status\/705992000659558401\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/CdjNDCehma",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVb-REYU4AAGJxu.png",
        "id_str" : "673004763525472256",
        "id" : 673004763525472256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVb-REYU4AAGJxu.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 626
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 626
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 626
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 626
        } ],
        "display_url" : "pic.twitter.com\/CdjNDCehma"
      } ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/rrEgTRani5",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/opinions\/free-money-might-be-the-best-way-to-end-poverty\/2013\/12\/29\/679c8344-5ec8-11e3-95c2-13623eb2b0e1_story.html",
        "display_url" : "washingtonpost.com\/opinions\/free-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705992000659558401",
    "text" : "What happens when you hand homeless men \u00A33,000 (~$4500), no strings attached?\nhttps:\/\/t.co\/rrEgTRani5 #basicincome https:\/\/t.co\/CdjNDCehma",
    "id" : 705992000659558401,
    "created_at" : "2016-03-05 05:43:04 +0000",
    "user" : {
      "name" : "Andrea Devers \u24BA",
      "screen_name" : "dotmacro",
      "protected" : false,
      "id_str" : "2211949592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650915645362565120\/fLKWNuec_normal.jpg",
      "id" : 2211949592,
      "verified" : false
    }
  },
  "id" : 706195251984211969,
  "created_at" : "2016-03-05 19:10:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11268076957214, 8.755709733822155 ]
  },
  "id_str" : "706148879704662016",
  "text" : "\uD83D\uDE97\uD83D\uDD0B\u2705",
  "id" : 706148879704662016,
  "created_at" : "2016-03-05 16:06:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "indices" : [ 3, 16 ],
      "id_str" : "35943",
      "id" : 35943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706107071943610368",
  "text" : "RT @karenmcgrane: I answered this young woman\u2019s career day questions and asked her some of my own, and posted the responses here: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/V354nUnWX3",
        "expanded_url" : "http:\/\/karenmcgrane.com\/2016\/03\/04\/career-day-special-with-a-future-web-designer\/",
        "display_url" : "karenmcgrane.com\/2016\/03\/04\/car\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "705749041469120512",
    "geo" : { },
    "id_str" : "705749116060618752",
    "in_reply_to_user_id" : 35943,
    "text" : "I answered this young woman\u2019s career day questions and asked her some of my own, and posted the responses here: https:\/\/t.co\/V354nUnWX3",
    "id" : 705749116060618752,
    "in_reply_to_status_id" : 705749041469120512,
    "created_at" : "2016-03-04 13:37:56 +0000",
    "in_reply_to_screen_name" : "karenmcgrane",
    "in_reply_to_user_id_str" : "35943",
    "user" : {
      "name" : "Karen McGrane",
      "screen_name" : "karenmcgrane",
      "protected" : false,
      "id_str" : "35943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827641980247273473\/Ci5X1aeS_normal.jpg",
      "id" : 35943,
      "verified" : true
    }
  },
  "id" : 706107071943610368,
  "created_at" : "2016-03-05 13:20:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 3, 11 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FGM",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "Tanzania",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "OSM",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "IWD",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706073058403033088",
  "text" : "RT @Seplute: We're raising #FGM awareness for Int. Women's Day by mapping girls villages in #Tanzania. You can help! :) #OSM #IWD https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FGM",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "Tanzania",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "OSM",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "IWD",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/KEyCgAMQk4",
        "expanded_url" : "https:\/\/twitter.com\/Crowd2Map\/status\/706041821047222272",
        "display_url" : "twitter.com\/Crowd2Map\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706043841447591936",
    "text" : "We're raising #FGM awareness for Int. Women's Day by mapping girls villages in #Tanzania. You can help! :) #OSM #IWD https:\/\/t.co\/KEyCgAMQk4",
    "id" : 706043841447591936,
    "created_at" : "2016-03-05 09:09:04 +0000",
    "user" : {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "protected" : false,
      "id_str" : "188833865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733429172165574656\/JFlTQmja_normal.jpg",
      "id" : 188833865,
      "verified" : false
    }
  },
  "id" : 706073058403033088,
  "created_at" : "2016-03-05 11:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona de Londras",
      "screen_name" : "fdelond",
      "indices" : [ 3, 11 ],
      "id_str" : "23397027",
      "id" : 23397027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706042348183101440",
  "text" : "RT @fdelond: I\u2019ve lost count of # of ppl who\u2019ve told me they\u2019re doing this \/ Rush for Irish passports brought on by Brexit fears https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/oDH7BOIscy",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/mar\/04\/rush-for-irish-passports-brought-on-by-brexit-fears?CMP=Share_AndroidApp_Tweet",
        "display_url" : "theguardian.com\/world\/2016\/mar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "706039682342248449",
    "text" : "I\u2019ve lost count of # of ppl who\u2019ve told me they\u2019re doing this \/ Rush for Irish passports brought on by Brexit fears https:\/\/t.co\/oDH7BOIscy",
    "id" : 706039682342248449,
    "created_at" : "2016-03-05 08:52:32 +0000",
    "user" : {
      "name" : "Fiona de Londras",
      "screen_name" : "fdelond",
      "protected" : false,
      "id_str" : "23397027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930345190807822336\/cNIRce-T_normal.jpg",
      "id" : 23397027,
      "verified" : false
    }
  },
  "id" : 706042348183101440,
  "created_at" : "2016-03-05 09:03:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/b15pAwc8uJ",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/TWk62vC7jMs\/info%3Adoi%2F10.1371%2Fjournal.pone.0150989",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "706039611622092800",
  "text" : "How rumours spread on Twitter: a rather simplistic and descriptive study. https:\/\/t.co\/b15pAwc8uJ",
  "id" : 706039611622092800,
  "created_at" : "2016-03-05 08:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/tgxnPcZAcX",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/03\/06\/opinion\/sunday\/she-wanted-to-do-her-research-he-wanted-to-talk-feelings.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
      "display_url" : "nytimes.com\/2016\/03\/06\/opi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101907701237, 8.818672578790055 ]
  },
  "id_str" : "706028111385726976",
  "text" : "\u00ABthe course of sexual harassment is so predictable\u00BB She Wanted to Do Her Research. He Wanted to Talk \u2018Feelings.\u2019 https:\/\/t.co\/tgxnPcZAcX",
  "id" : 706028111385726976,
  "created_at" : "2016-03-05 08:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessondra Springmann",
      "screen_name" : "sondy",
      "indices" : [ 3, 9 ],
      "id_str" : "135749583",
      "id" : 135749583
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sondy\/status\/687840673001635840\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/jAxH4X1u1k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYuzcpdUoAAcBi_.jpg",
      "id_str" : "687840672850681856",
      "id" : 687840672850681856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYuzcpdUoAAcBi_.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 494
      } ],
      "display_url" : "pic.twitter.com\/jAxH4X1u1k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706007964075827200",
  "text" : "RT @sondy: What is it about astronomy and academia? (Credit to [Redacted], they know who they are.) https:\/\/t.co\/jAxH4X1u1k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sondy\/status\/687840673001635840\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/jAxH4X1u1k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYuzcpdUoAAcBi_.jpg",
        "id_str" : "687840672850681856",
        "id" : 687840672850681856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYuzcpdUoAAcBi_.jpg",
        "sizes" : [ {
          "h" : 264,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 494
        } ],
        "display_url" : "pic.twitter.com\/jAxH4X1u1k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687840673001635840",
    "text" : "What is it about astronomy and academia? (Credit to [Redacted], they know who they are.) https:\/\/t.co\/jAxH4X1u1k",
    "id" : 687840673001635840,
    "created_at" : "2016-01-15 03:36:10 +0000",
    "user" : {
      "name" : "Alessondra Springmann",
      "screen_name" : "sondy",
      "protected" : false,
      "id_str" : "135749583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704066092096835585\/AAuYAywv_normal.jpg",
      "id" : 135749583,
      "verified" : false
    }
  },
  "id" : 706007964075827200,
  "created_at" : "2016-03-05 06:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705871697803681792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608367302789, 8.818735445879282 ]
  },
  "id_str" : "705879126335492097",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna oh nein :(",
  "id" : 705879126335492097,
  "in_reply_to_status_id" : 705871697803681792,
  "created_at" : "2016-03-04 22:14:32 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705869358837473280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075853513837, 8.818498706352171 ]
  },
  "id_str" : "705869930462367744",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna Mist, bin nur am 15. in der Stadt.",
  "id" : 705869930462367744,
  "in_reply_to_status_id" : 705869358837473280,
  "created_at" : "2016-03-04 21:38:00 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705868792279207936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076064267022, 8.818706158255647 ]
  },
  "id_str" : "705869078410489856",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna das w\u00FCrde ich zu gern sehen :D",
  "id" : 705869078410489856,
  "in_reply_to_status_id" : 705868792279207936,
  "created_at" : "2016-03-04 21:34:37 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705867226843385856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076674363423, 8.81869795994775 ]
  },
  "id_str" : "705867586014154752",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna ist der Papagei mit auf der Playlist gelandet? \uD83D\uDE09",
  "id" : 705867586014154752,
  "in_reply_to_status_id" : 705867226843385856,
  "created_at" : "2016-03-04 21:28:41 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705865633632804864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086595344173, 8.818675223706165 ]
  },
  "id_str" : "705865837039783936",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna ich bin Game :D",
  "id" : 705865837039783936,
  "in_reply_to_status_id" : 705865633632804864,
  "created_at" : "2016-03-04 21:21:44 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705864427552296960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089075005632, 8.818784256904742 ]
  },
  "id_str" : "705864888363646976",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna du, ich und der Papagei? \uD83D\uDE02",
  "id" : 705864888363646976,
  "in_reply_to_status_id" : 705864427552296960,
  "created_at" : "2016-03-04 21:17:58 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705864334526775298",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608131000222, 8.818646650595827 ]
  },
  "id_str" : "705864825633677312",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna drums, awesome! \uD83D\uDC96",
  "id" : 705864825633677312,
  "in_reply_to_status_id" : 705864334526775298,
  "created_at" : "2016-03-04 21:17:43 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705864212871036928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078929407887, 8.818624833445869 ]
  },
  "id_str" : "705864314062827520",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon ja, da kann man noch nachtr\u00E4glich gratulieren ;)",
  "id" : 705864314062827520,
  "in_reply_to_status_id" : 705864212871036928,
  "created_at" : "2016-03-04 21:15:41 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705863610183098369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083408576995, 8.818606124142645 ]
  },
  "id_str" : "705864100413308929",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna jetzt w\u00FCrde ich gerne mit einem davon tanzen :3",
  "id" : 705864100413308929,
  "in_reply_to_status_id" : 705863610183098369,
  "created_at" : "2016-03-04 21:14:50 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705863764894228481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081540546819, 8.81860913721102 ]
  },
  "id_str" : "705863848373460992",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon 10. Januar wieder ;)",
  "id" : 705863848373460992,
  "in_reply_to_status_id" : 705863764894228481,
  "created_at" : "2016-03-04 21:13:50 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705863153318555648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082445160453, 8.818717032156469 ]
  },
  "id_str" : "705863263238692864",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon gut erkannt ;) danke trotzdem :)",
  "id" : 705863263238692864,
  "in_reply_to_status_id" : 705863153318555648,
  "created_at" : "2016-03-04 21:11:30 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705862806294368256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076939641986, 8.818562567136162 ]
  },
  "id_str" : "705862952029650944",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon ich bin verloren, Kontext? :D",
  "id" : 705862952029650944,
  "in_reply_to_status_id" : 705862806294368256,
  "created_at" : "2016-03-04 21:10:16 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/XY2JGxhbdi",
      "expanded_url" : "http:\/\/scienceblogs.com\/notrocketscience\/2009\/04\/30\/alex-the-parrot-and-snowball-the-cockatoo-show-that-birds-ca\/",
      "display_url" : "scienceblogs.com\/notrocketscien\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "705861860076216320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079745016361, 8.818971747132915 ]
  },
  "id_str" : "705862240210186240",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna sie haben auch nachweislich den Beat im Blut ;) https:\/\/t.co\/XY2JGxhbdi",
  "id" : 705862240210186240,
  "in_reply_to_status_id" : 705861860076216320,
  "created_at" : "2016-03-04 21:07:27 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7unDB3CaFy",
      "expanded_url" : "http:\/\/m.imgur.com\/h3NXRt7?r",
      "display_url" : "m.imgur.com\/h3NXRt7?r"
    }, {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/tjkCGI97NH",
      "expanded_url" : "https:\/\/twitter.com\/SFtheWolf\/status\/705837961166753793",
      "display_url" : "twitter.com\/SFtheWolf\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085828167429, 8.818430038122564 ]
  },
  "id_str" : "705860274356658177",
  "text" : "https:\/\/t.co\/7unDB3CaFy \uD83E\uDD84 https:\/\/t.co\/tjkCGI97NH",
  "id" : 705860274356658177,
  "created_at" : "2016-03-04 20:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 15, 22 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 23, 35 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705840917484314627",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072640553451, 8.818286258223802 ]
  },
  "id_str" : "705857561422127105",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @mrgunn @Villavelius lucky you \uD83D\uDE0A",
  "id" : 705857561422127105,
  "in_reply_to_status_id" : 705840917484314627,
  "created_at" : "2016-03-04 20:48:51 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 15, 22 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 23, 35 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705832589509193728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082107514602, 8.818413321527764 ]
  },
  "id_str" : "705839948147122176",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @mrgunn @Villavelius you read too much Gould \uD83D\uDE09",
  "id" : 705839948147122176,
  "in_reply_to_status_id" : 705832589509193728,
  "created_at" : "2016-03-04 19:38:52 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/7jNYRn1RLU",
      "expanded_url" : "https:\/\/twitter.com\/mcsweeneys\/status\/705786142935756800",
      "display_url" : "twitter.com\/mcsweeneys\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098763543659, 8.818499108588775 ]
  },
  "id_str" : "705837513835941889",
  "text" : "Jonah Lehrer was just the beginning: \u00ABThere isn\u2019t even a Fecal Studies Laboratory at Poop University\u00BB https:\/\/t.co\/7jNYRn1RLU",
  "id" : 705837513835941889,
  "created_at" : "2016-03-04 19:29:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tal Yarkoni",
      "screen_name" : "talyarkoni",
      "indices" : [ 0, 11 ],
      "id_str" : "82511170",
      "id" : 82511170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705821528768688129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088083440293, 8.818641781836899 ]
  },
  "id_str" : "705826774735687680",
  "in_reply_to_user_id" : 82511170,
  "text" : "@talyarkoni \uD83D\uDC35 code, \uD83D\uDC35 eat.",
  "id" : 705826774735687680,
  "in_reply_to_status_id" : 705821528768688129,
  "created_at" : "2016-03-04 18:46:31 +0000",
  "in_reply_to_screen_name" : "talyarkoni",
  "in_reply_to_user_id_str" : "82511170",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10187516004594, 8.75293100382153 ]
  },
  "id_str" : "705817786442977280",
  "text" : "@malech immer brav die Taschent\u00FCcher wegr\u00E4umen vor dem Foto machen? :3",
  "id" : 705817786442977280,
  "created_at" : "2016-03-04 18:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/NnlZ6vxF1B",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371%2Fjournal.pone.0149431",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705817309919760389",
  "text" : "Putting dogs in the fMRI to see how they process faces \uD83D\uDC36\uD83C\uDFE5\uD83D\uDD2C https:\/\/t.co\/NnlZ6vxF1B",
  "id" : 705817309919760389,
  "created_at" : "2016-03-04 18:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705777665425481730",
  "geo" : { },
  "id_str" : "705777960725385216",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \uD83D\uDE2D\u2615\uFE0F",
  "id" : 705777960725385216,
  "in_reply_to_status_id" : 705777665425481730,
  "created_at" : "2016-03-04 15:32:33 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705777423061819392",
  "geo" : { },
  "id_str" : "705777501985972224",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s nope, vor lauter Arbeit nicht dazu gekommen m)",
  "id" : 705777501985972224,
  "in_reply_to_status_id" : 705777423061819392,
  "created_at" : "2016-03-04 15:30:43 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705777305814179841",
  "geo" : { },
  "id_str" : "705777372419776512",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich hatte heute noch nicht mal einen Kaffee! \uD83D\uDE31",
  "id" : 705777372419776512,
  "in_reply_to_status_id" : 705777305814179841,
  "created_at" : "2016-03-04 15:30:12 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705776343414341633",
  "geo" : { },
  "id_str" : "705777265855037440",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s und das trotz des mangelnden Sch\u00F6nheitsschlaf! :p",
  "id" : 705777265855037440,
  "in_reply_to_status_id" : 705776343414341633,
  "created_at" : "2016-03-04 15:29:47 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "tom delmont",
      "screen_name" : "tomodelmont",
      "indices" : [ 18, 30 ],
      "id_str" : "3391783527",
      "id" : 3391783527
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 31, 39 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705776260966969344",
  "geo" : { },
  "id_str" : "705777169742602240",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tomodelmont @fiedawn I will, had to somehow work around some troubles with the circlator first. :)",
  "id" : 705777169742602240,
  "in_reply_to_status_id" : 705776260966969344,
  "created_at" : "2016-03-04 15:29:24 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/aCKYCD1fh0",
      "expanded_url" : "https:\/\/twitter.com\/vortacist\/status\/705772444091600896",
      "display_url" : "twitter.com\/vortacist\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705776070956445697",
  "text" : "\u00ABI don\u2019t care if your manliness prevents you from fully enjoying this\u00BB \uD83D\uDC98 https:\/\/t.co\/aCKYCD1fh0",
  "id" : 705776070956445697,
  "created_at" : "2016-03-04 15:25:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "tom delmont",
      "screen_name" : "tomodelmont",
      "indices" : [ 18, 30 ],
      "id_str" : "3391783527",
      "id" : 3391783527
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 31, 39 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705773218032971776",
  "geo" : { },
  "id_str" : "705774279045029888",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tomodelmont @fiedawn currently trying to circularize those two ctgs :D",
  "id" : 705774279045029888,
  "in_reply_to_status_id" : 705773218032971776,
  "created_at" : "2016-03-04 15:17:55 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 8, 17 ],
      "id_str" : "16029156",
      "id" : 16029156
    }, {
      "name" : "tom delmont",
      "screen_name" : "tomodelmont",
      "indices" : [ 18, 30 ],
      "id_str" : "3391783527",
      "id" : 3391783527
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 31, 39 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705773218032971776",
  "geo" : { },
  "id_str" : "705774217384562688",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @merenbey @tomodelmont @fiedawn thanks, will have a look at that! Those 2 were just the ones that seem to have assembled into 1 ctg",
  "id" : 705774217384562688,
  "in_reply_to_status_id" : 705773218032971776,
  "created_at" : "2016-03-04 15:17:40 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 61, 67 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/z7wak21Il9",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/herder-an-explainer-for-linguists\/",
      "display_url" : "languageonthemove.com\/herder-an-expl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705769920529887233",
  "text" : "Herder: an explainer for linguists https:\/\/t.co\/z7wak21Il9 \/\/@lobot",
  "id" : 705769920529887233,
  "created_at" : "2016-03-04 15:00:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705752971636809728",
  "geo" : { },
  "id_str" : "705766801326673920",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn nope, not like the tardigrade genome, because I actually watched out for them ;) kidding aside: my lichens :)",
  "id" : 705766801326673920,
  "in_reply_to_status_id" : 705752971636809728,
  "created_at" : "2016-03-04 14:48:12 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/jklplNRMBz",
      "expanded_url" : "http:\/\/blog.ebemunk.com\/a-visual-look-at-2-million-chess-games\/",
      "display_url" : "blog.ebemunk.com\/a-visual-look-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705766636796715009",
  "text" : "Visualizing 2 million games of Chess https:\/\/t.co\/jklplNRMBz",
  "id" : 705766636796715009,
  "created_at" : "2016-03-04 14:47:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705706575156154368",
  "text" : "Whops, I think I accidentally assembled two complete bacterial genomes that were present in my sample as well. Funny what PacBio leads to!",
  "id" : 705706575156154368,
  "created_at" : "2016-03-04 10:48:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/JfNnxvWfJz",
      "expanded_url" : "https:\/\/twitter.com\/ACGT_blog\/status\/705550532446916608",
      "display_url" : "twitter.com\/ACGT_blog\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705689969793363968",
  "text" : "\u00ABI was disgusted with the short-read DNA sequencers\u00BB https:\/\/t.co\/JfNnxvWfJz",
  "id" : 705689969793363968,
  "created_at" : "2016-03-04 09:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10209791030747, 8.715024009212062 ]
  },
  "id_str" : "705657730229530624",
  "text" : "The more I read \u2018Command and Control\u2019, the more I wonder why stoned push button officers and plane crashes didn\u2019t lead to a nuclear war yet.",
  "id" : 705657730229530624,
  "created_at" : "2016-03-04 07:34:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    }, {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "indices" : [ 11, 21 ],
      "id_str" : "14315063",
      "id" : 14315063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705527428613935105",
  "geo" : { },
  "id_str" : "705528480549773312",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan @mjrobbins but similarly you probably have no idea what weird stuff other journals outside your field accept\/publish.",
  "id" : 705528480549773312,
  "in_reply_to_status_id" : 705527428613935105,
  "created_at" : "2016-03-03 23:01:12 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/tby0BovBQv",
      "expanded_url" : "http:\/\/www.wired.com\/2010\/11\/feeling-the-future-is-precognition-possible\/",
      "display_url" : "wired.com\/2010\/11\/feelin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "705501755770060801",
  "geo" : { },
  "id_str" : "705511852999102470",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski remember https:\/\/t.co\/tby0BovBQv ?",
  "id" : 705511852999102470,
  "in_reply_to_status_id" : 705501755770060801,
  "created_at" : "2016-03-03 21:55:08 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "PLOS ONE",
      "screen_name" : "PLOSONE",
      "indices" : [ 17, 25 ],
      "id_str" : "27596259",
      "id" : 27596259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705501111495614464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1018685901017, 8.75302254911979 ]
  },
  "id_str" : "705501667136040961",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @PLOSONE and it\u2019s not like glam journals are without those mistakes (arsenic life, tardigrades, \u2026)",
  "id" : 705501667136040961,
  "in_reply_to_status_id" : 705501111495614464,
  "created_at" : "2016-03-03 21:14:39 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "PLOS ONE",
      "screen_name" : "PLOSONE",
      "indices" : [ 17, 25 ],
      "id_str" : "27596259",
      "id" : 27596259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705501111495614464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10433742351965, 8.724014150943967 ]
  },
  "id_str" : "705501421207216130",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @PLOSONE i wouldn\u2019t say major tbh. Only people who don\u2019t work make no mistakes.",
  "id" : 705501421207216130,
  "in_reply_to_status_id" : 705501111495614464,
  "created_at" : "2016-03-03 21:13:41 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/DLnaqufbmi",
      "expanded_url" : "https:\/\/twitter.com\/ivanoransky\/status\/705498295989202944",
      "display_url" : "twitter.com\/ivanoransky\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10433750929236, 8.724061147285164 ]
  },
  "id_str" : "705500985326702592",
  "text" : "The Lord gives, and the Lord takes away. (Job 1:21) https:\/\/t.co\/DLnaqufbmi",
  "id" : 705500985326702592,
  "created_at" : "2016-03-03 21:11:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705473496013533184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09912878139833, 8.691654366466112 ]
  },
  "id_str" : "705473646643564544",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks yes, walking and taking trains instead.",
  "id" : 705473646643564544,
  "in_reply_to_status_id" : 705473496013533184,
  "created_at" : "2016-03-03 19:23:19 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705462392600322050",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09909261964965, 8.691844636754206 ]
  },
  "id_str" : "705473429856776193",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower great, if you need any help with that let me know.",
  "id" : 705473429856776193,
  "in_reply_to_status_id" : 705462392600322050,
  "created_at" : "2016-03-03 19:22:27 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705448208256913409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10046001207944, 8.691966000763028 ]
  },
  "id_str" : "705461852726280192",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower yes, your strength is the brand, not the software :)",
  "id" : 705461852726280192,
  "in_reply_to_status_id" : 705448208256913409,
  "created_at" : "2016-03-03 18:36:27 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eyebeam",
      "screen_name" : "eyebeamnyc",
      "indices" : [ 3, 14 ],
      "id_str" : "15906950",
      "id" : 15906950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705460539070222336",
  "text" : "RT @eyebeamnyc: Apply for the Ada Lovelace Fellowship to attend the Open Hardware Summit for women and poc! Chaired by @whereaddie https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/yQlUf4sxqw",
        "expanded_url" : "http:\/\/bit.ly\/1LBH0md",
        "display_url" : "bit.ly\/1LBH0md"
      } ]
    },
    "geo" : { },
    "id_str" : "705442496617308160",
    "text" : "Apply for the Ada Lovelace Fellowship to attend the Open Hardware Summit for women and poc! Chaired by @whereaddie https:\/\/t.co\/yQlUf4sxqw",
    "id" : 705442496617308160,
    "created_at" : "2016-03-03 17:19:32 +0000",
    "user" : {
      "name" : "Eyebeam",
      "screen_name" : "eyebeamnyc",
      "protected" : false,
      "id_str" : "15906950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699733288823451648\/e6D2PLrD_normal.jpg",
      "id" : 15906950,
      "verified" : false
    }
  },
  "id" : 705460539070222336,
  "created_at" : "2016-03-03 18:31:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11034629100531, 8.69164062919768 ]
  },
  "id_str" : "705455852535291905",
  "text" : "No good deed goes unpunished: \uD83D\uDE97\uD83D\uDD0B\u274C",
  "id" : 705455852535291905,
  "created_at" : "2016-03-03 18:12:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705445289411350529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16762205329307, 8.627424804425601 ]
  },
  "id_str" : "705445673630633984",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower uh, not really! But as many as I manage, okay? :)",
  "id" : 705445673630633984,
  "in_reply_to_status_id" : 705445289411350529,
  "created_at" : "2016-03-03 17:32:09 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705443777675173889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233970266408, 8.627608844790856 ]
  },
  "id_str" : "705444685863641088",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower that\u2019s great to hear!",
  "id" : 705444685863641088,
  "in_reply_to_status_id" : 705443777675173889,
  "created_at" : "2016-03-03 17:28:14 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/H290XSZrey",
      "expanded_url" : "https:\/\/github.com\/thewinnower\/terrier\/pull\/1",
      "display_url" : "github.com\/thewinnower\/te\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "705170080913608704",
  "geo" : { },
  "id_str" : "705443242502963200",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower and here\u2019s the promised pull request https:\/\/t.co\/H290XSZrey :)",
  "id" : 705443242502963200,
  "in_reply_to_status_id" : 705170080913608704,
  "created_at" : "2016-03-03 17:22:30 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1DRjlZ13AO",
      "expanded_url" : "https:\/\/twitter.com\/hatr\/status\/705427598504030208",
      "display_url" : "twitter.com\/hatr\/status\/70\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705438234273292289",
  "text" : "\u00AByou can\u2019t change the Twitter \u201Cverified\u201D blue check mark to a black R.I.P.\u00BB https:\/\/t.co\/1DRjlZ13AO",
  "id" : 705438234273292289,
  "created_at" : "2016-03-03 17:02:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 3, 15 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 52, 68 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/OARmzPYd7E",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/3536-the-future-of-scholarly-commons",
      "display_url" : "thewinnower.com\/papers\/3536-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705420290961117184",
  "text" : "RT @theWinnower: The Future of Scholarly Commons by @gedankenstuecke https:\/\/t.co\/OARmzPYd7E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 35, 51 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/OARmzPYd7E",
        "expanded_url" : "https:\/\/thewinnower.com\/papers\/3536-the-future-of-scholarly-commons",
        "display_url" : "thewinnower.com\/papers\/3536-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705392029711392768",
    "text" : "The Future of Scholarly Commons by @gedankenstuecke https:\/\/t.co\/OARmzPYd7E",
    "id" : 705392029711392768,
    "created_at" : "2016-03-03 13:59:00 +0000",
    "user" : {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "protected" : false,
      "id_str" : "748018813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459467186734514177\/xIXadyix_normal.jpeg",
      "id" : 748018813,
      "verified" : false
    }
  },
  "id" : 705420290961117184,
  "created_at" : "2016-03-03 15:51:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/zP4U9Qi6vy",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/705394484935262208",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705417773229465600",
  "text" : "I came for the puppy pic, I stayed for the DOI lookup. https:\/\/t.co\/zP4U9Qi6vy",
  "id" : 705417773229465600,
  "created_at" : "2016-03-03 15:41:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/17TH3weK3F",
      "expanded_url" : "https:\/\/twitter.com\/replicatedtypo\/status\/705364167449038848",
      "display_url" : "twitter.com\/replicatedtypo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705365480937275392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/17TH3weK3F",
  "id" : 705365480937275392,
  "created_at" : "2016-03-03 12:13:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/a7ZI8shbt2",
      "expanded_url" : "http:\/\/phys.org\/news\/2016-03-explores-prehistoric-relationship-humans-dogs.html",
      "display_url" : "phys.org\/news\/2016-03-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705361753425776640",
  "text" : "exploring the close prehistoric relationship between humans and dogs https:\/\/t.co\/a7ZI8shbt2",
  "id" : 705361753425776640,
  "created_at" : "2016-03-03 11:58:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705348594740633600",
  "geo" : { },
  "id_str" : "705348846977683456",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc only if you add a minION to the mix.",
  "id" : 705348846977683456,
  "in_reply_to_status_id" : 705348594740633600,
  "created_at" : "2016-03-03 11:07:24 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lowest Pair",
      "screen_name" : "TheLowestPair",
      "indices" : [ 15, 29 ],
      "id_str" : "1556747803",
      "id" : 1556747803
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 60, 66 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/JfR4B5BGSk",
      "expanded_url" : "http:\/\/www.popmatters.com\/post\/the-lowest-pair-keeweenaw-flower-when-they-dance-the-mountains-shake-premie\/",
      "display_url" : "popmatters.com\/post\/the-lowes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705346447731003392",
  "text" : "New songs from @TheLowestPair \uD83D\uDE0D\uD83D\uDC83\uD83D\uDC96 https:\/\/t.co\/JfR4B5BGSk \/\/@lobot",
  "id" : 705346447731003392,
  "created_at" : "2016-03-03 10:57:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/xHcKAJxzDm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=oijIV8XJ6O4",
      "display_url" : "youtube.com\/watch?v=oijIV8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705335050892677120",
  "text" : "Comedians Sitting on Vibrators Getting Coffee https:\/\/t.co\/xHcKAJxzDm",
  "id" : 705335050892677120,
  "created_at" : "2016-03-03 10:12:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel H\u00FCrlimann",
      "screen_name" : "dhuerlimann",
      "indices" : [ 3, 15 ],
      "id_str" : "196077348",
      "id" : 196077348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vchwTBU4XT",
      "expanded_url" : "http:\/\/goo.gl\/GDyG26",
      "display_url" : "goo.gl\/GDyG26"
    } ]
  },
  "geo" : { },
  "id_str" : "705333659927191552",
  "text" : "RT @dhuerlimann: How would we re-build Academia (if at all) and what would happen to the commons? #FutureCommons -- https:\/\/t.co\/vchwTBU4XT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureCommons",
        "indices" : [ 81, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/vchwTBU4XT",
        "expanded_url" : "http:\/\/goo.gl\/GDyG26",
        "display_url" : "goo.gl\/GDyG26"
      } ]
    },
    "geo" : { },
    "id_str" : "705129568076746754",
    "text" : "How would we re-build Academia (if at all) and what would happen to the commons? #FutureCommons -- https:\/\/t.co\/vchwTBU4XT",
    "id" : 705129568076746754,
    "created_at" : "2016-03-02 20:36:04 +0000",
    "user" : {
      "name" : "D\u24D0niel H\u00FCrlimann",
      "screen_name" : "dhuerlimann",
      "protected" : false,
      "id_str" : "196077348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1291206308\/dh_bw_normal.jpg",
      "id" : 196077348,
      "verified" : false
    }
  },
  "id" : 705333659927191552,
  "created_at" : "2016-03-03 10:07:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/rxZTtHhQ3R",
      "expanded_url" : "http:\/\/www.gemaker.com.au\/insights\/why-i-left-research%E2%80%94and-what-would-have-made-me-and-other-women-stay",
      "display_url" : "gemaker.com.au\/insights\/why-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705331775883575296",
  "text" : "\u00ABWhy I left research\u2014and what would have made me and other women stay\u00BB https:\/\/t.co\/rxZTtHhQ3R",
  "id" : 705331775883575296,
  "created_at" : "2016-03-03 09:59:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/9htry3F6p2",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4037",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705319912718397441",
  "text" : "Yep, that\u2019s how Paleoanthropology works https:\/\/t.co\/9htry3F6p2",
  "id" : 705319912718397441,
  "created_at" : "2016-03-03 09:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Hoerth",
      "screen_name" : "downtohoerth",
      "indices" : [ 3, 16 ],
      "id_str" : "2671556916",
      "id" : 2671556916
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 125, 132 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VR",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/YBBIfMGXid",
      "expanded_url" : "http:\/\/bit.ly\/1QmCiYL",
      "display_url" : "bit.ly\/1QmCiYL"
    } ]
  },
  "geo" : { },
  "id_str" : "705198782980472832",
  "text" : "RT @downtohoerth: I just published: \"I love #VR but hundreds of thousands of people think I hate it\" https:\/\/t.co\/YBBIfMGXid @Medium https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 107, 114 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/downtohoerth\/status\/705094721685704704\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/azimz1qU7q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccj_6bUUkAA2TOJ.jpg",
        "id_str" : "705094720913969152",
        "id" : 705094720913969152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccj_6bUUkAA2TOJ.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 1272
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 1272
        } ],
        "display_url" : "pic.twitter.com\/azimz1qU7q"
      } ],
      "hashtags" : [ {
        "text" : "VR",
        "indices" : [ 26, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/YBBIfMGXid",
        "expanded_url" : "http:\/\/bit.ly\/1QmCiYL",
        "display_url" : "bit.ly\/1QmCiYL"
      } ]
    },
    "geo" : { },
    "id_str" : "705094721685704704",
    "text" : "I just published: \"I love #VR but hundreds of thousands of people think I hate it\" https:\/\/t.co\/YBBIfMGXid @Medium https:\/\/t.co\/azimz1qU7q",
    "id" : 705094721685704704,
    "created_at" : "2016-03-02 18:17:36 +0000",
    "user" : {
      "name" : "Eva Hoerth",
      "screen_name" : "downtohoerth",
      "protected" : false,
      "id_str" : "2671556916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932479333473513472\/BMPl7tVu_normal.jpg",
      "id" : 2671556916,
      "verified" : false
    }
  },
  "id" : 705198782980472832,
  "created_at" : "2016-03-03 01:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705192804687937536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076906986121, 8.818676757565461 ]
  },
  "id_str" : "705198133266030593",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot \uD83D\uDC4D",
  "id" : 705198133266030593,
  "in_reply_to_status_id" : 705192804687937536,
  "created_at" : "2016-03-03 01:08:31 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705171936540827648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078183954273, 8.818369366675004 ]
  },
  "id_str" : "705172417799458816",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDC96",
  "id" : 705172417799458816,
  "in_reply_to_status_id" : 705171936540827648,
  "created_at" : "2016-03-02 23:26:20 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705170080913608704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078620002145, 8.81862813599076 ]
  },
  "id_str" : "705170222978830336",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower i will, and leave pull requests if anything comes up :)",
  "id" : 705170222978830336,
  "in_reply_to_status_id" : 705170080913608704,
  "created_at" : "2016-03-02 23:17:37 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705164786124910596",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078620002145, 8.81862813599076 ]
  },
  "id_str" : "705169901795844096",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower thanks, that's just what I was looking for today actually!",
  "id" : 705169901795844096,
  "in_reply_to_status_id" : 705164786124910596,
  "created_at" : "2016-03-02 23:16:20 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/705149393914236928\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/6PoX1EU1G5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CckxozjWIAIOjSd.jpg",
      "id_str" : "705149393763180546",
      "id" : 705149393763180546,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CckxozjWIAIOjSd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 261
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 261
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 261
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 261
      } ],
      "display_url" : "pic.twitter.com\/6PoX1EU1G5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Wh6dI4Y9cC",
      "expanded_url" : "http:\/\/amzn.to\/1LyJiTp",
      "display_url" : "amzn.to\/1LyJiTp"
    } ]
  },
  "geo" : { },
  "id_str" : "705149393914236928",
  "text" : "Nuclear safety\u2026 https:\/\/t.co\/Wh6dI4Y9cC https:\/\/t.co\/6PoX1EU1G5",
  "id" : 705149393914236928,
  "created_at" : "2016-03-02 21:54:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "indices" : [ 3, 16 ],
      "id_str" : "151257881",
      "id" : 151257881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705137874669314048",
  "text" : "RT @TRyanGregory: Someone at PLOS ONE dropped the ball. Which is weird because the Creator made hands really good at grabbing stuff. \n\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/65diqhhGKd",
        "expanded_url" : "http:\/\/goo.gl\/0yWl1x",
        "display_url" : "goo.gl\/0yWl1x"
      } ]
    },
    "geo" : { },
    "id_str" : "705123752489545728",
    "text" : "Someone at PLOS ONE dropped the ball. Which is weird because the Creator made hands really good at grabbing stuff. \n\nhttps:\/\/t.co\/65diqhhGKd",
    "id" : 705123752489545728,
    "created_at" : "2016-03-02 20:12:57 +0000",
    "user" : {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "protected" : false,
      "id_str" : "151257881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/954599622\/TRGDNA_normal.jpg",
      "id" : 151257881,
      "verified" : false
    }
  },
  "id" : 705137874669314048,
  "created_at" : "2016-03-02 21:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Bray",
      "screen_name" : "yarbsalocin",
      "indices" : [ 3, 15 ],
      "id_str" : "2164225381",
      "id" : 2164225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705096568802779136",
  "text" : "RT @yarbsalocin: Pointing to successful PI\/student relationships is like listening to people talk about the great time they had playing Rus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704844427458523136",
    "text" : "Pointing to successful PI\/student relationships is like listening to people talk about the great time they had playing Russian roulette.",
    "id" : 704844427458523136,
    "created_at" : "2016-03-02 01:43:01 +0000",
    "user" : {
      "name" : "Nicolas Bray",
      "screen_name" : "yarbsalocin",
      "protected" : false,
      "id_str" : "2164225381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000668148975\/29b568d3637e7b81340338d9ed331ab1_normal.jpeg",
      "id" : 2164225381,
      "verified" : false
    }
  },
  "id" : 705096568802779136,
  "created_at" : "2016-03-02 18:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "indices" : [ 3, 17 ],
      "id_str" : "14852199",
      "id" : 14852199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705049608901304321",
  "text" : "RT @christinelove: \u201CWhy do people like Markov-generated text?\u201D you ask. \n\nActually, Markov was the mathematician; what generates the text i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704531262061412352",
    "text" : "\u201CWhy do people like Markov-generated text?\u201D you ask. \n\nActually, Markov was the mathematician; what generates the text is Markov\u2019s monster",
    "id" : 704531262061412352,
    "created_at" : "2016-03-01 04:58:37 +0000",
    "user" : {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "protected" : false,
      "id_str" : "14852199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929084299172704256\/L1tPIyKz_normal.jpg",
      "id" : 14852199,
      "verified" : false
    }
  },
  "id" : 705049608901304321,
  "created_at" : "2016-03-02 15:18:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/9lOXBbCmAZ",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scholarly-commons\/",
      "display_url" : "ruleofthirds.de\/scholarly-comm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.179955, 8.612366 ]
  },
  "id_str" : "705045503759745024",
  "text" : "I wrote a small blogpost on how much fun I had at #futurecommons. https:\/\/t.co\/9lOXBbCmAZ",
  "id" : 705045503759745024,
  "created_at" : "2016-03-02 15:02:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/k0l4bQtqZo",
      "expanded_url" : "https:\/\/s.yimg.com\/ny\/api\/res\/1.2\/uh2msf_q4M1s7LxTpV7LSg--\/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9NTAwO2g9MjEy\/http:\/\/l.yimg.com\/cd\/diminuendo\/1.0\/original\/2d21f2c5898e7f53ac91ff0612071535ef1be9a5.gif",
      "display_url" : "s.yimg.com\/ny\/api\/res\/1.2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "704984337155018752",
  "geo" : { },
  "id_str" : "705038077161562112",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/k0l4bQtqZo",
  "id" : 705038077161562112,
  "in_reply_to_status_id" : 704984337155018752,
  "created_at" : "2016-03-02 14:32:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/NyWN0Fyyav",
      "expanded_url" : "http:\/\/www.cutecatgifs.com\/wp-content\/uploads\/2013\/08\/stealth.gif",
      "display_url" : "cutecatgifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704997381100666880",
  "text" : "sneaking in a documentation sprint https:\/\/t.co\/NyWN0Fyyav",
  "id" : 704997381100666880,
  "created_at" : "2016-03-02 11:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ivltW8nbQY",
      "expanded_url" : "http:\/\/media0.faz.net\/ppmedia\/aktuell\/rhein-main\/1749369135\/1.4079556\/article_multimedia_overview\/gross-wie-nie-der-frankfurter.jpg",
      "display_url" : "media0.faz.net\/ppmedia\/aktuel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "704967207969755136",
  "geo" : { },
  "id_str" : "704968275759919104",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente \u201Edarf ich dir mal meinen unglaublich langen Wahlzettel zeigen?\u201C https:\/\/t.co\/ivltW8nbQY",
  "id" : 704968275759919104,
  "in_reply_to_status_id" : 704967207969755136,
  "created_at" : "2016-03-02 09:55:09 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah m",
      "screen_name" : "sazza_jay",
      "indices" : [ 3, 13 ],
      "id_str" : "43522569",
      "id" : 43522569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vxTpNGM8Hw",
      "expanded_url" : "https:\/\/twitter.com\/anti_poon\/status\/609623257545728001",
      "display_url" : "twitter.com\/anti_poon\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704967105796509696",
  "text" : "RT @sazza_jay: Ada Lovelace did not invent computer programming so you could write sexist trash on the Internet. https:\/\/t.co\/vxTpNGM8Hw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/vxTpNGM8Hw",
        "expanded_url" : "https:\/\/twitter.com\/anti_poon\/status\/609623257545728001",
        "display_url" : "twitter.com\/anti_poon\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704729988222820354",
    "text" : "Ada Lovelace did not invent computer programming so you could write sexist trash on the Internet. https:\/\/t.co\/vxTpNGM8Hw",
    "id" : 704729988222820354,
    "created_at" : "2016-03-01 18:08:17 +0000",
    "user" : {
      "name" : "sarah claus",
      "screen_name" : "sazza_jay",
      "protected" : false,
      "id_str" : "43522569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/886511496381030400\/uJQJTL0w_normal.jpg",
      "id" : 43522569,
      "verified" : false
    }
  },
  "id" : 704967105796509696,
  "created_at" : "2016-03-02 09:50:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/CO6uUNTxSi",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0149852",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704964865023209472",
  "text" : "\u00ABHow to Rank Journals\u00BB Maybe we should discuss \u00ABWhy Rank Journals\u00BB or even \u00ABWhy Journals\u00BB first? https:\/\/t.co\/CO6uUNTxSi",
  "id" : 704964865023209472,
  "created_at" : "2016-03-02 09:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 73, 79 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/2IV9l9qYeF",
      "expanded_url" : "https:\/\/www.kindara.com\/home",
      "display_url" : "kindara.com\/home"
    } ]
  },
  "in_reply_to_status_id_str" : "704960893923303424",
  "geo" : { },
  "id_str" : "704963959334551553",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen btw, speaking of reproduction, check https:\/\/t.co\/2IV9l9qYeF @lobot",
  "id" : 704963959334551553,
  "in_reply_to_status_id" : 704960893923303424,
  "created_at" : "2016-03-02 09:38:00 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704959958496968704",
  "geo" : { },
  "id_str" : "704960564968235008",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \uD83D\uDE0D! Though that part is a bit different from the Pandas \uD83D\uDE1C",
  "id" : 704960564968235008,
  "in_reply_to_status_id" : 704959958496968704,
  "created_at" : "2016-03-02 09:24:30 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/nfhmxePfsn",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1860",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704959561086726144",
  "text" : "i\u2019m 80% \uD83D\uDC3C https:\/\/t.co\/nfhmxePfsn",
  "id" : 704959561086726144,
  "created_at" : "2016-03-02 09:20:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "ISMB2016",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704957609846173697",
  "text" : "RT @OBF_BOSC: #BOSC2016: Call for Abstracts for the 17th Annual Bioinformatics Open Source Conference, a\u00A0SIG meeting at #ISMB2016 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ISMB2016",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1MNuGGskKJ",
        "expanded_url" : "https:\/\/news.obf.io\/2016\/03\/01\/bosc-2016-call-for-abstracts\/",
        "display_url" : "news.obf.io\/2016\/03\/01\/bos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704724497610489857",
    "text" : "#BOSC2016: Call for Abstracts for the 17th Annual Bioinformatics Open Source Conference, a\u00A0SIG meeting at #ISMB2016 https:\/\/t.co\/1MNuGGskKJ",
    "id" : 704724497610489857,
    "created_at" : "2016-03-01 17:46:28 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 704957609846173697,
  "created_at" : "2016-03-02 09:12:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/hEEKcXtBKq",
      "expanded_url" : "http:\/\/cdn1.theodysseyonline.com\/files\/2015\/06\/08\/635693684258228149467605400_parks%20and%20rec%20gif%206.gif",
      "display_url" : "cdn1.theodysseyonline.com\/files\/2015\/06\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704953740948803584",
  "text" : "when collecting receipts in order to get reimbursed makes me feel like i\u2019m a responsible adult. https:\/\/t.co\/hEEKcXtBKq",
  "id" : 704953740948803584,
  "created_at" : "2016-03-02 08:57:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs \"ban nazis\" \uD83D\uDC99\uD83D\uDC9C\uD83D\uDC96\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/GUk04S4WIY",
      "expanded_url" : "https:\/\/twitter.com\/writersofcolor\/status\/704475079145603072",
      "display_url" : "twitter.com\/writersofcolor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704947175852273665",
  "text" : "RT @izs: \"The employer might not be racist, by the system still is\" https:\/\/t.co\/GUk04S4WIY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/GUk04S4WIY",
        "expanded_url" : "https:\/\/twitter.com\/writersofcolor\/status\/704475079145603072",
        "display_url" : "twitter.com\/writersofcolor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704721970508619776",
    "text" : "\"The employer might not be racist, by the system still is\" https:\/\/t.co\/GUk04S4WIY",
    "id" : 704721970508619776,
    "created_at" : "2016-03-01 17:36:25 +0000",
    "user" : {
      "name" : "isaacs \"ban nazis\" \uD83D\uDC99\uD83D\uDC9C\uD83D\uDC96\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917536371085950976\/MIuNwAAR_normal.png",
      "id" : 8038312,
      "verified" : true
    }
  },
  "id" : 704947175852273665,
  "created_at" : "2016-03-02 08:31:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mode",
      "screen_name" : "ModeAnalytics",
      "indices" : [ 3, 17 ],
      "id_str" : "1650684756",
      "id" : 1650684756
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 51, 67 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ModeAnalytics\/status\/704720432881147905\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/s0nl0O3BT3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccerf_LWwAAsXOa.jpg",
      "id_str" : "704720432730128384",
      "id" : 704720432730128384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccerf_LWwAAsXOa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/s0nl0O3BT3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/DZ3moPGVY9",
      "expanded_url" : "http:\/\/bit.ly\/1Ruae5U",
      "display_url" : "bit.ly\/1Ruae5U"
    } ]
  },
  "geo" : { },
  "id_str" : "704720623692595200",
  "text" : "RT @ModeAnalytics: Python punctuation, analyzed by @gedankenstuecke https:\/\/t.co\/DZ3moPGVY9 https:\/\/t.co\/s0nl0O3BT3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 32, 48 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ModeAnalytics\/status\/704720432881147905\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/s0nl0O3BT3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccerf_LWwAAsXOa.jpg",
        "id_str" : "704720432730128384",
        "id" : 704720432730128384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccerf_LWwAAsXOa.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/s0nl0O3BT3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/DZ3moPGVY9",
        "expanded_url" : "http:\/\/bit.ly\/1Ruae5U",
        "display_url" : "bit.ly\/1Ruae5U"
      } ]
    },
    "geo" : { },
    "id_str" : "704720432881147905",
    "text" : "Python punctuation, analyzed by @gedankenstuecke https:\/\/t.co\/DZ3moPGVY9 https:\/\/t.co\/s0nl0O3BT3",
    "id" : 704720432881147905,
    "created_at" : "2016-03-01 17:30:18 +0000",
    "user" : {
      "name" : "Mode",
      "screen_name" : "ModeAnalytics",
      "protected" : false,
      "id_str" : "1650684756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634158940364783616\/YuFKY6Wz_normal.png",
      "id" : 1650684756,
      "verified" : false
    }
  },
  "id" : 704720623692595200,
  "created_at" : "2016-03-01 17:31:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 3, 12 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704712435035406338",
  "text" : "RT @obf_news: Want to attend open source bioinformatics event, but cost is obstacle? Announcing the OBF Travel Fellowship Program: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/deTBI2rGWG",
        "expanded_url" : "https:\/\/wp.me\/p7fHjD-ns",
        "display_url" : "wp.me\/p7fHjD-ns"
      } ]
    },
    "geo" : { },
    "id_str" : "704696927321894912",
    "text" : "Want to attend open source bioinformatics event, but cost is obstacle? Announcing the OBF Travel Fellowship Program: https:\/\/t.co\/deTBI2rGWG",
    "id" : 704696927321894912,
    "created_at" : "2016-03-01 15:56:54 +0000",
    "user" : {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "protected" : false,
      "id_str" : "20624794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77404934\/OBF_logo_normal.png",
      "id" : 20624794,
      "verified" : false
    }
  },
  "id" : 704712435035406338,
  "created_at" : "2016-03-01 16:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704711145937100800",
  "geo" : { },
  "id_str" : "704711307216461824",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai I did a similar thing, just excluding some of the worst offenders.",
  "id" : 704711307216461824,
  "in_reply_to_status_id" : 704711145937100800,
  "created_at" : "2016-03-01 16:54:03 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704688474171899905",
  "geo" : { },
  "id_str" : "704710412131045376",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai did the same thing once, for a 10 day intensive course m(",
  "id" : 704710412131045376,
  "in_reply_to_status_id" : 704688474171899905,
  "created_at" : "2016-03-01 16:50:29 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 77, 93 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/704706240056848384\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/umbUs7cMfR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cceell6WwAABNZg.jpg",
      "id_str" : "704706235375992832",
      "id" : 704706235375992832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cceell6WwAABNZg.jpg",
      "sizes" : [ {
        "h" : 761,
        "resize" : "fit",
        "w" : 1142
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1142
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1142
      } ],
      "display_url" : "pic.twitter.com\/umbUs7cMfR"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704706240056848384",
  "text" : "Doing my \u201Eyay, something like democracy\u201C-face at #FutureCommons. Photo CC-BY @RadicevSlobodan https:\/\/t.co\/umbUs7cMfR",
  "id" : 704706240056848384,
  "created_at" : "2016-03-01 16:33:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704665191531741185",
  "geo" : { },
  "id_str" : "704666126622564356",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman sure, would love that too! :)",
  "id" : 704666126622564356,
  "in_reply_to_status_id" : 704665191531741185,
  "created_at" : "2016-03-01 13:54:31 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 26, 38 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "DiversifyEEB",
      "screen_name" : "DiversifyEEB",
      "indices" : [ 39, 52 ],
      "id_str" : "702945893398487040",
      "id" : 702945893398487040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704646407135883264",
  "geo" : { },
  "id_str" : "704646683154579456",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @NazeefaFatima @froggleston @DiversifyEEB \uD83D\uDC4D\u263A\uFE0F",
  "id" : 704646683154579456,
  "in_reply_to_status_id" : 704646407135883264,
  "created_at" : "2016-03-01 12:37:15 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 26, 38 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "DiversifyEEB",
      "screen_name" : "DiversifyEEB",
      "indices" : [ 39, 52 ],
      "id_str" : "702945893398487040",
      "id" : 702945893398487040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704646162473721856",
  "geo" : { },
  "id_str" : "704646226243883008",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @NazeefaFatima @froggleston @DiversifyEEB great, looking forward to see it :)",
  "id" : 704646226243883008,
  "in_reply_to_status_id" : 704646162473721856,
  "created_at" : "2016-03-01 12:35:26 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 26, 38 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "DiversifyEEB",
      "screen_name" : "DiversifyEEB",
      "indices" : [ 39, 52 ],
      "id_str" : "702945893398487040",
      "id" : 702945893398487040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704641077295321088",
  "geo" : { },
  "id_str" : "704645969070133248",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @NazeefaFatima @froggleston @DiversifyEEB any way one can contribute already? :)",
  "id" : 704645969070133248,
  "in_reply_to_status_id" : 704641077295321088,
  "created_at" : "2016-03-01 12:34:25 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 15, 27 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "DiversifyEEB",
      "screen_name" : "DiversifyEEB",
      "indices" : [ 28, 41 ],
      "id_str" : "702945893398487040",
      "id" : 702945893398487040
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 62, 72 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/nZK5N36Bdw",
      "expanded_url" : "https:\/\/github.com\/KirstieJane\/STEMMRoleModels",
      "display_url" : "github.com\/KirstieJane\/ST\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "704638978880892928",
  "geo" : { },
  "id_str" : "704640384719298560",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @froggleston @DiversifyEEB Have a look at what @kirstie_j is doing here: https:\/\/t.co\/nZK5N36Bdw \u263A\uFE0F",
  "id" : 704640384719298560,
  "in_reply_to_status_id" : 704638978880892928,
  "created_at" : "2016-03-01 12:12:13 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/wOWZtEagxC",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Kardashian_Index",
      "display_url" : "en.wikipedia.org\/wiki\/Kardashia\u2026"
    }, {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/DClbYkW4dW",
      "expanded_url" : "https:\/\/twitter.com\/ewanbirney\/status\/704623347422896128",
      "display_url" : "twitter.com\/ewanbirney\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704638693785661440",
  "text" : "The K-Index https:\/\/t.co\/wOWZtEagxC https:\/\/t.co\/DClbYkW4dW",
  "id" : 704638693785661440,
  "created_at" : "2016-03-01 12:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/flb5RZVTWV",
      "expanded_url" : "https:\/\/twitter.com\/FastCompany\/status\/704242473778941954",
      "display_url" : "twitter.com\/FastCompany\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704638146076676096",
  "text" : "Not yet my kind of Vibrams, but an interesting idea for the busy traveller. https:\/\/t.co\/flb5RZVTWV",
  "id" : 704638146076676096,
  "created_at" : "2016-03-01 12:03:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Simon Gladman",
      "screen_name" : "SimonGladman1",
      "indices" : [ 16, 30 ],
      "id_str" : "1339225556",
      "id" : 1339225556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704616248512901120",
  "geo" : { },
  "id_str" : "704618228560105472",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @SimonGladman1 or myself for not addressing this in my PRs \u263A\uFE0F",
  "id" : 704618228560105472,
  "in_reply_to_status_id" : 704616248512901120,
  "created_at" : "2016-03-01 10:44:11 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 9, 17 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704610143640686592",
  "geo" : { },
  "id_str" : "704617854520442880",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @PhdGeek yes, especially as in so many cases doing the documentation is work done in vain as it stays 1-off :(",
  "id" : 704617854520442880,
  "in_reply_to_status_id" : 704610143640686592,
  "created_at" : "2016-03-01 10:42:42 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704614168767299584",
  "geo" : { },
  "id_str" : "704615970954997760",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann could also be the VelvetOptimiser \uD83D\uDE1C *scnr*",
  "id" : 704615970954997760,
  "in_reply_to_status_id" : 704614168767299584,
  "created_at" : "2016-03-01 10:35:13 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 9, 17 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704606064835207168",
  "geo" : { },
  "id_str" : "704606384143405056",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @PhdGeek for me it depends. There are the one-off scripts that don\u2019t have any and become useful again years later.",
  "id" : 704606384143405056,
  "in_reply_to_status_id" : 704606064835207168,
  "created_at" : "2016-03-01 09:57:07 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704605003877638144",
  "geo" : { },
  "id_str" : "704605285315428352",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek the only thing worse is trying to remember how to use the software you wrote yourself a couple of years back ;)",
  "id" : 704605285315428352,
  "in_reply_to_status_id" : 704605003877638144,
  "created_at" : "2016-03-01 09:52:45 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/NHQnhc3d6G",
      "expanded_url" : "https:\/\/twitter.com\/BongaDlulane\/status\/704557321893093376",
      "display_url" : "twitter.com\/BongaDlulane\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704604914752884736",
  "text" : "RT @bella_velo: The challenges of navigating spaces as a women. Great article  https:\/\/t.co\/NHQnhc3d6G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/NHQnhc3d6G",
        "expanded_url" : "https:\/\/twitter.com\/BongaDlulane\/status\/704557321893093376",
        "display_url" : "twitter.com\/BongaDlulane\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704604113854701568",
    "text" : "The challenges of navigating spaces as a women. Great article  https:\/\/t.co\/NHQnhc3d6G",
    "id" : 704604113854701568,
    "created_at" : "2016-03-01 09:48:06 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 704604914752884736,
  "created_at" : "2016-03-01 09:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/SLzA9wHa5J",
      "expanded_url" : "http:\/\/unix.stackexchange.com\/a\/38960",
      "display_url" : "unix.stackexchange.com\/a\/38960"
    } ]
  },
  "in_reply_to_status_id_str" : "704592429169639424",
  "geo" : { },
  "id_str" : "704593071611256832",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler c.f. https:\/\/t.co\/SLzA9wHa5J \uD83D\uDE02",
  "id" : 704593071611256832,
  "in_reply_to_status_id" : 704592429169639424,
  "created_at" : "2016-03-01 09:04:13 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704592429169639424",
  "geo" : { },
  "id_str" : "704592724805230592",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler won\u2019t work, you can\u2019t expend the wild card because the list would be too long ;)",
  "id" : 704592724805230592,
  "in_reply_to_status_id" : 704592429169639424,
  "created_at" : "2016-03-01 09:02:50 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Oeu0oy4HGs",
      "expanded_url" : "https:\/\/45.media.tumblr.com\/tumblr_m2e08b9E8m1qkqozso1_500.gif",
      "display_url" : "45.media.tumblr.com\/tumblr_m2e08b9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704590106712268800",
  "text" : "when your scripts accidentally write 18 million files all over the place. https:\/\/t.co\/Oeu0oy4HGs",
  "id" : 704590106712268800,
  "created_at" : "2016-03-01 08:52:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704572566913085441",
  "geo" : { },
  "id_str" : "704578607885230080",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl i thought recipes as such aren\u2019t copyrightable?",
  "id" : 704578607885230080,
  "in_reply_to_status_id" : 704572566913085441,
  "created_at" : "2016-03-01 08:06:45 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]