Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Farr",
      "screen_name" : "Nickf4rr",
      "indices" : [ 0, 9 ],
      "id_str" : "11502562",
      "id" : 11502562
    }, {
      "name" : "Jella",
      "screen_name" : "Nienor_",
      "indices" : [ 10, 18 ],
      "id_str" : "17461946",
      "id" : 17461946
    }, {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 19, 24 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561313064306229248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066606528502, 8.759871895666892 ]
  },
  "id_str" : "561313912822722560",
  "in_reply_to_user_id" : 11502562,
  "text" : "@Nickf4rr @Nienor_ @towo @lnwdr I\u2019ll blame a paper deadline for my sub-par outcome :D",
  "id" : 561313912822722560,
  "in_reply_to_status_id" : 561313064306229248,
  "created_at" : "2015-01-31 00:04:00 +0000",
  "in_reply_to_screen_name" : "Nickf4rr",
  "in_reply_to_user_id_str" : "11502562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561196269503541249",
  "geo" : { },
  "id_str" : "561197094216949762",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju of course, what else is there?",
  "id" : 561197094216949762,
  "in_reply_to_status_id" : 561196269503541249,
  "created_at" : "2015-01-30 16:19:48 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "561194536719101952",
  "geo" : { },
  "id_str" : "561195092808323072",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju soon I\u2019ll have a PhD in data science\/overfitting!",
  "id" : 561195092808323072,
  "in_reply_to_status_id" : 561194536719101952,
  "created_at" : "2015-01-30 16:11:51 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/561193697703104512\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Y2jUWp4IbO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8nCsUXIgAEpeiO.png",
      "id_str" : "561193695220105217",
      "id" : 561193695220105217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8nCsUXIgAEpeiO.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1292,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 757,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1292,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Y2jUWp4IbO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561193697703104512",
  "text" : "Extrapolating from limited data: With a 95 CI my heart will stop beating between 2015-02-26 \u2013 2015-03-08. http:\/\/t.co\/Y2jUWp4IbO",
  "id" : 561193697703104512,
  "created_at" : "2015-01-30 16:06:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/0l7Lco2ds3",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2770",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561150318546026497",
  "text" : "weight loss 101 http:\/\/t.co\/0l7Lco2ds3",
  "id" : 561150318546026497,
  "created_at" : "2015-01-30 13:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/MAwWXYUvad",
      "expanded_url" : "http:\/\/whatif.xkcd.com\/126\/",
      "display_url" : "whatif.xkcd.com\/126\/"
    } ]
  },
  "geo" : { },
  "id_str" : "561148299382886400",
  "text" : "a really small butter mountain is enough to climb up into space http:\/\/t.co\/MAwWXYUvad",
  "id" : 561148299382886400,
  "created_at" : "2015-01-30 13:05:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/uJyaF1jIso",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/jan\/29\/hipster-churches-sillicon-valley-evangelical-new-home",
      "display_url" : "theguardian.com\/us-news\/2015\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561132139912376321",
  "text" : "Hipster churches in Silicon Valley: evangelicalism's unlikely new home http:\/\/t.co\/uJyaF1jIso",
  "id" : 561132139912376321,
  "created_at" : "2015-01-30 12:01:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACGT",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/XmJtBbfMw5",
      "expanded_url" : "http:\/\/buff.ly\/1yIdKgu",
      "display_url" : "buff.ly\/1yIdKgu"
    } ]
  },
  "geo" : { },
  "id_str" : "561097495598866432",
  "text" : "RT @kbradnam: Genome Assembly: the art of trying to make one BIG thing from millions of very small things #ACGT http:\/\/t.co\/XmJtBbfMw5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACGT",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/XmJtBbfMw5",
        "expanded_url" : "http:\/\/buff.ly\/1yIdKgu",
        "display_url" : "buff.ly\/1yIdKgu"
      } ]
    },
    "geo" : { },
    "id_str" : "561038413135380480",
    "text" : "Genome Assembly: the art of trying to make one BIG thing from millions of very small things #ACGT http:\/\/t.co\/XmJtBbfMw5",
    "id" : 561038413135380480,
    "created_at" : "2015-01-30 05:49:15 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 561097495598866432,
  "created_at" : "2015-01-30 09:44:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 0, 9 ],
      "id_str" : "17442320",
      "id" : 17442320
    }, {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 10, 19 ],
      "id_str" : "17442320",
      "id" : 17442320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560861921197711360",
  "geo" : { },
  "id_str" : "560863220693745665",
  "in_reply_to_user_id" : 17442320,
  "text" : "@jonworth @jonworth if you\u2019re willing to stay in Saarbr\u00FCcken for a month: arrival @ 10.02.15, departure @ 10.03.15  :D",
  "id" : 560863220693745665,
  "in_reply_to_status_id" : 560861921197711360,
  "created_at" : "2015-01-29 18:13:06 +0000",
  "in_reply_to_screen_name" : "jonworth",
  "in_reply_to_user_id_str" : "17442320",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark McCarthy",
      "screen_name" : "markmccarthyoxf",
      "indices" : [ 3, 19 ],
      "id_str" : "43848067",
      "id" : 43848067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560786035500916736",
  "text" : "RT @markmccarthyoxf: Great news for everyone (except Myriad shareholders and patent lawyers). End of the road for Myriad gene patent fight \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/bbuk3ZZk6g",
        "expanded_url" : "http:\/\/news.sciencemag.org\/biology\/2015\/01\/end-road-myriad-gene-patent-fight",
        "display_url" : "news.sciencemag.org\/biology\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "560609560411766784",
    "text" : "Great news for everyone (except Myriad shareholders and patent lawyers). End of the road for Myriad gene patent fight http:\/\/t.co\/bbuk3ZZk6g",
    "id" : 560609560411766784,
    "created_at" : "2015-01-29 01:25:09 +0000",
    "user" : {
      "name" : "Mark McCarthy",
      "screen_name" : "markmccarthyoxf",
      "protected" : false,
      "id_str" : "43848067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755895431947616256\/caN1-T7x_normal.jpg",
      "id" : 43848067,
      "verified" : false
    }
  },
  "id" : 560786035500916736,
  "created_at" : "2015-01-29 13:06:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/0Z2n7ZeqhD",
      "expanded_url" : "https:\/\/medium.com\/message\/never-trust-a-corporation-to-do-a-librarys-job-f58db4673351",
      "display_url" : "medium.com\/message\/never-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560751623828672512",
  "text" : "never trust a corporation to do a library\u2019s job https:\/\/t.co\/0Z2n7ZeqhD",
  "id" : 560751623828672512,
  "created_at" : "2015-01-29 10:49:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560739402788634624",
  "text" : "RT @JBYoder: \u201CThe Invisible Backpack of White Privilege is great for carrying \u2026  things like weed, Ponzi schemes, and sex crimes.\u201D http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/q913NIl49k",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/product-review-the-invisible-backpack-of-white-privilege-from-ll-bean",
        "display_url" : "mcsweeneys.net\/articles\/produ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "560535656892346368",
    "text" : "\u201CThe Invisible Backpack of White Privilege is great for carrying \u2026  things like weed, Ponzi schemes, and sex crimes.\u201D http:\/\/t.co\/q913NIl49k",
    "id" : 560535656892346368,
    "created_at" : "2015-01-28 20:31:29 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 560739402788634624,
  "created_at" : "2015-01-29 10:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 86, 99 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FSjIvI067i",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/DWkT7iN0-J0\/info%3Adoi%2F10.1371%2Fjournal.pone.0114615",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560724781587529729",
  "text" : "Naming a Lego World. The Role of Language in the Acquisition of Abstract Concepts \/cc @PhilippBayer  http:\/\/t.co\/FSjIvI067i",
  "id" : 560724781587529729,
  "created_at" : "2015-01-29 09:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Best",
      "screen_name" : "PhilipDBest",
      "indices" : [ 3, 15 ],
      "id_str" : "284189052",
      "id" : 284189052
    }, {
      "name" : "Setosa",
      "screen_name" : "setosaio",
      "indices" : [ 92, 101 ],
      "id_str" : "2691964027",
      "id" : 2691964027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/yhPDhmLUpc",
      "expanded_url" : "http:\/\/setosa.io\/ev\/eigenvectors-and-eigenvalues\/",
      "display_url" : "setosa.io\/ev\/eigenvector\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560708929689509888",
  "text" : "RT @PhilipDBest: Eigenvectors and eigenvalues explained visually http:\/\/t.co\/yhPDhmLUpc via @setosaio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Setosa",
        "screen_name" : "setosaio",
        "indices" : [ 75, 84 ],
        "id_str" : "2691964027",
        "id" : 2691964027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/yhPDhmLUpc",
        "expanded_url" : "http:\/\/setosa.io\/ev\/eigenvectors-and-eigenvalues\/",
        "display_url" : "setosa.io\/ev\/eigenvector\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "560575933459886080",
    "text" : "Eigenvectors and eigenvalues explained visually http:\/\/t.co\/yhPDhmLUpc via @setosaio",
    "id" : 560575933459886080,
    "created_at" : "2015-01-28 23:11:32 +0000",
    "user" : {
      "name" : "Philip Best",
      "screen_name" : "PhilipDBest",
      "protected" : false,
      "id_str" : "284189052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894622971129626625\/rlTyRi_U_normal.jpg",
      "id" : 284189052,
      "verified" : false
    }
  },
  "id" : 560708929689509888,
  "created_at" : "2015-01-29 08:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 3, 16 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jnN9loekFW",
      "expanded_url" : "http:\/\/buff.ly\/1uy1gaG",
      "display_url" : "buff.ly\/1uy1gaG"
    } ]
  },
  "geo" : { },
  "id_str" : "560508947636158464",
  "text" : "RT @assemblathon: The world\u2019s worst genome assembler in six lines of Python | Python for biologists http:\/\/t.co\/jnN9loekFW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/jnN9loekFW",
        "expanded_url" : "http:\/\/buff.ly\/1uy1gaG",
        "display_url" : "buff.ly\/1uy1gaG"
      } ]
    },
    "geo" : { },
    "id_str" : "560149999963885568",
    "text" : "The world\u2019s worst genome assembler in six lines of Python | Python for biologists http:\/\/t.co\/jnN9loekFW",
    "id" : 560149999963885568,
    "created_at" : "2015-01-27 18:59:01 +0000",
    "user" : {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "protected" : false,
      "id_str" : "216793572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458989689794355202\/qgt5fqB4_normal.jpeg",
      "id" : 216793572,
      "verified" : false
    }
  },
  "id" : 560508947636158464,
  "created_at" : "2015-01-28 18:45:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/LOlR8kpUIr",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/28\/the-surprising-history-of-hipp.html",
      "display_url" : "boingboing.net\/2015\/01\/28\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560422691652792322",
  "text" : "NO: The surprising history of hippy\u00A0crack http:\/\/t.co\/LOlR8kpUIr",
  "id" : 560422691652792322,
  "created_at" : "2015-01-28 13:02:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560360981394898944",
  "geo" : { },
  "id_str" : "560361296601047040",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport i sync my Charge HR through the iOS app and I want the data in a reusable format (csv\/json), ideally through dev.fitbit .com",
  "id" : 560361296601047040,
  "in_reply_to_status_id" : 560360981394898944,
  "created_at" : "2015-01-28 08:58:38 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560360348730290176",
  "text" : "\u00AB[Loathing administration] is a selfish attitude, but life is short &amp; should not be spent wallowing in unhappiness &amp; incompetence\u00BB\u2014SJ Gould",
  "id" : 560360348730290176,
  "created_at" : "2015-01-28 08:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/SlUnOLryvR",
      "expanded_url" : "https:\/\/evolution-institute.org\/article\/no-room-for-a-gentle-ape\/?source=tvol",
      "display_url" : "evolution-institute.org\/article\/no-roo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560353211845206016",
  "text" : "No Room for A Gentle Ape https:\/\/t.co\/SlUnOLryvR",
  "id" : 560353211845206016,
  "created_at" : "2015-01-28 08:26:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/eMTxYABzUq",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/frontiers-for-young-minds\/2015\/01\/27\/aiming-too-high-or-too-low-when-communicating-science\/",
      "display_url" : "blogs.scientificamerican.com\/frontiers-for-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560352637556916224",
  "text" : "Aiming Too High (Or Too Low) When Communicating Science http:\/\/t.co\/eMTxYABzUq",
  "id" : 560352637556916224,
  "created_at" : "2015-01-28 08:24:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560349939809935362",
  "geo" : { },
  "id_str" : "560350983952539648",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport thanks, but not exactly what I was looking for. I look for a way to get the Charge HR heart rate data through your API :)",
  "id" : 560350983952539648,
  "in_reply_to_status_id" : 560349939809935362,
  "created_at" : "2015-01-28 08:17:40 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/suGQfKP0aZ",
      "expanded_url" : "http:\/\/lh3.github.io\/2015\/01\/27\/the-early-history-of-the-sambam-format\/",
      "display_url" : "lh3.github.io\/2015\/01\/27\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560346155301994496",
  "text" : "RT @yokofakun: \"The early history of the SAM\/BAM format\" http:\/\/t.co\/suGQfKP0aZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/suGQfKP0aZ",
        "expanded_url" : "http:\/\/lh3.github.io\/2015\/01\/27\/the-early-history-of-the-sambam-format\/",
        "display_url" : "lh3.github.io\/2015\/01\/27\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "560345677298167808",
    "text" : "\"The early history of the SAM\/BAM format\" http:\/\/t.co\/suGQfKP0aZ",
    "id" : 560345677298167808,
    "created_at" : "2015-01-28 07:56:34 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 560346155301994496,
  "created_at" : "2015-01-28 07:58:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560284066894065664",
  "geo" : { },
  "id_str" : "560337422828195840",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport do you maybe have a link for that?",
  "id" : 560337422828195840,
  "in_reply_to_status_id" : 560284066894065664,
  "created_at" : "2015-01-28 07:23:46 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560284066894065664",
  "geo" : { },
  "id_str" : "560337398555762689",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport Thanks, but I can\u2019t find which endpoints to use for the heart rate (weight, steps\/floors\/distance,sleep all work fine).",
  "id" : 560337398555762689,
  "in_reply_to_status_id" : 560284066894065664,
  "created_at" : "2015-01-28 07:23:41 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brett johnson",
      "screen_name" : "granitehead",
      "indices" : [ 0, 12 ],
      "id_str" : "19118873",
      "id" : 19118873
    }, {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 77, 87 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560195066539806723",
  "geo" : { },
  "id_str" : "560195285516038145",
  "in_reply_to_user_id" : 19118873,
  "text" : "@granitehead sure, have fun and feel free to ask if any questions arise. thx @MandiBPro for the introduction.",
  "id" : 560195285516038145,
  "in_reply_to_status_id" : 560195066539806723,
  "created_at" : "2015-01-27 21:58:58 +0000",
  "in_reply_to_screen_name" : "granitehead",
  "in_reply_to_user_id_str" : "19118873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    }, {
      "name" : "brett johnson",
      "screen_name" : "granitehead",
      "indices" : [ 11, 23 ],
      "id_str" : "19118873",
      "id" : 19118873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560190792544051200",
  "geo" : { },
  "id_str" : "560191281818001411",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro @granitehead great, would love to hear about it!",
  "id" : 560191281818001411,
  "in_reply_to_status_id" : 560190792544051200,
  "created_at" : "2015-01-27 21:43:04 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560187163523174400",
  "geo" : { },
  "id_str" : "560187375826247682",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABWe could get stuff in the media and we looked like a responsible body, when actually we were a bunch of long-haired lefties.\u00BB",
  "id" : 560187375826247682,
  "in_reply_to_status_id" : 560187163523174400,
  "created_at" : "2015-01-27 21:27:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/olZzdbvWy8",
      "expanded_url" : "http:\/\/mosaicscience.com\/story\/science-people",
      "display_url" : "mosaicscience.com\/story\/science-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560187163523174400",
  "text" : "Science for the people! http:\/\/t.co\/olZzdbvWy8 #cszh",
  "id" : 560187163523174400,
  "created_at" : "2015-01-27 21:26:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/hGdtyg5h4u",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/26\/squirrel-is-pals-with-very-lar.html",
      "display_url" : "boingboing.net\/2015\/01\/26\/squ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560182274067791872",
  "text" : "Nuts! Squirrel tries to hide food in the dog's\u00A0coat http:\/\/t.co\/hGdtyg5h4u",
  "id" : 560182274067791872,
  "created_at" : "2015-01-27 21:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 16, 30 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560179646973886466",
  "text" : "Does the API of @FitbitSupport somehow allow for fetching the heart rate measurements done by the Charge HR? #quantifiedself",
  "id" : 560179646973886466,
  "created_at" : "2015-01-27 20:56:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560169279291940866",
  "geo" : { },
  "id_str" : "560169409554436096",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that would be great, it\u2019s been a long time :)",
  "id" : 560169409554436096,
  "in_reply_to_status_id" : 560169279291940866,
  "created_at" : "2015-01-27 20:16:09 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560168589911928835",
  "geo" : { },
  "id_str" : "560169079823417344",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks :)",
  "id" : 560169079823417344,
  "in_reply_to_status_id" : 560168589911928835,
  "created_at" : "2015-01-27 20:14:50 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560168517363056640",
  "geo" : { },
  "id_str" : "560169061855035394",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez sure, i will. btw: will be close-ish (SF bay) mid\/end of march.",
  "id" : 560169061855035394,
  "in_reply_to_status_id" : 560168517363056640,
  "created_at" : "2015-01-27 20:14:46 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 94, 103 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/7au8BiHJ7Q",
      "expanded_url" : "http:\/\/quantifiedself.com\/2015\/01\/qs-access-data-donation-part-1\/",
      "display_url" : "quantifiedself.com\/2015\/01\/qs-acc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560168342146023424",
  "text" : "How\/Where to donate your #quantifiedself data: http:\/\/t.co\/7au8BiHJ7Q Thanks for the shoutout @eramirez!",
  "id" : 560168342146023424,
  "created_at" : "2015-01-27 20:11:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/JNRQETUvSU",
      "expanded_url" : "http:\/\/th05.deviantart.net\/fs71\/PRE\/i\/2012\/322\/1\/6\/lincoln_riding_a_dinosaur_by_luxnax-d5ldjhs.jpg",
      "display_url" : "th05.deviantart.net\/fs71\/PRE\/i\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "559860346501234688",
  "geo" : { },
  "id_str" : "559860552605134848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cmon, future! http:\/\/t.co\/JNRQETUvSU",
  "id" : 559860552605134848,
  "in_reply_to_status_id" : 559860346501234688,
  "created_at" : "2015-01-26 23:48:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559855573869408256",
  "geo" : { },
  "id_str" : "559859976702001153",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer soon robots will do all the fancy science things for us! :p",
  "id" : 559859976702001153,
  "in_reply_to_status_id" : 559855573869408256,
  "created_at" : "2015-01-26 23:46:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 100, 113 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2vs56khWgT",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0116902",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559853362842451968",
  "text" : "Metro Maps of Plant Disease Dynamics\u2014Automated Mining of Differences Using Hyperspectral Images \/cc @PhilippBayer http:\/\/t.co\/2vs56khWgT",
  "id" : 559853362842451968,
  "created_at" : "2015-01-26 23:20:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559798058050129923",
  "geo" : { },
  "id_str" : "559798292000026624",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn as am I vice versa. :) btw you don\u2019t happen to be in SF around March 22-28th?",
  "id" : 559798292000026624,
  "in_reply_to_status_id" : 559798058050129923,
  "created_at" : "2015-01-26 19:41:28 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559797328396423168",
  "geo" : { },
  "id_str" : "559797931692531713",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn not only I\u2019d say :)",
  "id" : 559797931692531713,
  "in_reply_to_status_id" : 559797328396423168,
  "created_at" : "2015-01-26 19:40:02 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559796965614309376",
  "geo" : { },
  "id_str" : "559797154806763521",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn I\u2019m sure you did fine. You have lots of experience already :D",
  "id" : 559797154806763521,
  "in_reply_to_status_id" : 559796965614309376,
  "created_at" : "2015-01-26 19:36:56 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559434467878907904",
  "geo" : { },
  "id_str" : "559792988420046848",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn just heard you were also interviewed again. well done :D",
  "id" : 559792988420046848,
  "in_reply_to_status_id" : 559434467878907904,
  "created_at" : "2015-01-26 19:20:23 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "indices" : [ 3, 10 ],
      "id_str" : "17387342",
      "id" : 17387342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/cdjqMEH8vb",
      "expanded_url" : "http:\/\/daniellakens.blogspot.nl\/2015\/01\/always-use-welchs-t-test-instead-of.html",
      "display_url" : "daniellakens.blogspot.nl\/2015\/01\/always\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559732574491508739",
  "text" : "RT @lakens: New blog post: Why you should always report Welch's t-test instead of Student's t-test: http:\/\/t.co\/cdjqMEH8vb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/cdjqMEH8vb",
        "expanded_url" : "http:\/\/daniellakens.blogspot.nl\/2015\/01\/always-use-welchs-t-test-instead-of.html",
        "display_url" : "daniellakens.blogspot.nl\/2015\/01\/always\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559645785223352320",
    "text" : "New blog post: Why you should always report Welch's t-test instead of Student's t-test: http:\/\/t.co\/cdjqMEH8vb",
    "id" : 559645785223352320,
    "created_at" : "2015-01-26 09:35:27 +0000",
    "user" : {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "protected" : false,
      "id_str" : "17387342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875950390952554496\/G07USELb_normal.jpg",
      "id" : 17387342,
      "verified" : true
    }
  },
  "id" : 559732574491508739,
  "created_at" : "2015-01-26 15:20:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 60, 73 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Pr3bYwCfc0",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007\/s12079-014-0258-2",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559676371170263040",
  "text" : "\u00ABCommunication is the key: direct to consumer genetics\u00BB \/cc @PhilippBayer http:\/\/t.co\/Pr3bYwCfc0",
  "id" : 559676371170263040,
  "created_at" : "2015-01-26 11:36:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "indices" : [ 3, 13 ],
      "id_str" : "18911432",
      "id" : 18911432
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paulcoxon\/status\/559647129850093569\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/evKDHBiwBN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8RD82YCMAAAPL9.png",
      "id_str" : "559646966368317440",
      "id" : 559646966368317440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8RD82YCMAAAPL9.png",
      "sizes" : [ {
        "h" : 603,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/evKDHBiwBN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559655417048219648",
  "text" : "RT @paulcoxon: 19th century scientist, 21st century scientist (by Pedromics): http:\/\/t.co\/evKDHBiwBN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paulcoxon\/status\/559647129850093569\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/evKDHBiwBN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8RD82YCMAAAPL9.png",
        "id_str" : "559646966368317440",
        "id" : 559646966368317440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8RD82YCMAAAPL9.png",
        "sizes" : [ {
          "h" : 603,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/evKDHBiwBN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "559647129850093569",
    "text" : "19th century scientist, 21st century scientist (by Pedromics): http:\/\/t.co\/evKDHBiwBN",
    "id" : 559647129850093569,
    "created_at" : "2015-01-26 09:40:48 +0000",
    "user" : {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "protected" : false,
      "id_str" : "18911432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636660043312693248\/K6eLUfum_normal.jpg",
      "id" : 18911432,
      "verified" : true
    }
  },
  "id" : 559655417048219648,
  "created_at" : "2015-01-26 10:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/c4EMvdTOro",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/jan\/24\/if-you-dont-understand-poverty-youre-a-sociopath?CMP=fb_gu",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559647742902173696",
  "text" : "If you don\u2019t understand how people fall into poverty, you\u2019re probably a sociopath http:\/\/t.co\/c4EMvdTOro",
  "id" : 559647742902173696,
  "created_at" : "2015-01-26 09:43:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/hmlodvsHBP",
      "expanded_url" : "https:\/\/majesticforest.wordpress.com\/2015\/01\/10\/strikingly-important-it-is-not\/",
      "display_url" : "majesticforest.wordpress.com\/2015\/01\/10\/str\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559622604542476288",
  "text" : "Strikingly important it is\u00A0not https:\/\/t.co\/hmlodvsHBP",
  "id" : 559622604542476288,
  "created_at" : "2015-01-26 08:03:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RevolutionBio",
      "screen_name" : "RevolutionBio",
      "indices" : [ 3, 17 ],
      "id_str" : "1448919374",
      "id" : 1448919374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crabgrass",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/jOf0xHQf1n",
      "expanded_url" : "http:\/\/revolutionbio.co\/easy\/",
      "display_url" : "revolutionbio.co\/easy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "559617498606489600",
  "text" : "RT @RevolutionBio: What biology looks like to computer programmers\nhttp:\/\/t.co\/jOf0xHQf1n \nfrom our friends at #crabgrass http:\/\/t.co\/qpHhT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RevolutionBio\/status\/558268323746435072\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/qpHhTFNR93",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B79eFPmIYAAt_qR.jpg",
        "id_str" : "558268322996051968",
        "id" : 558268322996051968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B79eFPmIYAAt_qR.jpg",
        "sizes" : [ {
          "h" : 470,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 642
        } ],
        "display_url" : "pic.twitter.com\/qpHhTFNR93"
      } ],
      "hashtags" : [ {
        "text" : "crabgrass",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/jOf0xHQf1n",
        "expanded_url" : "http:\/\/revolutionbio.co\/easy\/",
        "display_url" : "revolutionbio.co\/easy\/"
      } ]
    },
    "geo" : { },
    "id_str" : "558268323746435072",
    "text" : "What biology looks like to computer programmers\nhttp:\/\/t.co\/jOf0xHQf1n \nfrom our friends at #crabgrass http:\/\/t.co\/qpHhTFNR93",
    "id" : 558268323746435072,
    "created_at" : "2015-01-22 14:21:55 +0000",
    "user" : {
      "name" : "RevolutionBio",
      "screen_name" : "RevolutionBio",
      "protected" : false,
      "id_str" : "1448919374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698227190031368192\/ivoQYUWa_normal.jpg",
      "id" : 1448919374,
      "verified" : false
    }
  },
  "id" : 559617498606489600,
  "created_at" : "2015-01-26 07:43:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Walton",
      "screen_name" : "rachelcwalton",
      "indices" : [ 3, 17 ],
      "id_str" : "4923635608",
      "id" : 4923635608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559615810529161216",
  "text" : "RT @rachelcwalton: Shld I learn Python? Have been thinking about this recently: The fall of Perl and the rise of Python: http:\/\/t.co\/jDcmQ5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PerlDaily",
        "screen_name" : "PerlDaily",
        "indices" : [ 129, 139 ],
        "id_str" : "1539035490",
        "id" : 1539035490
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/jDcmQ5N5ZU",
        "expanded_url" : "http:\/\/www.fastcolabs.com\/3026446\/the-fall-of-perl-the-webs-most-promising-language",
        "display_url" : "fastcolabs.com\/3026446\/the-fa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559487415795343360",
    "text" : "Shld I learn Python? Have been thinking about this recently: The fall of Perl and the rise of Python: http:\/\/t.co\/jDcmQ5N5ZU via @PerlDaily",
    "id" : 559487415795343360,
    "created_at" : "2015-01-25 23:06:09 +0000",
    "user" : {
      "name" : "Rachel Brenchley",
      "screen_name" : "DrRachelB",
      "protected" : false,
      "id_str" : "306154044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740473983187976192\/QvsVk8vd_normal.jpg",
      "id" : 306154044,
      "verified" : false
    }
  },
  "id" : 559615810529161216,
  "created_at" : "2015-01-26 07:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Ritchie",
      "screen_name" : "StuartJRitchie",
      "indices" : [ 3, 18 ],
      "id_str" : "180858875",
      "id" : 180858875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Fv9OyssjJ7",
      "expanded_url" : "http:\/\/slatestarcodex.com\/2015\/01\/24\/perceptions-of-required-ability-act-as-a-proxy-for-actual-required-ability-in-explaining-the-gender-gap\/",
      "display_url" : "slatestarcodex.com\/2015\/01\/24\/per\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559485631911718913",
  "text" : "RT @StuartJRitchie: Surely not! Another psychology paper published in Science turns out to be, er, not very good: http:\/\/t.co\/Fv9OyssjJ7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Fv9OyssjJ7",
        "expanded_url" : "http:\/\/slatestarcodex.com\/2015\/01\/24\/perceptions-of-required-ability-act-as-a-proxy-for-actual-required-ability-in-explaining-the-gender-gap\/",
        "display_url" : "slatestarcodex.com\/2015\/01\/24\/per\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559454510121512961",
    "text" : "Surely not! Another psychology paper published in Science turns out to be, er, not very good: http:\/\/t.co\/Fv9OyssjJ7",
    "id" : 559454510121512961,
    "created_at" : "2015-01-25 20:55:24 +0000",
    "user" : {
      "name" : "Stuart Ritchie",
      "screen_name" : "StuartJRitchie",
      "protected" : false,
      "id_str" : "180858875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512906786202873856\/O_gVcoqI_normal.jpeg",
      "id" : 180858875,
      "verified" : false
    }
  },
  "id" : 559485631911718913,
  "created_at" : "2015-01-25 22:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/05G1YMxnlQ",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/01\/tool-making-may-have-made-language-genes-more-useful\/",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559483918337191936",
  "text" : "Tool-making may have made language genes more useful http:\/\/t.co\/05G1YMxnlQ",
  "id" : 559483918337191936,
  "created_at" : "2015-01-25 22:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/dyIsbkKh1u",
      "expanded_url" : "https:\/\/medium.com\/@hankgreen\/holy-shit-i-interviewed-the-president-fa3e8fb44d16",
      "display_url" : "medium.com\/@hankgreen\/hol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559482895031894019",
  "text" : "\u00ABIn my experience, people under the age of 30 tend to simply assume that all media are biased\u00BB https:\/\/t.co\/dyIsbkKh1u",
  "id" : 559482895031894019,
  "created_at" : "2015-01-25 22:48:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/unweheSn6N",
      "expanded_url" : "http:\/\/oglaf.com\/clustering\/",
      "display_url" : "oglaf.com\/clustering\/"
    } ]
  },
  "geo" : { },
  "id_str" : "559472262785826817",
  "text" : "after you showed her the graph?! http:\/\/t.co\/unweheSn6N",
  "id" : 559472262785826817,
  "created_at" : "2015-01-25 22:05:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/L4X7m1WUyP",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0115451",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559446454658695168",
  "text" : "Wonder where they sent this one first: \u00ABWhere Should I Send It? Optimizing the Submission Decision Process\u00BB http:\/\/t.co\/L4X7m1WUyP",
  "id" : 559446454658695168,
  "created_at" : "2015-01-25 20:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559434467878907904",
  "geo" : { },
  "id_str" : "559435009518759938",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer guess who didn\u2019t know about those until like 2 minutes ago!",
  "id" : 559435009518759938,
  "in_reply_to_status_id" : 559434467878907904,
  "created_at" : "2015-01-25 19:37:54 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 63, 73 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/4JJxMnk24g",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/01\/study-complaining-on-twitter-correlates-with-heart-disease-risks\/?utm_content=buffer0ca65&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559434062247780353",
  "text" : "Complaining on Twitter correlates with heart disease risks \/HT @MandiBPro http:\/\/t.co\/4JJxMnk24g",
  "id" : 559434062247780353,
  "created_at" : "2015-01-25 19:34:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 33, 43 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559401839645712385",
  "geo" : { },
  "id_str" : "559404093501104129",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer aye, all credit to @eltonjohn though. :-)",
  "id" : 559404093501104129,
  "in_reply_to_status_id" : 559401839645712385,
  "created_at" : "2015-01-25 17:35:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 83, 96 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 101, 111 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ZFQdUBICif",
      "expanded_url" : "http:\/\/infoscience.epfl.ch\/record\/203833",
      "display_url" : "infoscience.epfl.ch\/record\/203833"
    } ]
  },
  "geo" : { },
  "id_str" : "559397121829646337",
  "text" : "\u00ABOn Non-cooperative Genomic Privacy\u00BB \u2013 Features openSNP &amp; Nash Equilibria! \/cc @PhilippBayer \/HT @eltonjohn http:\/\/t.co\/ZFQdUBICif",
  "id" : 559397121829646337,
  "created_at" : "2015-01-25 17:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/PEvnMf019Z",
      "expanded_url" : "http:\/\/www.rollingstone.com\/music\/features\/yusuf-islams-golden-years-cat-stevens-on-islam-and-his-return-to-music-20150113",
      "display_url" : "rollingstone.com\/music\/features\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559382990208630785",
  "text" : "Yusuf Islam's Golden Years: Cat Stevens on Islam and His Return to Music http:\/\/t.co\/PEvnMf019Z",
  "id" : 559382990208630785,
  "created_at" : "2015-01-25 16:11:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 85, 94 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/d3kA03lSNj",
      "expanded_url" : "http:\/\/stilldrinking.org\/programming-sucks",
      "display_url" : "stilldrinking.org\/programming-su\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559381629878419457",
  "text" : "Programming Sucks \u00ABAll programming teams are constructed by and of crazy people\u00BB \/HT @SuicideC http:\/\/t.co\/d3kA03lSNj",
  "id" : 559381629878419457,
  "created_at" : "2015-01-25 16:05:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ffOr0aLCtl",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/120731\/thank-god-i-didnt-have-twitter-when-i-was-racist-sexist-jerk",
      "display_url" : "newrepublic.com\/article\/120731\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559379872066592770",
  "text" : "I Was Once a Racist, Sexist Jerk. Thank God I Didn't Have Twitter. http:\/\/t.co\/ffOr0aLCtl",
  "id" : 559379872066592770,
  "created_at" : "2015-01-25 15:58:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/0WbUOqGgay",
      "expanded_url" : "http:\/\/markmanson.net\/not-giving-a-fuck",
      "display_url" : "markmanson.net\/not-giving-a-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559378546263859200",
  "text" : "the subtle art of not giving a fuck http:\/\/t.co\/0WbUOqGgay",
  "id" : 559378546263859200,
  "created_at" : "2015-01-25 15:53:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Levine",
      "screen_name" : "Dlloydlevine",
      "indices" : [ 3, 16 ],
      "id_str" : "19889143",
      "id" : 19889143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559375318776295424",
  "text" : "RT @Dlloydlevine: \u201CSponsored\u201D by my husband: Why it\u2019s a problem that writers never talk about where their money comes from http:\/\/t.co\/QPYh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salon",
        "screen_name" : "Salon",
        "indices" : [ 132, 138 ],
        "id_str" : "16955991",
        "id" : 16955991
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/QPYhOlaT6y",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/01\/25\/sponsored_by_my_husband_why_its_a_problem_that_writers_never_talk_about_where_their_money_comes_from\/",
        "display_url" : "salon.com\/2015\/01\/25\/spo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559352558096224258",
    "text" : "\u201CSponsored\u201D by my husband: Why it\u2019s a problem that writers never talk about where their money comes from http:\/\/t.co\/QPYhOlaT6y via @Salon",
    "id" : 559352558096224258,
    "created_at" : "2015-01-25 14:10:16 +0000",
    "user" : {
      "name" : "David Levine",
      "screen_name" : "Dlloydlevine",
      "protected" : false,
      "id_str" : "19889143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854345370310148097\/IybaS9w__normal.jpg",
      "id" : 19889143,
      "verified" : false
    }
  },
  "id" : 559375318776295424,
  "created_at" : "2015-01-25 15:40:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/559147521461612544\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/YV1zc2IvpX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8J9tQvCMAArfwo.jpg",
      "id_str" : "559147520287191040",
      "id" : 559147520287191040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8J9tQvCMAArfwo.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2431,
        "resize" : "fit",
        "w" : 2431
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/YV1zc2IvpX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/2LG119G6i0",
      "expanded_url" : "http:\/\/www.wildharvestorganic.com\/About_Wild_Harvest\/About_Free_From.html",
      "display_url" : "wildharvestorganic.com\/About_Wild_Har\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559352368450781185",
  "text" : "RT @JBYoder: Tryptophan. http:\/\/t.co\/2LG119G6i0\nhttp:\/\/t.co\/YV1zc2IvpX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/559147521461612544\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/YV1zc2IvpX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B8J9tQvCMAArfwo.jpg",
        "id_str" : "559147520287191040",
        "id" : 559147520287191040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8J9tQvCMAArfwo.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2431,
          "resize" : "fit",
          "w" : 2431
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/YV1zc2IvpX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/2LG119G6i0",
        "expanded_url" : "http:\/\/www.wildharvestorganic.com\/About_Wild_Harvest\/About_Free_From.html",
        "display_url" : "wildharvestorganic.com\/About_Wild_Har\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559150349714739201",
    "text" : "Tryptophan. http:\/\/t.co\/2LG119G6i0\nhttp:\/\/t.co\/YV1zc2IvpX",
    "id" : 559150349714739201,
    "created_at" : "2015-01-25 00:46:46 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 559352368450781185,
  "created_at" : "2015-01-25 14:09:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559345172346327041",
  "text" : "Is there a somewhat comprehensive list of \u201Call\u201D de novo genome assemblers out there?",
  "id" : 559345172346327041,
  "created_at" : "2015-01-25 13:40:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559341171458469888",
  "geo" : { },
  "id_str" : "559343083440336897",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish save travels!",
  "id" : 559343083440336897,
  "in_reply_to_status_id" : 559341171458469888,
  "created_at" : "2015-01-25 13:32:37 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/LxiohPBRYD",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3619",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559327796229857280",
  "text" : "I can still consult satanists if academia doesn\u2019t work out http:\/\/t.co\/LxiohPBRYD",
  "id" : 559327796229857280,
  "created_at" : "2015-01-25 12:31:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 0, 7 ],
      "id_str" : "159891548",
      "id" : 159891548
    }, {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 8, 16 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558698801880662016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00962944593321, 8.459633400715763 ]
  },
  "id_str" : "558713599641014272",
  "in_reply_to_user_id" : 159891548,
  "text" : "@ehafen @punkish I can only speak for myself, but I had a blast with all off you. :)",
  "id" : 558713599641014272,
  "in_reply_to_status_id" : 558698801880662016,
  "created_at" : "2015-01-23 19:51:17 +0000",
  "in_reply_to_screen_name" : "ehafen",
  "in_reply_to_user_id_str" : "159891548",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bolser",
      "screen_name" : "danbolser",
      "indices" : [ 0, 10 ],
      "id_str" : "16325864",
      "id" : 16325864
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 46, 59 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558694584134668290",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45367621641975, 8.560372973380737 ]
  },
  "id_str" : "558694726925582337",
  "in_reply_to_user_id" : 16325864,
  "text" : "@danbolser Na, then I have no idea. But maybe @PhilippBayer has an idea.",
  "id" : 558694726925582337,
  "in_reply_to_status_id" : 558694584134668290,
  "created_at" : "2015-01-23 18:36:17 +0000",
  "in_reply_to_screen_name" : "danbolser",
  "in_reply_to_user_id_str" : "16325864",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bolser",
      "screen_name" : "danbolser",
      "indices" : [ 0, 10 ],
      "id_str" : "16325864",
      "id" : 16325864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558651298103709696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45363628550391, 8.56010691356626 ]
  },
  "id_str" : "558692594092630016",
  "in_reply_to_user_id" : 16325864,
  "text" : "@danbolser dunno whether you can query it from dbSNP.",
  "id" : 558692594092630016,
  "in_reply_to_status_id" : 558651298103709696,
  "created_at" : "2015-01-23 18:27:49 +0000",
  "in_reply_to_screen_name" : "danbolser",
  "in_reply_to_user_id_str" : "16325864",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558681839309946881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.42622466082819, 8.561316508753857 ]
  },
  "id_str" : "558684504752402432",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish look who\u2019s looking fabulous! ;)",
  "id" : 558684504752402432,
  "in_reply_to_status_id" : 558681839309946881,
  "created_at" : "2015-01-23 17:55:40 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/558681224257232896\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ZZ1WG6COD2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8DVmvaCAAAtw_b.jpg",
      "id_str" : "558681215331336192",
      "id" : 558681215331336192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8DVmvaCAAAtw_b.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/ZZ1WG6COD2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558680730918977537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.39932322359797, 8.542633471504992 ]
  },
  "id_str" : "558681224257232896",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish here you go :-) http:\/\/t.co\/ZZ1WG6COD2",
  "id" : 558681224257232896,
  "in_reply_to_status_id" : 558680730918977537,
  "created_at" : "2015-01-23 17:42:38 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 15, 23 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 24, 38 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 39, 55 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "danielapaolotti",
      "screen_name" : "danielapaolotti",
      "indices" : [ 56, 72 ],
      "id_str" : "17657107",
      "id" : 17657107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.39623938530315, 8.544262694561652 ]
  },
  "id_str" : "558680535753834496",
  "text" : "Also thanks to @punkish @PenguinGalaxy @kevinschawinski @danielapaolotti et al. for the great discussions. #cszh",
  "id" : 558680535753834496,
  "created_at" : "2015-01-23 17:39:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 73, 80 ],
      "id_str" : "159891548",
      "id" : 159891548
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 87, 98 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/cYUoZEscAq",
      "expanded_url" : "http:\/\/instagram.com\/p\/yNH4prBwlZ\/",
      "display_url" : "instagram.com\/p\/yNH4prBwlZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3900364703604, 8.545786990035227 ]
  },
  "id_str" : "558679740463456256",
  "text" : "This must have been one of the coolest locations I ever spoke at. Thanks @ehafen &amp; @EffyVayena for the invite! http:\/\/t.co\/cYUoZEscAq #cszh",
  "id" : 558679740463456256,
  "created_at" : "2015-01-23 17:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/cYUoZEscAq",
      "expanded_url" : "http:\/\/instagram.com\/p\/yNH4prBwlZ\/",
      "display_url" : "instagram.com\/p\/yNH4prBwlZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.376532827, 8.548551833 ]
  },
  "id_str" : "558679495948132352",
  "text" : "This must have been one of the coolest locations I ever spoke at. @ ETH Z\u00FCrich http:\/\/t.co\/cYUoZEscAq",
  "id" : 558679495948132352,
  "created_at" : "2015-01-23 17:35:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 50, 56 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/PdIW3Bi2j7",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/23\/watch-alt-j-perform-left-han.html",
      "display_url" : "boingboing.net\/2015\/01\/23\/wat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558633434751721472",
  "text" : "alt-J perform \"Left Hand Free\" live in\u00A0studio \/cc @Lobot http:\/\/t.co\/PdIW3Bi2j7",
  "id" : 558633434751721472,
  "created_at" : "2015-01-23 14:32:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ayaW0WYpwZ",
      "expanded_url" : "https:\/\/nickilottmetagenomics.wordpress.com\/2015\/01\/19\/comparing-diamond-lca-against-kraken\/",
      "display_url" : "nickilottmetagenomics.wordpress.com\/2015\/01\/19\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558631769986301952",
  "text" : "Comparing DIAMOND + LCA against\u00A0Kraken https:\/\/t.co\/ayaW0WYpwZ",
  "id" : 558631769986301952,
  "created_at" : "2015-01-23 14:26:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558631532488036352",
  "text" : "Should be named \u2018Fireside Horror Stories\u2019: A page dedicated to stories on trying to get IRB approval for citizen science projects #cszh",
  "id" : 558631532488036352,
  "created_at" : "2015-01-23 14:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558573961777520640",
  "text" : "Springer-Rep RK: maybe not everything in citizen science should be open access, because Google might use the data for advertising o_O #cszh",
  "id" : 558573961777520640,
  "created_at" : "2015-01-23 10:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Rid",
      "screen_name" : "RidT",
      "indices" : [ 3, 8 ],
      "id_str" : "18742124",
      "id" : 18742124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RidT\/status\/558391354058113024\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HL5UZP54s4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_N7uCIMAEmcgl.jpg",
      "id_str" : "558391304670162945",
      "id" : 558391304670162945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_N7uCIMAEmcgl.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/HL5UZP54s4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558571422801739776",
  "text" : "RT @RidT: Look to Germany for how to run higher education into the ground -- even France looks good in comparison ... http:\/\/t.co\/HL5UZP54s4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RidT\/status\/558391354058113024\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/HL5UZP54s4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_N7uCIMAEmcgl.jpg",
        "id_str" : "558391304670162945",
        "id" : 558391304670162945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_N7uCIMAEmcgl.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/HL5UZP54s4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "558391354058113024",
    "text" : "Look to Germany for how to run higher education into the ground -- even France looks good in comparison ... http:\/\/t.co\/HL5UZP54s4",
    "id" : 558391354058113024,
    "created_at" : "2015-01-22 22:30:47 +0000",
    "user" : {
      "name" : "Thomas Rid",
      "screen_name" : "RidT",
      "protected" : false,
      "id_str" : "18742124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726135886543503360\/0-AZbPQ9_normal.jpg",
      "id" : 18742124,
      "verified" : true
    }
  },
  "id" : 558571422801739776,
  "created_at" : "2015-01-23 10:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558569172733788160",
  "geo" : { },
  "id_str" : "558569654877446144",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski there are similar things in other disciplines, but google (scholar) works equally well most of the time.",
  "id" : 558569654877446144,
  "in_reply_to_status_id" : 558569172733788160,
  "created_at" : "2015-01-23 10:19:18 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558568648148000768",
  "geo" : { },
  "id_str" : "558568985722380288",
  "in_reply_to_user_id" : 14286491,
  "text" : "Because what could be more fun than gaming Google in order to push closed access article up in the search ranking?",
  "id" : 558568985722380288,
  "in_reply_to_status_id" : 558568648148000768,
  "created_at" : "2015-01-23 10:16:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558568648148000768",
  "text" : "Reinald Klockenbusch of Springer: one benefit of publishing through Springer is that they do SEO to make papers rank high on Google\u2026 #cszh",
  "id" : 558568648148000768,
  "created_at" : "2015-01-23 10:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 99, 107 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37649109878269, 8.547562781306738 ]
  },
  "id_str" : "558549273143705600",
  "text" : "Licenses: \u00ABA signal to the good folks, a guide to the unsure, and meaningless to the bad folks.\u00BB \u2014 @punkish #cszh",
  "id" : 558549273143705600,
  "created_at" : "2015-01-23 08:58:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/q4NwObhgAQ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1004919",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558398432592023553",
  "text" : "Evolutionary Constraint and Disease Associations of Post-Translational Modification Sites \/cc @PhilippBayer http:\/\/t.co\/q4NwObhgAQ",
  "id" : 558398432592023553,
  "created_at" : "2015-01-22 22:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/uGTiv5GQKF",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/22\/7871579\/poop-feces",
      "display_url" : "vox.com\/2015\/1\/22\/7871\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558396791964831744",
  "text" : "\u00AB9 surprising facts about feces\u00BB Cool, I actually never read about Meconium so far. http:\/\/t.co\/uGTiv5GQKF",
  "id" : 558396791964831744,
  "created_at" : "2015-01-22 22:52:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/xFPFQS7QW5",
      "expanded_url" : "http:\/\/erlichya.tumblr.com\/post\/108802484899\/cancer-bad-luck-the-first-law-of-holes",
      "display_url" : "erlichya.tumblr.com\/post\/108802484\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558393484051505153",
  "text" : "Cancer Bad Luck: the first law of holes. http:\/\/t.co\/xFPFQS7QW5",
  "id" : 558393484051505153,
  "created_at" : "2015-01-22 22:39:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558335360510754816",
  "geo" : { },
  "id_str" : "558389769030602753",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj &lt;3",
  "id" : 558389769030602753,
  "in_reply_to_status_id" : 558335360510754816,
  "created_at" : "2015-01-22 22:24:29 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558315098457247744",
  "geo" : { },
  "id_str" : "558387244047007744",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy that\u2019s too bad. Hope we do see each other tomorrow then. :)",
  "id" : 558387244047007744,
  "in_reply_to_status_id" : 558315098457247744,
  "created_at" : "2015-01-22 22:14:27 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frontiers",
      "screen_name" : "FrontiersIn",
      "indices" : [ 3, 15 ],
      "id_str" : "86292908",
      "id" : 86292908
    }, {
      "name" : "Martin Vetterli",
      "screen_name" : "MartinVetterli",
      "indices" : [ 20, 35 ],
      "id_str" : "2382286849",
      "id" : 2382286849
    }, {
      "name" : "PeerJ - the journal",
      "screen_name" : "thePeerJ",
      "indices" : [ 105, 114 ],
      "id_str" : "402875257",
      "id" : 402875257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MartinVetterli\/status\/558273005110190080\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Hkzo6QWqWn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B79iVroCYAAk8Fl.png",
      "id_str" : "558273003444658176",
      "id" : 558273003444658176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B79iVroCYAAk8Fl.png",
      "sizes" : [ {
        "h" : 659,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Hkzo6QWqWn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/P9lN8APOBC",
      "expanded_url" : "https:\/\/peerj.com\/articles\/733\/",
      "display_url" : "peerj.com\/articles\/733\/"
    } ]
  },
  "geo" : { },
  "id_str" : "558275527216496641",
  "text" : "RT @FrontiersIn: RT @MartinVetterli: A surge of p-values in recent decades | https:\/\/t.co\/P9lN8APOBC via @thePeerJ http:\/\/t.co\/Hkzo6QWqWn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Vetterli",
        "screen_name" : "MartinVetterli",
        "indices" : [ 3, 18 ],
        "id_str" : "2382286849",
        "id" : 2382286849
      }, {
        "name" : "PeerJ - the journal",
        "screen_name" : "thePeerJ",
        "indices" : [ 88, 97 ],
        "id_str" : "402875257",
        "id" : 402875257
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MartinVetterli\/status\/558273005110190080\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Hkzo6QWqWn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B79iVroCYAAk8Fl.png",
        "id_str" : "558273003444658176",
        "id" : 558273003444658176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B79iVroCYAAk8Fl.png",
        "sizes" : [ {
          "h" : 659,
          "resize" : "fit",
          "w" : 1197
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 1197
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 1197
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Hkzo6QWqWn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/P9lN8APOBC",
        "expanded_url" : "https:\/\/peerj.com\/articles\/733\/",
        "display_url" : "peerj.com\/articles\/733\/"
      } ]
    },
    "geo" : { },
    "id_str" : "558274564711792640",
    "text" : "RT @MartinVetterli: A surge of p-values in recent decades | https:\/\/t.co\/P9lN8APOBC via @thePeerJ http:\/\/t.co\/Hkzo6QWqWn",
    "id" : 558274564711792640,
    "created_at" : "2015-01-22 14:46:43 +0000",
    "user" : {
      "name" : "Frontiers",
      "screen_name" : "FrontiersIn",
      "protected" : false,
      "id_str" : "86292908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923089875724840960\/ZWETEbZY_normal.jpg",
      "id" : 86292908,
      "verified" : false
    }
  },
  "id" : 558275527216496641,
  "created_at" : "2015-01-22 14:50:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558254422573453314",
  "text" : "On speeding up science: \u00ABWe no longer have the luxury to wait for funerals.\u00BB #cszh",
  "id" : 558254422573453314,
  "created_at" : "2015-01-22 13:26:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/gb4kwfIekD",
      "expanded_url" : "http:\/\/www.companionanimalpsychology.com\/2015\/01\/do-dogs-prefer-petting-or-praise.html",
      "display_url" : "companionanimalpsychology.com\/2015\/01\/do-dog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558253428296929281",
  "text" : "Do Dogs Prefer Petting or Praise? http:\/\/t.co\/gb4kwfIekD",
  "id" : 558253428296929281,
  "created_at" : "2015-01-22 13:22:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558252133385269248",
  "text" : "\u00ABCan I borrow your smartphone for my talk? I\u2019m using mine to record the talk and I need one to show to the audience.\u00BB",
  "id" : 558252133385269248,
  "created_at" : "2015-01-22 13:17:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 3, 10 ],
      "id_str" : "159891548",
      "id" : 159891548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/8qD1vFZlG7",
      "expanded_url" : "http:\/\/observationalepidemiology.blogspot.ch\/2010\/03\/curse-of-large-numbers-and-real-problem.html",
      "display_url" : "observationalepidemiology.blogspot.ch\/2010\/03\/curse-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558251279475310592",
  "text" : "As @ehafen just talked about having huge samples (and I did it myself): The curse of large numbers. #cszh http:\/\/t.co\/8qD1vFZlG7",
  "id" : 558251279475310592,
  "created_at" : "2015-01-22 13:14:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558249794557460480",
  "geo" : { },
  "id_str" : "558250139165667328",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy yeah, some really nice projects. And fits citizen science because older people themselves perform the experiments.",
  "id" : 558250139165667328,
  "in_reply_to_status_id" : 558249794557460480,
  "created_at" : "2015-01-22 13:09:39 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558249257925611521",
  "geo" : { },
  "id_str" : "558249887591309312",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy now briefly on other projects: street crossings &amp; whether supermarkets are accessible for older people.",
  "id" : 558249887591309312,
  "in_reply_to_status_id" : 558249257925611521,
  "created_at" : "2015-01-22 13:08:39 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558249257925611521",
  "geo" : { },
  "id_str" : "558249450913923072",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy yeah, he compared our work on safety for cars &amp; planes to the poor one on trip safety.",
  "id" : 558249450913923072,
  "in_reply_to_status_id" : 558249257925611521,
  "created_at" : "2015-01-22 13:06:55 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558248232921600000",
  "geo" : { },
  "id_str" : "558248677547200512",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy apparently his project is about working for and with older people, e.g. making sure stair cases are secure enough.",
  "id" : 558248677547200512,
  "in_reply_to_status_id" : 558248232921600000,
  "created_at" : "2015-01-22 13:03:51 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 66, 72 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/DxeUaaWpwk",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/01\/island-on-fire-excerpt-laki-volcano-iceland\/",
      "display_url" : "wired.com\/2015\/01\/island\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558247269833912322",
  "text" : "A Visit to the Forgotten Volcano That Once Turned Europe Dark \/cc @Lobot http:\/\/t.co\/DxeUaaWpwk",
  "id" : 558247269833912322,
  "created_at" : "2015-01-22 12:58:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/WBa1Pkiarm",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002050",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558246651773865984",
  "text" : "Where Next for Microbiome Research? http:\/\/t.co\/WBa1Pkiarm",
  "id" : 558246651773865984,
  "created_at" : "2015-01-22 12:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558245695858442242",
  "geo" : { },
  "id_str" : "558246141733920768",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy great, will do. thanks for sharing!",
  "id" : 558246141733920768,
  "in_reply_to_status_id" : 558245695858442242,
  "created_at" : "2015-01-22 12:53:46 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558244084692049920",
  "geo" : { },
  "id_str" : "558245376910950401",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just for fun: Try doing the math of recalculating those 16 years\/day on Angry Birds into hours\/year in order to not be fooled. #cszh",
  "id" : 558245376910950401,
  "in_reply_to_status_id" : 558244084692049920,
  "created_at" : "2015-01-22 12:50:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/558244084692049920\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/zMXvWDM4Ko",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B79ICMpIYAESTQr.jpg",
      "id_str" : "558244081407909889",
      "id" : 558244081407909889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B79ICMpIYAESTQr.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/zMXvWDM4Ko"
    } ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37655818990306, 8.54842575431974 ]
  },
  "id_str" : "558244084692049920",
  "text" : "Cognitive Surplus (a bit outdated): hours spent on watching TV vs editing Wikipedia vs playing Angry Birds #cszh http:\/\/t.co\/zMXvWDM4Ko",
  "id" : 558244084692049920,
  "created_at" : "2015-01-22 12:45:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558210459149824000",
  "geo" : { },
  "id_str" : "558223929488470016",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ist in Arbeit so weit ich weiss. :)",
  "id" : 558223929488470016,
  "in_reply_to_status_id" : 558210459149824000,
  "created_at" : "2015-01-22 11:25:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/558209926309617665\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/kiTkNa9eXf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B78o965IEAEgEAt.jpg",
      "id_str" : "558209923063222273",
      "id" : 558209923063222273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B78o965IEAEgEAt.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/kiTkNa9eXf"
    } ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37654554770322, 8.548377337389194 ]
  },
  "id_str" : "558209926309617665",
  "text" : "Syntactic distribution of emojis in German &amp; French #cszh http:\/\/t.co\/kiTkNa9eXf",
  "id" : 558209926309617665,
  "created_at" : "2015-01-22 10:29:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/558208385402036224\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/T36Pg6RMIr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B78nkDjCAAAtbfo.jpg",
      "id_str" : "558208379198242816",
      "id" : 558208379198242816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B78nkDjCAAAtbfo.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/T36Pg6RMIr"
    } ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37655754705136, 8.548338519334921 ]
  },
  "id_str" : "558208385402036224",
  "text" : "Examples for the SMS corpora #cszh http:\/\/t.co\/T36Pg6RMIr",
  "id" : 558208385402036224,
  "created_at" : "2015-01-22 10:23:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37657999765656, 8.548370754484942 ]
  },
  "id_str" : "558206680455188480",
  "text" : "sms4science: generating crowd sourced corpora on SMS communication. #cszh",
  "id" : 558206680455188480,
  "created_at" : "2015-01-22 10:16:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558194683739144192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37657999765656, 8.548370754484942 ]
  },
  "id_str" : "558206106858950656",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju correlation, often actually showing causation ;)",
  "id" : 558206106858950656,
  "in_reply_to_status_id" : 558194683739144192,
  "created_at" : "2015-01-22 10:14:41 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/558205987136757760\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/g3Ln0Z6c6W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B78lYn8CAAEGEFq.jpg",
      "id_str" : "558205983785091073",
      "id" : 558205983785091073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B78lYn8CAAEGEFq.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/g3Ln0Z6c6W"
    } ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37657999765656, 8.548370754484942 ]
  },
  "id_str" : "558205987136757760",
  "text" : "Now: Studying Linguistic Variation with SMS &amp; WhatsApp #cszh http:\/\/t.co\/g3Ln0Z6c6W",
  "id" : 558205987136757760,
  "created_at" : "2015-01-22 10:14:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558194502054453248",
  "geo" : { },
  "id_str" : "558195062085922816",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski yes! ;-) but seriously: i guess \u00B1 continuous model optimisation would require lots of battery\/sending data around.",
  "id" : 558195062085922816,
  "in_reply_to_status_id" : 558194502054453248,
  "created_at" : "2015-01-22 09:30:48 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558194394176958464",
  "text" : "I\u2019d rather offer my data into the public domain than doing distributed likelihood calculations on my phone, eating on its battery life #cszh",
  "id" : 558194394176958464,
  "created_at" : "2015-01-22 09:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8cAfagIIAR",
      "expanded_url" : "http:\/\/www.slideshare.net\/gedankenstuecke\/crowdsourcing-the-analysis-of-genomes",
      "display_url" : "slideshare.net\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558190090363863042",
  "text" : "The slides for my presentation on openSNP can be found here: http:\/\/t.co\/8cAfagIIAR #cszh",
  "id" : 558190090363863042,
  "created_at" : "2015-01-22 09:11:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 3, 19 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 22, 38 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kevinschawinski\/status\/558183704552812546\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/iD3i092emC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B78RHM_CUAEbgX7.jpg",
      "id_str" : "558183694259605505",
      "id" : 558183694259605505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B78RHM_CUAEbgX7.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iD3i092emC"
    } ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558186410264768513",
  "text" : "RT @kevinschawinski: .@gedankenstuecke talks about what happens when people upload their genome to the internet #cszh http:\/\/t.co\/iD3i092emC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 1, 17 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kevinschawinski\/status\/558183704552812546\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/iD3i092emC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B78RHM_CUAEbgX7.jpg",
        "id_str" : "558183694259605505",
        "id" : 558183694259605505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B78RHM_CUAEbgX7.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iD3i092emC"
      } ],
      "hashtags" : [ {
        "text" : "cszh",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "558183704552812546",
    "text" : ".@gedankenstuecke talks about what happens when people upload their genome to the internet #cszh http:\/\/t.co\/iD3i092emC",
    "id" : 558183704552812546,
    "created_at" : "2015-01-22 08:45:40 +0000",
    "user" : {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "protected" : false,
      "id_str" : "242844365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765909514549886976\/CSbHdSCr_normal.jpg",
      "id" : 242844365,
      "verified" : true
    }
  },
  "id" : 558186410264768513,
  "created_at" : "2015-01-22 08:56:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37647681955304, 8.548404891308573 ]
  },
  "id_str" : "558173898689507330",
  "text" : "\u00ABPlease be anarchist in thought and word. But not in deed.\u00BB",
  "id" : 558173898689507330,
  "created_at" : "2015-01-22 08:06:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/Z2Ytzf9W8n",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2015\/01\/21\/how-to-recruit-a-good-bioinformatician\/",
      "display_url" : "biomickwatson.wordpress.com\/2015\/01\/21\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558018856623820800",
  "text" : "How to recruit a good bioinformatician https:\/\/t.co\/Z2Ytzf9W8n",
  "id" : 558018856623820800,
  "created_at" : "2015-01-21 21:50:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/iT0ktitrxq",
      "expanded_url" : "http:\/\/www.acgt.me\/blog\/2015\/1\/21\/unpronounceable-bioinformatics-database-names?utm_content=buffere902a&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "acgt.me\/blog\/2015\/1\/21\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558017783943139328",
  "text" : "Unpronounceable bioinformatics database names http:\/\/t.co\/iT0ktitrxq",
  "id" : 558017783943139328,
  "created_at" : "2015-01-21 21:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43958349411039, 8.565187313651599 ]
  },
  "id_str" : "557942602306433026",
  "text" : "Ohai, Zurich.",
  "id" : 557942602306433026,
  "created_at" : "2015-01-21 16:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557892827477471234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04992886239652, 8.570547613718928 ]
  },
  "id_str" : "557898221532762112",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me danke",
  "id" : 557898221532762112,
  "in_reply_to_status_id" : 557892827477471234,
  "created_at" : "2015-01-21 13:51:15 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/XuNUt3hngN",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/20\/7859325\/sitting-increase-risk-disease",
      "display_url" : "vox.com\/2015\/1\/20\/7859\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557870243083993091",
  "text" : "Sitting all day increases risk of disease, even with\u00A0exercise http:\/\/t.co\/XuNUt3hngN",
  "id" : 557870243083993091,
  "created_at" : "2015-01-21 12:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/zE8JtlCpEQ",
      "expanded_url" : "https:\/\/medium.com\/matter\/are-you-internet-sexual-1f855e113df",
      "display_url" : "medium.com\/matter\/are-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557855740015435778",
  "text" : "On being internet sexual https:\/\/t.co\/zE8JtlCpEQ",
  "id" : 557855740015435778,
  "created_at" : "2015-01-21 11:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 77, 83 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/PIgtNu2XeT",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/20\/bearded-shirtless-dude-dancing.html",
      "display_url" : "boingboing.net\/2015\/01\/20\/bea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557852414372757504",
  "text" : "maybe we could skip the square dance festival and go straight for bluegrass, @Lobot? http:\/\/t.co\/PIgtNu2XeT",
  "id" : 557852414372757504,
  "created_at" : "2015-01-21 10:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/BheTMlaKdm",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/20\/yuri-shwedoff-postapocalyptic.html",
      "display_url" : "boingboing.net\/2015\/01\/20\/yur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557851058077450240",
  "text" : "Yuri Shwedoff's captivating postapocalyptic\u00A0fantasyscapes http:\/\/t.co\/BheTMlaKdm",
  "id" : 557851058077450240,
  "created_at" : "2015-01-21 10:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 0, 13 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Wa92MWwZGs",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ot15KMxWPcw",
      "display_url" : "youtube.com\/watch?v=ot15KM\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "557838607667699713",
  "geo" : { },
  "id_str" : "557847919626567684",
  "in_reply_to_user_id" : 74624782,
  "text" : "@SvavarKnutur Happy birthday! Paying forward some weird wishes: https:\/\/t.co\/Wa92MWwZGs",
  "id" : 557847919626567684,
  "in_reply_to_status_id" : 557838607667699713,
  "created_at" : "2015-01-21 10:31:23 +0000",
  "in_reply_to_screen_name" : "SvavarKnutur",
  "in_reply_to_user_id_str" : "74624782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Excoffier",
      "screen_name" : "loronet",
      "indices" : [ 3, 11 ],
      "id_str" : "14441838",
      "id" : 14441838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/F5TsGScaR7",
      "expanded_url" : "http:\/\/is.gd\/imqbVW",
      "display_url" : "is.gd\/imqbVW"
    } ]
  },
  "geo" : { },
  "id_str" : "557827630830202880",
  "text" : "RT @loronet: Still looking for a motivated student to do a PhD in human genomics in Berne. See http:\/\/t.co\/F5TsGScaR7 for more information.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/F5TsGScaR7",
        "expanded_url" : "http:\/\/is.gd\/imqbVW",
        "display_url" : "is.gd\/imqbVW"
      } ]
    },
    "geo" : { },
    "id_str" : "557574362182606850",
    "text" : "Still looking for a motivated student to do a PhD in human genomics in Berne. See http:\/\/t.co\/F5TsGScaR7 for more information. Please RT",
    "id" : 557574362182606850,
    "created_at" : "2015-01-20 16:24:21 +0000",
    "user" : {
      "name" : "Laurent Excoffier",
      "screen_name" : "loronet",
      "protected" : false,
      "id_str" : "14441838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634339988499398656\/HLaf1I1V_normal.jpg",
      "id" : 14441838,
      "verified" : false
    }
  },
  "id" : 557827630830202880,
  "created_at" : "2015-01-21 09:10:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel S. Katz",
      "screen_name" : "danielskatz",
      "indices" : [ 3, 15 ],
      "id_str" : "19238958",
      "id" : 19238958
    }, {
      "name" : "LSST Astronomy",
      "screen_name" : "LSST",
      "indices" : [ 31, 36 ],
      "id_str" : "15813928",
      "id" : 15813928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557821812936282114",
  "text" : "RT @danielskatz: Kian-Tat Lim (@LSST): \"Scientists are like MacGyver. They can build anything but it will only last until the end of the ep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LSST Astronomy",
        "screen_name" : "LSST",
        "indices" : [ 14, 19 ],
        "id_str" : "15813928",
        "id" : 15813928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "557661920304824320",
    "text" : "Kian-Tat Lim (@LSST): \"Scientists are like MacGyver. They can build anything but it will only last until the end of the episode.\"",
    "id" : 557661920304824320,
    "created_at" : "2015-01-20 22:12:17 +0000",
    "user" : {
      "name" : "Daniel S. Katz",
      "screen_name" : "danielskatz",
      "protected" : false,
      "id_str" : "19238958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875403836738981888\/tcEb9VMi_normal.jpg",
      "id" : 19238958,
      "verified" : false
    }
  },
  "id" : 557821812936282114,
  "created_at" : "2015-01-21 08:47:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETH Z\u00FCrich",
      "screen_name" : "ETH",
      "indices" : [ 62, 66 ],
      "id_str" : "202806809",
      "id" : 202806809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/8KWqT0G4Zi",
      "expanded_url" : "http:\/\/www.imsb.ethz.ch\/news-and-events\/events\/citizenscienceworkshop\/Program.html",
      "display_url" : "imsb.ethz.ch\/news-and-event\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09467756719134, 8.798705239478604 ]
  },
  "id_str" : "557820249161351168",
  "text" : "Guess you can still register for the citizen science workshop @ETH. If you happen to be in Zurich the next 2 days: http:\/\/t.co\/8KWqT0G4Zi",
  "id" : 557820249161351168,
  "created_at" : "2015-01-21 08:41:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Milton Tan",
      "screen_name" : "mt_ur_mind",
      "indices" : [ 3, 14 ],
      "id_str" : "872526996814909440",
      "id" : 872526996814909440
    }, {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 17, 24 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/uy09VmSlJ6",
      "expanded_url" : "http:\/\/blog.pacificbiosciences.com\/2015\/01\/looking-ahead-2015-pacbio-technology.html",
      "display_url" : "blog.pacificbiosciences.com\/2015\/01\/lookin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557819254045954048",
  "text" : "RT @mt_ur_mind: .@PacBio planning to cross the point of ~1x coverage per SMRT cell for many vertebrates soon. http:\/\/t.co\/uy09VmSlJ6 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PacBio",
        "screen_name" : "PacBio",
        "indices" : [ 1, 8 ],
        "id_str" : "39694489",
        "id" : 39694489
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mt_ur_mind\/status\/557677393100689408\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/hHB6U5Z6fd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B71Eol_IcAED_Ch.png",
        "id_str" : "557677393046171649",
        "id" : 557677393046171649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B71Eol_IcAED_Ch.png",
        "sizes" : [ {
          "h" : 92,
          "resize" : "crop",
          "w" : 92
        }, {
          "h" : 92,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 91,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 92,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 92,
          "resize" : "fit",
          "w" : 686
        } ],
        "display_url" : "pic.twitter.com\/hHB6U5Z6fd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/uy09VmSlJ6",
        "expanded_url" : "http:\/\/blog.pacificbiosciences.com\/2015\/01\/looking-ahead-2015-pacbio-technology.html",
        "display_url" : "blog.pacificbiosciences.com\/2015\/01\/lookin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557677393100689408",
    "text" : ".@PacBio planning to cross the point of ~1x coverage per SMRT cell for many vertebrates soon. http:\/\/t.co\/uy09VmSlJ6 http:\/\/t.co\/hHB6U5Z6fd",
    "id" : 557677393100689408,
    "created_at" : "2015-01-20 23:13:46 +0000",
    "user" : {
      "name" : "Milton Tan",
      "screen_name" : "mtanichthys",
      "protected" : false,
      "id_str" : "56302593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479747113425711104\/kFVKmkhB_normal.jpeg",
      "id" : 56302593,
      "verified" : false
    }
  },
  "id" : 557819254045954048,
  "created_at" : "2015-01-21 08:37:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Jonathan\uD83C\uDF39Mann)))",
      "screen_name" : "songadaymann",
      "indices" : [ 3, 16 ],
      "id_str" : "8632762",
      "id" : 8632762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/fi72sKQOOV",
      "expanded_url" : "http:\/\/youtu.be\/9odBeuK251o",
      "display_url" : "youtu.be\/9odBeuK251o"
    } ]
  },
  "geo" : { },
  "id_str" : "557581092694552578",
  "text" : "RT @songadaymann: I'm soooooo excited to share with you:\n\n\u266B THE MANSPLAINER \u266B\n\nhttp:\/\/t.co\/fi72sKQOOV\n\nMy collaboration with @TheDoubleclic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Doubleclicks",
        "screen_name" : "TheDoubleclicks",
        "indices" : [ 107, 123 ],
        "id_str" : "242923569",
        "id" : 242923569
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/fi72sKQOOV",
        "expanded_url" : "http:\/\/youtu.be\/9odBeuK251o",
        "display_url" : "youtu.be\/9odBeuK251o"
      } ]
    },
    "geo" : { },
    "id_str" : "557574676164378624",
    "text" : "I'm soooooo excited to share with you:\n\n\u266B THE MANSPLAINER \u266B\n\nhttp:\/\/t.co\/fi72sKQOOV\n\nMy collaboration with @TheDoubleclicks!!!",
    "id" : 557574676164378624,
    "created_at" : "2015-01-20 16:25:36 +0000",
    "user" : {
      "name" : "(((Jonathan\uD83C\uDF39Mann)))",
      "screen_name" : "songadaymann",
      "protected" : false,
      "id_str" : "8632762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684858570429612034\/u4ICWS0C_normal.jpg",
      "id" : 8632762,
      "verified" : true
    }
  },
  "id" : 557581092694552578,
  "created_at" : "2015-01-20 16:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shanley",
      "screen_name" : "shanley",
      "indices" : [ 3, 11 ],
      "id_str" : "50462250",
      "id" : 50462250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557562329173594114",
  "text" : "RT @shanley: This is my statement on my experiences over the past few days. Please read if you've been following it at all. http:\/\/t.co\/AQu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/AQuSk8Gay8",
        "expanded_url" : "http:\/\/pastebin.com\/3jAQARCy",
        "display_url" : "pastebin.com\/3jAQARCy"
      } ]
    },
    "geo" : { },
    "id_str" : "557551556262768640",
    "text" : "This is my statement on my experiences over the past few days. Please read if you've been following it at all. http:\/\/t.co\/AQuSk8Gay8",
    "id" : 557551556262768640,
    "created_at" : "2015-01-20 14:53:44 +0000",
    "user" : {
      "name" : "shanley",
      "screen_name" : "shanley",
      "protected" : false,
      "id_str" : "50462250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753060867302760451\/evCRynOH_normal.jpg",
      "id" : 50462250,
      "verified" : false
    }
  },
  "id" : 557562329173594114,
  "created_at" : "2015-01-20 15:36:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557546184127303680",
  "text" : "RT @TheScienceWeb: 80% of scientists disgusted at scientists who laughed at 80% of people who think food containing DNA ... https:\/\/t.co\/wM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/wMxYnzbe1A",
        "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/01\/20\/80-of-scientists-disgusted-at-the-80-of-scientists-who-laughed-at-the-80-of-people-who-think-food-containing-dna-should-be-labelled\/",
        "display_url" : "thescienceweb.wordpress.com\/2015\/01\/20\/80-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557544900221476865",
    "text" : "80% of scientists disgusted at scientists who laughed at 80% of people who think food containing DNA ... https:\/\/t.co\/wMxYnzbe1A",
    "id" : 557544900221476865,
    "created_at" : "2015-01-20 14:27:17 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 557546184127303680,
  "created_at" : "2015-01-20 14:32:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD835\uDE73\u0430\u0578\u0456\u0435\u04CF",
      "screen_name" : "DubioserKerl",
      "indices" : [ 0, 13 ],
      "id_str" : "56974526",
      "id" : 56974526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/xT9eCngY2B",
      "expanded_url" : "http:\/\/crev.info\/2013\/07\/longevity-of-dna-estimated\/",
      "display_url" : "crev.info\/2013\/07\/longev\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "557455933107081216",
  "geo" : { },
  "id_str" : "557458249059160065",
  "in_reply_to_user_id" : 56974526,
  "text" : "@DubioserKerl imho: Lagern ist kein Problem (bis zu einem Punkt: http:\/\/t.co\/xT9eCngY2B), die Pastaherstellung auch nicht.",
  "id" : 557458249059160065,
  "in_reply_to_status_id" : 557455933107081216,
  "created_at" : "2015-01-20 08:42:58 +0000",
  "in_reply_to_screen_name" : "DubioserKerl",
  "in_reply_to_user_id_str" : "56974526",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD835\uDE73\u0430\u0578\u0456\u0435\u04CF",
      "screen_name" : "DubioserKerl",
      "indices" : [ 0, 13 ],
      "id_str" : "56974526",
      "id" : 56974526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557449068977598464",
  "geo" : { },
  "id_str" : "557453706388852737",
  "in_reply_to_user_id" : 56974526,
  "text" : "@DubioserKerl z.B.? :)",
  "id" : 557453706388852737,
  "in_reply_to_status_id" : 557449068977598464,
  "created_at" : "2015-01-20 08:24:55 +0000",
  "in_reply_to_screen_name" : "DubioserKerl",
  "in_reply_to_user_id_str" : "56974526",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ninakix",
      "screen_name" : "ninakix",
      "indices" : [ 82, 90 ],
      "id_str" : "9366972",
      "id" : 9366972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/k1JJzNUfnk",
      "expanded_url" : "http:\/\/dotsies.org\/",
      "display_url" : "dotsies.org"
    } ]
  },
  "geo" : { },
  "id_str" : "557453451119321088",
  "text" : "\u00ABDotsies is a font that uses dots instead of letters.\u00BB http:\/\/t.co\/k1JJzNUfnk \/HT @ninakix",
  "id" : 557453451119321088,
  "created_at" : "2015-01-20 08:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/c6qrdCGXWf",
      "expanded_url" : "http:\/\/rrresearch.fieldofscience.com\/2015\/01\/is-there-dna-in-oreos.html",
      "display_url" : "rrresearch.fieldofscience.com\/2015\/01\/is-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557447523502399488",
  "text" : "Is there DNA in oreos? http:\/\/t.co\/c6qrdCGXWf",
  "id" : 557447523502399488,
  "created_at" : "2015-01-20 08:00:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557443046594584577",
  "text" : "\u00ABUh, Mist! Weisst du wo Google meine Kontakte speichert?\u00BB \u2013 \u00ABMh, in der Cloud?\u00BB",
  "id" : 557443046594584577,
  "created_at" : "2015-01-20 07:42:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle \uD83C\uDF7B\uD83D\uDC40\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDFC3\uD83C\uDFFC",
      "screen_name" : "kyleve",
      "indices" : [ 3, 10 ],
      "id_str" : "14680556",
      "id" : 14680556
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kyleve\/status\/557290788963368960\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/VOfBOknM5u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7vlBPqCAAEZ4SB.jpg",
      "id_str" : "557290788455841793",
      "id" : 557290788455841793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7vlBPqCAAEZ4SB.jpg",
      "sizes" : [ {
        "h" : 1170,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 1772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 1772
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/VOfBOknM5u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557305349175521281",
  "text" : "RT @kyleve: Software, 2015 \u2013 http:\/\/t.co\/VOfBOknM5u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kyleve\/status\/557290788963368960\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/VOfBOknM5u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7vlBPqCAAEZ4SB.jpg",
        "id_str" : "557290788455841793",
        "id" : 557290788455841793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7vlBPqCAAEZ4SB.jpg",
        "sizes" : [ {
          "h" : 1170,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1728,
          "resize" : "fit",
          "w" : 1772
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1728,
          "resize" : "fit",
          "w" : 1772
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/VOfBOknM5u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "557290788963368960",
    "text" : "Software, 2015 \u2013 http:\/\/t.co\/VOfBOknM5u",
    "id" : 557290788963368960,
    "created_at" : "2015-01-19 21:37:32 +0000",
    "user" : {
      "name" : "Kyle \uD83C\uDF7B\uD83D\uDC40\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDFC3\uD83C\uDFFC",
      "screen_name" : "kyleve",
      "protected" : false,
      "id_str" : "14680556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917935969264791552\/NKIhzT4A_normal.jpg",
      "id" : 14680556,
      "verified" : false
    }
  },
  "id" : 557305349175521281,
  "created_at" : "2015-01-19 22:35:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/uGc3nOrUX1",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/01\/the-math-of-organ-donation-kidneys-are-an-np-hard-problem\/",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557251897430921217",
  "text" : "The math of organ donation: Kidneys are an NP-hard problem http:\/\/t.co\/uGc3nOrUX1",
  "id" : 557251897430921217,
  "created_at" : "2015-01-19 19:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/UKSXx0MZDM",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0167701215000032",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557210012075196416",
  "text" : "Wait, why would you run SPAdes with only a single k? (a weird paper in general) http:\/\/t.co\/UKSXx0MZDM",
  "id" : 557210012075196416,
  "created_at" : "2015-01-19 16:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557201245556195328",
  "text" : "Do you use MP, ML or Bayesian tree reconstruction to build trees of diverging manuscript copies?",
  "id" : 557201245556195328,
  "created_at" : "2015-01-19 15:41:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/l8pfgRtuRD",
      "expanded_url" : "http:\/\/fuzzzbeed.herokuapp.com\/users\/isaacpeterson\/the-25-splendid-snails-you-probably-didnt-know#.mvex0AqZB",
      "display_url" : "fuzzzbeed.herokuapp.com\/users\/isaacpet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557125252850143232",
  "text" : "Hilarious: \u00ABThe 25 Splendid Snails You Probably Didn't Know\u00BB http:\/\/t.co\/l8pfgRtuRD",
  "id" : 557125252850143232,
  "created_at" : "2015-01-19 10:39:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557123851457687552",
  "text" : "\u00ABI went iceskating for the first time in my life this weekend. I had a couple of good, even great falls!\u00BB",
  "id" : 557123851457687552,
  "created_at" : "2015-01-19 10:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dTnehnCFe3",
      "expanded_url" : "http:\/\/www.brandeins.de\/archiv\/2014\/genuss\/kurt-starke-im-interview-die-liebe-ist-nicht-totzukriegen\/",
      "display_url" : "brandeins.de\/archiv\/2014\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557120744396951552",
  "text" : "\u00ABJugendliche sind an vielem interessiert, auch an Sex, aber eben nicht nur. Auf Platz 1 ist immer noch die Musik\u00BB http:\/\/t.co\/dTnehnCFe3",
  "id" : 557120744396951552,
  "created_at" : "2015-01-19 10:21:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/KwlEJgjIQl",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2015\/01\/jpm-wrap-up.html",
      "display_url" : "omicsomics.blogspot.de\/2015\/01\/jpm-wr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557109555986169856",
  "text" : "Sequencing: JPM Wrap-Up http:\/\/t.co\/KwlEJgjIQl",
  "id" : 557109555986169856,
  "created_at" : "2015-01-19 09:37:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/uch44xfitC",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/news-desk\/year-marriage-equality",
      "display_url" : "newyorker.com\/news\/news-desk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557102216059056130",
  "text" : "The Year of Marriage Equality http:\/\/t.co\/uch44xfitC",
  "id" : 557102216059056130,
  "created_at" : "2015-01-19 09:08:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/120pHkjX4r",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2015\/01\/18\/machine-learning-exceeding-chance-by-chance\/#.VLzDGi7F9dI",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557095818168369152",
  "text" : "Machine Learning: Exceeding Chance Level By Chance http:\/\/t.co\/120pHkjX4r",
  "id" : 557095818168369152,
  "created_at" : "2015-01-19 08:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 93, 106 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/FOvfApu4sa",
      "expanded_url" : "http:\/\/schatzlab.cshl.edu\/presentations\/2015.01.13.PAG.Bioinformatics.Oxford%20Nanopore%20Assembly.pdf",
      "display_url" : "schatzlab.cshl.edu\/presentations\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557094089326604290",
  "text" : "Hybrid Error Correction and de novo Assembly with Oxford Nanopore http:\/\/t.co\/FOvfApu4sa \/HT @PhilippBayer (iirc)",
  "id" : 557094089326604290,
  "created_at" : "2015-01-19 08:35:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557083247445045248",
  "text" : "bahnticket\/b\u00FCroschl\u00FCssel nicht zu finden \u2713\ncluster akzeptiert meinen key nicht mehr \u2713\nhome directory ist verschwunden \u2713",
  "id" : 557083247445045248,
  "created_at" : "2015-01-19 07:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/P2f0EtbrUH",
      "expanded_url" : "http:\/\/www.r-bloggers.com\/k-means-clustering-is-not-a-free-lunch\/",
      "display_url" : "r-bloggers.com\/k-means-cluste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556822713155997696",
  "text" : "K-means clustering is not a free lunch http:\/\/t.co\/P2f0EtbrUH",
  "id" : 556822713155997696,
  "created_at" : "2015-01-18 14:37:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/8ct7C7u3Pe",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/technology\/what-our-messages-to-et-say-about-us\/",
      "display_url" : "aeon.co\/magazine\/techn\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114484, 8.750245 ]
  },
  "id_str" : "556754603287797760",
  "text" : "What will a crowdsourced message say to ET? http:\/\/t.co\/8ct7C7u3Pe",
  "id" : 556754603287797760,
  "created_at" : "2015-01-18 10:06:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556597761789808643",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599255175, 8.759902090359521 ]
  },
  "id_str" : "556599623427837952",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann all the best for all of you. And well done :)",
  "id" : 556599623427837952,
  "in_reply_to_status_id" : 556597761789808643,
  "created_at" : "2015-01-17 23:51:06 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETH Z\u00FCrich",
      "screen_name" : "ETH",
      "indices" : [ 3, 7 ],
      "id_str" : "202806809",
      "id" : 202806809
    }, {
      "name" : "CitizenScience",
      "screen_name" : "CitizenScience_",
      "indices" : [ 38, 54 ],
      "id_str" : "448552985",
      "id" : 448552985
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 71, 82 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Citizen_Science",
      "indices" : [ 20, 36 ]
    }, {
      "text" : "Effy_Vayena",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/J3Lz781iXd",
      "expanded_url" : "http:\/\/bit.ly\/1BaGV2u",
      "display_url" : "bit.ly\/1BaGV2u"
    } ]
  },
  "geo" : { },
  "id_str" : "556510667042488320",
  "text" : "RT @ETH: Was bringt #Citizen_Science (@CitizenScience_)? #Effy_Vayena (@EffyVayena ) im Interview: http:\/\/t.co\/J3Lz781iXd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CitizenScience",
        "screen_name" : "CitizenScience_",
        "indices" : [ 29, 45 ],
        "id_str" : "448552985",
        "id" : 448552985
      }, {
        "name" : "Effy Vayena",
        "screen_name" : "EffyVayena",
        "indices" : [ 62, 73 ],
        "id_str" : "397518511",
        "id" : 397518511
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Citizen_Science",
        "indices" : [ 11, 27 ]
      }, {
        "text" : "Effy_Vayena",
        "indices" : [ 48, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/J3Lz781iXd",
        "expanded_url" : "http:\/\/bit.ly\/1BaGV2u",
        "display_url" : "bit.ly\/1BaGV2u"
      } ]
    },
    "geo" : { },
    "id_str" : "556068735069724672",
    "text" : "Was bringt #Citizen_Science (@CitizenScience_)? #Effy_Vayena (@EffyVayena ) im Interview: http:\/\/t.co\/J3Lz781iXd",
    "id" : 556068735069724672,
    "created_at" : "2015-01-16 12:41:32 +0000",
    "user" : {
      "name" : "ETH Z\u00FCrich",
      "screen_name" : "ETH",
      "protected" : false,
      "id_str" : "202806809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000473502381\/20b08fa38f1365b96da392c3276a5699_normal.png",
      "id" : 202806809,
      "verified" : true
    }
  },
  "id" : 556510667042488320,
  "created_at" : "2015-01-17 17:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    }, {
      "name" : "The CSU",
      "screen_name" : "calstate",
      "indices" : [ 17, 26 ],
      "id_str" : "15967775",
      "id" : 15967775
    }, {
      "name" : "Paul Orwin",
      "screen_name" : "PMOrwin",
      "indices" : [ 124, 132 ],
      "id_str" : "377150513",
      "id" : 377150513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/nlckmTCprq",
      "expanded_url" : "http:\/\/www.infodocket.com\/2015\/01\/08\/california-state-university-libraries-end-system-wide-subscription-to-wiley-electronic-journals-package\/",
      "display_url" : "infodocket.com\/2015\/01\/08\/cal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556508786199113728",
  "text" : "RT @hormiga: All @calstate campus ditch all Wiley journals, rather than give in to price gouging. http:\/\/t.co\/nlckmTCprq ht @PMOrwin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The CSU",
        "screen_name" : "calstate",
        "indices" : [ 4, 13 ],
        "id_str" : "15967775",
        "id" : 15967775
      }, {
        "name" : "Paul Orwin",
        "screen_name" : "PMOrwin",
        "indices" : [ 111, 119 ],
        "id_str" : "377150513",
        "id" : 377150513
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/nlckmTCprq",
        "expanded_url" : "http:\/\/www.infodocket.com\/2015\/01\/08\/california-state-university-libraries-end-system-wide-subscription-to-wiley-electronic-journals-package\/",
        "display_url" : "infodocket.com\/2015\/01\/08\/cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555466225502150656",
    "text" : "All @calstate campus ditch all Wiley journals, rather than give in to price gouging. http:\/\/t.co\/nlckmTCprq ht @PMOrwin",
    "id" : 555466225502150656,
    "created_at" : "2015-01-14 20:47:22 +0000",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 556508786199113728,
  "created_at" : "2015-01-17 17:50:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/4XK9NhRdwg",
      "expanded_url" : "http:\/\/www.thebigroundtable.com\/stories\/damage\/",
      "display_url" : "thebigroundtable.com\/stories\/damage\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110666, 8.759902 ]
  },
  "id_str" : "556228396343390209",
  "text" : "Damage http:\/\/t.co\/4XK9NhRdwg",
  "id" : 556228396343390209,
  "created_at" : "2015-01-16 23:15:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556164701852545024",
  "geo" : { },
  "id_str" : "556164847311020032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, nice. thanks :)",
  "id" : 556164847311020032,
  "in_reply_to_status_id" : 556164701852545024,
  "created_at" : "2015-01-16 19:03:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 74, 87 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SheqSxnKUM",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/fIXOykL3WKg\/info%3Adoi%2F10.1371%2Fjournal.pone.0116656",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556135971054686208",
  "text" : "Ontology-Based Data Integration between Clinical and Research Systems \/cc @PhilippBayer  http:\/\/t.co\/SheqSxnKUM",
  "id" : 556135971054686208,
  "created_at" : "2015-01-16 17:08:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3msO7i59O1",
      "expanded_url" : "http:\/\/simplystatistics.org\/2015\/01\/15\/how-to-find-the-science-paper-behind-a-headline-when-the-link-is-missing\/",
      "display_url" : "simplystatistics.org\/2015\/01\/15\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.148343, 8.665826 ]
  },
  "id_str" : "556134173866754048",
  "text" : "Because academic PR offices suck: \u00ABHow to find the science paper behind a headline when the link is missing\u00BB http:\/\/t.co\/3msO7i59O1",
  "id" : 556134173866754048,
  "created_at" : "2015-01-16 17:01:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/043tSqJQgj",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/01\/the-cathedral-of-computation\/384300\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556133442732056577",
  "text" : "\u00ABAlgorithms aren\u2019t gods. We need not believe that they rule the world in order to admit that they influence it\u00BB http:\/\/t.co\/043tSqJQgj",
  "id" : 556133442732056577,
  "created_at" : "2015-01-16 16:58:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/6g3Ne7OEEy",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/15\/7551873\/jaywalking-history",
      "display_url" : "vox.com\/2015\/1\/15\/7551\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556100551474429952",
  "text" : "The forgotten history of how automakers invented the crime of\u00A0\"jaywalking\" http:\/\/t.co\/6g3Ne7OEEy",
  "id" : 556100551474429952,
  "created_at" : "2015-01-16 14:47:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/spp6aJd5h6",
      "expanded_url" : "https:\/\/www.pinterest.com\/mariscavanagh\/stone-pathways-rocks-and-lichen\/",
      "display_url" : "pinterest.com\/mariscavanagh\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556032911280177153",
  "text" : "Not exactly what I was looking for when I searched for \u201Clichen pathways\u201D. https:\/\/t.co\/spp6aJd5h6",
  "id" : 556032911280177153,
  "created_at" : "2015-01-16 10:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556030997641564160",
  "text" : "Dear SEO, writing to a vegetarian blog author to ask whether he would advertise your ebook \u201Chow to fatten a pig\u201D isn\u2019t the smartest idea\u2026",
  "id" : 556030997641564160,
  "created_at" : "2015-01-16 10:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556021815420919808",
  "text" : "argh, citation scavenger hunt\u2026 it\u2019s paywalls all the way down\u2026",
  "id" : 556021815420919808,
  "created_at" : "2015-01-16 09:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/oHaA1Dc0cJ",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/15\/feminist-sex-positions-nsfw.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/01\/15\/fem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556004540466880513",
  "text" : "Feminist Sex Positions http:\/\/t.co\/oHaA1Dc0cJ",
  "id" : 556004540466880513,
  "created_at" : "2015-01-16 08:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/iTUJR1ed3R",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/15\/the-worlds-angriest-guitar-pla.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/01\/15\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555999847640477696",
  "text" : "How to play the guitar. In 3 simple steps.  http:\/\/t.co\/iTUJR1ed3R",
  "id" : 555999847640477696,
  "created_at" : "2015-01-16 08:07:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/40pUky8ge5",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/qBrWY2GGfYo\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555997969615712256",
  "text" : "Mintal Condition http:\/\/t.co\/40pUky8ge5",
  "id" : 555997969615712256,
  "created_at" : "2015-01-16 08:00:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555888042561380353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414898564118, 8.753566397362158 ]
  },
  "id_str" : "555986802109321216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s probably too late but I will. Also: my phone is +49 176 21304466",
  "id" : 555986802109321216,
  "in_reply_to_status_id" : 555888042561380353,
  "created_at" : "2015-01-16 07:15:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "indices" : [ 3, 18 ],
      "id_str" : "14962567",
      "id" : 14962567
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 95, 102 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555844798616469504",
  "text" : "RT @larsjuhljensen: I did not expect that firm a response from a scientific journal. Well done @nature - \"Science and satire\" http:\/\/t.co\/e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nature",
        "screen_name" : "nature",
        "indices" : [ 75, 82 ],
        "id_str" : "487833518",
        "id" : 487833518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/eVY3UWQb6w",
        "expanded_url" : "http:\/\/www.nature.com\/news\/science-and-satire-1.16703",
        "display_url" : "nature.com\/news\/science-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555453452718194689",
    "text" : "I did not expect that firm a response from a scientific journal. Well done @nature - \"Science and satire\" http:\/\/t.co\/eVY3UWQb6w",
    "id" : 555453452718194689,
    "created_at" : "2015-01-14 19:56:37 +0000",
    "user" : {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "protected" : false,
      "id_str" : "14962567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545518738791878656\/llrzPOuU_normal.jpeg",
      "id" : 14962567,
      "verified" : false
    }
  },
  "id" : 555844798616469504,
  "created_at" : "2015-01-15 21:51:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/g3WZzHd92P",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v404\/n6778\/abs\/404564a0.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555831457953095680",
  "text" : "the title sounds like a rather depressing story: \u00ABReproductive systems: Sex and the single lichen\u00BB http:\/\/t.co\/g3WZzHd92P",
  "id" : 555831457953095680,
  "created_at" : "2015-01-15 20:58:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555789389985378304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "555798715303469056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer take S8 or S9 to Hauptwache and from there U8 or U3 to Riedberg (U8) or Niederursel (U3).",
  "id" : 555798715303469056,
  "in_reply_to_status_id" : 555789389985378304,
  "created_at" : "2015-01-15 18:48:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555789389985378304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "555798492460122112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you get my email I sent w\/ instructions yesterdayish?",
  "id" : 555798492460122112,
  "in_reply_to_status_id" : 555789389985378304,
  "created_at" : "2015-01-15 18:47:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/V41U6kJopt",
      "expanded_url" : "http:\/\/instagram.com\/p\/x4bch8Bwhb\/",
      "display_url" : "instagram.com\/p\/x4bch8Bwhb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "555767022316171264",
  "text" : "No smoking http:\/\/t.co\/V41U6kJopt",
  "id" : 555767022316171264,
  "created_at" : "2015-01-15 16:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Matt Vaughn \u26C5\uFE0F",
      "screen_name" : "mattdotvaughn",
      "indices" : [ 17, 31 ],
      "id_str" : "215822029",
      "id" : 215822029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555755642712236033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08946547307106, 8.738326429934123 ]
  },
  "id_str" : "555757033522495488",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @mattdotvaughn but no one cares about \u201Cgood, let alone \u201Dbest\u201C ;)",
  "id" : 555757033522495488,
  "in_reply_to_status_id" : 555755642712236033,
  "created_at" : "2015-01-15 16:02:56 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Vaughn \u26C5\uFE0F",
      "screen_name" : "mattdotvaughn",
      "indices" : [ 0, 14 ],
      "id_str" : "215822029",
      "id" : 215822029
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 15, 31 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555721999712915456",
  "geo" : { },
  "id_str" : "555753243100594176",
  "in_reply_to_user_id" : 215822029,
  "text" : "@mattdotvaughn @pathogenomenick mind you, it\u2019s \u2018novel insights\u2019! :p",
  "id" : 555753243100594176,
  "in_reply_to_status_id" : 555721999712915456,
  "created_at" : "2015-01-15 15:47:53 +0000",
  "in_reply_to_screen_name" : "mattdotvaughn",
  "in_reply_to_user_id_str" : "215822029",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555736715940601856",
  "text" : "Verh\u00F6rt: \u00ABHallo? Hier sind die Schweine von der ABG. Wir m\u00FCssten mal ins Treppenhaus.\u00BB",
  "id" : 555736715940601856,
  "created_at" : "2015-01-15 14:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555732664335237121",
  "text" : "Mixed Messages: \u00ABThis does not guarantee admission; a CBP officer will have the final determination. Have a nice trip. Welcome to the US.\u00BB",
  "id" : 555732664335237121,
  "created_at" : "2015-01-15 14:26:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ff33UaNcjI",
      "expanded_url" : "http:\/\/philarcher.org\/diary\/2015\/50shadesofno\/",
      "display_url" : "philarcher.org\/diary\/2015\/50s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555725091544518657",
  "text" : "Reasons why we can\u2019t have nice things*: Fifty Shades of No http:\/\/t.co\/ff33UaNcjI *opendata",
  "id" : 555725091544518657,
  "created_at" : "2015-01-15 13:56:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    }, {
      "name" : "Frazer Meacham",
      "screen_name" : "FMeacham",
      "indices" : [ 96, 105 ],
      "id_str" : "297600842",
      "id" : 297600842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/RWK40xHMu8",
      "expanded_url" : "http:\/\/arxiv.org\/pdf\/1501.03205v1.pdf",
      "display_url" : "arxiv.org\/pdf\/1501.03205\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555716050843889666",
  "text" : "RT @lpachter: Why has evolution left us vulnerable to anxiety disorders? http:\/\/t.co\/RWK40xHMu8 @FMeacham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frazer Meacham",
        "screen_name" : "FMeacham",
        "indices" : [ 82, 91 ],
        "id_str" : "297600842",
        "id" : 297600842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/RWK40xHMu8",
        "expanded_url" : "http:\/\/arxiv.org\/pdf\/1501.03205v1.pdf",
        "display_url" : "arxiv.org\/pdf\/1501.03205\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555703915027505152",
    "text" : "Why has evolution left us vulnerable to anxiety disorders? http:\/\/t.co\/RWK40xHMu8 @FMeacham",
    "id" : 555703915027505152,
    "created_at" : "2015-01-15 12:31:52 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 555716050843889666,
  "created_at" : "2015-01-15 13:20:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555707114988273664",
  "text" : "No matter how much open (.*) activism you do, there comes the point where you are forced to install Word to work on a manuscript\u2026",
  "id" : 555707114988273664,
  "created_at" : "2015-01-15 12:44:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555669405615804416",
  "text" : "Every time I read over the \u2018ToS\u2019 of openSNP I\u2019m briefly scared. I\u2019ll just take that as a good sign.",
  "id" : 555669405615804416,
  "created_at" : "2015-01-15 10:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/555647175905275904\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/1M7ASDQWM1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7YOKOYCEAEPOAw.jpg",
      "id_str" : "555647172847210497",
      "id" : 555647172847210497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7YOKOYCEAEPOAw.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1M7ASDQWM1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12414546908059, 8.917770628722092 ]
  },
  "id_str" : "555647175905275904",
  "text" : "Na das macht den Zoll ja gleich viel attraktiver o_O http:\/\/t.co\/1M7ASDQWM1",
  "id" : 555647175905275904,
  "created_at" : "2015-01-15 08:46:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555303205211742211",
  "geo" : { },
  "id_str" : "555303575971463168",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon aye, den Eindruck hatte ich auch bei \u201Cmeinen\u201D Themen. Dass + Lehrer hat mein Fandom gebremst.",
  "id" : 555303575971463168,
  "in_reply_to_status_id" : 555303205211742211,
  "created_at" : "2015-01-14 10:01:04 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cNTnvYnckt",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/233381-our-listeners\/",
      "display_url" : "radiolab.org\/story\/233381-o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "555300090802626560",
  "geo" : { },
  "id_str" : "555300660607197184",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon ja, das war sehr entt\u00E4uschend. Sie haben danach aber wohl ein bisschen editing betrieben: http:\/\/t.co\/cNTnvYnckt",
  "id" : 555300660607197184,
  "in_reply_to_status_id" : 555300090802626560,
  "created_at" : "2015-01-14 09:49:29 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/fJ5iFzo569",
      "expanded_url" : "http:\/\/www.poynter.org\/news\/mediawire\/183515\/wnyc-no-reason-to-believe-that-jonah-lehrers-work-for-radiolab-is-compromised\/",
      "display_url" : "poynter.org\/news\/mediawire\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "555298635559473152",
  "geo" : { },
  "id_str" : "555299384611856384",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon allgemein, e.g. http:\/\/t.co\/fJ5iFzo569",
  "id" : 555299384611856384,
  "in_reply_to_status_id" : 555298635559473152,
  "created_at" : "2015-01-14 09:44:24 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/2uuT4KUFQn",
      "expanded_url" : "http:\/\/mosaicscience.com\/story\/breaking-bad-news",
      "display_url" : "mosaicscience.com\/story\/breaking\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555298582220537857",
  "text" : "Breaking bad news http:\/\/t.co\/2uuT4KUFQn",
  "id" : 555298582220537857,
  "created_at" : "2015-01-14 09:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/MZA9rcPDVR",
      "expanded_url" : "http:\/\/instagram.com\/p\/x1FvwRBwlG\/",
      "display_url" : "instagram.com\/p\/x1FvwRBwlG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "555297091753607168",
  "text" : "\u00ABWieso pustest du unsere Pflanzen an?!\u00BB http:\/\/t.co\/MZA9rcPDVR",
  "id" : 555297091753607168,
  "created_at" : "2015-01-14 09:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 3, 8 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Lockheed Martin",
      "screen_name" : "LockheedMartin",
      "indices" : [ 22, 37 ],
      "id_str" : "42871498",
      "id" : 42871498
    }, {
      "name" : "Illumina",
      "screen_name" : "illumina",
      "indices" : [ 58, 67 ],
      "id_str" : "46145761",
      "id" : 46145761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/K2pM4LVFfa",
      "expanded_url" : "http:\/\/lmt.co\/1xXxHnM",
      "display_url" : "lmt.co\/1xXxHnM"
    } ]
  },
  "geo" : { },
  "id_str" : "555295916102795264",
  "text" : "RT @klmr: Disgusting. @LockheedMartin: We're working with @Illumina to build personalized #healthcare's future: http:\/\/t.co\/K2pM4LVFfa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lockheed Martin",
        "screen_name" : "LockheedMartin",
        "indices" : [ 12, 27 ],
        "id_str" : "42871498",
        "id" : 42871498
      }, {
        "name" : "Illumina",
        "screen_name" : "illumina",
        "indices" : [ 48, 57 ],
        "id_str" : "46145761",
        "id" : 46145761
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthcare",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/K2pM4LVFfa",
        "expanded_url" : "http:\/\/lmt.co\/1xXxHnM",
        "display_url" : "lmt.co\/1xXxHnM"
      } ]
    },
    "in_reply_to_status_id_str" : "555084562242756608",
    "geo" : { },
    "id_str" : "555293643238805504",
    "in_reply_to_user_id" : 42871498,
    "text" : "Disgusting. @LockheedMartin: We're working with @Illumina to build personalized #healthcare's future: http:\/\/t.co\/K2pM4LVFfa",
    "id" : 555293643238805504,
    "in_reply_to_status_id" : 555084562242756608,
    "created_at" : "2015-01-14 09:21:36 +0000",
    "in_reply_to_screen_name" : "LockheedMartin",
    "in_reply_to_user_id_str" : "42871498",
    "user" : {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "protected" : false,
      "id_str" : "773450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2617576817\/4n2x4ln6fqopk944375r_normal.jpeg",
      "id" : 773450,
      "verified" : false
    }
  },
  "id" : 555295916102795264,
  "created_at" : "2015-01-14 09:30:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555293806325952513",
  "geo" : { },
  "id_str" : "555295415613272064",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Ich hab Radiolab den unkritischen Umgang mit J. Lehrer noch nicht verziehen. C.f. TAL &amp; M. Daisey\u2026",
  "id" : 555295415613272064,
  "in_reply_to_status_id" : 555293806325952513,
  "created_at" : "2015-01-14 09:28:38 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VcQB8nWgpJ",
      "expanded_url" : "http:\/\/www.scilogs.de\/mente-et-malleo\/fossil-des-jahres-arthropleura-armata\/",
      "display_url" : "scilogs.de\/mente-et-malle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555293126815141889",
  "text" : "Fossil des Jahres \u2013 Arthropleura armata http:\/\/t.co\/VcQB8nWgpJ",
  "id" : 555293126815141889,
  "created_at" : "2015-01-14 09:19:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555292239229124608",
  "geo" : { },
  "id_str" : "555292340462829568",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon noch nicht. Bislang nur die Folge die bei TAL featured war.",
  "id" : 555292340462829568,
  "in_reply_to_status_id" : 555292239229124608,
  "created_at" : "2015-01-14 09:16:25 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/X2cUHIAYwg",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/speaking-of-science\/wp\/2015\/01\/13\/meet-the-man-who-spent-12-years-trapped-inside-his-body-watching-barney-reruns\/",
      "display_url" : "washingtonpost.com\/news\/speaking-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555291805500338176",
  "text" : "Meet the man who spent 12 years trapped inside his body watching \u2018Barney\u2019 reruns http:\/\/t.co\/X2cUHIAYwg",
  "id" : 555291805500338176,
  "created_at" : "2015-01-14 09:14:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 82, 95 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/mCwOb8qDmu",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2014\/06\/18\/006395",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555287472612339712",
  "text" : "Error correction and assembly complexity of single molecule sequencing reads. \/HT @PhilippBayer (iirc) http:\/\/t.co\/mCwOb8qDmu",
  "id" : 555287472612339712,
  "created_at" : "2015-01-14 08:57:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 80, 88 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/GWn79fFkZD",
      "expanded_url" : "http:\/\/evolution-institute.org\/article\/coming-out-darwinian\/",
      "display_url" : "evolution-institute.org\/article\/coming\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555275814951215104",
  "text" : "\u00ABComing Out Darwinian. Is It Time To Rewrite The Story Of Sex?\u00BB Awesome, thanks @JBYoder http:\/\/t.co\/GWn79fFkZD",
  "id" : 555275814951215104,
  "created_at" : "2015-01-14 08:10:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659970993, 8.759901629785976 ]
  },
  "id_str" : "555249984992722944",
  "text" : "@JoergR @PhilippBayer I do, very much so. :)",
  "id" : 555249984992722944,
  "created_at" : "2015-01-14 06:28:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/FYLZCYYTAA",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/13\/7533665\/benjamin-frankling-farting",
      "display_url" : "vox.com\/2015\/1\/13\/7533\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555021431088877570",
  "text" : "Now I wonder how I can cite Ben Franklin\u2019s essay on farting in my next paper. http:\/\/t.co\/FYLZCYYTAA",
  "id" : 555021431088877570,
  "created_at" : "2015-01-13 15:19:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/puWZGUJBxR",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/13\/50-years-of-david-bowies-hai.html",
      "display_url" : "boingboing.net\/2015\/01\/13\/50-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555020575723499520",
  "text" : "50 years of David Bowie's\u00A0hairstyles http:\/\/t.co\/puWZGUJBxR",
  "id" : 555020575723499520,
  "created_at" : "2015-01-13 15:16:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Society of Biology",
      "screen_name" : "Society_biology",
      "indices" : [ 3, 19 ],
      "id_str" : "3291305547",
      "id" : 3291305547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenAccess",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555019158468198401",
  "text" : "RT @Society_Biology: Calling all biologists! We want to know your thoughts on academic publishing, #OpenAccess and dissemination. Survey: h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenAccess",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/j07SzUseA7",
        "expanded_url" : "http:\/\/svy.mk\/1wTT85k",
        "display_url" : "svy.mk\/1wTT85k"
      } ]
    },
    "geo" : { },
    "id_str" : "555002930055872512",
    "text" : "Calling all biologists! We want to know your thoughts on academic publishing, #OpenAccess and dissemination. Survey: http:\/\/t.co\/j07SzUseA7",
    "id" : 555002930055872512,
    "created_at" : "2015-01-13 14:06:24 +0000",
    "user" : {
      "name" : "Royal Society of Biology",
      "screen_name" : "RoyalSocBio",
      "protected" : false,
      "id_str" : "40914713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1101240588\/Shield_normal.jpg",
      "id" : 40914713,
      "verified" : false
    }
  },
  "id" : 555019158468198401,
  "created_at" : "2015-01-13 15:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236937752162, 8.627522320661294 ]
  },
  "id_str" : "555009178100834306",
  "text" : "\u00ABIch hab spontan beschlossen Feierabend zu machen. Aber ich dachte vorher zeige ich dir noch ein paar Mops-Videos!\u00BB",
  "id" : 555009178100834306,
  "created_at" : "2015-01-13 14:31:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 3, 17 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0xBivDCuef",
      "expanded_url" : "http:\/\/buff.ly\/1z3NUtk",
      "display_url" : "buff.ly\/1z3NUtk"
    } ]
  },
  "geo" : { },
  "id_str" : "554990426416230400",
  "text" : "RT @kai_arzheimer: Smart Phones and Postmodern Theory  http:\/\/t.co\/0xBivDCuef",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/0xBivDCuef",
        "expanded_url" : "http:\/\/buff.ly\/1z3NUtk",
        "display_url" : "buff.ly\/1z3NUtk"
      } ]
    },
    "geo" : { },
    "id_str" : "554989743470280704",
    "text" : "Smart Phones and Postmodern Theory  http:\/\/t.co\/0xBivDCuef",
    "id" : 554989743470280704,
    "created_at" : "2015-01-13 13:14:00 +0000",
    "user" : {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "protected" : false,
      "id_str" : "16736320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74112233\/kai_1_normal.jpg",
      "id" : 16736320,
      "verified" : false
    }
  },
  "id" : 554990426416230400,
  "created_at" : "2015-01-13 13:16:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/R9Q8qUZp8j",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/13\/the-9-month-vine.html",
      "display_url" : "boingboing.net\/2015\/01\/13\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554989257677615105",
  "text" : "the 9-month Vine http:\/\/t.co\/R9Q8qUZp8j",
  "id" : 554989257677615105,
  "created_at" : "2015-01-13 13:12:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554985214880284672",
  "geo" : { },
  "id_str" : "554986818463350784",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy also: the OA fee can only be paid with BTC.",
  "id" : 554986818463350784,
  "in_reply_to_status_id" : 554985214880284672,
  "created_at" : "2015-01-13 13:02:23 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/8RhGkAiXd7",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/12\/7531775\/sandberg-women-interrupt-work",
      "display_url" : "vox.com\/2015\/1\/12\/7531\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554972443438514176",
  "text" : "\u00ABFeeling righteous about diversity makes us feel warm&amp;fuzzy,but the discomfort of putting it into practice upsets us\u00BB http:\/\/t.co\/8RhGkAiXd7",
  "id" : 554972443438514176,
  "created_at" : "2015-01-13 12:05:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/W18Q6k85ge",
      "expanded_url" : "http:\/\/eatreadscience.com\/2015\/01\/12\/more-sex-more-utis-how-timing-affects-your-risk-of-bladder-infection\/",
      "display_url" : "eatreadscience.com\/2015\/01\/12\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554969008714547200",
  "text" : "More sex, more UTIs: how timing affects your risk of bladder infection http:\/\/t.co\/W18Q6k85ge",
  "id" : 554969008714547200,
  "created_at" : "2015-01-13 11:51:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/PIWIUcyQkj",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/12\/7532325\/george-zimmerman-arrest-assault",
      "display_url" : "vox.com\/2015\/1\/12\/7532\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554968263453855745",
  "text" : "Why it matters that George Zimmerman keeps getting\u00A0arrested http:\/\/t.co\/PIWIUcyQkj",
  "id" : 554968263453855745,
  "created_at" : "2015-01-13 11:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554956158478606337",
  "text" : "I may just have spent 2 1\/2 hours on debugging CEGMA. Before figuring out that I was too stupid to pass the parameters correctly\u2026",
  "id" : 554956158478606337,
  "created_at" : "2015-01-13 11:00:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554944456345264128",
  "text" : "My German deteriorated to a point that some people now assume I can barely speak it, compliment me for trying and then switch to English\u2026",
  "id" : 554944456345264128,
  "created_at" : "2015-01-13 10:14:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 3, 8 ],
      "id_str" : "12819112",
      "id" : 12819112
    }, {
      "name" : "PLOS ONE",
      "screen_name" : "PLOSONE",
      "indices" : [ 11, 19 ],
      "id_str" : "27596259",
      "id" : 27596259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5pXMf1ekpQ",
      "expanded_url" : "http:\/\/bit.ly\/1C99quz",
      "display_url" : "bit.ly\/1C99quz"
    } ]
  },
  "geo" : { },
  "id_str" : "554911161477775360",
  "text" : "RT @PLOS: .@PLOSONE Playing With Canines: Ancient Dog Teeth Reveal Early Human-Dog Interactions http:\/\/t.co\/5pXMf1ekpQ http:\/\/t.co\/pcapP36B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS ONE",
        "screen_name" : "PLOSONE",
        "indices" : [ 1, 9 ],
        "id_str" : "27596259",
        "id" : 27596259
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PLOS\/status\/554753830533857281\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/pcapP36Bi9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7LhpN8CYAAaa78.jpg",
        "id_str" : "554753802352353280",
        "id" : 554753802352353280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7LhpN8CYAAaa78.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/pcapP36Bi9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/5pXMf1ekpQ",
        "expanded_url" : "http:\/\/bit.ly\/1C99quz",
        "display_url" : "bit.ly\/1C99quz"
      } ]
    },
    "geo" : { },
    "id_str" : "554753830533857281",
    "text" : ".@PLOSONE Playing With Canines: Ancient Dog Teeth Reveal Early Human-Dog Interactions http:\/\/t.co\/5pXMf1ekpQ http:\/\/t.co\/pcapP36Bi9",
    "id" : 554753830533857281,
    "created_at" : "2015-01-12 21:36:34 +0000",
    "user" : {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "protected" : false,
      "id_str" : "12819112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553318804122370048\/0HTyc2Ot_normal.jpeg",
      "id" : 12819112,
      "verified" : false
    }
  },
  "id" : 554911161477775360,
  "created_at" : "2015-01-13 08:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/BUEukgaG3B",
      "expanded_url" : "http:\/\/errantscience.com\/blog\/2015\/01\/07\/5-lab-resolutions\/",
      "display_url" : "errantscience.com\/blog\/2015\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554649531200323584",
  "text" : "Labeling stuff: \u00ABNext year I plan on upgrading this resolution by doing it with legible handwriting.\u00BB http:\/\/t.co\/BUEukgaG3B",
  "id" : 554649531200323584,
  "created_at" : "2015-01-12 14:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554644880300179456",
  "text" : "\u00ABDoes the tool work now?\u00BB \u2013 \u00ABIt depends. Do you want to get a single random number? Then go for it. If you want a meaningful answer? Nope.\u00BB",
  "id" : 554644880300179456,
  "created_at" : "2015-01-12 14:23:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/UAYlA33ZCp",
      "expanded_url" : "http:\/\/languagengine.co\/blog\/what-happened-to-old-school-nlp\/",
      "display_url" : "languagengine.co\/blog\/what-happ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554642060662542336",
  "text" : "What Happened to Old School NLP? http:\/\/t.co\/UAYlA33ZCp",
  "id" : 554642060662542336,
  "created_at" : "2015-01-12 14:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237829726346, 8.627522856567458 ]
  },
  "id_str" : "554610029803077632",
  "text" : "\u00ABMein Freund hat eine Erkl\u00E4rb\u00E4rstimme beim Sex: \u2018Zuerst stecken Sie dies auf das\u2026\u2019\u00BB \u2014 \u00ABHast du mit Wetlab-Jargon gekontert? Gently vortex\u2026\u00BB",
  "id" : 554610029803077632,
  "created_at" : "2015-01-12 12:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/e3EGu1Y5lu",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/10\/7522889\/college-race-diversity-microaggressions",
      "display_url" : "vox.com\/2015\/1\/10\/7522\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554563499276636160",
  "text" : "The subtle racist and sexist slights that can make even diverse colleges hostile\u00A0places http:\/\/t.co\/e3EGu1Y5lu",
  "id" : 554563499276636160,
  "created_at" : "2015-01-12 09:00:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/H2MTQiRLEH",
      "expanded_url" : "http:\/\/www.hystericalfeminisms.com\/consent\/",
      "display_url" : "hystericalfeminisms.com\/consent\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554562397479137280",
  "text" : "Consent http:\/\/t.co\/H2MTQiRLEH",
  "id" : 554562397479137280,
  "created_at" : "2015-01-12 08:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/63UMcjfXNQ",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2015\/01\/2015-another-year-of-sequencing.html",
      "display_url" : "omicsomics.blogspot.de\/2015\/01\/2015-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554559800655486977",
  "text" : "2015: Another Year of Sequencing Evolution (not Revolution)? http:\/\/t.co\/63UMcjfXNQ",
  "id" : 554559800655486977,
  "created_at" : "2015-01-12 08:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ClttHcoL8O",
      "expanded_url" : "http:\/\/paintyourpanda.blogspot.de\/2015\/01\/police-brutality-and-efficacy-of-body.html",
      "display_url" : "paintyourpanda.blogspot.de\/2015\/01\/police\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554559018870784001",
  "text" : "Police Brutality And The Efficacy Of Body-Worn Cameras http:\/\/t.co\/ClttHcoL8O",
  "id" : 554559018870784001,
  "created_at" : "2015-01-12 08:42:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/vVZhzWbBnD",
      "expanded_url" : "http:\/\/loonylabs.org\/2015\/01\/11\/healthy-anger\/",
      "display_url" : "loonylabs.org\/2015\/01\/11\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554557079999234048",
  "text" : "it\u2019s the circumstances that elicit anger, and not anger itself, that seem to be bad for health http:\/\/t.co\/vVZhzWbBnD",
  "id" : 554557079999234048,
  "created_at" : "2015-01-12 08:34:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236685575574, 8.62752757297768 ]
  },
  "id_str" : "554541807036813312",
  "text" : "\u00ABWenn man das Fitbit auf Deutsch stellt sind die Achievements Teildistanzen bis Moskau.\u00BB \u2014 \u00ABDie Spazierung war ein voller Erfolg!\u00BB",
  "id" : 554541807036813312,
  "created_at" : "2015-01-12 07:34:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/oSemA5C66D",
      "expanded_url" : "http:\/\/instagram.com\/p\/xt7T96Bws8\/",
      "display_url" : "instagram.com\/p\/xt7T96Bws8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554288984588054528",
  "text" : "Tahini Cookies: post-game http:\/\/t.co\/oSemA5C66D",
  "id" : 554288984588054528,
  "created_at" : "2015-01-11 14:49:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/clfUe4ZzxL",
      "expanded_url" : "http:\/\/instagram.com\/p\/xt7EVbBwsd\/",
      "display_url" : "instagram.com\/p\/xt7EVbBwsd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554288447574528000",
  "text" : "Tahina Cookies: in-game http:\/\/t.co\/clfUe4ZzxL",
  "id" : 554288447574528000,
  "created_at" : "2015-01-11 14:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/iPKNZLb02T",
      "expanded_url" : "http:\/\/instagram.com\/p\/xt6zE_hwr5\/",
      "display_url" : "instagram.com\/p\/xt6zE_hwr5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554287854449606657",
  "text" : "Tahina Cookies: pre-game http:\/\/t.co\/iPKNZLb02T",
  "id" : 554287854449606657,
  "created_at" : "2015-01-11 14:44:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/V7LgqTp2FU",
      "expanded_url" : "http:\/\/instagram.com\/p\/xtzBL5hwvR\/",
      "display_url" : "instagram.com\/p\/xtzBL5hwvR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554270747221561344",
  "text" : "B\/W http:\/\/t.co\/V7LgqTp2FU",
  "id" : 554270747221561344,
  "created_at" : "2015-01-11 13:36:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/554233568093024256\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/3NfJtWsTTS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7EIfZuCMAEc7nc.jpg",
      "id_str" : "554233564716216321",
      "id" : 554233564716216321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7EIfZuCMAEc7nc.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3NfJtWsTTS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554232084999733249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554233568093024256",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot und Blade Runner kann ich dir aus Print heraus vorlesen ;) http:\/\/t.co\/3NfJtWsTTS",
  "id" : 554233568093024256,
  "in_reply_to_status_id" : 554232084999733249,
  "created_at" : "2015-01-11 11:09:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/J1WhupDaqz",
      "expanded_url" : "http:\/\/www.dc4mf.org\/sites\/default\/files\/single-pages\/images\/rm8743-72.gif",
      "display_url" : "dc4mf.org\/sites\/default\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "554232084999733249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554232750518337536",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot http:\/\/t.co\/J1WhupDaqz :p",
  "id" : 554232750518337536,
  "in_reply_to_status_id" : 554232084999733249,
  "created_at" : "2015-01-11 11:05:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/F1teRz7Z0S",
      "expanded_url" : "http:\/\/img0.joyreactor.com\/pics\/post\/gif-journalist-prank-pants-703092.gif",
      "display_url" : "img0.joyreactor.com\/pics\/post\/gif-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "554230584831401985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554231381522673665",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot http:\/\/t.co\/F1teRz7Z0S",
  "id" : 554231381522673665,
  "in_reply_to_status_id" : 554230584831401985,
  "created_at" : "2015-01-11 11:00:33 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/FC6bFUpvf8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YJfAnoCURkQ",
      "display_url" : "youtube.com\/watch?v=YJfAno\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554228880501116929",
  "text" : "\u00ABDa waren wir! Da hinten links hab ich gekackt!\u00BB https:\/\/t.co\/FC6bFUpvf8",
  "id" : 554228880501116929,
  "created_at" : "2015-01-11 10:50:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/o54FUWntdL",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/01\/10\/the_plight_of_the_bitter_nerd_why_so_many_awkward_shy_guys_end_up_hating_feminism\/",
      "display_url" : "salon.com\/2015\/01\/10\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554227625473101824",
  "text" : "The plight of the bitter nerd http:\/\/t.co\/o54FUWntdL",
  "id" : 554227625473101824,
  "created_at" : "2015-01-11 10:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 3, 9 ],
      "id_str" : "15276911",
      "id" : 15276911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/kljGzbgH3b",
      "expanded_url" : "http:\/\/Cracked.com",
      "display_url" : "Cracked.com"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/LAehPMTqYZ",
      "expanded_url" : "http:\/\/is.gd\/jClIHK",
      "display_url" : "is.gd\/jClIHK"
    } ]
  },
  "geo" : { },
  "id_str" : "554223359589101570",
  "text" : "RT @iddux: Why the 'Firefly' Crew Were the Bad Guys | http:\/\/t.co\/kljGzbgH3b - http:\/\/t.co\/LAehPMTqYZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/kljGzbgH3b",
        "expanded_url" : "http:\/\/Cracked.com",
        "display_url" : "Cracked.com"
      }, {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/LAehPMTqYZ",
        "expanded_url" : "http:\/\/is.gd\/jClIHK",
        "display_url" : "is.gd\/jClIHK"
      } ]
    },
    "geo" : { },
    "id_str" : "554131852257394688",
    "text" : "Why the 'Firefly' Crew Were the Bad Guys | http:\/\/t.co\/kljGzbgH3b - http:\/\/t.co\/LAehPMTqYZ",
    "id" : 554131852257394688,
    "created_at" : "2015-01-11 04:25:03 +0000",
    "user" : {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "protected" : false,
      "id_str" : "15276911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893496089013174272\/l628-eyh_normal.jpg",
      "id" : 15276911,
      "verified" : false
    }
  },
  "id" : 554223359589101570,
  "created_at" : "2015-01-11 10:28:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "indices" : [ 3, 16 ],
      "id_str" : "21607925",
      "id" : 21607925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554219386832420864",
  "text" : "RT @orchidhunter: I don't separate the science and the camp on this Twitter account. Being visible to queer kids who are thinking of #STEM \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 115, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554102269596426243",
    "text" : "I don't separate the science and the camp on this Twitter account. Being visible to queer kids who are thinking of #STEM careers matters.",
    "id" : 554102269596426243,
    "created_at" : "2015-01-11 02:27:30 +0000",
    "user" : {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "protected" : false,
      "id_str" : "21607925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860516945430429696\/NhIYG1Lp_normal.jpg",
      "id" : 21607925,
      "verified" : false
    }
  },
  "id" : 554219386832420864,
  "created_at" : "2015-01-11 10:12:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/e8f1gLo01J",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/the-intersect\/wp\/2015\/01\/08\/a-social-network-for-dudes-with-beards-is-kinda-sorta-accidentally-revolutionizing-online-dating\/",
      "display_url" : "washingtonpost.com\/news\/the-inter\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "554217136789671936",
  "text" : "How a beard-centric online dating site tries to fix some of the inherent problems of online dating so far http:\/\/t.co\/e8f1gLo01J",
  "id" : 554217136789671936,
  "created_at" : "2015-01-11 10:03:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/2E7at1HQRF",
      "expanded_url" : "http:\/\/www.johnskylar.com\/post\/107416685924\/a-career-in-science-will-cost-you-your-firstborn",
      "display_url" : "johnskylar.com\/post\/107416685\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965887674602, 8.283006930774311 ]
  },
  "id_str" : "554020809988395009",
  "text" : "Fittingly for this day I will now just cry a bit more: A Career in Science Will Cost You Your Firstborn http:\/\/t.co\/2E7at1HQRF",
  "id" : 554020809988395009,
  "created_at" : "2015-01-10 21:03:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "553688323538288641",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj alles Gute, gro\u00DFer. :)",
  "id" : 553688323538288641,
  "created_at" : "2015-01-09 23:02:38 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ks3SFYcDPK",
      "expanded_url" : "http:\/\/bjoern.brembs.net\/2015\/01\/booming-university-administrations\/",
      "display_url" : "bjoern.brembs.net\/2015\/01\/boomin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553556157026295809",
  "text" : "Booming University Administrations http:\/\/t.co\/ks3SFYcDPK",
  "id" : 553556157026295809,
  "created_at" : "2015-01-09 14:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/GcwNKjv6q2",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/xMrmuSK49nh7O\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/xMrmuSK4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553553749558689792",
  "text" : "every bioinformatics pipeline ever http:\/\/t.co\/GcwNKjv6q2 (should end on a perl syntax error note)",
  "id" : 553553749558689792,
  "created_at" : "2015-01-09 14:07:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/vaM9FafVFr",
      "expanded_url" : "http:\/\/www.plosgenetics.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pgen.1004857",
      "display_url" : "plosgenetics.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553551486748463104",
  "text" : "The Genetic and Mechanistic Basis for Variation in Gene Regulation \/cc @PhilippBayer http:\/\/t.co\/vaM9FafVFr",
  "id" : 553551486748463104,
  "created_at" : "2015-01-09 13:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iGgUIfepio",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/8\/7516607\/women-children-first-shipwreck",
      "display_url" : "vox.com\/2015\/1\/8\/75166\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553539139497644032",
  "text" : "\u00ABCrew members are also likelier to survive. The captain does not, it turns out, always go down with the ship.\u00BB http:\/\/t.co\/iGgUIfepio",
  "id" : 553539139497644032,
  "created_at" : "2015-01-09 13:09:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/SeI5F9v1Pn",
      "expanded_url" : "http:\/\/www.scilogs.de\/mente-et-malleo\/das-holuhraun-lavafeld\/",
      "display_url" : "scilogs.de\/mente-et-malle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553538590312251392",
  "text" : "\u00ABDie aktuelle Lava bedeckte bis zum 6. Januar eine Fl\u00E4che von rund 84 km\u00B2.\u00BB Also ~ 0,03307393 Saarland. http:\/\/t.co\/SeI5F9v1Pn",
  "id" : 553538590312251392,
  "created_at" : "2015-01-09 13:07:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233258282651, 8.627588109350066 ]
  },
  "id_str" : "553508449297113088",
  "text" : "\u00ABStart your machine in diagnostic mode by pressing D during boot.\u00BB Hard to do if you want to diagnose why your A-L keys do not work\u2026",
  "id" : 553508449297113088,
  "created_at" : "2015-01-09 11:07:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AhistoricalPics\/status\/553416558668566528\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/vsePfv2wla",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B64hbX2CEAAdi_u.jpg",
      "id_str" : "553416558353977344",
      "id" : 553416558353977344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B64hbX2CEAAdi_u.jpg",
      "sizes" : [ {
        "h" : 197,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/vsePfv2wla"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553475901066076160",
  "text" : "RT @AhistoricalPics: How that amazing New Yorker cover was made, 1880-something http:\/\/t.co\/vsePfv2wla",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AhistoricalPics\/status\/553416558668566528\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/vsePfv2wla",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B64hbX2CEAAdi_u.jpg",
        "id_str" : "553416558353977344",
        "id" : 553416558353977344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B64hbX2CEAAdi_u.jpg",
        "sizes" : [ {
          "h" : 197,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/vsePfv2wla"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "553416558668566528",
    "text" : "How that amazing New Yorker cover was made, 1880-something http:\/\/t.co\/vsePfv2wla",
    "id" : 553416558668566528,
    "created_at" : "2015-01-09 05:02:44 +0000",
    "user" : {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 553475901066076160,
  "created_at" : "2015-01-09 08:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/7Or4Tgdv0f",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/07\/detained-for-19-days-immigrat.html",
      "display_url" : "boingboing.net\/2015\/01\/07\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553163810807513091",
  "text" : "Detained for 19 days: immigration checkpoint refusal gone\u00A0wrong http:\/\/t.co\/7Or4Tgdv0f",
  "id" : 553163810807513091,
  "created_at" : "2015-01-08 12:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0508551625548, 8.571087084752277 ]
  },
  "id_str" : "553114601035141120",
  "text" : "\u00ABBist du in der N\u00E4he der Uni? Ich brauch sofort einen kompetenten Beisitzer f\u00FCr eine Verteidigung!\u00BB\u2014\u00ABDu wei\u00DFt das ich keinen PhD hab, oder?\u00BB",
  "id" : 553114601035141120,
  "created_at" : "2015-01-08 09:02:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553097941851078656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05110543846126, 8.571375610355153 ]
  },
  "id_str" : "553100573588094977",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at which T1 entrance are you? :D",
  "id" : 553100573588094977,
  "in_reply_to_status_id" : 553097941851078656,
  "created_at" : "2015-01-08 08:07:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553097941851078656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08043571636308, 8.63664902202106 ]
  },
  "id_str" : "553099023436238848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t fly w\/o me :p",
  "id" : 553099023436238848,
  "in_reply_to_status_id" : 553097941851078656,
  "created_at" : "2015-01-08 08:00:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11470877560924, 8.68260790829131 ]
  },
  "id_str" : "553096874979520512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ETA 0915, commuter trains are doing their best being Tokyoesk (in terms of load; not timing) today.",
  "id" : 553096874979520512,
  "created_at" : "2015-01-08 07:52:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "realscientists: Dr. Jacquelyn Gill, Paleoecologist",
      "screen_name" : "realscientists",
      "indices" : [ 3, 18 ],
      "id_str" : "1144882621",
      "id" : 1144882621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552834081508298752",
  "text" : "RT @realscientists: Which species, you might ask? Well, I'm a computational ecologist. It means I like ecology, but not to the point where \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "552833364957622274",
    "text" : "Which species, you might ask? Well, I'm a computational ecologist. It means I like ecology, but not to the point where I want to go outside.",
    "id" : 552833364957622274,
    "created_at" : "2015-01-07 14:25:20 +0000",
    "user" : {
      "name" : "realscientists: Dr. Jacquelyn Gill, Paleoecologist",
      "screen_name" : "realscientists",
      "protected" : false,
      "id_str" : "1144882621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932627189840990208\/dMdijAPT_normal.jpg",
      "id" : 1144882621,
      "verified" : false
    }
  },
  "id" : 552834081508298752,
  "created_at" : "2015-01-07 14:28:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552831434181050369",
  "text" : "I guess I accidentally rallied a new team for the relay marathon this year\u2026",
  "id" : 552831434181050369,
  "created_at" : "2015-01-07 14:17:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Nrpy5LXF8v",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2015\/01\/most-participants-in-citizen-science-projects-give-up-almost-immediately\/",
      "display_url" : "arstechnica.com\/science\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552754284874698752",
  "text" : "Most participants in \u201Ccitizen science\u201D projects give up almost immediately http:\/\/t.co\/Nrpy5LXF8v",
  "id" : 552754284874698752,
  "created_at" : "2015-01-07 09:11:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/RoZ5yjQhYu",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/06\/southwest-flight-attendants.html",
      "display_url" : "boingboing.net\/2015\/01\/06\/sou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552750767321677824",
  "text" : "\u00ABIt\u2019s a no-smoking, no-whining, no-complaining flight\u2026\u00BB http:\/\/t.co\/RoZ5yjQhYu",
  "id" : 552750767321677824,
  "created_at" : "2015-01-07 08:57:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552744767994728448",
  "geo" : { },
  "id_str" : "552745836825030656",
  "in_reply_to_user_id" : 14699615,
  "text" : "@BLugger that\u2019s not at all what the article says\u2026",
  "id" : 552745836825030656,
  "in_reply_to_status_id" : 552744767994728448,
  "created_at" : "2015-01-07 08:37:31 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/8niQJTqxaT",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/matthewherper\/2015\/01\/06\/surprise-with-60-million-genentech-deal-23andme-has-a-business-plan\/",
      "display_url" : "forbes.com\/sites\/matthewh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "552743157671424000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723681539913, 8.62754862093576 ]
  },
  "id_str" : "552744030556409856",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule http:\/\/t.co\/8niQJTqxaT",
  "id" : 552744030556409856,
  "in_reply_to_status_id" : 552743157671424000,
  "created_at" : "2015-01-07 08:30:21 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16429449698956, 8.644681002026756 ]
  },
  "id_str" : "552742522905432064",
  "text" : "The outrage over the 23andMe deal is about having to shell out $60m to get access instead of making it open data, right?",
  "id" : 552742522905432064,
  "created_at" : "2015-01-07 08:24:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552524694294102016",
  "text" : "Great. The home row keys (A-L) on my macbook air suddenly stopped working\u2026",
  "id" : 552524694294102016,
  "created_at" : "2015-01-06 17:58:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552470832136855552",
  "geo" : { },
  "id_str" : "552474065186082818",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv die mail kam nun an, danke! :)",
  "id" : 552474065186082818,
  "in_reply_to_status_id" : 552470832136855552,
  "created_at" : "2015-01-06 14:37:36 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552470832136855552",
  "geo" : { },
  "id_str" : "552470936575045633",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv yeah, try bastian@gedankenstuecke.de",
  "id" : 552470936575045633,
  "in_reply_to_status_id" : 552470832136855552,
  "created_at" : "2015-01-06 14:25:10 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552468788680335360",
  "geo" : { },
  "id_str" : "552469100434583554",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv yeah, i didn\u2019t get any mail so far.",
  "id" : 552469100434583554,
  "in_reply_to_status_id" : 552468788680335360,
  "created_at" : "2015-01-06 14:17:52 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552443589280948226",
  "geo" : { },
  "id_str" : "552444173232918529",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx, just forwarded this to my sysadmin.",
  "id" : 552444173232918529,
  "in_reply_to_status_id" : 552443589280948226,
  "created_at" : "2015-01-06 12:38:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552442910403473411",
  "geo" : { },
  "id_str" : "552443118545805313",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, that\u2019s not a problem for our small cluster here. I\u2019m already on first name basis with all nodes. ;)",
  "id" : 552443118545805313,
  "in_reply_to_status_id" : 552442910403473411,
  "created_at" : "2015-01-06 12:34:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552442420039016449",
  "geo" : { },
  "id_str" : "552442694971445248",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i see, in that case I could also just bypass the queue to make it even easier ;-)",
  "id" : 552442694971445248,
  "in_reply_to_status_id" : 552442420039016449,
  "created_at" : "2015-01-06 12:32:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QARHqocLRR",
      "expanded_url" : "https:\/\/medium.com\/backchannel\/even-william-gibson-cant-out-imagine-reality-a04ce555c567",
      "display_url" : "medium.com\/backchannel\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552430104555827200",
  "text" : "\u00ABOur top sci-fi bard is in a race with real life to create the gaudiest dystopia\u00BB https:\/\/t.co\/QARHqocLRR",
  "id" : 552430104555827200,
  "created_at" : "2015-01-06 11:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552429397563961346",
  "text" : "\u00ABHallo? Bin ich da mit dem Riedberg verbunden?\u00BB \u2013 \u00ABUhm jaein, sie wissen schon das der Campus nicht nur ein einziges Telefon hat, oder?\u00BB",
  "id" : 552429397563961346,
  "created_at" : "2015-01-06 11:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/5Kg8J9knbm",
      "expanded_url" : "https:\/\/soundcloud.com\/givemefiction\/013-maggie-tokuda-hall-miri-in-love",
      "display_url" : "soundcloud.com\/givemefiction\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552383274178596866",
  "text" : "In love with the printer https:\/\/t.co\/5Kg8J9knbm",
  "id" : 552383274178596866,
  "created_at" : "2015-01-06 08:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/U6LasIAfCK",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/5\/7482871\/types-of-study-design",
      "display_url" : "vox.com\/2015\/1\/5\/74828\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552380361381273600",
  "text" : "The one chart you need to understand any health\u00A0study http:\/\/t.co\/U6LasIAfCK",
  "id" : 552380361381273600,
  "created_at" : "2015-01-06 08:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/FA82U3KXXM",
      "expanded_url" : "http:\/\/labmath.org\/?p=371",
      "display_url" : "labmath.org\/?p=371"
    } ]
  },
  "geo" : { },
  "id_str" : "552378186420731905",
  "text" : "On 3D graphs: \u00ABMeanwhile, real researchers will be content with only two dimensions.\u00BB http:\/\/t.co\/FA82U3KXXM",
  "id" : 552378186420731905,
  "created_at" : "2015-01-06 08:16:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/RtaN7YTQQb",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/05\/what-your-phone-texting-hand-p.html",
      "display_url" : "boingboing.net\/2015\/01\/05\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552377705531203585",
  "text" : "\u201CTechnology savant\u201D? How else would you use smartphones in winter? http:\/\/t.co\/RtaN7YTQQb",
  "id" : 552377705531203585,
  "created_at" : "2015-01-06 08:14:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 113, 126 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16229603109173, 8.647948962859262 ]
  },
  "id_str" : "552371455376490497",
  "text" : "I want to benchmark memory consumption of different jobs submitted through the sge. Any best practices for that? @PhilippBayer",
  "id" : 552371455376490497,
  "created_at" : "2015-01-06 07:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "552358712145625089",
  "text" : "\u00ABOh, ich wollte deinen Kiefer nicht zum knacken bringen. War es weil ich dich daran festgehalten hab als du umgefallen bist?\u00BB",
  "id" : 552358712145625089,
  "created_at" : "2015-01-06 06:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067791681177, 8.75989008763267 ]
  },
  "id_str" : "552194885311528960",
  "text" : "\u00ABDas Steakkochbuch f\u00FCr echte M\u00E4nner.\u00BB \u2014 \u00ABF\u00FCr den kleinen Hunger nach dem gro\u00DFen Weltkrieg?\u00BB",
  "id" : 552194885311528960,
  "created_at" : "2015-01-05 20:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Ppms0Qr8Fy",
      "expanded_url" : "http:\/\/chronicle.su\/about\/",
      "display_url" : "chronicle.su\/about\/"
    } ]
  },
  "in_reply_to_status_id_str" : "552077536134701056",
  "geo" : { },
  "id_str" : "552077785343479809",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro i don\u2019t think so\u2026http:\/\/t.co\/Ppms0Qr8Fy",
  "id" : 552077785343479809,
  "in_reply_to_status_id" : 552077536134701056,
  "created_at" : "2015-01-05 12:22:55 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEM",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "queerSTEM",
      "indices" : [ 103, 113 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/SMlJPSzrE1",
      "expanded_url" : "https:\/\/www.facebook.com\/lgbtstem",
      "display_url" : "facebook.com\/lgbtstem"
    } ]
  },
  "geo" : { },
  "id_str" : "552070421588500480",
  "text" : "RT @LGBTSTEM: The #LGBTSTEM project now has a facebook page. Come and join us! https:\/\/t.co\/SMlJPSzrE1 #queerSTEM #LGBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEM",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "queerSTEM",
        "indices" : [ 89, 99 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/SMlJPSzrE1",
        "expanded_url" : "https:\/\/www.facebook.com\/lgbtstem",
        "display_url" : "facebook.com\/lgbtstem"
      } ]
    },
    "geo" : { },
    "id_str" : "552061847558688768",
    "text" : "The #LGBTSTEM project now has a facebook page. Come and join us! https:\/\/t.co\/SMlJPSzrE1 #queerSTEM #LGBT",
    "id" : 552061847558688768,
    "created_at" : "2015-01-05 11:19:35 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 552070421588500480,
  "created_at" : "2015-01-05 11:53:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552036053075636224",
  "text" : "Over the holidays the passphrase for my ssh certificate mysteriously stopped working\u2026 perfect timing\u2026",
  "id" : 552036053075636224,
  "created_at" : "2015-01-05 09:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/pipu3iZRhL",
      "expanded_url" : "http:\/\/wozniak.ca\/why-i-quit-os-x",
      "display_url" : "wozniak.ca\/why-i-quit-os-x"
    } ]
  },
  "geo" : { },
  "id_str" : "552021487272882176",
  "text" : "\u00ABmy default position on Apple software in OS X has moved from \"probably good\" to \"probably not OK\". \u00BB http:\/\/t.co\/pipu3iZRhL",
  "id" : 552021487272882176,
  "created_at" : "2015-01-05 08:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jZwEyDsd0t",
      "expanded_url" : "http:\/\/xkcd.com\/1469\/",
      "display_url" : "xkcd.com\/1469\/"
    } ]
  },
  "geo" : { },
  "id_str" : "552015296694075393",
  "text" : "\u00ABMy morality has evaporated under the harsh UV light.\u00BB Even more fun in a wet lab. EtBr everywhere. http:\/\/t.co\/jZwEyDsd0t",
  "id" : 552015296694075393,
  "created_at" : "2015-01-05 08:14:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10316158969563, 8.746109106442058 ]
  },
  "id_str" : "551999436591996929",
  "text" : "\u00ABAch, meinetwegen stell deinen esoterischen Kothocker bei uns ins Bad.\u00BB",
  "id" : 551999436591996929,
  "created_at" : "2015-01-05 07:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/ZJsr3tiR7t",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/10\/30\/7047429\/mortician-death-dying-caitlin-doughty",
      "display_url" : "vox.com\/2014\/10\/30\/704\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551867984252506114",
  "text" : "What being a mortician taught me about dying http:\/\/t.co\/ZJsr3tiR7t",
  "id" : 551867984252506114,
  "created_at" : "2015-01-04 22:29:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551814594784927745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "551815489379635200",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a of course :)",
  "id" : 551815489379635200,
  "in_reply_to_status_id" : 551814594784927745,
  "created_at" : "2015-01-04 19:00:39 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/ZIDhRsyfoy",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2014\/01\/alive-in-the-sunshine\/",
      "display_url" : "jacobinmag.com\/2014\/01\/alive-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551811619521835008",
  "text" : "\u00ABdreams of freedom from waged labor &amp; self-realization beyond work suddenly looks less like utopia than necessity\u00BB https:\/\/t.co\/ZIDhRsyfoy",
  "id" : 551811619521835008,
  "created_at" : "2015-01-04 18:45:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/OdxMudaA2O",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2015\/01\/04\/style\/the-unending-anxiety-of-an-icymi-world.html?referrer=",
      "display_url" : "mobile.nytimes.com\/2015\/01\/04\/sty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551810326040440832",
  "text" : "ICYMI: ICYMI http:\/\/t.co\/OdxMudaA2O",
  "id" : 551810326040440832,
  "created_at" : "2015-01-04 18:40:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citizenscience",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/MpJuQbcZ3b",
      "expanded_url" : "http:\/\/www.imsb.ethz.ch\/news-and-events\/events\/citizenscienceworkshop.html",
      "display_url" : "imsb.ethz.ch\/news-and-event\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551800906321494017",
  "text" : "I\u2019m part of a workshop on #citizenscience (Jan 22\/23rd in Zurich). Sign up, the program looks cool: http:\/\/t.co\/MpJuQbcZ3b",
  "id" : 551800906321494017,
  "created_at" : "2015-01-04 18:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/taP0YqvjIt",
      "expanded_url" : "http:\/\/instagram.com\/p\/xbqvuNhwg5\/",
      "display_url" : "instagram.com\/p\/xbqvuNhwg5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "551719279906004993",
  "text" : "\u00ABSo praktisch wenn man so klein ist. Die Welt ist voller Betten!\u00BB http:\/\/t.co\/taP0YqvjIt",
  "id" : 551719279906004993,
  "created_at" : "2015-01-04 12:38:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/SSrXCY7Otu",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/01\/04\/nyregion\/dying-in-the-er-and-on-tv-without-his-familys-consent.html",
      "display_url" : "nytimes.com\/2015\/01\/04\/nyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551703970474098688",
  "text" : "Dying in the E.R., and on TV\u00A0Without His Family\u2019s Consent http:\/\/t.co\/SSrXCY7Otu",
  "id" : 551703970474098688,
  "created_at" : "2015-01-04 11:37:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 0, 10 ],
      "id_str" : "16958590",
      "id" : 16958590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551539364984291330",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "551695359517659136",
  "in_reply_to_user_id" : 16958590,
  "text" : "@coraxaroc ich feiere das probeweise schon t\u00E4glich.",
  "id" : 551695359517659136,
  "in_reply_to_status_id" : 551539364984291330,
  "created_at" : "2015-01-04 11:03:18 +0000",
  "in_reply_to_screen_name" : "coraxaroc",
  "in_reply_to_user_id_str" : "16958590",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/d8ks0eaPqB",
      "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/107037075714\/masturbation-is-awesome-marys-letter",
      "display_url" : "sexlettersproject.tumblr.com\/post\/107037075\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551689668459520000",
  "text" : "Masturbation is Awesome http:\/\/t.co\/d8ks0eaPqB",
  "id" : 551689668459520000,
  "created_at" : "2015-01-04 10:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/QEkSvHLyl9",
      "expanded_url" : "http:\/\/i.imgur.com\/AJZFWkm.gif",
      "display_url" : "i.imgur.com\/AJZFWkm.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "551137174310379520",
  "geo" : { },
  "id_str" : "551138011862544386",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy http:\/\/t.co\/QEkSvHLyl9",
  "id" : 551138011862544386,
  "in_reply_to_status_id" : 551137174310379520,
  "created_at" : "2015-01-02 22:08:36 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551132524924370946",
  "geo" : { },
  "id_str" : "551136044092243968",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy now you\u2019re living the life!",
  "id" : 551136044092243968,
  "in_reply_to_status_id" : 551132524924370946,
  "created_at" : "2015-01-02 22:00:47 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 0, 10 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550775250527723522",
  "geo" : { },
  "id_str" : "550790136305553410",
  "in_reply_to_user_id" : 19767193,
  "text" : "@edyong209 C. elegans is even worse.",
  "id" : 550790136305553410,
  "in_reply_to_status_id" : 550775250527723522,
  "created_at" : "2015-01-01 23:06:16 +0000",
  "in_reply_to_screen_name" : "edyong209",
  "in_reply_to_user_id_str" : "19767193",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/pfopGYNHoP",
      "expanded_url" : "http:\/\/instagram.com\/p\/xUL4CshwlL\/",
      "display_url" : "instagram.com\/p\/xUL4CshwlL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "550666234631434240",
  "text" : "\u00ABIf the bear mauls you continuously, despite yourself being passive, you may have to fight back\u00BB http:\/\/t.co\/pfopGYNHoP",
  "id" : 550666234631434240,
  "created_at" : "2015-01-01 14:53:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/RSLCs8tR0a",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XpQMgbDJPok&feature=share",
      "display_url" : "youtube.com\/watch?v=XpQMgb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550636478318272512",
  "text" : "Cycling in the Netherlands: Junction design https:\/\/t.co\/RSLCs8tR0a",
  "id" : 550636478318272512,
  "created_at" : "2015-01-01 12:55:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/7LBnIQ3sXT",
      "expanded_url" : "http:\/\/instagram.com\/p\/xT8GsMBwmO\/",
      "display_url" : "instagram.com\/p\/xT8GsMBwmO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "550631552921927680",
  "text" : "someone had a rough night http:\/\/t.co\/7LBnIQ3sXT",
  "id" : 550631552921927680,
  "created_at" : "2015-01-01 12:36:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninscience",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/mqghbpCqsZ",
      "expanded_url" : "http:\/\/bit.ly\/1tBpvK4",
      "display_url" : "bit.ly\/1tBpvK4"
    } ]
  },
  "geo" : { },
  "id_str" : "550600579798818816",
  "text" : "RT @JacquelynGill: Remembering the #womeninscience we lost in 2014: http:\/\/t.co\/mqghbpCqsZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninscience",
        "indices" : [ 16, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/mqghbpCqsZ",
        "expanded_url" : "http:\/\/bit.ly\/1tBpvK4",
        "display_url" : "bit.ly\/1tBpvK4"
      } ]
    },
    "geo" : { },
    "id_str" : "550360883579584512",
    "text" : "Remembering the #womeninscience we lost in 2014: http:\/\/t.co\/mqghbpCqsZ",
    "id" : 550360883579584512,
    "created_at" : "2014-12-31 18:40:34 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 550600579798818816,
  "created_at" : "2015-01-01 10:33:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Warndorf",
      "screen_name" : "Frau_Elise",
      "indices" : [ 3, 14 ],
      "id_str" : "21445012",
      "id" : 21445012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/qnANq37ugt",
      "expanded_url" : "http:\/\/www.zeit.de\/2013\/48\/ernaehrung-essen-lebensmittelunvertraeglichkeit",
      "display_url" : "zeit.de\/2013\/48\/ernaeh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550599049343430656",
  "text" : "RT @Frau_Elise: \u00DCber den Wahnsinn mit dem Irrglauben an Lebensmittel-Unvertr\u00E4glichkeiten: http:\/\/t.co\/qnANq37ugt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/qnANq37ugt",
        "expanded_url" : "http:\/\/www.zeit.de\/2013\/48\/ernaehrung-essen-lebensmittelunvertraeglichkeit",
        "display_url" : "zeit.de\/2013\/48\/ernaeh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "550592820986540032",
    "text" : "\u00DCber den Wahnsinn mit dem Irrglauben an Lebensmittel-Unvertr\u00E4glichkeiten: http:\/\/t.co\/qnANq37ugt",
    "id" : 550592820986540032,
    "created_at" : "2015-01-01 10:02:12 +0000",
    "user" : {
      "name" : "Daniela Warndorf",
      "screen_name" : "Frau_Elise",
      "protected" : false,
      "id_str" : "21445012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881462143681429504\/Smir4scG_normal.jpg",
      "id" : 21445012,
      "verified" : false
    }
  },
  "id" : 550599049343430656,
  "created_at" : "2015-01-01 10:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]