Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/2XlUvMn8Ts",
      "expanded_url" : "https:\/\/twitter.com\/ellesep\/status\/726492013747671040",
      "display_url" : "twitter.com\/ellesep\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726515069450903553",
  "text" : "\u00ABToday we lay to rest our daughter Bess Kalb, twenty-six, who was claimed Saturday morning by Contact Yoga.\u00BB https:\/\/t.co\/2XlUvMn8Ts",
  "id" : 726515069450903553,
  "created_at" : "2016-04-30 20:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726480195658629120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393461740895, 8.753578884742996 ]
  },
  "id_str" : "726480368971440128",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the interesting bits I even left out :p",
  "id" : 726480368971440128,
  "in_reply_to_status_id" : 726480195658629120,
  "created_at" : "2016-04-30 18:36:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 3, 18 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726468522335997952",
  "text" : "RT @antifreezeprot: When it comes to harassment, stop doing it, and we\u2019ll stop complaining. Same for gender discrimination. https:\/\/t.co\/fl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genderbias",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/flZ4K8WZvW",
        "expanded_url" : "http:\/\/bit.ly\/1SVCoeb",
        "display_url" : "bit.ly\/1SVCoeb"
      } ]
    },
    "geo" : { },
    "id_str" : "726459929859596288",
    "text" : "When it comes to harassment, stop doing it, and we\u2019ll stop complaining. Same for gender discrimination. https:\/\/t.co\/flZ4K8WZvW #genderbias",
    "id" : 726459929859596288,
    "created_at" : "2016-04-30 17:15:18 +0000",
    "user" : {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "protected" : false,
      "id_str" : "851420822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741741227914231808\/8sZOBYzU_normal.jpg",
      "id" : 851420822,
      "verified" : false
    }
  },
  "id" : 726468522335997952,
  "created_at" : "2016-04-30 17:49:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 0, 13 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726407321686036480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17413463409624, 8.630586323991771 ]
  },
  "id_str" : "726414356687233024",
  "in_reply_to_user_id" : 3059929578,
  "text" : "@repositiveio happy to help out. Let me know if I ever again can be of service.",
  "id" : 726414356687233024,
  "in_reply_to_status_id" : 726407321686036480,
  "created_at" : "2016-04-30 14:14:13 +0000",
  "in_reply_to_screen_name" : "repositiveio",
  "in_reply_to_user_id_str" : "3059929578",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Robin Rice",
      "screen_name" : "sparrowbarley",
      "indices" : [ 46, 60 ],
      "id_str" : "186096225",
      "id" : 186096225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726406340126597121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17413452902768, 8.630586395033157 ]
  },
  "id_str" : "726414278190878721",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk meet her if you ever get the chance. @sparrowbarley is such an inspiring person!",
  "id" : 726414278190878721,
  "in_reply_to_status_id" : 726406340126597121,
  "created_at" : "2016-04-30 14:13:54 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/a4bYMWJupO",
      "expanded_url" : "http:\/\/ruleofthirds.de\/force2016\/",
      "display_url" : "ruleofthirds.de\/force2016\/"
    } ]
  },
  "geo" : { },
  "id_str" : "726402518528479232",
  "text" : "I did a quick write-up of my experience at #FORCE2016: https:\/\/t.co\/a4bYMWJupO",
  "id" : 726402518528479232,
  "created_at" : "2016-04-30 13:27:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726359219235000320",
  "geo" : { },
  "id_str" : "726359296750043136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer working on one for the stuff I did so far already ;)",
  "id" : 726359296750043136,
  "in_reply_to_status_id" : 726359219235000320,
  "created_at" : "2016-04-30 10:35:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726358829139550208",
  "geo" : { },
  "id_str" : "726358948752818176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nah, didn\u2019t so far. Actually have planned this as a small side-project for next week during my vacation :D",
  "id" : 726358948752818176,
  "in_reply_to_status_id" : 726358829139550208,
  "created_at" : "2016-04-30 10:34:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726122053703618561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084095309784, 8.818590313882906 ]
  },
  "id_str" : "726129487713304576",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds so you\u2019re doing even better!",
  "id" : 726129487713304576,
  "in_reply_to_status_id" : 726122053703618561,
  "created_at" : "2016-04-29 19:22:15 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/AT9cL2n2wr",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726055107360600064",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    }, {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/nB3VPu5J44",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726067246460731392",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726115849220677632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097342719048, 8.818531521134013 ]
  },
  "id_str" : "726117839866875904",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds yes, see how great Iran is doing! https:\/\/t.co\/AT9cL2n2wr  and https:\/\/t.co\/nB3VPu5J44",
  "id" : 726117839866875904,
  "in_reply_to_status_id" : 726115849220677632,
  "created_at" : "2016-04-29 18:35:58 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 3, 14 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/vrkbYNWDUf",
      "expanded_url" : "https:\/\/twitter.com\/loughlin\/status\/726107242932609024",
      "display_url" : "twitter.com\/loughlin\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726116282194624512",
  "text" : "RT @mollyclare: I can't \"snrk\" hard enough.  https:\/\/t.co\/vrkbYNWDUf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/vrkbYNWDUf",
        "expanded_url" : "https:\/\/twitter.com\/loughlin\/status\/726107242932609024",
        "display_url" : "twitter.com\/loughlin\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726110609473941504",
    "text" : "I can't \"snrk\" hard enough.  https:\/\/t.co\/vrkbYNWDUf",
    "id" : 726110609473941504,
    "created_at" : "2016-04-29 18:07:14 +0000",
    "user" : {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "protected" : false,
      "id_str" : "12138192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875775628762640385\/Es8xAowp_normal.jpg",
      "id" : 12138192,
      "verified" : false
    }
  },
  "id" : 726116282194624512,
  "created_at" : "2016-04-29 18:29:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TP1024",
      "screen_name" : "tp_1024",
      "indices" : [ 0, 8 ],
      "id_str" : "632102396",
      "id" : 632102396
    }, {
      "name" : "Philipp Hummel",
      "screen_name" : "p_humm",
      "indices" : [ 9, 16 ],
      "id_str" : "390742975",
      "id" : 390742975
    }, {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 17, 31 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 32, 36 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726102387325325312\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/YKu1znFucA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOiRUEWkAEZrId.jpg",
      "id_str" : "726102383265222657",
      "id" : 726102383265222657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOiRUEWkAEZrId.jpg",
      "sizes" : [ {
        "h" : 1913,
        "resize" : "fit",
        "w" : 3907
      }, {
        "h" : 1003,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/YKu1znFucA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726078483999408129",
  "geo" : { },
  "id_str" : "726102387325325312",
  "in_reply_to_user_id" : 632102396,
  "text" : "@tp_1024 @p_humm @worldbankdata @tkb here you go! https:\/\/t.co\/YKu1znFucA",
  "id" : 726102387325325312,
  "in_reply_to_status_id" : 726078483999408129,
  "created_at" : "2016-04-29 17:34:34 +0000",
  "in_reply_to_screen_name" : "tp_1024",
  "in_reply_to_user_id_str" : "632102396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/AT9cL2n2wr",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726055107360600064",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726052444761915395",
  "geo" : { },
  "id_str" : "726099511790194690",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney @shefw and here\u2019s me putting it to use! https:\/\/t.co\/AT9cL2n2wr",
  "id" : 726099511790194690,
  "in_reply_to_status_id" : 726052444761915395,
  "created_at" : "2016-04-29 17:23:08 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas",
      "screen_name" : "ivh",
      "indices" : [ 0, 4 ],
      "id_str" : "4252031",
      "id" : 4252031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726080345720918017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388345954828, 8.753462894203672 ]
  },
  "id_str" : "726082933228974080",
  "in_reply_to_user_id" : 4252031,
  "text" : "@ivh up to a point. You need enough personal safety to care for research and access to the web.",
  "id" : 726082933228974080,
  "in_reply_to_status_id" : 726080345720918017,
  "created_at" : "2016-04-29 16:17:15 +0000",
  "in_reply_to_screen_name" : "ivh",
  "in_reply_to_user_id_str" : "4252031",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726078771279855616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400506052261, 8.753481447965743 ]
  },
  "id_str" : "726082630748409857",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yep, hast ein gutes Auge :)",
  "id" : 726082630748409857,
  "in_reply_to_status_id" : 726078771279855616,
  "created_at" : "2016-04-29 16:16:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    }, {
      "name" : "Glenn K. Lockwood",
      "screen_name" : "glennklockwood",
      "indices" : [ 13, 28 ],
      "id_str" : "39569710",
      "id" : 39569710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726074805317959680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17094426667085, 8.627969360666093 ]
  },
  "id_str" : "726075205563637760",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp @glennklockwood didn\u2019t do correlations but looking at it: industrialized nations fall above the line, war-ridden nations below.",
  "id" : 726075205563637760,
  "in_reply_to_status_id" : 726074805317959680,
  "created_at" : "2016-04-29 15:46:33 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726074031720390656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227526540168, 8.627655026211269 ]
  },
  "id_str" : "726074666893332480",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy COI: I did some minor contributions to it :)",
  "id" : 726074666893332480,
  "in_reply_to_status_id" : 726074031720390656,
  "created_at" : "2016-04-29 15:44:25 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726074140587900928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227526540168, 8.627655026211269 ]
  },
  "id_str" : "726074378312671235",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb it\u2019s rather new. But glad it can be useful for you!",
  "id" : 726074378312671235,
  "in_reply_to_status_id" : 726074140587900928,
  "created_at" : "2016-04-29 15:43:16 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/nB3VPu5J44",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726067246460731392",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726072859550953472",
  "geo" : { },
  "id_str" : "726073034675724288",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich https:\/\/t.co\/nB3VPu5J44",
  "id" : 726073034675724288,
  "in_reply_to_status_id" : 726072859550953472,
  "created_at" : "2016-04-29 15:37:55 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/4VSPaNp29t",
      "expanded_url" : "https:\/\/github.com\/thewinnower\/terrier",
      "display_url" : "github.com\/thewinnower\/te\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726072217646194688",
  "geo" : { },
  "id_str" : "726072972365148160",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy getting some meta-data based on DOI is super easy, at least for title: https:\/\/t.co\/4VSPaNp29t",
  "id" : 726072972365148160,
  "in_reply_to_status_id" : 726072217646194688,
  "created_at" : "2016-04-29 15:37:41 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    }, {
      "name" : "Glenn K. Lockwood",
      "screen_name" : "glennklockwood",
      "indices" : [ 13, 28 ],
      "id_str" : "39569710",
      "id" : 39569710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726072355743764481",
  "geo" : { },
  "id_str" : "726072651463188480",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp @glennklockwood but not only! Many interesting outliers.",
  "id" : 726072651463188480,
  "in_reply_to_status_id" : 726072355743764481,
  "created_at" : "2016-04-29 15:36:24 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Reagan",
      "screen_name" : "andyreagan",
      "indices" : [ 0, 11 ],
      "id_str" : "55931868",
      "id" : 55931868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726068280469893120",
  "geo" : { },
  "id_str" : "726069435694469120",
  "in_reply_to_user_id" : 55931868,
  "text" : "@andyreagan absolutely, lots to see there :)",
  "id" : 726069435694469120,
  "in_reply_to_status_id" : 726068280469893120,
  "created_at" : "2016-04-29 15:23:37 +0000",
  "in_reply_to_screen_name" : "andyreagan",
  "in_reply_to_user_id_str" : "55931868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726058903360946176",
  "geo" : { },
  "id_str" : "726069318488870912",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yes! See also the absolute differences from the predicted numbers posted here :)",
  "id" : 726069318488870912,
  "in_reply_to_status_id" : 726058903360946176,
  "created_at" : "2016-04-29 15:23:09 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Lu\u0161trik",
      "screen_name" : "romunov",
      "indices" : [ 0, 8 ],
      "id_str" : "158756964",
      "id" : 158756964
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 9, 13 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726068971041083393\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/gPeNBupNDX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOD35pWgAENmeG.jpg",
      "id_str" : "726068961327087617",
      "id" : 726068961327087617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOD35pWgAENmeG.jpg",
      "sizes" : [ {
        "h" : 2739,
        "resize" : "fit",
        "w" : 5492
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/gPeNBupNDX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726068420219908096",
  "geo" : { },
  "id_str" : "726068971041083393",
  "in_reply_to_user_id" : 158756964,
  "text" : "@romunov @tkb ok, one last one for now. Will write up a bit about it and release data hopefully tomorrow. https:\/\/t.co\/gPeNBupNDX",
  "id" : 726068971041083393,
  "in_reply_to_status_id" : 726068420219908096,
  "created_at" : "2016-04-29 15:21:47 +0000",
  "in_reply_to_screen_name" : "romunov",
  "in_reply_to_user_id_str" : "158756964",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Lu\u0161trik",
      "screen_name" : "romunov",
      "indices" : [ 0, 8 ],
      "id_str" : "158756964",
      "id" : 158756964
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 9, 13 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726068187880628226\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/SO6PqQB0Ef",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChODKkIUcAEDPA2.jpg",
      "id_str" : "726068182457282561",
      "id" : 726068182457282561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChODKkIUcAEDPA2.jpg",
      "sizes" : [ {
        "h" : 2739,
        "resize" : "fit",
        "w" : 5492
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/SO6PqQB0Ef"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726067466607185920",
  "geo" : { },
  "id_str" : "726068187880628226",
  "in_reply_to_user_id" : 158756964,
  "text" : "@romunov @tkb well\u2026 ;) https:\/\/t.co\/SO6PqQB0Ef",
  "id" : 726068187880628226,
  "in_reply_to_status_id" : 726067466607185920,
  "created_at" : "2016-04-29 15:18:40 +0000",
  "in_reply_to_screen_name" : "romunov",
  "in_reply_to_user_id_str" : "158756964",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726067246460731392\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bRWneYd2vZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOCT03WgAAnPpA.jpg",
      "id_str" : "726067242056712192",
      "id" : 726067242056712192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOCT03WgAAnPpA.jpg",
      "sizes" : [ {
        "h" : 2739,
        "resize" : "fit",
        "w" : 5492
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bRWneYd2vZ"
    } ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726055107360600064",
  "geo" : { },
  "id_str" : "726067246460731392",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u2206 in residuals, which is ~ (observed downloads) minus (downloads predicted by glm) #scihub https:\/\/t.co\/bRWneYd2vZ",
  "id" : 726067246460731392,
  "in_reply_to_status_id" : 726055107360600064,
  "created_at" : "2016-04-29 15:14:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Lu\u0161trik",
      "screen_name" : "romunov",
      "indices" : [ 0, 8 ],
      "id_str" : "158756964",
      "id" : 158756964
    }, {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 9, 22 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/hOBsf4Ac4f",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/725982992812892160",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "726066045505691649",
  "geo" : { },
  "id_str" : "726066211247788033",
  "in_reply_to_user_id" : 158756964,
  "text" : "@romunov @randal_olson you\u2019re right. Did that later on: https:\/\/t.co\/hOBsf4Ac4f",
  "id" : 726066211247788033,
  "in_reply_to_status_id" : 726066045505691649,
  "created_at" : "2016-04-29 15:10:49 +0000",
  "in_reply_to_screen_name" : "romunov",
  "in_reply_to_user_id_str" : "158756964",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/VRCdQmm0rJ",
      "expanded_url" : "https:\/\/github.com\/slowkow\/ggrepel",
      "display_url" : "github.com\/slowkow\/ggrepel"
    } ]
  },
  "in_reply_to_status_id_str" : "726059577012326400",
  "geo" : { },
  "id_str" : "726059696575111168",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb that\u2019s ggplot along with the ggrepel extension https:\/\/t.co\/VRCdQmm0rJ",
  "id" : 726059696575111168,
  "in_reply_to_status_id" : 726059577012326400,
  "created_at" : "2016-04-29 14:44:55 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Alex Schestag)))",
      "screen_name" : "AlexSchestag",
      "indices" : [ 0, 13 ],
      "id_str" : "16813608",
      "id" : 16813608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726058131072139269",
  "geo" : { },
  "id_str" : "726058245891182593",
  "in_reply_to_user_id" : 16813608,
  "text" : "@AlexSchestag yep, R + ggplot2 + ggrepel :)",
  "id" : 726058245891182593,
  "in_reply_to_status_id" : 726058131072139269,
  "created_at" : "2016-04-29 14:39:09 +0000",
  "in_reply_to_screen_name" : "AlexSchestag",
  "in_reply_to_user_id_str" : "16813608",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726055107360600064",
  "geo" : { },
  "id_str" : "726056020338991104",
  "in_reply_to_user_id" : 14286491,
  "text" : "Regression done with stat_smooth(method=\u201Eglm\u201C).",
  "id" : 726056020338991104,
  "in_reply_to_status_id" : 726055107360600064,
  "created_at" : "2016-04-29 14:30:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Bank Data",
      "screen_name" : "worldbankdata",
      "indices" : [ 92, 106 ],
      "id_str" : "203332110",
      "id" : 203332110
    }, {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 111, 115 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/726055107360600064\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/RNhsoHiVPN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChN3RWKWIAAzbM2.png",
      "id_str" : "726055104827236352",
      "id" : 726055104827236352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChN3RWKWIAAzbM2.png",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1089,
        "resize" : "fit",
        "w" : 1952
      }, {
        "h" : 1089,
        "resize" : "fit",
        "w" : 1952
      } ],
      "display_url" : "pic.twitter.com\/RNhsoHiVPN"
    } ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725979530268127232",
  "geo" : { },
  "id_str" : "726055107360600064",
  "in_reply_to_user_id" : 14286491,
  "text" : "More on #scihub data: Number of downloads plotted against 2014 population size according to @worldbankdata \/cc @tkb https:\/\/t.co\/RNhsoHiVPN",
  "id" : 726055107360600064,
  "in_reply_to_status_id" : 725979530268127232,
  "created_at" : "2016-04-29 14:26:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726042436351479808",
  "geo" : { },
  "id_str" : "726052590589493248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep!",
  "id" : 726052590589493248,
  "in_reply_to_status_id" : 726042436351479808,
  "created_at" : "2016-04-29 14:16:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726041891255521280",
  "geo" : { },
  "id_str" : "726042133292048384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i want to do one!",
  "id" : 726042133292048384,
  "in_reply_to_status_id" : 726041891255521280,
  "created_at" : "2016-04-29 13:35:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/EaxUge3Fuy",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2016\/04\/29\/genomics-england-decide-to-just-impute-from-1000-genomes-data\/",
      "display_url" : "thescienceweb.wordpress.com\/2016\/04\/29\/gen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726035118717079552",
  "text" : "What do you mean, staff &amp; computing power?! \u00ABGenomics England decide to just impute from 1000 genomes\u00A0data\u00BB \uD83D\uDE02 https:\/\/t.co\/EaxUge3Fuy",
  "id" : 726035118717079552,
  "created_at" : "2016-04-29 13:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726020545846861825",
  "geo" : { },
  "id_str" : "726021916436389888",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 it\u2019s the default of ggplot :D",
  "id" : 726021916436389888,
  "in_reply_to_status_id" : 726020545846861825,
  "created_at" : "2016-04-29 12:14:48 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/foUKQtPesz",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/pen15-club-members-only-coloring-book#\/",
      "display_url" : "indiegogo.com\/projects\/pen15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726006597961568257",
  "text" : "what crowdfunding was really made for: \u00ABthe penis coloring book\u00BB https:\/\/t.co\/foUKQtPesz",
  "id" : 726006597961568257,
  "created_at" : "2016-04-29 11:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725984423607414784",
  "geo" : { },
  "id_str" : "726006240837554176",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye and I doubt that there\u2019s a systematic bias for underestimating at work.",
  "id" : 726006240837554176,
  "in_reply_to_status_id" : 725984423607414784,
  "created_at" : "2016-04-29 11:12:31 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725984423607414784",
  "geo" : { },
  "id_str" : "726006057030565889",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks, I assumed that much, but I\u2019m not close to the geographical center of Germany, so the numbers will only be under-estimated.",
  "id" : 726006057030565889,
  "in_reply_to_status_id" : 725984423607414784,
  "created_at" : "2016-04-29 11:11:47 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Travis",
      "screen_name" : "johnstravis",
      "indices" : [ 0, 12 ],
      "id_str" : "318586377",
      "id" : 318586377
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 13, 23 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725992067776823296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17487386693046, 8.615535798333706 ]
  },
  "id_str" : "725993237446582272",
  "in_reply_to_user_id" : 318586377,
  "text" : "@johnstravis @blahah404 yes!",
  "id" : 725993237446582272,
  "in_reply_to_status_id" : 725992067776823296,
  "created_at" : "2016-04-29 10:20:50 +0000",
  "in_reply_to_screen_name" : "johnstravis",
  "in_reply_to_user_id_str" : "318586377",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "John Travis",
      "screen_name" : "johnstravis",
      "indices" : [ 11, 23 ],
      "id_str" : "318586377",
      "id" : 318586377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725985235956056064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17274798993799, 8.627514323719247 ]
  },
  "id_str" : "725987964120109056",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @johnstravis but bulk is in working hours.",
  "id" : 725987964120109056,
  "in_reply_to_status_id" : 725985235956056064,
  "created_at" : "2016-04-29 09:59:53 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Travis",
      "screen_name" : "johnstravis",
      "indices" : [ 0, 12 ],
      "id_str" : "318586377",
      "id" : 318586377
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 13, 23 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725984361452036097",
  "geo" : { },
  "id_str" : "725985029155905536",
  "in_reply_to_user_id" : 318586377,
  "text" : "@johnstravis @blahah404 but I\u2019d say most people use it from work for papers they don\u2019t have lib-access to.",
  "id" : 725985029155905536,
  "in_reply_to_status_id" : 725984361452036097,
  "created_at" : "2016-04-29 09:48:13 +0000",
  "in_reply_to_screen_name" : "johnstravis",
  "in_reply_to_user_id_str" : "318586377",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Travis",
      "screen_name" : "johnstravis",
      "indices" : [ 0, 12 ],
      "id_str" : "318586377",
      "id" : 318586377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725984361452036097",
  "geo" : { },
  "id_str" : "725984766122704896",
  "in_reply_to_user_id" : 318586377,
  "text" : "@johnstravis I just saw yours, well done! I just wondered whether it might be the inverse: people using sci-hub from home when no lib-access",
  "id" : 725984766122704896,
  "in_reply_to_status_id" : 725984361452036097,
  "created_at" : "2016-04-29 09:47:11 +0000",
  "in_reply_to_screen_name" : "johnstravis",
  "in_reply_to_user_id_str" : "318586377",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Travis",
      "screen_name" : "johnstravis",
      "indices" : [ 0, 12 ],
      "id_str" : "318586377",
      "id" : 318586377
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 13, 23 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725984011659661312",
  "geo" : { },
  "id_str" : "725984166739845120",
  "in_reply_to_user_id" : 318586377,
  "text" : "@johnstravis @blahah404 thanks! :)",
  "id" : 725984166739845120,
  "in_reply_to_status_id" : 725984011659661312,
  "created_at" : "2016-04-29 09:44:48 +0000",
  "in_reply_to_screen_name" : "johnstravis",
  "in_reply_to_user_id_str" : "318586377",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725979962096889856",
  "geo" : { },
  "id_str" : "725983064451588097",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 seems to hover perfectly around 9 to 5 :p",
  "id" : 725983064451588097,
  "in_reply_to_status_id" : 725979962096889856,
  "created_at" : "2016-04-29 09:40:25 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/725982992812892160\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wQCReMSen0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChM1rMBUYAAGsjB.jpg",
      "id_str" : "725982981014183936",
      "id" : 725982981014183936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChM1rMBUYAAGsjB.jpg",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2391,
        "resize" : "fit",
        "w" : 4311
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wQCReMSen0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/725982992812892160\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wQCReMSen0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChM1rroXEAEP9Ec.jpg",
      "id_str" : "725982989499437057",
      "id" : 725982989499437057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChM1rroXEAEP9Ec.jpg",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2391,
        "resize" : "fit",
        "w" : 4311
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wQCReMSen0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725979962096889856",
  "geo" : { },
  "id_str" : "725982992812892160",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 think we both we\u2019re wrong. It\u2019s UTC I think, after selecting two country subsets. https:\/\/t.co\/wQCReMSen0",
  "id" : 725982992812892160,
  "in_reply_to_status_id" : 725979962096889856,
  "created_at" : "2016-04-29 09:40:08 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725979652024619008",
  "geo" : { },
  "id_str" : "725979795553697792",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 not sure how encoded in the data. But as they have the location I\u2019d say TZ of person downloading the files.",
  "id" : 725979795553697792,
  "in_reply_to_status_id" : 725979652024619008,
  "created_at" : "2016-04-29 09:27:25 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/725979530268127232\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lGOIh8rS2p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChMyiHLXEAAOcN3.jpg",
      "id_str" : "725979526560419840",
      "id" : 725979526560419840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChMyiHLXEAAOcN3.jpg",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2391,
        "resize" : "fit",
        "w" : 4311
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/lGOIh8rS2p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725968334236176385",
  "geo" : { },
  "id_str" : "725979530268127232",
  "in_reply_to_user_id" : 14286491,
  "text" : "Sci-Hub Downloads for February 2016 by Hour\/Weekday. I\u2019d say it looks like tons of downloads are from universities. https:\/\/t.co\/lGOIh8rS2p",
  "id" : 725979530268127232,
  "in_reply_to_status_id" : 725968334236176385,
  "created_at" : "2016-04-29 09:26:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/r9ytayo899",
      "expanded_url" : "https:\/\/49.media.tumblr.com\/3fdc622926c85cb31f8663065cfa702d\/tumblr_mg0wdveyAN1r75c30o1_500.gif",
      "display_url" : "49.media.tumblr.com\/3fdc622926c85c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725967708198674432",
  "geo" : { },
  "id_str" : "725968334236176385",
  "in_reply_to_user_id" : 14286491,
  "text" : "I wonder how many of those 21k downloads come from inside the university network. https:\/\/t.co\/r9ytayo899",
  "id" : 725968334236176385,
  "in_reply_to_status_id" : 725967708198674432,
  "created_at" : "2016-04-29 08:41:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/h9Bl28y38n",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/725915769075163138",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725967708198674432",
  "text" : "They also offer the raw data. 21k sci-hub downloads from Frankfurt, 150 from the city where I\u2019m living. https:\/\/t.co\/h9Bl28y38n",
  "id" : 725967708198674432,
  "created_at" : "2016-04-29 08:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725935034121617408",
  "geo" : { },
  "id_str" : "725953334562185216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I can bring some over in July :D",
  "id" : 725953334562185216,
  "in_reply_to_status_id" : 725935034121617408,
  "created_at" : "2016-04-29 07:42:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNA_Stellfox",
      "screen_name" : "dna_stellfox",
      "indices" : [ 0, 13 ],
      "id_str" : "717431376769900544",
      "id" : 717431376769900544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725407925267759105",
  "geo" : { },
  "id_str" : "725729509631221761",
  "in_reply_to_user_id" : 717431376769900544,
  "text" : "@dna_stellfox we think it\u2019s the latter, at least in the context of publishing your genome.",
  "id" : 725729509631221761,
  "in_reply_to_status_id" : 725407925267759105,
  "created_at" : "2016-04-28 16:52:53 +0000",
  "in_reply_to_screen_name" : "dna_stellfox",
  "in_reply_to_user_id_str" : "717431376769900544",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "INCF",
      "screen_name" : "INCForg",
      "indices" : [ 10, 18 ],
      "id_str" : "180310067",
      "id" : 180310067
    }, {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 67, 76 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725726928091648001",
  "geo" : { },
  "id_str" : "725727102213955584",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @INCForg nice. We\u2019re under the umbrella of the wonderful @obf_news who took us in!",
  "id" : 725727102213955584,
  "in_reply_to_status_id" : 725726928091648001,
  "created_at" : "2016-04-28 16:43:19 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725725675341135873",
  "geo" : { },
  "id_str" : "725725761970278400",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr we were really lucky and will have 3 students!",
  "id" : 725725761970278400,
  "in_reply_to_status_id" : 725725675341135873,
  "created_at" : "2016-04-28 16:37:59 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725721600918691841",
  "text" : "@malech \u201EDie 36 F\u00E4lle\u201C, kein wunder das niemand die Deutsche Grammatik mag :p",
  "id" : 725721600918691841,
  "created_at" : "2016-04-28 16:21:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725720732886556673",
  "text" : "From \u2018I just counted all my files, I shouldn\u2019t be over my disk quota!\u2019 to \u2018Oh, I totally forgot about this project!\u2019\u2026",
  "id" : 725720732886556673,
  "created_at" : "2016-04-28 16:18:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725717803773239300",
  "geo" : { },
  "id_str" : "725718503202906112",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish one is improving the UX\/UI, one linking genetics &lt;-&gt; phenotypes, last 1 is working on getting more quantified self-data in.",
  "id" : 725718503202906112,
  "in_reply_to_status_id" : 725717803773239300,
  "created_at" : "2016-04-28 16:09:09 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes'fish'Ziemke",
      "screen_name" : "discordianfish",
      "indices" : [ 0, 15 ],
      "id_str" : "21647811",
      "id" : 21647811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/FgGGauyr1Y",
      "expanded_url" : "http:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "in_reply_to_status_id_str" : "725717803773239300",
  "geo" : { },
  "id_str" : "725718335187509249",
  "in_reply_to_user_id" : 21647811,
  "text" : "@discordianfish we\u2019ll have 3 students working on features\/improvements for https:\/\/t.co\/FgGGauyr1Y",
  "id" : 725718335187509249,
  "in_reply_to_status_id" : 725717803773239300,
  "created_at" : "2016-04-28 16:08:28 +0000",
  "in_reply_to_screen_name" : "discordianfish",
  "in_reply_to_user_id_str" : "21647811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725717261928022016",
  "text" : "First GSoC student has his development environment set up! \uD83D\uDC4D\uD83D\uDC96",
  "id" : 725717261928022016,
  "created_at" : "2016-04-28 16:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 73, 79 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725696387522813953",
  "geo" : { },
  "id_str" : "725697349566255104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch too bad, we could do a live interpretation of @dvzrv\u2019s work! :D",
  "id" : 725697349566255104,
  "in_reply_to_status_id" : 725696387522813953,
  "created_at" : "2016-04-28 14:45:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725680711739518978",
  "geo" : { },
  "id_str" : "725680964437987328",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer wasn\u2019t too much on HN lately, so I missed it. Sounds nice though!",
  "id" : 725680964437987328,
  "in_reply_to_status_id" : 725680711739518978,
  "created_at" : "2016-04-28 13:39:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Gabo MH",
      "screen_name" : "gaboentropy",
      "indices" : [ 17, 29 ],
      "id_str" : "818581436",
      "id" : 818581436
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 30, 44 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725676845815992320",
  "geo" : { },
  "id_str" : "725677236532170752",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @gaboentropy @BioMickWatson there you go, straight out of \u201E10 simple rules to publish your work in nature\/science\/cell\u201C.",
  "id" : 725677236532170752,
  "in_reply_to_status_id" : 725676845815992320,
  "created_at" : "2016-04-28 13:25:10 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 17, 31 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725670704969043968",
  "geo" : { },
  "id_str" : "725670884413952000",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @BioMickWatson yep, wasn\u2019t too surprised about Bradyrhizobium until that point either.",
  "id" : 725670884413952000,
  "in_reply_to_status_id" : 725670704969043968,
  "created_at" : "2016-04-28 12:59:55 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725670274411155457",
  "geo" : { },
  "id_str" : "725670719405871104",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick and is it just me or are neither the SRA nor the GenBank sequences available?",
  "id" : 725670719405871104,
  "in_reply_to_status_id" : 725670274411155457,
  "created_at" : "2016-04-28 12:59:16 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/3tG0nhndbm",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007\/s00248-016-0755-3",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725669196961570816",
  "geo" : { },
  "id_str" : "725669884508655618",
  "in_reply_to_user_id" : 14286491,
  "text" : "@pathogenomenick see my original tweet in the thread :D https:\/\/t.co\/3tG0nhndbm",
  "id" : 725669884508655618,
  "in_reply_to_status_id" : 725669196961570816,
  "created_at" : "2016-04-28 12:55:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 118, 134 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725663153707737088",
  "geo" : { },
  "id_str" : "725669196961570816",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABSingle Bradyrhizobium OTU was dominant across all species, continents, and two independent primer sets.\u00BB how-to make @pathogenomenick cry?",
  "id" : 725669196961570816,
  "in_reply_to_status_id" : 725663153707737088,
  "created_at" : "2016-04-28 12:53:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine",
      "screen_name" : "mbonsma",
      "indices" : [ 3, 11 ],
      "id_str" : "422839831",
      "id" : 422839831
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 31, 46 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725665235600838658",
  "text" : "RT @mbonsma: I'll be MCing the @MozillaScience project call at 12ET today - come see what's new in the world of #openscience! \n\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 18, 33 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/T1F4mKddTn",
        "expanded_url" : "https:\/\/public.etherpad-mozilla.org\/p\/sciencelab-project-call-apr28-2016",
        "display_url" : "public.etherpad-mozilla.org\/p\/sciencelab-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725660999974551552",
    "text" : "I'll be MCing the @MozillaScience project call at 12ET today - come see what's new in the world of #openscience! \n\nhttps:\/\/t.co\/T1F4mKddTn",
    "id" : 725660999974551552,
    "created_at" : "2016-04-28 12:20:39 +0000",
    "user" : {
      "name" : "Madeleine",
      "screen_name" : "mbonsma",
      "protected" : false,
      "id_str" : "422839831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837015721469218828\/bqRa4-ha_normal.jpg",
      "id" : 422839831,
      "verified" : false
    }
  },
  "id" : 725665235600838658,
  "created_at" : "2016-04-28 12:37:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 48, 61 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725657697488633857",
  "geo" : { },
  "id_str" : "725665109725593600",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch we should do an openSNP-band, with @PhilippBayer on the Ukulele!",
  "id" : 725665109725593600,
  "in_reply_to_status_id" : 725657697488633857,
  "created_at" : "2016-04-28 12:36:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/3tG0nhndbm",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007\/s00248-016-0755-3",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725663153707737088",
  "text" : "Started reading about the truffle microbiome and now i\u2019m hungry. damn you fungal genomics! \/o\\ https:\/\/t.co\/3tG0nhndbm",
  "id" : 725663153707737088,
  "created_at" : "2016-04-28 12:29:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Salzberg",
      "screen_name" : "StevenSalzberg1",
      "indices" : [ 29, 45 ],
      "id_str" : "782615960",
      "id" : 782615960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/D0bAs3wqRI",
      "expanded_url" : "http:\/\/bmcbioinformatics.biomedcentral.com\/articles\/10.1186\/s12859-015-0668-z",
      "display_url" : "bmcbioinformatics.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725617096659472384",
  "geo" : { },
  "id_str" : "725662495042621440",
  "in_reply_to_user_id" : 14286491,
  "text" : "Totally missed this piece by @StevenSalzberg1 about the mis-use of supplements when it came out. https:\/\/t.co\/D0bAs3wqRI",
  "id" : 725662495042621440,
  "in_reply_to_status_id" : 725617096659472384,
  "created_at" : "2016-04-28 12:26:35 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725617096659472384",
  "geo" : { },
  "id_str" : "725617412658356224",
  "in_reply_to_user_id" : 14286491,
  "text" : "I have the feeling that this guarantees that nobody performed any significant peer review on it, because: \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 725617412658356224,
  "in_reply_to_status_id" : 725617096659472384,
  "created_at" : "2016-04-28 09:27:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725617096659472384",
  "text" : "a 134 pages supplement that contains all important method. details &amp; results but is formatted w\/ figures &amp; tables put in the end. \uD83D\uDE2D",
  "id" : 725617096659472384,
  "created_at" : "2016-04-28 09:26:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    }, {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 13, 22 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725611470474629120",
  "geo" : { },
  "id_str" : "725612011170701313",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp @arvestad The Final Fantasy Countdown.",
  "id" : 725612011170701313,
  "in_reply_to_status_id" : 725611470474629120,
  "created_at" : "2016-04-28 09:05:59 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/iBxb2v1AdD",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/265860340\/nes-paul-nintendo-electric-guitar-games",
      "display_url" : "etsy.com\/listing\/265860\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725606450807103488",
  "text" : "ok, the \u201ENES Paul\u201C takes the hipster guitar genre all the way to 11. https:\/\/t.co\/iBxb2v1AdD",
  "id" : 725606450807103488,
  "created_at" : "2016-04-28 08:43:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725415699359891457",
  "geo" : { },
  "id_str" : "725415918956847104",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \u00FCberall die gleichen Usernamen wie hier auch :p",
  "id" : 725415918956847104,
  "in_reply_to_status_id" : 725415699359891457,
  "created_at" : "2016-04-27 20:06:47 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725201701846847488",
  "geo" : { },
  "id_str" : "725414440124973056",
  "in_reply_to_user_id" : 14286491,
  "text" : "But: 3\/4 of the participants on the panel were female (after having fought the battle about representation when they first contacted me) \\o\/",
  "id" : 725414440124973056,
  "in_reply_to_status_id" : 725201701846847488,
  "created_at" : "2016-04-27 20:00:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725413616141357056",
  "geo" : { },
  "id_str" : "725413771422879745",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s das ist lieb. Ich dachte in dem Augenblick tats\u00E4chlich \u201Ek\u00F6nnt ihr nicht stattdessen aus meinem Fetlife-Profil vorlesen\u201C?",
  "id" : 725413771422879745,
  "in_reply_to_status_id" : 725413616141357056,
  "created_at" : "2016-04-27 19:58:15 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725413107120627714",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092474749457, 8.818627805834689 ]
  },
  "id_str" : "725413151504797696",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes noooo!",
  "id" : 725413151504797696,
  "in_reply_to_status_id" : 725413107120627714,
  "created_at" : "2016-04-27 19:55:47 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725413037063176192",
  "text" : "Today I was introduced as \u201Emember of the pirate party &amp; running for parliament\u201C. I\u2019m rarely embarrassed by things, but this did the job.",
  "id" : 725413037063176192,
  "created_at" : "2016-04-27 19:55:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725299066884751360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34915620093359, 12.37101693638821 ]
  },
  "id_str" : "725318090364473344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sagt wer?",
  "id" : 725318090364473344,
  "in_reply_to_status_id" : 725299066884751360,
  "created_at" : "2016-04-27 13:38:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34917982311767, 12.37095920836296 ]
  },
  "id_str" : "725317891957121024",
  "text" : "@stopifnot bist du in der N\u00E4he des Zoos?",
  "id" : 725317891957121024,
  "created_at" : "2016-04-27 13:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725294909318635521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34921476851962, 12.37104362200746 ]
  },
  "id_str" : "725317822964977664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep, that\u2019s just me.",
  "id" : 725317822964977664,
  "in_reply_to_status_id" : 725294909318635521,
  "created_at" : "2016-04-27 13:36:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725279237264003073",
  "text" : "RT @helgerausch: So, we have this data warehouse and need someone to take good care of it (or rebuild it). If that sounds great to you, ple\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725256293737480192",
    "text" : "So, we have this data warehouse and need someone to take good care of it (or rebuild it). If that sounds great to you, please talk to me!",
    "id" : 725256293737480192,
    "created_at" : "2016-04-27 09:32:29 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 725279237264003073,
  "created_at" : "2016-04-27 11:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 0, 8 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725205164487921664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34862547582799, 12.37101428202489 ]
  },
  "id_str" : "725277691616890880",
  "in_reply_to_user_id" : 19984919,
  "text" : "@JBYoder this is crying for a \u2018Darwin finds out systematics isn\u2019t solved\u2019-downfall meme.",
  "id" : 725277691616890880,
  "in_reply_to_status_id" : 725205164487921664,
  "created_at" : "2016-04-27 10:57:31 +0000",
  "in_reply_to_screen_name" : "JBYoder",
  "in_reply_to_user_id_str" : "19984919",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725201701846847488",
  "geo" : { },
  "id_str" : "725268535505723392",
  "in_reply_to_user_id" : 14286491,
  "text" : "Already spotted a single other person not wearing a suit-equivalent. Well that will be fun.",
  "id" : 725268535505723392,
  "in_reply_to_status_id" : 725201701846847488,
  "created_at" : "2016-04-27 10:21:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11451774747121, 8.751813909047051 ]
  },
  "id_str" : "725201701846847488",
  "text" : "Off to Leipzig to discuss \u2018Big Data\u2019 on a panel at the German Biotechnology Days.",
  "id" : 725201701846847488,
  "created_at" : "2016-04-27 05:55:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genome Galaxy",
      "screen_name" : "GenomeGalaxy",
      "indices" : [ 0, 13 ],
      "id_str" : "3924794952",
      "id" : 3924794952
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725194864778874880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391754095838, 8.753551903790365 ]
  },
  "id_str" : "725199473887088640",
  "in_reply_to_user_id" : 3924794952,
  "text" : "@GenomeGalaxy @PhilippBayer  predictions are always hard, especially concerning the future ;)",
  "id" : 725199473887088640,
  "in_reply_to_status_id" : 725194864778874880,
  "created_at" : "2016-04-27 05:46:42 +0000",
  "in_reply_to_screen_name" : "GenomeGalaxy",
  "in_reply_to_user_id_str" : "3924794952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cdrose",
      "screen_name" : "cdrose_writer",
      "indices" : [ 3, 17 ],
      "id_str" : "1905168630",
      "id" : 1905168630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cdrose_writer\/status\/691735860241416192\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/MgB4h34a5T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmKGNnWEAAtNhP.jpg",
      "id_str" : "691735857116614656",
      "id" : 691735857116614656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmKGNnWEAAtNhP.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/MgB4h34a5T"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/cdrose_writer\/status\/691735860241416192\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/MgB4h34a5T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmKGVuXEAAVnol.jpg",
      "id_str" : "691735859293523968",
      "id" : 691735859293523968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmKGVuXEAAVnol.jpg",
      "sizes" : [ {
        "h" : 621,
        "resize" : "fit",
        "w" : 461
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 461
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 461
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 461
      } ],
      "display_url" : "pic.twitter.com\/MgB4h34a5T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725078677168463873",
  "text" : "RT @cdrose_writer: Joyce on guitar, Wittgenstein on banjo.  Supergroup? https:\/\/t.co\/MgB4h34a5T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cdrose_writer\/status\/691735860241416192\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/MgB4h34a5T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmKGNnWEAAtNhP.jpg",
        "id_str" : "691735857116614656",
        "id" : 691735857116614656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmKGNnWEAAtNhP.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/MgB4h34a5T"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/cdrose_writer\/status\/691735860241416192\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/MgB4h34a5T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmKGVuXEAAVnol.jpg",
        "id_str" : "691735859293523968",
        "id" : 691735859293523968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmKGVuXEAAVnol.jpg",
        "sizes" : [ {
          "h" : 621,
          "resize" : "fit",
          "w" : 461
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 461
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 461
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 461
        } ],
        "display_url" : "pic.twitter.com\/MgB4h34a5T"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691735860241416192",
    "text" : "Joyce on guitar, Wittgenstein on banjo.  Supergroup? https:\/\/t.co\/MgB4h34a5T",
    "id" : 691735860241416192,
    "created_at" : "2016-01-25 21:34:15 +0000",
    "user" : {
      "name" : "cdrose",
      "screen_name" : "cdrose_writer",
      "protected" : false,
      "id_str" : "1905168630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724280207084011521\/Z6ssZbMZ_normal.jpg",
      "id" : 1905168630,
      "verified" : false
    }
  },
  "id" : 725078677168463873,
  "created_at" : "2016-04-26 21:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/2X5g0YqNNo",
      "expanded_url" : "http:\/\/www.nature.com\/news\/speak-up-about-subtle-sexism-in-science-1.19829",
      "display_url" : "nature.com\/news\/speak-up-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725062945957371904",
  "text" : "Speak up about subtle sexism in science https:\/\/t.co\/2X5g0YqNNo",
  "id" : 725062945957371904,
  "created_at" : "2016-04-26 20:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/uq4kn7QKZk",
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/725016526378532864",
      "display_url" : "twitter.com\/JBYoder\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725026402337198082",
  "text" : "Happy to contribute my own \u2018invented evolutionary synthesis\u2019 for that price tag. https:\/\/t.co\/uq4kn7QKZk",
  "id" : 725026402337198082,
  "created_at" : "2016-04-26 18:18:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/0jHiDME3nc",
      "expanded_url" : "http:\/\/www.nature.com\/ng\/journal\/vaop\/ncurrent\/full\/ng.3552.html",
      "display_url" : "nature.com\/ng\/journal\/vao\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724994376695484416",
  "text" : "According to this GWAS I\u2019m at a low risk for neuroticism. See how big data can lead to spurious correlations? https:\/\/t.co\/0jHiDME3nc",
  "id" : 724994376695484416,
  "created_at" : "2016-04-26 16:11:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendra Albert",
      "screen_name" : "KendraSerra",
      "indices" : [ 3, 15 ],
      "id_str" : "125195753",
      "id" : 125195753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/E5Tl6zhXmE",
      "expanded_url" : "https:\/\/medium.com\/on-archivy\/implications-of-archival-labor-b606d8d02014#.qsppvxdxj",
      "display_url" : "medium.com\/on-archivy\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724991067830018049",
  "text" : "RT @KendraSerra: Archiving requires labor. We could all stand to think about that more. https:\/\/t.co\/E5Tl6zhXmE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/E5Tl6zhXmE",
        "expanded_url" : "https:\/\/medium.com\/on-archivy\/implications-of-archival-labor-b606d8d02014#.qsppvxdxj",
        "display_url" : "medium.com\/on-archivy\/imp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724948930253959168",
    "text" : "Archiving requires labor. We could all stand to think about that more. https:\/\/t.co\/E5Tl6zhXmE",
    "id" : 724948930253959168,
    "created_at" : "2016-04-26 13:11:08 +0000",
    "user" : {
      "name" : "Kendra Albert",
      "screen_name" : "KendraSerra",
      "protected" : false,
      "id_str" : "125195753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773361272364503041\/FdBo5U1j_normal.jpg",
      "id" : 125195753,
      "verified" : false
    }
  },
  "id" : 724991067830018049,
  "created_at" : "2016-04-26 15:58:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/sSu4rfTrLZ",
      "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/724977473641926658",
      "display_url" : "twitter.com\/EffyVayena\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724978391720579075",
  "text" : "\u00ABas bodyhacking has become technology (which it wasn\u2019t always) it\u2019s become the realm of men.\u00BB \uD83D\uDE2D https:\/\/t.co\/sSu4rfTrLZ",
  "id" : 724978391720579075,
  "created_at" : "2016-04-26 15:08:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724972199338205184",
  "geo" : { },
  "id_str" : "724972539592712193",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not yet, but I should, because I already forgot half of them.",
  "id" : 724972539592712193,
  "in_reply_to_status_id" : 724972199338205184,
  "created_at" : "2016-04-26 14:44:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724968609735409664",
  "geo" : { },
  "id_str" : "724970095995457538",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u201Ethe accidental flexitarian\u201C, either yet another auto-biography chapter heading or a good title for a food podcast.",
  "id" : 724970095995457538,
  "in_reply_to_status_id" : 724968609735409664,
  "created_at" : "2016-04-26 14:35:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724967175350542336",
  "geo" : { },
  "id_str" : "724967798313725953",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot in that case I\u2019ll change my mind and happily take your money for doing it myself!",
  "id" : 724967798313725953,
  "in_reply_to_status_id" : 724967175350542336,
  "created_at" : "2016-04-26 14:26:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 3, 15 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "oa",
      "indices" : [ 121, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/j1NpHRMctz",
      "expanded_url" : "https:\/\/thewinnower.com\/posts\/contest-how-do-we-ensure-that-research-is-reproducible",
      "display_url" : "thewinnower.com\/posts\/contest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724958135958556672",
  "text" : "RT @theWinnower: CONTEST: How do we ensure that research is reproducible? (Pls RT!) https:\/\/t.co\/j1NpHRMctz #openscience #oa https:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/724950601084325889\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/HnxWXVFc4S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-KupSU0AAhBGl.jpg",
        "id_str" : "724950598991269888",
        "id" : 724950598991269888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-KupSU0AAhBGl.jpg",
        "sizes" : [ {
          "h" : 3300,
          "resize" : "fit",
          "w" : 2550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 927
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1583
        } ],
        "display_url" : "pic.twitter.com\/HnxWXVFc4S"
      } ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 91, 103 ]
      }, {
        "text" : "oa",
        "indices" : [ 104, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/j1NpHRMctz",
        "expanded_url" : "https:\/\/thewinnower.com\/posts\/contest-how-do-we-ensure-that-research-is-reproducible",
        "display_url" : "thewinnower.com\/posts\/contest-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724950601084325889",
    "text" : "CONTEST: How do we ensure that research is reproducible? (Pls RT!) https:\/\/t.co\/j1NpHRMctz #openscience #oa https:\/\/t.co\/HnxWXVFc4S",
    "id" : 724950601084325889,
    "created_at" : "2016-04-26 13:17:46 +0000",
    "user" : {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "protected" : false,
      "id_str" : "748018813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459467186734514177\/xIXadyix_normal.jpeg",
      "id" : 748018813,
      "verified" : false
    }
  },
  "id" : 724958135958556672,
  "created_at" : "2016-04-26 13:47:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/FpDlNFVisX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=UcDHXoQmxu0",
      "display_url" : "youtube.com\/watch?v=UcDHXo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724892851935563777",
  "text" : "Comfortably Purple Rain https:\/\/t.co\/FpDlNFVisX",
  "id" : 724892851935563777,
  "created_at" : "2016-04-26 09:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 65, 74 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/gxm2MtelYk",
      "expanded_url" : "http:\/\/www.fastcodesign.com\/3058943\/the-ux-of-ethics-should-google-tell-you-if-you-have-cancer",
      "display_url" : "fastcodesign.com\/3058943\/the-ux\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724881041522053121",
  "text" : "The UX Of Ethics: Should Google Tell You If You Have Cancer? \/HT @wilbanks https:\/\/t.co\/gxm2MtelYk",
  "id" : 724881041522053121,
  "created_at" : "2016-04-26 08:41:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Rendeiro",
      "screen_name" : "afrendeiro",
      "indices" : [ 3, 14 ],
      "id_str" : "20770013",
      "id" : 20770013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aphantasia",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724737466561892352",
  "text" : "RT @afrendeiro: Interested in #aphantasia and have done 23andme? Put your genotype to use by annotating your phenotype https:\/\/t.co\/dHooI36\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aphantasia",
        "indices" : [ 14, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/dHooI36ESz",
        "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/446",
        "display_url" : "opensnp.org\/phenotypes\/446"
      } ]
    },
    "geo" : { },
    "id_str" : "724193883249360896",
    "text" : "Interested in #aphantasia and have done 23andme? Put your genotype to use by annotating your phenotype https:\/\/t.co\/dHooI36ESz",
    "id" : 724193883249360896,
    "created_at" : "2016-04-24 11:10:51 +0000",
    "user" : {
      "name" : "Andr\u00E9 Rendeiro",
      "screen_name" : "afrendeiro",
      "protected" : false,
      "id_str" : "20770013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823660322032615424\/1QmsTaGf_normal.jpg",
      "id" : 20770013,
      "verified" : false
    }
  },
  "id" : 724737466561892352,
  "created_at" : "2016-04-25 23:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724707569911115776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082480144808, 8.818549272099999 ]
  },
  "id_str" : "724715710694449152",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick dammit!",
  "id" : 724715710694449152,
  "in_reply_to_status_id" : 724707569911115776,
  "created_at" : "2016-04-25 21:44:24 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724680541040160770",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094292742205, 8.81858775392996 ]
  },
  "id_str" : "724704721949351936",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick are going through Frankfurt?",
  "id" : 724704721949351936,
  "in_reply_to_status_id" : 724680541040160770,
  "created_at" : "2016-04-25 21:00:44 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/kzmX1mBhfo",
      "expanded_url" : "https:\/\/twitter.com\/KathleenLuschek\/status\/724678757114503168",
      "display_url" : "twitter.com\/KathleenLusche\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06106758997233, 8.818572970986514 ]
  },
  "id_str" : "724680051837509632",
  "text" : "I love how libraries are now becoming cool again, \u00ABshadowy pirate libraries\u00BB, what\u2019s not to love about that? https:\/\/t.co\/kzmX1mBhfo",
  "id" : 724680051837509632,
  "created_at" : "2016-04-25 19:22:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/KEykKjopcd",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/130",
      "display_url" : "existentialcomics.com\/comic\/130"
    } ]
  },
  "geo" : { },
  "id_str" : "724634193788059648",
  "text" : "I should rethink my teaching style. https:\/\/t.co\/KEykKjopcd",
  "id" : 724634193788059648,
  "created_at" : "2016-04-25 16:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ssZXfjYNRB",
      "expanded_url" : "https:\/\/twitter.com\/_inundata\/status\/724623376535314432",
      "display_url" : "twitter.com\/_inundata\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724633515321614336",
  "text" : "Awesome, starting to model simple evolution emoji right now. https:\/\/t.co\/ssZXfjYNRB",
  "id" : 724633515321614336,
  "created_at" : "2016-04-25 16:17:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/uemUjRhCl6",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/04\/19\/049338",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724615057166970882",
  "text" : "Ten simple rules we all should have read 10 years ago. https:\/\/t.co\/uemUjRhCl6",
  "id" : 724615057166970882,
  "created_at" : "2016-04-25 15:04:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 13, 27 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724609304054095872",
  "geo" : { },
  "id_str" : "724609398644060160",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @BioMickWatson no worries, it\u2019s the same for all biologists.",
  "id" : 724609398644060160,
  "in_reply_to_status_id" : 724609304054095872,
  "created_at" : "2016-04-25 14:41:57 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724608003538837504",
  "geo" : { },
  "id_str" : "724608325158096898",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb hatte mir f\u00FCr meinen China-Besuch einen Account bei expressVPN geklickt um durch die GFW zu kommen &amp; danach f\u00FCr Netflix behalten.",
  "id" : 724608325158096898,
  "in_reply_to_status_id" : 724608003538837504,
  "created_at" : "2016-04-25 14:37:41 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/t3AFUkIrgE",
      "expanded_url" : "http:\/\/www.yourgenome.org\/activities\/origami-dna",
      "display_url" : "yourgenome.org\/activities\/ori\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724605763746955264",
  "text" : "i\u2019m not slacking off, i\u2019m doing short-reads out of paper! https:\/\/t.co\/t3AFUkIrgE",
  "id" : 724605763746955264,
  "created_at" : "2016-04-25 14:27:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724599417001664513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219001650108, 8.627680095255492 ]
  },
  "id_str" : "724600617646350336",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb Nur ein paar Sekunden um zu sehen ob es l\u00E4uft. Reicht das? :)",
  "id" : 724600617646350336,
  "in_reply_to_status_id" : 724599417001664513,
  "created_at" : "2016-04-25 14:07:04 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724589321609707520",
  "geo" : { },
  "id_str" : "724590182389919745",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb geht beides. Solltest auch entsprechende IPs in deinen Logs finden :)",
  "id" : 724590182389919745,
  "in_reply_to_status_id" : 724589321609707520,
  "created_at" : "2016-04-25 13:25:36 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724589066012991488",
  "geo" : { },
  "id_str" : "724589147508367360",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb wenns per VPN geht kann ich es mir aussuchen. Was h\u00E4ttest denn gerne?",
  "id" : 724589147508367360,
  "in_reply_to_status_id" : 724589066012991488,
  "created_at" : "2016-04-25 13:21:29 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/3zBQxMjSGn",
      "expanded_url" : "https:\/\/peerj.com\/articles\/1960\/",
      "display_url" : "peerj.com\/articles\/1960\/"
    } ]
  },
  "geo" : { },
  "id_str" : "724588403304615940",
  "text" : "GoPros as an underwater photogrammetry tool for citizen science https:\/\/t.co\/3zBQxMjSGn",
  "id" : 724588403304615940,
  "created_at" : "2016-04-25 13:18:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/IvwYCpzloG",
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/724555621027205121",
      "display_url" : "twitter.com\/Helena_LB\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724578724490948609",
  "text" : "How to spin the fact that key research is usually only accessible for the privileged select few\u2026 #openaccess https:\/\/t.co\/IvwYCpzloG",
  "id" : 724578724490948609,
  "created_at" : "2016-04-25 12:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/30Lg7RimBJ",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/nph.13975\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/np\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724577135508226048",
  "text" : "TIL: there are fungal parasites that infect lichens, making their hosts being more tasty to snails. \uD83D\uDC0C\uD83C\uDF44 https:\/\/t.co\/30Lg7RimBJ",
  "id" : 724577135508226048,
  "created_at" : "2016-04-25 12:33:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724539890923384833",
  "geo" : { },
  "id_str" : "724575944523034625",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb brauchst du noch Leute?",
  "id" : 724575944523034625,
  "in_reply_to_status_id" : 724539890923384833,
  "created_at" : "2016-04-25 12:29:01 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/7kAQlw6nyw",
      "expanded_url" : "http:\/\/www.bailis.org\/blog\/you-can-do-research-too\/",
      "display_url" : "bailis.org\/blog\/you-can-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724568197018607616",
  "text" : "\u00ABTrust in your curiosity.\u00BB I feel like that\u2019s the #1 requirement for doing research. https:\/\/t.co\/7kAQlw6nyw",
  "id" : 724568197018607616,
  "created_at" : "2016-04-25 11:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724529245565915136",
  "text" : "@quominus I feel ya!",
  "id" : 724529245565915136,
  "created_at" : "2016-04-25 09:23:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/9tqKrNfR6G",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/4MRlTrIimLZZu\/200.gif",
      "display_url" : "media0.giphy.com\/media\/4MRlTrIi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724522669295722496",
  "text" : "tending to your inbox after a week of only doing the most urgent things https:\/\/t.co\/9tqKrNfR6G",
  "id" : 724522669295722496,
  "created_at" : "2016-04-25 08:57:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 3, 12 ],
      "id_str" : "20624794",
      "id" : 20624794
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 121, 132 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/E6yD6CnzWP",
      "expanded_url" : "https:\/\/wp.me\/p7fHjD-o6",
      "display_url" : "wp.me\/p7fHjD-o6"
    } ]
  },
  "geo" : { },
  "id_str" : "724514864190898177",
  "text" : "RT @obf_news: Welcome to Open Bioinformatics Foundation's Google Summer of Code 2016 students https:\/\/t.co\/E6yD6CnzWP CC @OpenSNPorg @BioNo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 107, 118 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "bionode",
        "screen_name" : "bionode",
        "indices" : [ 119, 127 ],
        "id_str" : "2304044137",
        "id" : 2304044137
      }, {
        "name" : "commonwl",
        "screen_name" : "commonwl",
        "indices" : [ 128, 137 ],
        "id_str" : "4482278729",
        "id" : 4482278729
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/E6yD6CnzWP",
        "expanded_url" : "https:\/\/wp.me\/p7fHjD-o6",
        "display_url" : "wp.me\/p7fHjD-o6"
      } ]
    },
    "geo" : { },
    "id_str" : "724512495566618624",
    "text" : "Welcome to Open Bioinformatics Foundation's Google Summer of Code 2016 students https:\/\/t.co\/E6yD6CnzWP CC @OpenSNPorg @BioNode @commonwl",
    "id" : 724512495566618624,
    "created_at" : "2016-04-25 08:16:54 +0000",
    "user" : {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "protected" : false,
      "id_str" : "20624794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77404934\/OBF_logo_normal.png",
      "id" : 20624794,
      "verified" : false
    }
  },
  "id" : 724514864190898177,
  "created_at" : "2016-04-25 08:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724374967211556865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076685793592, 8.81870569689443 ]
  },
  "id_str" : "724380999027691520",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a a follow up to Ruby on Rails?",
  "id" : 724380999027691520,
  "in_reply_to_status_id" : 724374967211556865,
  "created_at" : "2016-04-24 23:34:23 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radical Face",
      "screen_name" : "RadicalFace",
      "indices" : [ 78, 90 ],
      "id_str" : "351846496",
      "id" : 351846496
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/724310006141718528\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2qCIc9aSzt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg1D_L1WgAEP9Uv.jpg",
      "id_str" : "724309867863900161",
      "id" : 724309867863900161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg1D_L1WgAEP9Uv.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2qCIc9aSzt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13158855728886, 8.625957785480525 ]
  },
  "id_str" : "724310006141718528",
  "text" : "Awake for 30h hours already. What better way to fight jet lag than going to a @RadicalFace concert now? https:\/\/t.co\/2qCIc9aSzt",
  "id" : 724310006141718528,
  "created_at" : "2016-04-24 18:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 71, 80 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724176164722491392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05146385423639, 8.572307695019635 ]
  },
  "id_str" : "724176388794798080",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie my pleasure. Let\u2019s do this again some time. and let\u2019s invite @leejoeyk too! :)",
  "id" : 724176388794798080,
  "in_reply_to_status_id" : 724176164722491392,
  "created_at" : "2016-04-24 10:01:20 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/724170864917360640\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/90r4E0YA5O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgzFj7IWMAEjvYs.jpg",
      "id_str" : "724170861058600961",
      "id" : 724170861058600961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgzFj7IWMAEjvYs.jpg",
      "sizes" : [ {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/90r4E0YA5O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04748971417836, 8.573458468305562 ]
  },
  "id_str" : "724170864917360640",
  "text" : "\u00ABDeath\u2019s playing a C chord on a Fender Strat which unfortunately happens to be live.\u00BB I\u2019m in love. https:\/\/t.co\/90r4E0YA5O",
  "id" : 724170864917360640,
  "created_at" : "2016-04-24 09:39:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 16, 30 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 31, 47 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724152201971519488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04748971417836, 8.573458468305562 ]
  },
  "id_str" : "724170472561225728",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @BioMickWatson @pathogenomenick i thought tardigrade genes only outnumbered human genes until we took a dump?",
  "id" : 724170472561225728,
  "in_reply_to_status_id" : 724152201971519488,
  "created_at" : "2016-04-24 09:37:49 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/724169032220418048\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/8yqx05sTG1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgzD5dNWYAAi9K9.jpg",
      "id_str" : "724169031960387584",
      "id" : 724169031960387584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgzD5dNWYAAi9K9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1078,
        "resize" : "fit",
        "w" : 1046
      }, {
        "h" : 1078,
        "resize" : "fit",
        "w" : 1046
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 1078,
        "resize" : "fit",
        "w" : 1046
      } ],
      "display_url" : "pic.twitter.com\/8yqx05sTG1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.039555, 8.544758 ]
  },
  "id_str" : "724169032220418048",
  "text" : "Death has humor https:\/\/t.co\/8yqx05sTG1",
  "id" : 724169032220418048,
  "created_at" : "2016-04-24 09:32:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04789119442597, 8.499006245138402 ]
  },
  "id_str" : "724167900525940736",
  "text" : "And back at FRA. \u2708\uFE0F thanks again for a great week, Portland and #force2016",
  "id" : 724167900525940736,
  "created_at" : "2016-04-24 09:27:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724008322572140548",
  "geo" : { },
  "id_str" : "724008415425515520",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr Yes :D",
  "id" : 724008415425515520,
  "in_reply_to_status_id" : 724008322572140548,
  "created_at" : "2016-04-23 22:53:52 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 10, 21 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723996597902778369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4389253942543, -122.3016479209077 ]
  },
  "id_str" : "724007917272231936",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @LouWoodley 7 here :D",
  "id" : 724007917272231936,
  "in_reply_to_status_id" : 723996597902778369,
  "created_at" : "2016-04-23 22:51:53 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723995742570962946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4389253942543, -122.3016479209077 ]
  },
  "id_str" : "724007831263809536",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr \u2615\uFE0F",
  "id" : 724007831263809536,
  "in_reply_to_status_id" : 723995742570962946,
  "created_at" : "2016-04-23 22:51:33 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723950154861129728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58653868793097, -122.5922610599183 ]
  },
  "id_str" : "723950331239911424",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen and we all know the quip about the prophets in their own countries\u2026 ;)",
  "id" : 723950331239911424,
  "in_reply_to_status_id" : 723950154861129728,
  "created_at" : "2016-04-23 19:03:03 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723949246127415296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5866020882511, -122.5922714931911 ]
  },
  "id_str" : "723949438796877824",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen feels more like traveling salesman than science at times though :D",
  "id" : 723949438796877824,
  "in_reply_to_status_id" : 723949246127415296,
  "created_at" : "2016-04-23 18:59:31 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723948737807130625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58669501341058, -122.5923676856997 ]
  },
  "id_str" : "723948989750513664",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen making shit up as I go. Und viel Spa\u00DF beim prokrastinieren :D",
  "id" : 723948989750513664,
  "in_reply_to_status_id" : 723948737807130625,
  "created_at" : "2016-04-23 18:57:44 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723948060661956608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58667408580907, -122.5923571084408 ]
  },
  "id_str" : "723948248012967936",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen gibt keinen Text, so gut rehearsed bin ich nicht das ich nur das auswendig gelernte Vortrage :D",
  "id" : 723948248012967936,
  "in_reply_to_status_id" : 723948060661956608,
  "created_at" : "2016-04-23 18:54:47 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/71YOc93pwy",
      "expanded_url" : "http:\/\/fusion.net\/story\/47945\/this-guy-is-the-mark-zuckerberg-of-open-source-genetics\/",
      "display_url" : "fusion.net\/story\/47945\/th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "723947616317411333",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58667408580907, -122.5923571084408 ]
  },
  "id_str" : "723948072384880642",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen die Aufzeichnung dazu sollte irgendwann online sein. Bis dahin: https:\/\/t.co\/71YOc93pwy und der darin verlinkte Artikel :)",
  "id" : 723948072384880642,
  "in_reply_to_status_id" : 723947616317411333,
  "created_at" : "2016-04-23 18:54:05 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723947616317411333",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58655062851722, -122.5922419919073 ]
  },
  "id_str" : "723947745694781440",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen der Talk hier wurde als sehr Einsteigerfreundlich gelobt ;)",
  "id" : 723947745694781440,
  "in_reply_to_status_id" : 723947616317411333,
  "created_at" : "2016-04-23 18:52:47 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723945322716749825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58656729027746, -122.5922620968679 ]
  },
  "id_str" : "723946060884795392",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen ich momentan so 1x pro Jahr, aber immer so kurztrips wie jetzt.",
  "id" : 723946060884795392,
  "in_reply_to_status_id" : 723945322716749825,
  "created_at" : "2016-04-23 18:46:05 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723944574951944192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58658602991166, -122.592246851186 ]
  },
  "id_str" : "723944732406079488",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen ja, bin schon 2 Tage l\u00E4nger geblieben als n\u00F6tig gewesen w\u00E4re :D",
  "id" : 723944732406079488,
  "in_reply_to_status_id" : 723944574951944192,
  "created_at" : "2016-04-23 18:40:49 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723943925506039808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58657363720065, -122.5922586701968 ]
  },
  "id_str" : "723944085329862656",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen war eine nette Woche. Ich kann also gar nicht klagen :D",
  "id" : 723944085329862656,
  "in_reply_to_status_id" : 723943925506039808,
  "created_at" : "2016-04-23 18:38:14 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723943212671447040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58657363720065, -122.5922586701968 ]
  },
  "id_str" : "723943480939024384",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Danke. Warte schon auf das Boarding f\u00FCr den Flug zur\u00FCck ;)",
  "id" : 723943480939024384,
  "in_reply_to_status_id" : 723943212671447040,
  "created_at" : "2016-04-23 18:35:50 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723942328105336832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58657064334545, -122.5922525175356 ]
  },
  "id_str" : "723942392898850816",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Portland :D",
  "id" : 723942392898850816,
  "in_reply_to_status_id" : 723942328105336832,
  "created_at" : "2016-04-23 18:31:31 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 0, 9 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723929906703261696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58655033120981, -122.5922530284607 ]
  },
  "id_str" : "723929986692845568",
  "in_reply_to_user_id" : 575961466,
  "text" : "@leejoeyk \uD83D\uDC4D",
  "id" : 723929986692845568,
  "in_reply_to_status_id" : 723929906703261696,
  "created_at" : "2016-04-23 17:42:13 +0000",
  "in_reply_to_screen_name" : "leejoeyk",
  "in_reply_to_user_id_str" : "575961466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 0, 9 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723900694437072896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5865722870312, -122.5922569944864 ]
  },
  "id_str" : "723929453424832513",
  "in_reply_to_user_id" : 575961466,
  "text" : "@leejoeyk how long\u2019s your layover in SEA? Coming in at ~1pm!",
  "id" : 723929453424832513,
  "in_reply_to_status_id" : 723900694437072896,
  "created_at" : "2016-04-23 17:40:06 +0000",
  "in_reply_to_screen_name" : "leejoeyk",
  "in_reply_to_user_id_str" : "575961466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58653659598222, -122.5922370054334 ]
  },
  "id_str" : "723928702883500033",
  "text" : "@stopifnot \uD83D\uDC4D",
  "id" : 723928702883500033,
  "created_at" : "2016-04-23 17:37:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/723925859602563073\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/YvTgcpuK13",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgvmu1hUYAAWQ3U.jpg",
      "id_str" : "723925857438294016",
      "id" : 723925857438294016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgvmu1hUYAAWQ3U.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/YvTgcpuK13"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58661010188298, -122.5923248866208 ]
  },
  "id_str" : "723925859602563073",
  "text" : "Made it to PDX with only a bit of additional carry-on. https:\/\/t.co\/YvTgcpuK13",
  "id" : 723925859602563073,
  "created_at" : "2016-04-23 17:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/fscLuOizw8",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEjETJtBwjv\/",
      "display_url" : "instagram.com\/p\/BEjETJtBwjv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723897424595574784",
  "text" : "Got all the stereotypes https:\/\/t.co\/fscLuOizw8",
  "id" : 723897424595574784,
  "created_at" : "2016-04-23 15:32:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 13, 29 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723813140731990016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51643873243214, -122.6887205646428 ]
  },
  "id_str" : "723864797918285825",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @KathleenLuschek show me pictures please! :D",
  "id" : 723864797918285825,
  "in_reply_to_status_id" : 723813140731990016,
  "created_at" : "2016-04-23 13:23:11 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/fSfQ93Hm8p",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEiDj4uhwlR\/",
      "display_url" : "instagram.com\/p\/BEiDj4uhwlR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51625, -122.68357 ]
  },
  "id_str" : "723755062514880513",
  "text" : "Being super artsy @ Portland Art Museum https:\/\/t.co\/fSfQ93Hm8p",
  "id" : 723755062514880513,
  "created_at" : "2016-04-23 06:07:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723751522664734720",
  "text" : "The thing I\u2019ll miss most about Portland: How genuinely friendly everyone is, even every single bus driver I encountered.",
  "id" : 723751522664734720,
  "created_at" : "2016-04-23 05:53:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hobson",
      "screen_name" : "pmhobson",
      "indices" : [ 0, 9 ],
      "id_str" : "422283700",
      "id" : 422283700
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 10, 22 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723740921108385793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51273935677787, -122.6615351663778 ]
  },
  "id_str" : "723741223941488641",
  "in_reply_to_user_id" : 422283700,
  "text" : "@pmhobson @denormalize tell bad that I\u2019ll be on my plane back to Europe then ;)",
  "id" : 723741223941488641,
  "in_reply_to_status_id" : 723740921108385793,
  "created_at" : "2016-04-23 05:12:08 +0000",
  "in_reply_to_screen_name" : "pmhobson",
  "in_reply_to_user_id_str" : "422283700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Robine",
      "screen_name" : "notSoJunkDNA",
      "indices" : [ 3, 16 ],
      "id_str" : "107174526",
      "id" : 107174526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/fUQYnBbGfm",
      "expanded_url" : "http:\/\/erikbern.com\/2016\/04\/04\/nyc-subway-math.html",
      "display_url" : "erikbern.com\/2016\/04\/04\/nyc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723691561339359233",
  "text" : "RT @notSoJunkDNA: When a data scientist (and ggplot user) takes the NYC subway https:\/\/t.co\/fUQYnBbGfm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/fUQYnBbGfm",
        "expanded_url" : "http:\/\/erikbern.com\/2016\/04\/04\/nyc-subway-math.html",
        "display_url" : "erikbern.com\/2016\/04\/04\/nyc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723689762436055041",
    "text" : "When a data scientist (and ggplot user) takes the NYC subway https:\/\/t.co\/fUQYnBbGfm",
    "id" : 723689762436055041,
    "created_at" : "2016-04-23 01:47:39 +0000",
    "user" : {
      "name" : "Nicolas Robine",
      "screen_name" : "notSoJunkDNA",
      "protected" : false,
      "id_str" : "107174526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925905483302670338\/jMPGgj0v_normal.jpg",
      "id" : 107174526,
      "verified" : false
    }
  },
  "id" : 723691561339359233,
  "created_at" : "2016-04-23 01:54:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 10, 22 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723690093978873856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5165610340553, -122.6886450469828 ]
  },
  "id_str" : "723690320186077184",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @denormalize too bad. Let me know when you come through Frankfurt. :-)",
  "id" : 723690320186077184,
  "in_reply_to_status_id" : 723690093978873856,
  "created_at" : "2016-04-23 01:49:52 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 13, 22 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723671321654087680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51654186054328, -122.6885966632725 ]
  },
  "id_str" : "723671940204908544",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize @sckottie purrfect!",
  "id" : 723671940204908544,
  "in_reply_to_status_id" : 723671321654087680,
  "created_at" : "2016-04-23 00:36:50 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 17, 29 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723670966375583744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51654186054328, -122.6885966632725 ]
  },
  "id_str" : "723671819664789505",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek @froggleston now I\u2019m curious!",
  "id" : 723671819664789505,
  "in_reply_to_status_id" : 723670966375583744,
  "created_at" : "2016-04-23 00:36:21 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 13, 22 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723671321654087680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51654186054328, -122.6885966632725 ]
  },
  "id_str" : "723671741524922368",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize @sckottie let\u2019s say 8pm there!",
  "id" : 723671741524922368,
  "in_reply_to_status_id" : 723671321654087680,
  "created_at" : "2016-04-23 00:36:03 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 13, 22 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723670981659631616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51654186054328, -122.6885966632725 ]
  },
  "id_str" : "723671177609138176",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize @sckottie does 7:30\/8 work for you too?",
  "id" : 723671177609138176,
  "in_reply_to_status_id" : 723670981659631616,
  "created_at" : "2016-04-23 00:33:48 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723668946457513984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51645655926161, -122.688690446118 ]
  },
  "id_str" : "723669759926005760",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek we\u2019re all still waiting for the conference in Hawaii!",
  "id" : 723669759926005760,
  "in_reply_to_status_id" : 723668946457513984,
  "created_at" : "2016-04-23 00:28:10 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 13, 22 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/ppMwiSGPsx",
      "expanded_url" : "http:\/\/www.teotepdx.com\/",
      "display_url" : "teotepdx.com"
    } ]
  },
  "in_reply_to_status_id_str" : "723667410721480704",
  "geo" : { },
  "id_str" : "723668187670179841",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize @sckottie this https:\/\/t.co\/ppMwiSGPsx ?",
  "id" : 723668187670179841,
  "in_reply_to_status_id" : 723667410721480704,
  "created_at" : "2016-04-23 00:21:55 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723666519280914433",
  "geo" : { },
  "id_str" : "723666807496675329",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize too bad, that\u2019s a latergram, wouldn\u2019t make it in time. Do you have dinner plans?",
  "id" : 723666807496675329,
  "in_reply_to_status_id" : 723666519280914433,
  "created_at" : "2016-04-23 00:16:26 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/yHYU7PSH3P",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEha7P_BwgW\/",
      "display_url" : "instagram.com\/p\/BEha7P_BwgW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723665704860397568",
  "text" : "Downtown https:\/\/t.co\/yHYU7PSH3P",
  "id" : 723665704860397568,
  "created_at" : "2016-04-23 00:12:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723640791487270912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52253750875981, -122.68104598569 ]
  },
  "id_str" : "723641106672525313",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize awesome, so we\u2019re even colleagues in some way! :D",
  "id" : 723641106672525313,
  "in_reply_to_status_id" : 723640791487270912,
  "created_at" : "2016-04-22 22:34:19 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5200437164282, -122.6794543586431 ]
  },
  "id_str" : "723623516805820416",
  "text" : "@stopifmaybe yep!",
  "id" : 723623516805820416,
  "created_at" : "2016-04-22 21:24:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52002485385474, -122.6794548718262 ]
  },
  "id_str" : "723623143600852992",
  "text" : "@stopifmaybe please be in touch if you want to talk about it!",
  "id" : 723623143600852992,
  "created_at" : "2016-04-22 21:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52007037930772, -122.6795275332355 ]
  },
  "id_str" : "723622387917320193",
  "text" : "@stopifmaybe sorry to hear that :(",
  "id" : 723622387917320193,
  "created_at" : "2016-04-22 21:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52007037930772, -122.6795275332355 ]
  },
  "id_str" : "723621998090309633",
  "text" : "Got our students for the GSoC accepted \\o\/ \uD83C\uDF89",
  "id" : 723621998090309633,
  "created_at" : "2016-04-22 21:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723620137694277632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52004718508412, -122.6794802981372 ]
  },
  "id_str" : "723620418469285888",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not the one I\u2019m flying I guess. They even charge 10\u20AC for getting access to movies (which is why I read two books on my way over).",
  "id" : 723620418469285888,
  "in_reply_to_status_id" : 723620137694277632,
  "created_at" : "2016-04-22 21:12:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723619639218036737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52004449457662, -122.6794246715985 ]
  },
  "id_str" : "723619810160963584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, the single lefty.",
  "id" : 723619810160963584,
  "in_reply_to_status_id" : 723619639218036737,
  "created_at" : "2016-04-22 21:09:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723619090657628161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5200670831964, -122.6794761256451 ]
  },
  "id_str" : "723619278566641667",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, and w\/ a full body. Only $300 though.",
  "id" : 723619278566641667,
  "in_reply_to_status_id" : 723619090657628161,
  "created_at" : "2016-04-22 21:07:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723618143919321090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52008516230614, -122.6794745953104 ]
  },
  "id_str" : "723618551941062656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the Ibanez they had still sounded better than our Yamahas :p",
  "id" : 723618551941062656,
  "in_reply_to_status_id" : 723618143919321090,
  "created_at" : "2016-04-22 21:04:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723617955418873858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52005156588827, -122.6794915259901 ]
  },
  "id_str" : "723618183832170496",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy better not try playing western in Dick\u2019s country store!",
  "id" : 723618183832170496,
  "in_reply_to_status_id" : 723617955418873858,
  "created_at" : "2016-04-22 21:03:13 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723616849875836933",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003644136484, -122.6795018018799 ]
  },
  "id_str" : "723617109440253952",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Portlands weniger cooler kleiner Bruder? :D",
  "id" : 723617109440253952,
  "in_reply_to_status_id" : 723616849875836933,
  "created_at" : "2016-04-22 20:58:57 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723616421159251969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52008782854151, -122.6794708043927 ]
  },
  "id_str" : "723616699757383680",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg come to Portland, my luggage is maxed out w\/ books. \uD83D\uDE02",
  "id" : 723616699757383680,
  "in_reply_to_status_id" : 723616421159251969,
  "created_at" : "2016-04-22 20:57:20 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723616544396349441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52008782854151, -122.6794708043927 ]
  },
  "id_str" : "723616599756800000",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg bei der ist wirklich alles egal vermute ich :D",
  "id" : 723616599756800000,
  "in_reply_to_status_id" : 723616544396349441,
  "created_at" : "2016-04-22 20:56:56 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723615013273890817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52009412620659, -122.6794916739122 ]
  },
  "id_str" : "723615247550935043",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann haha, yes! Lots of frustrating things in everyday life. Don\u2019t get me started on mobile phone UI!",
  "id" : 723615247550935043,
  "in_reply_to_status_id" : 723615013273890817,
  "created_at" : "2016-04-22 20:51:33 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723614164774621184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003714339546, -122.6794523678831 ]
  },
  "id_str" : "723614762811023360",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann so I\u2019d say she should try and see what works best for her. If it makes you hate the instrument it\u2019s not worth the switch.",
  "id" : 723614762811023360,
  "in_reply_to_status_id" : 723614164774621184,
  "created_at" : "2016-04-22 20:49:38 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723614164774621184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003714339546, -122.6794523678831 ]
  },
  "id_str" : "723614589062025216",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann I felt it was so much harder doing what felt intuitively \u2018wrong\u2019, playing right-handed, that I stopped those attempts.",
  "id" : 723614589062025216,
  "in_reply_to_status_id" : 723614164774621184,
  "created_at" : "2016-04-22 20:48:56 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/723614205597745152\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/RurTbH69Bf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrLSS4UgAEz1v6.jpg",
      "id_str" : "723614205312532481",
      "id" : 723614205312532481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrLSS4UgAEz1v6.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1415,
        "resize" : "fit",
        "w" : 1061
      }, {
        "h" : 1415,
        "resize" : "fit",
        "w" : 1061
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/RurTbH69Bf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723614205597745152",
  "text" : "Right-handed hipster guitars? \u2714\uFE0F https:\/\/t.co\/RurTbH69Bf",
  "id" : 723614205597745152,
  "created_at" : "2016-04-22 20:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723613636447637507",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52008675435004, -122.6794760047704 ]
  },
  "id_str" : "723613881436786688",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann I know many people who do this. But it\u2019s like 25 years late for that advice :D",
  "id" : 723613881436786688,
  "in_reply_to_status_id" : 723613636447637507,
  "created_at" : "2016-04-22 20:46:08 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723613308054589440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003163496346, -122.6794145427857 ]
  },
  "id_str" : "723613552129368064",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley \uD83D\uDC96\uD83C\uDF3F",
  "id" : 723613552129368064,
  "in_reply_to_status_id" : 723613308054589440,
  "created_at" : "2016-04-22 20:44:49 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723613333228802048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003163496346, -122.6794145427857 ]
  },
  "id_str" : "723613483611217920",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg their selection of right-handed guitars definitely fit the hipster bill.",
  "id" : 723613483611217920,
  "in_reply_to_status_id" : 723613333228802048,
  "created_at" : "2016-04-22 20:44:33 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723612478148583424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003163496346, -122.6794145427857 ]
  },
  "id_str" : "723612989367033858",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg at least amongst acoustic guitars. But you\u2019ll be even less amused by the electric ones: 3 guitars, all Fender :p",
  "id" : 723612989367033858,
  "in_reply_to_status_id" : 723612478148583424,
  "created_at" : "2016-04-22 20:42:35 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/723612748857270272\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/BwxpBzYVFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrJ9VAUcAATrA2.jpg",
      "id_str" : "723612745594073088",
      "id" : 723612745594073088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrJ9VAUcAATrA2.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/BwxpBzYVFf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723612488818954241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52003163496346, -122.6794145427857 ]
  },
  "id_str" : "723612748857270272",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley will do. :) https:\/\/t.co\/BwxpBzYVFf",
  "id" : 723612748857270272,
  "in_reply_to_status_id" : 723612488818954241,
  "created_at" : "2016-04-22 20:41:38 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52002457571501, -122.6794857534141 ]
  },
  "id_str" : "723611608266604544",
  "text" : "Being left handed means you can choose from a total selection of one guitar in Oregon\u2019s largest music store. \uD83D\uDE14",
  "id" : 723611608266604544,
  "created_at" : "2016-04-22 20:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/UsRDz8sFAT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEhCFUnBwhZ\/",
      "display_url" : "instagram.com\/p\/BEhCFUnBwhZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723611075409793024",
  "text" : "Welcome to the Rain https:\/\/t.co\/UsRDz8sFAT",
  "id" : 723611075409793024,
  "created_at" : "2016-04-22 20:34:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 96, 107 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/PZ9zfgMJ3c",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/7GnxYeQcZtr",
      "display_url" : "swarmapp.com\/c\/7GnxYeQcZtr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5200497109434, -122.6794704644087 ]
  },
  "id_str" : "723609846977728515",
  "text" : "I\u2019m at Public Domain. Looks like we were especially unlucky in that they were closed yesterday, @LouWoodley. https:\/\/t.co\/PZ9zfgMJ3c",
  "id" : 723609846977728515,
  "created_at" : "2016-04-22 20:30:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723555414495879168",
  "geo" : { },
  "id_str" : "723555680200757249",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed thanks, I will have a look!",
  "id" : 723555680200757249,
  "in_reply_to_status_id" : 723555414495879168,
  "created_at" : "2016-04-22 16:54:51 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/4vrgi0S2tz",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/1583622717",
      "display_url" : "goodreads.com\/review\/show\/15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723553211840253953",
  "text" : "That was a really though and depressing read, but an important one. https:\/\/t.co\/4vrgi0S2tz",
  "id" : 723553211840253953,
  "created_at" : "2016-04-22 16:45:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9RrqtJySLv",
      "expanded_url" : "http:\/\/xkcd.com\/1669\/",
      "display_url" : "xkcd.com\/1669\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723537810825744384",
  "text" : "Despite my love for air travel that\u2019s about the level of expertise I bring to the table when discussing it. https:\/\/t.co\/9RrqtJySLv",
  "id" : 723537810825744384,
  "created_at" : "2016-04-22 15:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/v6nkgvFbOu",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEgczzHhwtL\/",
      "display_url" : "instagram.com\/p\/BEgczzHhwtL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723529109851222016",
  "text" : "Contrasts https:\/\/t.co\/v6nkgvFbOu",
  "id" : 723529109851222016,
  "created_at" : "2016-04-22 15:09:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723437536287166464",
  "geo" : { },
  "id_str" : "723438795467579392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDFC3\uD83C\uDFBD\uD83D\uDE16",
  "id" : 723438795467579392,
  "in_reply_to_status_id" : 723437536287166464,
  "created_at" : "2016-04-22 09:10:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723436243078410240",
  "geo" : { },
  "id_str" : "723436416756125696",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot soll ja Leute geben die genau deshalb beim falschen Staffelpunkt beim Marathon aufgelaufen sind.",
  "id" : 723436416756125696,
  "in_reply_to_status_id" : 723436243078410240,
  "created_at" : "2016-04-22 09:00:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723431581977743360",
  "geo" : { },
  "id_str" : "723433980293345283",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot jetzt bitte noch einen Merksatz f\u00FCr Nied(errad) :P",
  "id" : 723433980293345283,
  "in_reply_to_status_id" : 723431581977743360,
  "created_at" : "2016-04-22 08:51:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/XfQJhc12QE",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEfumS-hwk-\/",
      "display_url" : "instagram.com\/p\/BEfumS-hwk-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723427491247878144",
  "text" : "No Parking https:\/\/t.co\/XfQJhc12QE",
  "id" : 723427491247878144,
  "created_at" : "2016-04-22 08:25:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/qEmFYj4v2B",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEfk0DLhwpM\/",
      "display_url" : "instagram.com\/p\/BEfk0DLhwpM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723405973834985472",
  "text" : "Framed https:\/\/t.co\/qEmFYj4v2B",
  "id" : 723405973834985472,
  "created_at" : "2016-04-22 06:59:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.53975161432805, -122.6616623545135 ]
  },
  "id_str" : "723403976457101312",
  "text" : "I guess there really was no way to play a show tonight without doing Purple Rain during the encore.",
  "id" : 723403976457101312,
  "created_at" : "2016-04-22 06:52:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frightened Rabbit",
      "screen_name" : "FRabbits",
      "indices" : [ 77, 86 ],
      "id_str" : "43200260",
      "id" : 43200260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723339630406295552",
  "text" : "After a day at the Chinese garden &amp; the Portland Art Museum: Now for the @FRabbits show! \uD83C\uDFB8",
  "id" : 723339630406295552,
  "created_at" : "2016-04-22 02:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/ie7ZFSGUzg",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEevAw4hwqU\/",
      "display_url" : "instagram.com\/p\/BEevAw4hwqU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723287662300401664",
  "text" : "Flowing https:\/\/t.co\/ie7ZFSGUzg",
  "id" : 723287662300401664,
  "created_at" : "2016-04-21 23:09:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voodoo Doughnut",
      "screen_name" : "VoodooDoughnut",
      "indices" : [ 38, 53 ],
      "id_str" : "42711666",
      "id" : 42711666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/723282334544478208\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/koUpidTHmm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgmdcvrW0AEIO63.jpg",
      "id_str" : "723282332329889793",
      "id" : 723282332329889793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgmdcvrW0AEIO63.jpg",
      "sizes" : [ {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/koUpidTHmm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/rrkd8wWU4U",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/6Bt2UmcX9q1",
      "display_url" : "swarmapp.com\/c\/6Bt2UmcX9q1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52269667323421, -122.67300724983215 ]
  },
  "id_str" : "723282334544478208",
  "text" : "The doughnut formerly known as\u2026 \uD83C\uDF69 (at @VoodooDoughnut in Portland, OR) https:\/\/t.co\/rrkd8wWU4U https:\/\/t.co\/koUpidTHmm",
  "id" : 723282334544478208,
  "created_at" : "2016-04-21 22:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/mHXZ4tz46k",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEeq4e7Bwjy\/",
      "display_url" : "instagram.com\/p\/BEeq4e7Bwjy\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.525513586, -122.672967882 ]
  },
  "id_str" : "723278583414837252",
  "text" : "Rooftops @ Lan Su Chinese Garden https:\/\/t.co\/mHXZ4tz46k",
  "id" : 723278583414837252,
  "created_at" : "2016-04-21 22:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/IPGwRHyEeW",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEepT8EBwhB\/",
      "display_url" : "instagram.com\/p\/BEepT8EBwhB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723275127379636224",
  "text" : "Enter here https:\/\/t.co\/IPGwRHyEeW",
  "id" : 723275127379636224,
  "created_at" : "2016-04-21 22:20:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/fohEcG5YX6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEdIK8sBwtp\/",
      "display_url" : "instagram.com\/p\/BEdIK8sBwtp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "723061513070718977",
  "text" : "Ran back to the town bar\u2026 https:\/\/t.co\/fohEcG5YX6",
  "id" : 723061513070718977,
  "created_at" : "2016-04-21 08:11:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722977438628630531",
  "geo" : { },
  "id_str" : "722985527247405056",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan yes, most likely. I think I also clocked around 6h in total :)",
  "id" : 722985527247405056,
  "in_reply_to_status_id" : 722977438628630531,
  "created_at" : "2016-04-21 03:09:16 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 0, 16 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722960490335330306",
  "geo" : { },
  "id_str" : "722969872481689601",
  "in_reply_to_user_id" : 15626406,
  "text" : "@michael_nielsen more importantly: which one is your favorite?",
  "id" : 722969872481689601,
  "in_reply_to_status_id" : 722960490335330306,
  "created_at" : "2016-04-21 02:07:04 +0000",
  "in_reply_to_screen_name" : "michael_nielsen",
  "in_reply_to_user_id_str" : "15626406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722965995652927488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51652186004671, -122.6886590434188 ]
  },
  "id_str" : "722966294044110849",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery yes, and I had fear I wouldn\u2019t get to experience the Portlandian rain!",
  "id" : 722966294044110849,
  "in_reply_to_status_id" : 722965995652927488,
  "created_at" : "2016-04-21 01:52:51 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722965977260904448\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/sfQ3Aab71q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgh9uWxUcAIlfaR.jpg",
      "id_str" : "722965975532859394",
      "id" : 722965975532859394,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgh9uWxUcAIlfaR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/sfQ3Aab71q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51652186004671, -122.6886590434188 ]
  },
  "id_str" : "722965977260904448",
  "text" : "But it definitely felt good to move a bit post-conference, even if my feet now feel it a tiny bit. https:\/\/t.co\/sfQ3Aab71q",
  "id" : 722965977260904448,
  "created_at" : "2016-04-21 01:51:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722965635366440961\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XgyiLIUBwt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgh9ai-UYAYJLyg.jpg",
      "id_str" : "722965635211223046",
      "id" : 722965635211223046,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgh9ai-UYAYJLyg.jpg",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 1647
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 1647
      } ],
      "display_url" : "pic.twitter.com\/XgyiLIUBwt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51629, -122.688828 ]
  },
  "id_str" : "722965635366440961",
  "text" : "Before the storm came. In other words: today I got drenched in rain and got a sunburn. https:\/\/t.co\/XgyiLIUBwt",
  "id" : 722965635366440961,
  "created_at" : "2016-04-21 01:50:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722916168588075008\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/JSrSAxogbl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CghQbGSUMAETZVq.jpg",
      "id_str" : "722916166667087873",
      "id" : 722916166667087873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CghQbGSUMAETZVq.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/JSrSAxogbl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52359794099831, -122.6817952636898 ]
  },
  "id_str" : "722916168588075008",
  "text" : "On Bob Dylan. https:\/\/t.co\/JSrSAxogbl",
  "id" : 722916168588075008,
  "created_at" : "2016-04-20 22:33:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722877041868201984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.49715135624314, -122.6244899054913 ]
  },
  "id_str" : "722882156322811904",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux it was great, thanks so much for inviting me over!",
  "id" : 722882156322811904,
  "in_reply_to_status_id" : 722877041868201984,
  "created_at" : "2016-04-20 20:18:31 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722861786723000321",
  "geo" : { },
  "id_str" : "722861902972334080",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins that sounds like lots of fun too. Enjoy :)",
  "id" : 722861902972334080,
  "in_reply_to_status_id" : 722861786723000321,
  "created_at" : "2016-04-20 18:58:02 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/qZSubQ2oCJ",
      "expanded_url" : "http:\/\/feliciadaybook.com\/events.html",
      "display_url" : "feliciadaybook.com\/events.html"
    } ]
  },
  "in_reply_to_status_id_str" : "722859711524024324",
  "geo" : { },
  "id_str" : "722860071596609538",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins if you\u2019re the spontaneous type this event tonight could be your thing then though. :) https:\/\/t.co\/qZSubQ2oCJ",
  "id" : 722860071596609538,
  "in_reply_to_status_id" : 722859711524024324,
  "created_at" : "2016-04-20 18:50:45 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722857036577316866",
  "geo" : { },
  "id_str" : "722857518611890176",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins i hate myself so much for coming into PDX a day too late to hear her read.",
  "id" : 722857518611890176,
  "in_reply_to_status_id" : 722857036577316866,
  "created_at" : "2016-04-20 18:40:37 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722855588175093760",
  "geo" : { },
  "id_str" : "722856450985340928",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins have fun, that\u2019s an awesome read!",
  "id" : 722856450985340928,
  "in_reply_to_status_id" : 722855588175093760,
  "created_at" : "2016-04-20 18:36:22 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 56, 67 ],
      "id_str" : "160877807",
      "id" : 160877807
    }, {
      "name" : "Philip E. Bourne",
      "screen_name" : "pebourne",
      "indices" : [ 72, 81 ],
      "id_str" : "239255514",
      "id" : 239255514
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 102, 118 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722848274139328513\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/CRpWMGB4AO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CggSrOMUIAADQhz.jpg",
      "id_str" : "722848273946386432",
      "id" : 722848273946386432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CggSrOMUIAADQhz.jpg",
      "sizes" : [ {
        "h" : 1091,
        "resize" : "fit",
        "w" : 1454
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1091,
        "resize" : "fit",
        "w" : 1454
      } ],
      "display_url" : "pic.twitter.com\/CRpWMGB4AO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.516648, -122.688621 ]
  },
  "id_str" : "722848274139328513",
  "text" : "Had a great time talking data &amp; donuts at OHSU with @MarkHahnel and @pebourne. Thx for the invite @daniellecrobins! https:\/\/t.co\/CRpWMGB4AO",
  "id" : 722848274139328513,
  "created_at" : "2016-04-20 18:03:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722809142033780736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51651046292722, -122.6886707623331 ]
  },
  "id_str" : "722842921817387009",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins totally didn\u2019t get the notification for this. :D",
  "id" : 722842921817387009,
  "in_reply_to_status_id" : 722809142033780736,
  "created_at" : "2016-04-20 17:42:36 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Rice",
      "screen_name" : "sparrowbarley",
      "indices" : [ 0, 14 ],
      "id_str" : "186096225",
      "id" : 186096225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722594781059153921",
  "geo" : { },
  "id_str" : "722794271414177793",
  "in_reply_to_user_id" : 186096225,
  "text" : "@sparrowbarley so we are connected in some way already :)",
  "id" : 722794271414177793,
  "in_reply_to_status_id" : 722594781059153921,
  "created_at" : "2016-04-20 14:29:17 +0000",
  "in_reply_to_screen_name" : "sparrowbarley",
  "in_reply_to_user_id_str" : "186096225",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722793727677177857",
  "geo" : { },
  "id_str" : "722793879167053824",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs i\u2019m even more happy now that i stopped doing animal experiments long ago.",
  "id" : 722793879167053824,
  "in_reply_to_status_id" : 722793727677177857,
  "created_at" : "2016-04-20 14:27:44 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722793347518062593",
  "geo" : { },
  "id_str" : "722793537662640129",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs \uD83D\uDE31 not at all what they told us back when!",
  "id" : 722793537662640129,
  "in_reply_to_status_id" : 722793347518062593,
  "created_at" : "2016-04-20 14:26:22 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722737219979591682",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51643945905111, -122.6886683005337 ]
  },
  "id_str" : "722784434513022976",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs so it\u2019s rats and not mice, great! ;)",
  "id" : 722784434513022976,
  "in_reply_to_status_id" : 722737219979591682,
  "created_at" : "2016-04-20 13:50:12 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51643570439828, -122.6886871910996 ]
  },
  "id_str" : "722701098247712768",
  "text" : "I think I won Portland: spent the evening discussing bioethics and shaman healing in a gay bar. Your turn.",
  "id" : 722701098247712768,
  "created_at" : "2016-04-20 08:19:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 10, 26 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722608675311853568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51915563926462, -122.6776151684023 ]
  },
  "id_str" : "722613593380925440",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye @RadicevSlobodan on our way.",
  "id" : 722613593380925440,
  "in_reply_to_status_id" : 722608675311853568,
  "created_at" : "2016-04-20 02:31:20 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 63, 79 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722600682268659713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52465931089312, -122.6821763712767 ]
  },
  "id_str" : "722604656535347200",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye yes, not sure why though. So I\u2019ll be heading over to @RadicevSlobodan now and then we can see how to proceed :)",
  "id" : 722604656535347200,
  "in_reply_to_status_id" : 722600682268659713,
  "created_at" : "2016-04-20 01:55:50 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 10, 26 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722600341779288064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52437814888128, -122.6817522571633 ]
  },
  "id_str" : "722600582041575426",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye @RadicevSlobodan great, so that sounds like a match. Somehow I ended up at Deschutes w\/ the FORCE crowd atm.",
  "id" : 722600582041575426,
  "in_reply_to_status_id" : 722600341779288064,
  "created_at" : "2016-04-20 01:39:38 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 35, 51 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722599738520907777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52437814888128, -122.6817522571633 ]
  },
  "id_str" : "722600147809476608",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye where are you right now? @RadicevSlobodan et al. also wanna go out for food\/drinks at some point.",
  "id" : 722600147809476608,
  "in_reply_to_status_id" : 722599738520907777,
  "created_at" : "2016-04-20 01:37:55 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/sApQwBfOZK",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEZ2PhlBwjy\/",
      "display_url" : "instagram.com\/p\/BEZ2PhlBwjy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "722599875322462208",
  "text" : "\u00ABWill you try hiding behind the shelves to be locked in overnight?\u00BB \u2014 \u00ABDon't test me!\u00BB https:\/\/t.co\/sApQwBfOZK",
  "id" : 722599875322462208,
  "created_at" : "2016-04-20 01:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722584750565646336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52453488048451, -122.6819611457686 ]
  },
  "id_str" : "722598798971658240",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye when do you wanna head there? :)",
  "id" : 722598798971658240,
  "in_reply_to_status_id" : 722584750565646336,
  "created_at" : "2016-04-20 01:32:33 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 15, 24 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722578849196683264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51649886833763, -122.6884691073554 ]
  },
  "id_str" : "722580117478748161",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @InfinoMe not sure whether mosh and I can be friends than. Problems with vim would suck.",
  "id" : 722580117478748161,
  "in_reply_to_status_id" : 722578849196683264,
  "created_at" : "2016-04-20 00:18:19 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 0, 11 ],
      "id_str" : "160877807",
      "id" : 160877807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52425915474168, -122.6821393530813 ]
  },
  "id_str" : "722560740658257920",
  "in_reply_to_user_id" : 160877807,
  "text" : "@MarkHahnel btw: wanna ride share tomorrow morning?",
  "id" : 722560740658257920,
  "created_at" : "2016-04-19 23:01:19 +0000",
  "in_reply_to_screen_name" : "MarkHahnel",
  "in_reply_to_user_id_str" : "160877807",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722556612271951872\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/wF9cgRKZI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgcJaFHUsAAGsWU.jpg",
      "id_str" : "722556608870395904",
      "id" : 722556608870395904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgcJaFHUsAAGsWU.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/wF9cgRKZI7"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424759536308, -122.6821429853519 ]
  },
  "id_str" : "722556612271951872",
  "text" : "Pointing out once again, biomed is late to the preprint party. #force2016 https:\/\/t.co\/wF9cgRKZI7",
  "id" : 722556612271951872,
  "created_at" : "2016-04-19 22:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722551572673089536",
  "geo" : { },
  "id_str" : "722551642139131904",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery \uD83D\uDE4F",
  "id" : 722551642139131904,
  "in_reply_to_status_id" : 722551572673089536,
  "created_at" : "2016-04-19 22:25:10 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/hrMvr6mkbC",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722550570381217792",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "722550059712139265",
  "geo" : { },
  "id_str" : "722551108309098496",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery I didn\u2019t plagiarize, I swear ;) https:\/\/t.co\/hrMvr6mkbC",
  "id" : 722551108309098496,
  "in_reply_to_status_id" : 722550059712139265,
  "created_at" : "2016-04-19 22:23:03 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2VNCMNlJhu",
      "expanded_url" : "https:\/\/twitter.com\/ESIP_Erin\/status\/722548636337373185",
      "display_url" : "twitter.com\/ESIP_Erin\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722550570381217792",
  "text" : "A great honor to be amongst those many awesome people doing great stuff! #force2016 https:\/\/t.co\/2VNCMNlJhu",
  "id" : 722550570381217792,
  "created_at" : "2016-04-19 22:20:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722546506457341952",
  "geo" : { },
  "id_str" : "722549407753711618",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC36\uD83D\uDC96",
  "id" : 722549407753711618,
  "in_reply_to_status_id" : 722546506457341952,
  "created_at" : "2016-04-19 22:16:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 53, 62 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722538160450772992\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/qRqIAgFcGw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgb4mz1UEAEZ4RA.jpg",
      "id_str" : "722538135872081921",
      "id" : 722538135872081921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgb4mz1UEAEZ4RA.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qRqIAgFcGw"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427079971624, -122.6821316665451 ]
  },
  "id_str" : "722538160450772992",
  "text" : "Support for open science\/access in the EU #force2016 @senficon https:\/\/t.co\/qRqIAgFcGw",
  "id" : 722538160450772992,
  "created_at" : "2016-04-19 21:31:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 10, 22 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722537937930289152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52425557041255, -122.6821411470506 ]
  },
  "id_str" : "722538147763003392",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @denormalize those two are awesome :)",
  "id" : 722538147763003392,
  "in_reply_to_status_id" : 722537937930289152,
  "created_at" : "2016-04-19 21:31:33 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 10, 22 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/7OlqaiR8ms",
      "expanded_url" : "https:\/\/instagram.com\/p\/BEZZlKkhwmP\/",
      "display_url" : "instagram.com\/p\/BEZZlKkhwmP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5242461911147, -122.6821457499163 ]
  },
  "id_str" : "722537192774471680",
  "text" : "Thanks to @denormalize for this great portrait taken at #force2016! https:\/\/t.co\/7OlqaiR8ms",
  "id" : 722537192774471680,
  "created_at" : "2016-04-19 21:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/WThyGY7iOp",
      "expanded_url" : "https:\/\/twitter.com\/daniellecrobins\/status\/721734186688581634",
      "display_url" : "twitter.com\/daniellecrobin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52420391191013, -122.6821550214266 ]
  },
  "id_str" : "722533735841685504",
  "text" : "I\u2019ll be there: https:\/\/t.co\/WThyGY7iOp",
  "id" : 722533735841685504,
  "created_at" : "2016-04-19 21:14:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52422494649429, -122.6821610278225 ]
  },
  "id_str" : "722522864650326017",
  "text" : "Went into Powell\u2019s Books for half an our during the lunch break today. And now I might not be able to fly home with carry-on luggage only.",
  "id" : 722522864650326017,
  "created_at" : "2016-04-19 20:30:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722489676766916608\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/nk4ZiX5SGm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgbMg4PUIAAH0pR.jpg",
      "id_str" : "722489655464042496",
      "id" : 722489655464042496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgbMg4PUIAAH0pR.jpg",
      "sizes" : [ {
        "h" : 130,
        "resize" : "crop",
        "w" : 130
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/nk4ZiX5SGm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722489676766916608",
  "text" : "ssh over the conference wifi https:\/\/t.co\/nk4ZiX5SGm",
  "id" : 722489676766916608,
  "created_at" : "2016-04-19 18:18:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/fJWQDza7FF",
      "expanded_url" : "http:\/\/lacunas.inct.florabrasil.net\/2014\/index?lang=en",
      "display_url" : "lacunas.inct.florabrasil.net\/2014\/index?lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722476024760369152",
  "text" : "Amazed by Brazil\u2019s virtual herbarium of plants and fungi. I love the fungi of South America! https:\/\/t.co\/fJWQDza7FF #force2016",
  "id" : 722476024760369152,
  "created_at" : "2016-04-19 17:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/EAnHK22rbB",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/722451528859193344",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722472684039241729",
  "text" : "The boat formerly known as\u2026 https:\/\/t.co\/EAnHK22rbB",
  "id" : 722472684039241729,
  "created_at" : "2016-04-19 17:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/9k10tQCu9L",
      "expanded_url" : "https:\/\/ndownloader.figshare.com\/files\/4970227\/preview\/4970227\/page_15_width_860.png",
      "display_url" : "ndownloader.figshare.com\/files\/4970227\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "722461172507799552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52416778901106, -122.6821667951435 ]
  },
  "id_str" : "722467900410343424",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah https:\/\/t.co\/9k10tQCu9L",
  "id" : 722467900410343424,
  "in_reply_to_status_id" : 722461172507799552,
  "created_at" : "2016-04-19 16:52:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 0, 7 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722438702077640704",
  "geo" : { },
  "id_str" : "722450761901170688",
  "in_reply_to_user_id" : 15132914,
  "text" : "@EvoMRI nice",
  "id" : 722450761901170688,
  "in_reply_to_status_id" : 722438702077640704,
  "created_at" : "2016-04-19 15:44:18 +0000",
  "in_reply_to_screen_name" : "EvoMRI",
  "in_reply_to_user_id_str" : "15132914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Flatland",
      "screen_name" : "visitflatland",
      "indices" : [ 13, 27 ],
      "id_str" : "721613979567726592",
      "id" : 721613979567726592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/9k10tQCu9L",
      "expanded_url" : "https:\/\/ndownloader.figshare.com\/files\/4970227\/preview\/4970227\/page_15_width_860.png",
      "display_url" : "ndownloader.figshare.com\/files\/4970227\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "722436417922670592",
  "geo" : { },
  "id_str" : "722440039137841153",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @visitflatland it\u2019s in relation to this slide :p https:\/\/t.co\/9k10tQCu9L",
  "id" : 722440039137841153,
  "in_reply_to_status_id" : 722436417922670592,
  "created_at" : "2016-04-19 15:01:42 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Flatland",
      "screen_name" : "visitflatland",
      "indices" : [ 10, 24 ],
      "id_str" : "721613979567726592",
      "id" : 721613979567726592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722433883069788161",
  "geo" : { },
  "id_str" : "722434411434618880",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @visitflatland yes, I was very happy to see that! My cats back home will love that. :D",
  "id" : 722434411434618880,
  "in_reply_to_status_id" : 722433883069788161,
  "created_at" : "2016-04-19 14:39:20 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 0, 7 ],
      "id_str" : "15132914",
      "id" : 15132914
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 8, 19 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722425402782720000",
  "geo" : { },
  "id_str" : "722432096384323584",
  "in_reply_to_user_id" : 15132914,
  "text" : "@EvoMRI @rchampieux I don\u2019t have any so far. :)",
  "id" : 722432096384323584,
  "in_reply_to_status_id" : 722425402782720000,
  "created_at" : "2016-04-19 14:30:08 +0000",
  "in_reply_to_screen_name" : "EvoMRI",
  "in_reply_to_user_id_str" : "15132914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 0, 7 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722428471985590272",
  "geo" : { },
  "id_str" : "722432047810109440",
  "in_reply_to_user_id" : 15132914,
  "text" : "@EvoMRI I noticed that, what are you reading right now? :D",
  "id" : 722432047810109440,
  "in_reply_to_status_id" : 722428471985590272,
  "created_at" : "2016-04-19 14:29:56 +0000",
  "in_reply_to_screen_name" : "EvoMRI",
  "in_reply_to_user_id_str" : "15132914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flatland",
      "screen_name" : "visitflatland",
      "indices" : [ 90, 104 ],
      "id_str" : "721613979567726592",
      "id" : 721613979567726592
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722431263949238272\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ADp7RCtlh2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgaXZyFUAAEnE-w.jpg",
      "id_str" : "722431259436122113",
      "id" : 722431259436122113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgaXZyFUAAEnE-w.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/ADp7RCtlh2"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 3, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51640963530333, -122.6887376279513 ]
  },
  "id_str" : "722431263949238272",
  "text" : "My #force2016 talk, on paper. Featuring mad scientist-me. Thanks to the awesome people of @visitflatland! https:\/\/t.co\/ADp7RCtlh2",
  "id" : 722431263949238272,
  "created_at" : "2016-04-19 14:26:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722346473648693248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5164062392581, -122.6886441163192 ]
  },
  "id_str" : "722393951320170496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I didn\u2019t bring it along, but I was randomly carrying the WP along in my paper notebook.",
  "id" : 722393951320170496,
  "in_reply_to_status_id" : 722346473648693248,
  "created_at" : "2016-04-19 11:58:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722276589757538304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52582397499418, -122.6851674395577 ]
  },
  "id_str" : "722279534301683712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer they did. And someone with a valid EU drivers license wasn\u2019t allowed to drink. \uD83D\uDE02",
  "id" : 722279534301683712,
  "in_reply_to_status_id" : 722276589757538304,
  "created_at" : "2016-04-19 04:23:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52584354334822, -122.6850752579429 ]
  },
  "id_str" : "722275268358979584",
  "text" : "Apparently you need an international passport to be allowed to drink in Oregon. First time the World Passport actually helped.",
  "id" : 722275268358979584,
  "created_at" : "2016-04-19 04:06:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 15, 28 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52433264013185, -122.6821844129188 ]
  },
  "id_str" : "722250550335524864",
  "text" : "Presenting the @repositiveio poster at #force2016 is so much fun. Great feedback on it so far.",
  "id" : 722250550335524864,
  "created_at" : "2016-04-19 02:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 0, 10 ],
      "id_str" : "777135943",
      "id" : 777135943
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 11, 22 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Inspire",
      "screen_name" : "teaminspire",
      "indices" : [ 23, 35 ],
      "id_str" : "38722208",
      "id" : 38722208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722215690283851776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52223518887219, -122.6813037612953 ]
  },
  "id_str" : "722217772621676544",
  "in_reply_to_user_id" : 777135943,
  "text" : "@ontowonka @openSNPorg @teaminspire sure, let\u2019s do that. After posters tonight?",
  "id" : 722217772621676544,
  "in_reply_to_status_id" : 722215690283851776,
  "created_at" : "2016-04-19 00:18:29 +0000",
  "in_reply_to_screen_name" : "ontowonka",
  "in_reply_to_user_id_str" : "777135943",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 0, 10 ],
      "id_str" : "777135943",
      "id" : 777135943
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 11, 22 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Inspire",
      "screen_name" : "teaminspire",
      "indices" : [ 23, 35 ],
      "id_str" : "38722208",
      "id" : 38722208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722198654417657856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5242730468208, -122.682139411181 ]
  },
  "id_str" : "722199130320179203",
  "in_reply_to_user_id" : 777135943,
  "text" : "@ontowonka @openSNPorg @teaminspire doing something like this has been on our todo since forever. Would love that!",
  "id" : 722199130320179203,
  "in_reply_to_status_id" : 722198654417657856,
  "created_at" : "2016-04-18 23:04:25 +0000",
  "in_reply_to_screen_name" : "ontowonka",
  "in_reply_to_user_id_str" : "777135943",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427463841155, -122.6821386871176 ]
  },
  "id_str" : "722195905680551936",
  "text" : "Publication bias: After including all the negative studies a drug performed statistically worse than a placebo #force2016",
  "id" : 722195905680551936,
  "created_at" : "2016-04-18 22:51:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Federer",
      "screen_name" : "lisafederer",
      "indices" : [ 0, 12 ],
      "id_str" : "361690384",
      "id" : 361690384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722186765780578304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52425269797779, -122.6821476177245 ]
  },
  "id_str" : "722192427239346176",
  "in_reply_to_user_id" : 361690384,
  "text" : "@lisafederer yes, i left that bit out due to time constraints. But we\u2019re also trying to diversify the quantified self end.",
  "id" : 722192427239346176,
  "in_reply_to_status_id" : 722186765780578304,
  "created_at" : "2016-04-18 22:37:46 +0000",
  "in_reply_to_screen_name" : "lisafederer",
  "in_reply_to_user_id_str" : "361690384",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722191516798623746",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427290586829, -122.6821475160865 ]
  },
  "id_str" : "722191720587210752",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience applied what we\u2019ve learnt this morning: know your audience.",
  "id" : 722191720587210752,
  "in_reply_to_status_id" : 722191516798623746,
  "created_at" : "2016-04-18 22:34:58 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 24, 34 ],
      "id_str" : "777135943",
      "id" : 777135943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722191250900824065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424930988992, -122.6821476485873 ]
  },
  "id_str" : "722191574864502784",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy yes, but as @ontowonka pointed out: there\u2019s only 4 nucleotides and it\u2019s already going badly with file formats there ;)",
  "id" : 722191574864502784,
  "in_reply_to_status_id" : 722191250900824065,
  "created_at" : "2016-04-18 22:34:23 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722191100849426432\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/xKakVorTtA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgW8-XlVIAA2PGI.jpg",
      "id_str" : "722191094931333120",
      "id" : 722191094931333120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgW8-XlVIAA2PGI.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/xKakVorTtA"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424930988992, -122.6821476485873 ]
  },
  "id_str" : "722191100849426432",
  "text" : "What researchers can do to share their data. #force2016 https:\/\/t.co\/xKakVorTtA",
  "id" : 722191100849426432,
  "created_at" : "2016-04-18 22:32:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 66, 77 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 81, 89 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/LMGTBrCtAo",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "722190746766286849",
  "text" : "RT @GigaScience: Real community\/crowdfunded project - can support @openSNPorg on @Patreon here https:\/\/t.co\/LMGTBrCtAo #force2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 49, 60 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Patreon",
        "screen_name" : "Patreon",
        "indices" : [ 64, 72 ],
        "id_str" : "1228325660",
        "id" : 1228325660
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "force2016",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/LMGTBrCtAo",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
        "display_url" : "patreon.com\/openSNP?ty=h"
      } ]
    },
    "geo" : { },
    "id_str" : "722186660620795905",
    "text" : "Real community\/crowdfunded project - can support @openSNPorg on @Patreon here https:\/\/t.co\/LMGTBrCtAo #force2016",
    "id" : 722186660620795905,
    "created_at" : "2016-04-18 22:14:52 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 722190746766286849,
  "created_at" : "2016-04-18 22:31:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722183672405733377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424930988992, -122.6821476485873 ]
  },
  "id_str" : "722190414476746753",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience still feels a bit dirty to do it.",
  "id" : 722190414476746753,
  "in_reply_to_status_id" : 722183672405733377,
  "created_at" : "2016-04-18 22:29:47 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722188608480804865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424971486719, -122.6821525500846 ]
  },
  "id_str" : "722189115437912064",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn no problem, appreciate the spirit of it. And it helped finding a bug on our end. So well done!",
  "id" : 722189115437912064,
  "in_reply_to_status_id" : 722188608480804865,
  "created_at" : "2016-04-18 22:24:37 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722188857446248449\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/HlO7eqC6Zo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgW6542UkAABV_x.jpg",
      "id_str" : "722188818938368000",
      "id" : 722188818938368000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgW6542UkAABV_x.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HlO7eqC6Zo"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52425687624108, -122.6821466877259 ]
  },
  "id_str" : "722188857446248449",
  "text" : "How does a PhenoPacket look like? Using Trump as example. #force2016 https:\/\/t.co\/HlO7eqC6Zo",
  "id" : 722188857446248449,
  "created_at" : "2016-04-18 22:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722188844154511364\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qQalz7NvUS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgW62OhVAAAOnbC.jpg",
      "id_str" : "722188756036419584",
      "id" : 722188756036419584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgW62OhVAAAOnbC.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/qQalz7NvUS"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722188844154511364",
  "text" : "We have lots of formats for genetic data, but phenotypes and the environment? #force2016 https:\/\/t.co\/qQalz7NvUS",
  "id" : 722188844154511364,
  "created_at" : "2016-04-18 22:23:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Vasilevsky",
      "screen_name" : "N_Vasilevsky",
      "indices" : [ 0, 13 ],
      "id_str" : "1924323205",
      "id" : 1924323205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722187497652891648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52424971486719, -122.6821525500846 ]
  },
  "id_str" : "722188830472675328",
  "in_reply_to_user_id" : 1924323205,
  "text" : "@N_Vasilevsky glad people enjoy it!",
  "id" : 722188830472675328,
  "in_reply_to_status_id" : 722187497652891648,
  "created_at" : "2016-04-18 22:23:29 +0000",
  "in_reply_to_screen_name" : "N_Vasilevsky",
  "in_reply_to_user_id_str" : "1924323205",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 38, 49 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 89, 104 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722187907042123776",
  "text" : "RT @abbycabs: Like @gedankenstuecke's @openSNPorg talk at #force2016? You can contribute @MozillaScience global sprint June 2-3 \nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 5, 21 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 24, 35 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 75, 90 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "force2016",
        "indices" : [ 44, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/cemp2w51He",
        "expanded_url" : "https:\/\/mozillascience.org\/global-sprint-2016",
        "display_url" : "mozillascience.org\/global-sprint-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722187322469429249",
    "text" : "Like @gedankenstuecke's @openSNPorg talk at #force2016? You can contribute @MozillaScience global sprint June 2-3 \nhttps:\/\/t.co\/cemp2w51He",
    "id" : 722187322469429249,
    "created_at" : "2016-04-18 22:17:29 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 722187907042123776,
  "created_at" : "2016-04-18 22:19:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722187703052206081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722187876025303040",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn thanks for letting me know. Actually we are trying to at least avoid 1:1 duplicates. So that seems to be a bug!",
  "id" : 722187876025303040,
  "in_reply_to_status_id" : 722187703052206081,
  "created_at" : "2016-04-18 22:19:41 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/VdQVUKmEZB",
      "expanded_url" : "https:\/\/twitter.com\/petermurrayrust\/status\/722186620619730944",
      "display_url" : "twitter.com\/petermurrayrus\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722187659691462658",
  "text" : "Thanks! That\u2019s what I was aiming for! https:\/\/t.co\/VdQVUKmEZB",
  "id" : 722187659691462658,
  "created_at" : "2016-04-18 22:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Glenn",
      "screen_name" : "ejglenn030",
      "indices" : [ 0, 11 ],
      "id_str" : "2891208768",
      "id" : 2891208768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722185693024231424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722187489578864640",
  "in_reply_to_user_id" : 2891208768,
  "text" : "@ejglenn030 thanks!",
  "id" : 722187489578864640,
  "in_reply_to_status_id" : 722185693024231424,
  "created_at" : "2016-04-18 22:18:09 +0000",
  "in_reply_to_screen_name" : "ejglenn030",
  "in_reply_to_user_id_str" : "2891208768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristi Holmes",
      "screen_name" : "kristiholmes",
      "indices" : [ 0, 13 ],
      "id_str" : "18999920",
      "id" : 18999920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722184685263040513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722187419781451776",
  "in_reply_to_user_id" : 18999920,
  "text" : "@kristiholmes thanks so much!",
  "id" : 722187419781451776,
  "in_reply_to_status_id" : 722184685263040513,
  "created_at" : "2016-04-18 22:17:53 +0000",
  "in_reply_to_screen_name" : "kristiholmes",
  "in_reply_to_user_id_str" : "18999920",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Vasilevsky",
      "screen_name" : "N_Vasilevsky",
      "indices" : [ 0, 13 ],
      "id_str" : "1924323205",
      "id" : 1924323205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722184127789707264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52427111956101, -122.6821487311794 ]
  },
  "id_str" : "722187203477024768",
  "in_reply_to_user_id" : 1924323205,
  "text" : "@N_Vasilevsky thanks, many of them hand-drawn :)",
  "id" : 722187203477024768,
  "in_reply_to_status_id" : 722184127789707264,
  "created_at" : "2016-04-18 22:17:01 +0000",
  "in_reply_to_screen_name" : "N_Vasilevsky",
  "in_reply_to_user_id_str" : "1924323205",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 3, 14 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 24, 40 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/u67OSpwwbk",
      "expanded_url" : "http:\/\/bit.ly\/1VyBgxH",
      "display_url" : "bit.ly\/1VyBgxH"
    } ]
  },
  "geo" : { },
  "id_str" : "722187153208291328",
  "text" : "RT @rchampieux: More on @gedankenstuecke work here:  https:\/\/t.co\/u67OSpwwbk\n#force2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 8, 24 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "force2016",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/u67OSpwwbk",
        "expanded_url" : "http:\/\/bit.ly\/1VyBgxH",
        "display_url" : "bit.ly\/1VyBgxH"
      } ]
    },
    "geo" : { },
    "id_str" : "722184098643517440",
    "text" : "More on @gedankenstuecke work here:  https:\/\/t.co\/u67OSpwwbk\n#force2016",
    "id" : 722184098643517440,
    "created_at" : "2016-04-18 22:04:41 +0000",
    "user" : {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "protected" : false,
      "id_str" : "20653310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77507928\/c016m_normal.jpg",
      "id" : 20653310,
      "verified" : false
    }
  },
  "id" : 722187153208291328,
  "created_at" : "2016-04-18 22:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722144225261854720",
  "geo" : { },
  "id_str" : "722144522050797568",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek \uD83D\uDE07",
  "id" : 722144522050797568,
  "in_reply_to_status_id" : 722144225261854720,
  "created_at" : "2016-04-18 19:27:25 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722133677262651393",
  "geo" : { },
  "id_str" : "722143901998419969",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek well done, I see the payoff gotten by being so sneaky :D",
  "id" : 722143901998419969,
  "in_reply_to_status_id" : 722133677262651393,
  "created_at" : "2016-04-18 19:24:57 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Ryan Merkley",
      "screen_name" : "ryanmerkley",
      "indices" : [ 22, 34 ],
      "id_str" : "16648767",
      "id" : 16648767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/1G0Dyxzza7",
      "expanded_url" : "http:\/\/www.wired.com\/2016\/04\/stealing-publicly-funded-research-isnt-stealing\/",
      "display_url" : "wired.com\/2016\/04\/steali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722143242796445696",
  "text" : "RT @wilbanks: Go read @ryanmerkley going HAM on scihub kerfuffle and the role of open systems in innovation. https:\/\/t.co\/1G0Dyxzza7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Merkley",
        "screen_name" : "ryanmerkley",
        "indices" : [ 8, 20 ],
        "id_str" : "16648767",
        "id" : 16648767
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/1G0Dyxzza7",
        "expanded_url" : "http:\/\/www.wired.com\/2016\/04\/stealing-publicly-funded-research-isnt-stealing\/",
        "display_url" : "wired.com\/2016\/04\/steali\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722079520220651521",
    "text" : "Go read @ryanmerkley going HAM on scihub kerfuffle and the role of open systems in innovation. https:\/\/t.co\/1G0Dyxzza7",
    "id" : 722079520220651521,
    "created_at" : "2016-04-18 15:09:07 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 722143242796445696,
  "created_at" : "2016-04-18 19:22:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722130219369435136",
  "geo" : { },
  "id_str" : "722130975107362816",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon next time we meet up I can easily do that. (And I\u2019ll put political advisor on my CV after doing so!)",
  "id" : 722130975107362816,
  "in_reply_to_status_id" : 722130219369435136,
  "created_at" : "2016-04-18 18:33:35 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/SE3mS9jqa6",
      "expanded_url" : "https:\/\/twitter.com\/PhilDRoberts\/status\/722129386263044097",
      "display_url" : "twitter.com\/PhilDRoberts\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722129537601916928",
  "text" : "Don\u2019t get me started on those. Otherwise I\u2019ll use my 12-minute slot this afternoon on that instead!  https:\/\/t.co\/SE3mS9jqa6",
  "id" : 722129537601916928,
  "created_at" : "2016-04-18 18:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 0, 9 ],
      "id_str" : "96902749",
      "id" : 96902749
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 19, 35 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722106061830955008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52422452534941, -122.6821434800037 ]
  },
  "id_str" : "722128275783311360",
  "in_reply_to_user_id" : 96902749,
  "text" : "@sniyazov will do. @RadicevSlobodan already talked about how your photos will be missed here!",
  "id" : 722128275783311360,
  "in_reply_to_status_id" : 722106061830955008,
  "created_at" : "2016-04-18 18:22:52 +0000",
  "in_reply_to_screen_name" : "sniyazov",
  "in_reply_to_user_id_str" : "96902749",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722128082597912584\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/pDCVn4UHlH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWDqVfUkAAiVD3.jpg",
      "id_str" : "722128078609092608",
      "id" : 722128078609092608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWDqVfUkAAiVD3.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/pDCVn4UHlH"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52433272306828, -122.6821141599454 ]
  },
  "id_str" : "722128082597912584",
  "text" : "The first pie chart, 1801 by Playfair. A moment hated by data viz experts until today. #force2016 https:\/\/t.co\/pDCVn4UHlH",
  "id" : 722128082597912584,
  "created_at" : "2016-04-18 18:22:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 3, 12 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/uulVaizKz9",
      "expanded_url" : "https:\/\/wp.me\/p7fHjD-o1",
      "display_url" : "wp.me\/p7fHjD-o1"
    } ]
  },
  "geo" : { },
  "id_str" : "722093741675118593",
  "text" : "RT @obf_news: A gift from the Phyloinformatics Summer of Code supports the OBF Travel Fellowship Program https:\/\/t.co\/uulVaizKz9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/uulVaizKz9",
        "expanded_url" : "https:\/\/wp.me\/p7fHjD-o1",
        "display_url" : "wp.me\/p7fHjD-o1"
      } ]
    },
    "geo" : { },
    "id_str" : "722093066350239744",
    "text" : "A gift from the Phyloinformatics Summer of Code supports the OBF Travel Fellowship Program https:\/\/t.co\/uulVaizKz9",
    "id" : 722093066350239744,
    "created_at" : "2016-04-18 16:02:57 +0000",
    "user" : {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "protected" : false,
      "id_str" : "20624794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77404934\/OBF_logo_normal.png",
      "id" : 20624794,
      "verified" : false
    }
  },
  "id" : 722093741675118593,
  "created_at" : "2016-04-18 16:05:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722089127068307457\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/gGhtiXYYuE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVgMwkUMAAVmro.jpg",
      "id_str" : "722089087574749184",
      "id" : 722089087574749184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVgMwkUMAAVmro.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/gGhtiXYYuE"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52432193463456, -122.6821166115741 ]
  },
  "id_str" : "722089127068307457",
  "text" : "Very happy to be amongst this great list of #force2016 fellows! https:\/\/t.co\/gGhtiXYYuE",
  "id" : 722089127068307457,
  "created_at" : "2016-04-18 15:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oYOubUMsoP",
      "expanded_url" : "https:\/\/twitter.com\/monicamorrisong\/status\/722078980975804416",
      "display_url" : "twitter.com\/monicamorrison\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52428326528843, -122.6821317779892 ]
  },
  "id_str" : "722087947432910848",
  "text" : "See me thumb through a 1909 edition of Mendel\u2019s work after taking the tram up to nerd heaven yesterday. #force2016 https:\/\/t.co\/oYOubUMsoP",
  "id" : 722087947432910848,
  "created_at" : "2016-04-18 15:42:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 0, 13 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 14, 22 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/722086479745327104\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/VGIKYG0RnQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVd0usVAAERKN9.jpg",
      "id_str" : "722086475731369985",
      "id" : 722086475731369985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVd0usVAAERKN9.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/VGIKYG0RnQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52423193187369, -122.6821570487558 ]
  },
  "id_str" : "722086479745327104",
  "in_reply_to_user_id" : 3059929578,
  "text" : "@repositiveio @glyn_dk all set :) https:\/\/t.co\/VGIKYG0RnQ",
  "id" : 722086479745327104,
  "created_at" : "2016-04-18 15:36:47 +0000",
  "in_reply_to_screen_name" : "repositiveio",
  "in_reply_to_user_id_str" : "3059929578",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kingsley Shacklebolt",
      "screen_name" : "Sankore_Texte",
      "indices" : [ 0, 14 ],
      "id_str" : "168846668",
      "id" : 168846668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721959332330475520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52423193187369, -122.6821570487558 ]
  },
  "id_str" : "722086173284261888",
  "in_reply_to_user_id" : 168846668,
  "text" : "@Sankore_Texte OHSU Library :)",
  "id" : 722086173284261888,
  "in_reply_to_status_id" : 721959332330475520,
  "created_at" : "2016-04-18 15:35:34 +0000",
  "in_reply_to_screen_name" : "Sankore_Texte",
  "in_reply_to_user_id_str" : "168846668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722075821108760576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51652944226537, -122.6887593619356 ]
  },
  "id_str" : "722076934205616128",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg please don\u2019t! I think there are recordings and I know it\u2019s super late over in the UK by the time :D",
  "id" : 722076934205616128,
  "in_reply_to_status_id" : 722075821108760576,
  "created_at" : "2016-04-18 14:58:51 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "ContentMine",
      "screen_name" : "TheContentMine",
      "indices" : [ 69, 84 ],
      "id_str" : "2466224420",
      "id" : 2466224420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722072624680079360",
  "geo" : { },
  "id_str" : "722075283050737665",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg  I\u2019ll see whether I can fit that in. because we\u2019re not using @TheContentMine for now. :D",
  "id" : 722075283050737665,
  "in_reply_to_status_id" : 722072624680079360,
  "created_at" : "2016-04-18 14:52:17 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722065818926886913",
  "geo" : { },
  "id_str" : "722071985337929728",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg only to a very tiny extend. Is there anything specific I should cover? :D",
  "id" : 722071985337929728,
  "in_reply_to_status_id" : 722065818926886913,
  "created_at" : "2016-04-18 14:39:11 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721950975796207616\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/dxLHhwCRW1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgTilWtUEAAXtls.jpg",
      "id_str" : "721950971664797696",
      "id" : 721950971664797696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgTilWtUEAAXtls.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/dxLHhwCRW1"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51647505480398, -122.688737359324 ]
  },
  "id_str" : "721950975796207616",
  "text" : "The view at tonight\u2019s evening reception: Mt. Hood &amp; Mt. St. Helens #force2016 https:\/\/t.co\/dxLHhwCRW1",
  "id" : 721950975796207616,
  "created_at" : "2016-04-18 06:38:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721892852565876736\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/cxf1814ETT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgStuXXUEAIC-Qf.jpg",
      "id_str" : "721892852343508994",
      "id" : 721892852343508994,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgStuXXUEAIC-Qf.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 973,
        "resize" : "fit",
        "w" : 1298
      }, {
        "h" : 973,
        "resize" : "fit",
        "w" : 1298
      } ],
      "display_url" : "pic.twitter.com\/cxf1814ETT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721892852565876736",
  "text" : "I just thumbed through an 1870 copy of On The Origin of Species. And now I can die happily. https:\/\/t.co\/cxf1814ETT",
  "id" : 721892852565876736,
  "created_at" : "2016-04-18 02:47:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721849514819080192",
  "geo" : { },
  "id_str" : "721849627914280960",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw i noticed you bailed just in time when they announced that I wasn\u2019t joking. ;)",
  "id" : 721849627914280960,
  "in_reply_to_status_id" : 721849514819080192,
  "created_at" : "2016-04-17 23:55:37 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721849338721214464",
  "geo" : { },
  "id_str" : "721849419134427137",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw now I feel like I should have followed you to whatever session :p",
  "id" : 721849419134427137,
  "in_reply_to_status_id" : 721849338721214464,
  "created_at" : "2016-04-17 23:54:47 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/EeZXskIOaM",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Mutual_aid_(organization_theory)",
      "display_url" : "en.wikipedia.org\/wiki\/Mutual_ai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721849073666383872",
  "text" : "Now discussed at the scholarly commons group at #FORCE2016: Mutual aid &amp; Kropotkin. https:\/\/t.co\/EeZXskIOaM",
  "id" : 721849073666383872,
  "created_at" : "2016-04-17 23:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721828613344010240\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/r5IzzMv3JU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRzTEZUUAAnqTL.jpg",
      "id_str" : "721828611720761344",
      "id" : 721828611720761344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRzTEZUUAAnqTL.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/r5IzzMv3JU"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50308219452627, -122.6721154744668 ]
  },
  "id_str" : "721828613344010240",
  "text" : "\u00ABOur crappy version of the COEXIST bumper sticker.\u00BB #force2016 https:\/\/t.co\/r5IzzMv3JU",
  "id" : 721828613344010240,
  "created_at" : "2016-04-17 22:32:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/P4eUr6aAUF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BEUWcnyhwn_\/",
      "display_url" : "instagram.com\/p\/BEUWcnyhwn_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "721826269294424065",
  "text" : "Warming Up #latergram https:\/\/t.co\/P4eUr6aAUF",
  "id" : 721826269294424065,
  "created_at" : "2016-04-17 22:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721824136725540864\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/VfzWpIRh5W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRvOdLUAAMpTXg.jpg",
      "id_str" : "721824134427049987",
      "id" : 721824134427049987,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRvOdLUAAMpTXg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/VfzWpIRh5W"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50311203366685, -122.6720262381217 ]
  },
  "id_str" : "721824136725540864",
  "text" : "The changes of Peer Review #force2016 https:\/\/t.co\/VfzWpIRh5W",
  "id" : 721824136725540864,
  "created_at" : "2016-04-17 22:14:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721812840676401152\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/yAAKvmM8yw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRk89hUUAASnFK.jpg",
      "id_str" : "721812838755356672",
      "id" : 721812838755356672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRk89hUUAASnFK.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/yAAKvmM8yw"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50307296547557, -122.6721471810265 ]
  },
  "id_str" : "721812840676401152",
  "text" : "Sketching the commons at #force2016 https:\/\/t.co\/yAAKvmM8yw",
  "id" : 721812840676401152,
  "created_at" : "2016-04-17 21:29:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721805647973470209",
  "geo" : { },
  "id_str" : "721805804429422593",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw I\u2019d be very happy with that! \uD83C\uDF7B",
  "id" : 721805804429422593,
  "in_reply_to_status_id" : 721805647973470209,
  "created_at" : "2016-04-17 21:01:28 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tardigrade supreme",
      "screen_name" : "mrwaterbear",
      "indices" : [ 0, 12 ],
      "id_str" : "4382131093",
      "id" : 4382131093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721805288861335552",
  "geo" : { },
  "id_str" : "721805496823328768",
  "in_reply_to_user_id" : 4382131093,
  "text" : "@mrwaterbear no discussion at all. team lichen ftw!",
  "id" : 721805496823328768,
  "in_reply_to_status_id" : 721805288861335552,
  "created_at" : "2016-04-17 21:00:15 +0000",
  "in_reply_to_screen_name" : "mrwaterbear",
  "in_reply_to_user_id_str" : "4382131093",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 3, 14 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721803384286617600",
  "text" : "RT @LouWoodley: Why think conceptually about the Scholarly Commons? Co-creating shared principles can help inform new innovations and activ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "force2016",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721802283361521664",
    "text" : "Why think conceptually about the Scholarly Commons? Co-creating shared principles can help inform new innovations and activities #force2016",
    "id" : 721802283361521664,
    "created_at" : "2016-04-17 20:47:29 +0000",
    "user" : {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "protected" : false,
      "id_str" : "20342875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415633332408688640\/IRl4qNXY_normal.jpeg",
      "id" : 20342875,
      "verified" : false
    }
  },
  "id" : 721803384286617600,
  "created_at" : "2016-04-17 20:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721801088102367233",
  "geo" : { },
  "id_str" : "721802978932297728",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw cheap Spanish beer, we can do that I guess.",
  "id" : 721802978932297728,
  "in_reply_to_status_id" : 721801088102367233,
  "created_at" : "2016-04-17 20:50:15 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/9lOXBbTXsx",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scholarly-commons\/",
      "display_url" : "ruleofthirds.de\/scholarly-comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721802858048294912",
  "text" : "If you wanna read up on the Madrid workshop on Scholarly Commons, my quick blogpost from back when: https:\/\/t.co\/9lOXBbTXsx #force2016",
  "id" : 721802858048294912,
  "created_at" : "2016-04-17 20:49:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721801578194149376\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Mxhf0uLNt5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRatYfUMAAiV92.jpg",
      "id_str" : "721801576000532480",
      "id" : 721801576000532480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRatYfUMAAiV92.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Mxhf0uLNt5"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50310732318484, -122.6720623600295 ]
  },
  "id_str" : "721801578194149376",
  "text" : "Re-inventing the wheel can be a good thing. #force2016 https:\/\/t.co\/Mxhf0uLNt5",
  "id" : 721801578194149376,
  "created_at" : "2016-04-17 20:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721800406519525376",
  "geo" : { },
  "id_str" : "721800619007168512",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw before Madrid I\u2019d have had said the same. Go figure!",
  "id" : 721800619007168512,
  "in_reply_to_status_id" : 721800406519525376,
  "created_at" : "2016-04-17 20:40:52 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721799673598480385",
  "geo" : { },
  "id_str" : "721799852221333505",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw you might be asked to join in ;)",
  "id" : 721799852221333505,
  "in_reply_to_status_id" : 721799673598480385,
  "created_at" : "2016-04-17 20:37:49 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721773183448125440",
  "geo" : { },
  "id_str" : "721799476801724416",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs happy to give mine for checking at least one box!",
  "id" : 721799476801724416,
  "in_reply_to_status_id" : 721773183448125440,
  "created_at" : "2016-04-17 20:36:20 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721798697101561856",
  "geo" : { },
  "id_str" : "721799335378161664",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a i\u2019ll try my best!",
  "id" : 721799335378161664,
  "in_reply_to_status_id" : 721798697101561856,
  "created_at" : "2016-04-17 20:35:46 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/9E5JGRUQgU",
      "expanded_url" : "https:\/\/twitter.com\/LouWoodley\/status\/721797705178095616",
      "display_url" : "twitter.com\/LouWoodley\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721798579828817920",
  "text" : "The participants of the Madrid workshop on the Scholarly Commons already promised a dance session. #force2016 https:\/\/t.co\/9E5JGRUQgU",
  "id" : 721798579828817920,
  "created_at" : "2016-04-17 20:32:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721798248529158144",
  "geo" : { },
  "id_str" : "721798324156653569",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a ah, so it\u2019s now or never :D",
  "id" : 721798324156653569,
  "in_reply_to_status_id" : 721798248529158144,
  "created_at" : "2016-04-17 20:31:45 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721790544645660672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50317805354032, -122.6716094849189 ]
  },
  "id_str" : "721792138061590528",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg who would have guessed ;)",
  "id" : 721792138061590528,
  "in_reply_to_status_id" : 721790544645660672,
  "created_at" : "2016-04-17 20:07:10 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50312736843567, -122.6716476204616 ]
  },
  "id_str" : "721772238525976581",
  "text" : "Virtual Reality won\u2019t revolutionize class rooms. Already connecting your laptop to projectors doesn\u2019t work without any problems #force2016",
  "id" : 721772238525976581,
  "created_at" : "2016-04-17 18:48:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721769711818526722",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50315060560668, -122.6716499137862 ]
  },
  "id_str" : "721770244956553216",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a nice, you moved for good? :)",
  "id" : 721770244956553216,
  "in_reply_to_status_id" : 721769711818526722,
  "created_at" : "2016-04-17 18:40:10 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50308604019247, -122.6717623928893 ]
  },
  "id_str" : "721770156943249408",
  "text" : "\u00ABKeep paying attention to those gender symbols used on infographics. From a design standpoint those will change a lot soon.\u00BB #force2016",
  "id" : 721770156943249408,
  "created_at" : "2016-04-17 18:39:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721762350659796992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50312957221405, -122.6716284837373 ]
  },
  "id_str" : "721762938747400192",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a will do. What are you doing in SEA? :D",
  "id" : 721762938747400192,
  "in_reply_to_status_id" : 721762350659796992,
  "created_at" : "2016-04-17 18:11:08 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/pTbl0w0DVQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BETw91yhwnh\/",
      "display_url" : "instagram.com\/p\/BETw91yhwnh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "721743848054120448",
  "text" : "Mixed Use https:\/\/t.co\/pTbl0w0DVQ",
  "id" : 721743848054120448,
  "created_at" : "2016-04-17 16:55:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721742656037117955",
  "geo" : { },
  "id_str" : "721743211815800832",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thanks, at some point I should write a pipeline for generating those talks. Parameterized by talk-length &amp; audience specificity.",
  "id" : 721743211815800832,
  "in_reply_to_status_id" : 721742656037117955,
  "created_at" : "2016-04-17 16:52:45 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721738796690194432",
  "geo" : { },
  "id_str" : "721741349427367938",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thanks, I\u2019m just running through my slides right now :D",
  "id" : 721741349427367938,
  "in_reply_to_status_id" : 721738796690194432,
  "created_at" : "2016-04-17 16:45:21 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/721737046797066240\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/vbMoJeKSoU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgQgBMDUIAIHa1M.jpg",
      "id_str" : "721737045073207298",
      "id" : 721737045073207298,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgQgBMDUIAIHa1M.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/vbMoJeKSoU"
    } ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.50318371928739, -122.6715179566771 ]
  },
  "id_str" : "721737046797066240",
  "text" : "Now I really have to watch out what passport to use on my way out. #force2016 https:\/\/t.co\/vbMoJeKSoU",
  "id" : 721737046797066240,
  "created_at" : "2016-04-17 16:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Roberts",
      "screen_name" : "PhilDRoberts",
      "indices" : [ 0, 13 ],
      "id_str" : "20530586",
      "id" : 20530586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721728403338956800",
  "geo" : { },
  "id_str" : "721736662213009409",
  "in_reply_to_user_id" : 20530586,
  "text" : "@PhilDRoberts no problem, wouldn\u2019t have met on the plane in any case then ;)",
  "id" : 721736662213009409,
  "in_reply_to_status_id" : 721728403338956800,
  "created_at" : "2016-04-17 16:26:44 +0000",
  "in_reply_to_screen_name" : "PhilDRoberts",
  "in_reply_to_user_id_str" : "20530586",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721733273848782849",
  "geo" : { },
  "id_str" : "721736607422754816",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @PhilippBayer thanks, maybe the new Docker wasn\u2019t live yet.",
  "id" : 721736607422754816,
  "in_reply_to_status_id" : 721733273848782849,
  "created_at" : "2016-04-17 16:26:31 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 14, 25 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721698691862503425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51657194944802, -122.6886542497651 ]
  },
  "id_str" : "721715708543897600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @BrianPardy awesome, thanks so much!",
  "id" : 721715708543897600,
  "in_reply_to_status_id" : 721698691862503425,
  "created_at" : "2016-04-17 15:03:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721557925915795456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51640142694944, -122.6886350814442 ]
  },
  "id_str" : "721558124272812032",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley yes, the jumped very dramatically out of a tree i was wandering under.",
  "id" : 721558124272812032,
  "in_reply_to_status_id" : 721557925915795456,
  "created_at" : "2016-04-17 04:37:17 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721556669860196352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51630758677631, -122.688641308873 ]
  },
  "id_str" : "721557751554387969",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley i was nearly attacked by 2 unleashed squirrels today, when looking for dinner!",
  "id" : 721557751554387969,
  "in_reply_to_status_id" : 721556669860196352,
  "created_at" : "2016-04-17 04:35:48 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721553924776263680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5165273225881, -122.6886552861586 ]
  },
  "id_str" : "721554358475694080",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I actually might on my way out! Friday maybe!",
  "id" : 721554358475694080,
  "in_reply_to_status_id" : 721553924776263680,
  "created_at" : "2016-04-17 04:22:19 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721521105765339137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51651023281423, -122.6887758777269 ]
  },
  "id_str" : "721521234891018249",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen happy to help out :p",
  "id" : 721521234891018249,
  "in_reply_to_status_id" : 721521105765339137,
  "created_at" : "2016-04-17 02:10:42 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force2016",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51649835748903, -122.6886660280467 ]
  },
  "id_str" : "721521162027606016",
  "text" : "Hey #force2016, does anyone have dinner plans? Having just come in my body feels like having early breakfast.",
  "id" : 721521162027606016,
  "created_at" : "2016-04-17 02:10:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ryy7PLHaXZ",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Portland_International_Airport_carpet",
      "display_url" : "en.m.wikipedia.org\/wiki\/Portland_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "721520400321146880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51649237765869, -122.6886961068262 ]
  },
  "id_str" : "721520632886747136",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen thanks! (And just in case: https:\/\/t.co\/ryy7PLHaXZ )",
  "id" : 721520632886747136,
  "in_reply_to_status_id" : 721520400321146880,
  "created_at" : "2016-04-17 02:08:18 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/YHB5Xm8ndQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BESK_iZBwux\/",
      "display_url" : "instagram.com\/p\/BESK_iZBwux\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5891603636, -122.594478834 ]
  },
  "id_str" : "721519606234542080",
  "text" : "Am I doing this right? @ Portland International  Airport https:\/\/t.co\/YHB5Xm8ndQ",
  "id" : 721519606234542080,
  "created_at" : "2016-04-17 02:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721511258151903233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5248370161704, -122.6717748587231 ]
  },
  "id_str" : "721511500851109888",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy first destroy the production system and then say \u2018oh, gotta board my connecting flight\u2019 ;)",
  "id" : 721511500851109888,
  "in_reply_to_status_id" : 721511258151903233,
  "created_at" : "2016-04-17 01:32:01 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721473707244404736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44430545721896, -122.3032483087129 ]
  },
  "id_str" : "721474500273917952",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy I\u2019m not feeling adventurous enough to do production changes while jet lagged at an airport \uD83D\uDE02",
  "id" : 721474500273917952,
  "in_reply_to_status_id" : 721473707244404736,
  "created_at" : "2016-04-16 23:04:59 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 28, 41 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721473707244404736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44431467731245, -122.3033128493673 ]
  },
  "id_str" : "721474334800252928",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy ah, snap. Maybe @PhilippBayer can switch that at some point soonish. :)",
  "id" : 721474334800252928,
  "in_reply_to_status_id" : 721473707244404736,
  "created_at" : "2016-04-16 23:04:20 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Roberts",
      "screen_name" : "PhilDRoberts",
      "indices" : [ 0, 13 ],
      "id_str" : "20530586",
      "id" : 20530586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721436825215053826",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44446326172735, -122.3031234143104 ]
  },
  "id_str" : "721469891811745792",
  "in_reply_to_user_id" : 20530586,
  "text" : "@PhilDRoberts are you on the 5pm flight too? :D",
  "id" : 721469891811745792,
  "in_reply_to_status_id" : 721436825215053826,
  "created_at" : "2016-04-16 22:46:41 +0000",
  "in_reply_to_screen_name" : "PhilDRoberts",
  "in_reply_to_user_id_str" : "20530586",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/y003RxkT8Z",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/28212",
      "display_url" : "goodreads.com\/book\/show\/28212"
    } ]
  },
  "in_reply_to_status_id_str" : "721466364045561856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4444008098061, -122.3033098719104 ]
  },
  "id_str" : "721467449032318976",
  "in_reply_to_user_id" : 14286491,
  "text" : "#3: The first 50% I read of And the Band Played On: Politics, People, and the AIDS Epidemic by Randy Shilts https:\/\/t.co\/y003RxkT8Z",
  "id" : 721467449032318976,
  "in_reply_to_status_id" : 721466364045561856,
  "created_at" : "2016-04-16 22:36:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/desaAy6CoO",
      "expanded_url" : "http:\/\/www.tabletmag.com\/jewish-life-and-religion\/195164\/israel-story-jeff-yaacov-jessica-yiscah",
      "display_url" : "tabletmag.com\/jewish-life-an\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "721466364045561856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44457944227503, -122.3035461792959 ]
  },
  "id_str" : "721467127962607616",
  "in_reply_to_user_id" : 14286491,
  "text" : "#2: How Jeff became Yaacov became Jessica became Yiscah https:\/\/t.co\/desaAy6CoO",
  "id" : 721467127962607616,
  "in_reply_to_status_id" : 721466364045561856,
  "created_at" : "2016-04-16 22:35:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/aNKFjxVkG5",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/93840",
      "display_url" : "goodreads.com\/book\/show\/93840"
    } ]
  },
  "in_reply_to_status_id_str" : "721466364045561856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4445869640352, -122.3035440518831 ]
  },
  "id_str" : "721466514939842560",
  "in_reply_to_user_id" : 14286491,
  "text" : "#1: Diary of a Mad Old Man by Jun\u2019ichir\u014D Tanizaki https:\/\/t.co\/aNKFjxVkG5",
  "id" : 721466514939842560,
  "in_reply_to_status_id" : 721466364045561856,
  "created_at" : "2016-04-16 22:33:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4445869640352, -122.3035440518831 ]
  },
  "id_str" : "721466364045561856",
  "text" : "What follows is a non-comprehensive list of things that made me tear up on this long-distance flight.",
  "id" : 721466364045561856,
  "created_at" : "2016-04-16 22:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721458637236019200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44447232262522, -122.3034751313502 ]
  },
  "id_str" : "721465759398952961",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy great, thanks for testing it!",
  "id" : 721465759398952961,
  "in_reply_to_status_id" : 721458637236019200,
  "created_at" : "2016-04-16 22:30:15 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721457706784178177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44447232262522, -122.3034751313502 ]
  },
  "id_str" : "721465712204591104",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe they got it up and running in the end. :D",
  "id" : 721465712204591104,
  "in_reply_to_status_id" : 721457706784178177,
  "created_at" : "2016-04-16 22:30:04 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721457358384283649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43854104392101, -122.3027129992794 ]
  },
  "id_str" : "721457517809651712",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe worst part: the regular WiFi is down too! :p",
  "id" : 721457517809651712,
  "in_reply_to_status_id" : 721457358384283649,
  "created_at" : "2016-04-16 21:57:30 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721456058728845313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43888713587796, -122.3027470555216 ]
  },
  "id_str" : "721456184348135427",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy could you do a regular zip file? That should work.",
  "id" : 721456184348135427,
  "in_reply_to_status_id" : 721456058728845313,
  "created_at" : "2016-04-16 21:52:13 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43852250028637, -122.3024092853128 ]
  },
  "id_str" : "721455174275862528",
  "text" : "\u00ABOur fiber optics cable was cut. So we can\u2019t process anyone right now.\u00BB crossing borders, so much fun.",
  "id" : 721455174275862528,
  "created_at" : "2016-04-16 21:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721336626614562816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43899535078641, -122.3030875376979 ]
  },
  "id_str" : "721452607470895104",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy that one should(tm) work. So give it a try if you want. How large is your VCF? :)",
  "id" : 721452607470895104,
  "in_reply_to_status_id" : 721336626614562816,
  "created_at" : "2016-04-16 21:38:00 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721289930652131328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04087530060605, 8.548406927355268 ]
  },
  "id_str" : "721290162773352448",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog sitze gerade im Flugzeug nach Portland \u00FCber Seattle um dort bei der FORCE Konferenz einen Talk zu geben :)",
  "id" : 721290162773352448,
  "in_reply_to_status_id" : 721289930652131328,
  "created_at" : "2016-04-16 10:52:30 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721289437213245440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04044528107514, 8.548078885101798 ]
  },
  "id_str" : "721289641580765186",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog n\u00E4chstes Jahr dann hoffentlich wieder in Person um die Tassen zu heben :)",
  "id" : 721289641580765186,
  "in_reply_to_status_id" : 721289437213245440,
  "created_at" : "2016-04-16 10:50:26 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03941459426031, 8.550430719484835 ]
  },
  "id_str" : "721286632658362369",
  "text" : "\u00ABOur take-off is delayed by a bit because we\u2019re still missing a dog.\u00BB Best reason to wait.",
  "id" : 721286632658362369,
  "created_at" : "2016-04-16 10:38:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721280568512655360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04065346310719, 8.549374446550338 ]
  },
  "id_str" : "721280948449452032",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog viel Spa\u00DF und liebe Gr\u00FC\u00DFe an alle! :)",
  "id" : 721280948449452032,
  "in_reply_to_status_id" : 721280568512655360,
  "created_at" : "2016-04-16 10:15:53 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "ScienceOpen",
      "screen_name" : "Science_Open",
      "indices" : [ 37, 50 ],
      "id_str" : "1246397209",
      "id" : 1246397209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DeZVf8VfzP",
      "expanded_url" : "http:\/\/bit.ly\/1XxFqDa",
      "display_url" : "bit.ly\/1XxFqDa"
    } ]
  },
  "geo" : { },
  "id_str" : "721280667976351745",
  "text" : "RT @iaravps: ICYMI, my interview for @Science_Open went up yesterday. Apparently I'm a star https:\/\/t.co\/DeZVf8VfzP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ScienceOpen",
        "screen_name" : "Science_Open",
        "indices" : [ 24, 37 ],
        "id_str" : "1246397209",
        "id" : 1246397209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/DeZVf8VfzP",
        "expanded_url" : "http:\/\/bit.ly\/1XxFqDa",
        "display_url" : "bit.ly\/1XxFqDa"
      } ]
    },
    "geo" : { },
    "id_str" : "721075843632623617",
    "text" : "ICYMI, my interview for @Science_Open went up yesterday. Apparently I'm a star https:\/\/t.co\/DeZVf8VfzP",
    "id" : 721075843632623617,
    "created_at" : "2016-04-15 20:40:52 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 721280667976351745,
  "created_at" : "2016-04-16 10:14:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03991858981989, 8.550118835945801 ]
  },
  "id_str" : "721280298428854272",
  "text" : "\u00ABWe can\u2019t board you with a digital boarding pass. How would we scribble on it using ballpoint?\u00BB the digital revolution\u2026",
  "id" : 721280298428854272,
  "created_at" : "2016-04-16 10:13:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719552113861378048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0504169791174, 8.58162231776731 ]
  },
  "id_str" : "721271296659742721",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy totally didn\u2019t see your tweet. Sorry about that. Did the upload work? :)",
  "id" : 721271296659742721,
  "in_reply_to_status_id" : 719552113861378048,
  "created_at" : "2016-04-16 09:37:32 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04956176025426, 8.581631820845095 ]
  },
  "id_str" : "721254065146052609",
  "text" : "Ready for FRA \u2708\uFE0F SEA \u2708\uFE0F PDX.",
  "id" : 721254065146052609,
  "created_at" : "2016-04-16 08:29:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 0, 11 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721098286757580800",
  "geo" : { },
  "id_str" : "721098640329203712",
  "in_reply_to_user_id" : 322658299,
  "text" : "@HopeJahren too bad, will have to find another chance for a signed copy &amp; listening then. All the best for this evening &amp; safe travels tmrw!",
  "id" : 721098640329203712,
  "in_reply_to_status_id" : 721098286757580800,
  "created_at" : "2016-04-15 22:11:27 +0000",
  "in_reply_to_screen_name" : "HopeJahren",
  "in_reply_to_user_id_str" : "322658299",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Brack",
      "screen_name" : "beeblebrax",
      "indices" : [ 0, 11 ],
      "id_str" : "15621870",
      "id" : 15621870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721097208637046788",
  "geo" : { },
  "id_str" : "721097355093811200",
  "in_reply_to_user_id" : 15621870,
  "text" : "@beeblebrax I\u2019m a bit more worried about switching from metric to imperial mid-flight.",
  "id" : 721097355093811200,
  "in_reply_to_status_id" : 721097208637046788,
  "created_at" : "2016-04-15 22:06:21 +0000",
  "in_reply_to_screen_name" : "beeblebrax",
  "in_reply_to_user_id_str" : "15621870",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721096221394399233",
  "text" : "Airlines that can\u2019t correctly calculate their own flight time when crossing time zones. \uD83D\uDE02",
  "id" : 721096221394399233,
  "created_at" : "2016-04-15 22:01:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 0, 11 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721049712162316288",
  "geo" : { },
  "id_str" : "721088330746740740",
  "in_reply_to_user_id" : 322658299,
  "text" : "@HopeJahren snap, and I\u2019ll only come into town tomorrow. Guess you\u2019re not doing a second reading\/signing then? :D",
  "id" : 721088330746740740,
  "in_reply_to_status_id" : 721049712162316288,
  "created_at" : "2016-04-15 21:30:29 +0000",
  "in_reply_to_screen_name" : "HopeJahren",
  "in_reply_to_user_id_str" : "322658299",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/AE9hHkLjmV",
      "expanded_url" : "https:\/\/hbr.org\/2015\/03\/the-5-biases-pushing-women-out-of-stem",
      "display_url" : "hbr.org\/2015\/03\/the-5-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721084785179959296",
  "text" : "The 5 Biases Pushing Women Out of STEM https:\/\/t.co\/AE9hHkLjmV",
  "id" : 721084785179959296,
  "created_at" : "2016-04-15 21:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saeed Jones",
      "screen_name" : "theferocity",
      "indices" : [ 3, 15 ],
      "id_str" : "15649438",
      "id" : 15649438
    }, {
      "name" : "Niela Orr",
      "screen_name" : "nielaorr",
      "indices" : [ 51, 60 ],
      "id_str" : "99881780",
      "id" : 99881780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Rsbeb9pmqc",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/nielaorr\/black-trauma-remixed-for-your-clicks#.wigeZW3G5v",
      "display_url" : "buzzfeed.com\/nielaorr\/black\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721014680848900096",
  "text" : "RT @theferocity: Brilliant cultural criticism from @nielaorr: \"Black Trauma Remixed For Your Clicks\u201D https:\/\/t.co\/Rsbeb9pmqc https:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Niela Orr",
        "screen_name" : "nielaorr",
        "indices" : [ 34, 43 ],
        "id_str" : "99881780",
        "id" : 99881780
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theferocity\/status\/720651921518960640\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/onwKeBpyIO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgBFFQaW4AAU1Hv.jpg",
        "id_str" : "720651896986460160",
        "id" : 720651896986460160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgBFFQaW4AAU1Hv.jpg",
        "sizes" : [ {
          "h" : 498,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 890
        } ],
        "display_url" : "pic.twitter.com\/onwKeBpyIO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/Rsbeb9pmqc",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/nielaorr\/black-trauma-remixed-for-your-clicks#.wigeZW3G5v",
        "display_url" : "buzzfeed.com\/nielaorr\/black\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720651921518960640",
    "text" : "Brilliant cultural criticism from @nielaorr: \"Black Trauma Remixed For Your Clicks\u201D https:\/\/t.co\/Rsbeb9pmqc https:\/\/t.co\/onwKeBpyIO",
    "id" : 720651921518960640,
    "created_at" : "2016-04-14 16:36:21 +0000",
    "user" : {
      "name" : "Saeed Jones",
      "screen_name" : "theferocity",
      "protected" : false,
      "id_str" : "15649438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912106572481998855\/6k1r0Nlu_normal.jpg",
      "id" : 15649438,
      "verified" : true
    }
  },
  "id" : 721014680848900096,
  "created_at" : "2016-04-15 16:37:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/9RycVjhYVg",
      "expanded_url" : "http:\/\/gu.com\/p\/4tc43\/stw",
      "display_url" : "gu.com\/p\/4tc43\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "721010915479527425",
  "text" : "RT @phylogenomics: Pepper-sprayed students outraged as UC Davis tried to scrub incident from web https:\/\/t.co\/9RycVjhYVg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/9RycVjhYVg",
        "expanded_url" : "http:\/\/gu.com\/p\/4tc43\/stw",
        "display_url" : "gu.com\/p\/4tc43\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "721010338489958404",
    "text" : "Pepper-sprayed students outraged as UC Davis tried to scrub incident from web https:\/\/t.co\/9RycVjhYVg",
    "id" : 721010338489958404,
    "created_at" : "2016-04-15 16:20:35 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 721010915479527425,
  "created_at" : "2016-04-15 16:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720988040420859905",
  "text" : "the good feeling of having a first draft of a slide deck ready before boarding the flight.",
  "id" : 720988040420859905,
  "created_at" : "2016-04-15 14:51:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720913757849956352",
  "geo" : { },
  "id_str" : "720914798456750081",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, we should replace our error 500 page :D",
  "id" : 720914798456750081,
  "in_reply_to_status_id" : 720913757849956352,
  "created_at" : "2016-04-15 10:00:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 43, 55 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 56, 69 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/KCZB9bIFIk",
      "expanded_url" : "http:\/\/classicprogrammerpaintings.tumblr.com\/post\/142737403879\/programmers-at-work-maintaining-a-ruby-on-rails",
      "display_url" : "classicprogrammerpaintings.tumblr.com\/post\/142737403\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720912590336102404",
  "text" : "Maintaining Rails applications. Too close, @helgerausch @PhilippBayer? https:\/\/t.co\/KCZB9bIFIk",
  "id" : 720912590336102404,
  "created_at" : "2016-04-15 09:52:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/SMzWo0doFn",
      "expanded_url" : "https:\/\/twitter.com\/MsPhelps\/status\/720674234092142592",
      "display_url" : "twitter.com\/MsPhelps\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720906966873350144",
  "text" : "Glad I saw this tweet before packing tonight. https:\/\/t.co\/SMzWo0doFn",
  "id" : 720906966873350144,
  "created_at" : "2016-04-15 09:29:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/9hOcXJKT17",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/apr\/14\/the-red-pill-reddit-modern-misogyny-manosphere-men",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720884685069377536",
  "text" : "\u00ABanswers to the question \u201Chow shitty are men really?\u201D\u00BB https:\/\/t.co\/9hOcXJKT17",
  "id" : 720884685069377536,
  "created_at" : "2016-04-15 08:01:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/rJ9mca4J4S",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/720751012953231360",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139892349457, 8.753460237040642 ]
  },
  "id_str" : "720764839463923712",
  "text" : "My favorite hummus joint in Amsterdam :3 https:\/\/t.co\/rJ9mca4J4S",
  "id" : 720764839463923712,
  "created_at" : "2016-04-15 00:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720727817638518785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400707941389, 8.753475721798793 ]
  },
  "id_str" : "720753896549978113",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski no wonder they ask for money all the time!",
  "id" : 720753896549978113,
  "in_reply_to_status_id" : 720727817638518785,
  "created_at" : "2016-04-14 23:21:34 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 8, 18 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720736937506643968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392954282234, 8.753488527265075 ]
  },
  "id_str" : "720737117807190016",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @auremoser don\u2019t tell anyone that this is the whole thing that there is to science :D",
  "id" : 720737117807190016,
  "in_reply_to_status_id" : 720736937506643968,
  "created_at" : "2016-04-14 22:14:54 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 7, 17 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/6qfLHNELEF",
      "expanded_url" : "http:\/\/i.giphy.com\/3zNswv0TmYz5u.gif",
      "display_url" : "i.giphy.com\/3zNswv0TmYz5u.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720735853404942336",
  "text" : "thanks @auremoser, this basically describes my life right now https:\/\/t.co\/6qfLHNELEF",
  "id" : 720735853404942336,
  "created_at" : "2016-04-14 22:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 10, 20 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720567098305552384",
  "geo" : { },
  "id_str" : "720616633392316416",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @auremoser you like it too? :D",
  "id" : 720616633392316416,
  "in_reply_to_status_id" : 720567098305552384,
  "created_at" : "2016-04-14 14:16:08 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/shUn2VZwGf",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2013\/10\/why-we-cry-on-planes\/280143\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720543523611787264",
  "text" : "\u00AByou find yourself all alone in the low drone of the plane, what will you do?\u00BB Honestly love long-haul \u2708\uFE0F\u2019s for this https:\/\/t.co\/shUn2VZwGf",
  "id" : 720543523611787264,
  "created_at" : "2016-04-14 09:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 16, 30 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720422604901748736",
  "geo" : { },
  "id_str" : "720541492083834880",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @BioMickWatson just use enough SNP callers and you\u2019ll find there are no real SNPs but only SNP calling artefacts?",
  "id" : 720541492083834880,
  "in_reply_to_status_id" : 720422604901748736,
  "created_at" : "2016-04-14 09:17:33 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720528369901813760",
  "geo" : { },
  "id_str" : "720528492891402240",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this means my virtual workspace is just as messy as my physical one.",
  "id" : 720528492891402240,
  "in_reply_to_status_id" : 720528369901813760,
  "created_at" : "2016-04-14 08:25:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720527556391383040",
  "geo" : { },
  "id_str" : "720528043803086848",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot winner by an extreme margin he tried to say I guess, as those 5.9 TB are more than places 2 to 4 combined.",
  "id" : 720528043803086848,
  "in_reply_to_status_id" : 720527556391383040,
  "created_at" : "2016-04-14 08:24:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/iCXlmre8bJ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371%2Fjournal.pone.0152121",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720523655785132032",
  "text" : "\u00ABOur results supported the prediction that playing violent-sexist video games increases masculine beliefs\u2026\u00BB https:\/\/t.co\/iCXlmre8bJ",
  "id" : 720523655785132032,
  "created_at" : "2016-04-14 08:06:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720523218650591234",
  "text" : "\u00AB\u2026lonesome rider Bastian has about 5.9 TB of space reserved\u2026\u00BB Time to rather quickly leave the country I\u2019d say\u2026",
  "id" : 720523218650591234,
  "created_at" : "2016-04-14 08:04:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Va5q3jQQZc",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/720385482782285826",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "720385482782285826",
  "geo" : { },
  "id_str" : "720385709169885184",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just looking at the boxplot in Figure 1 (f) I suspect a statistical fluke\u2026 https:\/\/t.co\/Va5q3jQQZc",
  "id" : 720385709169885184,
  "in_reply_to_status_id" : 720385482782285826,
  "created_at" : "2016-04-13 22:58:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 94, 100 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 101, 116 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GgX8KYlqb2",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371%2Fjournal.pone.0151138",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720385482782285826",
  "text" : "\u00ABLanguages Support Efficient Communication about the Environment: Words for Snow Revisited\u00BB \/ @lobot @astefanowitsch https:\/\/t.co\/GgX8KYlqb2",
  "id" : 720385482782285826,
  "created_at" : "2016-04-13 22:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720358570240446464",
  "text" : "\u00ABMore than 1 significant other? Bonferroni or FDR corrected?\u00BB\u2013\u00ABShould write an appendix to The Ethical Slut\u2026\u00BB\u2013\u00ABThe Statistically Sound Slut\u00BB",
  "id" : 720358570240446464,
  "created_at" : "2016-04-13 21:10:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720287495078825984",
  "text" : "\u00AB\u2026yielding a highly contagious genome assembly\u2026\u00BB ok, I think I should take a break from writing.",
  "id" : 720287495078825984,
  "created_at" : "2016-04-13 16:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "I am Germany",
      "screen_name" : "I_amGermany",
      "indices" : [ 11, 23 ],
      "id_str" : "613201592",
      "id" : 613201592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720261799703101444",
  "geo" : { },
  "id_str" : "720262842432294912",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @I_amGermany I guess you can basically go for citizenship right away",
  "id" : 720262842432294912,
  "in_reply_to_status_id" : 720261799703101444,
  "created_at" : "2016-04-13 14:50:18 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The English Major",
      "screen_name" : "Audenary",
      "indices" : [ 3, 12 ],
      "id_str" : "3401649569",
      "id" : 3401649569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720251266845126657",
  "text" : "RT @Audenary: 'What breed is he?'\n\nMe: A Bertrand Russell\n\n'Haha, you mean a Jack Russell'\n\nDog: To conquer fear is the beginning of wisdom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685771012630265856",
    "text" : "'What breed is he?'\n\nMe: A Bertrand Russell\n\n'Haha, you mean a Jack Russell'\n\nDog: To conquer fear is the beginning of wisdom, Mike.",
    "id" : 685771012630265856,
    "created_at" : "2016-01-09 10:32:05 +0000",
    "user" : {
      "name" : "The English Major",
      "screen_name" : "Audenary",
      "protected" : false,
      "id_str" : "3401649569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791536622189834240\/PInL8B3f_normal.jpg",
      "id" : 3401649569,
      "verified" : false
    }
  },
  "id" : 720251266845126657,
  "created_at" : "2016-04-13 14:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/3SyJQop5P9",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/originals\/29\/d5\/94\/29d594e8f2f3d5e655455e7cab079208.gif",
      "display_url" : "s-media-cache-ak0.pinimg.com\/originals\/29\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720251192996139008",
  "text" : "geom_jitter(), aka I had too much coffee today. https:\/\/t.co\/3SyJQop5P9",
  "id" : 720251192996139008,
  "created_at" : "2016-04-13 14:04:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 5, 15 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/UWTipq5IYg",
      "expanded_url" : "https:\/\/twitter.com\/I_amGermany\/status\/719995620249968640",
      "display_url" : "twitter.com\/I_amGermany\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720231677449080833",
  "text" : "Omg, @eltonjohn, they are playing our song! https:\/\/t.co\/UWTipq5IYg",
  "id" : 720231677449080833,
  "created_at" : "2016-04-13 12:46:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720226252779614209",
  "geo" : { },
  "id_str" : "720227828336353280",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley the defiant squirrel lovers? :D",
  "id" : 720227828336353280,
  "in_reply_to_status_id" : 720226252779614209,
  "created_at" : "2016-04-13 12:31:10 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720158382775279616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249498834706, 8.627534073285224 ]
  },
  "id_str" : "720185743860232192",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \uD83D\uDE07",
  "id" : 720185743860232192,
  "in_reply_to_status_id" : 720158382775279616,
  "created_at" : "2016-04-13 09:43:56 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rQE01K1ZiT",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/04\/12\/science\/scientists-unveil-new-tree-of-life.html?smid=tw-share",
      "display_url" : "nytimes.com\/2016\/04\/12\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720163276055822336",
  "text" : "\u00ABThe researchers found that bacteria make up most of life\u2019s branches.\u00BB cool tree, but is this really news? \uD83E\uDD14 https:\/\/t.co\/rQE01K1ZiT",
  "id" : 720163276055822336,
  "created_at" : "2016-04-13 08:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720056453424377856",
  "geo" : { },
  "id_str" : "720158570461925376",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley I refuse to accept \uD83D\uDC3F not being a squirrel. At least unless we finally get a real replacement.",
  "id" : 720158570461925376,
  "in_reply_to_status_id" : 720056453424377856,
  "created_at" : "2016-04-13 07:55:57 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/s8i82jUvio",
      "expanded_url" : "https:\/\/twitter.com\/duffy_ma\/status\/719994645409759232",
      "display_url" : "twitter.com\/duffy_ma\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720158085415899138",
  "text" : "I can\u2019t wait for the moment when they are rebranded using a unicode character. I suggest \u2627 for now.  https:\/\/t.co\/s8i82jUvio",
  "id" : 720158085415899138,
  "created_at" : "2016-04-13 07:54:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 0, 10 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719958918114349056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086099431855, 8.818519189962016 ]
  },
  "id_str" : "719991640706912256",
  "in_reply_to_user_id" : 267256091,
  "text" : "@_inundata see ya at PDX!",
  "id" : 719991640706912256,
  "in_reply_to_status_id" : 719958918114349056,
  "created_at" : "2016-04-12 20:52:38 +0000",
  "in_reply_to_screen_name" : "_inundata",
  "in_reply_to_user_id_str" : "267256091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine",
      "screen_name" : "mbonsma",
      "indices" : [ 0, 8 ],
      "id_str" : "422839831",
      "id" : 422839831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719942862109061120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085060309213, 8.818588217403912 ]
  },
  "id_str" : "719967851986231296",
  "in_reply_to_user_id" : 422839831,
  "text" : "@mbonsma that\u2019s so tempting. I know the feeling :D",
  "id" : 719967851986231296,
  "in_reply_to_status_id" : 719942862109061120,
  "created_at" : "2016-04-12 19:18:06 +0000",
  "in_reply_to_screen_name" : "mbonsma",
  "in_reply_to_user_id_str" : "422839831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/tHCvhj9uDp",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/q8A1ONMbcQ0rS\/200.gif",
      "display_url" : "media2.giphy.com\/media\/q8A1ONMb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18176640010431, 8.622439162491387 ]
  },
  "id_str" : "719901048400424960",
  "text" : "Now: https:\/\/t.co\/tHCvhj9uDp",
  "id" : 719901048400424960,
  "created_at" : "2016-04-12 14:52:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 0, 7 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719851637318164481",
  "geo" : { },
  "id_str" : "719852091750158336",
  "in_reply_to_user_id" : 9793782,
  "text" : "@compay Sc\u00E4ndinavian J\u00F6rnal. There you go ;)",
  "id" : 719852091750158336,
  "in_reply_to_status_id" : 719851637318164481,
  "created_at" : "2016-04-12 11:38:07 +0000",
  "in_reply_to_screen_name" : "compay",
  "in_reply_to_user_id_str" : "9793782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/BpuycckLHg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kbW5sxyu9bU",
      "display_url" : "youtube.com\/watch?v=kbW5sx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719838605808635904",
  "text" : "\u00AB\u2026by combining the powers of short- and long-read sequencing\u2026\u00BB https:\/\/t.co\/BpuycckLHg",
  "id" : 719838605808635904,
  "created_at" : "2016-04-12 10:44:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Leighton Pritchard",
      "screen_name" : "widdowquinn",
      "indices" : [ 64, 76 ],
      "id_str" : "26800968",
      "id" : 26800968
    }, {
      "name" : "Sebastian Eves-van d",
      "screen_name" : "Seb_EvdA",
      "indices" : [ 77, 86 ],
      "id_str" : "2530205788",
      "id" : 2530205788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719827724949458944",
  "text" : "RT @pjacock: Public science engagement idea over morning tea w\/ @widdowquinn @Seb_EvdA etc: Dance Dance Evolution!\n\nAlready done https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leighton Pritchard",
        "screen_name" : "widdowquinn",
        "indices" : [ 51, 63 ],
        "id_str" : "26800968",
        "id" : 26800968
      }, {
        "name" : "Sebastian Eves-van d",
        "screen_name" : "Seb_EvdA",
        "indices" : [ 64, 73 ],
        "id_str" : "2530205788",
        "id" : 2530205788
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/miAgEzZ6Ke",
        "expanded_url" : "http:\/\/blog.danielwilson.me.uk\/2014\/06\/cheltenham-science-festival.html",
        "display_url" : "blog.danielwilson.me.uk\/2014\/06\/chelte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719824400971886592",
    "text" : "Public science engagement idea over morning tea w\/ @widdowquinn @Seb_EvdA etc: Dance Dance Evolution!\n\nAlready done https:\/\/t.co\/miAgEzZ6Ke",
    "id" : 719824400971886592,
    "created_at" : "2016-04-12 09:48:05 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 719827724949458944,
  "created_at" : "2016-04-12 10:01:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeb",
      "screen_name" : "treblesteph",
      "indices" : [ 0, 12 ],
      "id_str" : "316299043",
      "id" : 316299043
    }, {
      "name" : "\u24EA Rik Smith-Unna",
      "screen_name" : "blahah404",
      "indices" : [ 13, 23 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719823705199808512",
  "geo" : { },
  "id_str" : "719827573639880704",
  "in_reply_to_user_id" : 316299043,
  "text" : "@treblesteph @blahah404 \u201EAssassin\u2019s Creed: Coding\u201C \uD83D\uDE09",
  "id" : 719827573639880704,
  "in_reply_to_status_id" : 719823705199808512,
  "created_at" : "2016-04-12 10:00:41 +0000",
  "in_reply_to_screen_name" : "treblesteph",
  "in_reply_to_user_id_str" : "316299043",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719827020046327808",
  "text" : "I might be willing to take the free Nature Methods subscription they try to push because it means I\u2019ll get less spam in the short term\u2026",
  "id" : 719827020046327808,
  "created_at" : "2016-04-12 09:58:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719794247386406912",
  "geo" : { },
  "id_str" : "719817831433576448",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin that sucks, openSNP got some spam via the phenotype system in the past. Had to start using recaptcha.",
  "id" : 719817831433576448,
  "in_reply_to_status_id" : 719794247386406912,
  "created_at" : "2016-04-12 09:21:59 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719739624839512064",
  "geo" : { },
  "id_str" : "719805153805799424",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez omg, awesome :)",
  "id" : 719805153805799424,
  "in_reply_to_status_id" : 719739624839512064,
  "created_at" : "2016-04-12 08:31:36 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/7fCPv4koYE",
      "expanded_url" : "http:\/\/fap.sagepub.com\/content\/20\/1\/53.abstract",
      "display_url" : "fap.sagepub.com\/content\/20\/1\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719803196185657345",
  "text" : "\u2018vegansexuals\u2019, funny how they spell \u2018assortative mating\u2019 these days. https:\/\/t.co\/7fCPv4koYE",
  "id" : 719803196185657345,
  "created_at" : "2016-04-12 08:23:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/OhkcFyFrCu",
      "expanded_url" : "http:\/\/fuckyeahhipsterblackmetal.tumblr.com\/image\/94531843288",
      "display_url" : "fuckyeahhipsterblackmetal.tumblr.com\/image\/94531843\u2026"
    }, {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/d1bSRtc1KL",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/719798278200639489",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719798278200639489",
  "geo" : { },
  "id_str" : "719799436654866432",
  "in_reply_to_user_id" : 14286491,
  "text" : "While googling for \u201EHipster Black Metal\u201C https:\/\/t.co\/OhkcFyFrCu https:\/\/t.co\/d1bSRtc1KL",
  "id" : 719799436654866432,
  "in_reply_to_status_id" : 719798278200639489,
  "created_at" : "2016-04-12 08:08:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "indices" : [ 3, 14 ],
      "id_str" : "312426579",
      "id" : 312426579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719798986291470336",
  "text" : "RT @mcclure111: Here, Eric S Raymond calls for tech cos to not hire me because a racist scifi author put my name on an enemies list. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5ZqCtqlYcP",
        "expanded_url" : "https:\/\/twitter.com\/tqbf\/status\/719621538257903616",
        "display_url" : "twitter.com\/tqbf\/status\/71\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719669906057379846",
    "text" : "Here, Eric S Raymond calls for tech cos to not hire me because a racist scifi author put my name on an enemies list. https:\/\/t.co\/5ZqCtqlYcP",
    "id" : 719669906057379846,
    "created_at" : "2016-04-11 23:34:11 +0000",
    "user" : {
      "name" : "mcc",
      "screen_name" : "mcclure111",
      "protected" : false,
      "id_str" : "312426579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852519442047225857\/juzc1JeR_normal.jpg",
      "id" : 312426579,
      "verified" : false
    }
  },
  "id" : 719798986291470336,
  "created_at" : "2016-04-12 08:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719798278200639489",
  "text" : "\u00ABScandinavian Journal of Pain\u00BB Can\u2019t help but feel that this would make an awesome name for an hipsteresk Black Metal band. Try grunting it.",
  "id" : 719798278200639489,
  "created_at" : "2016-04-12 08:04:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/bPAPXJhvIA",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/719553149372141568",
      "display_url" : "twitter.com\/Lobot\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719553596375887875",
  "text" : "Not that inaccurate a depiction of what still regularly happens when I have to work with Docker \uD83D\uDC33. https:\/\/t.co\/bPAPXJhvIA",
  "id" : 719553596375887875,
  "created_at" : "2016-04-11 15:52:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719552351271591937",
  "geo" : { },
  "id_str" : "719552679492644864",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai awesome! :)",
  "id" : 719552679492644864,
  "in_reply_to_status_id" : 719552351271591937,
  "created_at" : "2016-04-11 15:48:22 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719551544648142849",
  "geo" : { },
  "id_str" : "719552044156239872",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai the same I do all the time. :D I\u2019d give faceting on the y-axis a try. Should allow to easily see trend over time if one is there.",
  "id" : 719552044156239872,
  "in_reply_to_status_id" : 719551544648142849,
  "created_at" : "2016-04-11 15:45:50 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719550677865914368",
  "geo" : { },
  "id_str" : "719550838859956224",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai I saw the example plot. Any reason why you can\u2019t facet by factor?",
  "id" : 719550838859956224,
  "in_reply_to_status_id" : 719550677865914368,
  "created_at" : "2016-04-11 15:41:03 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719547973349347328",
  "geo" : { },
  "id_str" : "719550255549833216",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai yep, also: keeping the colorblind in mind as it\u2019s still not the default :(",
  "id" : 719550255549833216,
  "in_reply_to_status_id" : 719547973349347328,
  "created_at" : "2016-04-11 15:38:44 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 3, 14 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Veritas Genetics",
      "screen_name" : "VeritasGenetics",
      "indices" : [ 108, 124 ],
      "id_str" : "2387644962",
      "id" : 2387644962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wgs",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "precisionmedicine",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719549757996339200",
  "text" : "RT @BrianPardy: Take my $1000 genome, please!\nReleasing my genome to public domain.\n#wgs #precisionmedicine @VeritasGenetics\u2026 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Veritas Genetics",
        "screen_name" : "VeritasGenetics",
        "indices" : [ 92, 108 ],
        "id_str" : "2387644962",
        "id" : 2387644962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wgs",
        "indices" : [ 68, 72 ]
      }, {
        "text" : "precisionmedicine",
        "indices" : [ 73, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/ZQFVeACfim",
        "expanded_url" : "https:\/\/pardydba.wordpress.com\/2016\/04\/11\/take-my-1000-genome-please",
        "display_url" : "pardydba.wordpress.com\/2016\/04\/11\/tak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719544406299160576",
    "text" : "Take my $1000 genome, please!\nReleasing my genome to public domain.\n#wgs #precisionmedicine @VeritasGenetics\u2026 https:\/\/t.co\/ZQFVeACfim",
    "id" : 719544406299160576,
    "created_at" : "2016-04-11 15:15:29 +0000",
    "user" : {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "protected" : false,
      "id_str" : "611699110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918597507592093697\/WxKDoUkP_normal.jpg",
      "id" : 611699110,
      "verified" : false
    }
  },
  "id" : 719549757996339200,
  "created_at" : "2016-04-11 15:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719544406299160576",
  "geo" : { },
  "id_str" : "719549746256441348",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy very cool! :)",
  "id" : 719549746256441348,
  "in_reply_to_status_id" : 719544406299160576,
  "created_at" : "2016-04-11 15:36:42 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/usRbyWXdMp",
      "expanded_url" : "http:\/\/fusion.net\/story\/287592\/internet-mapping-glitch-kansas-farm\/",
      "display_url" : "fusion.net\/story\/287592\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719539082070781953",
  "text" : "The repercussions small design choices can have: The Hills have I.P.\u2019s https:\/\/t.co\/usRbyWXdMp",
  "id" : 719539082070781953,
  "created_at" : "2016-04-11 14:54:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719532302003519489",
  "geo" : { },
  "id_str" : "719532955710963713",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna if that\u2019d be the case I\u2019d still be a Dawkinite :p",
  "id" : 719532955710963713,
  "in_reply_to_status_id" : 719532302003519489,
  "created_at" : "2016-04-11 14:29:59 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/N6oAxXetf1",
      "expanded_url" : "http:\/\/www.allespaka.de\/",
      "display_url" : "allespaka.de"
    } ]
  },
  "in_reply_to_status_id_str" : "719531949459550208",
  "geo" : { },
  "id_str" : "719532770326945792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but I\u2019m sure you could advertise a project in https:\/\/t.co\/N6oAxXetf1 and have the money in no time :D",
  "id" : 719532770326945792,
  "in_reply_to_status_id" : 719531949459550208,
  "created_at" : "2016-04-11 14:29:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/06NS9uPzB5",
      "expanded_url" : "http:\/\/www.ensembl.org\/Vicugna_pacos\/Info\/Annotation",
      "display_url" : "ensembl.org\/Vicugna_pacos\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719531949459550208",
  "geo" : { },
  "id_str" : "719532170117820416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, the current alpaca genome sucks (2.5X cov :D) https:\/\/t.co\/06NS9uPzB5",
  "id" : 719532170117820416,
  "in_reply_to_status_id" : 719531949459550208,
  "created_at" : "2016-04-11 14:26:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ZwSAwbw1sP",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/719525724147838976",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719530713582858240",
  "text" : "maybe it\u2019s because I\u2019m starving right now, but first bite == best bite in many cases. https:\/\/t.co\/ZwSAwbw1sP",
  "id" : 719530713582858240,
  "created_at" : "2016-04-11 14:21:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719529713060806656",
  "geo" : { },
  "id_str" : "719529847291297792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer And on the other end you virtually can\u2019t fail to get the Alpaca genome crowdfunded I\u2019d bet.",
  "id" : 719529847291297792,
  "in_reply_to_status_id" : 719529713060806656,
  "created_at" : "2016-04-11 14:17:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719529033298411520",
  "geo" : { },
  "id_str" : "719529336370540544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer think it\u2019s a fun project, harder to get funding for in general &amp; only non-western project!",
  "id" : 719529336370540544,
  "in_reply_to_status_id" : 719529033298411520,
  "created_at" : "2016-04-11 14:15:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719527986500751360",
  "geo" : { },
  "id_str" : "719528110660710400",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I voted for Sedum. :)",
  "id" : 719528110660710400,
  "in_reply_to_status_id" : 719527986500751360,
  "created_at" : "2016-04-11 14:10:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/alFKBsGEyh",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/719524350349561857",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719527446534582273",
  "text" : "The votes should be corrected by taxon. distance to humans &amp; cuteness. Otherwise Alpaca is nearly guaranteed to win. https:\/\/t.co\/alFKBsGEyh",
  "id" : 719527446534582273,
  "created_at" : "2016-04-11 14:08:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gila monster",
      "screen_name" : "gilamonsterasu",
      "indices" : [ 0, 15 ],
      "id_str" : "4795913713",
      "id" : 4795913713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719524858770501632",
  "geo" : { },
  "id_str" : "719525800253464576",
  "in_reply_to_user_id" : 4795913713,
  "text" : "@gilamonsterasu you\u2019re even the first Metazoan genome I\u2019m supporting ;-)",
  "id" : 719525800253464576,
  "in_reply_to_status_id" : 719524858770501632,
  "created_at" : "2016-04-11 14:01:33 +0000",
  "in_reply_to_screen_name" : "gilamonsterasu",
  "in_reply_to_user_id_str" : "4795913713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Dunsworth",
      "screen_name" : "HollyDunsworth",
      "indices" : [ 0, 15 ],
      "id_str" : "551112681",
      "id" : 551112681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719522921371287552",
  "geo" : { },
  "id_str" : "719525045299777537",
  "in_reply_to_user_id" : 551112681,
  "text" : "@HollyDunsworth I could also imagine some weird feeling of keeping the tradition.",
  "id" : 719525045299777537,
  "in_reply_to_status_id" : 719522921371287552,
  "created_at" : "2016-04-11 13:58:33 +0000",
  "in_reply_to_screen_name" : "HollyDunsworth",
  "in_reply_to_user_id_str" : "551112681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Dtl2wjVTaf",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonk\/wp\/2016\/04\/08\/we-analyzed-the-names-of-almost-every-chinese-restaurant-in-america-this-is-what-we-learned\/",
      "display_url" : "washingtonpost.com\/news\/wonk\/wp\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719521546218422273",
  "text" : "Analyzing the names of almost every Chinese restaurant in America https:\/\/t.co\/Dtl2wjVTaf",
  "id" : 719521546218422273,
  "created_at" : "2016-04-11 13:44:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/i6Mh3Kx6hF",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/stop-that-bus\/",
      "display_url" : "99percentinvisible.org\/episode\/stop-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719520055030128640",
  "text" : "\u00ABIf you\u2019ve ever taken a bus to or from Tel Aviv\u2019s new central bus station, you\u2019ve never forgotten the experience.\u00BB \uD83D\uDE02 https:\/\/t.co\/i6Mh3Kx6hF",
  "id" : 719520055030128640,
  "created_at" : "2016-04-11 13:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/1wThdId3TB",
      "expanded_url" : "https:\/\/twitter.com\/gilamonsterasu\/status\/719512854190133249",
      "display_url" : "twitter.com\/gilamonsterasu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719515105944301569",
  "text" : "Crowdfunded genome sequencing of non-model organisms: #1 reason I\u2019m always broke. Goodbye all disposable income \uD83D\uDCB8 https:\/\/t.co\/1wThdId3TB",
  "id" : 719515105944301569,
  "created_at" : "2016-04-11 13:19:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Songkick",
      "screen_name" : "songkick",
      "indices" : [ 0, 9 ],
      "id_str" : "15352674",
      "id" : 15352674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/b1jAfXZL1M",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-fKE1oyr7YPw\/U4cdwX0IVmI\/AAAAAAAAT2U\/WUc8tDJJOz0\/s1600\/403.gif",
      "display_url" : "2.bp.blogspot.com\/-fKE1oyr7YPw\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719510464439459840",
  "geo" : { },
  "id_str" : "719512418834059264",
  "in_reply_to_user_id" : 15352674,
  "text" : "@songkick Oh nice. But still, that\u2019s manual labor, and we all know how it is with laziness! \uD83D\uDE02 https:\/\/t.co\/b1jAfXZL1M",
  "id" : 719512418834059264,
  "in_reply_to_status_id" : 719510464439459840,
  "created_at" : "2016-04-11 13:08:23 +0000",
  "in_reply_to_screen_name" : "songkick",
  "in_reply_to_user_id_str" : "15352674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 0, 7 ],
      "id_str" : "52021289",
      "id" : 52021289
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 8, 16 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/RFhhDd1IHt",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/jan\/16\/the-tube-at-a-standstill-why-tfl-stopped-people-walking-up-the-escalators",
      "display_url" : "theguardian.com\/uk-news\/2016\/j\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719495363980341248",
  "geo" : { },
  "id_str" : "719506441007206400",
  "in_reply_to_user_id" : 52021289,
  "text" : "@dridde @moeffju kommt auf die Umst\u00E4nde an, siehe https:\/\/t.co\/RFhhDd1IHt",
  "id" : 719506441007206400,
  "in_reply_to_status_id" : 719495363980341248,
  "created_at" : "2016-04-11 12:44:37 +0000",
  "in_reply_to_screen_name" : "dridde",
  "in_reply_to_user_id_str" : "52021289",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Dunsworth",
      "screen_name" : "HollyDunsworth",
      "indices" : [ 0, 15 ],
      "id_str" : "551112681",
      "id" : 551112681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719498791074840576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723345427875, 8.627619596570813 ]
  },
  "id_str" : "719501371209330689",
  "in_reply_to_user_id" : 551112681,
  "text" : "@HollyDunsworth that\u2019s a policy I really don\u2019t understand. I don\u2019t want to be protected.",
  "id" : 719501371209330689,
  "in_reply_to_status_id" : 719498791074840576,
  "created_at" : "2016-04-11 12:24:29 +0000",
  "in_reply_to_screen_name" : "HollyDunsworth",
  "in_reply_to_user_id_str" : "551112681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/TttnbBN4MT",
      "expanded_url" : "http:\/\/45.media.tumblr.com\/800d86de0228be6d736d7d7531033a10\/tumblr_mvz2vd9iSL1shhaneo1_500.gif",
      "display_url" : "45.media.tumblr.com\/800d86de0228be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719498048372621312",
  "text" : "Signing reviews, because it\u2019s the right thing to do. https:\/\/t.co\/TttnbBN4MT",
  "id" : 719498048372621312,
  "created_at" : "2016-04-11 12:11:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripIt",
      "screen_name" : "TripIt",
      "indices" : [ 34, 41 ],
      "id_str" : "10751252",
      "id" : 10751252
    }, {
      "name" : "Songkick",
      "screen_name" : "songkick",
      "indices" : [ 46, 55 ],
      "id_str" : "15352674",
      "id" : 15352674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719491409536008192",
  "text" : "What I\u2019d really like: Integrating @TripIt and @songkick, suggesting concerts of artists I like, in places I\u2019ll visit anyhow.",
  "id" : 719491409536008192,
  "created_at" : "2016-04-11 11:44:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/EwRDHtByES",
      "expanded_url" : "http:\/\/kernelmag.dailydot.com\/issue-sections\/features-issue-sections\/16352\/speed-reading-does-not-work\/",
      "display_url" : "kernelmag.dailydot.com\/issue-sections\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719456937897803776",
  "text" : "\u00ABSpeed-readers [\u2026] read what they want to see, which perhaps explains why the practice continues to thrive\u00BB https:\/\/t.co\/EwRDHtByES",
  "id" : 719456937897803776,
  "created_at" : "2016-04-11 09:27:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719454971587141632",
  "geo" : { },
  "id_str" : "719455868694224896",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson btw: the science web could need some new posts!",
  "id" : 719455868694224896,
  "in_reply_to_status_id" : 719454971587141632,
  "created_at" : "2016-04-11 09:23:40 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/pbS0ykqX27",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/718851041102573568",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719453750017044480",
  "text" : "Don't tell them biologists, how else shall we get the cheapest co-authorships ever?   https:\/\/t.co\/pbS0ykqX27",
  "id" : 719453750017044480,
  "created_at" : "2016-04-11 09:15:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/Av1UdtRVrE",
      "expanded_url" : "http:\/\/cibiv.github.io\/NextGenMap\/",
      "display_url" : "cibiv.github.io\/NextGenMap\/"
    } ]
  },
  "in_reply_to_status_id_str" : "719437749623783425",
  "geo" : { },
  "id_str" : "719438275409231872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer https:\/\/t.co\/Av1UdtRVrE (COI: my PI was somewhat involved w\/ it) And: I have mixed experiences using it. :D",
  "id" : 719438275409231872,
  "in_reply_to_status_id" : 719437749623783425,
  "created_at" : "2016-04-11 08:13:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719434677585444864",
  "geo" : { },
  "id_str" : "719437064060710912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer have you tried nextgenmap?",
  "id" : 719437064060710912,
  "in_reply_to_status_id" : 719434677585444864,
  "created_at" : "2016-04-11 08:08:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719432258642251776",
  "geo" : { },
  "id_str" : "719433501892874240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer otherwise if blastx would work too, you could use diamond for ++++ speed. :)",
  "id" : 719433501892874240,
  "in_reply_to_status_id" : 719432258642251776,
  "created_at" : "2016-04-11 07:54:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719432258642251776",
  "geo" : { },
  "id_str" : "719433311047806976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer depends on similarity, could try a relaxed mapper if similar enough?",
  "id" : 719433311047806976,
  "in_reply_to_status_id" : 719432258642251776,
  "created_at" : "2016-04-11 07:54:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/lPWSsZZvoq",
      "expanded_url" : "http:\/\/www.franceinter.fr\/sites\/default\/files\/imagecache\/scald_image_max_size\/2012\/01\/24\/270055\/images\/Izno%20et%20bulle%20couv%20album%2050%20ans.jpg",
      "display_url" : "franceinter.fr\/sites\/default\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719427920020770816",
  "geo" : { },
  "id_str" : "719428395331883008",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon someone should do an academic remake https:\/\/t.co\/lPWSsZZvoq",
  "id" : 719428395331883008,
  "in_reply_to_status_id" : 719427920020770816,
  "created_at" : "2016-04-11 07:34:30 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719424911379472384",
  "geo" : { },
  "id_str" : "719427502482067456",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yep, because dictatorships are very cool, as long as you\u2019re the dictator.",
  "id" : 719427502482067456,
  "in_reply_to_status_id" : 719424911379472384,
  "created_at" : "2016-04-11 07:30:57 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719424221651316736",
  "geo" : { },
  "id_str" : "719424489113657344",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon people often make fun of my \u201Eprofessorial lifestyle\u201C. Somehow I feel I got all the drawbacks with none of the benefits ;)",
  "id" : 719424489113657344,
  "in_reply_to_status_id" : 719424221651316736,
  "created_at" : "2016-04-11 07:18:59 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719294917714046977",
  "geo" : { },
  "id_str" : "719423702564265984",
  "in_reply_to_user_id" : 14286491,
  "text" : "From inbox zero to inbox 127 over the course of just weekend of not tending to it.",
  "id" : 719423702564265984,
  "in_reply_to_status_id" : 719294917714046977,
  "created_at" : "2016-04-11 07:15:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "indices" : [ 3, 14 ],
      "id_str" : "33773592",
      "id" : 33773592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719310836372795392",
  "text" : "RT @AstroKatie: Sciencey Twitter account: Look at this awesome thing someone made! So cool!\nMe: Who made it?\nSciencey Twitter account: Lol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719291745305894913",
    "text" : "Sciencey Twitter account: Look at this awesome thing someone made! So cool!\nMe: Who made it?\nSciencey Twitter account: Lol who cares?\nMe: \uD83D\uDE20",
    "id" : 719291745305894913,
    "created_at" : "2016-04-10 22:31:30 +0000",
    "user" : {
      "name" : "Katie Mack",
      "screen_name" : "AstroKatie",
      "protected" : false,
      "id_str" : "33773592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2818477708\/0ef050189a11bb7f9cf56306f5d171bf_normal.png",
      "id" : 33773592,
      "verified" : true
    }
  },
  "id" : 719310836372795392,
  "created_at" : "2016-04-10 23:47:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399189300376, 8.753464447637214 ]
  },
  "id_str" : "719294917714046977",
  "text" : "When you have REM rebound w\/o boarding any long haul recently &amp; your nightmares feature yourself successively managing your calendar \uD83E\uDD14",
  "id" : 719294917714046977,
  "created_at" : "2016-04-10 22:44:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928070908861, 8.58776028466428 ]
  },
  "id_str" : "719152517565820928",
  "text" : "\u00ABNo worries, it\u2019s a sign of affection if I want to put electrodes onto you.\u00BB",
  "id" : 719152517565820928,
  "created_at" : "2016-04-10 13:18:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718498151230005249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36202421136886, 8.597751930364034 ]
  },
  "id_str" : "718500023831556096",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn that would be awesome!",
  "id" : 718500023831556096,
  "in_reply_to_status_id" : 718498151230005249,
  "created_at" : "2016-04-08 18:05:29 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/w1GQdfEwHJ",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/uzZh2psw4J3ri\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/uzZh2psw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718421147331727360",
  "text" : "when you\u2019re not sure whether you see meaningful results or just artefacts based on rubbish draft genome assemblies\u2026 https:\/\/t.co\/w1GQdfEwHJ",
  "id" : 718421147331727360,
  "created_at" : "2016-04-08 12:52:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/MV9wQRLezc",
      "expanded_url" : "http:\/\/grouplens.org\/blog\/investigating-the-potential-for-miscommunication-using-emoji\/",
      "display_url" : "grouplens.org\/blog\/investiga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718413979744342016",
  "text" : "Investigating the Potential for Miscommunication Using Emoji: \uD83D\uDE0D vs \uD83D\uDE06 https:\/\/t.co\/MV9wQRLezc",
  "id" : 718413979744342016,
  "created_at" : "2016-04-08 12:23:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718405684761649152",
  "geo" : { },
  "id_str" : "718406938502041600",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye nice, looking forward to see the results!",
  "id" : 718406938502041600,
  "in_reply_to_status_id" : 718405684761649152,
  "created_at" : "2016-04-08 11:55:36 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/x4NFgahyfK",
      "expanded_url" : "https:\/\/medium.com\/@pdehaye\/how-did-facebook-try-to-manipulate-my-emotions-i-will-find-out-76d0d682385e",
      "display_url" : "medium.com\/@pdehaye\/how-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718406829974364160",
  "text" : "RT @podehaye: How did Facebook manipulate my emotions? I will find out. https:\/\/t.co\/x4NFgahyfK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/x4NFgahyfK",
        "expanded_url" : "https:\/\/medium.com\/@pdehaye\/how-did-facebook-try-to-manipulate-my-emotions-i-will-find-out-76d0d682385e",
        "display_url" : "medium.com\/@pdehaye\/how-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718405684761649152",
    "text" : "How did Facebook manipulate my emotions? I will find out. https:\/\/t.co\/x4NFgahyfK",
    "id" : 718405684761649152,
    "created_at" : "2016-04-08 11:50:37 +0000",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 718406829974364160,
  "created_at" : "2016-04-08 11:55:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wandering Gio",
      "screen_name" : "wanderingGio",
      "indices" : [ 3, 16 ],
      "id_str" : "1053548070",
      "id" : 1053548070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Thh03ROUzI",
      "expanded_url" : "http:\/\/buff.ly\/1qxxp6T",
      "display_url" : "buff.ly\/1qxxp6T"
    } ]
  },
  "geo" : { },
  "id_str" : "718399173322809344",
  "text" : "RT @wanderingGio: The Largest Analysis of Film Dialogue by Gender, Ever https:\/\/t.co\/Thh03ROUzI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Thh03ROUzI",
        "expanded_url" : "http:\/\/buff.ly\/1qxxp6T",
        "display_url" : "buff.ly\/1qxxp6T"
      } ]
    },
    "geo" : { },
    "id_str" : "718357206207479808",
    "text" : "The Largest Analysis of Film Dialogue by Gender, Ever https:\/\/t.co\/Thh03ROUzI",
    "id" : 718357206207479808,
    "created_at" : "2016-04-08 08:37:59 +0000",
    "user" : {
      "name" : "Wandering Gio",
      "screen_name" : "wanderingGio",
      "protected" : false,
      "id_str" : "1053548070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684422740795887616\/PGmfBi3X_normal.jpg",
      "id" : 1053548070,
      "verified" : false
    }
  },
  "id" : 718399173322809344,
  "created_at" : "2016-04-08 11:24:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/7GdKVQkaNL",
      "expanded_url" : "https:\/\/twitter.com\/ItsNeuronal\/status\/718220339357097985",
      "display_url" : "twitter.com\/ItsNeuronal\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718397219091648512",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess fitting to our brief discussion of PCA lately. :-) https:\/\/t.co\/7GdKVQkaNL",
  "id" : 718397219091648512,
  "created_at" : "2016-04-08 11:16:58 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718379397477244929",
  "geo" : { },
  "id_str" : "718393779795992577",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot a psych evaluation that boils down to \u201Eswipe left for no drama, swipe right for drama\u201C. Myers &amp; Briggs approve!",
  "id" : 718393779795992577,
  "in_reply_to_status_id" : 718379397477244929,
  "created_at" : "2016-04-08 11:03:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/dj0DrHLOnH",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/how-two-grad-students-uncovered-michael-lacour-fraud-and-a-way-to-change-opinions-on-transgender-rights\/",
      "display_url" : "fivethirtyeight.com\/features\/how-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718376689173151744",
  "text" : "Awesome follow-up on LaCour\u2019s fraud: Uncovering An Apparent Fraud &amp; A Way To Change Opinions On Transgender Rights https:\/\/t.co\/dj0DrHLOnH",
  "id" : 718376689173151744,
  "created_at" : "2016-04-08 09:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/j4wW9MJMPw",
      "expanded_url" : "https:\/\/twitter.com\/repositiveio\/status\/718372066903388160",
      "display_url" : "twitter.com\/repositiveio\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718372617208639488",
  "text" : "I\u2019ll also be giving a talk along the lines of data by the people, for the people at #FORCE2016: https:\/\/t.co\/j4wW9MJMPw",
  "id" : 718372617208639488,
  "created_at" : "2016-04-08 09:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718365592445706240",
  "geo" : { },
  "id_str" : "718370739674619904",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn hope we\u2019ll manage to go for drinks at some point again. I\u2019ll need some excuse to come to Toronto :D",
  "id" : 718370739674619904,
  "in_reply_to_status_id" : 718365592445706240,
  "created_at" : "2016-04-08 09:31:45 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718363333800370177",
  "geo" : { },
  "id_str" : "718364417973428224",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn thanks \uD83D\uDE0D and fwiw: this friendship is one of the best outcomes of all the weird open-data things :D",
  "id" : 718364417973428224,
  "in_reply_to_status_id" : 718363333800370177,
  "created_at" : "2016-04-08 09:06:38 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/MYhOXAhGv5",
      "expanded_url" : "http:\/\/www.vocativ.com\/305430\/inside-the-world-of-witches-who-practice-bdsm\/",
      "display_url" : "vocativ.com\/305430\/inside-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718359377997086722",
  "text" : "Inside The World Of Witches Who Practice BDSM https:\/\/t.co\/MYhOXAhGv5",
  "id" : 718359377997086722,
  "created_at" : "2016-04-08 08:46:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/jPQh5dW8Ty",
      "expanded_url" : "https:\/\/twitter.com\/notSoJunkDNA\/status\/718162271462146048",
      "display_url" : "twitter.com\/notSoJunkDNA\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718353636909309953",
  "text" : "Even before opening the link I thought \u201Esounds like Deepak Chopra\u2019s bullshit\u201C, and I wasn\u2019t disappointed\u2026 https:\/\/t.co\/jPQh5dW8Ty",
  "id" : 718353636909309953,
  "created_at" : "2016-04-08 08:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RIKsA0RLBJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/718350441982070784",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "718350441982070784",
  "geo" : { },
  "id_str" : "718350652615827456",
  "in_reply_to_user_id" : 14286491,
  "text" : "And linked inside is an article w\/ the headline \u00ABYour Doctor Does Not Give a Crap About Your Fitness Tracker Data\u00BB \uD83D\uDE02 https:\/\/t.co\/RIKsA0RLBJ",
  "id" : 718350652615827456,
  "in_reply_to_status_id" : 718350441982070784,
  "created_at" : "2016-04-08 08:11:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ZSCa35PFpa",
      "expanded_url" : "http:\/\/gizmodo.com\/this-dudes-fitness-tracker-may-have-just-saved-his-life-1769604325?utm_campaign=socialflow_gizmodo_twitter&utm_source=gizmodo_twitter&utm_medium=socialflow",
      "display_url" : "gizmodo.com\/this-dudes-fit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718350441982070784",
  "text" : "\u00ABThis Dude's Fitness Tracker May Have Just Saved His Life\u00BB And how often is such data making it worse? https:\/\/t.co\/ZSCa35PFpa",
  "id" : 718350441982070784,
  "created_at" : "2016-04-08 08:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\"if true\"",
      "screen_name" : "SaraMorrison",
      "indices" : [ 3, 16 ],
      "id_str" : "17533518",
      "id" : 17533518
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SaraMorrison\/status\/715680088432504833\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/zZGtxQsO1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce6bP36WQAA516h.jpg",
      "id_str" : "715680087807508480",
      "id" : 715680087807508480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce6bP36WQAA516h.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 307
      } ],
      "display_url" : "pic.twitter.com\/zZGtxQsO1z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718228949638258689",
  "text" : "RT @SaraMorrison: when ur an outspoken woman on the internet looking at ur mentions https:\/\/t.co\/zZGtxQsO1z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SaraMorrison\/status\/715680088432504833\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/zZGtxQsO1z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce6bP36WQAA516h.jpg",
        "id_str" : "715680087807508480",
        "id" : 715680087807508480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce6bP36WQAA516h.jpg",
        "sizes" : [ {
          "h" : 243,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 307
        } ],
        "display_url" : "pic.twitter.com\/zZGtxQsO1z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "715678787187449857",
    "geo" : { },
    "id_str" : "715680088432504833",
    "in_reply_to_user_id" : 17533518,
    "text" : "when ur an outspoken woman on the internet looking at ur mentions https:\/\/t.co\/zZGtxQsO1z",
    "id" : 715680088432504833,
    "in_reply_to_status_id" : 715678787187449857,
    "created_at" : "2016-03-31 23:20:04 +0000",
    "in_reply_to_screen_name" : "SaraMorrison",
    "in_reply_to_user_id_str" : "17533518",
    "user" : {
      "name" : "\"if true\"",
      "screen_name" : "SaraMorrison",
      "protected" : false,
      "id_str" : "17533518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839299922834915334\/2iAyQTPZ_normal.jpg",
      "id" : 17533518,
      "verified" : true
    }
  },
  "id" : 718228949638258689,
  "created_at" : "2016-04-08 00:08:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "hullodave",
      "indices" : [ 3, 13 ],
      "id_str" : "239409512",
      "id" : 239409512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718176593554903040",
  "text" : "RT @hullodave: I haven't done a joke about the Gambler's Fallacy for a while, so maybe I'll do that next.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718141455458549765",
    "text" : "I haven't done a joke about the Gambler's Fallacy for a while, so maybe I'll do that next.",
    "id" : 718141455458549765,
    "created_at" : "2016-04-07 18:20:40 +0000",
    "user" : {
      "name" : "Dave",
      "screen_name" : "hullodave",
      "protected" : false,
      "id_str" : "239409512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423563658942099457\/HyHeWcnT_normal.jpeg",
      "id" : 239409512,
      "verified" : false
    }
  },
  "id" : 718176593554903040,
  "created_at" : "2016-04-07 20:40:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717998163131502592",
  "geo" : { },
  "id_str" : "717998441889206272",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad I didn\u2019t even know screen provided such a thing!",
  "id" : 717998441889206272,
  "in_reply_to_status_id" : 717998163131502592,
  "created_at" : "2016-04-07 08:52:22 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/sCxs9gCSwU",
      "expanded_url" : "https:\/\/cosmolearning.org\/images_dir\/education\/photos\/1069-thumbnail-w700.jpg",
      "display_url" : "cosmolearning.org\/images_dir\/edu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717992309669961729",
  "geo" : { },
  "id_str" : "717996093141815296",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/sCxs9gCSwU",
  "id" : 717996093141815296,
  "in_reply_to_status_id" : 717992309669961729,
  "created_at" : "2016-04-07 08:43:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/HUdVczDzIu",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/04\/05\/029926",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717989827405328384",
  "text" : "Recycler: an algorithm for detecting plasmids from de novo assembly graphs https:\/\/t.co\/HUdVczDzIu",
  "id" : 717989827405328384,
  "created_at" : "2016-04-07 08:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/UapkHYDos4",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/717987977847304193",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717988919112032256",
  "text" : "\uD83D\uDE12 is all I have to say when it comes to that \u201Eeasy\u201C how-to. https:\/\/t.co\/UapkHYDos4",
  "id" : 717988919112032256,
  "created_at" : "2016-04-07 08:14:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717985979970273280",
  "geo" : { },
  "id_str" : "717986533576425472",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc i think there are plenty on that. :)",
  "id" : 717986533576425472,
  "in_reply_to_status_id" : 717985979970273280,
  "created_at" : "2016-04-07 08:05:03 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/VEFwzMdkpI",
      "expanded_url" : "http:\/\/boingboing.net\/2016\/04\/06\/dog-barks-376572715308-time.html",
      "display_url" : "boingboing.net\/2016\/04\/06\/dog\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717984255566036993",
  "geo" : { },
  "id_str" : "717984750053552128",
  "in_reply_to_user_id" : 14286491,
  "text" : "related: dog barks 376,572,715,308 times https:\/\/t.co\/VEFwzMdkpI",
  "id" : 717984750053552128,
  "in_reply_to_status_id" : 717984255566036993,
  "created_at" : "2016-04-07 07:57:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/atE5rIuAWo",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/inkfish\/2016\/04\/06\/words-we-say-to-dogs-and-other-things-scientists-learned-watching-people-play-with-pets\/",
      "display_url" : "blogs.discovermagazine.com\/inkfish\/2016\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717984255566036993",
  "text" : "my kind of linguistics: the words we say to dogs https:\/\/t.co\/atE5rIuAWo",
  "id" : 717984255566036993,
  "created_at" : "2016-04-07 07:56:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717968941029588993",
  "geo" : { },
  "id_str" : "717976070536962048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good luck nevertheless!",
  "id" : 717976070536962048,
  "in_reply_to_status_id" : 717968941029588993,
  "created_at" : "2016-04-07 07:23:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717833704182165505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399553735856, 8.753412783902835 ]
  },
  "id_str" : "717947569989689344",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski and I'm somewhat sure that the east\/west dimensions are also off (or it's a very weird projection).",
  "id" : 717947569989689344,
  "in_reply_to_status_id" : 717833704182165505,
  "created_at" : "2016-04-07 05:30:14 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Vaughan",
      "screen_name" : "agvaughan",
      "indices" : [ 0, 10 ],
      "id_str" : "35239457",
      "id" : 35239457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717728542809829377",
  "geo" : { },
  "id_str" : "717730605568552964",
  "in_reply_to_user_id" : 35239457,
  "text" : "@agvaughan I think it could even be unbalanced as it basically only displays the first punctuation symbols :)",
  "id" : 717730605568552964,
  "in_reply_to_status_id" : 717728542809829377,
  "created_at" : "2016-04-06 15:08:05 +0000",
  "in_reply_to_screen_name" : "agvaughan",
  "in_reply_to_user_id_str" : "35239457",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    }, {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 14, 24 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 25, 37 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Alex Vaughan",
      "screen_name" : "agvaughan",
      "indices" : [ 38, 48 ],
      "id_str" : "35239457",
      "id" : 35239457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717719066526539776",
  "geo" : { },
  "id_str" : "717722727663210496",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology @abellogin @rosettacode @agvaughan I never gave it a try. But maybe I should.",
  "id" : 717722727663210496,
  "in_reply_to_status_id" : 717719066526539776,
  "created_at" : "2016-04-06 14:36:47 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    }, {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 14, 24 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 25, 37 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Alex Vaughan",
      "screen_name" : "agvaughan",
      "indices" : [ 38, 48 ],
      "id_str" : "35239457",
      "id" : 35239457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717714979294720004",
  "geo" : { },
  "id_str" : "717715902863638529",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology @abellogin @rosettacode @agvaughan at least if you are really into parentheses! (is parenthophilia a thing?)",
  "id" : 717715902863638529,
  "in_reply_to_status_id" : 717714979294720004,
  "created_at" : "2016-04-06 14:09:40 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    }, {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 14, 24 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 25, 37 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Alex Vaughan",
      "screen_name" : "agvaughan",
      "indices" : [ 75, 85 ],
      "id_str" : "35239457",
      "id" : 35239457
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/717714600817475584\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/eWQHfSQa24",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfXVn5AWwAA2xwB.jpg",
      "id_str" : "717714596929388544",
      "id" : 717714596929388544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfXVn5AWwAA2xwB.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eWQHfSQa24"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717714237582393344",
  "geo" : { },
  "id_str" : "717714600817475584",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology @abellogin @rosettacode no problem, and here you go w\/ Lisp. @agvaughan https:\/\/t.co\/eWQHfSQa24",
  "id" : 717714600817475584,
  "in_reply_to_status_id" : 717714237582393344,
  "created_at" : "2016-04-06 14:04:29 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 0, 13 ],
      "id_str" : "636023721",
      "id" : 636023721
    }, {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 14, 24 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 25, 37 ],
      "id_str" : "136689390",
      "id" : 136689390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/j57syg55Wg",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/703018961265254401?ref_src=twsrc%5Etfw",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717713971072073729",
  "geo" : { },
  "id_str" : "717714187858927616",
  "in_reply_to_user_id" : 636023721,
  "text" : "@neuroecology @abellogin @rosettacode I did scheme in the first post: https:\/\/t.co\/j57syg55Wg :)",
  "id" : 717714187858927616,
  "in_reply_to_status_id" : 717713971072073729,
  "created_at" : "2016-04-06 14:02:51 +0000",
  "in_reply_to_screen_name" : "neuroecology",
  "in_reply_to_user_id_str" : "636023721",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 0, 10 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 11, 23 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 24, 37 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717711365222301696",
  "geo" : { },
  "id_str" : "717711582923517952",
  "in_reply_to_user_id" : 147949965,
  "text" : "@abellogin @rosettacode @neuroecology let me know if you have some favorites you would like to see added. Went for the most mainstream now",
  "id" : 717711582923517952,
  "in_reply_to_status_id" : 717711365222301696,
  "created_at" : "2016-04-06 13:52:30 +0000",
  "in_reply_to_screen_name" : "abellogin",
  "in_reply_to_user_id_str" : "147949965",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/lje1B53Squ",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/E2USislQIlsfm\/200.gif",
      "display_url" : "media4.giphy.com\/media\/E2USislQ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717705419079217153",
  "geo" : { },
  "id_str" : "717706186540335104",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 oh noes :( https:\/\/t.co\/lje1B53Squ",
  "id" : 717706186540335104,
  "in_reply_to_status_id" : 717705419079217153,
  "created_at" : "2016-04-06 13:31:03 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Brock",
      "screen_name" : "DrBrocktagon",
      "indices" : [ 3, 16 ],
      "id_str" : "172317565",
      "id" : 172317565
    }, {
      "name" : "Rebecca Gelding",
      "screen_name" : "RebeccaGelding",
      "indices" : [ 109, 124 ],
      "id_str" : "499636235",
      "id" : 499636235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/n7GtSuJEOh",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kNz8mfFa7nc",
      "display_url" : "youtube.com\/watch?v=kNz8mf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717701336838578176",
  "text" : "RT @DrBrocktagon: Oh my word. All about the Bayes - a musical statistical parody https:\/\/t.co\/n7GtSuJEOh via @RebeccaGelding",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rebecca Gelding",
        "screen_name" : "RebeccaGelding",
        "indices" : [ 91, 106 ],
        "id_str" : "499636235",
        "id" : 499636235
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/n7GtSuJEOh",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=kNz8mfFa7nc",
        "display_url" : "youtube.com\/watch?v=kNz8mf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717675340261228545",
    "text" : "Oh my word. All about the Bayes - a musical statistical parody https:\/\/t.co\/n7GtSuJEOh via @RebeccaGelding",
    "id" : 717675340261228545,
    "created_at" : "2016-04-06 11:28:29 +0000",
    "user" : {
      "name" : "Jon Brock",
      "screen_name" : "DrBrocktagon",
      "protected" : false,
      "id_str" : "172317565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/898077753722916865\/ybfKFxf0_normal.jpg",
      "id" : 172317565,
      "verified" : false
    }
  },
  "id" : 717701336838578176,
  "created_at" : "2016-04-06 13:11:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 28, 38 ],
      "id_str" : "147949965",
      "id" : 147949965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/fxjPeFyL3y",
      "expanded_url" : "http:\/\/ruleofthirds.de\/visualizing-code-part2\/",
      "display_url" : "ruleofthirds.de\/visualizing-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717697973711474688",
  "text" : "Following the suggestion of @abellogin I extended my programming language visualization a bit: https:\/\/t.co\/fxjPeFyL3y",
  "id" : 717697973711474688,
  "created_at" : "2016-04-06 12:58:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Bellogin",
      "screen_name" : "abellogin",
      "indices" : [ 0, 10 ],
      "id_str" : "147949965",
      "id" : 147949965
    }, {
      "name" : "Rosetta Code",
      "screen_name" : "rosettacode",
      "indices" : [ 11, 23 ],
      "id_str" : "136689390",
      "id" : 136689390
    }, {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 24, 37 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fxjPeFyL3y",
      "expanded_url" : "http:\/\/ruleofthirds.de\/visualizing-code-part2\/",
      "display_url" : "ruleofthirds.de\/visualizing-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "712971774716149760",
  "geo" : { },
  "id_str" : "717697839435018240",
  "in_reply_to_user_id" : 147949965,
  "text" : "@abellogin @rosettacode @neuroecology sorry, took me a while, but here are some: https:\/\/t.co\/fxjPeFyL3y :)",
  "id" : 717697839435018240,
  "in_reply_to_status_id" : 712971774716149760,
  "created_at" : "2016-04-06 12:57:53 +0000",
  "in_reply_to_screen_name" : "abellogin",
  "in_reply_to_user_id_str" : "147949965",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/eXiVrfuh4d",
      "expanded_url" : "https:\/\/twitter.com\/jtkantor\/status\/717411774727852032",
      "display_url" : "twitter.com\/jtkantor\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717679738941272064",
  "text" : "things that would make me visit a physical library for a change. https:\/\/t.co\/eXiVrfuh4d",
  "id" : 717679738941272064,
  "created_at" : "2016-04-06 11:45:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 0, 10 ],
      "id_str" : "29082973",
      "id" : 29082973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717659626062352384",
  "geo" : { },
  "id_str" : "717679267895721984",
  "in_reply_to_user_id" : 29082973,
  "text" : "@ballaschk danke, ich leite es mal weiter :)",
  "id" : 717679267895721984,
  "in_reply_to_status_id" : 717659626062352384,
  "created_at" : "2016-04-06 11:44:05 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/717651787608678400\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/CS8qjrB1Ew",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfWcfxJUUAA9W9V.jpg",
      "id_str" : "717651785217757184",
      "id" : 717651785217757184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfWcfxJUUAA9W9V.jpg",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 772
      } ],
      "display_url" : "pic.twitter.com\/CS8qjrB1Ew"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717651787608678400",
  "text" : "having too much fun watching the xkcd garden grow, observing a turtle riding a deer. https:\/\/t.co\/CS8qjrB1Ew",
  "id" : 717651787608678400,
  "created_at" : "2016-04-06 09:54:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 102, 116 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Ibc2Ba5QiN",
      "expanded_url" : "http:\/\/www.theguardian.com\/media\/2016\/apr\/06\/nine-year-old-us-reporter-defiant-after-critics-say-go-back-to-playing-with-dolls",
      "display_url" : "theguardian.com\/media\/2016\/apr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717634042976460800",
  "text" : "the sorry state of journalism at large, where people have to attack a 9 y\/o reporter for her work \/HT @marcelsalathe https:\/\/t.co\/Ibc2Ba5QiN",
  "id" : 717634042976460800,
  "created_at" : "2016-04-06 08:44:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717632762187005952",
  "geo" : { },
  "id_str" : "717632923114020865",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot taser-induced planking",
  "id" : 717632923114020865,
  "in_reply_to_status_id" : 717632762187005952,
  "created_at" : "2016-04-06 08:39:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaa",
      "screen_name" : "katrinfaensen",
      "indices" : [ 0, 14 ],
      "id_str" : "306281663",
      "id" : 306281663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Q7wGeqWDw8",
      "expanded_url" : "http:\/\/edition.cnn.com\/2015\/01\/30\/asia\/china-dragon-dinosaur\/",
      "display_url" : "edition.cnn.com\/2015\/01\/30\/asi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717629965794209792",
  "geo" : { },
  "id_str" : "717630248838365184",
  "in_reply_to_user_id" : 306281663,
  "text" : "@katrinfaensen well\u2026 https:\/\/t.co\/Q7wGeqWDw8 ;)",
  "id" : 717630248838365184,
  "in_reply_to_status_id" : 717629965794209792,
  "created_at" : "2016-04-06 08:29:18 +0000",
  "in_reply_to_screen_name" : "katrinfaensen",
  "in_reply_to_user_id_str" : "306281663",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/J12xh7VnFT",
      "expanded_url" : "http:\/\/imgur.com\/f2HlJMl",
      "display_url" : "imgur.com\/f2HlJMl"
    } ]
  },
  "in_reply_to_status_id_str" : "717626137468387328",
  "geo" : { },
  "id_str" : "717629954607984640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/J12xh7VnFT ?",
  "id" : 717629954607984640,
  "in_reply_to_status_id" : 717626137468387328,
  "created_at" : "2016-04-06 08:28:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SXcCWxM2PJ",
      "expanded_url" : "http:\/\/www.nature.com\/news\/did-humans-drive-hobbit-species-to-extinction-1.19651",
      "display_url" : "nature.com\/news\/did-human\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717629117315870720",
  "text" : "Totally missed the news that we might have killed the hobbits. Well done, humans! https:\/\/t.co\/SXcCWxM2PJ",
  "id" : 717629117315870720,
  "created_at" : "2016-04-06 08:24:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Hvw3p13Wke",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4071",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717627699183947776",
  "text" : "when your pattern recognition fails at the worst time https:\/\/t.co\/Hvw3p13Wke",
  "id" : 717627699183947776,
  "created_at" : "2016-04-06 08:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717623396381515777",
  "geo" : { },
  "id_str" : "717626152412700672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the only plants i\u2019m working with are algae, and those are weirdos in any case, no DB really works for them.",
  "id" : 717626152412700672,
  "in_reply_to_status_id" : 717623396381515777,
  "created_at" : "2016-04-06 08:13:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717622290024804353",
  "geo" : { },
  "id_str" : "717622600076238848",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer if you\u2019ve no RNAseq I\u2019d do the Maker2 pipeline. Try getting the protein set of closely related species though.",
  "id" : 717622600076238848,
  "in_reply_to_status_id" : 717622290024804353,
  "created_at" : "2016-04-06 07:58:55 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/92J41v2pqz",
      "expanded_url" : "http:\/\/thebloodvoyage.tumblr.com\/post\/142270309011\/their-extinction-has-probably-been-caused-by-a",
      "display_url" : "thebloodvoyage.tumblr.com\/post\/142270309\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717622425794510848",
  "text" : "\u00ABTheir extinction has probably been caused by a shifting gallery of townspeople\u00BB \uD83D\uDE02 https:\/\/t.co\/92J41v2pqz",
  "id" : 717622425794510848,
  "created_at" : "2016-04-06 07:58:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717621475319029761",
  "geo" : { },
  "id_str" : "717621770103169024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just running the general EUK set for BUSCO instead? CEGMA gave irreproducible results on my end.",
  "id" : 717621770103169024,
  "in_reply_to_status_id" : 717621475319029761,
  "created_at" : "2016-04-06 07:55:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 68, 81 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/EGb2OUrEiD",
      "expanded_url" : "https:\/\/github.com\/sujaikumar\/assemblage\/blob\/master\/README-annotation.md",
      "display_url" : "github.com\/sujaikumar\/ass\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717620799557935104",
  "geo" : { },
  "id_str" : "717621152282238976",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Still Maker2 i\u2019d say. See also https:\/\/t.co\/EGb2OUrEiD \/HT @PhilippBayer",
  "id" : 717621152282238976,
  "in_reply_to_status_id" : 717620799557935104,
  "created_at" : "2016-04-06 07:53:10 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717597099240456192",
  "geo" : { },
  "id_str" : "717617038559166464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer any reason why you don\u2019t just stop using CEGMA? :D",
  "id" : 717617038559166464,
  "in_reply_to_status_id" : 717597099240456192,
  "created_at" : "2016-04-06 07:36:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717477235951796224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398574817813, 8.753466011949952 ]
  },
  "id_str" : "717480288721481728",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC duly noted :)",
  "id" : 717480288721481728,
  "in_reply_to_status_id" : 717477235951796224,
  "created_at" : "2016-04-05 22:33:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 10, 21 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717476543153508352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391059165106, 8.753519650470375 ]
  },
  "id_str" : "717476764054896640",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @HopeJahren that\u2019s the spirit. Happy early(?) birthday.",
  "id" : 717476764054896640,
  "in_reply_to_status_id" : 717476543153508352,
  "created_at" : "2016-04-05 22:19:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 10, 21 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717471946494066689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139913900663, 8.753462026013395 ]
  },
  "id_str" : "717472290661916672",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @HopeJahren I\u2019m pretty sure you\u2019ll love it, judging from my prior experience with your taste in books :)",
  "id" : 717472290661916672,
  "in_reply_to_status_id" : 717471946494066689,
  "created_at" : "2016-04-05 22:01:38 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 60, 71 ],
      "id_str" : "322658299",
      "id" : 322658299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399053668036, 8.753462206629656 ]
  },
  "id_str" : "717412962387017733",
  "text" : "Now that it\u2019s out as an ebook, I just read the first 20% of @HopeJahren\u2019s amazing Lab Girl while cycling in the gym. Was really hard to stop",
  "id" : 717412962387017733,
  "created_at" : "2016-04-05 18:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717375020708724738",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1730471943041, 8.627912281089115 ]
  },
  "id_str" : "717375469021237248",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yes, but not what I\u2019m looking for. Was from a rather recent paper. Like last year maybe.",
  "id" : 717375469021237248,
  "in_reply_to_status_id" : 717375020708724738,
  "created_at" : "2016-04-05 15:36:54 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717370513333456896",
  "geo" : { },
  "id_str" : "717372144238338050",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy but can\u2019t find the image :(",
  "id" : 717372144238338050,
  "in_reply_to_status_id" : 717370513333456896,
  "created_at" : "2016-04-05 15:23:41 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717370513333456896",
  "geo" : { },
  "id_str" : "717372105696931841",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I remember seeing something along those lines (importance of looking at taxonomy for doing correlations) on Twitter a while back.",
  "id" : 717372105696931841,
  "in_reply_to_status_id" : 717370513333456896,
  "created_at" : "2016-04-05 15:23:32 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/2SiLBQ8F2F",
      "expanded_url" : "http:\/\/www.pepsplace.org.uk\/Iceland\/Black-Cone.jpg",
      "display_url" : "pepsplace.org.uk\/Iceland\/Black-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717370586973007872",
  "text" : "Looks like Iceland is trying to make clear that it has this monument in front of parliament for a reason. https:\/\/t.co\/2SiLBQ8F2F",
  "id" : 717370586973007872,
  "created_at" : "2016-04-05 15:17:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/hB3dsH67oX",
      "expanded_url" : "http:\/\/www.genomicron.evolverzone.com\/2007\/09\/genome-size-and-gene-number\/",
      "display_url" : "genomicron.evolverzone.com\/2007\/09\/genome\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717359453855621120",
  "geo" : { },
  "id_str" : "717368856226963458",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy not really, c.f. https:\/\/t.co\/hB3dsH67oX :D",
  "id" : 717368856226963458,
  "in_reply_to_status_id" : 717359453855621120,
  "created_at" : "2016-04-05 15:10:38 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717300280556142592",
  "geo" : { },
  "id_str" : "717306798227779584",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon that\u2019s why I\u2019ll talk in the session \u201Edata by the people, for the people\u201C at #FORCE2016. \uD83D\uDE0A",
  "id" : 717306798227779584,
  "in_reply_to_status_id" : 717300280556142592,
  "created_at" : "2016-04-05 11:04:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/DnfRKqZhpx",
      "expanded_url" : "https:\/\/twitter.com\/nickschurch\/status\/717268087066738688",
      "display_url" : "twitter.com\/nickschurch\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717286877888454656",
  "text" : "\u00ABPeople aren\u2019t engaged or empowered when data is inaccessible.\u00BB Yep, pretty much that. https:\/\/t.co\/DnfRKqZhpx",
  "id" : 717286877888454656,
  "created_at" : "2016-04-05 09:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/teZsqTJpm4",
      "expanded_url" : "https:\/\/twitter.com\/protohedgehog\/status\/627060432956715008",
      "display_url" : "twitter.com\/protohedgehog\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717284967013879809",
  "geo" : { },
  "id_str" : "717285546788327424",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed see https:\/\/t.co\/teZsqTJpm4 ;)",
  "id" : 717285546788327424,
  "in_reply_to_status_id" : 717284967013879809,
  "created_at" : "2016-04-05 09:39:35 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/rlfLZhiCfq",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/717283359362314240",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717284159773925376",
  "text" : "Unless it\u2019s their own research and they really need this citation to boost their h-index. https:\/\/t.co\/rlfLZhiCfq",
  "id" : 717284159773925376,
  "created_at" : "2016-04-05 09:34:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/piSPwQPJEN",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/xTiTnxpQ3ghPiB2Hp6\/200.gif",
      "display_url" : "media4.giphy.com\/media\/xTiTnxpQ\u2026"
    }, {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/IUGNy4W5FH",
      "expanded_url" : "http:\/\/nowomaha.com\/wp-content\/uploads\/2016\/03\/anigif_enhanced-30895-1457975244-2.gif",
      "display_url" : "nowomaha.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717284028819324928",
  "text" : "how i assume network analysis will be: https:\/\/t.co\/piSPwQPJEN how it really is: https:\/\/t.co\/IUGNy4W5FH",
  "id" : 717284028819324928,
  "created_at" : "2016-04-05 09:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 3, 13 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/qZVl6xY1DQ",
      "expanded_url" : "http:\/\/lab.dessimoz.org\/blog\/2016\/04\/05\/ortholog-benchmark-service",
      "display_url" : "lab.dessimoz.org\/blog\/2016\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717268757438193664",
  "text" : "RT @cdessimoz: Story behind the paper: https:\/\/t.co\/qZVl6xY1DQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/qZVl6xY1DQ",
        "expanded_url" : "http:\/\/lab.dessimoz.org\/blog\/2016\/04\/05\/ortholog-benchmark-service",
        "display_url" : "lab.dessimoz.org\/blog\/2016\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717268363945312257",
    "text" : "Story behind the paper: https:\/\/t.co\/qZVl6xY1DQ",
    "id" : 717268363945312257,
    "created_at" : "2016-04-05 08:31:18 +0000",
    "user" : {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "protected" : false,
      "id_str" : "274388734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1467970873\/photo_normal.png",
      "id" : 274388734,
      "verified" : false
    }
  },
  "id" : 717268757438193664,
  "created_at" : "2016-04-05 08:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717257479890067458",
  "geo" : { },
  "id_str" : "717266336771125250",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz congrats!",
  "id" : 717266336771125250,
  "in_reply_to_status_id" : 717257479890067458,
  "created_at" : "2016-04-05 08:23:15 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717243160372453377",
  "geo" : { },
  "id_str" : "717263329404841984",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy the r^2 for Eukaryotes would be pretty bad, judging from my guessthecorrelation experience :D",
  "id" : 717263329404841984,
  "in_reply_to_status_id" : 717243160372453377,
  "created_at" : "2016-04-05 08:11:18 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/mi8gODCZZm",
      "expanded_url" : "http:\/\/rewritingthecode.com\/2016\/03\/27\/hello-world\/",
      "display_url" : "rewritingthecode.com\/2016\/03\/27\/hel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717259187235995648",
  "text" : "RT @PhilippBayer: \"Being a \u2018Dumb\u2019 Girl in Computer Science\" Conquering the fear of looking stupid \nhttps:\/\/t.co\/mi8gODCZZm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/mi8gODCZZm",
        "expanded_url" : "http:\/\/rewritingthecode.com\/2016\/03\/27\/hello-world\/",
        "display_url" : "rewritingthecode.com\/2016\/03\/27\/hel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717198778818801665",
    "text" : "\"Being a \u2018Dumb\u2019 Girl in Computer Science\" Conquering the fear of looking stupid \nhttps:\/\/t.co\/mi8gODCZZm",
    "id" : 717198778818801665,
    "created_at" : "2016-04-05 03:54:48 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 717259187235995648,
  "created_at" : "2016-04-05 07:54:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/bRGRqfp2OH",
      "expanded_url" : "https:\/\/medium.com\/@anonopensci\/openness-is-inclusivity-fa65718e55e9",
      "display_url" : "medium.com\/@anonopensci\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717256809891962881",
  "text" : "RT @ctitusbrown: Well, so this happened: https:\/\/t.co\/bRGRqfp2OH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/bRGRqfp2OH",
        "expanded_url" : "https:\/\/medium.com\/@anonopensci\/openness-is-inclusivity-fa65718e55e9",
        "display_url" : "medium.com\/@anonopensci\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715961119823630336",
    "text" : "Well, so this happened: https:\/\/t.co\/bRGRqfp2OH",
    "id" : 715961119823630336,
    "created_at" : "2016-04-01 17:56:47 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 717256809891962881,
  "created_at" : "2016-04-05 07:45:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/glQMR2Hw7e",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/qCXHn1PU7PIly\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/qCXHn1PU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717255722665394176",
  "text" : "when you re-read the abstract you submitted months ago and figure out you didn\u2019t overpromise in it after all. https:\/\/t.co\/glQMR2Hw7e",
  "id" : 717255722665394176,
  "created_at" : "2016-04-05 07:41:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717099552659124224",
  "text" : "RT @Senficon: Discussion with Elsevier lobbyist. He asked me if I know what XML is, then he said he's not a lawyer as soon as I got into de\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TDM",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717050964411289601",
    "text" : "Discussion with Elsevier lobbyist. He asked me if I know what XML is, then he said he's not a lawyer as soon as I got into detail on #TDM.",
    "id" : 717050964411289601,
    "created_at" : "2016-04-04 18:07:26 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 717099552659124224,
  "created_at" : "2016-04-04 21:20:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398750966666, 8.753470327161535 ]
  },
  "id_str" : "717019574617698304",
  "text" : "\uD83D\uDC83 the accepted paper dance \uD83D\uDC83",
  "id" : 717019574617698304,
  "created_at" : "2016-04-04 16:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717001859647606786",
  "geo" : { },
  "id_str" : "717002710105636864",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess \\o\/ \uD83D\uDE0D",
  "id" : 717002710105636864,
  "in_reply_to_status_id" : 717001859647606786,
  "created_at" : "2016-04-04 14:55:42 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717000893565153281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232947119713, 8.627631014384022 ]
  },
  "id_str" : "717001230111911936",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess gerne. Und PCA muss man auch nicht unbedingt kennen wenn man nicht gerade viel in Populationsgenetik unterwegs ist. :)",
  "id" : 717001230111911936,
  "in_reply_to_status_id" : 717000893565153281,
  "created_at" : "2016-04-04 14:49:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "Rafael Irizarry",
      "screen_name" : "rafalab",
      "indices" : [ 17, 25 ],
      "id_str" : "177729631",
      "id" : 177729631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/Yxrqjx6JEr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Principal_component_analysis",
      "display_url" : "en.wikipedia.org\/wiki\/Principal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "716999770989047808",
  "geo" : { },
  "id_str" : "716999945228779520",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @rafalab https:\/\/t.co\/Yxrqjx6JEr I\u2019d assume if not further specified :)",
  "id" : 716999945228779520,
  "in_reply_to_status_id" : 716999770989047808,
  "created_at" : "2016-04-04 14:44:42 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Irizarry",
      "screen_name" : "rafalab",
      "indices" : [ 3, 11 ],
      "id_str" : "177729631",
      "id" : 177729631
    }, {
      "name" : "Erik Voeten",
      "screen_name" : "ErikVoeten",
      "indices" : [ 86, 97 ],
      "id_str" : "2364189422",
      "id" : 2364189422
    }, {
      "name" : "Anton Strezhnev",
      "screen_name" : "a_strezh",
      "indices" : [ 104, 113 ],
      "id_str" : "104533670",
      "id" : 104533670
    }, {
      "name" : "David Robinson",
      "screen_name" : "drob",
      "indices" : [ 127, 132 ],
      "id_str" : "46245868",
      "id" : 46245868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716997493662330880",
  "text" : "RT @rafalab: Distance between countries through the years based on UN voting. Data by @ErikVoeten &amp; @a_strezh, wrangled by @drob https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erik Voeten",
        "screen_name" : "ErikVoeten",
        "indices" : [ 73, 84 ],
        "id_str" : "2364189422",
        "id" : 2364189422
      }, {
        "name" : "Anton Strezhnev",
        "screen_name" : "a_strezh",
        "indices" : [ 91, 100 ],
        "id_str" : "104533670",
        "id" : 104533670
      }, {
        "name" : "David Robinson",
        "screen_name" : "drob",
        "indices" : [ 114, 119 ],
        "id_str" : "46245868",
        "id" : 46245868
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rafalab\/status\/716995754309652480\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/X2wAmX05Xl",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfNG3-PWAAAw9K7.jpg",
        "id_str" : "716994693096144896",
        "id" : 716994693096144896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfNG3-PWAAAw9K7.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/X2wAmX05Xl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716995754309652480",
    "text" : "Distance between countries through the years based on UN voting. Data by @ErikVoeten &amp; @a_strezh, wrangled by @drob https:\/\/t.co\/X2wAmX05Xl",
    "id" : 716995754309652480,
    "created_at" : "2016-04-04 14:28:03 +0000",
    "user" : {
      "name" : "Rafael Irizarry",
      "screen_name" : "rafalab",
      "protected" : false,
      "id_str" : "177729631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631957216254423040\/aYpkFMFG_normal.jpg",
      "id" : 177729631,
      "verified" : false
    }
  },
  "id" : 716997493662330880,
  "created_at" : "2016-04-04 14:34:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716984914135162880",
  "geo" : { },
  "id_str" : "716986073851830272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Prof. Citizen Science? \uD83D\uDE02",
  "id" : 716986073851830272,
  "in_reply_to_status_id" : 716984914135162880,
  "created_at" : "2016-04-04 13:49:35 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/2nRyrTHvZM",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2016\/04\/mosquito-genomes-chance-for-long-range.html",
      "display_url" : "omicsomics.blogspot.de\/2016\/04\/mosqui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716944077414141952",
  "text" : "Mosquito Genomes: Chance for Long-Range Companies to Shine https:\/\/t.co\/2nRyrTHvZM",
  "id" : 716944077414141952,
  "created_at" : "2016-04-04 11:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "opensource",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 86, 101 ]
    }, {
      "text" : "ISMB",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716926009992282119",
  "text" : "RT @OBF_BOSC: Today's the deadline for submitting a full #BOSC2016 talk - #opensource #bioinformatics pre #ISMB in Florida, July https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 43, 52 ]
      }, {
        "text" : "opensource",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 72, 87 ]
      }, {
        "text" : "ISMB",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/2mqw5woI1S",
        "expanded_url" : "https:\/\/news.open-bio.org\/2016\/03\/01\/bosc-2016-call-for-abstracts\/",
        "display_url" : "news.open-bio.org\/2016\/03\/01\/bos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716906503651926016",
    "text" : "Today's the deadline for submitting a full #BOSC2016 talk - #opensource #bioinformatics pre #ISMB in Florida, July https:\/\/t.co\/2mqw5woI1S",
    "id" : 716906503651926016,
    "created_at" : "2016-04-04 08:33:24 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 716926009992282119,
  "created_at" : "2016-04-04 09:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Baucom",
      "screen_name" : "gbaucom",
      "indices" : [ 3, 11 ],
      "id_str" : "48988084",
      "id" : 48988084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ZvnD4Qoh8D",
      "expanded_url" : "https:\/\/twitter.com\/blaxterlab\/status\/716657564927336448",
      "display_url" : "twitter.com\/blaxterlab\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716711893478539265",
  "text" : "RT @gbaucom: \"Memo to self: Submit early, submit openly and use the preprint servers.\" Interesting https:\/\/t.co\/ZvnD4Qoh8D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/ZvnD4Qoh8D",
        "expanded_url" : "https:\/\/twitter.com\/blaxterlab\/status\/716657564927336448",
        "display_url" : "twitter.com\/blaxterlab\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716666835110871041",
    "text" : "\"Memo to self: Submit early, submit openly and use the preprint servers.\" Interesting https:\/\/t.co\/ZvnD4Qoh8D",
    "id" : 716666835110871041,
    "created_at" : "2016-04-03 16:41:03 +0000",
    "user" : {
      "name" : "Gina Baucom",
      "screen_name" : "gbaucom",
      "protected" : false,
      "id_str" : "48988084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882059982828711936\/d-4Rusoy_normal.jpg",
      "id" : 48988084,
      "verified" : false
    }
  },
  "id" : 716711893478539265,
  "created_at" : "2016-04-03 19:40:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imaginedmuseum",
      "indices" : [ 7, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/CqaoBcoM3n",
      "expanded_url" : "https:\/\/vine.co\/v\/ijPwAXYpLVq",
      "display_url" : "vine.co\/v\/ijPwAXYpLVq"
    } ]
  },
  "geo" : { },
  "id_str" : "716620778805051392",
  "text" : "Time @ #imaginedmuseum https:\/\/t.co\/CqaoBcoM3n",
  "id" : 716620778805051392,
  "created_at" : "2016-04-03 13:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ZhsoRSJQlC",
      "expanded_url" : "http:\/\/bust.com\/feminism\/15989-how-to-mansplain-in-6-easy-steps.html",
      "display_url" : "bust.com\/feminism\/15989\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716567931434438656",
  "text" : "How To Mansplain In 6 Easy Steps https:\/\/t.co\/ZhsoRSJQlC",
  "id" : 716567931434438656,
  "created_at" : "2016-04-03 10:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cobi Smith",
      "screen_name" : "cobismith",
      "indices" : [ 3, 13 ],
      "id_str" : "26703939",
      "id" : 26703939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716554962583613440",
  "text" : "RT @cobismith: one of many amusing things about the Canadian Avalanche Rescue Cat Association is that some people think it's real https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/o5vJ3OvuQx",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=JAYQyrsX1HM",
        "display_url" : "youtube.com\/watch?v=JAYQyr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716465506123800576",
    "text" : "one of many amusing things about the Canadian Avalanche Rescue Cat Association is that some people think it's real https:\/\/t.co\/o5vJ3OvuQx",
    "id" : 716465506123800576,
    "created_at" : "2016-04-03 03:21:02 +0000",
    "user" : {
      "name" : "Cobi Smith",
      "screen_name" : "cobismith",
      "protected" : false,
      "id_str" : "26703939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790170148560736256\/0ldZu4X5_normal.jpg",
      "id" : 26703939,
      "verified" : false
    }
  },
  "id" : 716554962583613440,
  "created_at" : "2016-04-03 09:16:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy McSweeney",
      "screen_name" : "mcsweeneys",
      "indices" : [ 3, 14 ],
      "id_str" : "30109507",
      "id" : 30109507
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mcsweeneys\/status\/715955652862947328\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/zpwpVP6zxt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce0FqILUYAA6SUP.jpg",
      "id_str" : "715234137129377792",
      "id" : 715234137129377792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce0FqILUYAA6SUP.jpg",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 1105
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 1105
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 1105
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zpwpVP6zxt"
    } ],
    "hashtags" : [ {
      "text" : "AWP16",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/frC1WSWuiW",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/everybodys-invited-to-my-all-male-all-white-literary-panel",
      "display_url" : "mcsweeneys.net\/articles\/every\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716534011368251392",
  "text" : "RT @mcsweeneys: Everybody\u2019s Invited to My All-Male, All-White Literary Panel!  https:\/\/t.co\/frC1WSWuiW #AWP16 https:\/\/t.co\/zpwpVP6zxt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mcsweeneys\/status\/715955652862947328\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/zpwpVP6zxt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce0FqILUYAA6SUP.jpg",
        "id_str" : "715234137129377792",
        "id" : 715234137129377792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce0FqILUYAA6SUP.jpg",
        "sizes" : [ {
          "h" : 598,
          "resize" : "fit",
          "w" : 1105
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 1105
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 1105
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/zpwpVP6zxt"
      } ],
      "hashtags" : [ {
        "text" : "AWP16",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/frC1WSWuiW",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/everybodys-invited-to-my-all-male-all-white-literary-panel",
        "display_url" : "mcsweeneys.net\/articles\/every\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715955652862947328",
    "text" : "Everybody\u2019s Invited to My All-Male, All-White Literary Panel!  https:\/\/t.co\/frC1WSWuiW #AWP16 https:\/\/t.co\/zpwpVP6zxt",
    "id" : 715955652862947328,
    "created_at" : "2016-04-01 17:35:04 +0000",
    "user" : {
      "name" : "Timothy McSweeney",
      "screen_name" : "mcsweeneys",
      "protected" : false,
      "id_str" : "30109507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753636910656958465\/PZMyIsPO_normal.jpg",
      "id" : 30109507,
      "verified" : true
    }
  },
  "id" : 716534011368251392,
  "created_at" : "2016-04-03 07:53:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716327325076496388",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09916799123582, 8.691546769551723 ]
  },
  "id_str" : "716367560623656960",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed nah, ich lese Twitter 50:50 mobile\/an Desktop.",
  "id" : 716367560623656960,
  "in_reply_to_status_id" : 716327325076496388,
  "created_at" : "2016-04-02 20:51:50 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716325740619411456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09910950348205, 8.691710056901334 ]
  },
  "id_str" : "716326109399420929",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed mh, ich vermute letzteres. Hab die URL direkt aus der mobile website kopiert.",
  "id" : 716326109399420929,
  "in_reply_to_status_id" : 716325740619411456,
  "created_at" : "2016-04-02 18:07:07 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademicHipster",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/A5iOaEIGEA",
      "expanded_url" : "https:\/\/s3.amazonaws.com\/cn-ppg-api-development\/dest\/605337ff-c26e-4db6-9a39-14b6fa486f70\/animated.gif",
      "display_url" : "s3.amazonaws.com\/cn-ppg-api-dev\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0990879750796, 8.691720582330616 ]
  },
  "id_str" : "716324845806620678",
  "text" : "#AcademicHipster seems about right. https:\/\/t.co\/A5iOaEIGEA",
  "id" : 716324845806620678,
  "created_at" : "2016-04-02 18:02:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/w8WU5ZH9vQ",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/716294087335260160",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09901747112171, 8.692566342659939 ]
  },
  "id_str" : "716306881027973121",
  "text" : "A great opportunity for those interested in bioinformatics and open source: https:\/\/t.co\/w8WU5ZH9vQ",
  "id" : 716306881027973121,
  "created_at" : "2016-04-02 16:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 3, 14 ],
      "id_str" : "44903491",
      "id" : 44903491
    }, {
      "name" : "Massachusetts Institute of Technology (MIT)",
      "screen_name" : "MIT",
      "indices" : [ 26, 30 ],
      "id_str" : "15460048",
      "id" : 15460048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/oc2y4ZCzyN",
      "expanded_url" : "http:\/\/tech.mit.edu\/V136\/N9\/harassment.html",
      "display_url" : "tech.mit.edu\/V136\/N9\/harass\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716293463617175554",
  "text" : "RT @roseveleth: Holy shit @MIT this is completely unacceptable https:\/\/t.co\/oc2y4ZCzyN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Massachusetts Institute of Technology (MIT)",
        "screen_name" : "MIT",
        "indices" : [ 10, 14 ],
        "id_str" : "15460048",
        "id" : 15460048
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/oc2y4ZCzyN",
        "expanded_url" : "http:\/\/tech.mit.edu\/V136\/N9\/harassment.html",
        "display_url" : "tech.mit.edu\/V136\/N9\/harass\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716232356181491712",
    "text" : "Holy shit @MIT this is completely unacceptable https:\/\/t.co\/oc2y4ZCzyN",
    "id" : 716232356181491712,
    "created_at" : "2016-04-02 11:54:35 +0000",
    "user" : {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "protected" : false,
      "id_str" : "44903491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782201676006588416\/GAIXvMwJ_normal.jpg",
      "id" : 44903491,
      "verified" : false
    }
  },
  "id" : 716293463617175554,
  "created_at" : "2016-04-02 15:57:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 0, 10 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716265692748767232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11334796906459, 8.75421138481121 ]
  },
  "id_str" : "716280115236311041",
  "in_reply_to_user_id" : 334912047,
  "text" : "@DNADigest thanks, but the deadline was last Friday :)",
  "id" : 716280115236311041,
  "in_reply_to_status_id" : 716265692748767232,
  "created_at" : "2016-04-02 15:04:21 +0000",
  "in_reply_to_screen_name" : "DNADigest",
  "in_reply_to_user_id_str" : "334912047",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    }, {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 8, 16 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716059267921534977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139834934614, 8.753466844468651 ]
  },
  "id_str" : "716061528198410240",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle @ny_borg da muss die WG-Kasse noch etwas sparen. :D",
  "id" : 716061528198410240,
  "in_reply_to_status_id" : 716059267921534977,
  "created_at" : "2016-04-02 00:35:46 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716058653787291649",
  "geo" : { },
  "id_str" : "716058794502066178",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle Nice. Das hilft mir f\u00FCr Frankfurt, Brisbane, Orlando, Frankfurt nur wenig ;)",
  "id" : 716058794502066178,
  "in_reply_to_status_id" : 716058653787291649,
  "created_at" : "2016-04-02 00:24:54 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    }, {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 8, 16 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716046077888184321",
  "geo" : { },
  "id_str" : "716058295300186112",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle @ny_borg Was ist da die maximum range? :)",
  "id" : 716058295300186112,
  "in_reply_to_status_id" : 716046077888184321,
  "created_at" : "2016-04-02 00:22:55 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716039330574311424",
  "text" : "@stopifnot enjoy, the two of you and good night. \uD83D\uDC36\uD83D\uDCA4",
  "id" : 716039330574311424,
  "created_at" : "2016-04-01 23:07:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716038394682425344",
  "text" : "@stopifnot &lt;3 and please keep going if you have more, I\u2019m enjoying those. It\u2019s just that my creativity has run dry :D",
  "id" : 716038394682425344,
  "created_at" : "2016-04-01 23:03:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716036697419591684",
  "text" : "@stopifnot I\u2019m out of puns, the only one left is geom_rex :p",
  "id" : 716036697419591684,
  "created_at" : "2016-04-01 22:57:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716034385955450882",
  "text" : "@stopifnot \uD83D\uDE0D (\u201Cposition=\u2018dog\u2019\u201C is a typo I already do all the time )",
  "id" : 716034385955450882,
  "created_at" : "2016-04-01 22:47:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/JsiRO6VcAr",
      "expanded_url" : "https:\/\/twitter.com\/BioDataGanache\/status\/716000751374434304",
      "display_url" : "twitter.com\/BioDataGanache\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716032692953939970",
  "text" : "Could we get something similar w\/ dogs into ggplot2 please? I suggest geom_bark and geom_dogplot. https:\/\/t.co\/JsiRO6VcAr",
  "id" : 716032692953939970,
  "created_at" : "2016-04-01 22:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/716022824897478657\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/SFUzRCICTS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_S9sjXEAEBWM2.jpg",
      "id_str" : "716022823148523521",
      "id" : 716022823148523521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_S9sjXEAEBWM2.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/SFUzRCICTS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398287272295, 8.753464954537183 ]
  },
  "id_str" : "716022824897478657",
  "text" : "Close! https:\/\/t.co\/SFUzRCICTS",
  "id" : 716022824897478657,
  "created_at" : "2016-04-01 22:01:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/3OFXdoO3bP",
      "expanded_url" : "https:\/\/www.goodreads.com\/blog\/show\/632-announcing-the-new-goodreads-literary-magazine",
      "display_url" : "goodreads.com\/blog\/show\/632-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716019377997484033",
  "text" : "\u00ABAuthors: They\u2019re nothing like us! They _finish_ Infinite Jest!\u00BB \uD83D\uDE02 https:\/\/t.co\/3OFXdoO3bP",
  "id" : 716019377997484033,
  "created_at" : "2016-04-01 21:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    }, {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 8, 16 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716011825935069185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398521948298, 8.753472208955559 ]
  },
  "id_str" : "716012059931099136",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle @ny_borg k\u00F6nnen wir es \u2018Uber-Schall\u2019 nennen, pretty pls?",
  "id" : 716012059931099136,
  "in_reply_to_status_id" : 716011825935069185,
  "created_at" : "2016-04-01 21:19:12 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716011182080008192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398797156738, 8.753470965518606 ]
  },
  "id_str" : "716011353492877312",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg word! Wir brauchen einen WG-Jet.",
  "id" : 716011353492877312,
  "in_reply_to_status_id" : 716011182080008192,
  "created_at" : "2016-04-01 21:16:24 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716010408922976257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393206644422, 8.753543551712886 ]
  },
  "id_str" : "716010624208207872",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg die Letztere Option ist halt viel l\u00E4nger :\/",
  "id" : 716010624208207872,
  "in_reply_to_status_id" : 716010408922976257,
  "created_at" : "2016-04-01 21:13:30 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 10, 24 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/6ILbE8X7TW",
      "expanded_url" : "https:\/\/youtu.be\/_7iXw9zZrLo?t=3m2s",
      "display_url" : "youtu.be\/_7iXw9zZrLo?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716005250088452096",
  "text" : "@quominus @hadleywickham https:\/\/t.co\/6ILbE8X7TW",
  "id" : 716005250088452096,
  "created_at" : "2016-04-01 20:52:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/s4gBpZPJCN",
      "expanded_url" : "http:\/\/qz.com\/648407\/philosophers-are-increasingly-using-empirical-data-to-test-theories-of-morality\/",
      "display_url" : "qz.com\/648407\/philoso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715995125328060416",
  "text" : "imho the only reason that \u201Earmchair philosophy\u201C is now being less of a thing is the current standing desk fad. https:\/\/t.co\/s4gBpZPJCN",
  "id" : 715995125328060416,
  "created_at" : "2016-04-01 20:11:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715936748229038082",
  "geo" : { },
  "id_str" : "715936814855548929",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe nah, no problem. Much appreciated advice! :)",
  "id" : 715936814855548929,
  "in_reply_to_status_id" : 715936748229038082,
  "created_at" : "2016-04-01 16:20:12 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715936327477370881",
  "geo" : { },
  "id_str" : "715936453147160576",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe see follow up-tweet a bit later. round-trips did decrease price by 2k.",
  "id" : 715936453147160576,
  "in_reply_to_status_id" : 715936327477370881,
  "created_at" : "2016-04-01 16:18:46 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715929409220427777",
  "text" : "Fun tools that should only calculate ~10k numbers between 0 &amp; 1 but somehow manage to write 10 MB+ XML files for it. \uD83D\uDE12",
  "id" : 715929409220427777,
  "created_at" : "2016-04-01 15:50:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/rF4Avx7c8i",
      "expanded_url" : "https:\/\/aeon.co\/opinions\/galileo-s-reputation-is-more-hyperbole-than-truth",
      "display_url" : "aeon.co\/opinions\/galil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715916337625870336",
  "text" : "\u00ABGalileo\u2019s vast reputation, and the hyperbolic accolades that go with it, are not justified by the real history.\u00BB \uD83C\uDF89 https:\/\/t.co\/rF4Avx7c8i",
  "id" : 715916337625870336,
  "created_at" : "2016-04-01 14:58:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715909996622528512",
  "geo" : { },
  "id_str" : "715910249241321472",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen you can\u2019t afford slow travel if you have to be in BNE until 7th and should be in MCO on 8th :\/",
  "id" : 715910249241321472,
  "in_reply_to_status_id" : 715909996622528512,
  "created_at" : "2016-04-01 14:34:39 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715909327979220993",
  "geo" : { },
  "id_str" : "715909438444552193",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen crossing the international dateline eastwards is so much faster :D",
  "id" : 715909438444552193,
  "in_reply_to_status_id" : 715909327979220993,
  "created_at" : "2016-04-01 14:31:25 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/TAQEcls7OM",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=4066",
      "display_url" : "smbc-comics.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715908975242424320",
  "text" : "always prioritise https:\/\/t.co\/TAQEcls7OM",
  "id" : 715908975242424320,
  "created_at" : "2016-04-01 14:29:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/UaXQkaWZT8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/715877508021936128",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715877508021936128",
  "geo" : { },
  "id_str" : "715907878197063681",
  "in_reply_to_user_id" : 14286491,
  "text" : "Doing the 5.5k \u20AC option &amp; buying return-tickets for each leg drives the price down to ~3.5k \u20AC. Air travel is magic\u2026 https:\/\/t.co\/UaXQkaWZT8",
  "id" : 715907878197063681,
  "in_reply_to_status_id" : 715877508021936128,
  "created_at" : "2016-04-01 14:25:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715885571890135040",
  "geo" : { },
  "id_str" : "715885709173858305",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot aaah, too bad. Would have enjoyed meeting more of the Twitter-folk :)",
  "id" : 715885709173858305,
  "in_reply_to_status_id" : 715885571890135040,
  "created_at" : "2016-04-01 12:57:08 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715880524397559808",
  "geo" : { },
  "id_str" : "715885247150350336",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I know, &amp; a pilot\u2019s license so I can just take care of it myself! (preparing talks while on the plane might be a problem though).",
  "id" : 715885247150350336,
  "in_reply_to_status_id" : 715880524397559808,
  "created_at" : "2016-04-01 12:55:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Komljenovi\u0107",
      "screen_name" : "antifreezeprot",
      "indices" : [ 0, 15 ],
      "id_str" : "851420822",
      "id" : 851420822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715882945496612864",
  "geo" : { },
  "id_str" : "715884498299318273",
  "in_reply_to_user_id" : 851420822,
  "text" : "@antifreezeprot of course, and so I take you won\u2019t attend? :(",
  "id" : 715884498299318273,
  "in_reply_to_status_id" : 715882945496612864,
  "created_at" : "2016-04-01 12:52:19 +0000",
  "in_reply_to_screen_name" : "antifreezeprot",
  "in_reply_to_user_id_str" : "851420822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715879055971758080",
  "geo" : { },
  "id_str" : "715879124695429121",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor looking into that right now :D",
  "id" : 715879124695429121,
  "in_reply_to_status_id" : 715879055971758080,
  "created_at" : "2016-04-01 12:30:58 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715877837459296257",
  "geo" : { },
  "id_str" : "715877963946921984",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor nope, this was going for overall cheapest connections.",
  "id" : 715877963946921984,
  "in_reply_to_status_id" : 715877837459296257,
  "created_at" : "2016-04-01 12:26:21 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715877023890214912",
  "geo" : { },
  "id_str" : "715877565328715776",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek fully agree :D",
  "id" : 715877565328715776,
  "in_reply_to_status_id" : 715877023890214912,
  "created_at" : "2016-04-01 12:24:46 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715871419826106368",
  "geo" : { },
  "id_str" : "715877508021936128",
  "in_reply_to_user_id" : 14286491,
  "text" : "Related: doing a multi-city trip FRA \u2708\uFE0F BNE \u2708\uFE0F MCO \u2708\uFE0F FRA is ~5.5k \u20AC. \nDoing FRA \u2708\uFE0F BNE \u2708\uFE0F FRA \u2708\uFE0F MCO \u2708\uFE0F FRA is only ~1.5 k \u20AC \uD83D\uDE12",
  "id" : 715877508021936128,
  "in_reply_to_status_id" : 715871419826106368,
  "created_at" : "2016-04-01 12:24:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715876722860761088",
  "geo" : { },
  "id_str" : "715876858278125568",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek it\u2019s not one of the SMBE grants though. It\u2019s from a foundation attached to my uni. :)",
  "id" : 715876858278125568,
  "in_reply_to_status_id" : 715876722860761088,
  "created_at" : "2016-04-01 12:21:58 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715858774507065344",
  "geo" : { },
  "id_str" : "715873233086636032",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant i haven\u2019t checked, in the end I just downloaded the ready-made pandoc package.",
  "id" : 715873233086636032,
  "in_reply_to_status_id" : 715858774507065344,
  "created_at" : "2016-04-01 12:07:33 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715871419826106368",
  "text" : "Got a travel grant for this year\u2019s SMBE. Now I really need to figure out how to get there. \uD83E\uDD14",
  "id" : 715871419826106368,
  "created_at" : "2016-04-01 12:00:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/GgmSHgZU0t",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/MVOvIa3JYKeCA\/200.gif",
      "display_url" : "media3.giphy.com\/media\/MVOvIa3J\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715850438252367872",
  "geo" : { },
  "id_str" : "715867927543676928",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @lobot misread that as sloth-motion https:\/\/t.co\/GgmSHgZU0t",
  "id" : 715867927543676928,
  "in_reply_to_status_id" : 715850438252367872,
  "created_at" : "2016-04-01 11:46:28 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "Bioinformatics",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/2mqw5woI1S",
      "expanded_url" : "https:\/\/news.open-bio.org\/2016\/03\/01\/bosc-2016-call-for-abstracts\/",
      "display_url" : "news.open-bio.org\/2016\/03\/01\/bos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715842909841530881",
  "text" : "RT @OBF_BOSC: No fooling: you have an extra 3 days to submit your abstract to #BOSC2016! https:\/\/t.co\/2mqw5woI1S #Bioinformatics #Opensourc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "Bioinformatics",
        "indices" : [ 99, 114 ]
      }, {
        "text" : "Opensource",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/2mqw5woI1S",
        "expanded_url" : "https:\/\/news.open-bio.org\/2016\/03\/01\/bosc-2016-call-for-abstracts\/",
        "display_url" : "news.open-bio.org\/2016\/03\/01\/bos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715805963517882368",
    "text" : "No fooling: you have an extra 3 days to submit your abstract to #BOSC2016! https:\/\/t.co\/2mqw5woI1S #Bioinformatics #Opensource Conference",
    "id" : 715805963517882368,
    "created_at" : "2016-04-01 07:40:15 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 715842909841530881,
  "created_at" : "2016-04-01 10:07:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715828263009042433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16218123030864, 8.670332841583221 ]
  },
  "id_str" : "715834159462289409",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it\u2019s just a matter of timing\u2026",
  "id" : 715834159462289409,
  "in_reply_to_status_id" : 715828263009042433,
  "created_at" : "2016-04-01 09:32:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/vMV1mEungY",
      "expanded_url" : "http:\/\/m.imgur.com\/EiKG8i1?r",
      "display_url" : "m.imgur.com\/EiKG8i1?r"
    } ]
  },
  "in_reply_to_status_id_str" : "715826587460046849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399342829385, 8.753473676962528 ]
  },
  "id_str" : "715827769129754625",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well\u2026 https:\/\/t.co\/vMV1mEungY",
  "id" : 715827769129754625,
  "in_reply_to_status_id" : 715826587460046849,
  "created_at" : "2016-04-01 09:06:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "gutsle",
      "indices" : [ 0, 7 ],
      "id_str" : "837535866",
      "id" : 837535866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715782746711437312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398858935539, 8.753469787427228 ]
  },
  "id_str" : "715824969381502977",
  "in_reply_to_user_id" : 837535866,
  "text" : "@gutsle thx!",
  "id" : 715824969381502977,
  "in_reply_to_status_id" : 715782746711437312,
  "created_at" : "2016-04-01 08:55:46 +0000",
  "in_reply_to_screen_name" : "gutsle",
  "in_reply_to_user_id_str" : "837535866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715812127139823616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139845457604, 8.753468006431891 ]
  },
  "id_str" : "715824944349839360",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot why?",
  "id" : 715824944349839360,
  "in_reply_to_status_id" : 715812127139823616,
  "created_at" : "2016-04-01 08:55:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/715677241930358786\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Kr5waMOJXJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce6YqD_WAAEVyuZ.jpg",
      "id_str" : "715677239191404545",
      "id" : 715677239191404545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce6YqD_WAAEVyuZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Kr5waMOJXJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398627675585, 8.753472878408637 ]
  },
  "id_str" : "715677241930358786",
  "text" : "One last thing from \u2018How to be an Explorer of the World\u2019: If you start to think you\u2019re wasting your time\u2026 https:\/\/t.co\/Kr5waMOJXJ",
  "id" : 715677241930358786,
  "created_at" : "2016-03-31 23:08:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]