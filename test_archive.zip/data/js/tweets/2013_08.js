Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 17, 30 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373874068141121538",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373875596365135873",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot @Naturalismus a series of honest mistakes down the rabbit hole!",
  "id" : 373875596365135873,
  "in_reply_to_status_id" : 373874068141121538,
  "created_at" : "2013-08-31 18:31:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 42, 48 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 95, 108 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373872650025586689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373873887207251968",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Endlich verwechsle ich dich und @Lobot nicht mehr beim \u00FCberfliegen der Timeline! \\o\/ @Naturalismus",
  "id" : 373873887207251968,
  "in_reply_to_status_id" : 373872650025586689,
  "created_at" : "2013-08-31 18:24:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "derAfri",
      "screen_name" : "derAfri",
      "indices" : [ 7, 15 ],
      "id_str" : "15588017",
      "id" : 15588017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373864641308672000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095814067, 8.2831358472 ]
  },
  "id_str" : "373865145199779840",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @derAfri gute Besserung euch!",
  "id" : 373865145199779840,
  "in_reply_to_status_id" : 373864641308672000,
  "created_at" : "2013-08-31 17:49:31 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/BXmydJDPzk",
      "expanded_url" : "http:\/\/instagram.com\/p\/dr71Glhwlz\/",
      "display_url" : "instagram.com\/p\/dr71Glhwlz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01431218, 8.27548549 ]
  },
  "id_str" : "373864737530183680",
  "text" : "Wohnhof @ Rheinwiesen Kastel http:\/\/t.co\/BXmydJDPzk",
  "id" : 373864737530183680,
  "created_at" : "2013-08-31 17:47:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286079, 8.2830930439 ]
  },
  "id_str" : "373843430272929792",
  "text" : "\u00ABDie Intelligenzija der Piraten findet man auf der #om13, das Gegenteil sp\u00E4ter unter dem Hashtag auf Twitter.\u00BB",
  "id" : 373843430272929792,
  "created_at" : "2013-08-31 16:23:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/D8aDsLx2V8",
      "expanded_url" : "http:\/\/instagram.com\/p\/drxKFdBwg7\/",
      "display_url" : "instagram.com\/p\/drxKFdBwg7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "373841320902918144",
  "text" : "Kasteler Street Art: Vorsicht Schl\u00E4gertrupps http:\/\/t.co\/D8aDsLx2V8",
  "id" : 373841320902918144,
  "created_at" : "2013-08-31 16:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iBHtThw1Za",
      "expanded_url" : "http:\/\/www.theguardian.com\/higher-education-network\/2013\/aug\/30\/what-does-phd-stand-for",
      "display_url" : "theguardian.com\/higher-educati\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373806089076494336",
  "text" : "Academia: \u00ABAll of which result in, if not professorship, then potential heavy drinking.\u00BB http:\/\/t.co\/iBHtThw1Za",
  "id" : 373806089076494336,
  "created_at" : "2013-08-31 13:54:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/KWWRQ56S2E",
      "expanded_url" : "http:\/\/imgur.com\/89AnV12",
      "display_url" : "imgur.com\/89AnV12"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373799569861406720",
  "text" : "They Told Me I Could Be Anything I Wanted! http:\/\/t.co\/KWWRQ56S2E",
  "id" : 373799569861406720,
  "created_at" : "2013-08-31 13:28:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/bCfsAX3pSy",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1625",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373795725173612544",
  "text" : "Working a boring desk job http:\/\/t.co\/bCfsAX3pSy",
  "id" : 373795725173612544,
  "created_at" : "2013-08-31 13:13:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naim Matasci",
      "screen_name" : "nmatasci",
      "indices" : [ 0, 9 ],
      "id_str" : "322061462",
      "id" : 322061462
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 10, 18 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373625909648957440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096297726, 8.2830480942 ]
  },
  "id_str" : "373753744103862272",
  "in_reply_to_user_id" : 322061462,
  "text" : "@nmatasci @heyaudy iirc the caption said it was a chameleon. :)",
  "id" : 373753744103862272,
  "in_reply_to_status_id" : 373625909648957440,
  "created_at" : "2013-08-31 10:26:51 +0000",
  "in_reply_to_screen_name" : "nmatasci",
  "in_reply_to_user_id_str" : "322061462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 43, 50 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096297726, 8.2830480942 ]
  },
  "id_str" : "373752985614286848",
  "text" : "\u00ABAber da ist Bundestagswahl!\u00BB \u2014 \u00ABUm es mit @lsanoj zu sagen: Meine Orgasmen sind wichtiger als Deutschland!\u00BB",
  "id" : 373752985614286848,
  "created_at" : "2013-08-31 10:23:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096724162, 8.283005035 ]
  },
  "id_str" : "373606215236210688",
  "text" : "Aus Penis Enlargement Spam: \u00AB\u2026ungefl\u00FCgelten Weibchen misst meist zwischen 0.9-1.5 mm. Die Segmentierung der K\u00F6rper ist\u2026\u00BB Gutes Targeting!",
  "id" : 373606215236210688,
  "created_at" : "2013-08-31 00:40:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373604351870500866",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096724162, 8.283005035 ]
  },
  "id_str" : "373604435370725376",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj :*",
  "id" : 373604435370725376,
  "in_reply_to_status_id" : 373604351870500866,
  "created_at" : "2013-08-31 00:33:33 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 22, 29 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096724162, 8.283005035 ]
  },
  "id_str" : "373604296832856064",
  "text" : "Jetzt w\u00FCrde ich gerne @lsanoj knutschen. Wie die Tiere!",
  "id" : 373604296832856064,
  "created_at" : "2013-08-31 00:33:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/sIAWZj39ZK",
      "expanded_url" : "http:\/\/i.imgur.com\/ruNl5CR.gif",
      "display_url" : "i.imgur.com\/ruNl5CR.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00962, 8.283045 ]
  },
  "id_str" : "373600130949459968",
  "text" : "And then we kissed like\u2026 http:\/\/t.co\/sIAWZj39ZK",
  "id" : 373600130949459968,
  "created_at" : "2013-08-31 00:16:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/dPYsxrWpoY",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=kHCmw5tv1CU",
      "display_url" : "youtube.com\/watch?v=kHCmw5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373598606336352256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096703454, 8.2830584779 ]
  },
  "id_str" : "373599041361575937",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng http:\/\/t.co\/dPYsxrWpoY ;)",
  "id" : 373599041361575937,
  "in_reply_to_status_id" : 373598606336352256,
  "created_at" : "2013-08-31 00:12:07 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/PTc9HsI8iS",
      "expanded_url" : "http:\/\/i.imgur.com\/7Tbs33g.png",
      "display_url" : "i.imgur.com\/7Tbs33g.png"
    } ]
  },
  "geo" : { },
  "id_str" : "373595390186381312",
  "text" : "Party Time! http:\/\/t.co\/PTc9HsI8iS",
  "id" : 373595390186381312,
  "created_at" : "2013-08-30 23:57:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/PuPcnzRQnY",
      "expanded_url" : "http:\/\/www.dorkly.com\/comic\/53783\/fallout-companion-break-up",
      "display_url" : "dorkly.com\/comic\/53783\/fa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009668, 8.283058 ]
  },
  "id_str" : "373579197060743168",
  "text" : "We're not breaking up. We're taking a break! http:\/\/t.co\/PuPcnzRQnY",
  "id" : 373579197060743168,
  "created_at" : "2013-08-30 22:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373571334711672832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096721885, 8.2830877931 ]
  },
  "id_str" : "373571996074139649",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a &lt;3",
  "id" : 373571996074139649,
  "in_reply_to_status_id" : 373571334711672832,
  "created_at" : "2013-08-30 22:24:39 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sung won Lim",
      "screen_name" : "bookhling",
      "indices" : [ 3, 13 ],
      "id_str" : "14482242",
      "id" : 14482242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373568427329609728",
  "text" : "RT @bookhling: Listening to some of those professional futurists talk... Sometimes I feel like they stole my future and sold it out for con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373471708927115265",
    "text" : "Listening to some of those professional futurists talk... Sometimes I feel like they stole my future and sold it out for consulting gigs.",
    "id" : 373471708927115265,
    "created_at" : "2013-08-30 15:46:08 +0000",
    "user" : {
      "name" : "Sung won Lim",
      "screen_name" : "bookhling",
      "protected" : false,
      "id_str" : "14482242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671091829199101953\/Rd53X4zf_normal.jpg",
      "id" : 14482242,
      "verified" : false
    }
  },
  "id" : 373568427329609728,
  "created_at" : "2013-08-30 22:10:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373567014268203009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096371959, 8.2830206248 ]
  },
  "id_str" : "373567141657980928",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a fehlen nur alte Freunde.",
  "id" : 373567141657980928,
  "in_reply_to_status_id" : 373567014268203009,
  "created_at" : "2013-08-30 22:05:21 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/c8AMjdgStd",
      "expanded_url" : "http:\/\/memecrunch.com\/image\/4ee0fac4186133195c000c5a.jpg",
      "display_url" : "memecrunch.com\/image\/4ee0fac4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373566167039754240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096371959, 8.2830206248 ]
  },
  "id_str" : "373567025098276864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot soon! http:\/\/t.co\/c8AMjdgStd",
  "id" : 373567025098276864,
  "in_reply_to_status_id" : 373566167039754240,
  "created_at" : "2013-08-30 22:04:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373563900085551104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096262183, 8.2830471278 ]
  },
  "id_str" : "373564052578271233",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng vor jeder Revolution stehen die melancholischen Abende. :)",
  "id" : 373564052578271233,
  "in_reply_to_status_id" : 373563900085551104,
  "created_at" : "2013-08-30 21:53:05 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373563531024547840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096262183, 8.2830471278 ]
  },
  "id_str" : "373563712411815936",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng ich hab auch schon heimlich Wader-Songs ge\u00FCbt!",
  "id" : 373563712411815936,
  "in_reply_to_status_id" : 373563531024547840,
  "created_at" : "2013-08-30 21:51:44 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 87, 94 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096262183, 8.2830471278 ]
  },
  "id_str" : "373563373986004992",
  "text" : "In einen Topf voll Rotwein &amp; Ton Steine Scherben gefallen. Sp\u00FCre das Verlangen mit @TnaKng die Revolution auszurufen.",
  "id" : 373563373986004992,
  "created_at" : "2013-08-30 21:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096664429, 8.2830579056 ]
  },
  "id_str" : "373561048248635392",
  "text" : "\u00ABDer Wein arbeitet f\u00FCr mich!\u00BB \u2014 \u00ABVorsicht, er soll zwar atmen, aber er tut das nicht an deiner Stelle!\u00BB",
  "id" : 373561048248635392,
  "created_at" : "2013-08-30 21:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096750448, 8.2828548183 ]
  },
  "id_str" : "373547964587081728",
  "text" : "\u00ABDarf ich dir was zu trinken anbieten?\u00BB \u2014 \u00ABGerne, dein Blut!\u00BB",
  "id" : 373547964587081728,
  "created_at" : "2013-08-30 20:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5SyCfnWG5X",
      "expanded_url" : "http:\/\/iwasanawesomerkid.tumblr.com\/",
      "display_url" : "iwasanawesomerkid.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373541892765794305",
  "text" : "\u00ABYou didn\u2019t know right from wrong, you just knew right from not fun. Sugar hangovers, swimming right after you ate\u2026\u00BB http:\/\/t.co\/5SyCfnWG5X",
  "id" : 373541892765794305,
  "created_at" : "2013-08-30 20:25:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoterFranz",
      "screen_name" : "RoterFranz",
      "indices" : [ 0, 11 ],
      "id_str" : "3177839572",
      "id" : 3177839572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373534687152865280",
  "text" : "@RoterFranz Evolutionsbiologie, was denn sonst? ;)",
  "id" : 373534687152865280,
  "created_at" : "2013-08-30 19:56:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0090825354, 8.2841816366 ]
  },
  "id_str" : "373533466102861824",
  "text" : "\u00ABTrotz Godwin kein Shitstorm! mit meinem Troll-Latein am Ende.\u00BB \u2014 \u00ABKeine Sorge. Hase. Irgendwann wirst du schon Eva Braun mit Bart genannt.\u00BB",
  "id" : 373533466102861824,
  "created_at" : "2013-08-30 19:51:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1037734543, 8.5470409607 ]
  },
  "id_str" : "373532351571439616",
  "text" : "\u00ABIch wusste du kannst mich treffen wenn du willst. Sehr n\u00FCtzlich.\u00BB \u2014 \u00ABJa, mein praktischer Geheimskill: Den Menschen die ich liebe weh tun!\u00BB",
  "id" : 373532351571439616,
  "created_at" : "2013-08-30 19:47:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0067906559, 8.2886158425 ]
  },
  "id_str" : "373531352165281793",
  "text" : "\u00ABEy, Benziner oder Diesel?\u00BB \u2014 \u00ABF\u00FC\u00DFe\u2026\u00BB",
  "id" : 373531352165281793,
  "created_at" : "2013-08-30 19:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1054987181, 8.6415527748 ]
  },
  "id_str" : "373512338240196608",
  "text" : "Literally impressive reasoning \u00ABDaraus schlie\u00DFe ich das du mich verabscheust. Wie kannst du mich dann lieben? Deshalb bei\u00DFe ich dich jetzt!\u00BB",
  "id" : 373512338240196608,
  "created_at" : "2013-08-30 18:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13gate",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1055644955, 8.7424431726 ]
  },
  "id_str" : "373407109897273344",
  "text" : "Typisch: Das parallel zum #om13gate mit dem Burning Man DAS Festival der feministischen Weltverschw\u00F6rung l\u00E4uft interessiert wieder keinen\u2026",
  "id" : 373407109897273344,
  "created_at" : "2013-08-30 11:29:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373404835904634880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1054113011, 8.6962366086 ]
  },
  "id_str" : "373405093846327297",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente aber man muss sie doch aus ihrer Faktenfreiheit erl\u00F6sen!",
  "id" : 373405093846327297,
  "in_reply_to_status_id" : 373404835904634880,
  "created_at" : "2013-08-30 11:21:26 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1110976149, 8.6879698389 ]
  },
  "id_str" : "373404412162871296",
  "text" : "\u00ABAlter, bist du dumm?! Alle Tiere m\u00FCssen bei\u00DFen, f\u00FCr ihre Schei\u00DF Nahrung!\u00BB 3 S-Bahn-Stationen um \u00FCber Fliegen, Schlangen &amp; Co zu referieren.",
  "id" : 373404412162871296,
  "created_at" : "2013-08-30 11:18:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoterFranz",
      "screen_name" : "RoterFranz",
      "indices" : [ 0, 11 ],
      "id_str" : "3177839572",
      "id" : 3177839572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1499595083, 8.6639617446 ]
  },
  "id_str" : "373400438378598400",
  "text" : "@RoterFranz das war alles total wissenschaftlich!",
  "id" : 373400438378598400,
  "created_at" : "2013-08-30 11:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1692706266, 8.6225284156 ]
  },
  "id_str" : "373397630732480512",
  "text" : "\u00ABDiplomatisch ausgedr\u00FCckt: Nach dem Tag solltest du meinen posterior belief in dich lieber nicht mit dem Prior vergleichen\u2026\u00BB",
  "id" : 373397630732480512,
  "created_at" : "2013-08-30 10:51:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373394944464916480",
  "text" : "\u00ABGuten Tag, ich rufe an weil wir mal wieder ihr Blut ben\u00F6tigen w\u00FCrden. Passt es ihnen n\u00E4chste Woche?\u00BB",
  "id" : 373394944464916480,
  "created_at" : "2013-08-30 10:41:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723216897, 8.6276352855 ]
  },
  "id_str" : "373363435473743872",
  "text" : "\u00ABAlso Jan hat Geschlechtskrankheiten\u2026 \u2026in seinem Baum!\u00BB",
  "id" : 373363435473743872,
  "created_at" : "2013-08-30 08:35:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722886173, 8.6276417671 ]
  },
  "id_str" : "373361509260619776",
  "text" : "\u00ABOh nein, nicht dein Baum! K\u00F6nnen wir nicht lieber \u00FCber was nettes, also weiter \u00FCber Geschlechtskrankheiten, reden?\u00BB",
  "id" : 373361509260619776,
  "created_at" : "2013-08-30 08:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/38Waaej41y",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072427",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373354870226440192",
  "text" : "From: \u00ABA Model of Human Cooperation in Social Dilemmas\u00BB http:\/\/t.co\/38Waaej41y",
  "id" : 373354870226440192,
  "created_at" : "2013-08-30 08:01:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373354762948706304",
  "text" : "Contribs:\u00ABI am the only author, so, I did everything! The manuscript do not contain any experiment, I would say only \u201Cwrote the manuscript\u201D\u00BB",
  "id" : 373354762948706304,
  "created_at" : "2013-08-30 08:01:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/nB53qfmP3G",
      "expanded_url" : "http:\/\/www.nydailynews.com\/news\/national\/monument-god-chaos-materializes-front-oklahoma-city-restaurant-article-1.1439431",
      "display_url" : "nydailynews.com\/news\/national\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373348895247433728",
  "text" : "'fictional deity' - welcome to tautology club http:\/\/t.co\/nB53qfmP3G",
  "id" : 373348895247433728,
  "created_at" : "2013-08-30 07:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/DJEBRUA51N",
      "expanded_url" : "http:\/\/www.businessinsider.com\/mathematicians-figured-out-how-to-execute-the-perfect-reddit-submission-2013-8",
      "display_url" : "businessinsider.com\/mathematicians\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373341900301811712",
  "text" : "Going Viral 101: \u00ABComputer Scientists Figured Out How To Execute The Perfect Reddit Submission\u00BB http:\/\/t.co\/DJEBRUA51N",
  "id" : 373341900301811712,
  "created_at" : "2013-08-30 07:10:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1707852958, 8.6235256959 ]
  },
  "id_str" : "373336702880071680",
  "text" : "Gehaltfreie Kommunikation",
  "id" : 373336702880071680,
  "created_at" : "2013-08-30 06:49:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spam",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1670705372, 8.6344919495 ]
  },
  "id_str" : "373335742980055040",
  "text" : "\u00ABMore remains to be written about the role of graduate student poverty and parsimony in shaping the hacker ethos.\u00BB #spam",
  "id" : 373335742980055040,
  "created_at" : "2013-08-30 06:45:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spam",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1029193422, 8.6556002896 ]
  },
  "id_str" : "373329587721482240",
  "text" : "\u00ABThe Order of Wizards in Middle Earth, the Jedi Council, the Linux kernel programmers: the group operates on rough consensus [\u2026]\u00BB #spam",
  "id" : 373329587721482240,
  "created_at" : "2013-08-30 06:21:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/CK3QdTFj2D",
      "expanded_url" : "http:\/\/chainsawsuit.com\/2013\/07\/10\/joy-detector\/",
      "display_url" : "chainsawsuit.com\/2013\/07\/10\/joy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373229320887861248",
  "text" : "RT @PhilippBayer: Can we have a Kickstarter for this machine? It seems like it must be built by Germans http:\/\/t.co\/CK3QdTFj2D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/CK3QdTFj2D",
        "expanded_url" : "http:\/\/chainsawsuit.com\/2013\/07\/10\/joy-detector\/",
        "display_url" : "chainsawsuit.com\/2013\/07\/10\/joy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373228876127670272",
    "text" : "Can we have a Kickstarter for this machine? It seems like it must be built by Germans http:\/\/t.co\/CK3QdTFj2D",
    "id" : 373228876127670272,
    "created_at" : "2013-08-29 23:41:12 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 373229320887861248,
  "created_at" : "2013-08-29 23:42:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Q9ZXpKP8Ck",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/science-with-moxie\/2013\/08\/29\/its-what-you-see-at-the-concert-not-what-you-hear\/",
      "display_url" : "blogs.scientificamerican.com\/science-with-m\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373221298291613697",
  "text" : "It\u2019s what you see at the concert, not what you hear http:\/\/t.co\/Q9ZXpKP8Ck",
  "id" : 373221298291613697,
  "created_at" : "2013-08-29 23:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373217809989255168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373218198914859008",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I obviously didn\u2019t\u2026",
  "id" : 373218198914859008,
  "in_reply_to_status_id" : 373217809989255168,
  "created_at" : "2013-08-29 22:58:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373217238636969984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967684, 8.2830217975 ]
  },
  "id_str" : "373217579663642624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lecturing you about poly terminology is clearly a lost cause. But even in your age you still might get that repulsion != attraction.",
  "id" : 373217579663642624,
  "in_reply_to_status_id" : 373217238636969984,
  "created_at" : "2013-08-29 22:56:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373214746276659200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009695285, 8.28305154 ]
  },
  "id_str" : "373215502958886912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u2018repulsive\u2019? You keep using that word, I do not think it means what you think it means!",
  "id" : 373215502958886912,
  "in_reply_to_status_id" : 373214746276659200,
  "created_at" : "2013-08-29 22:48:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/8o02YEXON9",
      "expanded_url" : "http:\/\/i.imgur.com\/dAPcJ6L.gif",
      "display_url" : "i.imgur.com\/dAPcJ6L.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009639074, 8.282997336 ]
  },
  "id_str" : "373213251003482112",
  "text" : "The side effects of unicorn hunting http:\/\/t.co\/8o02YEXON9",
  "id" : 373213251003482112,
  "created_at" : "2013-08-29 22:39:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 8, 13 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373211614444793856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964625, 8.28303787 ]
  },
  "id_str" : "373211993496637441",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @johl Alle kommerz. Dinge die auf Basis deiner Videos entstehen m\u00FCssen Share-Alike sein -&gt; Bleiben also auch unter CC verf\u00FCgbar",
  "id" : 373211993496637441,
  "in_reply_to_status_id" : 373211614444793856,
  "created_at" : "2013-08-29 22:34:07 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 8, 13 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373210701088960512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964625, 8.28303787 ]
  },
  "id_str" : "373211488481468417",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @johl f\u00FCr die meisten F\u00E4lle reicht da -SA schon aus.",
  "id" : 373211488481468417,
  "in_reply_to_status_id" : 373210701088960512,
  "created_at" : "2013-08-29 22:32:07 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373204059182071808",
  "text" : "\u00ABUnsere dramat. Abschiedsszenen sind von deiner Seite aus shortcutted?\u00BB \u2013 \u00ABKomplett scriptet, dein beschr\u00E4nktes Vokabular macht es einfach.\u00BB",
  "id" : 373204059182071808,
  "created_at" : "2013-08-29 22:02:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/vu8ZwZRnJx",
      "expanded_url" : "https:\/\/theconversation.com\/shakespeare-and-cancer-diagnoses-how-bard-can-it-be-15381",
      "display_url" : "theconversation.com\/shakespeare-an\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373200702195400705",
  "text" : "Shakespeare and cancer diagnoses: how bard can it be? https:\/\/t.co\/vu8ZwZRnJx",
  "id" : 373200702195400705,
  "created_at" : "2013-08-29 21:49:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/DjSY3K1Vcj",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0070488",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373199081868632065",
  "text" : "Grad students all over the world will read this as \u00ABIn Situ Ramen Study\u00BB http:\/\/t.co\/DjSY3K1Vcj",
  "id" : 373199081868632065,
  "created_at" : "2013-08-29 21:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/M6srsRirLm",
      "expanded_url" : "http:\/\/imgur.com\/r\/aww\/cHEHhzw",
      "display_url" : "imgur.com\/r\/aww\/cHEHhzw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373194365839376384",
  "text" : "Identity Crisis http:\/\/t.co\/M6srsRirLm",
  "id" : 373194365839376384,
  "created_at" : "2013-08-29 21:24:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373183592924721153",
  "text" : "\u00ABHast du auch noch Hunger?\u00BB \u2013 \u00ABNein, ich esse gleich Eis.\u00BB",
  "id" : 373183592924721153,
  "created_at" : "2013-08-29 20:41:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/6G4qcZ209q",
      "expanded_url" : "http:\/\/i.imgur.com\/i15DM4Z.jpg",
      "display_url" : "i.imgur.com\/i15DM4Z.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373180914446393344",
  "text" : "Godzilla (the early days) http:\/\/t.co\/6G4qcZ209q",
  "id" : 373180914446393344,
  "created_at" : "2013-08-29 20:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373178722389880832",
  "text" : "\u00ABSorry, ich hab gerade keine Zeit mir Hass auf Twitter anzuschauen. Ich muss Hundebildchen browsen.\u00BB",
  "id" : 373178722389880832,
  "created_at" : "2013-08-29 20:21:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/vk9FkzfvMx",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/e2e4b4acf15bb32c187746e4505f024d\/tumblr_ms0t86tTxZ1rkg4zto1_500.gif",
      "display_url" : "24.media.tumblr.com\/e2e4b4acf15bb3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373161681314410496",
  "text" : "Twitter (Symbolfoto) http:\/\/t.co\/vk9FkzfvMx",
  "id" : 373161681314410496,
  "created_at" : "2013-08-29 19:14:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "50 Prozent",
      "screen_name" : "haelfte",
      "indices" : [ 0, 8 ],
      "id_str" : "1400899219",
      "id" : 1400899219
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 9, 15 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 16, 20 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373150237042307072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095849271, 8.2829006443 ]
  },
  "id_str" : "373150865211031552",
  "in_reply_to_user_id" : 1400899219,
  "text" : "@haelfte @_Rya_ @scy Dann stimmen die 15 Frauen, 17 M\u00E4nner f\u00FCr das regul\u00E4re Programm. Im Barcamp: 3 Frauen, 10 M\u00E4nner.",
  "id" : 373150865211031552,
  "in_reply_to_status_id" : 373150237042307072,
  "created_at" : "2013-08-29 18:31:13 +0000",
  "in_reply_to_screen_name" : "haelfte",
  "in_reply_to_user_id_str" : "1400899219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 5, 11 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "50 Prozent",
      "screen_name" : "haelfte",
      "indices" : [ 12, 20 ],
      "id_str" : "1400899219",
      "id" : 1400899219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373136558280671232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373137774079410176",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @_Rya_ @haelfte hab\u2019s nur \u00FCberflogen, aber unter allen Teilnehmenden ~ 1\/3.",
  "id" : 373137774079410176,
  "in_reply_to_status_id" : 373136558280671232,
  "created_at" : "2013-08-29 17:39:12 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373132903812575233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373133583650942976",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a In that case I probably found it somewhere online (best guess would be boingboing).",
  "id" : 373133583650942976,
  "in_reply_to_status_id" : 373132903812575233,
  "created_at" : "2013-08-29 17:22:33 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373132903812575233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373133425802510336",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Okay, if you only read it in April 2013 as Goodreads suggests you\u2019re probably right. I read from Sep 18-20 2012. :)",
  "id" : 373133425802510336,
  "in_reply_to_status_id" : 373132903812575233,
  "created_at" : "2013-08-29 17:21:55 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373133057605521408",
  "text" : "An die #om13 Referent*innen auch hier der Hinweis: Wenn ihr uns eure Slides an info@openmind-konferenz.de mailt kommen sie zum Fahrplan.",
  "id" : 373133057605521408,
  "created_at" : "2013-08-29 17:20:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "50 Prozent",
      "screen_name" : "haelfte",
      "indices" : [ 12, 20 ],
      "id_str" : "1400899219",
      "id" : 1400899219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373131696369307648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373131812303675393",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @scy @haelfte Achso, ich dachte an die Referent*innen. :)",
  "id" : 373131812303675393,
  "in_reply_to_status_id" : 373131696369307648,
  "created_at" : "2013-08-29 17:15:31 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "50 Prozent",
      "screen_name" : "haelfte",
      "indices" : [ 12, 20 ],
      "id_str" : "1400899219",
      "id" : 1400899219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373130021797642240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "373131516681158656",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @scy @haelfte Im offiziellen Programm (nicht Barcamp): 17 M\u00E4nner, 15 Frauen wenn ich mich nicht verz\u00E4hlt habe.",
  "id" : 373131516681158656,
  "in_reply_to_status_id" : 373130021797642240,
  "created_at" : "2013-08-29 17:14:20 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/0vN3RzfDws",
      "expanded_url" : "http:\/\/instagram.com\/p\/dmsiM3BwsM\/",
      "display_url" : "instagram.com\/p\/dmsiM3BwsM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "373127598911807488",
  "text" : "\u00ABIm Vergleich zu den Bisswunden von dir sind die Kratzer von den Katzen harmlos!\u00BB @ Elfenbeinturm http:\/\/t.co\/0vN3RzfDws",
  "id" : 373127598911807488,
  "created_at" : "2013-08-29 16:58:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008651882, 8.2924289272 ]
  },
  "id_str" : "373109790287093760",
  "text" : "\u00ABSir! I have a plan\u2026 Mein F\u00FChrer, I can troll!\u00BB",
  "id" : 373109790287093760,
  "created_at" : "2013-08-29 15:48:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 85, 94 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/5APhKDD3c3",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/8d96f7d169b76f81fce31fffacfbc377\/tumblr_mhcbzameAC1rjhn1to1_500.gif",
      "display_url" : "24.media.tumblr.com\/8d96f7d169b76f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009606, 8.282911 ]
  },
  "id_str" : "373099883986948096",
  "text" : "Unterdessen huldige ich einfach im #om13 Bunker als Reichscontentminister der gro\u00DFen @senficon &lt;3 http:\/\/t.co\/5APhKDD3c3",
  "id" : 373099883986948096,
  "created_at" : "2013-08-29 15:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096423652, 8.2829444743 ]
  },
  "id_str" : "373095425491742720",
  "text" : "\u00ABOkay, Miezi liegt auf der Couch. Aber wo ist Miller?\u00BB \u2014 \u00ABAlso im Bett ist er nicht, da habe ich ganz genau geschaut.\u00BB",
  "id" : 373095425491742720,
  "created_at" : "2013-08-29 14:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373090027779014656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007971411, 8.2824191324 ]
  },
  "id_str" : "373091302201913344",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Wool lag bei mir ~1 Jahr zur\u00FCck als ich jetzt Shift gelesen habe, deshalb war der Einstieg etwas schwer. Dann fand ich es gut.",
  "id" : 373091302201913344,
  "in_reply_to_status_id" : 373090027779014656,
  "created_at" : "2013-08-29 14:34:32 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007971411, 8.2824191324 ]
  },
  "id_str" : "373090289000656896",
  "text" : "\u00ABMal schauen wie sehr die Katzen mich zerkratzen wenn ich sie zum Tierarzt bringen will.\u00BB \u2014 \u00ABPass auf dich auf. Oder mach Fotos!\u00BB",
  "id" : 373090289000656896,
  "created_at" : "2013-08-29 14:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/hmIVgcGruO",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/eoBVfiPfRo8\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373084211257049088",
  "text" : "Unofficial Monty Python-Lego-Sets http:\/\/t.co\/hmIVgcGruO",
  "id" : 373084211257049088,
  "created_at" : "2013-08-29 14:06:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 86, 91 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0410569734, 8.4600556537 ]
  },
  "id_str" : "373083731768377344",
  "text" : "Finally made it through all of the great Wool\/Shift\/Silo series. iirc I have to thank @li5a for the recommendation.",
  "id" : 373083731768377344,
  "created_at" : "2013-08-29 14:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373065615600123904",
  "geo" : { },
  "id_str" : "373066307513483264",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt Ich leide darunter doch genauso wie du! (und jetzt schon wieder!)",
  "id" : 373066307513483264,
  "in_reply_to_status_id" : 373065615600123904,
  "created_at" : "2013-08-29 12:55:13 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/8QnxFWD5C7",
      "expanded_url" : "http:\/\/weknowmemes.com\/wp-content\/uploads\/2012\/05\/chewbaccas-penis.jpg",
      "display_url" : "weknowmemes.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "373062066673692672",
  "geo" : { },
  "id_str" : "373065396460331009",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I guess this says it more or less http:\/\/t.co\/8QnxFWD5C7",
  "id" : 373065396460331009,
  "in_reply_to_status_id" : 373062066673692672,
  "created_at" : "2013-08-29 12:51:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/DQ1StoIrmF",
      "expanded_url" : "http:\/\/www.nature.com\/news\/just-thinking-about-science-triggers-moral-behavior-1.13616",
      "display_url" : "nature.com\/news\/just-thin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373057073996914688",
  "text" : "RT @PhilippBayer: This feels weird. \"Just thinking about science triggers moral behavior\" http:\/\/t.co\/DQ1StoIrmF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/DQ1StoIrmF",
        "expanded_url" : "http:\/\/www.nature.com\/news\/just-thinking-about-science-triggers-moral-behavior-1.13616",
        "display_url" : "nature.com\/news\/just-thin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372849334837972992",
    "text" : "This feels weird. \"Just thinking about science triggers moral behavior\" http:\/\/t.co\/DQ1StoIrmF",
    "id" : 372849334837972992,
    "created_at" : "2013-08-28 22:33:03 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 373057073996914688,
  "created_at" : "2013-08-29 12:18:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373053149126213632",
  "text" : "\u00ABDid you fall asleep over your BLAST results?\u00BB \u2013 \u00ABYeah, sorry. I somehow parsed out.\u00BB",
  "id" : 373053149126213632,
  "created_at" : "2013-08-29 12:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/B6cGUPJjaA",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Standhitze",
      "display_url" : "de.wikipedia.org\/wiki\/Standhitze"
    } ]
  },
  "geo" : { },
  "id_str" : "373051606696067072",
  "text" : "TIL: Standhitze http:\/\/t.co\/B6cGUPJjaA",
  "id" : 373051606696067072,
  "created_at" : "2013-08-29 11:56:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373049739253530625",
  "geo" : { },
  "id_str" : "373049853678325760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that came out wrong! ;)",
  "id" : 373049853678325760,
  "in_reply_to_status_id" : 373049739253530625,
  "created_at" : "2013-08-29 11:49:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/bt9GAplkrN",
      "expanded_url" : "http:\/\/imgur.com\/a\/fUD7n",
      "display_url" : "imgur.com\/a\/fUD7n"
    } ]
  },
  "geo" : { },
  "id_str" : "373048429049438208",
  "text" : "\u00ABI'm not a topologist or anything, but\u2026\u00BB - Doughnut game worlds http:\/\/t.co\/bt9GAplkrN",
  "id" : 373048429049438208,
  "created_at" : "2013-08-29 11:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373046280294895617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172300516, 8.6276456816 ]
  },
  "id_str" : "373047835207684096",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it\u2019s not the size of the boat\u2026 ;)",
  "id" : 373047835207684096,
  "in_reply_to_status_id" : 373046280294895617,
  "created_at" : "2013-08-29 11:41:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373046817157427200",
  "text" : "\u00ABWieso sagt deine Unterw\u00E4sche 'average boxer'?\u00BB \u2013 \u00ABDruckfehler, sie meinten 'Durchshitlich'.\u00BB",
  "id" : 373046817157427200,
  "created_at" : "2013-08-29 11:37:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373035891679195136",
  "geo" : { },
  "id_str" : "373036200765816832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot weil ich mich kurz mit einem Kaffee raus in die Sonne in den Pool gelegt habe. ;)",
  "id" : 373036200765816832,
  "in_reply_to_status_id" : 373035891679195136,
  "created_at" : "2013-08-29 10:55:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/lHws5OlGFC",
      "expanded_url" : "http:\/\/instagram.com\/p\/dmCf9IhwoR\/",
      "display_url" : "instagram.com\/p\/dmCf9IhwoR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "373035448828190720",
  "text" : "\u00ABWas machst du gerade?\u00BB \u2014 \u00ABMoment, ich schicke dir ein Symbolbild.\u00BB @ Biologicum http:\/\/t.co\/lHws5OlGFC",
  "id" : 373035448828190720,
  "created_at" : "2013-08-29 10:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373031272638996480",
  "geo" : { },
  "id_str" : "373032706113675264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I was a bit puzzled what Hunter S would love about that? But you probably talk about John N, right?",
  "id" : 373032706113675264,
  "in_reply_to_status_id" : 373031272638996480,
  "created_at" : "2013-08-29 10:41:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373024050429194240",
  "text" : "re last tweet: I'm too aware of all the drawbacks of positive selection studies like these, but still: It's fun to find expected candidates.",
  "id" : 373024050429194240,
  "created_at" : "2013-08-29 10:07:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 131, 144 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/RAibPjGqm1",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0074938#s4",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373023461716660225",
  "text" : "Signatures of Rapid Evolution in Urban &amp; Rural Transcriptomes of White-Footed Mice in the NY Metro Area http:\/\/t.co\/RAibPjGqm1 @PhilippBayer",
  "id" : 373023461716660225,
  "created_at" : "2013-08-29 10:04:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 53, 62 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/XK8WpGUosA",
      "expanded_url" : "http:\/\/www.companionanimalpsychology.com\/2013\/08\/is-income-inequality-linked-to-animal.html",
      "display_url" : "companionanimalpsychology.com\/2013\/08\/is-inc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373020245071384576",
  "text" : "Is Income (In)Equality Linked to Animal Welfare? \/cc @Roterhai http:\/\/t.co\/XK8WpGUosA",
  "id" : 373020245071384576,
  "created_at" : "2013-08-29 09:52:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/DlZmD5K9pP",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072269",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373018181599637505",
  "text" : "A Reassessment of Bergmann's Rule in Modern Humans http:\/\/t.co\/DlZmD5K9pP",
  "id" : 373018181599637505,
  "created_at" : "2013-08-29 09:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/S0HnWZFiEd",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072479",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373015590065020928",
  "text" : "TV Fast Food Marketing \u00ABChildren\u2019s advertisements emphasized toy giveaways &amp; movie tie-ins rather than food products\u00BB http:\/\/t.co\/S0HnWZFiEd",
  "id" : 373015590065020928,
  "created_at" : "2013-08-29 09:33:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722694988, 8.6277403857 ]
  },
  "id_str" : "373009911720189952",
  "text" : "\u00ABWas zur H\u00F6lle tust du da?\u00BB \u2014 \u00ABMir einen Kindheitstraum erf\u00FCllen!\u00BB \u2014 \u00ABMit Kaffeebohnen werfen? Klingt mehr nach Kindheitstrauma\u2026\u00BB",
  "id" : 373009911720189952,
  "created_at" : "2013-08-29 09:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723178012, 8.6276214702 ]
  },
  "id_str" : "373005462499000320",
  "text" : "Yo dawg, I herd you like predictions. So I made a protein prediction based on a \u2018hypothetical protein-like protein' prediction!",
  "id" : 373005462499000320,
  "created_at" : "2013-08-29 08:53:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723203285, 8.6276375384 ]
  },
  "id_str" : "372999845323476993",
  "text" : "\u00ABDas du mich verl\u00E4sst halte ich f\u00FCr wahrscheinlicher als das dich \u00FCber Nacht der in deinem Fall extrem versp\u00E4tete Kindstod ereilt.\u00BB",
  "id" : 372999845323476993,
  "created_at" : "2013-08-29 08:31:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/r1D107ab0C",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072211",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372994940973744128",
  "text" : "Why Are Product Prices in Online Markets Not Converging? http:\/\/t.co\/r1D107ab0C",
  "id" : 372994940973744128,
  "created_at" : "2013-08-29 08:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/iy1qyA1hDB",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/polyamory\/comments\/1l9b04\/just_found_on_my_fb_newsfeed_what_everyone_else\/",
      "display_url" : "reddit.com\/r\/polyamory\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096214982, 8.2830105443 ]
  },
  "id_str" : "372857894511075328",
  "text" : "\u00ABWhat if polyamory is a movement that needed free shared calendars to take off?\u00BB http:\/\/t.co\/iy1qyA1hDB",
  "id" : 372857894511075328,
  "created_at" : "2013-08-28 23:07:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/XI0y9kcY5D",
      "expanded_url" : "http:\/\/www.qmed.com\/mpmn\/medtechpulse\/drones-could-give-heart-patients-fast-access-defibrillators-remote-areas?cid=nl.qmed01",
      "display_url" : "qmed.com\/mpmn\/medtechpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372856831041110016",
  "text" : "RT @yokofakun: \"Drones Could Give Heart Patients Fast Access to Defibrillators in Remote Areas\" http:\/\/t.co\/XI0y9kcY5D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/XI0y9kcY5D",
        "expanded_url" : "http:\/\/www.qmed.com\/mpmn\/medtechpulse\/drones-could-give-heart-patients-fast-access-defibrillators-remote-areas?cid=nl.qmed01",
        "display_url" : "qmed.com\/mpmn\/medtechpu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372856447341981696",
    "text" : "\"Drones Could Give Heart Patients Fast Access to Defibrillators in Remote Areas\" http:\/\/t.co\/XI0y9kcY5D",
    "id" : 372856447341981696,
    "created_at" : "2013-08-28 23:01:19 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 372856831041110016,
  "created_at" : "2013-08-28 23:02:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "372849744886104064",
  "text" : "\u00ABIch fand das Buch nicht so gut. Das war so eine Wall of Text.\u00BB",
  "id" : 372849744886104064,
  "created_at" : "2013-08-28 22:34:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Funk",
      "screen_name" : "cantfakethefunk",
      "indices" : [ 3, 19 ],
      "id_str" : "13796782",
      "id" : 13796782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372833326362812416",
  "text" : "RT @cantfakethefunk: \"I'm not a misandrist, but I just don't think boys are as interested in gaming as women are...\" Ha, this is great http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UirCGPBkQs",
        "expanded_url" : "http:\/\/imnotamisandristbut.tumblr.com\/post\/59044103214\/im-not-a-misandrist-but-i-just-dont-think-boys",
        "display_url" : "imnotamisandristbut.tumblr.com\/post\/590441032\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370955354500112384",
    "text" : "\"I'm not a misandrist, but I just don't think boys are as interested in gaming as women are...\" Ha, this is great http:\/\/t.co\/UirCGPBkQs",
    "id" : 370955354500112384,
    "created_at" : "2013-08-23 17:07:03 +0000",
    "user" : {
      "name" : "John Funk",
      "screen_name" : "cantfakethefunk",
      "protected" : false,
      "id_str" : "13796782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627604374815154177\/dfe6mqN9_normal.jpg",
      "id" : 13796782,
      "verified" : false
    }
  },
  "id" : 372833326362812416,
  "created_at" : "2013-08-28 21:29:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/f27W55879z",
      "expanded_url" : "http:\/\/www.kernelmag.com\/features\/report\/4732\/my-gruelling-day-as-an-amazon-mechanical-turk\/",
      "display_url" : "kernelmag.com\/features\/repor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "372831480382496768",
  "text" : "\u00ABI half-expected Mechanical Turk to be a window to some terrifying dystopian future, but\u2026\u00BB http:\/\/t.co\/f27W55879z",
  "id" : 372831480382496768,
  "created_at" : "2013-08-28 21:22:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Data Borat",
      "screen_name" : "BigDataBorat",
      "indices" : [ 3, 16 ],
      "id_str" : "539296619",
      "id" : 539296619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372824767835160576",
  "text" : "RT @BigDataBorat: R is domain specific language for sadomasochist with number fetish.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361628648115146754",
    "text" : "R is domain specific language for sadomasochist with number fetish.",
    "id" : 361628648115146754,
    "created_at" : "2013-07-28 23:26:03 +0000",
    "user" : {
      "name" : "Big Data Borat",
      "screen_name" : "BigDataBorat",
      "protected" : false,
      "id_str" : "539296619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1979623485\/borat_normal.jpg",
      "id" : 539296619,
      "verified" : false
    }
  },
  "id" : 372824767835160576,
  "created_at" : "2013-08-28 20:55:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692805, 8.2830364 ]
  },
  "id_str" : "372816925891772416",
  "text" : "Die armen, falsch zitierten Trolle: \u00ABVon \u2019Ihr geh\u00F6rt nur mal ordentlich durchgev\u00F6gelt\u2019 war nie die Rede. \u2018Gefickt\u2019 war das Wort!\u00BB m( #om13",
  "id" : 372816925891772416,
  "created_at" : "2013-08-28 20:24:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782467, 8.283017455 ]
  },
  "id_str" : "372807971811885057",
  "text" : "Good news: You can now also upload AncestryDNA files to openSNP and they will get parsed correctly.",
  "id" : 372807971811885057,
  "created_at" : "2013-08-28 19:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus \u99AC\u516D \uD83C\uDDEA\uD83C\uDDFA\uD83C\uDDED\uD83C\uDDF0",
      "screen_name" : "sixtus",
      "indices" : [ 0, 7 ],
      "id_str" : "9334352",
      "id" : 9334352
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 8, 19 ],
      "id_str" : "58569837",
      "id" : 58569837
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 20, 26 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372802745427714048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782467, 8.283017455 ]
  },
  "id_str" : "372803034021367808",
  "in_reply_to_user_id" : 9334352,
  "text" : "@sixtus @leitmedium @tante verst\u00E4ndlich, aus genau den Gr\u00FCnden habe ich auch nicht weiter zur\u00FCck in den Stammbaum gefragt.",
  "id" : 372803034021367808,
  "in_reply_to_status_id" : 372802745427714048,
  "created_at" : "2013-08-28 19:29:04 +0000",
  "in_reply_to_screen_name" : "sixtus",
  "in_reply_to_user_id_str" : "9334352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus \u99AC\u516D \uD83C\uDDEA\uD83C\uDDFA\uD83C\uDDED\uD83C\uDDF0",
      "screen_name" : "sixtus",
      "indices" : [ 0, 7 ],
      "id_str" : "9334352",
      "id" : 9334352
    }, {
      "name" : "Caspar C. Mierau",
      "screen_name" : "leitmedium",
      "indices" : [ 8, 19 ],
      "id_str" : "58569837",
      "id" : 58569837
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 20, 26 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/q2HISdHwxN",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/bierologie\/biologie\/2012-04-15\/der-prostatakrebs-meine-gene-und-ich",
      "display_url" : "scilogs.de\/wblogs\/blog\/bi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372801676811313152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782467, 8.283017455 ]
  },
  "id_str" : "372801987341217792",
  "in_reply_to_user_id" : 9334352,
  "text" : "@sixtus @leitmedium @tante as in http:\/\/t.co\/q2HISdHwxN Deshalb hatte ich meine Eltern vor der Ver\u00F6ffentlichung ebenfalls gefragt.",
  "id" : 372801987341217792,
  "in_reply_to_status_id" : 372801676811313152,
  "created_at" : "2013-08-28 19:24:54 +0000",
  "in_reply_to_screen_name" : "sixtus",
  "in_reply_to_user_id_str" : "9334352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/IxJL8ZX3vs",
      "expanded_url" : "http:\/\/instagram.com\/p\/dkTwHrBwmo\/",
      "display_url" : "instagram.com\/p\/dkTwHrBwmo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "372791425211310080",
  "text" : "Upper Class Baumhaus http:\/\/t.co\/IxJL8ZX3vs",
  "id" : 372791425211310080,
  "created_at" : "2013-08-28 18:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/oBW2QD6sbo",
      "expanded_url" : "http:\/\/instagram.com\/p\/dkTVhvBwlw\/",
      "display_url" : "instagram.com\/p\/dkTVhvBwlw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "372790461104394241",
  "text" : "Semesterferien http:\/\/t.co\/oBW2QD6sbo",
  "id" : 372790461104394241,
  "created_at" : "2013-08-28 18:39:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009238829, 8.2816568302 ]
  },
  "id_str" : "372774510204035072",
  "text" : "\u00ABDu lachst ja gar nicht \u00FCber meine Anal Fisting-Witze? Oh, ich blute ja. An der Hand!\u00BB \u2014 \u00ABDu machst es nicht besser\u2026\u00BB",
  "id" : 372774510204035072,
  "created_at" : "2013-08-28 17:35:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0199891607, 8.4325825707 ]
  },
  "id_str" : "372761100674404352",
  "text" : "\u00ABWie ich gerade erfahren habe - als mein Zug an der Weiche ohne mein Wissen falsch abgebogen ist - f\u00E4hrt diese S9 heute wie die S1.\u00BB",
  "id" : 372761100674404352,
  "created_at" : "2013-08-28 16:42:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Neumann",
      "screen_name" : "fxneumann",
      "indices" : [ 3, 13 ],
      "id_str" : "43292041",
      "id" : 43292041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/DbsnERRhSR",
      "expanded_url" : "http:\/\/pocket.co\/sswR7",
      "display_url" : "pocket.co\/sswR7"
    } ]
  },
  "geo" : { },
  "id_str" : "372736811484712960",
  "text" : "RT @fxneumann: Mehr davon: Liebeserkl\u00E4rungen an Fritiergut. \u00BBhushpuppies are cornmeal in a state of grace.\u00AB http:\/\/t.co\/DbsnERRhSR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/DbsnERRhSR",
        "expanded_url" : "http:\/\/pocket.co\/sswR7",
        "display_url" : "pocket.co\/sswR7"
      } ]
    },
    "geo" : { },
    "id_str" : "372736473931739137",
    "text" : "Mehr davon: Liebeserkl\u00E4rungen an Fritiergut. \u00BBhushpuppies are cornmeal in a state of grace.\u00AB http:\/\/t.co\/DbsnERRhSR",
    "id" : 372736473931739137,
    "created_at" : "2013-08-28 15:04:35 +0000",
    "user" : {
      "name" : "Felix Neumann",
      "screen_name" : "fxneumann",
      "protected" : false,
      "id_str" : "43292041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425920335586668544\/TM936pUx_normal.jpeg",
      "id" : 43292041,
      "verified" : false
    }
  },
  "id" : 372736811484712960,
  "created_at" : "2013-08-28 15:05:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ibjEPKNycr",
      "expanded_url" : "http:\/\/www.mymodernmet.com\/profiles\/blogs\/ulric-collette-therianthropes",
      "display_url" : "mymodernmet.com\/profiles\/blogs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372735904911065088",
  "text" : "That's some interesting interspecies erotica! http:\/\/t.co\/ibjEPKNycr",
  "id" : 372735904911065088,
  "created_at" : "2013-08-28 15:02:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372728080554786816",
  "geo" : { },
  "id_str" : "372730437040234496",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Breaking: Gr\u00FCner BT-Kandidat will uns alle zur\u00FCck in die Steinzeit kalorienbomben!",
  "id" : 372730437040234496,
  "in_reply_to_status_id" : 372728080554786816,
  "created_at" : "2013-08-28 14:40:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/u38WABcbe7",
      "expanded_url" : "http:\/\/hackingdistributed.com\/2013\/08\/02\/metadata\/",
      "display_url" : "hackingdistributed.com\/2013\/08\/02\/met\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372720108491128832",
  "text" : "RT @ctitusbrown: \"the intelligence community ... never met-a-data that it didn't want to collect\" http:\/\/t.co\/u38WABcbe7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/u38WABcbe7",
        "expanded_url" : "http:\/\/hackingdistributed.com\/2013\/08\/02\/metadata\/",
        "display_url" : "hackingdistributed.com\/2013\/08\/02\/met\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372717775636033536",
    "text" : "\"the intelligence community ... never met-a-data that it didn't want to collect\" http:\/\/t.co\/u38WABcbe7",
    "id" : 372717775636033536,
    "created_at" : "2013-08-28 13:50:17 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 372720108491128832,
  "created_at" : "2013-08-28 13:59:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/MdbBp4qsYC",
      "expanded_url" : "http:\/\/www.mccullagh.org\/db9\/1ds3-3\/flintstones-art-car.jpg",
      "display_url" : "mccullagh.org\/db9\/1ds3-3\/fli\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372713496359604224",
  "geo" : { },
  "id_str" : "372716450605068288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Paleo-Autos sind ideal f\u00FCr Crossfit! http:\/\/t.co\/MdbBp4qsYC",
  "id" : 372716450605068288,
  "in_reply_to_status_id" : 372713496359604224,
  "created_at" : "2013-08-28 13:45:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372715088769077248",
  "text" : "\u00ABIch sehe das Mensa-Personal h\u00E4ufiger als dich\u2026\u00BB \u2013 \u00ABDas heisst nicht unbedingt das ich wenig im B\u00FCro bin. Du k\u00F6nntest sehr verfressen sein!\u00BB",
  "id" : 372715088769077248,
  "created_at" : "2013-08-28 13:39:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/NQnb0pDggN",
      "expanded_url" : "http:\/\/www.polyneux.de\/archiv\/705-frauenflyer.html",
      "display_url" : "polyneux.de\/archiv\/705-fra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372700349699592193",
  "text" : "\u00ABA, B, CD in BH\u00BB http:\/\/t.co\/NQnb0pDggN",
  "id" : 372700349699592193,
  "created_at" : "2013-08-28 12:41:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372696209506332673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724656998, 8.6275455728 ]
  },
  "id_str" : "372697156119191552",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil wieso auch einfach -v=5, wer verbose Output will muss genauso seinen Input geben!",
  "id" : 372697156119191552,
  "in_reply_to_status_id" : 372696209506332673,
  "created_at" : "2013-08-28 12:28:21 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372696012994789376",
  "text" : "\u00AB--verbose=n: verbosity level 0, 1, 2, 3. Default: 2. You can also use a shortcut: \"-v\", \"-v -v\" or \"-v -v -v\"\u00BB",
  "id" : 372696012994789376,
  "created_at" : "2013-08-28 12:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722969823, 8.6276536807 ]
  },
  "id_str" : "372669605564923904",
  "text" : "\u00ABDas kommt in die Acknowledgements meiner Bachelorarbeit: \u201EAlles was ich \u00FCber Evolution wei\u00DF habe ich vom \u2018Jurassic Park Builder\u2019 gelernt\u201D.\u00BB",
  "id" : 372669605564923904,
  "created_at" : "2013-08-28 10:38:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722941845, 8.6276536071 ]
  },
  "id_str" : "372665815994490880",
  "text" : "Barebacktracking",
  "id" : 372665815994490880,
  "created_at" : "2013-08-28 10:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724798659, 8.6273504099 ]
  },
  "id_str" : "372644195062013952",
  "text" : "\u00ABOrr Hund! Das hei\u00DFt \u2018l\u00E4ufig\u2019, nicht \u2018ausl\u00E4ufig\u2019!\u00BB",
  "id" : 372644195062013952,
  "created_at" : "2013-08-28 08:57:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eDceM3o1Jc",
      "expanded_url" : "http:\/\/blog.okfn.org\/2013\/08\/27\/open-data-privacy\/",
      "display_url" : "blog.okfn.org\/2013\/08\/27\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372641608715341824",
  "text" : "\u201Cyes, the government should open other people\u2019s data\u201D The OKNF about Open Data Privacy http:\/\/t.co\/eDceM3o1Jc",
  "id" : 372641608715341824,
  "created_at" : "2013-08-28 08:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1702401368, 8.622943908 ]
  },
  "id_str" : "372629428662444032",
  "text" : "\u00ABGuten Morgen Mr. SysAdmin. Hei\u00DFgelaufene Server aus deiner Umgebung warten schon auf dich!\u00BB",
  "id" : 372629428662444032,
  "created_at" : "2013-08-28 07:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372512627420721152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096255033, 8.2830299981 ]
  },
  "id_str" : "372512904618459136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer now I have to generate random answers and save them somewhere just in case one day I will need them.",
  "id" : 372512904618459136,
  "in_reply_to_status_id" : 372512627420721152,
  "created_at" : "2013-08-28 00:16:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372512058681470977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096255033, 8.2830299981 ]
  },
  "id_str" : "372512672824434689",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, Apple forced me to do the same after the remote wipe-thing happening to that WIRED-author.",
  "id" : 372512672824434689,
  "in_reply_to_status_id" : 372512058681470977,
  "created_at" : "2013-08-28 00:15:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372511327463301120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009701329, 8.2830354951 ]
  },
  "id_str" : "372512179209400322",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2018generate this key using your auth device. Or tell us your mother\u2019s maiden name which can be googled in 10 seconds'",
  "id" : 372512179209400322,
  "in_reply_to_status_id" : 372511327463301120,
  "created_at" : "2013-08-28 00:13:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372511327463301120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009701329, 8.2830354951 ]
  },
  "id_str" : "372511706758787072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019ve no idea, and don\u2019t get me started on services that use \u2018security\u2019 questions that can override 2-factor auth, e.g. PayPal.",
  "id" : 372511706758787072,
  "in_reply_to_status_id" : 372511327463301120,
  "created_at" : "2013-08-28 00:11:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372510891855454208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009701329, 8.2830354951 ]
  },
  "id_str" : "372511152376672256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my bank only allows 5-digit PINs for online banking iirc\u2026",
  "id" : 372511152376672256,
  "in_reply_to_status_id" : 372510891855454208,
  "created_at" : "2013-08-28 00:09:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ow3aJPJC8V",
      "expanded_url" : "http:\/\/i.minus.com\/ibk1u316eZLQ03.gif",
      "display_url" : "i.minus.com\/ibk1u316eZLQ03\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009664, 8.283091 ]
  },
  "id_str" : "372503808964067330",
  "text" : "Southpaw woes http:\/\/t.co\/ow3aJPJC8V",
  "id" : 372503808964067330,
  "created_at" : "2013-08-27 23:40:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/bmfuRtQD96",
      "expanded_url" : "http:\/\/www.colorsmagazine.com\/stories\/magazine\/83\/story\/beat-your-intimacy-issues",
      "display_url" : "colorsmagazine.com\/stories\/magazi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667, 8.283046 ]
  },
  "id_str" : "372499528207044608",
  "text" : "\u00ABMarisco and N.H are trained therapists, and they are llamas.\u00BB http:\/\/t.co\/bmfuRtQD96",
  "id" : 372499528207044608,
  "created_at" : "2013-08-27 23:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JKucTjcBZ4",
      "expanded_url" : "http:\/\/violentmetaphors.com\/2013\/08\/25\/how-to-read-and-understand-a-scientific-paper-2\/",
      "display_url" : "violentmetaphors.com\/2013\/08\/25\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372498384336457728",
  "text" : "How to read and understand a scientific paper: a guide for non-scientists  http:\/\/t.co\/JKucTjcBZ4",
  "id" : 372498384336457728,
  "created_at" : "2013-08-27 23:18:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/SoqnkxXOLT",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/octopus-chronicles\/2013\/08\/27\/even-severed-octopus-arms-have-smart-moves\/",
      "display_url" : "blogs.scientificamerican.com\/octopus-chroni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372497069438935040",
  "text" : "Even Severed Octopus Arms Have Smart Moves  http:\/\/t.co\/SoqnkxXOLT",
  "id" : 372497069438935040,
  "created_at" : "2013-08-27 23:13:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 64, 79 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/kZqng9xDQm",
      "expanded_url" : "http:\/\/m.vice.com\/en_ca\/read\/polyamory-is-a-good-way-to-be-slutty-without-hurting-anyone",
      "display_url" : "m.vice.com\/en_ca\/read\/pol\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097312592, 8.2832447346 ]
  },
  "id_str" : "372494814396567552",
  "text" : "Polyamory Is a Good Way to Be Slutty Without Hurting Anyone \/cc @JanDoerrenhaus http:\/\/t.co\/kZqng9xDQm",
  "id" : 372494814396567552,
  "created_at" : "2013-08-27 23:04:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 18, 30 ],
      "id_str" : "149089037",
      "id" : 149089037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372489365035175936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096655264, 8.2830914626 ]
  },
  "id_str" : "372489649446744064",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon @antiprodukt achso, ich dachte du h\u00E4ttest ihnen am WE vielleicht LSD oder so ins Trinkwasser gegeben.",
  "id" : 372489649446744064,
  "in_reply_to_status_id" : 372489365035175936,
  "created_at" : "2013-08-27 22:43:47 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372488217016430592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0125357087, 8.284057803 ]
  },
  "id_str" : "372488401171529728",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon ist mir nicht so aufgefallen. Sollten sie? ;)",
  "id" : 372488401171529728,
  "in_reply_to_status_id" : 372488217016430592,
  "created_at" : "2013-08-27 22:38:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096987796, 8.2830218886 ]
  },
  "id_str" : "372487936836927488",
  "text" : "Pro forma ins Modulhandbuch f\u00FCr den Bachelor Geographie geschaut in den ich nun accidentally eingeschrieben bin: \u00ABSport: Zielschussspiele\u00BB",
  "id" : 372487936836927488,
  "created_at" : "2013-08-27 22:36:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372482498019991552",
  "text" : "RT @TheTweetOfGod: Attention: will the owners of a blue planet with tectonic plates please tend to your vehicle. It is overheating.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366292148989079552",
    "text" : "Attention: will the owners of a blue planet with tectonic plates please tend to your vehicle. It is overheating.",
    "id" : 366292148989079552,
    "created_at" : "2013-08-10 20:17:08 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 372482498019991552,
  "created_at" : "2013-08-27 22:15:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/sr9hpDFRBo",
      "expanded_url" : "http:\/\/www.thebolditalic.com\/Jessica_Saia\/stories\/3547-guys-with-fancy-lady-hair",
      "display_url" : "thebolditalic.com\/Jessica_Saia\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372478539003883520",
  "text" : "RT @Lobot: And what about the menz? Here's for you: guys with fancy lady hair. http:\/\/t.co\/sr9hpDFRBo (omg how I love this.) via @kaltmamse\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kaltmamsell",
        "screen_name" : "kaltmamsell",
        "indices" : [ 118, 130 ],
        "id_str" : "10735362",
        "id" : 10735362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/sr9hpDFRBo",
        "expanded_url" : "http:\/\/www.thebolditalic.com\/Jessica_Saia\/stories\/3547-guys-with-fancy-lady-hair",
        "display_url" : "thebolditalic.com\/Jessica_Saia\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372297019005861889",
    "text" : "And what about the menz? Here's for you: guys with fancy lady hair. http:\/\/t.co\/sr9hpDFRBo (omg how I love this.) via @kaltmamsell",
    "id" : 372297019005861889,
    "created_at" : "2013-08-27 09:58:20 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 372478539003883520,
  "created_at" : "2013-08-27 21:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth\u00E4us Cebulla",
      "screen_name" : "MattCeb",
      "indices" : [ 0, 8 ],
      "id_str" : "180457928",
      "id" : 180457928
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372476402949300224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782467, 8.283017455 ]
  },
  "id_str" : "372476554087239682",
  "in_reply_to_user_id" : 180457928,
  "text" : "@MattCeb @Senficon Ach, wir haben ja eine normale DSL-Flat zuhause. Da sind wir nur so selten ;)",
  "id" : 372476554087239682,
  "in_reply_to_status_id" : 372476402949300224,
  "created_at" : "2013-08-27 21:51:45 +0000",
  "in_reply_to_screen_name" : "MattCeb",
  "in_reply_to_user_id_str" : "180457928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth\u00E4us Cebulla",
      "screen_name" : "MattCeb",
      "indices" : [ 0, 8 ],
      "id_str" : "180457928",
      "id" : 180457928
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372474627416543232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096782467, 8.283017455 ]
  },
  "id_str" : "372475770129874944",
  "in_reply_to_user_id" : 180457928,
  "text" : "@MattCeb @Senficon Ja, eine Woche l\u00E4nger in etwa ;)",
  "id" : 372475770129874944,
  "in_reply_to_status_id" : 372474627416543232,
  "created_at" : "2013-08-27 21:48:38 +0000",
  "in_reply_to_screen_name" : "MattCeb",
  "in_reply_to_user_id_str" : "180457928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    }, {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 16, 30 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372465967583879168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009665304, 8.2830281933 ]
  },
  "id_str" : "372468249675718656",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus @MenschZwoNull gerne doch, im Zweifel muss man bei jedem der das Wort verwendet die pers\u00F6nliche Definition Abfragen. ;)",
  "id" : 372468249675718656,
  "in_reply_to_status_id" : 372465967583879168,
  "created_at" : "2013-08-27 21:18:45 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089721941, 8.2792196609 ]
  },
  "id_str" : "372466470682656768",
  "text" : "You\u2019re entering a World Wide Web of pain: \u00ABSie surfen jetzt bis Ende des Monats mit reduzierter Geschwindigkeit\u00BB",
  "id" : 372466470682656768,
  "created_at" : "2013-08-27 21:11:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    }, {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 16, 30 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372465061211566081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0145611844, 8.2751886356 ]
  },
  "id_str" : "372465588142366720",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus @MenschZwoNull ich denke consensual non-monogamy w\u00E4re der beste Oberbegriff. Aber je nachdem wen du fragst stimmt deins auch",
  "id" : 372465588142366720,
  "in_reply_to_status_id" : 372465061211566081,
  "created_at" : "2013-08-27 21:08:10 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    }, {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 16, 30 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372462603571695617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0145611844, 8.2751886356 ]
  },
  "id_str" : "372464503507918848",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus @MenschZwoNull ich w\u00FCrde einfach behaupten das es daf\u00FCr keine einheitliche Definition gibt &amp; jeder was anderes drunter sieht",
  "id" : 372464503507918848,
  "in_reply_to_status_id" : 372462603571695617,
  "created_at" : "2013-08-27 21:03:52 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    }, {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 16, 30 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372462468636749824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0187482728, 8.2713782208 ]
  },
  "id_str" : "372462748153937921",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus @MenschZwoNull ich hatte es auch nur als Trollerei aufgefasst, Carlin sei dank ;)",
  "id" : 372462748153937921,
  "in_reply_to_status_id" : 372462468636749824,
  "created_at" : "2013-08-27 20:56:53 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0180695062, 8.271810071 ]
  },
  "id_str" : "372460365235650560",
  "text" : "\u00ABWann ich dich verlassen w\u00FCrde? Zum Beispiel wenn du durch die NPD zu Jesus finden und deshalb monogam werden w\u00FCrdest.\u00BB",
  "id" : 372460365235650560,
  "created_at" : "2013-08-27 20:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/rMl1OvkA6x",
      "expanded_url" : "http:\/\/i.imgur.com\/bnYaM9D.jpg",
      "display_url" : "i.imgur.com\/bnYaM9D.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009683, 8.283067 ]
  },
  "id_str" : "372449715755184128",
  "text" : "Took me some time to parse this outside a metamour relationship context.  http:\/\/t.co\/rMl1OvkA6x",
  "id" : 372449715755184128,
  "created_at" : "2013-08-27 20:05:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0124843694, 8.2840334139 ]
  },
  "id_str" : "372442152305184768",
  "text" : "\u00ABWenn du mir die Halsschlagader aufbei\u00DFt w\u00E4re das einer der F\u00E4lle in denen ich erst ins Krankenhaus will bevor wir wieder ins Bett gehen.\u00BB",
  "id" : 372442152305184768,
  "created_at" : "2013-08-27 19:35:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722907533, 8.6276521954 ]
  },
  "id_str" : "372326618309881856",
  "text" : "\u00ABDu kannst doch Histogramme in R plotten, oder nicht? Dann bist du R-Experte!\u00BB",
  "id" : 372326618309881856,
  "created_at" : "2013-08-27 11:55:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/unQXZn2MZO",
      "expanded_url" : "http:\/\/nl.wikipedia.org\/wiki\/Polderblindheid",
      "display_url" : "nl.wikipedia.org\/wiki\/Polderbli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372322687579738112",
  "text" : "TIL: In Dutch 'Highway Hypnosis' is 'Polderblindheid' http:\/\/t.co\/unQXZn2MZO",
  "id" : 372322687579738112,
  "created_at" : "2013-08-27 11:40:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/UKMl4PucwK",
      "expanded_url" : "http:\/\/i.imgur.com\/u8NcwKe.gif",
      "display_url" : "i.imgur.com\/u8NcwKe.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "372320586279567360",
  "text" : "Waiting for the results of the assembly evaluation http:\/\/t.co\/UKMl4PucwK",
  "id" : 372320586279567360,
  "created_at" : "2013-08-27 11:31:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 25, 35 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722853147, 8.6276369095 ]
  },
  "id_str" : "372298948217962496",
  "text" : "Ein &lt;3 an das SSC der @goetheuni, das unb\u00FCrokratisch mit meiner Verpeiltheit umgeht damit ich Student bleiben kann.",
  "id" : 372298948217962496,
  "created_at" : "2013-08-27 10:06:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AhzJlXJxmP",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0073302",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372289800511819777",
  "text" : "How to Become a Mentalist: The science of rock-scissors-paper and pupil dilation http:\/\/t.co\/AhzJlXJxmP",
  "id" : 372289800511819777,
  "created_at" : "2013-08-27 09:29:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0IQTyQpKYG",
      "expanded_url" : "http:\/\/thegenomefactory.blogspot.de\/2013\/08\/paired-end-read-confusion-library.html",
      "display_url" : "thegenomefactory.blogspot.de\/2013\/08\/paired\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372284979738206208",
  "text" : "That should be required reading in bioinformatics: Paired-end read confusion - library, fragment or insert size? http:\/\/t.co\/0IQTyQpKYG",
  "id" : 372284979738206208,
  "created_at" : "2013-08-27 09:10:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/hyZc9yLvnY",
      "expanded_url" : "http:\/\/instagram.com\/p\/dgsPjRBwnA\/",
      "display_url" : "instagram.com\/p\/dgsPjRBwnA\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1735988061, 8.6295649714 ]
  },
  "id_str" : "372282577606176768",
  "text" : "Molehills @ Goethe-Universit\u00E4t Frankfurt\/Main - Campus Riedberg http:\/\/t.co\/hyZc9yLvnY",
  "id" : 372282577606176768,
  "created_at" : "2013-08-27 09:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9h3HPTSF68",
      "expanded_url" : "http:\/\/whatever.scalzi.com\/2013\/08\/26\/to-the-dudebro-who-thinks-hes-insulting-me-by-calling-me-a-feminist\/",
      "display_url" : "whatever.scalzi.com\/2013\/08\/26\/to-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372280196092551168",
  "text" : "\u00ABSeriously, now: \u201CThis is what a feminist looks like\u201D qualifies as arch mockery in your world? Dudebro, please\u00BB http:\/\/t.co\/9h3HPTSF68",
  "id" : 372280196092551168,
  "created_at" : "2013-08-27 08:51:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vV9fVskI8K",
      "expanded_url" : "http:\/\/www.manath.com\/pictures\/tumbleweed.gif",
      "display_url" : "manath.com\/pictures\/tumbl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372278441933942784",
  "text" : "\u00ABDu gehst schon?\u00BB - \u00ABIch besorg uns ein bisschen Tumbleweed damit wir es durch die verwaisten AG-Flure pusten k\u00F6nnen\u00BB http:\/\/t.co\/vV9fVskI8K",
  "id" : 372278441933942784,
  "created_at" : "2013-08-27 08:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/vf8Dd9YsmN",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/science-sushi\/2013\/08\/23\/16-things-buzzfeed-doesnt-know-about-the-ocean\/#.UhxN9VUazCQ",
      "display_url" : "blogs.discovermagazine.com\/science-sushi\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372252189252943872",
  "text" : "16 Things BuzzFeed Doesn't Know About The Ocean http:\/\/t.co\/vf8Dd9YsmN",
  "id" : 372252189252943872,
  "created_at" : "2013-08-27 07:00:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/cCxEMSJ1hG",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1007",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372250171541049344",
  "text" : "Stay http:\/\/t.co\/cCxEMSJ1hG",
  "id" : 372250171541049344,
  "created_at" : "2013-08-27 06:52:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mongabay",
      "screen_name" : "mongabay",
      "indices" : [ 3, 12 ],
      "id_str" : "27740227",
      "id" : 27740227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/0kpJUt4U7L",
      "expanded_url" : "http:\/\/ow.ly\/2zpH3P",
      "display_url" : "ow.ly\/2zpH3P"
    } ]
  },
  "geo" : { },
  "id_str" : "372248703274590208",
  "text" : "RT @mongabay: Activists propose naming hurricanes after politicians who deny climate change http:\/\/t.co\/0kpJUt4U7L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/0kpJUt4U7L",
        "expanded_url" : "http:\/\/ow.ly\/2zpH3P",
        "display_url" : "ow.ly\/2zpH3P"
      } ]
    },
    "geo" : { },
    "id_str" : "372246138034081792",
    "text" : "Activists propose naming hurricanes after politicians who deny climate change http:\/\/t.co\/0kpJUt4U7L",
    "id" : 372246138034081792,
    "created_at" : "2013-08-27 06:36:09 +0000",
    "user" : {
      "name" : "Mongabay",
      "screen_name" : "mongabay",
      "protected" : false,
      "id_str" : "27740227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877957542093045760\/YRH_Z1E6_normal.jpg",
      "id" : 27740227,
      "verified" : true
    }
  },
  "id" : 372248703274590208,
  "created_at" : "2013-08-27 06:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0115230976, 8.2831245301 ]
  },
  "id_str" : "372153313070178305",
  "text" : "Im Schlaf reden kann so niedlich sein: \u00ABIch liebe dich.\u00BB \u2014 \u00ABFor realz?!\u00BB \u2014 \u00ABYep, for all the rationals and the irrationals!\u00BB",
  "id" : 372153313070178305,
  "created_at" : "2013-08-27 00:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/FbSRIFmSZv",
      "expanded_url" : "http:\/\/ksj.mit.edu\/tracker\/2013\/08\/john-horgan-end-optogenetics",
      "display_url" : "ksj.mit.edu\/tracker\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372146611981656064",
  "text" : "RT @BoraZ: John Horgan: The end of optogenetics. http:\/\/t.co\/FbSRIFmSZv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/FbSRIFmSZv",
        "expanded_url" : "http:\/\/ksj.mit.edu\/tracker\/2013\/08\/john-horgan-end-optogenetics",
        "display_url" : "ksj.mit.edu\/tracker\/2013\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372145805022359553",
    "text" : "John Horgan: The end of optogenetics. http:\/\/t.co\/FbSRIFmSZv",
    "id" : 372145805022359553,
    "created_at" : "2013-08-26 23:57:28 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 372146611981656064,
  "created_at" : "2013-08-27 00:00:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/E00XqOnTvH",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/pdf\/10.1080\/08927014.2000.9522807#preview",
      "display_url" : "tandfonline.com\/doi\/pdf\/10.108\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097180679, 8.2831159952 ]
  },
  "id_str" : "372144797748051968",
  "text" : "\u00ABThey will enter, will bury, will live on my flesh; and in the shape of their children and mine, I will escape death\u00BB http:\/\/t.co\/E00XqOnTvH",
  "id" : 372144797748051968,
  "created_at" : "2013-08-26 23:53:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "indices" : [ 3, 17 ],
      "id_str" : "128292609",
      "id" : 128292609
    }, {
      "name" : "Improbable Research",
      "screen_name" : "improbresearch",
      "indices" : [ 123, 138 ],
      "id_str" : "109310784",
      "id" : 109310784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5ZVEVjmPSE",
      "expanded_url" : "http:\/\/shar.es\/zj5vu",
      "display_url" : "shar.es\/zj5vu"
    } ]
  },
  "geo" : { },
  "id_str" : "372123290930016256",
  "text" : "RT @JenLucPiquant: Science, you shock me. Discovery: Students Who Do Homework Get Higher Grades http:\/\/t.co\/5ZVEVjmPSE via @improbresearch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Improbable Research",
        "screen_name" : "improbresearch",
        "indices" : [ 104, 119 ],
        "id_str" : "109310784",
        "id" : 109310784
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/5ZVEVjmPSE",
        "expanded_url" : "http:\/\/shar.es\/zj5vu",
        "display_url" : "shar.es\/zj5vu"
      } ]
    },
    "geo" : { },
    "id_str" : "372119239840133120",
    "text" : "Science, you shock me. Discovery: Students Who Do Homework Get Higher Grades http:\/\/t.co\/5ZVEVjmPSE via @improbresearch",
    "id" : 372119239840133120,
    "created_at" : "2013-08-26 22:11:55 +0000",
    "user" : {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "protected" : false,
      "id_str" : "128292609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525328824133636096\/85rXVsFk_normal.jpeg",
      "id" : 128292609,
      "verified" : true
    }
  },
  "id" : 372123290930016256,
  "created_at" : "2013-08-26 22:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/XbUebI1nQA",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/occams-corner\/2013\/aug\/22\/1",
      "display_url" : "theguardian.com\/science\/occams\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372122763550806016",
  "text" : "RT @PhilippBayer: Pregnant in the lab: how does child-bearing affect a science career? http:\/\/t.co\/XbUebI1nQA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/XbUebI1nQA",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/occams-corner\/2013\/aug\/22\/1",
        "display_url" : "theguardian.com\/science\/occams\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370673713177321472",
    "text" : "Pregnant in the lab: how does child-bearing affect a science career? http:\/\/t.co\/XbUebI1nQA",
    "id" : 370673713177321472,
    "created_at" : "2013-08-22 22:27:54 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 372122763550806016,
  "created_at" : "2013-08-26 22:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097094311, 8.2830499397 ]
  },
  "id_str" : "372115129267392512",
  "text" : "\u00ABI guess this date\u2019s over.\u00BB \u2014 \u00ABNo, it\u2019s not. I still have 3 minutes left. Where were you on the night of the 18th?!\u00BB",
  "id" : 372115129267392512,
  "created_at" : "2013-08-26 21:55:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097118404, 8.2830665147 ]
  },
  "id_str" : "372081984744734720",
  "text" : "\u00ABDating nach actuarial tables: Damit nicht ein Partner den anderen so lange \u00FCberlebt.\u00BB \u2014 \u00ABVersteck deine Gerontophilia hinter Statistiken\u2026\u00BB",
  "id" : 372081984744734720,
  "created_at" : "2013-08-26 19:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372081059611303936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097118404, 8.2830665147 ]
  },
  "id_str" : "372081152355762176",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Senficon besser zwei Freundinnen als eine Pointe verlieren!",
  "id" : 372081152355762176,
  "in_reply_to_status_id" : 372081059611303936,
  "created_at" : "2013-08-26 19:40:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372080754106195968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097118404, 8.2830665147 ]
  },
  "id_str" : "372080979114229760",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Senficon come back once you\u2019ve learned using Internet lingo.",
  "id" : 372080979114229760,
  "in_reply_to_status_id" : 372080754106195968,
  "created_at" : "2013-08-26 19:39:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372066208545120257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0081367634, 8.2929918912 ]
  },
  "id_str" : "372067230491889665",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon nicht ohne 5% H\u00FCrde. ;)",
  "id" : 372067230491889665,
  "in_reply_to_status_id" : 372066208545120257,
  "created_at" : "2013-08-26 18:45:15 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norbert Hense",
      "screen_name" : "norberthense",
      "indices" : [ 0, 13 ],
      "id_str" : "19775104",
      "id" : 19775104
    }, {
      "name" : ".",
      "screen_name" : "kevusch",
      "indices" : [ 14, 22 ],
      "id_str" : "90213634",
      "id" : 90213634
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372065033859002369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00829102, 8.2934276955 ]
  },
  "id_str" : "372065789245128704",
  "in_reply_to_user_id" : 19775104,
  "text" : "@norberthense @kevusch @Senficon es war als \u2018when\u2019, nicht \u2018if\u2019 gemeint. ;)",
  "id" : 372065789245128704,
  "in_reply_to_status_id" : 372065033859002369,
  "created_at" : "2013-08-26 18:39:31 +0000",
  "in_reply_to_screen_name" : "norberthense",
  "in_reply_to_user_id_str" : "19775104",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 112, 121 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0083127898, 8.289013831 ]
  },
  "id_str" : "372063030143893504",
  "text" : "Wahlempfehlung mal ander5: W\u00E4hlt Piraten damit alle Karrieregeilen schon in den Bundestag abgeschoben sind wenn @Senficon ins EP will.",
  "id" : 372063030143893504,
  "created_at" : "2013-08-26 18:28:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 69, 76 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095567385, 8.2830706427 ]
  },
  "id_str" : "372061355026960385",
  "text" : "\u00ABHeute hat Miezi auf den Sitzsack gepinkelt. Vielleicht vermisst sie @lsanoj\u00BB",
  "id" : 372061355026960385,
  "created_at" : "2013-08-26 18:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 32, 41 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/372060230185914369\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/vUkMoZYgke",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSnSzs2IcAA1mW4.jpg",
      "id_str" : "372060229888143360",
      "id" : 372060229888143360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSnSzs2IcAA1mW4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/vUkMoZYgke"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096972105, 8.2830430563 ]
  },
  "id_str" : "372060230185914369",
  "text" : "More like \u2018risque d\u2019 OMG\u2019. brb, @Senficon zeigen wo die T\u00FCr ist. http:\/\/t.co\/vUkMoZYgke",
  "id" : 372060230185914369,
  "created_at" : "2013-08-26 18:17:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723281386, 8.6276722244 ]
  },
  "id_str" : "372030158888509440",
  "text" : "\u00ABIch hoffe sehr das du deinen 30. Geburtstag noch erlebst (und ich auch).\u00BB \u2014 \u00ABSorry to break the news: Du hast deinen 30. schon erlebt.\u00BB",
  "id" : 372030158888509440,
  "created_at" : "2013-08-26 16:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 63, 74 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/MdKTQ2c9I2",
      "expanded_url" : "https:\/\/lh3.googleusercontent.com\/-flnMpo23PLM\/UhtFP4Do9pI\/AAAAAAAAH_I\/2AuukFZKPLI\/w995-h686-no\/130825_11_13_01.JPG",
      "display_url" : "lh3.googleusercontent.com\/-flnMpo23PLM\/U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372029108793794562",
  "text" : "\"Das mag ich: Du mit deiner nat\u00FCrlichen Handhaltung (am Bart), @herrurbach als w\u00FCrde er dich gleich K\u00FCssen!\" https:\/\/t.co\/MdKTQ2c9I2 #om13",
  "id" : 372029108793794562,
  "created_at" : "2013-08-26 16:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/8dk209QJE2",
      "expanded_url" : "http:\/\/www.theatlantic.com\/magazine\/archive\/2013\/09\/advertisement-for-murder\/309435\/?single_page=true",
      "display_url" : "theatlantic.com\/magazine\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372028188366356480",
  "text" : "Murder by Craigslist http:\/\/t.co\/8dk209QJE2",
  "id" : 372028188366356480,
  "created_at" : "2013-08-26 16:10:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Felix Neumann",
      "screen_name" : "fxneumann",
      "indices" : [ 7, 17 ],
      "id_str" : "43292041",
      "id" : 43292041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/JaTQ0uk1hK",
      "expanded_url" : "http:\/\/www.gesetze-im-internet.de\/gendg\/BJNR252900009.html#BJNR252900009BJNG000400000",
      "display_url" : "gesetze-im-internet.de\/gendg\/BJNR2529\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372021223347482624",
  "geo" : { },
  "id_str" : "372022085180084224",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @fxneumann status quo ist: http:\/\/t.co\/JaTQ0uk1hK",
  "id" : 372022085180084224,
  "in_reply_to_status_id" : 372021223347482624,
  "created_at" : "2013-08-26 15:45:51 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9tAOEGx0nS",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/chelseamarshall\/signs-your-dogs-an-introvert",
      "display_url" : "buzzfeed.com\/chelseamarshal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372020134618988544",
  "text" : "22 Signs Your Dog\u2019s An Introvert http:\/\/t.co\/9tAOEGx0nS",
  "id" : 372020134618988544,
  "created_at" : "2013-08-26 15:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Fs9CdRSrCT",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/59398296412\/trying-to-relate-to-my-students",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/593982964\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372017098098085889",
  "text" : "I relate http:\/\/t.co\/Fs9CdRSrCT",
  "id" : 372017098098085889,
  "created_at" : "2013-08-26 15:26:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/sfb7srXm0U",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/the-curious-wavefunction\/2013\/08\/23\/deconstructing-john-millers-arguments-against-nuclear-energy-in-the-times\/",
      "display_url" : "blogs.scientificamerican.com\/the-curious-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371999522160779264",
  "text" : "Deconstructing John Miller\u2019s arguments against nuclear energy in the New York Times http:\/\/t.co\/sfb7srXm0U",
  "id" : 371999522160779264,
  "created_at" : "2013-08-26 14:16:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/4zkni94D0n",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0071246",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371996708139311105",
  "text" : "Hidden Markov Models: The Best Models for Forager Movements? http:\/\/t.co\/4zkni94D0n",
  "id" : 371996708139311105,
  "created_at" : "2013-08-26 14:05:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 78, 91 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 92, 102 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/TNPdCYnexH",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072614",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371991146957787137",
  "text" : "DistMap: A Toolkit for Distributed Short Read Mapping on a Hadoop Cluster \/cc @PhilippBayer @fbnzimmer http:\/\/t.co\/TNPdCYnexH",
  "id" : 371991146957787137,
  "created_at" : "2013-08-26 13:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/wdPQPkKjpt",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0070284",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371988990368309249",
  "text" : "At Grammatical Faculty of Language, Flies Outsmart Men http:\/\/t.co\/wdPQPkKjpt",
  "id" : 371988990368309249,
  "created_at" : "2013-08-26 13:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 106, 110 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 116, 126 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371976416952610816",
  "geo" : { },
  "id_str" : "371984305825660928",
  "in_reply_to_user_id" : 500939542,
  "text" : "@herrpeukert Okay, ich schau mal. Mit meinem Account geht es vermutlich ob admin-Rechte, vielleicht haben @scy oder @prauscher da eine Idee?",
  "id" : 371984305825660928,
  "in_reply_to_status_id" : 371976416952610816,
  "created_at" : "2013-08-26 13:15:44 +0000",
  "in_reply_to_screen_name" : "bettercallklaus",
  "in_reply_to_user_id_str" : "500939542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371975883755888641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1788558142, 8.621598418 ]
  },
  "id_str" : "371976260412788736",
  "in_reply_to_user_id" : 500939542,
  "text" : "@herrpeukert was willst du denn tun?",
  "id" : 371976260412788736,
  "in_reply_to_status_id" : 371975883755888641,
  "created_at" : "2013-08-26 12:43:46 +0000",
  "in_reply_to_screen_name" : "bettercallklaus",
  "in_reply_to_user_id_str" : "500939542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723172975, 8.6277560431 ]
  },
  "id_str" : "371946175156744192",
  "text" : "\u00ABBleib weg mit dem Sp\u00FCli! Mein Nachtisch-Sch\u00E4lchen wird nur durch die Oberfl\u00E4chenspannung vom \u00FCberlaufen abgehalten!\u00BB",
  "id" : 371946175156744192,
  "created_at" : "2013-08-26 10:44:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722774202, 8.6276369095 ]
  },
  "id_str" : "371941271054876672",
  "text" : "\u00ABDu machst den Browser auf, gehst zur NCBI Taxonomnomnomy-Seite und schaust was der geschmackliche Unterschied zwischen Huhn und Pute ist.\u00BB",
  "id" : 371941271054876672,
  "created_at" : "2013-08-26 10:24:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722774202, 8.6276369095 ]
  },
  "id_str" : "371940415794323456",
  "text" : "\u00ABWenn du mir mal kurz in den Schritt greifst und an dem B\u00E4ndchen ziehst kannst du auch die T\u00FCr aufmachen.\u00BB",
  "id" : 371940415794323456,
  "created_at" : "2013-08-26 10:21:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371934328122789889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723863087, 8.6276156545 ]
  },
  "id_str" : "371937143926845440",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy kein Ding :)",
  "id" : 371937143926845440,
  "in_reply_to_status_id" : 371934328122789889,
  "created_at" : "2013-08-26 10:08:20 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371936292625326080",
  "text" : "Gr\u00FCnde f\u00FCr das Zweitstudium. Fallgruppe 6: Ich will das Semesterticket.",
  "id" : 371936292625326080,
  "created_at" : "2013-08-26 10:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 5, 15 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371932127488925697",
  "geo" : { },
  "id_str" : "371932399984066560",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @prauscher Hab deinen User \u00FCber das Formular gesucht und dann auf der User-Seite im Reiter \"Account\"",
  "id" : 371932399984066560,
  "in_reply_to_status_id" : 371932127488925697,
  "created_at" : "2013-08-26 09:49:29 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 5, 15 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371931547072753664",
  "geo" : { },
  "id_str" : "371931686918836224",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @prauscher Ich hab nur f\u00FCr den account \"scy\" das Flag f\u00FCr Admin gesetzt.",
  "id" : 371931686918836224,
  "in_reply_to_status_id" : 371931547072753664,
  "created_at" : "2013-08-26 09:46:38 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 5, 15 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371930302740185088",
  "geo" : { },
  "id_str" : "371930699902640128",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @prauscher solltest admin-status haben seit gerade, ich sehe nicht wo man dich der konferenz zuweisen k\u00F6nnte :)",
  "id" : 371930699902640128,
  "in_reply_to_status_id" : 371930302740185088,
  "created_at" : "2013-08-26 09:42:43 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/J15U603wFj",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/59228130344",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/592281303\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172282, 8.62769 ]
  },
  "id_str" : "371915841660784640",
  "text" : "RNA benches http:\/\/t.co\/J15U603wFj",
  "id" : 371915841660784640,
  "created_at" : "2013-08-26 08:43:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C H A R N L E Y",
      "screen_name" : "DanKCharnley",
      "indices" : [ 3, 16 ],
      "id_str" : "48761924",
      "id" : 48761924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371889261135810560",
  "text" : "RT @DanKCharnley: if i ever get married, i will absolutely mention wolves in my vows",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371407043716190209",
    "text" : "if i ever get married, i will absolutely mention wolves in my vows",
    "id" : 371407043716190209,
    "created_at" : "2013-08-24 23:01:54 +0000",
    "user" : {
      "name" : "C H A R N L E Y",
      "screen_name" : "DanKCharnley",
      "protected" : false,
      "id_str" : "48761924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921550974736576512\/50tSSVn8_normal.jpg",
      "id" : 48761924,
      "verified" : false
    }
  },
  "id" : 371889261135810560,
  "created_at" : "2013-08-26 06:58:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371876094485331968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0125153343, 8.284048459 ]
  },
  "id_str" : "371876460157763584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, thanks!",
  "id" : 371876460157763584,
  "in_reply_to_status_id" : 371876094485331968,
  "created_at" : "2013-08-26 06:07:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097031606, 8.2830471685 ]
  },
  "id_str" : "371756749445156864",
  "text" : "\u00ABWieso tut dein Oberarm weh?\u00BB \u2014 \u00ABWeil ich Spass hatte.\u00BB \u2014 \u00ABOh, das tut mir leid.\u00BB",
  "id" : 371756749445156864,
  "created_at" : "2013-08-25 22:11:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om10",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371748683274264576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096321141, 8.2830234906 ]
  },
  "id_str" : "371749596793700352",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 auf der #om10 gab es sogar schon mal eine iirc.",
  "id" : 371749596793700352,
  "in_reply_to_status_id" : 371748683274264576,
  "created_at" : "2013-08-25 21:43:05 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096230529, 8.2830045422 ]
  },
  "id_str" : "371748049959546880",
  "text" : "\u00ABIhr seid doch politisch motiviert.\u00BB \u2014 \u00ABIch kann mir nicht helfen, das klingt gleich immer so nach Terror und Anschl\u00E4gen.\u00BB #om13",
  "id" : 371748049959546880,
  "created_at" : "2013-08-25 21:36:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667132, 8.2829721279 ]
  },
  "id_str" : "371741259490394112",
  "text" : "\u00ABOh, du bist gar nicht Horst? Und wieso hast du eigentlich keine Schuhe an?!\u00BB",
  "id" : 371741259490394112,
  "created_at" : "2013-08-25 21:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 79, 90 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "om14",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095545687, 8.2827822212 ]
  },
  "id_str" : "371733611848151040",
  "text" : "Zum 5-j\u00E4hrigen der #om13 wird auf der #om14 also mal wieder der Geburtstag von @herrurbach gefeiert. Alleine daf\u00FCr lohnt es sich zu kommen.",
  "id" : 371733611848151040,
  "created_at" : "2013-08-25 20:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371653999298355200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192107566, 9.4760321996 ]
  },
  "id_str" : "371655065452683265",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro awww, danke!",
  "id" : 371655065452683265,
  "in_reply_to_status_id" : 371653999298355200,
  "created_at" : "2013-08-25 15:27:27 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371652178639060992",
  "text" : "RT @Lobot: \u00ABVanilla h\u00F6rt da auf, wo ich es meiner Mutter erz\u00E4hle und sie sagt 'Oh Gott, sowas machst du?'\u00BB - \u00ABF\u00FCr dein Kind w\u00E4re also alles\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.3232866, 9.4737179 ]
    },
    "id_str" : "371651188846256128",
    "text" : "\u00ABVanilla h\u00F6rt da auf, wo ich es meiner Mutter erz\u00E4hle und sie sagt 'Oh Gott, sowas machst du?'\u00BB - \u00ABF\u00FCr dein Kind w\u00E4re also alles Vanilla.\u00BB",
    "id" : 371651188846256128,
    "created_at" : "2013-08-25 15:12:03 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 371652178639060992,
  "created_at" : "2013-08-25 15:15:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3184826169, 9.4771878091 ]
  },
  "id_str" : "371609174452740096",
  "text" : "(Nicht-)Anonyme Sexisten aus dem Internet: \u00ABDie gibt es auch in Wirklichkeit. Ich habe sogar schon manche von denen gesehen.\u00BB #om13",
  "id" : 371609174452740096,
  "created_at" : "2013-08-25 12:25:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 11, 15 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 16, 25 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371606215455158272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192930495, 9.4753151863 ]
  },
  "id_str" : "371606399287300096",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @scy @Senficon danke! :)",
  "id" : 371606399287300096,
  "in_reply_to_status_id" : 371606215455158272,
  "created_at" : "2013-08-25 12:14:04 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192925373, 9.4756748433 ]
  },
  "id_str" : "371605855634227200",
  "text" : "In Raum 1 werden gerade die Bewerber f\u00FCr die One-Way Mission to Mars vorgestellt. #om13",
  "id" : 371605855634227200,
  "created_at" : "2013-08-25 12:11:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 5, 15 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 16, 25 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 52, 62 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371603329878863872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192925373, 9.4756748433 ]
  },
  "id_str" : "371604985894932480",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @prauscher @Senficon das flag ist gesetzt. Hat @prauscher vermutlich gerade gemacht? :)",
  "id" : 371604985894932480,
  "in_reply_to_status_id" : 371603329878863872,
  "created_at" : "2013-08-25 12:08:27 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/pnTS2E3u30",
      "expanded_url" : "http:\/\/www.gotik-shop.de\/",
      "display_url" : "gotik-shop.de"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193322172, 9.4758158133 ]
  },
  "id_str" : "371588601228034048",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err http:\/\/t.co\/pnTS2E3u30",
  "id" : 371588601228034048,
  "created_at" : "2013-08-25 11:03:20 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193516281, 9.4759066691 ]
  },
  "id_str" : "371577991584686080",
  "text" : "\u00ABNa, solange wir nur H\u00E4ndchen halten ohne es zu merken.\u00BB \u2014 \u00ABOh Gott, wo ist meine Hose hin?!\u00BB",
  "id" : 371577991584686080,
  "created_at" : "2013-08-25 10:21:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192539542, 9.4755066113 ]
  },
  "id_str" : "371574538800463872",
  "text" : "Schweinzeit",
  "id" : 371574538800463872,
  "created_at" : "2013-08-25 10:07:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192866273, 9.4753307265 ]
  },
  "id_str" : "371571847500140544",
  "text" : "Der Schutzheilige der nautischen Metaphern. #om13",
  "id" : 371571847500140544,
  "created_at" : "2013-08-25 09:56:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192910715, 9.4755037096 ]
  },
  "id_str" : "371568895200878592",
  "text" : "\u00ABWir sind von Herzen Pirat. Ich kann nicht wir sagen, ich bin gar kein Pirat. Also ihr seid von Herzen Pirat\u2026\u00BB #om13",
  "id" : 371568895200878592,
  "created_at" : "2013-08-25 09:45:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FAHRRADkultur",
      "screen_name" : "RADkult",
      "indices" : [ 3, 11 ],
      "id_str" : "1130619578",
      "id" : 1130619578
    }, {
      "name" : "Colville-Andersen",
      "screen_name" : "copenhagenize",
      "indices" : [ 104, 118 ],
      "id_str" : "17815546",
      "id" : 17815546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/gXOowYFxQQ",
      "expanded_url" : "http:\/\/twitpic.com\/cqcgm6",
      "display_url" : "twitpic.com\/cqcgm6"
    } ]
  },
  "geo" : { },
  "id_str" : "371562085878341632",
  "text" : "RT @RADkult: Remember kids: Half of all head injuries happen inside of cars. http:\/\/t.co\/gXOowYFxQQ via @copenhagenize",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colville-Andersen",
        "screen_name" : "copenhagenize",
        "indices" : [ 91, 105 ],
        "id_str" : "17815546",
        "id" : 17815546
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/gXOowYFxQQ",
        "expanded_url" : "http:\/\/twitpic.com\/cqcgm6",
        "display_url" : "twitpic.com\/cqcgm6"
      } ]
    },
    "geo" : { },
    "id_str" : "371170011546914816",
    "text" : "Remember kids: Half of all head injuries happen inside of cars. http:\/\/t.co\/gXOowYFxQQ via @copenhagenize",
    "id" : 371170011546914816,
    "created_at" : "2013-08-24 07:20:01 +0000",
    "user" : {
      "name" : "FAHRRADkultur",
      "screen_name" : "RADkult",
      "protected" : false,
      "id_str" : "1130619578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3585306734\/09b5a271f1c01ef63ff061361cbfb2ac_normal.png",
      "id" : 1130619578,
      "verified" : false
    }
  },
  "id" : 371562085878341632,
  "created_at" : "2013-08-25 09:17:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 95, 103 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3184912477, 9.4771983936 ]
  },
  "id_str" : "371560648419065856",
  "text" : "\u00ABIch glaube nicht das jemand in diesem Raum wirklich zur\u00FCck in die Steinzeit will.\u00BB \u2014 \u00ABStimmt, @moeffju ist ja nicht da.\u00BB #om13",
  "id" : 371560648419065856,
  "created_at" : "2013-08-25 09:12:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192930332, 9.4753152197 ]
  },
  "id_str" : "371558861242904576",
  "text" : "Smartphones: \u00ABDa ist die Frage: Ist das gut f\u00FCr die Kultur? Pipapo, mimimi\u2026\u00BB #om13",
  "id" : 371558861242904576,
  "created_at" : "2013-08-25 09:05:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/qTVS46XC07",
      "expanded_url" : "http:\/\/instagram.com\/p\/dbiARHhwvT\/",
      "display_url" : "instagram.com\/p\/dbiARHhwvT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193633306, 9.4757418888 ]
  },
  "id_str" : "371556204440731648",
  "text" : "Social-Media scy #om13 @ JH Kassel http:\/\/t.co\/qTVS46XC07",
  "id" : 371556204440731648,
  "created_at" : "2013-08-25 08:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371552324021649408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192557164, 9.4753753129 ]
  },
  "id_str" : "371553595365523456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nach 3 Monaten ohne Duschen kannst auch du langsam deinen Gestank nicht mehr ertragen?",
  "id" : 371553595365523456,
  "in_reply_to_status_id" : 371552324021649408,
  "created_at" : "2013-08-25 08:44:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193001744, 9.4753028172 ]
  },
  "id_str" : "371549350801211392",
  "text" : "Das implantierte Smartphone. Damit auch die 3 von uns die Sex haben w\u00E4hrenddessen besser twittern k\u00F6nnen. #om13",
  "id" : 371549350801211392,
  "created_at" : "2013-08-25 08:27:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371542892487385089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191976708, 9.4756576023 ]
  },
  "id_str" : "371543282264064000",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Z\u00E4hne putzen und Duschen, in einer Woche! H\u00E4lt dein K\u00F6rper so viel Hygiene aus?",
  "id" : 371543282264064000,
  "in_reply_to_status_id" : 371542892487385089,
  "created_at" : "2013-08-25 08:03:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371542823671054336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191976708, 9.4756576023 ]
  },
  "id_str" : "371543083382759425",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great :)",
  "id" : 371543083382759425,
  "in_reply_to_status_id" : 371542823671054336,
  "created_at" : "2013-08-25 08:02:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caro Mahn-Gauseweg",
      "screen_name" : "688i",
      "indices" : [ 0, 5 ],
      "id_str" : "432028832",
      "id" : 432028832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371541028060540928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191976708, 9.4756576023 ]
  },
  "id_str" : "371542831313473536",
  "in_reply_to_user_id" : 432028832,
  "text" : "@688i gerne :)",
  "id" : 371542831313473536,
  "in_reply_to_status_id" : 371541028060540928,
  "created_at" : "2013-08-25 08:01:28 +0000",
  "in_reply_to_screen_name" : "688i",
  "in_reply_to_user_id_str" : "432028832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371534708699447296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191976708, 9.4756576023 ]
  },
  "id_str" : "371542724438417408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh no, not again! ;)",
  "id" : 371542724438417408,
  "in_reply_to_status_id" : 371534708699447296,
  "created_at" : "2013-08-25 08:01:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191428612, 9.4757501505 ]
  },
  "id_str" : "371536343132037120",
  "text" : "Liebe Gemeinde, wir haben uns heute hier versammelt um uns die Z\u00E4hne zu putzen. #om13",
  "id" : 371536343132037120,
  "created_at" : "2013-08-25 07:35:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192566395, 9.475736579 ]
  },
  "id_str" : "371532125004394496",
  "text" : "\u00ABDu hast da einen eitrigen, blutigen Pickel auf der Nase\u2026 Du wei\u00DFt wie du mich anmachst!\u00BB #om13",
  "id" : 371532125004394496,
  "created_at" : "2013-08-25 07:18:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192566395, 9.475736579 ]
  },
  "id_str" : "371530625662328832",
  "text" : "\u00ABIch w\u00FCrde ja mein V\u00F6gel-Shirt anziehen, aber das stinkt schon so.\u00BB #om13",
  "id" : 371530625662328832,
  "created_at" : "2013-08-25 07:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.319151265, 9.4756648605 ]
  },
  "id_str" : "371423555571183616",
  "text" : "\u00ABWenn wir uns irgendwann trennen werd ich alle deine Tweets entfaven!\u00BB",
  "id" : 371423555571183616,
  "created_at" : "2013-08-25 00:07:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192262082, 9.4756606588 ]
  },
  "id_str" : "371421642985332736",
  "text" : "\u00ABOh, siehst du ungl\u00FCcklich aus! Was liest du denn gerade?!\u00BB \u2014 \u00ABDeine Tweets\u2026\u00BB #om13",
  "id" : 371421642985332736,
  "created_at" : "2013-08-24 23:59:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192608852, 9.4754795423 ]
  },
  "id_str" : "371419321995894784",
  "text" : "\u00ABIch f\u00FChle mich von dir so ernst genommen.\u00BB \u2014 \u00ABDas Wort was du suchst ist \u2018hart\u2019.\u00BB #om13",
  "id" : 371419321995894784,
  "created_at" : "2013-08-24 23:50:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192608852, 9.4754795423 ]
  },
  "id_str" : "371418638001389568",
  "text" : "\u00ABOrr, [cunt|Kant]!\u00BB \u2014 \u00ABIch freu mich auch dich zu sehen, Hase. Ich wollt nur sagen: Ich geh ins Bett.\u00BB #om13",
  "id" : 371418638001389568,
  "created_at" : "2013-08-24 23:47:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191465285, 9.4758586745 ]
  },
  "id_str" : "371411297281527808",
  "text" : "\u00AB12 unique gnome!\u00BB #om13",
  "id" : 371411297281527808,
  "created_at" : "2013-08-24 23:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 5, 12 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192435527, 9.4755658937 ]
  },
  "id_str" : "371407311044349952",
  "text" : "Dank @lsanoj sehe ich die Katzen von der #om13 aus h\u00E4ufiger als wenn ich Zuhause bin.",
  "id" : 371407311044349952,
  "created_at" : "2013-08-24 23:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371337405204553728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193346987, 9.4761700872 ]
  },
  "id_str" : "371402198200373248",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon om-bierzehn!",
  "id" : 371402198200373248,
  "in_reply_to_status_id" : 371337405204553728,
  "created_at" : "2013-08-24 22:42:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371399841857155072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193544073, 9.4759545671 ]
  },
  "id_str" : "371400665127739392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Schmerz lernen sie erst kennen wenn eine 747 an ihrem Bart zieht (oder du)!",
  "id" : 371400665127739392,
  "in_reply_to_status_id" : 371399841857155072,
  "created_at" : "2013-08-24 22:36:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192462078, 9.4758064485 ]
  },
  "id_str" : "371333050724282368",
  "text" : "\u00ABDu schaufelst dir dein eigenes Grab.\u00BB \u2014 \u00ABIch wei\u00DF, ich tue das mit Freude \u00F6fters. Ich bin Mutter, du wei\u00DFt\u2026\u00BB",
  "id" : 371333050724282368,
  "created_at" : "2013-08-24 18:07:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193401022, 9.4759013814 ]
  },
  "id_str" : "371315670819942400",
  "text" : "\u00ABEuer Modell ist kaputt. Ihr geht davon aus das Kommentatoren erst lesen bevor sie kommentieren. Das m\u00F6chte ich stark bezweifeln.\u00BB #om13",
  "id" : 371315670819942400,
  "created_at" : "2013-08-24 16:58:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192374413, 9.4750849587 ]
  },
  "id_str" : "371294620879441921",
  "text" : "Kommentarmoderation: \u00ABEs kommt darauf an wie gro\u00DF der kleine Stalin in einem ist.\u00BB #om13",
  "id" : 371294620879441921,
  "created_at" : "2013-08-24 15:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.319280802, 9.4754845669 ]
  },
  "id_str" : "371289223481274368",
  "text" : "Google Readercats #om13",
  "id" : 371289223481274368,
  "created_at" : "2013-08-24 15:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192823293, 9.4755254289 ]
  },
  "id_str" : "371265281899114496",
  "text" : "\u00ABDas ist was meine Freunde denken was Toleranz ist: Schmerz.\u00BB #om13",
  "id" : 371265281899114496,
  "created_at" : "2013-08-24 13:38:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371257781627936768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3187771744, 9.4767365761 ]
  },
  "id_str" : "371258358097248256",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot das war genau so geplant, damit ich deinen Standpunkt durchgehen kann! ;)",
  "id" : 371258358097248256,
  "in_reply_to_status_id" : 371257781627936768,
  "created_at" : "2013-08-24 13:11:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191645622, 9.4754532796 ]
  },
  "id_str" : "371251261087035393",
  "text" : "Yo dawg, I herd you like standards, so I put a standard in your standard, so you can standardize while you standardize\u2026 #om13",
  "id" : 371251261087035393,
  "created_at" : "2013-08-24 12:42:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 0, 9 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371242558955192320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191485685, 9.4756269548 ]
  },
  "id_str" : "371242804334567424",
  "in_reply_to_user_id" : 16034275,
  "text" : "@ennomane Gl\u00FCckwunsch :)",
  "id" : 371242804334567424,
  "in_reply_to_status_id" : 371242558955192320,
  "created_at" : "2013-08-24 12:09:16 +0000",
  "in_reply_to_screen_name" : "ennopark",
  "in_reply_to_user_id_str" : "16034275",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371240040665722880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3190600937, 9.4753031786 ]
  },
  "id_str" : "371240872530436096",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj awww!",
  "id" : 371240872530436096,
  "in_reply_to_status_id" : 371240040665722880,
  "created_at" : "2013-08-24 12:01:35 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192758862, 9.4758336598 ]
  },
  "id_str" : "371238453868249088",
  "text" : "\u00ABDie Gitarre klingt nach dem neu bespannen als h\u00E4tte sie mehr Saiten.\u00BB \u2014 \u00ABHast du die Alten nicht abgemacht?\u00BB",
  "id" : 371238453868249088,
  "created_at" : "2013-08-24 11:51:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/y0l8b3ccoz",
      "expanded_url" : "http:\/\/instagram.com\/p\/dZLxanBwjE\/",
      "display_url" : "instagram.com\/p\/dZLxanBwjE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "371231582373576704",
  "text" : "\u00ABSchau mal, wir beide beim B\u00FCrsten!\u00BB http:\/\/t.co\/y0l8b3ccoz",
  "id" : 371231582373576704,
  "created_at" : "2013-08-24 11:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/4TwMWIwtNS",
      "expanded_url" : "http:\/\/instagram.com\/p\/dZHQDFBwuQ\/",
      "display_url" : "instagram.com\/p\/dZHQDFBwuQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "371215848880746496",
  "text" : "Die MVG hat ein seltsames Leistungsspektrum\u2026 http:\/\/t.co\/4TwMWIwtNS",
  "id" : 371215848880746496,
  "created_at" : "2013-08-24 10:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spieluhr",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191557952, 9.4752712372 ]
  },
  "id_str" : "371205378258001920",
  "text" : "\u00ABEr greift schon immer danach, aber er hat noch nicht verstanden das man am Schwanz ziehen muss, damit es wieder los geht.\u00BB #spieluhr",
  "id" : 371205378258001920,
  "created_at" : "2013-08-24 09:40:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3189104246, 9.4758500565 ]
  },
  "id_str" : "371197586306527232",
  "text" : "\u00ABDas ist eine Banane, nicht dein Penis.\u00BB #om13",
  "id" : 371197586306527232,
  "created_at" : "2013-08-24 09:09:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "indices" : [ 3, 16 ],
      "id_str" : "9221622",
      "id" : 9221622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/sM7R295xPO",
      "expanded_url" : "http:\/\/bit.ly\/1d9We0b",
      "display_url" : "bit.ly\/1d9We0b"
    } ]
  },
  "geo" : { },
  "id_str" : "371187217655689216",
  "text" : "RT @andrewducker: Are vulvas so obscene that we have to censor them? (NSFW) http:\/\/t.co\/sM7R295xPO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/sM7R295xPO",
        "expanded_url" : "http:\/\/bit.ly\/1d9We0b",
        "display_url" : "bit.ly\/1d9We0b"
      } ]
    },
    "geo" : { },
    "id_str" : "371172628540960768",
    "text" : "Are vulvas so obscene that we have to censor them? (NSFW) http:\/\/t.co\/sM7R295xPO",
    "id" : 371172628540960768,
    "created_at" : "2013-08-24 07:30:25 +0000",
    "user" : {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "protected" : false,
      "id_str" : "9221622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512715233370976256\/QfL7JYGT_normal.jpeg",
      "id" : 9221622,
      "verified" : false
    }
  },
  "id" : 371187217655689216,
  "created_at" : "2013-08-24 08:28:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3186569911, 9.4758703092 ]
  },
  "id_str" : "371186264810487808",
  "text" : "Achievement unlocked: Mit gr\u00FCnen Creepercards verpr\u00FCgelt worden. #om13",
  "id" : 371186264810487808,
  "created_at" : "2013-08-24 08:24:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 4, 14 ],
      "id_str" : "15494684",
      "id" : 15494684
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 78, 87 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3186584789, 9.4758692188 ]
  },
  "id_str" : "371185144021135360",
  "text" : "Mit @zeitweise er\u00F6ffnet die Netzgemeinde ihren allj\u00E4hrlichen Gottesdienst. RT @Senficon: \u201ELiebe Suchende\u201C. Hach, ich bin zuhause. #om13",
  "id" : 371185144021135360,
  "created_at" : "2013-08-24 08:20:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192476135, 9.4754373578 ]
  },
  "id_str" : "371162654196654080",
  "text" : "\u00ABStrohballen umschubsen. Klingt nicht so, aber ist besoffen genauso lustig wie K\u00FChe schubsen. Willkommen in Oldenburg!\u00BB",
  "id" : 371162654196654080,
  "created_at" : "2013-08-24 06:50:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191874468, 9.4756298047 ]
  },
  "id_str" : "371059163147022336",
  "text" : "\u00ABWas, vor 28 Minuten hat er das getwittert? Dann hat er uns ja auch geh\u00F6rt!\u00BB #om13",
  "id" : 371059163147022336,
  "created_at" : "2013-08-23 23:59:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3190518169, 9.4754213351 ]
  },
  "id_str" : "371054327764643840",
  "text" : "\u00ABWenn du Komplexe wegen deines Alters hast solltest du dir keinen J\u00FCngeren anlachen!\u00BB #om13",
  "id" : 371054327764643840,
  "created_at" : "2013-08-23 23:40:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371053659167412224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3190518169, 9.4754213351 ]
  },
  "id_str" : "371054018401173504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lube is loot!",
  "id" : 371054018401173504,
  "in_reply_to_status_id" : 371053659167412224,
  "created_at" : "2013-08-23 23:39:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3177505245, 9.4751034779 ]
  },
  "id_str" : "370985613421707264",
  "text" : "\u00ABIn-Ihr-H\u00F6rer? Du meinst Geh\u00F6rschutz?\u00BB",
  "id" : 370985613421707264,
  "created_at" : "2013-08-23 19:07:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3177505245, 9.4751034779 ]
  },
  "id_str" : "370979572902559745",
  "text" : "\u00ABWir sind etwas sp\u00E4t dran. Wir hatten noch krassen Verkehr.\u00BB",
  "id" : 370979572902559745,
  "created_at" : "2013-08-23 18:43:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    }, {
      "name" : "herzbruch",
      "screen_name" : "herzbruch1",
      "indices" : [ 24, 35 ],
      "id_str" : "622213000",
      "id" : 622213000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xrpcqL2BEn",
      "expanded_url" : "http:\/\/herzbruch.blogger.de\/stories\/2306881\/#2307037",
      "display_url" : "herzbruch.blogger.de\/stories\/230688\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370935510661095424",
  "text" : "RT @fragmente: Wie Frau @herzbruch1 eine Strafanzeige bekam (und austeilte): http:\/\/t.co\/xrpcqL2BEn (gro\u00DFes Kino)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "herzbruch",
        "screen_name" : "herzbruch1",
        "indices" : [ 9, 20 ],
        "id_str" : "622213000",
        "id" : 622213000
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/xrpcqL2BEn",
        "expanded_url" : "http:\/\/herzbruch.blogger.de\/stories\/2306881\/#2307037",
        "display_url" : "herzbruch.blogger.de\/stories\/230688\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369560796889481216",
    "text" : "Wie Frau @herzbruch1 eine Strafanzeige bekam (und austeilte): http:\/\/t.co\/xrpcqL2BEn (gro\u00DFes Kino)",
    "id" : 369560796889481216,
    "created_at" : "2013-08-19 20:45:34 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 370935510661095424,
  "created_at" : "2013-08-23 15:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/5uHK5LLkNV",
      "expanded_url" : "http:\/\/instagram.com\/p\/dKW80ohwpR\/",
      "display_url" : "instagram.com\/p\/dKW80ohwpR\/"
    } ]
  },
  "in_reply_to_status_id_str" : "370898128045883392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095792304, 8.2829465182 ]
  },
  "id_str" : "370898360611663873",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich am Hbf: http:\/\/t.co\/5uHK5LLkNV :)",
  "id" : 370898360611663873,
  "in_reply_to_status_id" : 370898128045883392,
  "created_at" : "2013-08-23 13:20:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamescom",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009641888, 8.2829726435 ]
  },
  "id_str" : "370897540700733440",
  "text" : "\u00ABKommst du mit Duschen?\u00BB \u2014 \u00ABWieso, ist schon wieder #gamescom?\u00BB",
  "id" : 370897540700733440,
  "created_at" : "2013-08-23 13:17:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 76, 83 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095535424, 8.2828797837 ]
  },
  "id_str" : "370890428297793536",
  "text" : "\u00ABHabt ihr eigentlich \u00FCberlegt was f\u00FCr Konsequenzen es haben k\u00F6nnte wenn ihr @lsanoj alleine in eine Wohnung voller Gitarre lasst?\u00BB",
  "id" : 370890428297793536,
  "created_at" : "2013-08-23 12:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/p44wBS12CE",
      "expanded_url" : "http:\/\/instagram.com\/p\/dWUBr9Bwvf\/",
      "display_url" : "instagram.com\/p\/dWUBr9Bwvf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370821847723806721",
  "text" : "\u00ABSchau mal, dein Blutfleck sieht aus wie ein Vogel!\u00BB http:\/\/t.co\/p44wBS12CE",
  "id" : 370821847723806721,
  "created_at" : "2013-08-23 08:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9750714191, 8.189951051 ]
  },
  "id_str" : "370679324804120576",
  "text" : "\u00ABLiegst du bequem?\u00BB \u2014 \u00ABJa, in meinem Blut\u2026\u00BB",
  "id" : 370679324804120576,
  "created_at" : "2013-08-22 22:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/ta9Rv0xTzN",
      "expanded_url" : "http:\/\/instagram.com\/p\/dVCR8xBwgP\/",
      "display_url" : "instagram.com\/p\/dVCR8xBwgP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370641934404321282",
  "text" : "Um die Wette spritzen. http:\/\/t.co\/ta9Rv0xTzN",
  "id" : 370641934404321282,
  "created_at" : "2013-08-22 20:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9750008365, 8.1899904166 ]
  },
  "id_str" : "370639806868774912",
  "text" : "\u00ABIch finde nicht das deine F\u00FCrze stinken.\u00BB \u2014 \u00ABIch liebe dich auch!\u00BB",
  "id" : 370639806868774912,
  "created_at" : "2013-08-22 20:13:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9751933257, 8.1901761489 ]
  },
  "id_str" : "370638574326411264",
  "text" : "\u00ABSeine eigenen F\u00FCrze nicht m\u00F6gen ist kodifizierter Selbsthass.\u00BB",
  "id" : 370638574326411264,
  "created_at" : "2013-08-22 20:08:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370565527875235843",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1767433329, 8.6172839126 ]
  },
  "id_str" : "370565687590526976",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon das ist ja der \u00DCberraschungspart. ;)",
  "id" : 370565687590526976,
  "in_reply_to_status_id" : 370565527875235843,
  "created_at" : "2013-08-22 15:18:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370558774404067328",
  "text" : "\"By the predictive power of Grayskull!\"",
  "id" : 370558774404067328,
  "created_at" : "2013-08-22 14:51:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370552861278482432",
  "text" : "That's a first: My age was just underestimated!",
  "id" : 370552861278482432,
  "created_at" : "2013-08-22 14:27:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370552294137286656",
  "text" : "\"Ich soll mit dir die Details zu den Katzen ausmachen. Wollen wir mal sabbern?\" - Well played, Autokorrektur\u2026",
  "id" : 370552294137286656,
  "created_at" : "2013-08-22 14:25:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370548824265076736",
  "text" : "\u00DCberraschungsbesuch vom Hund &lt;3",
  "id" : 370548824265076736,
  "created_at" : "2013-08-22 14:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370538736225767424",
  "text" : "\"Note: Numerical optimization cannot work miracles\" Thx for the hint, R.",
  "id" : 370538736225767424,
  "created_at" : "2013-08-22 13:31:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370479370579619840",
  "geo" : { },
  "id_str" : "370479481825153024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that should make for an army of banana costumes by now!",
  "id" : 370479481825153024,
  "in_reply_to_status_id" : 370479370579619840,
  "created_at" : "2013-08-22 09:36:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370477123237986304",
  "geo" : { },
  "id_str" : "370477365500997632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer after all those \"hi\"-messages weren't sent in vain! (I expect it to wear a banana costume!)",
  "id" : 370477365500997632,
  "in_reply_to_status_id" : 370477123237986304,
  "created_at" : "2013-08-22 09:27:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370475677239107584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172306529, 8.6276397633 ]
  },
  "id_str" : "370476741577699329",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju I swear, I just snip tripped over and fell into her!",
  "id" : 370476741577699329,
  "in_reply_to_status_id" : 370475677239107584,
  "created_at" : "2013-08-22 09:25:12 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370475426440704000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172306529, 8.6276397633 ]
  },
  "id_str" : "370475601209327616",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju \u2018Teil' sollte es sein, aber das kann auch sehr trippig sein. ;)",
  "id" : 370475601209327616,
  "in_reply_to_status_id" : 370475426440704000,
  "created_at" : "2013-08-22 09:20:41 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370474623613145090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172306529, 8.6276397633 ]
  },
  "id_str" : "370475429909774336",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju gib mir deinen haploiden Satz, du Sau!",
  "id" : 370475429909774336,
  "in_reply_to_status_id" : 370474623613145090,
  "created_at" : "2013-08-22 09:20:00 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370474576242683904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722993864, 8.627648849 ]
  },
  "id_str" : "370475362431795200",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju \u2018Hier sind \u00FCbrigens meine SNPs frei runterladbar, falls ihr mit einem Trip meines Genomes spielen wollt\u2019",
  "id" : 370475362431795200,
  "in_reply_to_status_id" : 370474576242683904,
  "created_at" : "2013-08-22 09:19:44 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Hh85FlcTUU",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/f2eab241c484c343c4d3fcf14c338298\/tumblr_mh157eMiV81s14h9co1_500.gif",
      "display_url" : "24.media.tumblr.com\/f2eab241c484c3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370472735522045952",
  "geo" : { },
  "id_str" : "370474418922721280",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju http:\/\/t.co\/Hh85FlcTUU (f\u00FCr das Klonen!)",
  "id" : 370474418922721280,
  "in_reply_to_status_id" : 370472735522045952,
  "created_at" : "2013-08-22 09:15:59 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/7Gy1OboWtL",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/21\/magic-beard.html",
      "display_url" : "boingboing.net\/2013\/08\/21\/mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370471085138915328",
  "text" : "Magic Beard (breaks my heart around the 1:00 minute mark) http:\/\/t.co\/7Gy1OboWtL",
  "id" : 370471085138915328,
  "created_at" : "2013-08-22 09:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/OvIqfPjjmc",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/21\/shark-inside-sharks-mouth.html",
      "display_url" : "boingboing.net\/2013\/08\/21\/sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370469482361155584",
  "text" : "Yo dawg, i herd u like sharks\u2026 http:\/\/t.co\/OvIqfPjjmc",
  "id" : 370469482361155584,
  "created_at" : "2013-08-22 08:56:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/aat7Siw4eY",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/21\/swedish-seventies-neoretrofutu.html",
      "display_url" : "boingboing.net\/2013\/08\/21\/swe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370467152345567232",
  "text" : "Swedish seventies neoretrofuturism: the paintings of Simon St\u00E5lenhag http:\/\/t.co\/aat7Siw4eY",
  "id" : 370467152345567232,
  "created_at" : "2013-08-22 08:47:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4CoTU8Mv9Y",
      "expanded_url" : "http:\/\/xkcd.com\/1254\/",
      "display_url" : "xkcd.com\/1254\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370464933596508160",
  "text" : "A pretty accurate description of how @PhilippBayer and I tend to communicate. http:\/\/t.co\/4CoTU8Mv9Y",
  "id" : 370464933596508160,
  "created_at" : "2013-08-22 08:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 76, 85 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/OIHycgnVts",
      "expanded_url" : "http:\/\/comics.billroundy.com\/?p=1116",
      "display_url" : "comics.billroundy.com\/?p=1116"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0945620411, 8.7522794099 ]
  },
  "id_str" : "370443141994016768",
  "text" : "\u00ABIt\u2019s like the Orientation Police are on patrol\u00BB http:\/\/t.co\/OIHycgnVts \/HT @Senficon",
  "id" : 370443141994016768,
  "created_at" : "2013-08-22 07:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0945598207, 8.7522489688 ]
  },
  "id_str" : "370441549001531392",
  "text" : "\u00ABWas?! Du willst keine 12 Partner? Sorry, das klingt aber nicht sehr poly, mehr nach oligo\u2026\u00BB",
  "id" : 370441549001531392,
  "created_at" : "2013-08-22 07:05:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/xiuQhOz7y0",
      "expanded_url" : "http:\/\/instagram.com\/p\/dSlTiEBwpI\/",
      "display_url" : "instagram.com\/p\/dSlTiEBwpI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370296778543099904",
  "text" : "\u00ABDid you install the wrong device drivers?\u00BB http:\/\/t.co\/xiuQhOz7y0",
  "id" : 370296778543099904,
  "created_at" : "2013-08-21 21:30:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0948306889, 8.7519546713 ]
  },
  "id_str" : "370296262962454528",
  "text" : "\u00ABIch hab deine Fettexplosion schon auf Instagram gesehen!\u00BB \u2014 \u00ABSagt die Frau die ihren Pizza-Rekord gerade bricht\u2026\u00BB",
  "id" : 370296262962454528,
  "created_at" : "2013-08-21 21:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.099567883, 8.7487217603 ]
  },
  "id_str" : "370267690612850688",
  "text" : "@JoergR it\u2019s biology. You can always claim the unpredictability of natural systems made you do it.",
  "id" : 370267690612850688,
  "created_at" : "2013-08-21 19:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1046687636, 8.6973322008 ]
  },
  "id_str" : "370264390924533760",
  "text" : "Success: Yay, my Markov chains are trained (slighty) better than chance aka coin flips!",
  "id" : 370264390924533760,
  "created_at" : "2013-08-21 19:21:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/1huy045Dgt",
      "expanded_url" : "http:\/\/instagram.com\/p\/dSN7aMBwjN\/",
      "display_url" : "instagram.com\/p\/dSN7aMBwjN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "370251495671091200",
  "text" : "Staying late can be nice. @ Biologicum http:\/\/t.co\/1huy045Dgt",
  "id" : 370251495671091200,
  "created_at" : "2013-08-21 18:30:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/nY4M8wZJgk",
      "expanded_url" : "http:\/\/instagram.com\/p\/dRzAGKhwrs\/",
      "display_url" : "instagram.com\/p\/dRzAGKhwrs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "370200961224282112",
  "text" : "\u00ABF\u00E4r de Hesse is des glei: Robbe, klobbe, l\u00F6sche!\u00BB http:\/\/t.co\/nY4M8wZJgk",
  "id" : 370200961224282112,
  "created_at" : "2013-08-21 15:09:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/0g6DNN1uxL",
      "expanded_url" : "http:\/\/instagram.com\/p\/dRoAWPhwuR\/",
      "display_url" : "instagram.com\/p\/dRoAWPhwuR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172766268, 8.6300062943 ]
  },
  "id_str" : "370162034404773888",
  "text" : "How-Not-To @ Goethe-Universit\u00E4t - Biozentrum http:\/\/t.co\/0g6DNN1uxL",
  "id" : 370162034404773888,
  "created_at" : "2013-08-21 12:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/a8l1rSeGrW",
      "expanded_url" : "http:\/\/13.openmind-konferenz.de\/veranstaltung\/anmeldung\/",
      "display_url" : "13.openmind-konferenz.de\/veranstaltung\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721792957, 8.6276160079 ]
  },
  "id_str" : "370140555466268673",
  "text" : "Es gibt immer noch ein paar Tickets f\u00FCr die #om13 f\u00FCr Kurzentschlossene: http:\/\/t.co\/a8l1rSeGrW",
  "id" : 370140555466268673,
  "created_at" : "2013-08-21 11:09:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/RUiZYWjOiO",
      "expanded_url" : "http:\/\/instagram.com\/p\/dRW-zQhwuh\/",
      "display_url" : "instagram.com\/p\/dRW-zQhwuh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "370124582944256000",
  "text" : "Omnomnom, wilde Brombeeren @ Biologicum http:\/\/t.co\/RUiZYWjOiO",
  "id" : 370124582944256000,
  "created_at" : "2013-08-21 10:05:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 3, 13 ],
      "id_str" : "14937469",
      "id" : 14937469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/6RCDR8PnQH",
      "expanded_url" : "http:\/\/0cn.de\/y0lh",
      "display_url" : "0cn.de\/y0lh"
    } ]
  },
  "geo" : { },
  "id_str" : "370059226515001344",
  "text" : "RT @v_i_o_l_a: an der ulb m\u00FCnster sind drei befristete dipl.bibl.stellen ausgeschrieben: http:\/\/t.co\/6RCDR8PnQH bewerbungsfrist: 13.9.13. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bibliojobs",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/6RCDR8PnQH",
        "expanded_url" : "http:\/\/0cn.de\/y0lh",
        "display_url" : "0cn.de\/y0lh"
      } ]
    },
    "geo" : { },
    "id_str" : "370059130154668033",
    "text" : "an der ulb m\u00FCnster sind drei befristete dipl.bibl.stellen ausgeschrieben: http:\/\/t.co\/6RCDR8PnQH bewerbungsfrist: 13.9.13. #bibliojobs",
    "id" : 370059130154668033,
    "created_at" : "2013-08-21 05:45:46 +0000",
    "user" : {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "protected" : false,
      "id_str" : "14937469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908747934547742720\/JdLgkzf8_normal.jpg",
      "id" : 14937469,
      "verified" : false
    }
  },
  "id" : 370059226515001344,
  "created_at" : "2013-08-21 05:46:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/S8g5HIeysM",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=TqDsMEOYA9g",
      "display_url" : "youtube.com\/watch?v=TqDsME\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072620763, 8.2819492277 ]
  },
  "id_str" : "370045000866074625",
  "text" : "Next up: Rausfinden ob mir das Internet eine falsche Vorstellung von Brandschutz vermittelt hat. http:\/\/t.co\/S8g5HIeysM",
  "id" : 370045000866074625,
  "created_at" : "2013-08-21 04:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096907034, 8.2830222283 ]
  },
  "id_str" : "369956988245258241",
  "text" : "\u00ABDu riechst so als h\u00E4ttest du einen sch\u00F6nen Nachmittag gehabt.\u00BB",
  "id" : 369956988245258241,
  "created_at" : "2013-08-20 22:59:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369952888807628800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096900205, 8.2830105164 ]
  },
  "id_str" : "369953257692872704",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju \u2018Schlag mich einfach in den Schlaf'",
  "id" : 369953257692872704,
  "in_reply_to_status_id" : 369952888807628800,
  "created_at" : "2013-08-20 22:45:04 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Kathryn Schulz",
      "screen_name" : "kathrynschulz",
      "indices" : [ 100, 114 ],
      "id_str" : "119625403",
      "id" : 119625403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KlwBMDvFJd",
      "expanded_url" : "http:\/\/onion.com\/1aoNLnC",
      "display_url" : "onion.com\/1aoNLnC"
    } ]
  },
  "geo" : { },
  "id_str" : "369929840306450432",
  "text" : "RT @edyong209: HA! The Onion\u2019s tribute to Elmore Leonard is the best thing they\u2019ve done for ages RT @kathrynschulz http:\/\/t.co\/KlwBMDvFJd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathryn Schulz",
        "screen_name" : "kathrynschulz",
        "indices" : [ 85, 99 ],
        "id_str" : "119625403",
        "id" : 119625403
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/KlwBMDvFJd",
        "expanded_url" : "http:\/\/onion.com\/1aoNLnC",
        "display_url" : "onion.com\/1aoNLnC"
      } ]
    },
    "geo" : { },
    "id_str" : "369923590642483201",
    "text" : "HA! The Onion\u2019s tribute to Elmore Leonard is the best thing they\u2019ve done for ages RT @kathrynschulz http:\/\/t.co\/KlwBMDvFJd",
    "id" : 369923590642483201,
    "created_at" : "2013-08-20 20:47:11 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 369929840306450432,
  "created_at" : "2013-08-20 21:12:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/3SXcov49kS",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/19\/burning-man-drone-rules.html",
      "display_url" : "boingboing.net\/2013\/08\/19\/bur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369907955808104448",
  "text" : "Burning Man drone\u00A0rules http:\/\/t.co\/3SXcov49kS",
  "id" : 369907955808104448,
  "created_at" : "2013-08-20 19:45:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/DS8WU8oiMW",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/08\/fungus-and-bacteria-play-game-theory-to-make-biofuels\/",
      "display_url" : "arstechnica.com\/science\/2013\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369907503192350720",
  "text" : "Fungus and bacteria play game theory to make biofuels http:\/\/t.co\/DS8WU8oiMW",
  "id" : 369907503192350720,
  "created_at" : "2013-08-20 19:43:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/qdq95jmKVa",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/19\/bsa-to-hacker-scouts-change-y.html",
      "display_url" : "boingboing.net\/2013\/08\/19\/bsa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369903391235133440",
  "text" : "BSA to Hacker Scouts: change your name or be\u00A0sued m( http:\/\/t.co\/qdq95jmKVa",
  "id" : 369903391235133440,
  "created_at" : "2013-08-20 19:26:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/70syg9Y5PE",
      "expanded_url" : "http:\/\/instagram.com\/p\/dPn66gBwvK\/",
      "display_url" : "instagram.com\/p\/dPn66gBwvK\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0012153697, 8.2858138472 ]
  },
  "id_str" : "369880423494877184",
  "text" : "Food? @ Maaraue http:\/\/t.co\/70syg9Y5PE",
  "id" : 369880423494877184,
  "created_at" : "2013-08-20 17:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/2qESrJGHyW",
      "expanded_url" : "http:\/\/instagram.com\/p\/dPnbXJBwuR\/",
      "display_url" : "instagram.com\/p\/dPnbXJBwuR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0012153697, 8.2858138472 ]
  },
  "id_str" : "369879246380212224",
  "text" : "Gustavsburger Eisenbahnbr\u00FCcke @ Maaraue http:\/\/t.co\/2qESrJGHyW",
  "id" : 369879246380212224,
  "created_at" : "2013-08-20 17:50:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "indices" : [ 3, 16 ],
      "id_str" : "158112993",
      "id" : 158112993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/3GY27DIk6p",
      "expanded_url" : "http:\/\/13.openmind-konferenz.de\/veranstaltung\/anmeldung\/",
      "display_url" : "13.openmind-konferenz.de\/veranstaltung\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369877195214585856",
  "text" : "RT @openmindkonf: Schnell zugreifen! Es gibt wieder Tickets f\u00FCr die openmind #om13 am kommenden Wochenende: http:\/\/t.co\/3GY27DIk6p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "om13",
        "indices" : [ 59, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/3GY27DIk6p",
        "expanded_url" : "http:\/\/13.openmind-konferenz.de\/veranstaltung\/anmeldung\/",
        "display_url" : "13.openmind-konferenz.de\/veranstaltung\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369877049617694720",
    "text" : "Schnell zugreifen! Es gibt wieder Tickets f\u00FCr die openmind #om13 am kommenden Wochenende: http:\/\/t.co\/3GY27DIk6p",
    "id" : 369877049617694720,
    "created_at" : "2013-08-20 17:42:15 +0000",
    "user" : {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "protected" : false,
      "id_str" : "158112993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836318939831549952\/alPrgEJx_normal.jpg",
      "id" : 158112993,
      "verified" : false
    }
  },
  "id" : 369877195214585856,
  "created_at" : "2013-08-20 17:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007404862, 8.2799664047 ]
  },
  "id_str" : "369873920343961600",
  "text" : "\u00ABSo naturgetreu, charakteristisch und auch etwas plump.\u00BB \u2014 \u00ABRedest du von dem T-Shirt oder von mir?\u00BB",
  "id" : 369873920343961600,
  "created_at" : "2013-08-20 17:29:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 25, 35 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369868994876289024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369870125673218048",
  "in_reply_to_user_id" : 549994796,
  "text" : "@Literalschaden @levudev @prauscher Bei beiden Seiten:\nAAAT\nTTTA\ndann:\nsum(A) == sum(T) &amp; sum(G) == sum(C)",
  "id" : 369870125673218048,
  "in_reply_to_status_id" : 369868994876289024,
  "created_at" : "2013-08-20 17:14:44 +0000",
  "in_reply_to_screen_name" : "literal_lia",
  "in_reply_to_user_id_str" : "549994796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 25, 35 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369868994876289024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369869915991597056",
  "in_reply_to_user_id" : 549994796,
  "text" : "@Literalschaden @levudev @prauscher Na schaut man sich nur eine Seite des Doppelstrangs an, dann kann es != in der Anzahl sein, e.g. AAAT.",
  "id" : 369869915991597056,
  "in_reply_to_status_id" : 369868994876289024,
  "created_at" : "2013-08-20 17:13:54 +0000",
  "in_reply_to_screen_name" : "literal_lia",
  "in_reply_to_user_id_str" : "549994796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 9, 19 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096517202, 8.283049244 ]
  },
  "id_str" : "369866971229478913",
  "text" : "@levudev @prauscher dann kommt es drauf an ob man Single oder Double Strand betrachtet. ;)",
  "id" : 369866971229478913,
  "created_at" : "2013-08-20 17:02:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369864878187896833",
  "text" : "\u00ABSeit du mir regelm\u00E4ssig die Nase ausleckst blutet sie voll oft!\u00BB \u2013 \u00ABAwww, deine auch?! Mir geht es andersrum genauso!\u00BB",
  "id" : 369864878187896833,
  "created_at" : "2013-08-20 16:53:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369818886155534336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968582, 8.2831028643 ]
  },
  "id_str" : "369863693791940608",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher kommt drauf an was du mit A!=T meinst und wo sind die Angaben? ;)",
  "id" : 369863693791940608,
  "in_reply_to_status_id" : 369818886155534336,
  "created_at" : "2013-08-20 16:49:10 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369738927587864576",
  "text" : "\"Thank you for noticing that this is *NOT* a crash, but a controlled program stop.\"",
  "id" : 369738927587864576,
  "created_at" : "2013-08-20 08:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/1i8U2gqT1p",
      "expanded_url" : "http:\/\/cl.ly\/image\/1q2R1a3Q0Z0y",
      "display_url" : "cl.ly\/image\/1q2R1a3Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369716011945447424",
  "text" : "RT @waxpancake: There, I fixed Dave Winer's post. http:\/\/t.co\/1i8U2gqT1p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/1i8U2gqT1p",
        "expanded_url" : "http:\/\/cl.ly\/image\/1q2R1a3Q0Z0y",
        "display_url" : "cl.ly\/image\/1q2R1a3Q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369627466685374464",
    "text" : "There, I fixed Dave Winer's post. http:\/\/t.co\/1i8U2gqT1p",
    "id" : 369627466685374464,
    "created_at" : "2013-08-20 01:10:30 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590385501179289602\/qvTvxmCX_normal.png",
      "id" : 13461,
      "verified" : true
    }
  },
  "id" : 369716011945447424,
  "created_at" : "2013-08-20 07:02:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UqimQz9Hc3",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/369679446619340800",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096347631, 8.2830714362 ]
  },
  "id_str" : "369701941502545920",
  "text" : "1st I thought @PhilippBayer was just poking fun at me for obv reasons. But he\u2019s right, I did work\/do a course there https:\/\/t.co\/UqimQz9Hc3",
  "id" : 369701941502545920,
  "created_at" : "2013-08-20 06:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 30, 46 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369700557478719488",
  "text" : "RT @PhilippBayer: Pretty sure @gedankenstuecke worked there: \"German University's Research Animals Evicted After Neighbor Complains\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 12, 28 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LRaguvnbWn",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/08\/16\/guinea-pig-sex-too-loud-complaint-germany_n_3768351.html?utm_hp_ref=fb&src=sp&comm_ref=false#sb=4157027b=facebook",
        "display_url" : "huffingtonpost.com\/2013\/08\/16\/gui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369679446619340800",
    "text" : "Pretty sure @gedankenstuecke worked there: \"German University's Research Animals Evicted After Neighbor Complains\" http:\/\/t.co\/LRaguvnbWn",
    "id" : 369679446619340800,
    "created_at" : "2013-08-20 04:37:03 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 369700557478719488,
  "created_at" : "2013-08-20 06:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369604176793595904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096287796, 8.2830637759 ]
  },
  "id_str" : "369604647742607360",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj zur Verbesserung der Versorgungslinie um schneller an Nachschub zu kommen?",
  "id" : 369604647742607360,
  "in_reply_to_status_id" : 369604176793595904,
  "created_at" : "2013-08-19 23:39:49 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 15, 24 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 25, 31 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369600553984086017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965972, 8.28302819 ]
  },
  "id_str" : "369600713883922432",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @Senficon @_Rya_ Alles au\u00DFer 4:3 oder 16:9 ist unnat\u00FCrlich!",
  "id" : 369600713883922432,
  "in_reply_to_status_id" : 369600553984086017,
  "created_at" : "2013-08-19 23:24:11 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "indices" : [ 0, 13 ],
      "id_str" : "158112993",
      "id" : 158112993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369590746380500992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965972, 8.28302819 ]
  },
  "id_str" : "369591979711426560",
  "in_reply_to_user_id" : 158112993,
  "text" : "@openmindkonf danke!",
  "id" : 369591979711426560,
  "in_reply_to_status_id" : 369590746380500992,
  "created_at" : "2013-08-19 22:49:29 +0000",
  "in_reply_to_screen_name" : "openmindkonf",
  "in_reply_to_user_id_str" : "158112993",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura S. Dornheim",
      "screen_name" : "schwarzblond",
      "indices" : [ 82, 95 ],
      "id_str" : "402220351",
      "id" : 402220351
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 100, 107 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QkKmlJTQWo",
      "expanded_url" : "https:\/\/pentabarf.junge-piraten.de\/fahrplan\/om13\/day_2013-08-25.de.html",
      "display_url" : "pentabarf.junge-piraten.de\/fahrplan\/om13\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711065, 8.2830014625 ]
  },
  "id_str" : "369585645494484992",
  "text" : "Die letzten beiden L\u00FCcken im #om13 Fahrplan sind soeben geschlossen worden: Gratz @schwarzblond und @acid23!  https:\/\/t.co\/QkKmlJTQWo",
  "id" : 369585645494484992,
  "created_at" : "2013-08-19 22:24:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369580901602439168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096843483, 8.2831034233 ]
  },
  "id_str" : "369581531335233536",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj fair enough, danke :)",
  "id" : 369581531335233536,
  "in_reply_to_status_id" : 369580901602439168,
  "created_at" : "2013-08-19 22:07:58 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369580356221288448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096843483, 8.2831034233 ]
  },
  "id_str" : "369580496239730688",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj wie kommst du darauf? ;)",
  "id" : 369580496239730688,
  "in_reply_to_status_id" : 369580356221288448,
  "created_at" : "2013-08-19 22:03:51 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 60, 66 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369570425170558976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096843483, 8.2831034233 ]
  },
  "id_str" : "369570779052388352",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy und dann wird wieder auf den Zimmern geraucht und Frau @_Rya_ muss ihre Ausbildung ausspielen. ;)",
  "id" : 369570779052388352,
  "in_reply_to_status_id" : 369570425170558976,
  "created_at" : "2013-08-19 21:25:14 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 10, 23 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Michael Ebner",
      "screen_name" : "MichaelEbnerPP",
      "indices" : [ 24, 39 ],
      "id_str" : "375484736",
      "id" : 375484736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/bbozjT8nls",
      "expanded_url" : "https:\/\/wiki.piratenpartei.de\/Openmind\/2013#Mitfahrb.C3.B6rse",
      "display_url" : "wiki.piratenpartei.de\/Openmind\/2013#\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369566497922088960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096843483, 8.2831034233 ]
  },
  "id_str" : "369566634664792064",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Naturalismus @MichaelEbnerPP steht schon drin https:\/\/t.co\/bbozjT8nls",
  "id" : 369566634664792064,
  "in_reply_to_status_id" : 369566497922088960,
  "created_at" : "2013-08-19 21:08:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096843483, 8.2831034233 ]
  },
  "id_str" : "369565490571919360",
  "text" : "\u00ABOrr, ich hasse gedrosselt sein!\u00BB \u2013 \u00ABGedrosselt werden hingegen\u2026\u00BB",
  "id" : 369565490571919360,
  "created_at" : "2013-08-19 21:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0113273832, 8.2772926614 ]
  },
  "id_str" : "369563061780488192",
  "text" : "\u00ABOh, schau mal, fast Vollmond! Mh, wie ein Fleischkl\u00F6\u00DFchen. Ich glaube ich esse gleich Nudeln.\u00BB \u2014 \u00ABDu bist so romantisch!\u00BB",
  "id" : 369563061780488192,
  "created_at" : "2013-08-19 20:54:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369541338733084672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009584684, 8.282955878 ]
  },
  "id_str" : "369541401035296768",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Im Vergleich zu den anderen Locations auf jeden Fall.",
  "id" : 369541401035296768,
  "in_reply_to_status_id" : 369541338733084672,
  "created_at" : "2013-08-19 19:28:30 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369540937531129856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009584684, 8.282955878 ]
  },
  "id_str" : "369541189709488128",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Wader in der Alten Oper!",
  "id" : 369541189709488128,
  "in_reply_to_status_id" : 369540937531129856,
  "created_at" : "2013-08-19 19:27:40 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369540313305473025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009584684, 8.282955878 ]
  },
  "id_str" : "369540776734105600",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Wader oder Wecker oder egal? ;)",
  "id" : 369540776734105600,
  "in_reply_to_status_id" : 369540313305473025,
  "created_at" : "2013-08-19 19:26:01 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369539910656466944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009584684, 8.282955878 ]
  },
  "id_str" : "369540266325069824",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng wir m\u00FCssen noch auf so ein Konzert! &lt;3",
  "id" : 369540266325069824,
  "in_reply_to_status_id" : 369539910656466944,
  "created_at" : "2013-08-19 19:23:59 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/a2bWO4UIuN",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/b038c0fj",
      "display_url" : "bbc.co.uk\/programmes\/b03\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009584684, 8.282955878 ]
  },
  "id_str" : "369535293214294016",
  "text" : "Now on BBC Radio 4: \u00ABMonogamy and the Rules of Love\u00BB http:\/\/t.co\/a2bWO4UIuN",
  "id" : 369535293214294016,
  "created_at" : "2013-08-19 19:04:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095357454, 8.2829692333 ]
  },
  "id_str" : "369529045966258177",
  "text" : "Hat gedauert bis ich gemerkt habe das meine Mutter in ihrer Mail mit \u2018den beiden S\u00FC\u00DFen\u2019 die Katzen meint. Suddenly: Ganz anderer Inhalt. m)",
  "id" : 369529045966258177,
  "created_at" : "2013-08-19 18:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0676789712, 8.4890552928 ]
  },
  "id_str" : "369512497805418496",
  "text" : "\u00ABthere is a dearth of people with relevant practical experience in the conduct of thermonuclear wars.\u00BB Who would have guessed? #otnw",
  "id" : 369512497805418496,
  "created_at" : "2013-08-19 17:33:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723218006, 8.6276542234 ]
  },
  "id_str" : "369483533552611328",
  "text" : "TIL: Wurstkalibrator",
  "id" : 369483533552611328,
  "created_at" : "2013-08-19 15:38:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/OakaWafBJs",
      "expanded_url" : "http:\/\/i.imgur.com\/NawfxsB.gif",
      "display_url" : "i.imgur.com\/NawfxsB.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "369462970117414912",
  "text" : "Using SOAPdenovo2 for the first time http:\/\/t.co\/OakaWafBJs",
  "id" : 369462970117414912,
  "created_at" : "2013-08-19 14:16:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/lSbM7gJ5IH",
      "expanded_url" : "http:\/\/www.strikemag.org\/bullshit-jobs\/",
      "display_url" : "strikemag.org\/bullshit-jobs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "369445097680547840",
  "text" : "\"It\u2019s as if someone were out there making up pointless jobs just for the sake of keeping us all working\" http:\/\/t.co\/lSbM7gJ5IH",
  "id" : 369445097680547840,
  "created_at" : "2013-08-19 13:05:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369392281763065856",
  "geo" : { },
  "id_str" : "369392712467750912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer made me think that I'll have to go on with the wool\/silo-series :D",
  "id" : 369392712467750912,
  "in_reply_to_status_id" : 369392281763065856,
  "created_at" : "2013-08-19 09:37:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369388725437865984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725249598, 8.6277441401 ]
  },
  "id_str" : "369391790945607682",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so far it\u2019s great fun. If you think contemplating thermonuclear war qualifies for fun. ;)",
  "id" : 369391790945607682,
  "in_reply_to_status_id" : 369388725437865984,
  "created_at" : "2013-08-19 09:34:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369388077229150208",
  "geo" : { },
  "id_str" : "369388558718488577",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope, I got the print version as I couldn't find any ebook of it iirc, sorry.",
  "id" : 369388558718488577,
  "in_reply_to_status_id" : 369388077229150208,
  "created_at" : "2013-08-19 09:21:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723724324, 8.6276240527 ]
  },
  "id_str" : "369377611920580608",
  "text" : "\u00ABOnce the insert size is long enough they are called a mate pair.\u00BB \u2014 \u00ABI see what you did there\u2026\u00BB",
  "id" : 369377611920580608,
  "created_at" : "2013-08-19 08:37:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369374171735678976",
  "text" : "Is it just me or is the sequence assembly bible (aka the MIRA manual on sourceforge) not available?",
  "id" : 369374171735678976,
  "created_at" : "2013-08-19 08:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1327305474, 8.6723908145 ]
  },
  "id_str" : "369354021812711424",
  "text" : "\u00ABThe Homicide Pact Machine is clearly more satisfactory to both humanitarians and neutrals than the Doomsday Machine\u2026\u00BB #otnw",
  "id" : 369354021812711424,
  "created_at" : "2013-08-19 07:03:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0809423812, 8.5046805808 ]
  },
  "id_str" : "369350947400466433",
  "text" : "\u00ABThere\u2019s no need to promise to destroy the enemy within 15 minutes.It\u2019s perfectly all right to promise to destroy him somewhat later\u00BB #otnw",
  "id" : 369350947400466433,
  "created_at" : "2013-08-19 06:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0787126572, 8.5024784432 ]
  },
  "id_str" : "369346589296304128",
  "text" : "\u00ABThis is the first analysis done by man in which more than 10,000,000 multiplications were made.\u00BB Books from the 60s can be so cute. #otnw",
  "id" : 369346589296304128,
  "created_at" : "2013-08-19 06:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0164471492, 8.4294290682 ]
  },
  "id_str" : "369344542538858497",
  "text" : "\u00ABNat\u00FCrlich will ich von deinen Abenteuern h\u00F6ren. Das ist doch wie Porn, nur mit Leuten f\u00FCr die ich mich interessiere!\u00BB",
  "id" : 369344542538858497,
  "created_at" : "2013-08-19 06:26:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quinnsplainer ' ; DROP TABLE altright_users",
      "screen_name" : "quinnnorton",
      "indices" : [ 3, 15 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feminism",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "yaymen",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/SUcP01PSnI",
      "expanded_url" : "http:\/\/wilwheaton.tumblr.com\/post\/58628885059\/he-waited-until-the-train-was-in-motion-to-make",
      "display_url" : "wilwheaton.tumblr.com\/post\/586288850\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369331949208616960",
  "text" : "RT @quinnnorton: This is amazing and wonderful. http:\/\/t.co\/SUcP01PSnI #feminism #yaymen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "feminism",
        "indices" : [ 54, 63 ]
      }, {
        "text" : "yaymen",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/SUcP01PSnI",
        "expanded_url" : "http:\/\/wilwheaton.tumblr.com\/post\/58628885059\/he-waited-until-the-train-was-in-motion-to-make",
        "display_url" : "wilwheaton.tumblr.com\/post\/586288850\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369246871526469632",
    "text" : "This is amazing and wonderful. http:\/\/t.co\/SUcP01PSnI #feminism #yaymen",
    "id" : 369246871526469632,
    "created_at" : "2013-08-18 23:58:09 +0000",
    "user" : {
      "name" : "Quinnsplainer ' ; DROP TABLE altright_users",
      "screen_name" : "quinnnorton",
      "protected" : false,
      "id_str" : "38975663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925809688989523968\/1LolWEWQ_normal.jpg",
      "id" : 38975663,
      "verified" : false
    }
  },
  "id" : 369331949208616960,
  "created_at" : "2013-08-19 05:36:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 5, 21 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/fqVwDDC5oJ",
      "expanded_url" : "http:\/\/i.imgur.com\/lmGC87I.jpg",
      "display_url" : "i.imgur.com\/lmGC87I.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "369234112768266240",
  "text" : "\u00ABAls @gedankenstuecke  eines Morgens aus unruhigen Tr\u00E4umen erwachte\u2026\u00BB (I wish!) http:\/\/t.co\/fqVwDDC5oJ",
  "id" : 369234112768266240,
  "created_at" : "2013-08-18 23:07:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/TvS0SVEpFv",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/coworker-with-two-computer-screens-not-fucking-aro,29151\/?utm_source=Facebook&utm_medium=SocialMarketing&utm_campaign=LinkPreview:NA:InFocus&recirc=tech-issue",
      "display_url" : "theonion.com\/articles\/cowor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369216010441613312",
  "text" : "Coworker With Two Computer Screens Not Fucking Around http:\/\/t.co\/TvS0SVEpFv",
  "id" : 369216010441613312,
  "created_at" : "2013-08-18 21:55:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/NacUajK4mx",
      "expanded_url" : "http:\/\/img81.imageshack.us\/img81\/5622\/immortal44tv.gif",
      "display_url" : "img81.imageshack.us\/img81\/5622\/imm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369207411338276864",
  "text" : "\u00ABMan merkt an deiner Musikauswahl das du in Skandinavien warst!\u00BB http:\/\/t.co\/NacUajK4mx",
  "id" : 369207411338276864,
  "created_at" : "2013-08-18 21:21:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0116243802, 8.2783226602 ]
  },
  "id_str" : "369189659303108608",
  "text" : "\u00ABNa Baby, darf ich deinen Seed acceleraten?\u00BB \u2014 \u00ABDu liest eindeutig zuviel Hacker News\u2026\u00BB",
  "id" : 369189659303108608,
  "created_at" : "2013-08-18 20:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/rwxXSbZnbZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/dKbMrIBwhF\/",
      "display_url" : "instagram.com\/p\/dKbMrIBwhF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066633432, 8.2770395279 ]
  },
  "id_str" : "369148957424762880",
  "text" : "Hollow Stares @ Theodor-Heuss-Br\u00FCcke http:\/\/t.co\/rwxXSbZnbZ",
  "id" : 369148957424762880,
  "created_at" : "2013-08-18 17:29:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/HC6Ep2X9gM",
      "expanded_url" : "http:\/\/instagram.com\/p\/dKbAzyBwgy\/",
      "display_url" : "instagram.com\/p\/dKbAzyBwgy\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066633432, 8.2770395279 ]
  },
  "id_str" : "369148215506903040",
  "text" : "Axolotl @ Theodor-Heuss-Br\u00FCcke http:\/\/t.co\/HC6Ep2X9gM",
  "id" : 369148215506903040,
  "created_at" : "2013-08-18 17:26:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/r05xCkl6Vv",
      "expanded_url" : "http:\/\/instagram.com\/p\/dKW80ohwpR\/",
      "display_url" : "instagram.com\/p\/dKW80ohwpR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "369139292892696577",
  "text" : "Democracia http:\/\/t.co\/r05xCkl6Vv",
  "id" : 369139292892696577,
  "created_at" : "2013-08-18 16:50:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr J Rogel-Salazar",
      "screen_name" : "quantum_tunnel",
      "indices" : [ 3, 18 ],
      "id_str" : "22902732",
      "id" : 22902732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MWeCrxXUc5",
      "expanded_url" : "http:\/\/twentytwowords.com\/2013\/08\/16\/dolly-partons-original-recording-of-jolene-slowed-down-by-25-is-surprisingly-awesome\/",
      "display_url" : "twentytwowords.com\/2013\/08\/16\/dol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369110255269339136",
  "text" : "RT @quantum_tunnel: \"Dolly Parton\u2019s original recording of 'Jolene' slowed down by 25% is surprisingly awesome\" http:\/\/t.co\/MWeCrxXUc5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/MWeCrxXUc5",
        "expanded_url" : "http:\/\/twentytwowords.com\/2013\/08\/16\/dolly-partons-original-recording-of-jolene-slowed-down-by-25-is-surprisingly-awesome\/",
        "display_url" : "twentytwowords.com\/2013\/08\/16\/dol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369109376524484608",
    "text" : "\"Dolly Parton\u2019s original recording of 'Jolene' slowed down by 25% is surprisingly awesome\" http:\/\/t.co\/MWeCrxXUc5",
    "id" : 369109376524484608,
    "created_at" : "2013-08-18 14:51:47 +0000",
    "user" : {
      "name" : "Dr J Rogel-Salazar",
      "screen_name" : "quantum_tunnel",
      "protected" : false,
      "id_str" : "22902732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926565530600747008\/Tl3Mafyd_normal.jpg",
      "id" : 22902732,
      "verified" : false
    }
  },
  "id" : 369110255269339136,
  "created_at" : "2013-08-18 14:55:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Lm9iFfDDWC",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0069386?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369103782006632450",
  "text" : "Degradation of Oxo-Biodegradable Plastic by Pleurotus ostreatus http:\/\/t.co\/Lm9iFfDDWC",
  "id" : 369103782006632450,
  "created_at" : "2013-08-18 14:29:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/hoNaWrokSd",
      "expanded_url" : "http:\/\/egtheory.wordpress.com\/2013\/08\/16\/fitness-landscapes\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingMathematicsEnglish+%28Research+Blogging+-+English+-+Mathematics%29",
      "display_url" : "egtheory.wordpress.com\/2013\/08\/16\/fit\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369102284723986432",
  "text" : "Fitness landscapes as mental and mathematical models of\u00A0evolution http:\/\/t.co\/hoNaWrokSd",
  "id" : 369102284723986432,
  "created_at" : "2013-08-18 14:23:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/TOnPJNx9Ic",
      "expanded_url" : "http:\/\/instagram.com\/p\/dKE7ByBwqR\/",
      "display_url" : "instagram.com\/p\/dKE7ByBwqR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "369099724919291905",
  "text" : "\u00ABDir w\u00E4chst da etwas seltsames im Gesicht!\u00BB @ Elfenbeinturm http:\/\/t.co\/TOnPJNx9Ic",
  "id" : 369099724919291905,
  "created_at" : "2013-08-18 14:13:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369099036076154881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369099325512482816",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon call me data scientist* (*text en\/decoding monkey)",
  "id" : 369099325512482816,
  "in_reply_to_status_id" : 369099036076154881,
  "created_at" : "2013-08-18 14:11:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Metaliberal",
      "screen_name" : "Metaliberal",
      "indices" : [ 3, 15 ],
      "id_str" : "283095166",
      "id" : 283095166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369076125445918720",
  "text" : "RT @Metaliberal: \"Jerks Destroy Test Fields of Golden Rice in the Philippines. Scientists Pissed. Kids Still Going Blind\" http:\/\/t.co\/KN1JZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ludditen",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/KN1JZFoCDg",
        "expanded_url" : "http:\/\/reason.com\/blog\/2013\/08\/16\/jerks-destroy-test-fields-of-golden-rice",
        "display_url" : "reason.com\/blog\/2013\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369059803177299968",
    "text" : "\"Jerks Destroy Test Fields of Golden Rice in the Philippines. Scientists Pissed. Kids Still Going Blind\" http:\/\/t.co\/KN1JZFoCDg #Ludditen",
    "id" : 369059803177299968,
    "created_at" : "2013-08-18 11:34:48 +0000",
    "user" : {
      "name" : "Metaliberal",
      "screen_name" : "Metaliberal",
      "protected" : false,
      "id_str" : "283095166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892475643300073478\/G2HRiPNf_normal.jpg",
      "id" : 283095166,
      "verified" : false
    }
  },
  "id" : 369076125445918720,
  "created_at" : "2013-08-18 12:39:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097016405, 8.283034902 ]
  },
  "id_str" : "369074995244191745",
  "text" : "\u00ABKein Problem, ich kann den Parser f\u00FCr die Porn-Ontology auch schnell auf deine Wahlprogramme anpassen.\u00BB",
  "id" : 369074995244191745,
  "created_at" : "2013-08-18 12:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/r7zIsXAFn5",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/uncovering-spurious-correlations-between-language-and-culture\/6396.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingSocialScienceEnglish+%28Research+Blogging+-+English+-+Social+Science%29",
      "display_url" : "replicatedtypo.com\/uncovering-spu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369070634598297602",
  "text" : "Confounding variables: Uncovering spurious correlations between language and culture http:\/\/t.co\/r7zIsXAFn5",
  "id" : 369070634598297602,
  "created_at" : "2013-08-18 12:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369068731378331649",
  "text" : "\u00ABDu ern\u00E4hrst dich doch nur von meinem Leid. Und frittiertem Gem\u00FCse.\u00BB",
  "id" : 369068731378331649,
  "created_at" : "2013-08-18 12:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/6L5StGRBEj",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/16\/beastie-boys-sabotage-re.html",
      "display_url" : "boingboing.net\/2013\/08\/16\/bea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "369061947217412096",
  "text" : "Librarians &lt;3 http:\/\/t.co\/6L5StGRBEj",
  "id" : 369061947217412096,
  "created_at" : "2013-08-18 11:43:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096349514, 8.2828995944 ]
  },
  "id_str" : "369041801526525952",
  "text" : "\u00ABAmazon hat uns als intellektuelle Rockstars filed: Die Empfehlungsmails bestehen aus Wissenschaftsphilosophie, Guitar Strings &amp; Kondomen.\u00BB",
  "id" : 369041801526525952,
  "created_at" : "2013-08-18 10:23:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ohPDM6NKGb",
      "expanded_url" : "http:\/\/i.imgur.com\/Ha2wD19.gif",
      "display_url" : "i.imgur.com\/Ha2wD19.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009603, 8.282909 ]
  },
  "id_str" : "369027950714187776",
  "text" : "These Jedi, playing around with their force push http:\/\/t.co\/ohPDM6NKGb",
  "id" : 369027950714187776,
  "created_at" : "2013-08-18 09:28:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097021575, 8.2830365664 ]
  },
  "id_str" : "368903890445426690",
  "text" : "\u00ABDer Kater, immer: \u2018Ich habe Dinge gesehen (und dann gleich wieder vergessen), die ihr Menschen niemals glauben w\u00FCrdet\u2026\u2019\u00BB",
  "id" : 368903890445426690,
  "created_at" : "2013-08-18 01:15:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097021575, 8.2830365664 ]
  },
  "id_str" : "368902889600581632",
  "text" : "\u00ABIch hoffe de Grey hat recht und wir erreichen die Longevity Escape Velocity bevor der Kater stirbt.\u00BB",
  "id" : 368902889600581632,
  "created_at" : "2013-08-18 01:11:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0125404159, 8.2841213146 ]
  },
  "id_str" : "368885795970482176",
  "text" : "Nur weil @Gilles_PPDE 2 Zeilen von den Bonnie Banks o\u2019 Loch Lomond angestimmt hat immer noch einen Ohrwurm. m)",
  "id" : 368885795970482176,
  "created_at" : "2013-08-18 00:03:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "der LUSTIGE Wellensittich",
      "screen_name" : "FR31H31T",
      "indices" : [ 0, 9 ],
      "id_str" : "73747798",
      "id" : 73747798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/kvp7K2TusE",
      "expanded_url" : "http:\/\/farm3.staticflickr.com\/2010\/2025709688_344e8d9753_m.jpg",
      "display_url" : "farm3.staticflickr.com\/2010\/202570968\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368883565817118721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0125407048, 8.2841214261 ]
  },
  "id_str" : "368883986652602368",
  "in_reply_to_user_id" : 73747798,
  "text" : "@FR31H31T the snake! http:\/\/t.co\/kvp7K2TusE",
  "id" : 368883986652602368,
  "in_reply_to_status_id" : 368883565817118721,
  "created_at" : "2013-08-17 23:56:10 +0000",
  "in_reply_to_screen_name" : "FR31H31T",
  "in_reply_to_user_id_str" : "73747798",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 3, 14 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/mjVlKE5nTC",
      "expanded_url" : "http:\/\/bit.ly\/14KIKOb",
      "display_url" : "bit.ly\/14KIKOb"
    } ]
  },
  "geo" : { },
  "id_str" : "368883474444587008",
  "text" : "RT @ewanbirney: New blog post: 5 reasons to love logarithms. http:\/\/t.co\/mjVlKE5nTC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/mjVlKE5nTC",
        "expanded_url" : "http:\/\/bit.ly\/14KIKOb",
        "display_url" : "bit.ly\/14KIKOb"
      } ]
    },
    "geo" : { },
    "id_str" : "368882458659282944",
    "text" : "New blog post: 5 reasons to love logarithms. http:\/\/t.co\/mjVlKE5nTC",
    "id" : 368882458659282944,
    "created_at" : "2013-08-17 23:50:06 +0000",
    "user" : {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "protected" : false,
      "id_str" : "183548902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775452689450799104\/Kc6o3PTV_normal.jpg",
      "id" : 183548902,
      "verified" : false
    }
  },
  "id" : 368883474444587008,
  "created_at" : "2013-08-17 23:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097005057, 8.2830247776 ]
  },
  "id_str" : "368878190233530368",
  "text" : "\u00ABthe threat of mutual suicide is a very uninspiring concept, no matter how logical it may seem.\u00BB",
  "id" : 368878190233530368,
  "created_at" : "2013-08-17 23:33:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/h7u36WhBJV",
      "expanded_url" : "http:\/\/i.imgur.com\/QaaBVzv.jpg",
      "display_url" : "i.imgur.com\/QaaBVzv.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "368877542234529792",
  "text" : "Omnomnom http:\/\/t.co\/h7u36WhBJV",
  "id" : 368877542234529792,
  "created_at" : "2013-08-17 23:30:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/yYjphKfk1u",
      "expanded_url" : "http:\/\/lareviewofbooks.org\/review\/the-tedium-is-the-message-finn-bruntons-spam-a-shadow-history-of-the-internet",
      "display_url" : "lareviewofbooks.org\/review\/the-ted\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096942367, 8.28303155 ]
  },
  "id_str" : "368866077398142977",
  "text" : "The Tedium is the Message: Finn Brunton\u2019s \u201CSpam: A Shadow History of the Internet\u201D http:\/\/t.co\/yYjphKfk1u",
  "id" : 368866077398142977,
  "created_at" : "2013-08-17 22:45:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368836133058543616",
  "text" : "RT @Senficon: \u201EAlso, ich finde ja p-values sehr sexy.\u201C \u201EKommt auf die Gr\u00F6\u00DFe an.\u201C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368835642840461312",
    "text" : "\u201EAlso, ich finde ja p-values sehr sexy.\u201C \u201EKommt auf die Gr\u00F6\u00DFe an.\u201C",
    "id" : 368835642840461312,
    "created_at" : "2013-08-17 20:44:04 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 368836133058543616,
  "created_at" : "2013-08-17 20:46:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.105526651, 8.6401283184 ]
  },
  "id_str" : "368827924129927168",
  "text" : "\u00ABPolys schauen \u2018Polyamory\u2019 aus genau einem Grund: Um zu sagen \u2018puh, meine Beziehungen sind so viel besser\u2019\u00BB",
  "id" : 368827924129927168,
  "created_at" : "2013-08-17 20:13:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1034477045, 8.6671386455 ]
  },
  "id_str" : "368798738799529984",
  "text" : "\u00ABGalactica ist so cool. Lauter h\u00FCbsche Menschen und Uniformen.\u00BB \u2014 \u00ABKlingt nach dem Dritten Reich\u2026\u00BB",
  "id" : 368798738799529984,
  "created_at" : "2013-08-17 18:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096427353, 8.2830011016 ]
  },
  "id_str" : "368763953838444545",
  "text" : "Having just seen the first episode of \u2018Polyamory: Married &amp; Dating\u2019 I\u2019m kinda impressed by how fair the issue is presented.",
  "id" : 368763953838444545,
  "created_at" : "2013-08-17 15:59:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 0, 13 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368760290810138626",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097016903, 8.2830368395 ]
  },
  "id_str" : "368761656735584256",
  "in_reply_to_user_id" : 19084034,
  "text" : "@ericmjohnson enjoy Munich and your short stay in Frankfurt!",
  "id" : 368761656735584256,
  "in_reply_to_status_id" : 368760290810138626,
  "created_at" : "2013-08-17 15:50:04 +0000",
  "in_reply_to_screen_name" : "ericmjohnson",
  "in_reply_to_user_id_str" : "19084034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368711191650004994",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096834367, 8.2830132583 ]
  },
  "id_str" : "368718951640879105",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke ich finde das ja wundersch\u00F6n :)",
  "id" : 368718951640879105,
  "in_reply_to_status_id" : 368711191650004994,
  "created_at" : "2013-08-17 13:00:23 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096834367, 8.2830132583 ]
  },
  "id_str" : "368716558069026816",
  "text" : "\u00ABDie neue Haarfarbe heisst \u2018ultraviolett\u2019.\u00BB \u2013 \u00ABDas glaube ich erst wenn ich es sehe.\u00BB \u2013 \u00ABDu meinst wenn du es nicht mehr siehst?\u00BB",
  "id" : 368716558069026816,
  "created_at" : "2013-08-17 12:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3WrdZKVGD8",
      "expanded_url" : "http:\/\/instagram.com\/p\/dHUJ4xBwpG\/",
      "display_url" : "instagram.com\/p\/dHUJ4xBwpG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "368711044148912128",
  "text" : "Multiple heads = so much more face licking! http:\/\/t.co\/3WrdZKVGD8",
  "id" : 368711044148912128,
  "created_at" : "2013-08-17 12:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0002934751, 8.3039376218 ]
  },
  "id_str" : "368691373869760512",
  "text" : "\u00ABIch habe ein sehr geb\u00E4rtfreudiges Kinn!\u00BB",
  "id" : 368691373869760512,
  "created_at" : "2013-08-17 11:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097147397, 8.283115607 ]
  },
  "id_str" : "368672685909217281",
  "text" : "\u00ABDeine Alternativ-Job-Pl\u00E4ne sind so gut. Ich wei\u00DF gar nicht ob ich Anal Stretching Artist vor oder nach Strassenmusiker einsortieren soll.\u00BB",
  "id" : 368672685909217281,
  "created_at" : "2013-08-17 09:56:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ij4XphOXag",
      "expanded_url" : "http:\/\/1.media.dorkly.cvcdn.com\/66\/17\/5d128996f954bf37100e7cf07ff706f9-8-fallout-psas.jpg",
      "display_url" : "1.media.dorkly.cvcdn.com\/66\/17\/5d128996\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096834367, 8.2830132583 ]
  },
  "id_str" : "368527085188288512",
  "text" : "Get your dog checked! http:\/\/t.co\/ij4XphOXag",
  "id" : 368527085188288512,
  "created_at" : "2013-08-17 00:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096990351, 8.2830339741 ]
  },
  "id_str" : "368520268366372864",
  "text" : "\u00ABW\u00FCrdest du mich wirklich ohne Vorwarnung verlassen?\u00BB \u2014 \u00ABNat\u00FCrlich nicht. Ich w\u00FCrde noch \u2018Tsch\u00FCs\u2019 rufen.\u00BB",
  "id" : 368520268366372864,
  "created_at" : "2013-08-16 23:50:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 0, 6 ],
      "id_str" : "16309072",
      "id" : 16309072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368405065906020352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1068811631, 8.6614147481 ]
  },
  "id_str" : "368405329891328001",
  "in_reply_to_user_id" : 16309072,
  "text" : "@alios ja, das macht besonders Spass wenn man jeden Tag von\/gen Mainz pendeln muss\u2026",
  "id" : 368405329891328001,
  "in_reply_to_status_id" : 368405065906020352,
  "created_at" : "2013-08-16 16:14:09 +0000",
  "in_reply_to_screen_name" : "alios",
  "in_reply_to_user_id_str" : "16309072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1068447747, 8.6625922492 ]
  },
  "id_str" : "368403570917658624",
  "text" : "\u00ABAufgrund einer Schl\u00E4gerei die unseren Zug besch\u00E4digt hat &amp; des damit verbundenen Noteinsatzes &amp; der Versp\u00E4tung endet dieser Zug hier.\u00BB",
  "id" : 368403570917658624,
  "created_at" : "2013-08-16 16:07:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.138190424, 8.6705599001 ]
  },
  "id_str" : "368390964702097408",
  "text" : "\u00ABIt is not the numbers of dead or the number of years it takes for economic recuperation; rather it is \u2018Will the survivors envy the dead?\u2019\u00BB",
  "id" : 368390964702097408,
  "created_at" : "2013-08-16 15:17:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368389556233441280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1429373737, 8.6686506339 ]
  },
  "id_str" : "368389900066111488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that\u2019s a thing I like about you: you provide ample opportunities to memorize fallacies and biases!",
  "id" : 368389900066111488,
  "in_reply_to_status_id" : 368389556233441280,
  "created_at" : "2013-08-16 15:12:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368388239863713792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1525393339, 8.6615355655 ]
  },
  "id_str" : "368389287387340800",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, now you\u2019re just subject to confirmation bias. But that\u2019s another list.",
  "id" : 368389287387340800,
  "in_reply_to_status_id" : 368388239863713792,
  "created_at" : "2013-08-16 15:10:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/KslukLV5eM",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Texas_sharpshooter_fallacy",
      "display_url" : "en.wikipedia.org\/wiki\/Texas_sha\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368383732303941634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693951532, 8.6224044262 ]
  },
  "id_str" : "368387667937222656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot na damit die nicht kaputt gemacht werden! http:\/\/t.co\/KslukLV5eM",
  "id" : 368387667937222656,
  "in_reply_to_status_id" : 368383732303941634,
  "created_at" : "2013-08-16 15:03:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ZvxvO6JdKn",
      "expanded_url" : "https:\/\/www.grants4apps.com\/#\/grants-2013\/",
      "display_url" : "grants4apps.com\/#\/grants-2013\/"
    } ]
  },
  "geo" : { },
  "id_str" : "368377259196833792",
  "text" : "Nice, you can now see which projects besides openSNP have been awarded a grant by Bayer Healthcare. https:\/\/t.co\/ZvxvO6JdKn",
  "id" : 368377259196833792,
  "created_at" : "2013-08-16 14:22:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/PD6RNC1NTr",
      "expanded_url" : "http:\/\/www.foreignaffairs.com\/articles\/139817\/jacob-n-shapiro\/the-business-habits-of-highly-effective-terrorists?page=show",
      "display_url" : "foreignaffairs.com\/articles\/13981\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368365758696263680",
  "text" : "The Business Habits of Highly Effective Terrorists http:\/\/t.co\/PD6RNC1NTr",
  "id" : 368365758696263680,
  "created_at" : "2013-08-16 13:36:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/hikOMTeQMS",
      "expanded_url" : "http:\/\/flowingdata.com\/2013\/08\/16\/extensive-timelines-of-slang-for-genitalia\/",
      "display_url" : "flowingdata.com\/2013\/08\/16\/ext\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368353661245612032",
  "text" : "Masterjohn Goodfellow! Extensive timelines of slang for genitalia http:\/\/t.co\/hikOMTeQMS",
  "id" : 368353661245612032,
  "created_at" : "2013-08-16 12:48:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368328138259832833",
  "geo" : { },
  "id_str" : "368329131231940608",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Vorsicht: Dummerweise wird dir das Gesetz der gro\u00DFen Zahlen irgendwann v\u00F6llig unbedeutende effect sizes signifikant machen. :P",
  "id" : 368329131231940608,
  "in_reply_to_status_id" : 368328138259832833,
  "created_at" : "2013-08-16 11:11:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368328251950649344",
  "text" : "\"Argh, ich muss jetzt alle Reads noch mal anfassen!\" \u2013 \"Don't try to be all touchy feely\u2026\"",
  "id" : 368328251950649344,
  "created_at" : "2013-08-16 11:07:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/usYuLDUcVj",
      "expanded_url" : "http:\/\/gifninja.com\/animatedgifs\/62997\/fake-texting.gif",
      "display_url" : "gifninja.com\/animatedgifs\/6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368326460936683521",
  "geo" : { },
  "id_str" : "368327716421906432",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Hallo! http:\/\/t.co\/usYuLDUcVj",
  "id" : 368327716421906432,
  "in_reply_to_status_id" : 368326460936683521,
  "created_at" : "2013-08-16 11:05:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Katharina Binz",
      "screen_name" : "katharina_binz",
      "indices" : [ 10, 25 ],
      "id_str" : "141163937",
      "id" : 141163937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/DB22DqVsmW",
      "expanded_url" : "http:\/\/assets0.ordienetworks.com\/misc\/5%20come%20on%20fan.gif",
      "display_url" : "assets0.ordienetworks.com\/misc\/5%20come%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368326106824196096",
  "geo" : { },
  "id_str" : "368327221435314176",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @katharina_binz http:\/\/t.co\/DB22DqVsmW (hey, &lt; 0.1 wird ja manchmal als Trend ausgewiesen ;))",
  "id" : 368327221435314176,
  "in_reply_to_status_id" : 368326106824196096,
  "created_at" : "2013-08-16 11:03:47 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/MYAbJUMK9s",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_maoeayLg5D1rvzhd1o1_500.jpg",
      "display_url" : "25.media.tumblr.com\/tumblr_maoeayL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368326156027584512",
  "text" : "Post-Dog http:\/\/t.co\/MYAbJUMK9s",
  "id" : 368326156027584512,
  "created_at" : "2013-08-16 10:59:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368320631659438080",
  "geo" : { },
  "id_str" : "368324418625216512",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you mean: talking at all!",
  "id" : 368324418625216512,
  "in_reply_to_status_id" : 368320631659438080,
  "created_at" : "2013-08-16 10:52:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Katharina Binz",
      "screen_name" : "katharina_binz",
      "indices" : [ 10, 25 ],
      "id_str" : "141163937",
      "id" : 141163937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368320860391612416",
  "geo" : { },
  "id_str" : "368324250764980224",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @katharina_binz nicht! nicht abh\u00E4ngig, sorry. H0 ist Unabh\u00E4ngigkeit, du kannst H0 nicht mit p&lt; 0.05 verwerfen. So ist's richtig :)",
  "id" : 368324250764980224,
  "in_reply_to_status_id" : 368320860391612416,
  "created_at" : "2013-08-16 10:51:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Katharina Binz",
      "screen_name" : "katharina_binz",
      "indices" : [ 10, 25 ],
      "id_str" : "141163937",
      "id" : 141163937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9v3ufnfgvx",
      "expanded_url" : "http:\/\/www.r-tutor.com\/elementary-statistics\/goodness-fit\/chi-squared-test-independence",
      "display_url" : "r-tutor.com\/elementary-sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "368320860391612416",
  "geo" : { },
  "id_str" : "368323732458065920",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @katharina_binz ist abh\u00E4ngig iirc, siehe auch hier: http:\/\/t.co\/9v3ufnfgvx",
  "id" : 368323732458065920,
  "in_reply_to_status_id" : 368320860391612416,
  "created_at" : "2013-08-16 10:49:55 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368312915176075266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724283374, 8.6275509055 ]
  },
  "id_str" : "368319885694480384",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich try me :)",
  "id" : 368319885694480384,
  "in_reply_to_status_id" : 368312915176075266,
  "created_at" : "2013-08-16 10:34:38 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368310987943714816",
  "text" : "usearch removes my unique field from the fasta headers &amp; shuffles seqs in the output. Good thing I noticed it after doing 16 mio alignments\u2026",
  "id" : 368310987943714816,
  "created_at" : "2013-08-16 09:59:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/pugoQI39nI",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=9VDvgL58h_Y",
      "display_url" : "youtube.com\/watch?v=9VDvgL\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722849652, 8.6276645709 ]
  },
  "id_str" : "368299160971530240",
  "text" : "\u00ABI think I might have written an overlap assembler in Python by accident.\u00BB http:\/\/t.co\/pugoQI39nI",
  "id" : 368299160971530240,
  "created_at" : "2013-08-16 09:12:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XgS1WUdtmI",
      "expanded_url" : "http:\/\/i.imgur.com\/PnYkQKr.gif",
      "display_url" : "i.imgur.com\/PnYkQKr.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "368289528731033600",
  "text" : "\"Ich prokrastiniere nicht, ich denke angestrengt \u00FCber mein Problem nach!\"\u2013\"Du schaust Katzen-GIFs\u2026\"\u2013\"Sag ich doch!\" http:\/\/t.co\/XgS1WUdtmI",
  "id" : 368289528731033600,
  "created_at" : "2013-08-16 08:34:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368286717234511873",
  "text" : "for j in i:\n  pass # you shall not!",
  "id" : 368286717234511873,
  "created_at" : "2013-08-16 08:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722744975, 8.6276828281 ]
  },
  "id_str" : "368280819045257216",
  "text" : "\u00ABAch, macht das FACT wieder das du fucked bist?\u00BB",
  "id" : 368280819045257216,
  "created_at" : "2013-08-16 07:59:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/OhvpRWbTQV",
      "expanded_url" : "http:\/\/instagram.com\/p\/dEQFxpBwqh\/",
      "display_url" : "instagram.com\/p\/dEQFxpBwqh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "368279764945371136",
  "text" : "\u00ABLauf schneller!\u00BB http:\/\/t.co\/OhvpRWbTQV",
  "id" : 368279764945371136,
  "created_at" : "2013-08-16 07:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072100645, 8.2832606704 ]
  },
  "id_str" : "368261058592792576",
  "text" : "\u00ABOn Thermonuclear War was controversial when published and remains so today. It\u2019s iconoclastic; worse, it\u2019s interdisciplinary.\u00BB",
  "id" : 368261058592792576,
  "created_at" : "2013-08-16 06:40:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/zyZiSLJqJy",
      "expanded_url" : "http:\/\/i.imgur.com\/gha4qi0.gif",
      "display_url" : "i.imgur.com\/gha4qi0.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0116134737, 8.2835044895 ]
  },
  "id_str" : "368163329317294081",
  "text" : "Good night! http:\/\/t.co\/zyZiSLJqJy",
  "id" : 368163329317294081,
  "created_at" : "2013-08-16 00:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/5TCjb9L8rS",
      "expanded_url" : "http:\/\/i.imgur.com\/eNBdf.jpg",
      "display_url" : "i.imgur.com\/eNBdf.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.011398, 8.283461 ]
  },
  "id_str" : "368149688455032833",
  "text" : "Sounds good to me! http:\/\/t.co\/5TCjb9L8rS",
  "id" : 368149688455032833,
  "created_at" : "2013-08-15 23:18:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Coop",
      "screen_name" : "Graham_Coop",
      "indices" : [ 3, 15 ],
      "id_str" : "713648564",
      "id" : 713648564
    }, {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 20, 29 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/GaRTvMTNN3",
      "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/57993700472\/encode-gwas-and-pentecostalism-a-true-religion-or",
      "display_url" : "judgestarling.tumblr.com\/post\/579937004\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368144461941207040",
  "text" : "RT @Graham_Coop: Is @DanGraur an elaborate hoax or just a man struggling to read a methods section? http:\/\/t.co\/GaRTvMTNN3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan (((Graur)))",
        "screen_name" : "DanGraur",
        "indices" : [ 3, 12 ],
        "id_str" : "1205345400",
        "id" : 1205345400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/GaRTvMTNN3",
        "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/57993700472\/encode-gwas-and-pentecostalism-a-true-religion-or",
        "display_url" : "judgestarling.tumblr.com\/post\/579937004\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366708860557340674",
    "text" : "Is @DanGraur an elaborate hoax or just a man struggling to read a methods section? http:\/\/t.co\/GaRTvMTNN3",
    "id" : 366708860557340674,
    "created_at" : "2013-08-11 23:53:00 +0000",
    "user" : {
      "name" : "Graham Coop",
      "screen_name" : "Graham_Coop",
      "protected" : false,
      "id_str" : "713648564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758139683276677123\/yjSMCK2c_normal.jpg",
      "id" : 713648564,
      "verified" : false
    }
  },
  "id" : 368144461941207040,
  "created_at" : "2013-08-15 22:57:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368119159827091457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968572, 8.283017905 ]
  },
  "id_str" : "368133750196277248",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju faptik!",
  "id" : 368133750196277248,
  "in_reply_to_status_id" : 368119159827091457,
  "created_at" : "2013-08-15 22:15:00 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 100, 109 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/4Qon0dOLWM",
      "expanded_url" : "http:\/\/onion.com\/15N3AAT",
      "display_url" : "onion.com\/15N3AAT"
    } ]
  },
  "geo" : { },
  "id_str" : "368125861440274432",
  "text" : "RT @AndreaKuszewski: MIT Scientists Create Robot Capable Of Feeling Lust http:\/\/t.co\/4Qon0dOLWM via @TheOnion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Onion",
        "screen_name" : "TheOnion",
        "indices" : [ 79, 88 ],
        "id_str" : "14075928",
        "id" : 14075928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/4Qon0dOLWM",
        "expanded_url" : "http:\/\/onion.com\/15N3AAT",
        "display_url" : "onion.com\/15N3AAT"
      } ]
    },
    "geo" : { },
    "id_str" : "368124996716986368",
    "text" : "MIT Scientists Create Robot Capable Of Feeling Lust http:\/\/t.co\/4Qon0dOLWM via @TheOnion",
    "id" : 368124996716986368,
    "created_at" : "2013-08-15 21:40:13 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 368125861440274432,
  "created_at" : "2013-08-15 21:43:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0174482348, 8.2726057903 ]
  },
  "id_str" : "368105487923154944",
  "text" : "\u00ABWir nehmen den B\u00FCrohund einfach mit wenn ich meinen aussuche, f\u00FCr den Perfect Match!\u00BB \u2014 \u00ABOkRuffpid\u2026\u00BB",
  "id" : 368105487923154944,
  "created_at" : "2013-08-15 20:22:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0112576289, 8.2716848753 ]
  },
  "id_str" : "368103057428844544",
  "text" : "\u00ABWir d\u00FCrfen auf keinen Fall einen Nobelpreis gewinnen. Nachher hei\u00DFt es \u00FCberall wir h\u00E4tten unsere Entdeckung im \u2018Zum Lahmen Esel\u2019 gefeiert!\u00BB",
  "id" : 368103057428844544,
  "created_at" : "2013-08-15 20:13:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/RljIsQP9Hl",
      "expanded_url" : "http:\/\/www.smithsonianmag.com\/science-nature\/For-the-First-Time-in-35-Years-A-New-Carnivorous-Mammal-Species-is-Discovered-in-the-Western-Hemisphere--219762981.html#.Ug0cyfNLI2M.twitter",
      "display_url" : "smithsonianmag.com\/science-nature\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969993, 8.283054035 ]
  },
  "id_str" : "368075789717487616",
  "text" : "For the First Time in 35 Years, A New Carnivorous Mammal Species is Discovered in the American Continents http:\/\/t.co\/RljIsQP9Hl",
  "id" : 368075789717487616,
  "created_at" : "2013-08-15 18:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368075194113736704",
  "text" : "RT @razibkhan: this urban legend so annoying RT Darwin did not cheat Wallace out of his rightful place in history \u00BB good read http:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/rDiE9dAjos",
        "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2013\/08\/15\/darwin-did-not-cheat-wallace-out-of-his-rightful-place-in-history",
        "display_url" : "whyevolutionistrue.wordpress.com\/2013\/08\/15\/dar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "368074577672273920",
    "text" : "this urban legend so annoying RT Darwin did not cheat Wallace out of his rightful place in history \u00BB good read http:\/\/t.co\/rDiE9dAjos",
    "id" : 368074577672273920,
    "created_at" : "2013-08-15 18:19:52 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 368075194113736704,
  "created_at" : "2013-08-15 18:22:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/glSeyO1mHv",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/VD5SFzUtt3Q\/info%3Adoi%2F10.1371%2Fjournal.pone.0071589",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368044585375006720",
  "text" : "Why Has the Continuous Decline in German Suicide Rates Stopped in 2007? http:\/\/t.co\/glSeyO1mHv",
  "id" : 368044585375006720,
  "created_at" : "2013-08-15 16:20:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722927882, 8.6276457425 ]
  },
  "id_str" : "368035204705046528",
  "text" : "\u00ABKlar k\u00F6nnte man das effizienter schreiben, aber wof\u00FCr haben wir die Node mit 160 GB RAM?\u00BB",
  "id" : 368035204705046528,
  "created_at" : "2013-08-15 15:43:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 48, 54 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722867316, 8.6276568686 ]
  },
  "id_str" : "368026410633662464",
  "text" : "\u00ABUnd was wird der Titel deiner Diss?\u00BB \u2014 \u00AB\u2018Danke @Lobot, deinetwegen darf ich bis zum Ende meiner Tage Flechtenexperte sein\u2019\u2026\u00BB",
  "id" : 368026410633662464,
  "created_at" : "2013-08-15 15:08:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367949877453393920",
  "text" : "Hundesabber &gt; Nasenfett",
  "id" : 367949877453393920,
  "created_at" : "2013-08-15 10:04:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "IR Blog",
      "screen_name" : "theIRblog",
      "indices" : [ 110, 120 ],
      "id_str" : "921242090",
      "id" : 921242090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Ob5K4hqvNk",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jessicamisener\/25-deeply-painful-phd-student-problems-besides-your-thesis",
      "display_url" : "buzzfeed.com\/jessicamisener\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367948170636296192",
  "text" : "RT @zoonpolitikon: \"25 Deeply Painful Ph.D. Student Problems (Besides Your Thesis)\" http:\/\/t.co\/Ob5K4hqvNk HT @theIRblog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IR Blog",
        "screen_name" : "theIRblog",
        "indices" : [ 91, 101 ],
        "id_str" : "921242090",
        "id" : 921242090
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Ob5K4hqvNk",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/jessicamisener\/25-deeply-painful-phd-student-problems-besides-your-thesis",
        "display_url" : "buzzfeed.com\/jessicamisener\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367947596079194112",
    "text" : "\"25 Deeply Painful Ph.D. Student Problems (Besides Your Thesis)\" http:\/\/t.co\/Ob5K4hqvNk HT @theIRblog",
    "id" : 367947596079194112,
    "created_at" : "2013-08-15 09:55:17 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 367948170636296192,
  "created_at" : "2013-08-15 09:57:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 38, 47 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367939714462273536",
  "geo" : { },
  "id_str" : "367941829204779008",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Doppelblind ist wenn @Senficon und ich die Brille abnehmen.",
  "id" : 367941829204779008,
  "in_reply_to_status_id" : 367939714462273536,
  "created_at" : "2013-08-15 09:32:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 10, 19 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367935767114297344",
  "geo" : { },
  "id_str" : "367938425984266240",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @JP_Stich @Lobot \"I'd like to thank three anonymous reviewers for helpful suggestions regarding my personality\"?",
  "id" : 367938425984266240,
  "in_reply_to_status_id" : 367935767114297344,
  "created_at" : "2013-08-15 09:18:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IpTILf8oKg",
      "expanded_url" : "http:\/\/opensnp.org\/fitbit\/show\/1",
      "display_url" : "opensnp.org\/fitbit\/show\/1"
    } ]
  },
  "in_reply_to_status_id_str" : "367934226739372032",
  "geo" : { },
  "id_str" : "367935078938058752",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon @Lobot Die Rohdaten daf\u00FCr sind auch schon in der Public Domain. Viel Erfolg beim Review! :P http:\/\/t.co\/IpTILf8oKg",
  "id" : 367935078938058752,
  "in_reply_to_status_id" : 367934226739372032,
  "created_at" : "2013-08-15 09:05:33 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 10, 19 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367933673816870912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722974814, 8.6276578453 ]
  },
  "id_str" : "367933929850159104",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @JP_Stich @Lobot don\u2019t get me started again. I did resort to frequentism so you couldn\u2019t attack my prior!",
  "id" : 367933929850159104,
  "in_reply_to_status_id" : 367933673816870912,
  "created_at" : "2013-08-15 09:00:59 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367932522472038400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722308368, 8.6277038147 ]
  },
  "id_str" : "367933334934274048",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon @Lobot Zeit f\u00FCr einen Livehacking-Artikel: \u2018How R Saved my Relationships\u2019 ;)",
  "id" : 367933334934274048,
  "in_reply_to_status_id" : 367932522472038400,
  "created_at" : "2013-08-15 08:58:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367932126861074432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722308368, 8.6277038147 ]
  },
  "id_str" : "367932592802508800",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot actually more data is needed to do a complete comparison (2-tailed t-test, unequal variance, just in case you wondered)",
  "id" : 367932592802508800,
  "in_reply_to_status_id" : 367932126861074432,
  "created_at" : "2013-08-15 08:55:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 42, 48 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/367931351950835712\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/I7XvTjm5sy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRsnnX9CQAEiMWt.png",
      "id_str" : "367931351959224321",
      "id" : 367931351959224321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRsnnX9CQAEiMWt.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/I7XvTjm5sy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367931351950835712",
  "text" : "Looks like @Senficon is rehabilitated, as @Lobot is equally bad for my sleep. \u0394x\u0304 = 77.80 minutes, p = 1.51E-016 http:\/\/t.co\/I7XvTjm5sy",
  "id" : 367931351950835712,
  "created_at" : "2013-08-15 08:50:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1033849456, 8.5594853573 ]
  },
  "id_str" : "367906601275236352",
  "text" : "\u00AB90% of nutrient absorption is in the small intestine. Rectal meals could postpone death but it\u2019s an exaggeration to say they sustain life.\u00BB",
  "id" : 367906601275236352,
  "created_at" : "2013-08-15 07:12:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/b4Ile9IpuO",
      "expanded_url" : "http:\/\/psych-your-mind.blogspot.de\/2013\/08\/the-psychology-of-psychology-isnt.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+PsychYourMind+(Psych+Your+Mind)&m=1",
      "display_url" : "psych-your-mind.blogspot.de\/2013\/08\/the-ps\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.067584, 8.489397 ]
  },
  "id_str" : "367903879415214080",
  "text" : "The Psychology of the \"Psychology Isn't a Science\" Argument http:\/\/t.co\/b4Ile9IpuO",
  "id" : 367903879415214080,
  "created_at" : "2013-08-15 07:01:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/y3sEWHdqED",
      "expanded_url" : "http:\/\/www.peerreviewedbymyneurons.com\/2013\/08\/14\/rethinking-the-marshmallow-experiment\/",
      "display_url" : "peerreviewedbymyneurons.com\/2013\/08\/14\/ret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367902504304250880",
  "text" : "Rethinking the Marshmallow Experiment http:\/\/t.co\/y3sEWHdqED",
  "id" : 367902504304250880,
  "created_at" : "2013-08-15 06:56:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ySn3756KWG",
      "expanded_url" : "http:\/\/keenetrial.com\/blog\/2013\/08\/14\/how-myside-bias-is-related-to-your-intelligence\/?utm_source=feedly",
      "display_url" : "keenetrial.com\/blog\/2013\/08\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.002101, 8.365596 ]
  },
  "id_str" : "367901701711593472",
  "text" : "\u00ABHow \u2018myside bias\u2019 is related to your intelligence\u00BB Well, IQ, not intelligence, probably\u2026 http:\/\/t.co\/ySn3756KWG",
  "id" : 367901701711593472,
  "created_at" : "2013-08-15 06:52:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh K. Phisher \u2603",
      "screen_name" : "josh_k_phisher",
      "indices" : [ 3, 18 ],
      "id_str" : "15155455",
      "id" : 15155455
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Perspective_pic\/status\/367760111424389120\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/utObE6nBT3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRqL33RCQAEUnV8.jpg",
      "id_str" : "367760111428583425",
      "id" : 367760111428583425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRqL33RCQAEUnV8.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/utObE6nBT3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367898973673385985",
  "text" : "RT @josh_k_phisher: Aus der Rubrik \"Ich benutze immer nur den mittleren Autofokuspunkt\": http:\/\/t.co\/utObE6nBT3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Perspective_pic\/status\/367760111424389120\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/utObE6nBT3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRqL33RCQAEUnV8.jpg",
        "id_str" : "367760111428583425",
        "id" : 367760111428583425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRqL33RCQAEUnV8.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/utObE6nBT3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367760571992506368",
    "text" : "Aus der Rubrik \"Ich benutze immer nur den mittleren Autofokuspunkt\": http:\/\/t.co\/utObE6nBT3",
    "id" : 367760571992506368,
    "created_at" : "2013-08-14 21:32:07 +0000",
    "user" : {
      "name" : "Josh K. Phisher \u2603",
      "screen_name" : "josh_k_phisher",
      "protected" : false,
      "id_str" : "15155455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261597225\/00eeccde1695a9e7c9a72945db063566_normal.jpeg",
      "id" : 15155455,
      "verified" : false
    }
  },
  "id" : 367898973673385985,
  "created_at" : "2013-08-15 06:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00952343, 8.28301901 ]
  },
  "id_str" : "367750916637986816",
  "text" : "\u00ABGrunting ist wenn du versuchst zu lachen. Growling wenn du versuchst Chewbacca zu spielen.\u00BB",
  "id" : 367750916637986816,
  "created_at" : "2013-08-14 20:53:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/LO6i15fJa7",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1618",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367685274819895296",
  "text" : "Data encryption http:\/\/t.co\/LO6i15fJa7",
  "id" : 367685274819895296,
  "created_at" : "2013-08-14 16:32:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/881lQA6yis",
      "expanded_url" : "http:\/\/startupdbag.tumblr.com\/",
      "display_url" : "startupdbag.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "367682625722679296",
  "text" : "STFU Startup Douchebag http:\/\/t.co\/881lQA6yis",
  "id" : 367682625722679296,
  "created_at" : "2013-08-14 16:22:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "indices" : [ 3, 15 ],
      "id_str" : "15327996",
      "id" : 15327996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367681153219964928",
  "text" : "RT @BFriedmanDC: This DoD statement on same-sex couples being allowed non-chargeable leave for travel to marry is pretty amazing: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BFriedmanDC\/status\/367671607541510145\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/WwHFLEaKEA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRo7YQoCMAAe4PP.png",
        "id_str" : "367671607549898752",
        "id" : 367671607549898752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRo7YQoCMAAe4PP.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 428
        } ],
        "display_url" : "pic.twitter.com\/WwHFLEaKEA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367671607541510145",
    "text" : "This DoD statement on same-sex couples being allowed non-chargeable leave for travel to marry is pretty amazing: http:\/\/t.co\/WwHFLEaKEA",
    "id" : 367671607541510145,
    "created_at" : "2013-08-14 15:38:36 +0000",
    "user" : {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "protected" : false,
      "id_str" : "15327996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649427993161433088\/nzkLsEDl_normal.jpg",
      "id" : 15327996,
      "verified" : true
    }
  },
  "id" : 367681153219964928,
  "created_at" : "2013-08-14 16:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367678059190972416",
  "text" : "RT @li5a: OR: Time flies like an arrow. Fruit flies like a banana.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367624502722560000",
    "text" : "OR: Time flies like an arrow. Fruit flies like a banana.",
    "id" : 367624502722560000,
    "created_at" : "2013-08-14 12:31:26 +0000",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/42645812\/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 367678059190972416,
  "created_at" : "2013-08-14 16:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367675038750625792",
  "text" : "\"# insert weird magical quality recalculations here. tomorrow, maybe\"",
  "id" : 367675038750625792,
  "created_at" : "2013-08-14 15:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/367635690470645760\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/KH9HnDxcN3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRoatnGCIAA-vIm.jpg",
      "id_str" : "367635690474840064",
      "id" : 367635690474840064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRoatnGCIAA-vIm.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 169
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 169
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 169
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 169
      } ],
      "display_url" : "pic.twitter.com\/KH9HnDxcN3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xFj8YgmDWF",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Escherichia_coli_long-term_evolution_experiment",
      "display_url" : "en.m.wikipedia.org\/wiki\/Escherich\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367674612286754816",
  "text" : "RT @randal_olson: Lenski: LTEE celebrated 25th birthday this year. Happy birthday LTEE! http:\/\/t.co\/xFj8YgmDWF http:\/\/t.co\/KH9HnDxcN3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/367635690470645760\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/KH9HnDxcN3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRoatnGCIAA-vIm.jpg",
        "id_str" : "367635690474840064",
        "id" : 367635690474840064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRoatnGCIAA-vIm.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 169
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 169
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 169
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 169
        } ],
        "display_url" : "pic.twitter.com\/KH9HnDxcN3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/xFj8YgmDWF",
        "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Escherichia_coli_long-term_evolution_experiment",
        "display_url" : "en.m.wikipedia.org\/wiki\/Escherich\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367635690470645760",
    "text" : "Lenski: LTEE celebrated 25th birthday this year. Happy birthday LTEE! http:\/\/t.co\/xFj8YgmDWF http:\/\/t.co\/KH9HnDxcN3",
    "id" : 367635690470645760,
    "created_at" : "2013-08-14 13:15:53 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 367674612286754816,
  "created_at" : "2013-08-14 15:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/UHNjUeFU9f",
      "expanded_url" : "http:\/\/instagram.com\/p\/c_je0nBwgv\/",
      "display_url" : "instagram.com\/p\/c_je0nBwgv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "367618811497033728",
  "text" : "Not slacking off, my dog's compiling. http:\/\/t.co\/UHNjUeFU9f",
  "id" : 367618811497033728,
  "created_at" : "2013-08-14 12:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/5bsfarnVGK",
      "expanded_url" : "http:\/\/instagram.com\/p\/c_jP4WBwgi\/",
      "display_url" : "instagram.com\/p\/c_jP4WBwgi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "367618243097550848",
  "text" : "Wall of Fur http:\/\/t.co\/5bsfarnVGK",
  "id" : 367618243097550848,
  "created_at" : "2013-08-14 12:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/188B1Q7zBK",
      "expanded_url" : "http:\/\/i.imgur.com\/sQ4qGlq.gif",
      "display_url" : "i.imgur.com\/sQ4qGlq.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "367586725000134656",
  "text" : "Time to run away\u2026 http:\/\/t.co\/188B1Q7zBK",
  "id" : 367586725000134656,
  "created_at" : "2013-08-14 10:01:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723044297, 8.6276480786 ]
  },
  "id_str" : "367574013981499392",
  "text" : "\u00ABNein, ich habe auch keine Ahnung davon. Aber frag doch Kollegen X?\u00BB \u2014 \u00ABAch, ich will niemanden damit bel\u00E4stigen.\u00BB \u2014 \u00ABAu\u00DFer mich\u2026\u00BB",
  "id" : 367574013981499392,
  "created_at" : "2013-08-14 09:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voll dufter Typ",
      "screen_name" : "supaheld",
      "indices" : [ 95, 104 ],
      "id_str" : "52670399",
      "id" : 52670399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722839163, 8.6276530256 ]
  },
  "id_str" : "367560079945785344",
  "text" : "\u00ABDu hast ja schon so das Gesicht eines zerstreuten Professors. Ist das dein Berufsziel?\u00BB \u2014 Der @supaheld macht morgens super Komplimente!",
  "id" : 367560079945785344,
  "created_at" : "2013-08-14 08:15:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/b6AvmPdlRT",
      "expanded_url" : "http:\/\/www.jasoncollins.org\/2013\/08\/four-reasons-why-evolutionary-theory-might-not-add-value-to-economics\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "jasoncollins.org\/2013\/08\/four-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367553196149190656",
  "text" : "Four reasons why evolutionary theory might not add value to economics http:\/\/t.co\/b6AvmPdlRT",
  "id" : 367553196149190656,
  "created_at" : "2013-08-14 07:48:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gulp",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/rdzZhEEQ0f",
      "expanded_url" : "http:\/\/www.theguardian.com\/books\/2009\/jan\/03\/book-cook-chocolate",
      "display_url" : "theguardian.com\/books\/2009\/jan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.094505, 8.628672 ]
  },
  "id_str" : "367547292574056448",
  "text" : "\u00ABI confess to never having heard of the anal violin before\u00BB ditto. #gulp mentions it as well. Sources pls. http:\/\/t.co\/rdzZhEEQ0f",
  "id" : 367547292574056448,
  "created_at" : "2013-08-14 07:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 0, 10 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367540784951599104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0446850108, 8.4626592882 ]
  },
  "id_str" : "367541259667509248",
  "in_reply_to_user_id" : 1130798947,
  "text" : "@Gene_Talk great, looking forward to read more about it. So I now should probably start to read up on exome analysis best practices! ;)",
  "id" : 367541259667509248,
  "in_reply_to_status_id" : 367540784951599104,
  "created_at" : "2013-08-14 07:00:39 +0000",
  "in_reply_to_screen_name" : "Gene_Talk",
  "in_reply_to_user_id_str" : "1130798947",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/J0oIgbx1uI",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/gaming\/comments\/1k9xkb\/the_frustrated_musings_of_a_colour_blind_gamer\/",
      "display_url" : "reddit.com\/r\/gaming\/comme\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814143, 8.2830888829 ]
  },
  "id_str" : "367430519862349825",
  "text" : "What happens if you can\u2019t see colors: \u00ABThe frustrated musings of a colour blind gamer\u00BB http:\/\/t.co\/J0oIgbx1uI",
  "id" : 367430519862349825,
  "created_at" : "2013-08-13 23:40:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/1xvdpJNBGl",
      "expanded_url" : "http:\/\/i.imgur.com\/vxjOv.jpg",
      "display_url" : "i.imgur.com\/vxjOv.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814143, 8.2830888829 ]
  },
  "id_str" : "367430305000734720",
  "text" : "I can see colors! http:\/\/t.co\/1xvdpJNBGl",
  "id" : 367430305000734720,
  "created_at" : "2013-08-13 23:39:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814143, 8.2830888829 ]
  },
  "id_str" : "367428967873388544",
  "text" : "Meh, why do ppl still not get that p-values != effect size\u2026",
  "id" : 367428967873388544,
  "created_at" : "2013-08-13 23:34:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Iuajbm1ZLt",
      "expanded_url" : "http:\/\/i.imgur.com\/YyCj8oR.gif",
      "display_url" : "i.imgur.com\/YyCj8oR.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096881975, 8.28302468 ]
  },
  "id_str" : "367420384851030016",
  "text" : "I have no idea what I\u2019m doing! http:\/\/t.co\/Iuajbm1ZLt",
  "id" : 367420384851030016,
  "created_at" : "2013-08-13 23:00:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/HQKNq5mPon",
      "expanded_url" : "http:\/\/i.imgur.com\/rrH6DmK.jpg",
      "display_url" : "i.imgur.com\/rrH6DmK.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096881975, 8.28302468 ]
  },
  "id_str" : "367411219298545664",
  "text" : "I\u2019m sorry Dave\u2026 http:\/\/t.co\/HQKNq5mPon",
  "id" : 367411219298545664,
  "created_at" : "2013-08-13 22:23:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tim_yates\/status\/367297797709504513\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/cLgIWSzaA6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRjnZqeCIAEl84N.png",
      "id_str" : "367297797713698817",
      "id" : 367297797713698817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRjnZqeCIAEl84N.png",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 256
      } ],
      "display_url" : "pic.twitter.com\/cLgIWSzaA6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367408776741400576",
  "text" : "It looks like you want to shoot yourself in the foot. Continue? https:\/\/t.co\/cLgIWSzaA6",
  "id" : 367408776741400576,
  "created_at" : "2013-08-13 22:14:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/CMYrmxnnbx",
      "expanded_url" : "http:\/\/i.imgur.com\/mkC3G4I.gif",
      "display_url" : "i.imgur.com\/mkC3G4I.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096538514, 8.2830078314 ]
  },
  "id_str" : "367385716894232576",
  "text" : "Curiosity http:\/\/t.co\/CMYrmxnnbx",
  "id" : 367385716894232576,
  "created_at" : "2013-08-13 20:42:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/rUQ2igqre4",
      "expanded_url" : "http:\/\/i.imgur.com\/r6YETqQ.jpg",
      "display_url" : "i.imgur.com\/r6YETqQ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "367380071814029312",
  "text" : "Fuck Borders http:\/\/t.co\/rUQ2igqre4",
  "id" : 367380071814029312,
  "created_at" : "2013-08-13 20:20:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 0, 10 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367274947183259648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009602856, 8.2829354709 ]
  },
  "id_str" : "367372386745978880",
  "in_reply_to_user_id" : 1130798947,
  "text" : "@Gene_Talk yay, so the library has been prepped already? :)",
  "id" : 367372386745978880,
  "in_reply_to_status_id" : 367274947183259648,
  "created_at" : "2013-08-13 19:49:37 +0000",
  "in_reply_to_screen_name" : "Gene_Talk",
  "in_reply_to_user_id_str" : "1130798947",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096538514, 8.2830078314 ]
  },
  "id_str" : "367363774287982592",
  "text" : "\u00ABSie m\u00FCssen das Lube nicht einpacken. Wir nehmen es auf die Faust!\u00BB",
  "id" : 367363774287982592,
  "created_at" : "2013-08-13 19:15:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    }, {
      "name" : "Feedly",
      "screen_name" : "feedly",
      "indices" : [ 123, 130 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5lxL6GCQRi",
      "expanded_url" : "http:\/\/isteve.blogspot.com\/2013\/08\/higher-iq-people-just-better-at-getting.html",
      "display_url" : "isteve.blogspot.com\/2013\/08\/higher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367350557331456000",
  "text" : "RT @razibkhan: Higher IQ people \"just better\" at getting away with being prejudiced \u00BB good read http:\/\/t.co\/5lxL6GCQRi via @feedly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Feedly",
        "screen_name" : "feedly",
        "indices" : [ 108, 115 ],
        "id_str" : "14485018",
        "id" : 14485018
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/5lxL6GCQRi",
        "expanded_url" : "http:\/\/isteve.blogspot.com\/2013\/08\/higher-iq-people-just-better-at-getting.html",
        "display_url" : "isteve.blogspot.com\/2013\/08\/higher\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367349986293321728",
    "text" : "Higher IQ people \"just better\" at getting away with being prejudiced \u00BB good read http:\/\/t.co\/5lxL6GCQRi via @feedly",
    "id" : 367349986293321728,
    "created_at" : "2013-08-13 18:20:36 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 367350557331456000,
  "created_at" : "2013-08-13 18:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367213290264342530",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1164719549, 8.6495335667 ]
  },
  "id_str" : "367213523463864321",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I don\u2019t want pics, I want the recalculated phred scores for my read overlaps of a pair wise alignment. :)",
  "id" : 367213523463864321,
  "in_reply_to_status_id" : 367213290264342530,
  "created_at" : "2013-08-13 09:18:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1777684807, 8.6251634416 ]
  },
  "id_str" : "367202469006553088",
  "text" : "\u00AB1\/3 of us harbor bact. that produce methane. 2\/3 of us harbor a belief that methane farts burn blue. A YT search unearthed no evidence.\u00BB",
  "id" : 367202469006553088,
  "created_at" : "2013-08-13 08:34:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 102, 115 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lazyweb",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693220496, 8.6224581193 ]
  },
  "id_str" : "367200444449579008",
  "text" : "#lazyweb: What\u2019s the standard way of calculating a consensus phred score for a column of nucleotides? @PhilippBayer",
  "id" : 367200444449579008,
  "created_at" : "2013-08-13 08:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gulp",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722785743, 8.6276487779 ]
  },
  "id_str" : "367177242151251968",
  "text" : "\u00ABThere was no academic term for fist-fucking, so eventually Lowry made one up: brachioproctic eroticism.\u00BB #gulp",
  "id" : 367177242151251968,
  "created_at" : "2013-08-13 06:54:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gulp",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1473549611, 8.6668268589 ]
  },
  "id_str" : "367167065725358081",
  "text" : "Kids, remember: \u00ABTrip and fall, or cough in the security line with a stomach full of TATP, and you may explode prematurely.\u00BB #gulp ",
  "id" : 367167065725358081,
  "created_at" : "2013-08-13 06:13:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/4Mia63FZUy",
      "expanded_url" : "http:\/\/addiction-dirkh.blogspot.de\/2013\/08\/will-power-and-its-limits.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+AddictionInbox+(Addiction+Inbox",
      "display_url" : "addiction-dirkh.blogspot.de\/2013\/08\/will-p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096538514, 8.2830078314 ]
  },
  "id_str" : "367060348077350912",
  "text" : "\u00ABThe person who still trusts will power has not been sufficiently tempted.\u00BB http:\/\/t.co\/4Mia63FZUy)",
  "id" : 367060348077350912,
  "created_at" : "2013-08-12 23:09:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/aJ4CmuPb10",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0071432?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009690975, 8.28303801 ]
  },
  "id_str" : "367055990250041344",
  "text" : "Possible Role of Mother-Daughter Vocal Interactions on the Development of Species-Specific Song in Gibbons http:\/\/t.co\/aJ4CmuPb10",
  "id" : 367055990250041344,
  "created_at" : "2013-08-12 22:52:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/QUJi5D1LPY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JltXS4oqTeI",
      "display_url" : "youtube.com\/watch?v=JltXS4\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009690975, 8.28303801 ]
  },
  "id_str" : "367054803698208769",
  "text" : "Star Wars Speed Dating: \u00ABIt takes me hours to condition\u00BB http:\/\/t.co\/QUJi5D1LPY",
  "id" : 367054803698208769,
  "created_at" : "2013-08-12 22:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097040782, 8.2831824771 ]
  },
  "id_str" : "367023304789733377",
  "text" : "\u00ABWas soll ich denn antworten wenn ich gefragt werde wie h\u00E4ufig ich meine Partner wechsele? Z\u00E4hlt auch alternierend? \u2018Im Schnitt alle 18h\u2019?\u00BB",
  "id" : 367023304789733377,
  "created_at" : "2013-08-12 20:42:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0110147953, 8.2782736033 ]
  },
  "id_str" : "367006859959336962",
  "text" : "\u00ABDas ist ja widerlich! Aber ich freue mich das du jemanden gefunden hat der noch weniger Ekel kennt als ich.\u00BB",
  "id" : 367006859959336962,
  "created_at" : "2013-08-12 19:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095810587, 8.2828991508 ]
  },
  "id_str" : "367002966152065026",
  "text" : "\u00ABIch bin so verliebt in dich. Ich will den Schleim aus deiner Nase lecken!\u00BB \u2014 \u00ABDu bist so romantisch\u2026\u00BB",
  "id" : 367002966152065026,
  "created_at" : "2013-08-12 19:21:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/EZxL8cDJOQ",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/m\/pubmed\/15201304\/",
      "display_url" : "ncbi.nlm.nih.gov\/m\/pubmed\/15201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1385954326, 8.667305649 ]
  },
  "id_str" : "366931142345113600",
  "text" : "TIL: Penguins can shut down digestion in their stomachs for long-term food storage http:\/\/t.co\/EZxL8cDJOQ",
  "id" : 366931142345113600,
  "created_at" : "2013-08-12 14:36:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 39, 49 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366911572125286400",
  "geo" : { },
  "id_str" : "366913324287397888",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur I'd do it as a team along with @Fischblog!",
  "id" : 366913324287397888,
  "in_reply_to_status_id" : 366911572125286400,
  "created_at" : "2013-08-12 13:25:28 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 32, 45 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Thomas Down",
      "screen_name" : "dasmoth",
      "indices" : [ 122, 130 ],
      "id_str" : "71291461",
      "id" : 71291461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/mXgMNZIU7z",
      "expanded_url" : "http:\/\/ieeexplore.ieee.org\/xpl\/freeabs_all.jsp?arnumber=6413595&abstractAccess=no&userType=",
      "display_url" : "ieeexplore.ieee.org\/xpl\/freeabs_al\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366905658748051456",
  "text" : "That might interest you as well @PhilippBayer: Differential Privacy for Analysis of Large Data http:\/\/t.co\/mXgMNZIU7z \/HT @dasmoth",
  "id" : 366905658748051456,
  "created_at" : "2013-08-12 12:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 130, 143 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/e5y9HYF7c6",
      "expanded_url" : "http:\/\/www.newstatesman.com\/religion\/2013\/08\/atheism-maturing-and-it-will-leave-richard-dawkins-behind",
      "display_url" : "newstatesman.com\/religion\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366899831454711808",
  "text" : "\"Tragedy of Richard Dawkins\u2013a man who knows the definition of everything &amp; the meaning of nothing\" http:\/\/t.co\/e5y9HYF7c6 \/HT @PhilippBayer",
  "id" : 366899831454711808,
  "created_at" : "2013-08-12 12:31:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/MoKgvIQEzi",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/head-quarters\/2013\/aug\/12\/psychology-trolling-online-abuse",
      "display_url" : "theguardian.com\/science\/head-q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366897242084343808",
  "text" : "Psychology's answer to trolling and online abuse http:\/\/t.co\/MoKgvIQEzi",
  "id" : 366897242084343808,
  "created_at" : "2013-08-12 12:21:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366891674108039169",
  "geo" : { },
  "id_str" : "366892047124283392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Ja, und deshalb TIL: Ich kann einen relativ gro\u00DFen Hund an meinem Bart hochheben!",
  "id" : 366892047124283392,
  "in_reply_to_status_id" : 366891674108039169,
  "created_at" : "2013-08-12 12:00:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/7kmOYHlL4S",
      "expanded_url" : "http:\/\/i.imgur.com\/UYXzh9y.gif",
      "display_url" : "i.imgur.com\/UYXzh9y.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "366891911866351616",
  "text" : "Oh fuck, a crocodile! http:\/\/t.co\/7kmOYHlL4S",
  "id" : 366891911866351616,
  "created_at" : "2013-08-12 12:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366882363931754497",
  "text" : "Was der B\u00FCrohund heute gelernt hat: Man kann ausgezeichnet in B\u00E4rte bei\u00DFen und sich daran festhalten.",
  "id" : 366882363931754497,
  "created_at" : "2013-08-12 11:22:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722787172, 8.6276541369 ]
  },
  "id_str" : "366866931371880448",
  "text" : "\u00ABDie Nase l\u00E4uft auch wenn man viel denkt.\u00BB \u2014 \u00ABKeine Sorge, bei dem Gesichtsausdruck den du gerade hast wird dir das nicht passieren.\u00BB",
  "id" : 366866931371880448,
  "created_at" : "2013-08-12 10:21:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/RUMjrItz5a",
      "expanded_url" : "http:\/\/imgur.com\/a\/01efz",
      "display_url" : "imgur.com\/a\/01efz"
    } ]
  },
  "geo" : { },
  "id_str" : "366859542551736321",
  "text" : "\"Late one night in 1990, I beat the NES game Rygar.\" http:\/\/t.co\/RUMjrItz5a",
  "id" : 366859542551736321,
  "created_at" : "2013-08-12 09:51:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366853130975051778",
  "text" : "\"Nachrichten sind doch frei erfunden. Lieber so einen ehrlichen \u2026 Kaffee. Oder Doublefist bis \u00FCber den Ellenbogen.\"",
  "id" : 366853130975051778,
  "created_at" : "2013-08-12 09:26:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172294887, 8.6276413203 ]
  },
  "id_str" : "366851442394402816",
  "text" : "\u00ABKlar helfe ich dir bei deinem Problem. Wenn du mir Ausdrucke deiner Suchanfragen mitbringst die nicht geholfen haben.\u00BB",
  "id" : 366851442394402816,
  "created_at" : "2013-08-12 09:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366845845380935680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722943258, 8.6276461591 ]
  },
  "id_str" : "366848466057572352",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi but for most of your article it\u2019s used more or less interchangeably.",
  "id" : 366848466057572352,
  "in_reply_to_status_id" : 366845845380935680,
  "created_at" : "2013-08-12 09:07:44 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366845845380935680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722943258, 8.6276461591 ]
  },
  "id_str" : "366848349556588544",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi maybe it\u2019s just me being over-conscientious of this because so often people mix it up. I saw you had those disclaimers.",
  "id" : 366848349556588544,
  "in_reply_to_status_id" : 366845845380935680,
  "created_at" : "2013-08-12 09:07:16 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/xpo7N1DXoS",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Intelligence_quotient#Criticism_and_views",
      "display_url" : "en.wikipedia.org\/wiki\/Intellige\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366842737540071424",
  "geo" : { },
  "id_str" : "366843151668871168",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi Yes, I feel you should have made it more clearly that intelligence != IQ, e.g. http:\/\/t.co\/xpo7N1DXoS",
  "id" : 366843151668871168,
  "in_reply_to_status_id" : 366842737540071424,
  "created_at" : "2013-08-12 08:46:37 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366840219443531777",
  "text" : "\"Kaffee? Um morgens wach zu werden \u00F6ffne ich eine beliebige Nachrichtenseite. Zack bin ich wach und der Blutdruck ist auch wieder oben.\"",
  "id" : 366840219443531777,
  "created_at" : "2013-08-12 08:34:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/JhwwU9M1nY",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/blogs\/adamcurtis\/posts\/BUGGER",
      "display_url" : "bbc.co.uk\/blogs\/adamcurt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366835537841106944",
  "text" : "Spies: \"weirdos who have created a completely mad version of the world that they then impose on the rest of us.\" http:\/\/t.co\/JhwwU9M1nY",
  "id" : 366835537841106944,
  "created_at" : "2013-08-12 08:16:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0126316947, 8.2840820466 ]
  },
  "id_str" : "366826336104349696",
  "text" : "\u00ABDu schmeckst so Lube\u00BB",
  "id" : 366826336104349696,
  "created_at" : "2013-08-12 07:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366682579778289664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068990561, 8.2825219631 ]
  },
  "id_str" : "366803603949748224",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay, nice!",
  "id" : 366803603949748224,
  "in_reply_to_status_id" : 366682579778289664,
  "created_at" : "2013-08-12 06:09:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366801914538627073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0078325067, 8.2829386275 ]
  },
  "id_str" : "366802061796442112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer hah, great! :)",
  "id" : 366802061796442112,
  "in_reply_to_status_id" : 366801914538627073,
  "created_at" : "2013-08-12 06:03:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Nq2wOt1hXu",
      "expanded_url" : "http:\/\/instagram.com\/p\/c4hHGxBwmB\/",
      "display_url" : "instagram.com\/p\/c4hHGxBwmB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366628433888935937",
  "text" : "traveling = waiting http:\/\/t.co\/Nq2wOt1hXu",
  "id" : 366628433888935937,
  "created_at" : "2013-08-11 18:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.8893285795, 0.2601570077 ]
  },
  "id_str" : "366614338406055936",
  "text" : "strip search: \u00ABNow we only need you to sign this form.\u00BB\u2014\u00ABThe form says I don\u2019t have to &amp; I can travel on\u2026\u00BB \u2014 \u00ABYet another one who reads it\u2026\u00BB",
  "id" : 366614338406055936,
  "created_at" : "2013-08-11 17:37:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 55, 64 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jaRABQA8HY",
      "expanded_url" : "http:\/\/instagram.com\/p\/c4XiZWBwjP\/",
      "display_url" : "instagram.com\/p\/c4XiZWBwjP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366607422674055168",
  "text" : "I guess the Metalcore roots don't work out any longer, @JP_Stich! http:\/\/t.co\/jaRABQA8HY",
  "id" : 366607422674055168,
  "created_at" : "2013-08-11 17:09:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.887336606, 0.262709659 ]
  },
  "id_str" : "366605787839201280",
  "text" : "It\u2019s probably just a coincidence that I always type STD as IATA code for Stansted\u2026",
  "id" : 366605787839201280,
  "created_at" : "2013-08-11 17:03:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gulp",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.9789144075, 0.2135356752 ]
  },
  "id_str" : "366597960106119168",
  "text" : "\u00ABThere was plenty of time to think about [the taste], as it takes approximately as long to chew narwhal as it does to hunt them.\u00BB #gulp",
  "id" : 366597960106119168,
  "created_at" : "2013-08-11 16:32:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 0, 11 ],
      "id_str" : "14085070",
      "id" : 14085070
    }, {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 12, 25 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/366594573646057472\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/nJtGIbpD2K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRZn0osCUAAw6HI.jpg",
      "id_str" : "366594573650251776",
      "id" : 366594573650251776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRZn0osCUAAw6HI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/nJtGIbpD2K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366593553842982912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1581206657, 0.1345376763 ]
  },
  "id_str" : "366594573646057472",
  "in_reply_to_user_id" : 14085070,
  "text" : "@carlzimmer @ericmjohnson oh, and there\u2019s the phylogeny used in my master\u2019s thesis http:\/\/t.co\/nJtGIbpD2K",
  "id" : 366594573646057472,
  "in_reply_to_status_id" : 366593553842982912,
  "created_at" : "2013-08-11 16:18:52 +0000",
  "in_reply_to_screen_name" : "carlzimmer",
  "in_reply_to_user_id_str" : "14085070",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 0, 11 ],
      "id_str" : "14085070",
      "id" : 14085070
    }, {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 12, 25 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 61, 72 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366593553842982912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1905674664, 0.1353493693 ]
  },
  "id_str" : "366593929669390336",
  "in_reply_to_user_id" : 14085070,
  "text" : "@carlzimmer @ericmjohnson thanks, I think [pun not intended] @PygmyLoris has one as well.",
  "id" : 366593929669390336,
  "in_reply_to_status_id" : 366593553842982912,
  "created_at" : "2013-08-11 16:16:18 +0000",
  "in_reply_to_screen_name" : "carlzimmer",
  "in_reply_to_user_id_str" : "14085070",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 0, 13 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366591636047806464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2000636641, 0.1451866357 ]
  },
  "id_str" : "366592889393922049",
  "in_reply_to_user_id" : 19084034,
  "text" : "@ericmjohnson are they worth reading as well?",
  "id" : 366592889393922049,
  "in_reply_to_status_id" : 366591636047806464,
  "created_at" : "2013-08-11 16:12:10 +0000",
  "in_reply_to_screen_name" : "ericmjohnson",
  "in_reply_to_user_id_str" : "19084034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 0, 13 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/xQ8GUaUpMW",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0068814",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "366589853867053057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2002398073, 0.1442382406 ]
  },
  "id_str" : "366591239191146496",
  "in_reply_to_user_id" : 19084034,
  "text" : "@ericmjohnson oh, and the paper I told you about. http:\/\/t.co\/xQ8GUaUpMW;",
  "id" : 366591239191146496,
  "in_reply_to_status_id" : 366589853867053057,
  "created_at" : "2013-08-11 16:05:37 +0000",
  "in_reply_to_screen_name" : "ericmjohnson",
  "in_reply_to_user_id_str" : "19084034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 0, 13 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 14, 25 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/366590961977028608\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/e8Y5AlcSzp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRZkiaLCcAEJN4T.jpg",
      "id_str" : "366590961981222913",
      "id" : 366590961981222913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRZkiaLCcAEJN4T.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/e8Y5AlcSzp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366589853867053057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2000955689, 0.1440046932 ]
  },
  "id_str" : "366590961977028608",
  "in_reply_to_user_id" : 19084034,
  "text" : "@ericmjohnson @carlzimmer even many fellow evolutionary biologists have to ask. :) http:\/\/t.co\/e8Y5AlcSzp",
  "id" : 366590961977028608,
  "in_reply_to_status_id" : 366589853867053057,
  "created_at" : "2013-08-11 16:04:31 +0000",
  "in_reply_to_screen_name" : "ericmjohnson",
  "in_reply_to_user_id_str" : "19084034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1932769835, 0.1351184292 ]
  },
  "id_str" : "366582042269462528",
  "text" : "\u00ABWell, you don\u2019t have to do rowing when studying in Cambridge. You can also choose to get flogged. It\u2019s up to you!\u00BB",
  "id" : 366582042269462528,
  "created_at" : "2013-08-11 15:29:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 19, 32 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2008691263, 0.125741791 ]
  },
  "id_str" : "366569580677709824",
  "text" : "Congratulations to @ericmjohnson for being the first to instantly recognize the tattoo on the back of my hand!",
  "id" : 366569580677709824,
  "created_at" : "2013-08-11 14:39:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366545608833630208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.206785685, 0.1158928357 ]
  },
  "id_str" : "366564390192947200",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode wenn du keinen Bart hast\u2026hast du keinen Bart\u2026 But I\u2019m not gonna judge!",
  "id" : 366564390192947200,
  "in_reply_to_status_id" : 366545608833630208,
  "created_at" : "2013-08-11 14:18:55 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitzwilliam Darcy",
      "screen_name" : "FtzwilliamDarcy",
      "indices" : [ 0, 16 ],
      "id_str" : "872329956",
      "id" : 872329956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366563858191622146",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2080762618, 0.1158714736 ]
  },
  "id_str" : "366564078161899521",
  "in_reply_to_user_id" : 872329956,
  "text" : "@FtzwilliamDarcy I had to think of you all time I went through the museum!",
  "id" : 366564078161899521,
  "in_reply_to_status_id" : 366563858191622146,
  "created_at" : "2013-08-11 14:17:41 +0000",
  "in_reply_to_screen_name" : "FtzwilliamDarcy",
  "in_reply_to_user_id_str" : "872329956",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/7Ed9hxwAnk",
      "expanded_url" : "http:\/\/instagram.com\/p\/c4Bsqihwsn\/",
      "display_url" : "instagram.com\/p\/c4Bsqihwsn\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.200308801, 0.1200979524 ]
  },
  "id_str" : "366559685286965248",
  "text" : "Enough sightseeing for today. @ Fitzwilliam Museum http:\/\/t.co\/7Ed9hxwAnk",
  "id" : 366559685286965248,
  "created_at" : "2013-08-11 14:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366557072474644480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2067828598, 0.1158930152 ]
  },
  "id_str" : "366558478929629185",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk very much so, will do the river trip the next time around :)",
  "id" : 366558478929629185,
  "in_reply_to_status_id" : 366557072474644480,
  "created_at" : "2013-08-11 13:55:26 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 7, 15 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 96, 106 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366554305983037440",
  "text" : "Thanks @glyn_dk for recommending the Fitzwilliam. It is great (so no punting today). And thanks @DNADigest for the nice hack day!",
  "id" : 366554305983037440,
  "created_at" : "2013-08-11 13:38:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/RMNUnedzz8",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3-_y4BwpT\/",
      "display_url" : "instagram.com\/p\/c3-_y4BwpT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.200308801, 0.1200979524 ]
  },
  "id_str" : "366553399312908288",
  "text" : "Choose your own adventure @ Fitzwilliam Museum http:\/\/t.co\/RMNUnedzz8",
  "id" : 366553399312908288,
  "created_at" : "2013-08-11 13:35:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/gURCrcDuS6",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3-6iyhwpM\/",
      "display_url" : "instagram.com\/p\/c3-6iyhwpM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.200308801, 0.1200979524 ]
  },
  "id_str" : "366553114402226176",
  "text" : "Mummified cat @ Fitzwilliam Museum http:\/\/t.co\/gURCrcDuS6",
  "id" : 366553114402226176,
  "created_at" : "2013-08-11 13:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366546217955639296",
  "text" : "Porcelain dogs everywhere!",
  "id" : 366546217955639296,
  "created_at" : "2013-08-11 13:06:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bdsm",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/jSCbmFfqxp",
      "expanded_url" : "http:\/\/bitchyjones.wordpress.com\/2009\/10\/02\/kinky-sex-tips\/",
      "display_url" : "bitchyjones.wordpress.com\/2009\/10\/02\/kin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366545874488270849",
  "text" : "RT @fragmente: \"Do it to Julia! Do it to Julia!\" als safeword: http:\/\/t.co\/jSCbmFfqxp #1984 #bdsm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bdsm",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/jSCbmFfqxp",
        "expanded_url" : "http:\/\/bitchyjones.wordpress.com\/2009\/10\/02\/kinky-sex-tips\/",
        "display_url" : "bitchyjones.wordpress.com\/2009\/10\/02\/kin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366542676335656961",
    "text" : "\"Do it to Julia! Do it to Julia!\" als safeword: http:\/\/t.co\/jSCbmFfqxp #1984 #bdsm",
    "id" : 366542676335656961,
    "created_at" : "2013-08-11 12:52:38 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 366545874488270849,
  "created_at" : "2013-08-11 13:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366543267577331712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2001025328, 0.120091387 ]
  },
  "id_str" : "366544664150540288",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode nein, prinzipiell nicht. Jeder Bart ist ein guter Bart. Nur die initiale Entt\u00E4uschung, aber auch mit Verl\u00E4ngerung impressive! :)",
  "id" : 366544664150540288,
  "in_reply_to_status_id" : 366543267577331712,
  "created_at" : "2013-08-11 13:00:32 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366542283073531904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2018031843, 0.1202334341 ]
  },
  "id_str" : "366542656895057924",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode das w\u00FCrde mich sehr traurig machen :(",
  "id" : 366542656895057924,
  "in_reply_to_status_id" : 366542283073531904,
  "created_at" : "2013-08-11 12:52:34 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366537480327008258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2018030687, 0.1202333877 ]
  },
  "id_str" : "366542145747828738",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode du meinst er k\u00F6nnte bei der Bartl\u00E4nge cheaten?!",
  "id" : 366542145747828738,
  "in_reply_to_status_id" : 366537480327008258,
  "created_at" : "2013-08-11 12:50:32 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/KnoEoLwyfC",
      "expanded_url" : "http:\/\/instagram.com\/p\/c30lx_hwtk\/",
      "display_url" : "instagram.com\/p\/c30lx_hwtk\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.200308801, 0.1200979524 ]
  },
  "id_str" : "366530410009731072",
  "text" : "Beard Porn @ Fitzwilliam Museum http:\/\/t.co\/KnoEoLwyfC",
  "id" : 366530410009731072,
  "created_at" : "2013-08-11 12:03:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1995735755, 0.1141666883 ]
  },
  "id_str" : "366526000181415937",
  "text" : "\u00ABX-ray analysis of the painting has shown that Degas painted \u2018David &amp; Goliath\u2019 on top of a painting of a nude male model.\u00BB",
  "id" : 366526000181415937,
  "created_at" : "2013-08-11 11:46:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/GiBNfBOyLy",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3sk_6BwmC\/",
      "display_url" : "instagram.com\/p\/c3sk_6BwmC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366512848467267586",
  "text" : "Don't steal, no value http:\/\/t.co\/GiBNfBOyLy",
  "id" : 366512848467267586,
  "created_at" : "2013-08-11 10:54:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/R6YbE1vqhj",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3pWXphwjR\/",
      "display_url" : "instagram.com\/p\/c3pWXphwjR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2061061575, 0.1151556277 ]
  },
  "id_str" : "366506796514418689",
  "text" : "punts @ Magdlene Bridge http:\/\/t.co\/R6YbE1vqhj",
  "id" : 366506796514418689,
  "created_at" : "2013-08-11 10:30:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/XdWuRNrGbn",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3oNDohwid\/",
      "display_url" : "instagram.com\/p\/c3oNDohwid\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2070791029, 0.1177851314 ]
  },
  "id_str" : "366504155432484864",
  "text" : "\u00ABYou could be hit by an apple of a descendent of THE tree. If you'd be allowed to walk on the lawn\u00BB @\u2026 http:\/\/t.co\/XdWuRNrGbn",
  "id" : 366504155432484864,
  "created_at" : "2013-08-11 10:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366502231912103936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2107949215, 0.116791921 ]
  },
  "id_str" : "366502743940141056",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode sexy!",
  "id" : 366502743940141056,
  "in_reply_to_status_id" : 366502231912103936,
  "created_at" : "2013-08-11 10:13:58 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 10, 18 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366497797253496833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2053245269, 0.1216411963 ]
  },
  "id_str" : "366499464992665600",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @insideX gute Reise!",
  "id" : 366499464992665600,
  "in_reply_to_status_id" : 366497797253496833,
  "created_at" : "2013-08-11 10:00:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366493713213562880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2041831691, 0.1194003736 ]
  },
  "id_str" : "366494970200334337",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX @Senficon danke! Ich hoffe du hast dich im Garten gut bedient? :)",
  "id" : 366494970200334337,
  "in_reply_to_status_id" : 366493713213562880,
  "created_at" : "2013-08-11 09:43:04 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VMYE8EyHhY",
      "expanded_url" : "http:\/\/instagram.com\/p\/c3gQZXhwsZ\/",
      "display_url" : "instagram.com\/p\/c3gQZXhwsZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.195803602, 0.1392066479 ]
  },
  "id_str" : "366485689694556160",
  "text" : "Greenhouse Overpass @ Tony Carter Bridge http:\/\/t.co\/VMYE8EyHhY",
  "id" : 366485689694556160,
  "created_at" : "2013-08-11 09:06:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Gerlach",
      "screen_name" : "gerlach_d",
      "indices" : [ 3, 13 ],
      "id_str" : "1325200380",
      "id" : 1325200380
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 109, 125 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/jV7WOvMd04",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-5g",
      "display_url" : "wp.me\/p1PnkE-5g"
    } ]
  },
  "geo" : { },
  "id_str" : "366471147228897281",
  "text" : "RT @gerlach_d: Bioinformatics is not something you are taught, it's a way of life http:\/\/t.co\/jV7WOvMd04 via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 94, 110 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/jV7WOvMd04",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-5g",
        "display_url" : "wp.me\/p1PnkE-5g"
      } ]
    },
    "geo" : { },
    "id_str" : "365131530764435456",
    "text" : "Bioinformatics is not something you are taught, it's a way of life http:\/\/t.co\/jV7WOvMd04 via @wordpressdotcom",
    "id" : 365131530764435456,
    "created_at" : "2013-08-07 15:25:15 +0000",
    "user" : {
      "name" : "Daniel Gerlach",
      "screen_name" : "gerlach_d",
      "protected" : false,
      "id_str" : "1325200380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467033587813203968\/N3rhrX_E_normal.jpeg",
      "id" : 1325200380,
      "verified" : false
    }
  },
  "id" : 366471147228897281,
  "created_at" : "2013-08-11 08:08:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366422372481368064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1921751718, 0.1409267853 ]
  },
  "id_str" : "366455775289282560",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode und wie gut ist der Match?",
  "id" : 366455775289282560,
  "in_reply_to_status_id" : 366422372481368064,
  "created_at" : "2013-08-11 07:07:19 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/4jhyAcjZsr",
      "expanded_url" : "http:\/\/i.imgur.com\/ui37SnV.gif",
      "display_url" : "i.imgur.com\/ui37SnV.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.191946025, 0.1408591633 ]
  },
  "id_str" : "366368302555070464",
  "text" : "Cats vs Dogs http:\/\/t.co\/4jhyAcjZsr",
  "id" : 366368302555070464,
  "created_at" : "2013-08-11 01:19:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/bnseFMcIJW",
      "expanded_url" : "http:\/\/instagram.com\/p\/c2hAIYhwn6\/",
      "display_url" : "instagram.com\/p\/c2hAIYhwn6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2043586752, 0.1173949242 ]
  },
  "id_str" : "366346632150777856",
  "text" : "Drama Queen @ King's College http:\/\/t.co\/bnseFMcIJW",
  "id" : 366346632150777856,
  "created_at" : "2013-08-10 23:53:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Down",
      "screen_name" : "dasmoth",
      "indices" : [ 94, 102 ],
      "id_str" : "71291461",
      "id" : 71291461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/e80fjzWv5A",
      "expanded_url" : "http:\/\/www.biodalliance.org\/",
      "display_url" : "biodalliance.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.191946025, 0.1408591633 ]
  },
  "id_str" : "366345337444642816",
  "text" : "Wow, the new biodalliance really looks great. Will try to upgrade it on openSNP. Gratulations @dasmoth http:\/\/t.co\/e80fjzWv5A",
  "id" : 366345337444642816,
  "created_at" : "2013-08-10 23:48:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.191946025, 0.1408591633 ]
  },
  "id_str" : "366344422931169280",
  "text" : "reverse is-ought fallacy",
  "id" : 366344422931169280,
  "created_at" : "2013-08-10 23:44:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/nqd2X8ZMFW",
      "expanded_url" : "http:\/\/instagram.com\/p\/c2cjnghwgl\/",
      "display_url" : "instagram.com\/p\/c2cjnghwgl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2043586752, 0.1173949242 ]
  },
  "id_str" : "366337106903179264",
  "text" : "\u00ABWow, a rare day without rain!\u00BB @ King's College http:\/\/t.co\/nqd2X8ZMFW",
  "id" : 366337106903179264,
  "created_at" : "2013-08-10 23:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/ZLIQI9ONz9",
      "expanded_url" : "http:\/\/instagram.com\/p\/c2bmTaBwui\/",
      "display_url" : "instagram.com\/p\/c2bmTaBwui\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366334735053627392",
  "text" : "Burger Menu II http:\/\/t.co\/ZLIQI9ONz9",
  "id" : 366334735053627392,
  "created_at" : "2013-08-10 23:06:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/ayTYjGnrhY",
      "expanded_url" : "http:\/\/instagram.com\/p\/c2beb1hwuR\/",
      "display_url" : "instagram.com\/p\/c2beb1hwuR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366334450725953536",
  "text" : "Burger Menu http:\/\/t.co\/ayTYjGnrhY",
  "id" : 366334450725953536,
  "created_at" : "2013-08-10 23:05:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1948453878, 0.1373418421 ]
  },
  "id_str" : "366330287719858177",
  "text" : "\u00ABDamals gab es noch gar keine Videokameras.\u00BB \u2014 \u00ABDas glaube ich dir nicht. Du bist zwar alt, aber nicht \u00E4lter als Leni Riefenstahl.",
  "id" : 366330287719858177,
  "created_at" : "2013-08-10 22:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2019659105, 0.1256800935 ]
  },
  "id_str" : "366277130214445056",
  "text" : "\u00ABUsually I say that you\u2019re surprised when people on the street are talking english.\u00BB \u2014 \u00ABToday it\u2019s when people aren\u2019t talking about sex.\u00BB",
  "id" : 366277130214445056,
  "created_at" : "2013-08-10 19:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Down",
      "screen_name" : "dasmoth",
      "indices" : [ 0, 8 ],
      "id_str" : "71291461",
      "id" : 71291461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366250735513513984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2041838781, 0.1191758558 ]
  },
  "id_str" : "366251845380870144",
  "in_reply_to_user_id" : 71291461,
  "text" : "@dasmoth thanks for giving the author. You made it home safely? :)",
  "id" : 366251845380870144,
  "in_reply_to_status_id" : 366250735513513984,
  "created_at" : "2013-08-10 17:36:59 +0000",
  "in_reply_to_screen_name" : "dasmoth",
  "in_reply_to_user_id_str" : "71291461",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2041972784, 0.1194110379 ]
  },
  "id_str" : "366250551157071872",
  "text" : "\u00ABThey were so annoyed with me arguing programming languages, they made me head of media: had to watch porn all day with highest salary ever\u00BB",
  "id" : 366250551157071872,
  "created_at" : "2013-08-10 17:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/rxwDZXHDUW",
      "expanded_url" : "http:\/\/instagram.com\/p\/c10o5aBwho\/",
      "display_url" : "instagram.com\/p\/c10o5aBwho\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.206380483, 0.1199752092 ]
  },
  "id_str" : "366249350453665793",
  "text" : "End of Hack Day @ Baroosh http:\/\/t.co\/rxwDZXHDUW",
  "id" : 366249350453665793,
  "created_at" : "2013-08-10 17:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.2066594288, 0.1198789012 ]
  },
  "id_str" : "366246460594982912",
  "text" : "\u00ABThen the CEO told me he never thought that a woman could be sysadmin\u2026\u00BB \u2014 \u00ABWhat did you do?\u00BB \u2014 \u00ABLeave France\u2026\u00BB",
  "id" : 366246460594982912,
  "created_at" : "2013-08-10 17:15:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949855736, 0.1347230756 ]
  },
  "id_str" : "366231135908401154",
  "text" : "\u00ABThe dragon with the finger? What kind of shortcut is that?\u00BB \u2014 \u00ABDRAGGING!\u00BB",
  "id" : 366231135908401154,
  "created_at" : "2013-08-10 16:14:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.194947376, 0.1346770946 ]
  },
  "id_str" : "366227182357463041",
  "text" : "\u00ABI\u2019ll head home. I haven\u2019t really seen my wife this week.\u00BB \u2014 \u00ABAnd I guess she\u2019s really happy about it!\u00BB",
  "id" : 366227182357463041,
  "created_at" : "2013-08-10 15:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 3, 13 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/366205548028383233\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/WalH5tMW8M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRUGAXWCUAAGxK7.jpg",
      "id_str" : "366205548036771840",
      "id" : 366205548036771840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRUGAXWCUAAGxK7.jpg",
      "sizes" : [ {
        "h" : 1226,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1552,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WalH5tMW8M"
    } ],
    "hashtags" : [ {
      "text" : "genomics",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "data",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "sharing",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "OA",
      "indices" : [ 86, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366224283451662336",
  "text" : "RT @DNADigest: Great discussions at the DNAdigest hack day!  #genomics #data #sharing #OA http:\/\/t.co\/WalH5tMW8M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/366205548028383233\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/WalH5tMW8M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRUGAXWCUAAGxK7.jpg",
        "id_str" : "366205548036771840",
        "id" : 366205548036771840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRUGAXWCUAAGxK7.jpg",
        "sizes" : [ {
          "h" : 1226,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1552,
          "resize" : "fit",
          "w" : 2592
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WalH5tMW8M"
      } ],
      "hashtags" : [ {
        "text" : "genomics",
        "indices" : [ 46, 55 ]
      }, {
        "text" : "data",
        "indices" : [ 56, 61 ]
      }, {
        "text" : "sharing",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "OA",
        "indices" : [ 71, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366205548028383233",
    "text" : "Great discussions at the DNAdigest hack day!  #genomics #data #sharing #OA http:\/\/t.co\/WalH5tMW8M",
    "id" : 366205548028383233,
    "created_at" : "2013-08-10 14:33:01 +0000",
    "user" : {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "protected" : false,
      "id_str" : "334912047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430707142232772608\/Vmx-V5fY_normal.png",
      "id" : 334912047,
      "verified" : false
    }
  },
  "id" : 366224283451662336,
  "created_at" : "2013-08-10 15:47:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949440218, 0.1347347625 ]
  },
  "id_str" : "366216354992357376",
  "text" : "\u00ABLooking at genomes I know there is no god. He would have got fed up and would have done some refactoring by now.\u00BB",
  "id" : 366216354992357376,
  "created_at" : "2013-08-10 15:15:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949111627, 0.134691212 ]
  },
  "id_str" : "366211034769399809",
  "text" : "\u00ABThere\u2019s more variation in the Variant Call Format then in genomes.\u00BB",
  "id" : 366211034769399809,
  "created_at" : "2013-08-10 14:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949397026, 0.1346783637 ]
  },
  "id_str" : "366204127522463746",
  "text" : "\u00ABI want to die on Mars. Preferably not on impact.\u00BB",
  "id" : 366204127522463746,
  "created_at" : "2013-08-10 14:27:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949759667, 0.1347299707 ]
  },
  "id_str" : "366179025825169410",
  "text" : "\u00ABThere\u2019s a special circle in hell for people who use telephones!\u00BB",
  "id" : 366179025825169410,
  "created_at" : "2013-08-10 12:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1948959502, 0.1346345553 ]
  },
  "id_str" : "366161483572314112",
  "text" : "\u00ABUnfortunately, because it\u2019s Microsoft, it\u2019s a secure building.\u00BB \u2014 \u00ABUnlike their software\u2026\u00BB",
  "id" : 366161483572314112,
  "created_at" : "2013-08-10 11:37:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949300401, 0.1347133808 ]
  },
  "id_str" : "366155233828675585",
  "text" : "\u00ABGenau, ich brauche ganz dringend mehr Kinder. Bist du schon wieder auf Drogen?\u00BB",
  "id" : 366155233828675585,
  "created_at" : "2013-08-10 11:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949195247, 0.1346957228 ]
  },
  "id_str" : "366144262468939776",
  "text" : "\u00ABI feel we should split that category in case of the government. There\u2019s no way that things fit \u2018say\u2019 and \u2018do\u2019 at the same time!\u00BB",
  "id" : 366144262468939776,
  "created_at" : "2013-08-10 10:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366143788420308992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949195247, 0.1346957228 ]
  },
  "id_str" : "366143903642030082",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I know, don\u2019t worry. :)",
  "id" : 366143903642030082,
  "in_reply_to_status_id" : 366143788420308992,
  "created_at" : "2013-08-10 10:28:03 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366135348025233408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1948810695, 0.1346892128 ]
  },
  "id_str" : "366138497792348160",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sure, I will run around, dropping your name ;)",
  "id" : 366138497792348160,
  "in_reply_to_status_id" : 366135348025233408,
  "created_at" : "2013-08-10 10:06:35 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366132159200763904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1947944148, 0.1346736281 ]
  },
  "id_str" : "366133689098317825",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a indeed!",
  "id" : 366133689098317825,
  "in_reply_to_status_id" : 366132159200763904,
  "created_at" : "2013-08-10 09:47:28 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366119178446442496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1949126894, 0.1346999953 ]
  },
  "id_str" : "366119517677551616",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon I\u2019m in love! &lt;3",
  "id" : 366119517677551616,
  "in_reply_to_status_id" : 366119178446442496,
  "created_at" : "2013-08-10 08:51:09 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1948099519, 0.1346736774 ]
  },
  "id_str" : "366117229219168256",
  "text" : "\u00ABI have to brief you today. If there\u2019s a fire: Cross your fingers and run for the exits. That\u2019s it.\u00BB",
  "id" : 366117229219168256,
  "created_at" : "2013-08-10 08:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1948717502, 0.1346971334 ]
  },
  "id_str" : "366112560103170048",
  "text" : "\u00ABYou have been to Cambridge before? And came back? You must be mad!\u00BB",
  "id" : 366112560103170048,
  "created_at" : "2013-08-10 08:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/FSM3esEZNP",
      "expanded_url" : "http:\/\/instagram.com\/p\/c0xs1CBwrD\/",
      "display_url" : "instagram.com\/p\/c0xs1CBwrD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366101841584459778",
  "text" : "Live http:\/\/t.co\/FSM3esEZNP",
  "id" : 366101841584459778,
  "created_at" : "2013-08-10 07:40:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/nMWemXRhQk",
      "expanded_url" : "http:\/\/instagram.com\/p\/c0tB_Chwne\/",
      "display_url" : "instagram.com\/p\/c0tB_Chwne\/"
    } ]
  },
  "geo" : { },
  "id_str" : "366091588050493441",
  "text" : "All Is Known http:\/\/t.co\/nMWemXRhQk",
  "id" : 366091588050493441,
  "created_at" : "2013-08-10 07:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 45, 55 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1921842039, 0.1409118512 ]
  },
  "id_str" : "366090837026799616",
  "text" : "Now for some breakfast before heading to the @DNADigest Hack Day.",
  "id" : 366090837026799616,
  "created_at" : "2013-08-10 06:57:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jTHPf7WeBY",
      "expanded_url" : "http:\/\/i.imgur.com\/MWuH16w.gif",
      "display_url" : "i.imgur.com\/MWuH16w.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365973785460998145",
  "text" : "Empathic yawning in dogs. cats on the other hand\u2026 http:\/\/t.co\/jTHPf7WeBY",
  "id" : 365973785460998145,
  "created_at" : "2013-08-09 23:12:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/ZAY4qsShvJ",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/57808976418\/reviewer-3",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/578089764\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365971249593196544",
  "text" : "Reviewer #3 http:\/\/t.co\/ZAY4qsShvJ",
  "id" : 365971249593196544,
  "created_at" : "2013-08-09 23:01:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/2Ixx5Uv0Ay",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/overthinking-it\/2013\/08\/09\/tusken-raiders-ride-single-file-as-a-valid-military-tactic\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/overthinking-i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365970555331026945",
  "text" : "Tusken Raiders Ride Single File as a Valid Military Tactic http:\/\/t.co\/2Ixx5Uv0Ay",
  "id" : 365970555331026945,
  "created_at" : "2013-08-09 22:59:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/fB2ITCIp3T",
      "expanded_url" : "http:\/\/www.smithsonianmag.com\/ideas-innovations\/The-Education-of-a-Bomb-Dog-213881241.html#Bomb-Dogs-explosive-detection-canine-training-1.jpg",
      "display_url" : "smithsonianmag.com\/ideas-innovati\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365967742903402496",
  "text" : "The Education of a Bomb Dog http:\/\/t.co\/fB2ITCIp3T",
  "id" : 365967742903402496,
  "created_at" : "2013-08-09 22:48:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365964239761969152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365964676426776576",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich in unseren Herzen &amp; Emulatoren wird es ewig leben!",
  "id" : 365964676426776576,
  "in_reply_to_status_id" : 365964239761969152,
  "created_at" : "2013-08-09 22:35:52 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/2k2Uv9DJVA",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/08\/09\/secret-of-mana-is-20-years-old.html",
      "display_url" : "boingboing.net\/2013\/08\/09\/sec\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365963728946085888",
  "text" : "Secret of Mana is 20 years old http:\/\/t.co\/2k2Uv9DJVA",
  "id" : 365963728946085888,
  "created_at" : "2013-08-09 22:32:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1920523544, 0.14088101 ]
  },
  "id_str" : "365963516835930113",
  "text" : "\u00ABActually I just arrived 5 minutes ago. But for the street you\u2019re looking for you have to go into that direction &amp; take the 2nd on the left\u00BB",
  "id" : 365963516835930113,
  "created_at" : "2013-08-09 22:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.9285858097, 0.2253936511 ]
  },
  "id_str" : "365949972237123584",
  "text" : "\u00ABThe first class is completely empty and there are even power plugs. So consider yourself upgraded.\u00BB &lt;3",
  "id" : 365949972237123584,
  "created_at" : "2013-08-09 21:37:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.8938678735, 0.2586502002 ]
  },
  "id_str" : "365938161945284609",
  "text" : "\u00ABWie sie alle gemerkt haben: Wir sind gelandet und versuchen noch zu bremsen.\u00BB",
  "id" : 365938161945284609,
  "created_at" : "2013-08-09 20:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9461182324, 7.2698801106 ]
  },
  "id_str" : "365907897022021632",
  "text" : "So spannend wie die Fl\u00FCssigkeitsmengen &gt;100ml auf dem Weg von Flasche in Magen durch Zauberei unbedenklich werden!",
  "id" : 365907897022021632,
  "created_at" : "2013-08-09 18:50:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/0WpjEXRk1y",
      "expanded_url" : "http:\/\/instagram.com\/p\/czVRCdhwnV\/",
      "display_url" : "instagram.com\/p\/czVRCdhwnV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9459178382, 7.2696876526 ]
  },
  "id_str" : "365898697298546688",
  "text" : "not ready yet @ Frankfurt Hahn Airport (HHN) http:\/\/t.co\/0WpjEXRk1y",
  "id" : 365898697298546688,
  "created_at" : "2013-08-09 18:13:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/sYRMgZjjrc",
      "expanded_url" : "http:\/\/instagram.com\/p\/czS21Ghwia\/",
      "display_url" : "instagram.com\/p\/czS21Ghwia\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9459178382, 7.2696876526 ]
  },
  "id_str" : "365893862725656576",
  "text" : "behind bars @ Frankfurt Hahn Airport (HHN) http:\/\/t.co\/sYRMgZjjrc",
  "id" : 365893862725656576,
  "created_at" : "2013-08-09 17:54:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VPlfZXfsyV",
      "expanded_url" : "http:\/\/www.roche.com\/media\/media_releases\/med_dia_2013-08-06.htm",
      "display_url" : "roche.com\/media\/media_re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365891404909654016",
  "text" : "RT @pathogenomenick: About three hundred years after 454 released 1kb reads, they can now do 800bp amplicons: http:\/\/t.co\/VPlfZXfsyV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/VPlfZXfsyV",
        "expanded_url" : "http:\/\/www.roche.com\/media\/media_releases\/med_dia_2013-08-06.htm",
        "display_url" : "roche.com\/media\/media_re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365782413697224706",
    "text" : "About three hundred years after 454 released 1kb reads, they can now do 800bp amplicons: http:\/\/t.co\/VPlfZXfsyV",
    "id" : 365782413697224706,
    "created_at" : "2013-08-09 10:31:37 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 365891404909654016,
  "created_at" : "2013-08-09 17:44:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bioinformatik Bingen",
      "screen_name" : "bioinformatik",
      "indices" : [ 3, 17 ],
      "id_str" : "234886028",
      "id" : 234886028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bingen",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "Bioinformatik",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365888143838289921",
  "text" : "RT @bioinformatik: Bewerbungsfrist verl\u00E4ngert! Noch bis 31.8. kann man sich an der FH #Bingen f\u00FCr die Angewandte #Bioinformatik bewerben ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bingen",
        "indices" : [ 67, 74 ]
      }, {
        "text" : "Bioinformatik",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/sDQpLKhl2v",
        "expanded_url" : "http:\/\/www.fh-bingen.de\/studieninteressierte\/online-bewerbung.html",
        "display_url" : "fh-bingen.de\/studieninteres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365887943203758081",
    "text" : "Bewerbungsfrist verl\u00E4ngert! Noch bis 31.8. kann man sich an der FH #Bingen f\u00FCr die Angewandte #Bioinformatik bewerben http:\/\/t.co\/sDQpLKhl2v",
    "id" : 365887943203758081,
    "created_at" : "2013-08-09 17:30:58 +0000",
    "user" : {
      "name" : "Bioinformatik Bingen",
      "screen_name" : "bioinformatik",
      "protected" : false,
      "id_str" : "234886028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738332744502108160\/XEd5Vt7L_normal.jpg",
      "id" : 234886028,
      "verified" : false
    }
  },
  "id" : 365888143838289921,
  "created_at" : "2013-08-09 17:31:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/lIZZZMJNfu",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=Z_uSbxUSNmg",
      "display_url" : "youtube.com\/watch?v=Z_uSbx\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0521480181, 8.5865675261 ]
  },
  "id_str" : "365866135985463296",
  "text" : "Oh, the next Pearl Jam record is getting 20 years old this year! http:\/\/t.co\/lIZZZMJNfu",
  "id" : 365866135985463296,
  "created_at" : "2013-08-09 16:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 10, 18 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365859945691873283",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0859392485, 8.6610618064 ]
  },
  "id_str" : "365860271262154754",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @insideX das waren +\/- die Worte die Silke gestern am Telefon verwendete. Liebe Gr\u00FC\u00DFe \u00FCbrigens. :)",
  "id" : 365860271262154754,
  "in_reply_to_status_id" : 365859945691873283,
  "created_at" : "2013-08-09 15:41:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 30, 44 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365859148182716416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0949247481, 8.6676124162 ]
  },
  "id_str" : "365859435895205888",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a you should team up with @onetruecathal ;)",
  "id" : 365859435895205888,
  "in_reply_to_status_id" : 365859148182716416,
  "created_at" : "2013-08-09 15:37:41 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365858322714345472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1055900511, 8.6635944211 ]
  },
  "id_str" : "365858718061043712",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor nur ein billiger pun.",
  "id" : 365858718061043712,
  "in_reply_to_status_id" : 365858322714345472,
  "created_at" : "2013-08-09 15:34:50 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365852540681715715",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1055900511, 8.6635944211 ]
  },
  "id_str" : "365858453303984128",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX @Senficon die Schwarze ist sowieso schon bei uns als Gnadenhof-Ersatz gelandet. Pass nur auf den Kater auf. ;)",
  "id" : 365858453303984128,
  "in_reply_to_status_id" : 365852540681715715,
  "created_at" : "2013-08-09 15:33:47 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1051829057, 8.6621911638 ]
  },
  "id_str" : "365857263774208000",
  "text" : "Ass-at-Management",
  "id" : 365857263774208000,
  "created_at" : "2013-08-09 15:29:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365851611685335043",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1063942541, 8.6645770869 ]
  },
  "id_str" : "365851936316076033",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX @Senficon das ist schon die executive summary-version! Da ist alles wichtig. Aber vor allem Kapitel 6.3.4!",
  "id" : 365851936316076033,
  "in_reply_to_status_id" : 365851611685335043,
  "created_at" : "2013-08-09 15:07:53 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 10, 18 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365850624564269058",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1063942541, 8.6645770869 ]
  },
  "id_str" : "365850982267097088",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @insideX und sie sogar ausgedruckt! Damit gar nichts schief gehen kann!",
  "id" : 365850982267097088,
  "in_reply_to_status_id" : 365850624564269058,
  "created_at" : "2013-08-09 15:04:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/XfcoukDJkW",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/PVsFz2r7uJ4\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365847318261542913",
  "text" : "It's a trap! http:\/\/t.co\/XfcoukDJkW",
  "id" : 365847318261542913,
  "created_at" : "2013-08-09 14:49:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1432343901, 8.6685944717 ]
  },
  "id_str" : "365842502089056256",
  "text" : "\u00ABToms River Water was much more worried about running out of water than they were about chemical contamination.\u00BB Yay, capitalism! m(",
  "id" : 365842502089056256,
  "created_at" : "2013-08-09 14:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365826709154570244",
  "geo" : { },
  "id_str" : "365828737238970368",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon Bis zur letzten Milliamperestunde!",
  "id" : 365828737238970368,
  "in_reply_to_status_id" : 365826709154570244,
  "created_at" : "2013-08-09 13:35:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 0, 7 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365823964754350080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722912509, 8.6276515245 ]
  },
  "id_str" : "365825925637603328",
  "in_reply_to_user_id" : 111716214,
  "text" : "@nplhse Kinkleitfaden",
  "id" : 365825925637603328,
  "in_reply_to_status_id" : 365823964754350080,
  "created_at" : "2013-08-09 13:24:32 +0000",
  "in_reply_to_screen_name" : "nplhse",
  "in_reply_to_user_id_str" : "111716214",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/5170wExYCS",
      "expanded_url" : "http:\/\/img.pandawhale.com\/post-19104-Tuxedo-cat-jump-fail-gif--The-mdfk.gif",
      "display_url" : "img.pandawhale.com\/post-19104-Tux\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "365813317748539393",
  "geo" : { },
  "id_str" : "365825635865726976",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon next: the great leap forward http:\/\/t.co\/5170wExYCS",
  "id" : 365825635865726976,
  "in_reply_to_status_id" : 365813317748539393,
  "created_at" : "2013-08-09 13:23:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365821887403659264",
  "text" : "\"Hast du gute oder schlechte Nachrichten?\" - \"Sowohl als auch: Gut: Die Analyse hat funktioniert. Schlecht: Garbage In, Garbage Out...\"",
  "id" : 365821887403659264,
  "created_at" : "2013-08-09 13:08:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365807818768531456",
  "geo" : { },
  "id_str" : "365809063533096961",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon gratz, great leader ;)",
  "id" : 365809063533096961,
  "in_reply_to_status_id" : 365807818768531456,
  "created_at" : "2013-08-09 12:17:31 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 108, 113 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/KrHHVeSF1G",
      "expanded_url" : "http:\/\/www.plosgenetics.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pgen.1003692?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosgenetics%2FNewArticles+%28PLOS+Genetics+-+New+Articles%29",
      "display_url" : "plosgenetics.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365798054995038208",
  "text" : "DNA profiling: \"The Innocence Project at Twenty: An Interview with Barry Scheck\" http:\/\/t.co\/KrHHVeSF1G \/cc @li5a",
  "id" : 365798054995038208,
  "created_at" : "2013-08-09 11:33:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 99, 112 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dKsMweIRSB",
      "expanded_url" : "http:\/\/www.plosgenetics.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pgen.1003609?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosgenetics%2FNewArticles+%28PLOS+Genetics+-+New+Articles%29",
      "display_url" : "plosgenetics.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365794247892406272",
  "text" : "Re-Ranking Sequencing Variants in the Post-GWAS Era for Accurate Causal Variant Identification \/cc @PhilippBayer http:\/\/t.co\/dKsMweIRSB",
  "id" : 365794247892406272,
  "created_at" : "2013-08-09 11:18:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 111, 122 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/69eufhSxKm",
      "expanded_url" : "http:\/\/blogs.nature.com\/news\/2013\/08\/why-rabbits-have-white-tails.html\/",
      "display_url" : "blogs.nature.com\/news\/2013\/08\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365793341427814400",
  "text" : "Nice, just had a discussion about this some weeks ago: Why rabbits have white tails http:\/\/t.co\/69eufhSxKm \/HT @LouWoodley",
  "id" : 365793341427814400,
  "created_at" : "2013-08-09 11:15:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/3A8DHd3uPe",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0069924?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365792875709087744",
  "text" : "Beyond Reasonable Doubt: Evolution from DNA Sequences http:\/\/t.co\/3A8DHd3uPe",
  "id" : 365792875709087744,
  "created_at" : "2013-08-09 11:13:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722852835, 8.6276513896 ]
  },
  "id_str" : "365780789004222464",
  "text" : "\u00ABEr ist sehr beliebt in der Rechtsmedizin. Als super Positivkontrolle f\u00FCr alle Drogentests.\u00BB",
  "id" : 365780789004222464,
  "created_at" : "2013-08-09 10:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eduard Hergenreider",
      "screen_name" : "edix237",
      "indices" : [ 0, 8 ],
      "id_str" : "55818956",
      "id" : 55818956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365768157287284736",
  "geo" : { },
  "id_str" : "365772961380184064",
  "in_reply_to_user_id" : 55818956,
  "text" : "@edix237 Danke, das Paper was der Artikel zitiert kannte ich schon, die Gegen\u00FCberstellung zum Kaffeekonsum war mir neu :)",
  "id" : 365772961380184064,
  "in_reply_to_status_id" : 365768157287284736,
  "created_at" : "2013-08-09 09:54:04 +0000",
  "in_reply_to_screen_name" : "edix237",
  "in_reply_to_user_id_str" : "55818956",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722852835, 8.6276513896 ]
  },
  "id_str" : "365761274119856128",
  "text" : "\u00ABWas tust du da?!\u00BB \u2014 \u00ABIhre Lefzen kraulen. Von innen. Mit meiner Zunge.\u00BB",
  "id" : 365761274119856128,
  "created_at" : "2013-08-09 09:07:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/L4y5fXoz7t",
      "expanded_url" : "http:\/\/www.popsci.com\/science\/article\/2013-07\/meet-researcher-whose-fake-poop-project-could-save-your-life",
      "display_url" : "popsci.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365756319443058689",
  "text" : "\"How do you turn that sludge into a fecal transplant?\" \u2013 \"Robogut.\" http:\/\/t.co\/L4y5fXoz7t",
  "id" : 365756319443058689,
  "created_at" : "2013-08-09 08:47:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1780654423, 8.6242252114 ]
  },
  "id_str" : "365753629501702144",
  "text" : "\u00ABJuPi-Kink\u00BB Ach, Autokorrektur\u2026",
  "id" : 365753629501702144,
  "created_at" : "2013-08-09 08:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1374352012, 8.6707724968 ]
  },
  "id_str" : "365739623902744576",
  "text" : "\u00ABBy the 1960s, biostatisticians had turned cancer cluster analysis into a well-structured scientific endeavor that no one wanted to pursue.\u00BB",
  "id" : 365739623902744576,
  "created_at" : "2013-08-09 07:41:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1008458296, 8.5334899593 ]
  },
  "id_str" : "365731625503424513",
  "text" : "\u00ABBin in einer 3\/4 Stunde im B\u00FCro. Sorg bitte daf\u00FCr das ein doppelter Kaffee mit vierfacher Bohnenmenge auf meinem Schreibtisch steht.\u00BB",
  "id" : 365731625503424513,
  "created_at" : "2013-08-09 07:09:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365623501832466432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0053775763, 8.3097416849 ]
  },
  "id_str" : "365726523845644289",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, doing all the maps was such a pain!",
  "id" : 365726523845644289,
  "in_reply_to_status_id" : 365623501832466432,
  "created_at" : "2013-08-09 06:49:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/ND56TaR0Lf",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/dog-spies\/2013\/08\/08\/what-do-you-hear-in-these-dog-sounds\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/dog-spies\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365630017532727297",
  "text" : "What Do You Hear in These Dog Sounds? http:\/\/t.co\/ND56TaR0Lf",
  "id" : 365630017532727297,
  "created_at" : "2013-08-09 00:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 66, 74 ],
      "id_str" : "778057",
      "id" : 778057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/wz2xAL0vCq",
      "expanded_url" : "http:\/\/bzfd.it\/14yKxMU",
      "display_url" : "bzfd.it\/14yKxMU"
    } ]
  },
  "geo" : { },
  "id_str" : "365607858580111360",
  "text" : "RT @zoonpolitikon: I think a qualify. I get about 18 out of 27 RT @acarvin 27 Signs You're A Browncoat - http:\/\/t.co\/wz2xAL0vCq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Carvin",
        "screen_name" : "acarvin",
        "indices" : [ 47, 55 ],
        "id_str" : "778057",
        "id" : 778057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/wz2xAL0vCq",
        "expanded_url" : "http:\/\/bzfd.it\/14yKxMU",
        "display_url" : "bzfd.it\/14yKxMU"
      } ]
    },
    "geo" : { },
    "id_str" : "365607578828423168",
    "text" : "I think a qualify. I get about 18 out of 27 RT @acarvin 27 Signs You're A Browncoat - http:\/\/t.co\/wz2xAL0vCq",
    "id" : 365607578828423168,
    "created_at" : "2013-08-08 22:56:54 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 365607858580111360,
  "created_at" : "2013-08-08 22:58:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/hnd4pfYceG",
      "expanded_url" : "http:\/\/listen.hatnote.com\/#en,de,nl",
      "display_url" : "listen.hatnote.com\/#en,de,nl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365602187054821377",
  "text" : "Listen to Wikipedia edits http:\/\/t.co\/hnd4pfYceG",
  "id" : 365602187054821377,
  "created_at" : "2013-08-08 22:35:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365599783890595842",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365600159138185218",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot hohe Erwartungen? Mittlerweile erwarte ich ja nicht mal mehr das du am n\u00E4chsten Morgen wieder aufwachst!",
  "id" : 365600159138185218,
  "in_reply_to_status_id" : 365599783890595842,
  "created_at" : "2013-08-08 22:27:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365597870969196546",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365598266211053569",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wenn du zeigst das du Daten besser erfassen kannst als eine Schnecke. Wie \u00FCblich entt\u00E4uschst du dabei permanent.",
  "id" : 365598266211053569,
  "in_reply_to_status_id" : 365597870969196546,
  "created_at" : "2013-08-08 22:19:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365596540137504770",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365597108818034690",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot zwischen der Rehabilitation steht nur noch der Peer Review-Prozess!",
  "id" : 365597108818034690,
  "in_reply_to_status_id" : 365596540137504770,
  "created_at" : "2013-08-08 22:15:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bayer Grants4Apps",
      "screen_name" : "grants4apps",
      "indices" : [ 3, 15 ],
      "id_str" : "974130415",
      "id" : 974130415
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 17, 28 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 29, 41 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 108, 124 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Berlin",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365580902111264768",
  "text" : "RT @grants4apps: @openSNPorg @helgerausch confirmed @ Grants4Apps session BarCamp Health IT #Berlin Sept 4, @gedankenstuecke by stream http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 0, 11 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Helge Rausch \uD83E\uDD59",
        "screen_name" : "helgerausch",
        "indices" : [ 12, 24 ],
        "id_str" : "52747896",
        "id" : 52747896
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 91, 107 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Berlin",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/RUHS6bpMCs",
        "expanded_url" : "http:\/\/goo.gl\/8XLJd6",
        "display_url" : "goo.gl\/8XLJd6"
      } ]
    },
    "geo" : { },
    "id_str" : "365578863708872704",
    "in_reply_to_user_id" : 380205172,
    "text" : "@openSNPorg @helgerausch confirmed @ Grants4Apps session BarCamp Health IT #Berlin Sept 4, @gedankenstuecke by stream http:\/\/t.co\/RUHS6bpMCs",
    "id" : 365578863708872704,
    "created_at" : "2013-08-08 21:02:47 +0000",
    "in_reply_to_screen_name" : "openSNPorg",
    "in_reply_to_user_id_str" : "380205172",
    "user" : {
      "name" : "Bayer Grants4Apps",
      "screen_name" : "grants4apps",
      "protected" : false,
      "id_str" : "974130415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890845033989066753\/ZEP1BR8F_normal.jpg",
      "id" : 974130415,
      "verified" : false
    }
  },
  "id" : 365580902111264768,
  "created_at" : "2013-08-08 21:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365578322433945600",
  "text" : "Waterboarding pass",
  "id" : 365578322433945600,
  "created_at" : "2013-08-08 21:00:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nS7Stnf4uI",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/polygonwild",
      "display_url" : "reddit.com\/r\/polygonwild"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365568233329274880",
  "text" : "Sexy, there\u2019s a polygonwild-subreddit! http:\/\/t.co\/nS7Stnf4uI",
  "id" : 365568233329274880,
  "created_at" : "2013-08-08 20:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/6n80vehh60",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/08\/living-3d-printed-cyborg-ear-promising-but-eww\/#p3",
      "display_url" : "arstechnica.com\/science\/2013\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365553873915609089",
  "text" : "I love that they just downloaded the seed for their 3D-printed fleshy cyborg ear from thingiverse. http:\/\/t.co\/6n80vehh60",
  "id" : 365553873915609089,
  "created_at" : "2013-08-08 19:23:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/AvdZDfhRjA",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1617",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365552654212022273",
  "text" : "Totally wrong for the combination of taking a shower while talking to someone! http:\/\/t.co\/AvdZDfhRjA",
  "id" : 365552654212022273,
  "created_at" : "2013-08-08 19:18:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Becca, PhD \uD83D\uDC18",
      "screen_name" : "doc_becca",
      "indices" : [ 3, 13 ],
      "id_str" : "30233007",
      "id" : 30233007
    }, {
      "name" : "animal Mistress",
      "screen_name" : "pottytheron",
      "indices" : [ 29, 41 ],
      "id_str" : "1241965878",
      "id" : 1241965878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/c2LHL0SLS5",
      "expanded_url" : "http:\/\/wp.me\/p2YCl9-gZ",
      "display_url" : "wp.me\/p2YCl9-gZ"
    } ]
  },
  "geo" : { },
  "id_str" : "365544295584890880",
  "text" : "RT @doc_becca: Must read. RT @pottytheron: Type 1 and Type 2 errors http:\/\/t.co\/c2LHL0SLS5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "animal Mistress",
        "screen_name" : "pottytheron",
        "indices" : [ 14, 26 ],
        "id_str" : "1241965878",
        "id" : 1241965878
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/c2LHL0SLS5",
        "expanded_url" : "http:\/\/wp.me\/p2YCl9-gZ",
        "display_url" : "wp.me\/p2YCl9-gZ"
      } ]
    },
    "geo" : { },
    "id_str" : "365543377627906048",
    "text" : "Must read. RT @pottytheron: Type 1 and Type 2 errors http:\/\/t.co\/c2LHL0SLS5",
    "id" : 365543377627906048,
    "created_at" : "2013-08-08 18:41:47 +0000",
    "user" : {
      "name" : "Dr Becca, PhD \uD83D\uDC18",
      "screen_name" : "doc_becca",
      "protected" : false,
      "id_str" : "30233007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/132012394\/dumbobutt_normal.jpg",
      "id" : 30233007,
      "verified" : false
    }
  },
  "id" : 365544295584890880,
  "created_at" : "2013-08-08 18:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/3WCEyCIuQo",
      "expanded_url" : "http:\/\/i.imgur.com\/qHKsHfj.jpg",
      "display_url" : "i.imgur.com\/qHKsHfj.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365527124595060737",
  "text" : "Pure bliss http:\/\/t.co\/3WCEyCIuQo",
  "id" : 365527124595060737,
  "created_at" : "2013-08-08 17:37:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 0, 10 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365517128788475907",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365518036981121025",
  "in_reply_to_user_id" : 334912047,
  "text" : "@DNADigest great :)",
  "id" : 365518036981121025,
  "in_reply_to_status_id" : 365517128788475907,
  "created_at" : "2013-08-08 17:01:05 +0000",
  "in_reply_to_screen_name" : "DNADigest",
  "in_reply_to_user_id_str" : "334912047",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 0, 10 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365516230603448320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365516765322686465",
  "in_reply_to_user_id" : 334912047,
  "text" : "@DNADigest also looking forward to it! Unfortunately I probably won\u2019t join you. I\u2019ll only arrive in Stansted on 21:50.",
  "id" : 365516765322686465,
  "in_reply_to_status_id" : 365516230603448320,
  "created_at" : "2013-08-08 16:56:02 +0000",
  "in_reply_to_screen_name" : "DNADigest",
  "in_reply_to_user_id_str" : "334912047",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Henderson",
      "screen_name" : "markgfh",
      "indices" : [ 3, 11 ],
      "id_str" : "33249457",
      "id" : 33249457
    }, {
      "name" : "Tom Chivers",
      "screen_name" : "TomChivers",
      "indices" : [ 48, 59 ],
      "id_str" : "19533817",
      "id" : 19533817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TeINsZX0oi",
      "expanded_url" : "http:\/\/blogs.telegraph.co.uk\/news\/tomchiversscience\/100230250\/please-be-quiet-richard-dawkins-im-begging-as-a-fan\/",
      "display_url" : "blogs.telegraph.co.uk\/news\/tomchiver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365500083187351552",
  "text" : "RT @markgfh: Such a great advert for editors RT @TomChivers: Please be quiet, Richard Dawkins, I'm begging, as a fan http:\/\/t.co\/TeINsZX0oi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Chivers",
        "screen_name" : "TomChivers",
        "indices" : [ 35, 46 ],
        "id_str" : "19533817",
        "id" : 19533817
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/TeINsZX0oi",
        "expanded_url" : "http:\/\/blogs.telegraph.co.uk\/news\/tomchiversscience\/100230250\/please-be-quiet-richard-dawkins-im-begging-as-a-fan\/",
        "display_url" : "blogs.telegraph.co.uk\/news\/tomchiver\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365499230443413504",
    "text" : "Such a great advert for editors RT @TomChivers: Please be quiet, Richard Dawkins, I'm begging, as a fan http:\/\/t.co\/TeINsZX0oi",
    "id" : 365499230443413504,
    "created_at" : "2013-08-08 15:46:21 +0000",
    "user" : {
      "name" : "Mark Henderson",
      "screen_name" : "markgfh",
      "protected" : false,
      "id_str" : "33249457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/301596801\/n613320651_548757_4691_normal.jpg",
      "id" : 33249457,
      "verified" : false
    }
  },
  "id" : 365500083187351552,
  "created_at" : "2013-08-08 15:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365490131521650692",
  "geo" : { },
  "id_str" : "365490370718601219",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv for me Python \"already\" crashed with 600k ;)",
  "id" : 365490370718601219,
  "in_reply_to_status_id" : 365490131521650692,
  "created_at" : "2013-08-08 15:11:09 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/F57SBnMzEQ",
      "expanded_url" : "http:\/\/blogs.plos.org\/dnascience\/2013\/08\/08\/hela-the-havasupai-and-informed-consent\/",
      "display_url" : "blogs.plos.org\/dnascience\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365488400058429440",
  "text" : "HeLa, the Havasupai, and Informed Consent http:\/\/t.co\/F57SBnMzEQ",
  "id" : 365488400058429440,
  "created_at" : "2013-08-08 15:03:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/KfZ8QYqLCv",
      "expanded_url" : "http:\/\/imgur.com\/FIyBARg",
      "display_url" : "imgur.com\/FIyBARg"
    } ]
  },
  "geo" : { },
  "id_str" : "365484435585511424",
  "text" : "There should be a whole subreddit for things people say while being asleep http:\/\/t.co\/KfZ8QYqLCv",
  "id" : 365484435585511424,
  "created_at" : "2013-08-08 14:47:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ch08lRgYv5",
      "expanded_url" : "http:\/\/puntcon2013.eventbrite.co.uk\/",
      "display_url" : "puntcon2013.eventbrite.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "365482153292730368",
  "text" : "\"Why PuntCon? - Conferences are fun, but don\u2019t have ducklings.\" http:\/\/t.co\/ch08lRgYv5",
  "id" : 365482153292730368,
  "created_at" : "2013-08-08 14:38:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365480806191345664",
  "geo" : { },
  "id_str" : "365481090821005313",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj it's \"jumped the shark\"-week, isn't it?",
  "id" : 365481090821005313,
  "in_reply_to_status_id" : 365480806191345664,
  "created_at" : "2013-08-08 14:34:17 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 11, 18 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/akaTlwbWtK",
      "expanded_url" : "http:\/\/www.cls-med.de\/images\/product_images\/popup_images\/6914_0.jpg",
      "display_url" : "cls-med.de\/images\/product\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "365473688008667136",
  "geo" : { },
  "id_str" : "365474303787020288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Der @nplhse kann dir da bestimmt einen einfachen Hack zeigen. http:\/\/t.co\/akaTlwbWtK",
  "id" : 365474303787020288,
  "in_reply_to_status_id" : 365473688008667136,
  "created_at" : "2013-08-08 14:07:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365470930966818816",
  "geo" : { },
  "id_str" : "365472792222769152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Das ist nur Erdnussbutter!",
  "id" : 365472792222769152,
  "in_reply_to_status_id" : 365470930966818816,
  "created_at" : "2013-08-08 14:01:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1783146159, 8.6261684237 ]
  },
  "id_str" : "365467060614082560",
  "text" : "\u00ABWei\u00DFt du wer noch gerne B\u00E4ume gemalt hat?!\u00BB \u2014 \u00ABJaja, Hitler\u2026 Aber meine Bootstrap Values sind definitiv besser!\u00BB",
  "id" : 365467060614082560,
  "created_at" : "2013-08-08 13:38:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365461866773889025",
  "text" : "\u00ABWollt ihr nicht zumindest mal versuchen mit was anderem als Star Wars-Quotes zu kommunizieren?\u00BB \u2014 \u00ABDo or do not. There is no try!\u00BB",
  "id" : 365461866773889025,
  "created_at" : "2013-08-08 13:17:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365453459648032770",
  "text" : "RT @helgerausch: Pro tip: 80486 CPUs make excellent beard combs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365453164272562179",
    "text" : "Pro tip: 80486 CPUs make excellent beard combs",
    "id" : 365453164272562179,
    "created_at" : "2013-08-08 12:43:18 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 365453459648032770,
  "created_at" : "2013-08-08 12:44:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365453406606860288",
  "text" : "\"Willst du weiter mit uns \u00FCber Quer- und L\u00E4ngsstreifen diskutieren? Oder dich einfacheren Problemen wie Meta-Genome-Assemblies widmen?\"",
  "id" : 365453406606860288,
  "created_at" : "2013-08-08 12:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723014507, 8.6276274302 ]
  },
  "id_str" : "365443828515213314",
  "text" : "\u00ABMaximum Arsemony\u00BB \u2026",
  "id" : 365443828515213314,
  "created_at" : "2013-08-08 12:06:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/M0NyNqqG1h",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1jw6r2\/fathers_of_reddit_whats_your_greatest_dont_tell\/cbj1s6z",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365436510499115009",
  "text" : "So this is why people are having kids! http:\/\/t.co\/M0NyNqqG1h",
  "id" : 365436510499115009,
  "created_at" : "2013-08-08 11:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/yW67NTApHz",
      "expanded_url" : "http:\/\/i.imgur.com\/vCU80VI.gif",
      "display_url" : "i.imgur.com\/vCU80VI.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "365429028502503424",
  "text" : "Putting 14 million files into a single directory\u2026 http:\/\/t.co\/yW67NTApHz",
  "id" : 365429028502503424,
  "created_at" : "2013-08-08 11:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/ZZdPdVXHsT",
      "expanded_url" : "http:\/\/bitly.net\/a\/feelings",
      "display_url" : "bitly.net\/a\/feelings"
    } ]
  },
  "geo" : { },
  "id_str" : "365426373940097024",
  "text" : "\"It's like URL shortening for feelings\" Oh, wait... http:\/\/t.co\/ZZdPdVXHsT",
  "id" : 365426373940097024,
  "created_at" : "2013-08-08 10:56:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/XZtjuKjWxx",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi%2F10.1371%2Fjournal.pone.0071783?utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29&utm_medium=feed&utm_source=feedburner",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365424650060177409",
  "text" : "Diversity &amp; Biotic Homogenization of Urban Land-Snail Faunas in Relation 2  Habitat Types &amp; Macroclimate in 32 Cities http:\/\/t.co\/XZtjuKjWxx",
  "id" : 365424650060177409,
  "created_at" : "2013-08-08 10:50:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365399040654983168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1776789617, 8.6141008427 ]
  },
  "id_str" : "365400023334256640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, and I think it\u2019s fun to see MP being used on non-sequence based matrices which you rarely do outside paleontology. :)",
  "id" : 365400023334256640,
  "in_reply_to_status_id" : 365399040654983168,
  "created_at" : "2013-08-08 09:12:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/pAFBA6UcqH",
      "expanded_url" : "http:\/\/bit.ly\/15Q1cbL",
      "display_url" : "bit.ly\/15Q1cbL"
    } ]
  },
  "geo" : { },
  "id_str" : "365395721098248193",
  "text" : "RT @PygmyLoris: Ah this has made my day. How to be angry on the internet http:\/\/t.co\/pAFBA6UcqH via EVERYONE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/pAFBA6UcqH",
        "expanded_url" : "http:\/\/bit.ly\/15Q1cbL",
        "display_url" : "bit.ly\/15Q1cbL"
      } ]
    },
    "geo" : { },
    "id_str" : "365394628419125250",
    "text" : "Ah this has made my day. How to be angry on the internet http:\/\/t.co\/pAFBA6UcqH via EVERYONE",
    "id" : 365394628419125250,
    "created_at" : "2013-08-08 08:50:42 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 365395721098248193,
  "created_at" : "2013-08-08 08:55:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 94, 107 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/fTBjR8TUXx",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0068814?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365378920255717376",
  "text" : "The phylomemetic tree of phylogenetics: \"Categorizing Ideas about Trees: A Tree of Trees\" \/cc @PhilippBayer http:\/\/t.co\/fTBjR8TUXx",
  "id" : 365378920255717376,
  "created_at" : "2013-08-08 07:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bZmOAPBt6u",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0071365?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365377522063515648",
  "text" : "Contagious Yawning by Dogs &amp; Empathy: \"We thank the dogs and their owners for their participation in the study\" http:\/\/t.co\/bZmOAPBt6u",
  "id" : 365377522063515648,
  "created_at" : "2013-08-08 07:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365376988325756928",
  "text" : "\"Anschlie\u00DFend gehen wir zum L\u00F6schplatz (praktischer Teil \u2013L\u00F6sch\u00FCbung-, ca. 1 \u2013 11\u008E2 Std.).\" Ach, daher kommt die Nummer!",
  "id" : 365376988325756928,
  "created_at" : "2013-08-08 07:40:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722856558, 8.6276543377 ]
  },
  "id_str" : "365369725728997376",
  "text" : "\u00ABDas war jetzt aber nicht besonders quick\u2026\u00BB \u2014 \u00ABDaf\u00FCr au\u00DFergew\u00F6hnlich dirty, sogar f\u00FCr meine Code-Verh\u00E4ltnisse!\u00BB",
  "id" : 365369725728997376,
  "created_at" : "2013-08-08 07:11:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1644917857, 8.6431544367 ]
  },
  "id_str" : "365362086722805761",
  "text" : "\u00ABresidential cluster investigations were closer to existentialist drama. Important, provocative questions were asked; nothing ever resolved\u00BB",
  "id" : 365362086722805761,
  "created_at" : "2013-08-08 06:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365348123138207746",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0060163079, 8.3183184507 ]
  },
  "id_str" : "365348260363251713",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer you should have an email with the details. :)",
  "id" : 365348260363251713,
  "in_reply_to_status_id" : 365348123138207746,
  "created_at" : "2013-08-08 05:46:27 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365257236693528576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096968934, 8.2830708101 ]
  },
  "id_str" : "365258689717874688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so it\u2019s not faster from that point of view.",
  "id" : 365258689717874688,
  "in_reply_to_status_id" : 365257236693528576,
  "created_at" : "2013-08-07 23:50:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365257236693528576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096892653, 8.2829955345 ]
  },
  "id_str" : "365258619513614336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in terms of animal suffering: I guess so. For researchers: iirc you still have to give the animals anesthetics beforehand.",
  "id" : 365258619513614336,
  "in_reply_to_status_id" : 365257236693528576,
  "created_at" : "2013-08-07 23:50:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365255263483203585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0126365003, 8.2840946907 ]
  },
  "id_str" : "365255887738241025",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer back in the days we did decapitation, CO2 &amp; Isoflurane. Have to say I preferred the last two as it\u2019s less prone to hum. error",
  "id" : 365255887738241025,
  "in_reply_to_status_id" : 365255263483203585,
  "created_at" : "2013-08-07 23:39:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/hb3HExyxZh",
      "expanded_url" : "http:\/\/www.nature.com\/news\/best-way-to-kill-lab-animals-sought-1.13509",
      "display_url" : "nature.com\/news\/best-way-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365254843151024129",
  "text" : "Best way to kill lab animals sought http:\/\/t.co\/hb3HExyxZh",
  "id" : 365254843151024129,
  "created_at" : "2013-08-07 23:35:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 23, 35 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/7tI5o672BA",
      "expanded_url" : "http:\/\/git-animals.tumblr.com\/post\/24405409515\/pull-request-merged",
      "display_url" : "git-animals.tumblr.com\/post\/244054095\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365254600703475715",
  "text" : "RT @PhilippBayer: When @helgerausch accepted my pull-request http:\/\/t.co\/7tI5o672BA and when he tried to run my changes http:\/\/t.co\/Iyoxh6t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Helge Rausch \uD83E\uDD59",
        "screen_name" : "helgerausch",
        "indices" : [ 5, 17 ],
        "id_str" : "52747896",
        "id" : 52747896
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/7tI5o672BA",
        "expanded_url" : "http:\/\/git-animals.tumblr.com\/post\/24405409515\/pull-request-merged",
        "display_url" : "git-animals.tumblr.com\/post\/244054095\u2026"
      }, {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Iyoxh6tCEW",
        "expanded_url" : "http:\/\/git-animals.tumblr.com\/post\/25384356630\/git-pull-error-your-local-changes-to-the",
        "display_url" : "git-animals.tumblr.com\/post\/253843566\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365251937995730944",
    "text" : "When @helgerausch accepted my pull-request http:\/\/t.co\/7tI5o672BA and when he tried to run my changes http:\/\/t.co\/Iyoxh6tCEW",
    "id" : 365251937995730944,
    "created_at" : "2013-08-07 23:23:42 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 365254600703475715,
  "created_at" : "2013-08-07 23:34:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Xdr3uJZJBd",
      "expanded_url" : "http:\/\/blog.chembark.com\/2013\/08\/06\/a-disturbing-note-in-a-recent-si-file\/?utm_source=twitterfeed&utm_medium=twitter",
      "display_url" : "blog.chembark.com\/2013\/08\/06\/a-d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365241658222182402",
  "text" : "\u00ABEmma, please insert NMR data here! where are they? and for this compound, just make up an elemental analysis\u2026\u00BB http:\/\/t.co\/Xdr3uJZJBd",
  "id" : 365241658222182402,
  "created_at" : "2013-08-07 22:42:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENCODE",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365232267406217216",
  "text" : "RT @DanGraur: I got a 3D print as a present. It's now been blinged and I shall wear it at special \"Kill #ENCODE\" occasions. Thanks. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENCODE",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/YhwKF8wfup",
        "expanded_url" : "https:\/\/twitter.com\/DanGraur\/status\/365231570736517121\/photo\/1",
        "display_url" : "pic.twitter.com\/YhwKF8wfup"
      } ]
    },
    "geo" : { },
    "id_str" : "365231570736517121",
    "text" : "I got a 3D print as a present. It's now been blinged and I shall wear it at special \"Kill #ENCODE\" occasions. Thanks. http:\/\/t.co\/YhwKF8wfup",
    "id" : 365231570736517121,
    "created_at" : "2013-08-07 22:02:46 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 365232267406217216,
  "created_at" : "2013-08-07 22:05:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RoterFranz",
      "screen_name" : "RoterFranz",
      "indices" : [ 0, 11 ],
      "id_str" : "3177839572",
      "id" : 3177839572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365230489730166785",
  "text" : "@RoterFranz Ich reiche sie gerne an die Autorin weiter. ;)",
  "id" : 365230489730166785,
  "created_at" : "2013-08-07 21:58:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365229795539288064",
  "text" : "\u00ABProlapse Tree\u00BB \u2013 Die Typos die ich so lesen muss werden immer interessanter.",
  "id" : 365229795539288064,
  "created_at" : "2013-08-07 21:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 28, 40 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0099572051, 8.2696826242 ]
  },
  "id_str" : "365221296595931137",
  "text" : "Yay, funding! @PhilippBayer @helgerausch",
  "id" : 365221296595931137,
  "created_at" : "2013-08-07 21:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/76vXQ4qbrH",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/extinction-countdown\/2013\/08\/07\/pangolins-peril-illegal-trade\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/extinction-cou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365219028047892482",
  "text" : "Pangolins in Peril: All 8 Species of Scaly Anteaters Endangered by Illegal Trade http:\/\/t.co\/76vXQ4qbrH",
  "id" : 365219028047892482,
  "created_at" : "2013-08-07 21:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maciej Ceglowski",
      "screen_name" : "baconmeteor",
      "indices" : [ 3, 15 ],
      "id_str" : "150185852",
      "id" : 150185852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365218718235631617",
  "text" : "RT @baconmeteor: I've spent too many hours trying to explain the sunk cost fallacy to stop now",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365096499908059136",
    "text" : "I've spent too many hours trying to explain the sunk cost fallacy to stop now",
    "id" : 365096499908059136,
    "created_at" : "2013-08-07 13:06:03 +0000",
    "user" : {
      "name" : "Maciej Ceglowski",
      "screen_name" : "baconmeteor",
      "protected" : false,
      "id_str" : "150185852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3149352891\/1082c5f5629fc830a0de3edcc4423916_normal.jpeg",
      "id" : 150185852,
      "verified" : false
    }
  },
  "id" : 365218718235631617,
  "created_at" : "2013-08-07 21:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Maloney",
      "screen_name" : "dtrmcr",
      "indices" : [ 3, 10 ],
      "id_str" : "16889315",
      "id" : 16889315
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 101, 110 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dtrmcr\/status\/364841734838034432\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/B18yrKrJvI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRAtn_SCIAAF0xG.jpg",
      "id_str" : "364841734842228736",
      "id" : 364841734842228736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRAtn_SCIAAF0xG.jpg",
      "sizes" : [ {
        "h" : 870,
        "resize" : "fit",
        "w" : 1651
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 870,
        "resize" : "fit",
        "w" : 1651
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/B18yrKrJvI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/pXWTEExny0",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_cetaceans",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365218496201752578",
  "text" : "RT @dtrmcr: Nice work editor of https:\/\/t.co\/pXWTEExny0 - missing diagrams labeled 'cetacean needed' @doctorow http:\/\/t.co\/B18yrKrJvI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 89, 98 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dtrmcr\/status\/364841734838034432\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/B18yrKrJvI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRAtn_SCIAAF0xG.jpg",
        "id_str" : "364841734842228736",
        "id" : 364841734842228736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRAtn_SCIAAF0xG.jpg",
        "sizes" : [ {
          "h" : 870,
          "resize" : "fit",
          "w" : 1651
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 1651
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/B18yrKrJvI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/pXWTEExny0",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/List_of_cetaceans",
        "display_url" : "en.wikipedia.org\/wiki\/List_of_c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364841734838034432",
    "text" : "Nice work editor of https:\/\/t.co\/pXWTEExny0 - missing diagrams labeled 'cetacean needed' @doctorow http:\/\/t.co\/B18yrKrJvI",
    "id" : 364841734838034432,
    "created_at" : "2013-08-06 20:13:42 +0000",
    "user" : {
      "name" : "David Maloney",
      "screen_name" : "dtrmcr",
      "protected" : false,
      "id_str" : "16889315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785064708621627392\/3_HFcB62_normal.jpg",
      "id" : 16889315,
      "verified" : false
    }
  },
  "id" : 365218496201752578,
  "created_at" : "2013-08-07 21:10:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/iO8pF81G7g",
      "expanded_url" : "http:\/\/i.imgur.com\/8BjP2E2.gif",
      "display_url" : "i.imgur.com\/8BjP2E2.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365212021878308866",
  "text" : "Go, get it, Tardigrade! &lt;3 http:\/\/t.co\/iO8pF81G7g",
  "id" : 365212021878308866,
  "created_at" : "2013-08-07 20:45:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 4, 13 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/JoGxh6st4p",
      "expanded_url" : "http:\/\/m.washingtonpost.com\/blogs\/the-switch\/wp\/2013\/08\/06\/lonely-curiosity-rover-sings-happy-birthday-to-itself-on-mars\/?Post+generic=%3Ftid%3Dsm_twitter_washingtonpost",
      "display_url" : "m.washingtonpost.com\/blogs\/the-swit\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007923, 8.287795 ]
  },
  "id_str" : "365195161577340929",
  "text" : "Uh, @senficon, du musst jetzt ganz stark sein! http:\/\/t.co\/JoGxh6st4p",
  "id" : 365195161577340929,
  "created_at" : "2013-08-07 19:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/OrX0EHBHwt",
      "expanded_url" : "http:\/\/i.imgur.com\/otlr4Ta.jpg",
      "display_url" : "i.imgur.com\/otlr4Ta.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096869243, 8.2830401257 ]
  },
  "id_str" : "365187573888466946",
  "text" : "How the typical student looks like while asking for help with sed\/awk http:\/\/t.co\/OrX0EHBHwt",
  "id" : 365187573888466946,
  "created_at" : "2013-08-07 19:07:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0694625298, 8.6328467265 ]
  },
  "id_str" : "365162455300710400",
  "text" : "\u00ABTo a Greenpeace veteran like Rapaport, an industrial tower on private property was like a fire hydrant to a dog.\u00BB",
  "id" : 365162455300710400,
  "created_at" : "2013-08-07 17:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 8, 16 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365151403091562497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693725929, 8.6223593695 ]
  },
  "id_str" : "365152056559935488",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @heyaudy the first 1000 alignments looked fine. Going to let it run over night. All sequences are 250bp, so that\u2019s not an issue. ;)",
  "id" : 365152056559935488,
  "in_reply_to_status_id" : 365151403091562497,
  "created_at" : "2013-08-07 16:46:49 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 8, 16 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365148536330919936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1702686858, 8.6229336624 ]
  },
  "id_str" : "365150287209562116",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @heyaudy will give that a try as soon as I\u2019m home. ClustalW failed miserably.",
  "id" : 365150287209562116,
  "in_reply_to_status_id" : 365148536330919936,
  "created_at" : "2013-08-07 16:39:47 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365143165835030528",
  "text" : "\"Ich finde Backups doof. Das verf\u00FChrt die Leute doch nur dazu mal ihren Homefolder zu l\u00F6schen!\"",
  "id" : 365143165835030528,
  "created_at" : "2013-08-07 16:11:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365138712797003776",
  "geo" : { },
  "id_str" : "365141502944485376",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Ah, stupid me. Now I only need to find out how to make it report the whole alignment instead of only the overlap :D",
  "id" : 365141502944485376,
  "in_reply_to_status_id" : 365138712797003776,
  "created_at" : "2013-08-07 16:04:52 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365136911813189632",
  "geo" : { },
  "id_str" : "365138036989759488",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Thanks, but from their website it looks like it doesn't offer that option.",
  "id" : 365138036989759488,
  "in_reply_to_status_id" : 365136911813189632,
  "created_at" : "2013-08-07 15:51:06 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365136304456990721",
  "text" : "Any recommendations for the fastest tool for creating pairwise semi-global alignments of nucleotide sequences?",
  "id" : 365136304456990721,
  "created_at" : "2013-08-07 15:44:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365108481205874688",
  "text" : "\"I love parsing \u2013 please don\u2019t stop talking about it!\" - Just to get an idea what kind of people are working on Biopython.",
  "id" : 365108481205874688,
  "created_at" : "2013-08-07 13:53:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1751653073, 8.6278959556 ]
  },
  "id_str" : "365063104586973184",
  "text" : "\u00ABIch war relativ leicht bekleidet &amp; das hat die Ameise voll abgefuckt: \u2018Immer diese freiz\u00FCgigen jungen Damen!\u2019 Dann hat sie mich gebissen\u2026\u00BB",
  "id" : 365063104586973184,
  "created_at" : "2013-08-07 10:53:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1777144028, 8.6144238573 ]
  },
  "id_str" : "365057639337566208",
  "text" : "\u00ABF\u00FCr das was ich hier in Frankfurt Miete zahle kannst du in den neuen Bundesl\u00E4ndern ganze D\u00F6rfer kaufen!\u00BB",
  "id" : 365057639337566208,
  "created_at" : "2013-08-07 10:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1777017842, 8.6148610485 ]
  },
  "id_str" : "365055982474244097",
  "text" : "\u00ABA great disturbance in the Multiple Sequence Alignment.\u00BB \u2014 \u00ABAs if millions of compute nodes cried out in terror &amp; were suddenly silenced!\u00BB",
  "id" : 365055982474244097,
  "created_at" : "2013-08-07 10:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722891157, 8.6276542474 ]
  },
  "id_str" : "365026958582628352",
  "text" : "\u00ABWoran arbeitest du gerade?\u00BB \u2014 \u00ABIch bade im Blut meiner Feinde, \u00E4h, in den Flechten-Daten die gestern gekommen sind.\u00BB",
  "id" : 365026958582628352,
  "created_at" : "2013-08-07 08:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Stumpf",
      "screen_name" : "theosysbio",
      "indices" : [ 26, 37 ],
      "id_str" : "73870184",
      "id" : 73870184
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/theosysbio\/status\/365014460680794112\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/AUh8J1vMUB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRDKt9NCcAAcD7a.jpg",
      "id_str" : "365014460689182720",
      "id" : 365014460689182720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRDKt9NCcAAcD7a.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/AUh8J1vMUB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1659954302, 8.639211884 ]
  },
  "id_str" : "365018856382672897",
  "text" : "Hashes to Hashes &lt;3 RT @theosysbio: The Computer Programmers' Song Book. http:\/\/t.co\/AUh8J1vMUB",
  "id" : 365018856382672897,
  "created_at" : "2013-08-07 07:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135693022, 8.67893468 ]
  },
  "id_str" : "365012687450673152",
  "text" : "\u00ABGuten Tag, ich hab sie schon mal gegoogelt. Sollen wir das Paket morgen zu dieser Alternativadresse mit dieser Telefonnummer zustellen?\u00BB",
  "id" : 365012687450673152,
  "created_at" : "2013-08-07 07:33:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/QhiPtyvkaa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5Qvi9gjRwKk",
      "display_url" : "youtube.com\/watch?v=5Qvi9g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096069525, 8.2828951838 ]
  },
  "id_str" : "364862314425483265",
  "text" : "The people need to know the truth! \u00ABThere is no one named Edward Sharp in this band.\u00BB http:\/\/t.co\/QhiPtyvkaa",
  "id" : 364862314425483265,
  "created_at" : "2013-08-06 21:35:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364855896876138496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096508386, 8.2829786035 ]
  },
  "id_str" : "364856980738801665",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju nein, es ist die reine Lehre des kodifizierten Selbsthass!",
  "id" : 364856980738801665,
  "in_reply_to_status_id" : 364855896876138496,
  "created_at" : "2013-08-06 21:14:17 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 40, 48 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009623335, 8.282967107 ]
  },
  "id_str" : "364855793150992385",
  "text" : "\u00ABNudeln mit Kartoffelso\u00DFe. Wenn das der @moeffju w\u00FCsste.\u00BB",
  "id" : 364855793150992385,
  "created_at" : "2013-08-06 21:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097044202, 8.2830626272 ]
  },
  "id_str" : "364852307957002240",
  "text" : "\u00ABDu Vaterlandsverr\u00E4ter, ich schick dir die Feldj\u00E4ger auf den Hals!\u00BB \u2014 \u00ABFahnenflucht w\u00E4hrend meines Dienstes f\u00FCr Pasta-kistan\u2026\u00BB",
  "id" : 364852307957002240,
  "created_at" : "2013-08-06 20:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/B988OAEd1j",
      "expanded_url" : "http:\/\/instagram.com\/p\/crbG2jBwjK\/",
      "display_url" : "instagram.com\/p\/crbG2jBwjK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "364785607702093825",
  "text" : "\u00ABSchau mal, kleine Pferde am Horizont!\u00BB http:\/\/t.co\/B988OAEd1j",
  "id" : 364785607702093825,
  "created_at" : "2013-08-06 16:30:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675542, 8.2829942646 ]
  },
  "id_str" : "364784331610259456",
  "text" : "\u00ABIch liebe dich :wq\u00BB \u2014 \u00ABIch wei\u00DF schon, falsches Terminal. Du liebst deinen Editor sehr.\u00BB",
  "id" : 364784331610259456,
  "created_at" : "2013-08-06 16:25:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GaTGbjTyC9",
      "expanded_url" : "http:\/\/elisabethsheff.com\/2012\/12\/20\/failure-or-transition-redefining-the-end-of-polyamorous-relationships\/",
      "display_url" : "elisabethsheff.com\/2012\/12\/20\/fai\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0124292727, 8.2835846006 ]
  },
  "id_str" : "364782479204302848",
  "text" : "Failure or Transition: \u00ABpoly people lie, betray, and cheat each other like everyone else.\u00BB http:\/\/t.co\/GaTGbjTyC9",
  "id" : 364782479204302848,
  "created_at" : "2013-08-06 16:18:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/4tZdDfezJe",
      "expanded_url" : "http:\/\/instagram.com\/p\/crOVfsBwhT\/",
      "display_url" : "instagram.com\/p\/crOVfsBwhT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1735988061, 8.6295649714 ]
  },
  "id_str" : "364757772941795329",
  "text" : "Kurz vor \u00ABHoly shit, gro\u00DFkalibrige Hagelk\u00F6rner!\u00BB @ Goethe-Universit\u00E4t Frankfurt\/Main - Campus Riedberg http:\/\/t.co\/4tZdDfezJe",
  "id" : 364757772941795329,
  "created_at" : "2013-08-06 14:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarle Pahr",
      "screen_name" : "Jarlemag",
      "indices" : [ 0, 9 ],
      "id_str" : "45940338",
      "id" : 45940338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364750417239871489",
  "geo" : { },
  "id_str" : "364752009741611011",
  "in_reply_to_user_id" : 45940338,
  "text" : "@Jarlemag sure, no problem. :)",
  "id" : 364752009741611011,
  "in_reply_to_status_id" : 364750417239871489,
  "created_at" : "2013-08-06 14:17:10 +0000",
  "in_reply_to_screen_name" : "Jarlemag",
  "in_reply_to_user_id_str" : "45940338",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarle Pahr",
      "screen_name" : "Jarlemag",
      "indices" : [ 0, 9 ],
      "id_str" : "45940338",
      "id" : 45940338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/GaTGbjTyC9",
      "expanded_url" : "http:\/\/elisabethsheff.com\/2012\/12\/20\/failure-or-transition-redefining-the-end-of-polyamorous-relationships\/",
      "display_url" : "elisabethsheff.com\/2012\/12\/20\/fai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364738811042869248",
  "geo" : { },
  "id_str" : "364741463424241665",
  "in_reply_to_user_id" : 45940338,
  "text" : "@Jarlemag http:\/\/t.co\/GaTGbjTyC9 (fair warning: haven't read the whole thing yet, just stumbled upon the quote)",
  "id" : 364741463424241665,
  "in_reply_to_status_id" : 364738811042869248,
  "created_at" : "2013-08-06 13:35:16 +0000",
  "in_reply_to_screen_name" : "Jarlemag",
  "in_reply_to_user_id_str" : "45940338",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364737733001875456",
  "text" : "Making death a victory condition always struck me as odd. And only the people behind Planescape Torment pulled it off somewhat successfully.",
  "id" : 364737733001875456,
  "created_at" : "2013-08-06 13:20:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364736449897168898",
  "text" : "\u00ABSome polyamorous relationships last until one of the partners dies, and in that sense they meet the conventional definition of \u201Csuccess\u201D\u00BB",
  "id" : 364736449897168898,
  "created_at" : "2013-08-06 13:15:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723318827, 8.6276715528 ]
  },
  "id_str" : "364725451861663746",
  "text" : "\u00ABK\u00F6nnen wir sp\u00E4ter telefonieren? Mein Kollege macht gerade seinen obligaten Mittagsschlaf und ich w\u00FCrde ihn ungern dabei st\u00F6ren.\u00BB",
  "id" : 364725451861663746,
  "created_at" : "2013-08-06 12:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/mMKAoV1ad6",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Widdershins",
      "display_url" : "en.wikipedia.org\/wiki\/Widdershi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364719610509012994",
  "text" : "TIL: Widdershins http:\/\/t.co\/mMKAoV1ad6",
  "id" : 364719610509012994,
  "created_at" : "2013-08-06 12:08:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/cZac1UzVEz",
      "expanded_url" : "http:\/\/instagram.com\/p\/cq42ChBwpk\/",
      "display_url" : "instagram.com\/p\/cq42ChBwpk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "364710168107302912",
  "text" : "\u00ABOh, was ein niedlicher Hund!\u00BB http:\/\/t.co\/cZac1UzVEz",
  "id" : 364710168107302912,
  "created_at" : "2013-08-06 11:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francis Martin",
      "screen_name" : "fmartin1954",
      "indices" : [ 3, 15 ],
      "id_str" : "131574252",
      "id" : 131574252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hpiXL2QgVN",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/mec.12481\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364709173474627585",
  "text" : "RT @fmartin1954: Towards a unified paradigm for sequencebased identification of Fungi  K\u00F5ljalg  Molecular Ecology http:\/\/t.co\/hpiXL2QgVN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/hpiXL2QgVN",
        "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/mec.12481\/abstract",
        "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/me\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364653604323344384",
    "text" : "Towards a unified paradigm for sequencebased identification of Fungi  K\u00F5ljalg  Molecular Ecology http:\/\/t.co\/hpiXL2QgVN",
    "id" : 364653604323344384,
    "created_at" : "2013-08-06 07:46:08 +0000",
    "user" : {
      "name" : "Francis Martin",
      "screen_name" : "fmartin1954",
      "protected" : false,
      "id_str" : "131574252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924543907194638336\/uNV_Kuag_normal.jpg",
      "id" : 131574252,
      "verified" : false
    }
  },
  "id" : 364709173474627585,
  "created_at" : "2013-08-06 11:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ZqVCtfCwHp",
      "expanded_url" : "http:\/\/www.vanityfair.com\/online\/oscars\/2013\/07\/chewbacca-interview-harrison-ford\/jcr:content\/cn_page_metadata\/search.rendition.facebookThumbnail.s-chewbacca-wookie-comic-con-christopher-petrone.jpg",
      "display_url" : "vanityfair.com\/online\/oscars\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364703902542725122",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1790090942, 8.6246187512 ]
  },
  "id_str" : "364706294290059264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot noch besser als Patronengurt! http:\/\/t.co\/ZqVCtfCwHp",
  "id" : 364706294290059264,
  "in_reply_to_status_id" : 364703902542725122,
  "created_at" : "2013-08-06 11:15:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wasfehlt",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364703870301114368",
  "text" : "Ein Rechner der mir sagt ab wann die Bandbreite des DFN von einer S-Bahn-Fahrt Frankfurt-&gt;Mainz-&gt;Frankfurt geschlagen wird. #wasfehlt",
  "id" : 364703870301114368,
  "created_at" : "2013-08-06 11:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/nFtnjkeTFj",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0069889?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364698226709893120",
  "text" : "Better than porn: Exposure to Odors of Rivals Enhances Sexual Motivation in Male Giant Pandas http:\/\/t.co\/nFtnjkeTFj",
  "id" : 364698226709893120,
  "created_at" : "2013-08-06 10:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364697796755988481",
  "geo" : { },
  "id_str" : "364697997277274112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer na, I don't have too much interest in the topic right now (certainly not enough for a 14 week course).",
  "id" : 364697997277274112,
  "in_reply_to_status_id" : 364697796755988481,
  "created_at" : "2013-08-06 10:42:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 52, 65 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/9326eYkv71",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0070094?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364695925819576321",
  "text" : "The Power of Ground User in Recommender Systems \/cc @PhilippBayer http:\/\/t.co\/9326eYkv71",
  "id" : 364695925819576321,
  "created_at" : "2013-08-06 10:34:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/98O3Y3BIFB",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0070576?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364695071519543296",
  "text" : "Revisiting the Role of Individual Variability in Population Persistence and Stability http:\/\/t.co\/98O3Y3BIFB",
  "id" : 364695071519543296,
  "created_at" : "2013-08-06 10:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/H0M6RxtnBJ",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/HeLa#Chromosome_number",
      "display_url" : "en.wikipedia.org\/wiki\/HeLa#Chro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "364691313167306752",
  "geo" : { },
  "id_str" : "364693982527242240",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ja, alleine der Karyotype ist schon verr\u00FCckt: http:\/\/t.co\/H0M6RxtnBJ",
  "id" : 364693982527242240,
  "in_reply_to_status_id" : 364691313167306752,
  "created_at" : "2013-08-06 10:26:35 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364690646516244481",
  "geo" : { },
  "id_str" : "364691034120257538",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Gibt ja auch genug Leute die (imho nicht ganz zu unrecht) argumentieren das HeLa-Lines sowieso nicht mehr menschlich sind.",
  "id" : 364691034120257538,
  "in_reply_to_status_id" : 364690646516244481,
  "created_at" : "2013-08-06 10:14:52 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HwAiIwaMhw",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/ELHXnyxB_iw\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364688193318170624",
  "text" : "So there's a tooth fairy meets the Battle of Agincourt mashup meme? http:\/\/t.co\/HwAiIwaMhw",
  "id" : 364688193318170624,
  "created_at" : "2013-08-06 10:03:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364687170847514626",
  "geo" : { },
  "id_str" : "364687625988222976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, let's see whether this helps to keep everything running (by making everything even slower ;))",
  "id" : 364687625988222976,
  "in_reply_to_status_id" : 364687170847514626,
  "created_at" : "2013-08-06 10:01:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364685687439626243",
  "geo" : { },
  "id_str" : "364686062959865859",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer doh, I wonder whether Solr just hogs all memory and then crashes when there's no more left?",
  "id" : 364686062959865859,
  "in_reply_to_status_id" : 364685687439626243,
  "created_at" : "2013-08-06 09:55:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1787721219, 8.6246839883 ]
  },
  "id_str" : "364680938237607937",
  "text" : "\u00ABWei\u00DFt du auch welche Katze gekotzt hat?\u00BB \u2014 \u00ABMoment, vom Geruch her w\u00FCrde ich sagen Miezi.\u00BB",
  "id" : 364680938237607937,
  "created_at" : "2013-08-06 09:34:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364675944155324418",
  "text" : "*.doc tease",
  "id" : 364675944155324418,
  "created_at" : "2013-08-06 09:14:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1788646141, 8.6246470027 ]
  },
  "id_str" : "364670931613913088",
  "text" : "\u00ABUnd was ist dein Stuhlkreiszeichen?\u00BB",
  "id" : 364670931613913088,
  "created_at" : "2013-08-06 08:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364640545433337857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097195246, 8.2831632625 ]
  },
  "id_str" : "364643953523429376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay.",
  "id" : 364643953523429376,
  "in_reply_to_status_id" : 364640545433337857,
  "created_at" : "2013-08-06 07:07:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0122455534, 8.2838559535 ]
  },
  "id_str" : "364643901535043584",
  "text" : "\u00ABSchau dich doch mal an! Selber niedlich, du Hurensohn!\u00BB",
  "id" : 364643901535043584,
  "created_at" : "2013-08-06 07:07:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364512404450705408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096799204, 8.2830200253 ]
  },
  "id_str" : "364640111100571648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay, thanks for restarting solr. Shouldn\u2019t the robots stop the crawling?",
  "id" : 364640111100571648,
  "in_reply_to_status_id" : 364512404450705408,
  "created_at" : "2013-08-06 06:52:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009613797, 8.2829255529 ]
  },
  "id_str" : "364446917373489152",
  "text" : "Nothing Fried Left Behind",
  "id" : 364446917373489152,
  "created_at" : "2013-08-05 18:04:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jella",
      "screen_name" : "Nienor_",
      "indices" : [ 0, 8 ],
      "id_str" : "17461946",
      "id" : 17461946
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 9, 18 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364437672095670272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516218, 8.2829694137 ]
  },
  "id_str" : "364437847492665345",
  "in_reply_to_user_id" : 17461946,
  "text" : "@Nienor_ @viirus42 das ist mittlerweile vergeben.",
  "id" : 364437847492665345,
  "in_reply_to_status_id" : 364437672095670272,
  "created_at" : "2013-08-05 17:28:48 +0000",
  "in_reply_to_screen_name" : "Nienor_",
  "in_reply_to_user_id_str" : "17461946",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0051160995, 8.289735429 ]
  },
  "id_str" : "364428458530975744",
  "text" : "\u00ABNachdem ich sie hinter mir in der Schlange sah dachte ich kurz die Kassiererin h\u00E4tte tats\u00E4chlich \u2018an dieser Kasse nur Bart\u2019 gesagt.\u00BB",
  "id" : 364428458530975744,
  "created_at" : "2013-08-05 16:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096069525, 8.2828951838 ]
  },
  "id_str" : "364411193701969920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Das Katzenfutter ist gelandet. Sp\u00FCre meine Arme nicht mehr!",
  "id" : 364411193701969920,
  "created_at" : "2013-08-05 15:42:53 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364405106101325824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0087461297, 8.2829118124 ]
  },
  "id_str" : "364405781715623936",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me ich find es mehr aus der planned obsolescence-Sicht spannend. Das Ding ist von 99!",
  "id" : 364405781715623936,
  "in_reply_to_status_id" : 364405106101325824,
  "created_at" : "2013-08-05 15:21:23 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/kcS1mfDlMj",
      "expanded_url" : "http:\/\/instagram.com\/p\/cotmYkhwp-\/",
      "display_url" : "instagram.com\/p\/cotmYkhwp-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "364404947460169729",
  "text" : "Heute ist Retro-Tag in der S-Bahn. Erst einen Discman, jetzt einen Psion 5mx http:\/\/t.co\/kcS1mfDlMj",
  "id" : 364404947460169729,
  "created_at" : "2013-08-05 15:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/G6K7zvkANW",
      "expanded_url" : "http:\/\/bytesizebio.net\/index.php\/2013\/08\/03\/aphid-attacks-should-be-reported-through-the-fungusphone\/",
      "display_url" : "bytesizebio.net\/index.php\/2013\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1327557159, 8.6723805948 ]
  },
  "id_str" : "364391832953688064",
  "text" : "Yay! Plants communicating through fungal symbionts! http:\/\/t.co\/G6K7zvkANW",
  "id" : 364391832953688064,
  "created_at" : "2013-08-05 14:25:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722941807, 8.627645845 ]
  },
  "id_str" : "364327259915960320",
  "text" : "\u00ABseq. alignment methods [\u2026] have a long history of their own and can live in happy ignorance of the Chomsky hierarchy.\u00BB Sounds like Bob Ross",
  "id" : 364327259915960320,
  "created_at" : "2013-08-05 10:09:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/yITBUMSSS7",
      "expanded_url" : "http:\/\/instagram.com\/p\/coHNPbhwhi\/",
      "display_url" : "instagram.com\/p\/coHNPbhwhi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "364319785481273344",
  "text" : "I'm not slacking off, my Markov chains are getting trained! http:\/\/t.co\/yITBUMSSS7",
  "id" : 364319785481273344,
  "created_at" : "2013-08-05 09:39:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ej3P9tlPtZ",
      "expanded_url" : "https:\/\/pentabarf.junge-piraten.de\/fahrplan\/om13\/day_2013-08-24.de.html",
      "display_url" : "pentabarf.junge-piraten.de\/fahrplan\/om13\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096069525, 8.2828951838 ]
  },
  "id_str" : "364113214956511232",
  "text" : "Und da hat sich eine L\u00FCcke im #om13 Fahrplan am Samstag um 14:00 auch schon geschlossen! https:\/\/t.co\/ej3P9tlPtZ",
  "id" : 364113214956511232,
  "created_at" : "2013-08-04 19:58:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Wb9G88UmmT",
      "expanded_url" : "http:\/\/thememorypalace.us\/2013\/05\/guinea-pigs\/",
      "display_url" : "thememorypalace.us\/2013\/05\/guinea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009657, 8.28294 ]
  },
  "id_str" : "364057812998950914",
  "text" : "Guinea Pigs, about animals in space @ the memory palace &lt;3 http:\/\/t.co\/Wb9G88UmmT",
  "id" : 364057812998950914,
  "created_at" : "2013-08-04 16:18:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JlB21P3ZUf",
      "expanded_url" : "http:\/\/www.br.de\/radio\/bayern2\/sendungen\/radiofeature\/ard-radiofeature-zins-und-zockerei-ade-100.html",
      "display_url" : "br.de\/radio\/bayern2\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.000474, 8.301097 ]
  },
  "id_str" : "364044592200425473",
  "text" : "\u00ABBei Risiken und Nebenwirkungen: Tod\u00BB Kommerzielle IRBs &amp; outgesourcte Klinische Studien\u2026 http:\/\/t.co\/JlB21P3ZUf",
  "id" : 364044592200425473,
  "created_at" : "2013-08-04 15:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 3, 17 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/NLn06okMrv",
      "expanded_url" : "http:\/\/buff.ly\/1cz7ct2",
      "display_url" : "buff.ly\/1cz7ct2"
    } ]
  },
  "geo" : { },
  "id_str" : "363983582978916352",
  "text" : "RT @kai_arzheimer: If Book Acknowledgments Were Really Honest\u2026 | Daniel W. Drezner  http:\/\/t.co\/NLn06okMrv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/NLn06okMrv",
        "expanded_url" : "http:\/\/buff.ly\/1cz7ct2",
        "display_url" : "buff.ly\/1cz7ct2"
      } ]
    },
    "geo" : { },
    "id_str" : "363981425760296960",
    "text" : "If Book Acknowledgments Were Really Honest\u2026 | Daniel W. Drezner  http:\/\/t.co\/NLn06okMrv",
    "id" : 363981425760296960,
    "created_at" : "2013-08-04 11:15:09 +0000",
    "user" : {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "protected" : false,
      "id_str" : "16736320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74112233\/kai_1_normal.jpg",
      "id" : 16736320,
      "verified" : false
    }
  },
  "id" : 363983582978916352,
  "created_at" : "2013-08-04 11:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363703419938537472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096180197, 8.2829316706 ]
  },
  "id_str" : "363945551177322496",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon erh\u00F6he auf 95%",
  "id" : 363945551177322496,
  "in_reply_to_status_id" : 363703419938537472,
  "created_at" : "2013-08-04 08:52:35 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363931171735871488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0964906941, 8.6085961583 ]
  },
  "id_str" : "363932206882099200",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @Senficon wissenschaftliche Diskussionen mit Lippenstift auf Spiegel?",
  "id" : 363932206882099200,
  "in_reply_to_status_id" : 363931171735871488,
  "created_at" : "2013-08-04 07:59:34 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363929187981082624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1000043983, 8.6098858249 ]
  },
  "id_str" : "363930899785977856",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon k\u00F6nnen wir dann bitte ein Whiteboard \u00FCbers Bett h\u00E4ngen?",
  "id" : 363930899785977856,
  "in_reply_to_status_id" : 363929187981082624,
  "created_at" : "2013-08-04 07:54:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363927255845961728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1007535894, 8.6194192585 ]
  },
  "id_str" : "363929003931238400",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon actually I\u2019m more in it for the scientific discussions.",
  "id" : 363929003931238400,
  "in_reply_to_status_id" : 363927255845961728,
  "created_at" : "2013-08-04 07:46:50 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994365244, 8.6214906536 ]
  },
  "id_str" : "363925215421546497",
  "text" : "\u00ABEr hatte Angst vor dem Grumpy Old Man!\u00BB \u2014 \u00ABDas ausgerechnet du das sagst\u2026\u00BB \u2014 \u00ABNa, du siehst so alt aus. So alt werd ich nie werden!\u00BB",
  "id" : 363925215421546497,
  "created_at" : "2013-08-04 07:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rmadillo",
      "screen_name" : "healthstatsdude",
      "indices" : [ 3, 19 ],
      "id_str" : "1077116203",
      "id" : 1077116203
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/healthstatsdude\/status\/362962267433730049\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/OAjhxnvGlf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQmAQlmCAAMKDrc.jpg",
      "id_str" : "362962267437924355",
      "id" : 362962267437924355,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQmAQlmCAAMKDrc.jpg",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 628
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 628
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 628
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 628
      } ],
      "display_url" : "pic.twitter.com\/OAjhxnvGlf"
    } ],
    "hashtags" : [ {
      "text" : "overlyhonesyscience",
      "indices" : [ 53, 73 ]
    }, {
      "text" : "sciconfessions",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363821849953992705",
  "text" : "RT @healthstatsdude: Confessions of a former prof... #overlyhonesyscience #sciconfessions http:\/\/t.co\/OAjhxnvGlf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/healthstatsdude\/status\/362962267433730049\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/OAjhxnvGlf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQmAQlmCAAMKDrc.jpg",
        "id_str" : "362962267437924355",
        "id" : 362962267437924355,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQmAQlmCAAMKDrc.jpg",
        "sizes" : [ {
          "h" : 316,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/OAjhxnvGlf"
      } ],
      "hashtags" : [ {
        "text" : "overlyhonesyscience",
        "indices" : [ 32, 52 ]
      }, {
        "text" : "sciconfessions",
        "indices" : [ 53, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362962267433730049",
    "text" : "Confessions of a former prof... #overlyhonesyscience #sciconfessions http:\/\/t.co\/OAjhxnvGlf",
    "id" : 362962267433730049,
    "created_at" : "2013-08-01 15:45:22 +0000",
    "user" : {
      "name" : "Rmadillo",
      "screen_name" : "healthstatsdude",
      "protected" : false,
      "id_str" : "1077116203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468183905640525825\/jcdMWwrO_normal.png",
      "id" : 1077116203,
      "verified" : false
    }
  },
  "id" : 363821849953992705,
  "created_at" : "2013-08-04 00:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/aUuiCqGxJl",
      "expanded_url" : "http:\/\/disneyladiesfromlastnight.tumblr.com\/image\/56977541229",
      "display_url" : "disneyladiesfromlastnight.tumblr.com\/image\/56977541\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993725427, 8.6215295989 ]
  },
  "id_str" : "363820954860130306",
  "text" : "Oh god, yes! I\u2019m not alone! http:\/\/t.co\/aUuiCqGxJl",
  "id" : 363820954860130306,
  "created_at" : "2013-08-04 00:37:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363811756659208193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994839684, 8.6213412975 ]
  },
  "id_str" : "363812150277451778",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX in meinem Hirn bildet sich ein Mash-Up aus \u2018als die Tiere den Wald verlie\u00DFen\u2019 und Protomenschen die von den B\u00E4umen klettern!",
  "id" : 363812150277451778,
  "in_reply_to_status_id" : 363811756659208193,
  "created_at" : "2013-08-04 00:02:30 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 6, 14 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993257475, 8.6214094092 ]
  },
  "id_str" : "363809757401858049",
  "text" : "Onkel @insideX erz\u00E4hlt vom Krieg, als das Internet noch aus Holz war.",
  "id" : 363809757401858049,
  "created_at" : "2013-08-03 23:53:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hughes",
      "screen_name" : "ZombieAntGuy",
      "indices" : [ 3, 16 ],
      "id_str" : "946065337",
      "id" : 946065337
    }, {
      "name" : "Greenpeace",
      "screen_name" : "Greenpeace",
      "indices" : [ 35, 46 ],
      "id_str" : "3459051",
      "id" : 3459051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363809104445595648",
  "text" : "RT @ZombieAntGuy: I wanted to be a @Greenpeace scientist when I was a kid. Now their anti-science GMO stance sickens me. Let kids die. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greenpeace",
        "screen_name" : "Greenpeace",
        "indices" : [ 17, 28 ],
        "id_str" : "3459051",
        "id" : 3459051
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/9bki5AZvhw",
        "expanded_url" : "http:\/\/www.ottawacitizen.com\/opinion\/op-ed\/crops%20kill%20kids%20Opposing%20them%20does\/8738060\/story.html?utm_source=buffer&utm_campaign=Buffer&utm_content=bufferedc88&utm_medium=twitter",
        "display_url" : "ottawacitizen.com\/opinion\/op-ed\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363773840716865536",
    "text" : "I wanted to be a @Greenpeace scientist when I was a kid. Now their anti-science GMO stance sickens me. Let kids die. http:\/\/t.co\/9bki5AZvhw",
    "id" : 363773840716865536,
    "created_at" : "2013-08-03 21:30:16 +0000",
    "user" : {
      "name" : "David Hughes",
      "screen_name" : "ZombieAntGuy",
      "protected" : false,
      "id_str" : "946065337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456498883607003136\/4M6cfavo_normal.jpeg",
      "id" : 946065337,
      "verified" : false
    }
  },
  "id" : 363809104445595648,
  "created_at" : "2013-08-03 23:50:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0995740631, 8.621229974 ]
  },
  "id_str" : "363800507594186754",
  "text" : "\u00ABDer Mann spricht halt nicht unsere Sprache. Der ist ja nichtmal von diesem Planeten!\u00BB",
  "id" : 363800507594186754,
  "created_at" : "2013-08-03 23:16:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363799372477112321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0995205425, 8.6213180031 ]
  },
  "id_str" : "363799526576259072",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ic",
  "id" : 363799526576259072,
  "in_reply_to_status_id" : 363799372477112321,
  "created_at" : "2013-08-03 23:12:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363798297619996672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994706103, 8.62130834 ]
  },
  "id_str" : "363798709361852417",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon protected Account. Kein Kontext, keine Antwort.",
  "id" : 363798709361852417,
  "in_reply_to_status_id" : 363798297619996672,
  "created_at" : "2013-08-03 23:09:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994520406, 8.6213191454 ]
  },
  "id_str" : "363784518609944576",
  "text" : "\u00ABSo habe ich damals versucht der Filmindustrie zu schaden. Ich habe Password Swordfish runtergeladen, gel\u00F6scht, runtergeladen, gel\u00F6scht,\u2026\u00BB",
  "id" : 363784518609944576,
  "created_at" : "2013-08-03 22:12:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 119, 125 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993028814, 8.6213964543 ]
  },
  "id_str" : "363762006223880192",
  "text" : "\u00ABWir haben uns ja ewig nicht gesehen. Das ist 1 1\/2 Jahre her. Ich seh sonst immer nur Fotos auf Instagram von dir von @Lobot\u00BB",
  "id" : 363762006223880192,
  "created_at" : "2013-08-03 20:43:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/SM4tM6J1Ux",
      "expanded_url" : "http:\/\/instagram.com\/p\/ckHSJphwmz\/",
      "display_url" : "instagram.com\/p\/ckHSJphwmz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363756884572250112",
  "text" : "Ornithologen-Spanner-Reporter http:\/\/t.co\/SM4tM6J1Ux",
  "id" : 363756884572250112,
  "created_at" : "2013-08-03 20:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993526359, 8.6214458041 ]
  },
  "id_str" : "363754651511832576",
  "text" : "\u00ABInsekten haben mich lieb!\u00BB \u2014 \u00ABAber ich bin gar kein Insekt\u2026\u00BB",
  "id" : 363754651511832576,
  "created_at" : "2013-08-03 20:14:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.099185405, 8.6213750239 ]
  },
  "id_str" : "363752472319635456",
  "text" : "\u00AB\u2018Richtig s\u00FCchtig machen\u2019 ist wenn du daf\u00FCr morden wirst. Diese Kirschen machen richtig s\u00FCchtig.\u00BB \u2014 \u00ABIch gebe dir die eine ja schon zur\u00FCck\u2026\u00BB",
  "id" : 363752472319635456,
  "created_at" : "2013-08-03 20:05:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363744775083540480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0995945524, 8.6211675135 ]
  },
  "id_str" : "363745377708552192",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon deshalb der hohe Prior. ;)",
  "id" : 363745377708552192,
  "in_reply_to_status_id" : 363744775083540480,
  "created_at" : "2013-08-03 19:37:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363743203737878528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993891907, 8.6214028514 ]
  },
  "id_str" : "363743362920493056",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon warten wir darauf das ich neue Posteriors durchgebe. ;)",
  "id" : 363743362920493056,
  "in_reply_to_status_id" : 363743203737878528,
  "created_at" : "2013-08-03 19:29:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994765752, 8.621335365 ]
  },
  "id_str" : "363743184498597888",
  "text" : "\u00ABIch hab jetzt Mein Wahlkampf.\u00BB \u2014 \u00ABSeit 18:00 Uhr wird ausgez\u00E4hlt!\u00BB",
  "id" : 363743184498597888,
  "created_at" : "2013-08-03 19:28:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994736597, 8.6214179364 ]
  },
  "id_str" : "363730814170705920",
  "text" : "\u00ABIch hab keine Lust mehr zu grillen. Man reiche mir mein Twitterdevice! Was ist der Hashtag?\u00BB",
  "id" : 363730814170705920,
  "created_at" : "2013-08-03 18:39:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363703419938537472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0949679485, 8.6072677758 ]
  },
  "id_str" : "363703703788089344",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon die Dichtung unten links war aus der Fassung gesprungen. Hab die einfach mal wieder richtig eingesetzt. ;)",
  "id" : 363703703788089344,
  "in_reply_to_status_id" : 363703419938537472,
  "created_at" : "2013-08-03 16:51:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/wbQOf6whmQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/cjqRaihwhm\/",
      "display_url" : "instagram.com\/p\/cjqRaihwhm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363693302043783168",
  "text" : "\u00ABWas ein niedliches kleines Schild!\u00BB http:\/\/t.co\/wbQOf6whmQ",
  "id" : 363693302043783168,
  "created_at" : "2013-08-03 16:10:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 70, 79 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073559536, 8.2831345964 ]
  },
  "id_str" : "363691947963473920",
  "text" : "Mit ~70% Wahrscheinlichkeit den tropfenden Gefrierschrank gefixt. \/cc @Senficon",
  "id" : 363691947963473920,
  "created_at" : "2013-08-03 16:04:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "indices" : [ 3, 16 ],
      "id_str" : "22247075",
      "id" : 22247075
    }, {
      "name" : "Meg Howarth",
      "screen_name" : "howarthm",
      "indices" : [ 118, 127 ],
      "id_str" : "131573707",
      "id" : 131573707
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Blonde_M\/status\/363215095024742400\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2ohNBDQ5JP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQpmNF1CAAA6pLV.jpg",
      "id_str" : "363215095045685248",
      "id" : 363215095045685248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQpmNF1CAAA6pLV.jpg",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 482
      } ],
      "display_url" : "pic.twitter.com\/2ohNBDQ5JP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363674427290304512",
  "text" : "RT @amateursuman: How BBC's Libby Purves responded to abuse before Twitter was even born! https:\/\/t.co\/2ohNBDQ5JP via @howarthm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meg Howarth",
        "screen_name" : "howarthm",
        "indices" : [ 100, 109 ],
        "id_str" : "131573707",
        "id" : 131573707
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Blonde_M\/status\/363215095024742400\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/2ohNBDQ5JP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQpmNF1CAAA6pLV.jpg",
        "id_str" : "363215095045685248",
        "id" : 363215095045685248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQpmNF1CAAA6pLV.jpg",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 482
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 482
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 482
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 482
        } ],
        "display_url" : "pic.twitter.com\/2ohNBDQ5JP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "363609283843203072",
    "geo" : { },
    "id_str" : "363674199224614912",
    "in_reply_to_user_id" : 131573707,
    "text" : "How BBC's Libby Purves responded to abuse before Twitter was even born! https:\/\/t.co\/2ohNBDQ5JP via @howarthm",
    "id" : 363674199224614912,
    "in_reply_to_status_id" : 363609283843203072,
    "created_at" : "2013-08-03 14:54:20 +0000",
    "in_reply_to_screen_name" : "howarthm",
    "in_reply_to_user_id_str" : "131573707",
    "user" : {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "protected" : false,
      "id_str" : "22247075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000677237177\/8ff4e5616cfb26ff1381653e0ec8940a_normal.jpeg",
      "id" : 22247075,
      "verified" : false
    }
  },
  "id" : 363674427290304512,
  "created_at" : "2013-08-03 14:55:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363665295900028929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096634374, 8.2830137378 ]
  },
  "id_str" : "363665744778637314",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nachdem ich mich vom Schock erholt und meine Tr\u00E4nen getrocknet habe!",
  "id" : 363665744778637314,
  "in_reply_to_status_id" : 363665295900028929,
  "created_at" : "2013-08-03 14:20:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363663737762623488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0088628962, 8.2862057981 ]
  },
  "id_str" : "363664498797719552",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot als ob du schon dramatic gesehen h\u00E4ttest. Da stellst du dich ja immer tot.",
  "id" : 363664498797719552,
  "in_reply_to_status_id" : 363663737762623488,
  "created_at" : "2013-08-03 14:15:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "indices" : [ 3, 17 ],
      "id_str" : "316327930",
      "id" : 316327930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363658354805448704",
  "text" : "RT @Neuro_Skeptic: \"Communicating science to the public takes time away from research. So why would you do it? I offer six reasons...\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/61D9ocLfQd",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/23884922",
        "display_url" : "ncbi.nlm.nih.gov\/pubmed\/23884922"
      } ]
    },
    "geo" : { },
    "id_str" : "363447608418648064",
    "text" : "\"Communicating science to the public takes time away from research. So why would you do it? I offer six reasons...\" http:\/\/t.co\/61D9ocLfQd",
    "id" : 363447608418648064,
    "created_at" : "2013-08-02 23:53:57 +0000",
    "user" : {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "protected" : false,
      "id_str" : "316327930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703637604181393409\/iCflIKVK_normal.jpg",
      "id" : 316327930,
      "verified" : false
    }
  },
  "id" : 363658354805448704,
  "created_at" : "2013-08-03 13:51:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/L0qnw4vq6W",
      "expanded_url" : "http:\/\/instagram.com\/p\/cjWTRQBwi_\/",
      "display_url" : "instagram.com\/p\/cjWTRQBwi_\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0063495725, 8.2808076579 ]
  },
  "id_str" : "363649199537008641",
  "text" : "Wenn man schon alle Flugg\u00E4ste als Terroristen behandelt\u2026 @ Rheinstrand an der Reduit http:\/\/t.co\/L0qnw4vq6W",
  "id" : 363649199537008641,
  "created_at" : "2013-08-03 13:15:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Liebich",
      "screen_name" : "Dirk_Liebich",
      "indices" : [ 0, 13 ],
      "id_str" : "20760764",
      "id" : 20760764
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 114, 127 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361072236821626881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814057, 8.2830123786 ]
  },
  "id_str" : "363643000393441280",
  "in_reply_to_user_id" : 20760764,
  "text" : "@Dirk_Liebich @helgerausch sorry, hat wegen meines Urlaubs etwas gedauert. Unser Interesse ist auf jeden Fall da. @PhilippBayer",
  "id" : 363643000393441280,
  "in_reply_to_status_id" : 361072236821626881,
  "created_at" : "2013-08-03 12:50:22 +0000",
  "in_reply_to_screen_name" : "Dirk_Liebich",
  "in_reply_to_user_id_str" : "20760764",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/yBf1avtXRi",
      "expanded_url" : "http:\/\/instagram.com\/p\/ci89b0Bwt0\/",
      "display_url" : "instagram.com\/p\/ci89b0Bwt0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9965552296, 8.2757673392 ]
  },
  "id_str" : "363593428287766528",
  "text" : "Stadtrundfahrten @ Mainz Altstadt http:\/\/t.co\/yBf1avtXRi",
  "id" : 363593428287766528,
  "created_at" : "2013-08-03 09:33:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/wwWrA9jIuc",
      "expanded_url" : "https:\/\/www.facebook.com\/notes\/lars-fischer\/wacken\/10201445227159928",
      "display_url" : "facebook.com\/notes\/lars-fis\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9994680379, 8.2744865678 ]
  },
  "id_str" : "363592722264756224",
  "text" : "Wacken damals(tm): \u00ABEs ist ganz sch\u00F6n viel Schei\u00DFe gelaufen damals. In B\u00E4chen, quer \u00FCber die Zeltpl\u00E4tze.\u00BB https:\/\/t.co\/wwWrA9jIuc",
  "id" : 363592722264756224,
  "created_at" : "2013-08-03 09:30:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/8fhOCCpVAD",
      "expanded_url" : "http:\/\/instagram.com\/p\/ci7Ve0hwsn\/",
      "display_url" : "instagram.com\/p\/ci7Ve0hwsn\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.002284, 8.267522 ]
  },
  "id_str" : "363589783785701376",
  "text" : "Keyboard @ Mainzer Schl\u00FCssel-Laden http:\/\/t.co\/8fhOCCpVAD",
  "id" : 363589783785701376,
  "created_at" : "2013-08-03 09:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david",
      "screen_name" : "davidecarroll",
      "indices" : [ 0, 14 ],
      "id_str" : "50987947",
      "id" : 50987947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363566069702606848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814057, 8.2830123786 ]
  },
  "id_str" : "363566908487897088",
  "in_reply_to_user_id" : 50987947,
  "text" : "@davidecarroll thanks! :)",
  "id" : 363566908487897088,
  "in_reply_to_status_id" : 363566069702606848,
  "created_at" : "2013-08-03 07:48:00 +0000",
  "in_reply_to_screen_name" : "davidecarroll",
  "in_reply_to_user_id_str" : "50987947",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innenhofgespraeche",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096418243, 8.2830703072 ]
  },
  "id_str" : "363561164417941504",
  "text" : "\u00ABDaniel? Daniel! DANIEL!\u00BB \u2014 \u00ABAlso sowas hab ich ja noch nie geh\u00F6rt!\u00BB \u2014 \u00ABDas ist dein Name! Und jetzt komm gef\u00E4lligst!\u00BB #innenhofgespraeche",
  "id" : 363561164417941504,
  "created_at" : "2013-08-03 07:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas",
      "screen_name" : "necolas",
      "indices" : [ 3, 11 ],
      "id_str" : "24974216",
      "id" : 24974216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/BpJPJJVgNa",
      "expanded_url" : "http:\/\/i.imgur.com\/K9XK5So.gif",
      "display_url" : "i.imgur.com\/K9XK5So.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "363560516025057280",
  "text" : "RT @necolas: Refactoring http:\/\/t.co\/BpJPJJVgNa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/BpJPJJVgNa",
        "expanded_url" : "http:\/\/i.imgur.com\/K9XK5So.gif",
        "display_url" : "i.imgur.com\/K9XK5So.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "362745985010634754",
    "text" : "Refactoring http:\/\/t.co\/BpJPJJVgNa",
    "id" : 362745985010634754,
    "created_at" : "2013-08-01 01:25:56 +0000",
    "user" : {
      "name" : "Nicolas",
      "screen_name" : "necolas",
      "protected" : false,
      "id_str" : "24974216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921930545595957249\/dauinGb__normal.jpg",
      "id" : 24974216,
      "verified" : false
    }
  },
  "id" : 363560516025057280,
  "created_at" : "2013-08-03 07:22:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/OU5U30XIiU",
      "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2013\/08\/02\/gaming-the-system\/",
      "display_url" : "whyevolutionistrue.wordpress.com\/2013\/08\/02\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363446975435665408",
  "text" : "RT @DanGraur: Bear, dumpster, fun... http:\/\/t.co\/OU5U30XIiU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/OU5U30XIiU",
        "expanded_url" : "http:\/\/whyevolutionistrue.wordpress.com\/2013\/08\/02\/gaming-the-system\/",
        "display_url" : "whyevolutionistrue.wordpress.com\/2013\/08\/02\/gam\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 29.7049065214, -95.4094382376 ]
    },
    "id_str" : "363446645515489280",
    "text" : "Bear, dumpster, fun... http:\/\/t.co\/OU5U30XIiU",
    "id" : 363446645515489280,
    "created_at" : "2013-08-02 23:50:07 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 363446975435665408,
  "created_at" : "2013-08-02 23:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Jytc41RFM9",
      "expanded_url" : "http:\/\/gamasutra.com\/view\/feature\/195148\/dwarf_fortress_in_2013.php",
      "display_url" : "gamasutra.com\/view\/feature\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814057, 8.2830123786 ]
  },
  "id_str" : "363437576570810369",
  "text" : "Dwarf Fortress in 2013 http:\/\/t.co\/Jytc41RFM9",
  "id" : 363437576570810369,
  "created_at" : "2013-08-02 23:14:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/eEaTMeDW4b",
      "expanded_url" : "http:\/\/www.scilogs.com\/epilogue\/burn-your-textbooks\/",
      "display_url" : "scilogs.com\/epilogue\/burn-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363434403223330816",
  "text" : "RT @BoraZ: \u201CBurn Your Textbooks\u201D  http:\/\/t.co\/eEaTMeDW4b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/eEaTMeDW4b",
        "expanded_url" : "http:\/\/www.scilogs.com\/epilogue\/burn-your-textbooks\/",
        "display_url" : "scilogs.com\/epilogue\/burn-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363433645945520128",
    "text" : "\u201CBurn Your Textbooks\u201D  http:\/\/t.co\/eEaTMeDW4b",
    "id" : 363433645945520128,
    "created_at" : "2013-08-02 22:58:28 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 363434403223330816,
  "created_at" : "2013-08-02 23:01:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/khUt9yBEbI",
      "expanded_url" : "http:\/\/imgur.com\/a\/JQF6O",
      "display_url" : "imgur.com\/a\/JQF6O"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814057, 8.2830123786 ]
  },
  "id_str" : "363432854589423616",
  "text" : "Touching Strangers http:\/\/t.co\/khUt9yBEbI",
  "id" : 363432854589423616,
  "created_at" : "2013-08-02 22:55:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/aCDHaWNrAI",
      "expanded_url" : "http:\/\/i.imgur.com\/xq6QkH3.jpg",
      "display_url" : "i.imgur.com\/xq6QkH3.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814057, 8.2830123786 ]
  },
  "id_str" : "363432339474362368",
  "text" : "So this is what you\u2019re supposed to do with dirty laundry in hotels. http:\/\/t.co\/aCDHaWNrAI",
  "id" : 363432339474362368,
  "created_at" : "2013-08-02 22:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 68, 81 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/9S4R1BBPiX",
      "expanded_url" : "http:\/\/egtheory.wordpress.com\/2013\/07\/28\/hunger-games-themed-semi-iterated-prisoners-dilemma-tournament\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingMathematicsEnglish+%28Research+Blogging+-+English+-+Mathematics%29",
      "display_url" : "egtheory.wordpress.com\/2013\/07\/28\/hun\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097012475, 8.28305469 ]
  },
  "id_str" : "363422887958827008",
  "text" : "Hunger Games themed semi-iterated prisoner\u2019s dilemma\u00A0tournament \/cc @PhilippBayer http:\/\/t.co\/9S4R1BBPiX",
  "id" : 363422887958827008,
  "created_at" : "2013-08-02 22:15:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 89, 101 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/IoMWRyokBb",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/08\/genetic-adam-and-eve-may-have-walked-on-earth-at-the-same-time\/",
      "display_url" : "arstechnica.com\/science\/2013\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097012475, 8.28305469 ]
  },
  "id_str" : "363421503078928384",
  "text" : "Genetic Adam and Eve may have walked on Earth at the same time http:\/\/t.co\/IoMWRyokBb by @AkshatRathi",
  "id" : 363421503078928384,
  "created_at" : "2013-08-02 22:10:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/vhsU1Eb9OT",
      "expanded_url" : "http:\/\/instagram.com\/p\/chkjCZhwtl\/",
      "display_url" : "instagram.com\/p\/chkjCZhwtl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363398967432052736",
  "text" : "\u00ABDu kochst so gut!\u00BB http:\/\/t.co\/vhsU1Eb9OT",
  "id" : 363398967432052736,
  "created_at" : "2013-08-02 20:40:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363395061548986369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096915448, 8.2830165584 ]
  },
  "id_str" : "363396377340305408",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente au\u00DFer der\/die Partner\/in klaut die Decke!",
  "id" : 363396377340305408,
  "in_reply_to_status_id" : 363395061548986369,
  "created_at" : "2013-08-02 20:30:22 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363395040543911936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0093671268, 8.2831084321 ]
  },
  "id_str" : "363395512726061056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot passt schon, bin weder verdurstet noch verhungert und mit nur +15 (oder wie du es nennst: p\u00FCnktlich) heil angekommen.",
  "id" : 363395512726061056,
  "in_reply_to_status_id" : 363395040543911936,
  "created_at" : "2013-08-02 20:26:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363393704255430657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0074189874, 8.2831595214 ]
  },
  "id_str" : "363394663148826625",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente ja, yeah for spooning. L\u00F6ffelgr\u00F6\u00DFe egal.",
  "id" : 363394663148826625,
  "in_reply_to_status_id" : 363393704255430657,
  "created_at" : "2013-08-02 20:23:33 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363393951900123136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072032139, 8.2832056998 ]
  },
  "id_str" : "363394493309280256",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA passt zu meinem Bild und damit bleibe ich bei meiner Einsch\u00E4tzung. :)",
  "id" : 363394493309280256,
  "in_reply_to_status_id" : 363393951900123136,
  "created_at" : "2013-08-02 20:22:53 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363392188232634368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045723915, 8.3017361574 ]
  },
  "id_str" : "363393755497652224",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht ich hab da die Hoffnung ja aufgegeben.",
  "id" : 363393755497652224,
  "in_reply_to_status_id" : 363392188232634368,
  "created_at" : "2013-08-02 20:19:57 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363388956530208769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045723915, 8.3017361574 ]
  },
  "id_str" : "363393688837574656",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA was sagen deine Studenten denn \u00FCber dich?",
  "id" : 363393688837574656,
  "in_reply_to_status_id" : 363388956530208769,
  "created_at" : "2013-08-02 20:19:41 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363393079362846720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0103204109, 8.3170735746 ]
  },
  "id_str" : "363393320749649920",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente welchen davon meintest du?",
  "id" : 363393320749649920,
  "in_reply_to_status_id" : 363393079362846720,
  "created_at" : "2013-08-02 20:18:13 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/FzKrvq0Dqi",
      "expanded_url" : "http:\/\/glumm.wordpress.com\/2013\/07\/28\/its-all-about-finesse-zum-tode-von-jj-cale\/",
      "display_url" : "glumm.wordpress.com\/2013\/07\/28\/its\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.02446, 8.43855 ]
  },
  "id_str" : "363392445515440128",
  "text" : "\u00AB[\u2026] das Cale sterben k\u00F6nnte, damit habe ich nicht gerechnet. Das war nicht vorgesehen.\u00BB http:\/\/t.co\/FzKrvq0Dqi",
  "id" : 363392445515440128,
  "created_at" : "2013-08-02 20:14:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363390707395866625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.033134413, 8.4494606406 ]
  },
  "id_str" : "363391400303276032",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht komme jetzt erst dazu nachzulesen was so w\u00E4hrend meines Urlaubs passierte. Und dann gleich sowas als erste Nachricht!",
  "id" : 363391400303276032,
  "in_reply_to_status_id" : 363390707395866625,
  "created_at" : "2013-08-02 20:10:35 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Ed4cvwi4G6",
      "expanded_url" : "http:\/\/www.theguardian.com\/music\/2013\/jul\/28\/jj-cale",
      "display_url" : "theguardian.com\/music\/2013\/jul\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.099444, 8.534071 ]
  },
  "id_str" : "363390421352726529",
  "text" : "Totally missed it: JJ Cale died. The Guardian has a pretty nice obituary.  http:\/\/t.co\/Ed4cvwi4G6",
  "id" : 363390421352726529,
  "created_at" : "2013-08-02 20:06:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363388414714204160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1032393519, 8.5498221964 ]
  },
  "id_str" : "363388772924538880",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA ich hab den Eindruck das du die Art Lehrperson bist die ich w\u00E4hrend des Studiums immer sehr sympathisch fand.",
  "id" : 363388772924538880,
  "in_reply_to_status_id" : 363388414714204160,
  "created_at" : "2013-08-02 20:00:09 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363388011545108480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1032393519, 8.5498221964 ]
  },
  "id_str" : "363388327078002692",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA leider nein, manchmal f\u00E4nde ich das eigentlich ganz cool.",
  "id" : 363388327078002692,
  "in_reply_to_status_id" : 363388011545108480,
  "created_at" : "2013-08-02 19:58:23 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363387253789573120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1032393519, 8.5498221964 ]
  },
  "id_str" : "363387919928537091",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA solange du kein Student von mir bist ja ;)",
  "id" : 363387919928537091,
  "in_reply_to_status_id" : 363387253789573120,
  "created_at" : "2013-08-02 19:56:46 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/dAI6v2u1mJ",
      "expanded_url" : "http:\/\/bit.ly\/15khVGn",
      "display_url" : "bit.ly\/15khVGn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1027374898, 8.5536364287 ]
  },
  "id_str" : "363387636288724992",
  "text" : "\u00ABIss ruhig meine Banane und trink mein Wasser, noch mal werden die S-Bahnen bestimmt keinen \u00C4rger machen!\u00BB \u2026 http:\/\/t.co\/dAI6v2u1mJ",
  "id" : 363387636288724992,
  "created_at" : "2013-08-02 19:55:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363386429621436416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1030241731, 8.5585066976 ]
  },
  "id_str" : "363387156666286080",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA you say it like it\u2019s a bad thing!",
  "id" : 363387156666286080,
  "in_reply_to_status_id" : 363386429621436416,
  "created_at" : "2013-08-02 19:53:44 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363385121606746112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0997851909, 8.5982910569 ]
  },
  "id_str" : "363386298079248387",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA das f\u00FChrt ganz schnell zu \u201EHallo, hast du es gar nicht gemerkt? Ich habe was dummes gesagt!\u201C",
  "id" : 363386298079248387,
  "in_reply_to_status_id" : 363385121606746112,
  "created_at" : "2013-08-02 19:50:19 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363384280632033280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0953820028, 8.6268631728 ]
  },
  "id_str" : "363384960268251138",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA meinst du meine Lehrmethoden sind unangemessen? ;)",
  "id" : 363384960268251138,
  "in_reply_to_status_id" : 363384280632033280,
  "created_at" : "2013-08-02 19:45:00 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1337235021, 8.6591245537 ]
  },
  "id_str" : "363384154710609920",
  "text" : "\u00ABMetagenomik: Man hat 36 Mio. W\u00F6rter &amp; versucht f\u00FCr jedes rauszufinden wer der Autor war. Wenn du jetzt Gott sagst schlage ich dich wieder.\u00BB",
  "id" : 363384154710609920,
  "created_at" : "2013-08-02 19:41:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363346295101984768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1298566303, 8.7762559578 ]
  },
  "id_str" : "363361411994759168",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode &lt;3",
  "id" : 363361411994759168,
  "in_reply_to_status_id" : 363346295101984768,
  "created_at" : "2013-08-02 18:11:26 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1302535553, 8.7770921365 ]
  },
  "id_str" : "363361307472711681",
  "text" : "\u00ABAch, die sind ja schon \u00FCber 70. Da verliert man jede Scham\u00BB\u2014\u00ABOh Gott, wie bist du denn dann in dem Alter? Wirfst du dann nur noch mit Kot?\u00BB",
  "id" : 363361307472711681,
  "created_at" : "2013-08-02 18:11:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdierbands",
      "indices" : [ 10, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1022504344, 8.7483479817 ]
  },
  "id_str" : "363305977698725889",
  "text" : "MC HMMER3 #nerdierbands",
  "id" : 363305977698725889,
  "created_at" : "2013-08-02 14:31:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSH",
      "screen_name" : "CSHLaboratory",
      "indices" : [ 3, 17 ],
      "id_str" : "1235031679",
      "id" : 1235031679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363304157501222912",
  "text" : "RT @CSHLaboratory: We are happy to announce our new maternity leave policy for postdocs. Simply, if you even think about maternity, then yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363296834095419392",
    "text" : "We are happy to announce our new maternity leave policy for postdocs. Simply, if you even think about maternity, then you have to leave.",
    "id" : 363296834095419392,
    "created_at" : "2013-08-02 13:54:49 +0000",
    "user" : {
      "name" : "CSH",
      "screen_name" : "CSHLaboratory",
      "protected" : false,
      "id_str" : "1235031679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3331354215\/0dc1156eaf41055aef53e3dcd8e345ce_normal.png",
      "id" : 1235031679,
      "verified" : false
    }
  },
  "id" : 363304157501222912,
  "created_at" : "2013-08-02 14:23:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    }, {
      "name" : "John Horgan",
      "screen_name" : "Horganism",
      "indices" : [ 128, 138 ],
      "id_str" : "586841695",
      "id" : 586841695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/wvYY6X9DY7",
      "expanded_url" : "http:\/\/bit.ly\/18WgUXJ",
      "display_url" : "bit.ly\/18WgUXJ"
    } ]
  },
  "geo" : { },
  "id_str" : "363294960462069760",
  "text" : "RT @BoraZ: Survey of Earliest Human Settlements Undermines Claim that War Has Deep Evolutionary Roots http:\/\/t.co\/wvYY6X9DY7 by @Horganism \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Horgan",
        "screen_name" : "Horganism",
        "indices" : [ 117, 127 ],
        "id_str" : "586841695",
        "id" : 586841695
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SciAmBlogs",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/wvYY6X9DY7",
        "expanded_url" : "http:\/\/bit.ly\/18WgUXJ",
        "display_url" : "bit.ly\/18WgUXJ"
      } ]
    },
    "geo" : { },
    "id_str" : "363294356960477184",
    "text" : "Survey of Earliest Human Settlements Undermines Claim that War Has Deep Evolutionary Roots http:\/\/t.co\/wvYY6X9DY7 by @Horganism #SciAmBlogs",
    "id" : 363294356960477184,
    "created_at" : "2013-08-02 13:44:59 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 363294960462069760,
  "created_at" : "2013-08-02 13:47:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723002115, 8.6276447555 ]
  },
  "id_str" : "363290422350577664",
  "text" : "\u00ABDas Kuchenessen war ein Befehl!\u00BB",
  "id" : 363290422350577664,
  "created_at" : "2013-08-02 13:29:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/OkrNE4qm7T",
      "expanded_url" : "http:\/\/instagram.com\/p\/cgwvfpBwhE\/",
      "display_url" : "instagram.com\/p\/cgwvfpBwhE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1728922651, 8.6278766317 ]
  },
  "id_str" : "363285192070266880",
  "text" : "No wetlab? No air conditioning\u2026 @ Biologicum http:\/\/t.co\/OkrNE4qm7T",
  "id" : 363285192070266880,
  "created_at" : "2013-08-02 13:08:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citizenscience",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/UWY4hepQSw",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/08\/how-to-do-scientific-research-without-even-trying-much\/",
      "display_url" : "arstechnica.com\/science\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363275162134650881",
  "text" : "\"Most photographers, the authors lament, don't take the time to get a good shot of bugs' genitalia\" #citizenscience http:\/\/t.co\/UWY4hepQSw",
  "id" : 363275162134650881,
  "created_at" : "2013-08-02 12:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363266790190612481",
  "text" : "Hidden Markov Magic \\o\/",
  "id" : 363266790190612481,
  "created_at" : "2013-08-02 11:55:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6ADGYwJK3G",
      "expanded_url" : "http:\/\/synapticscoop.com\/2013\/08\/01\/surprising-brain-scan-of-individual-living-with-walking-corpse-syndrome\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingPsychologyEnglish+%28Research+Blogging+-+English+-+Psychology%29",
      "display_url" : "synapticscoop.com\/2013\/08\/01\/sur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363260979968086016",
  "text" : "Walking Corpse Syndrome: \"His brain\u2019s metabolism was so low that it was reminiscent of a brain under anaesthesia\" http:\/\/t.co\/6ADGYwJK3G",
  "id" : 363260979968086016,
  "created_at" : "2013-08-02 11:32:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/YYjEQERSR8",
      "expanded_url" : "http:\/\/instagram.com\/p\/cgYFFthwse\/",
      "display_url" : "instagram.com\/p\/cgYFFthwse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363230784150589440",
  "text" : "Saint Trofee http:\/\/t.co\/YYjEQERSR8",
  "id" : 363230784150589440,
  "created_at" : "2013-08-02 09:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/y8sBKUsL1w",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/57064664194\/when-my-favorite-song-comes-on-during-data-processing",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/570646641\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363224324255125504",
  "text" : "A pretty accurate depiction of what happens in our offices! http:\/\/t.co\/y8sBKUsL1w",
  "id" : 363224324255125504,
  "created_at" : "2013-08-02 09:06:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.177614851, 8.6230433811 ]
  },
  "id_str" : "363212362691936256",
  "text" : "Irgendwann lerne ich auch noch das man 30+ GB Dateien besser nicht im Browser runterl\u00E4dt.",
  "id" : 363212362691936256,
  "created_at" : "2013-08-02 08:19:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/363199505371365376\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/KRTc3vqbJo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQpYBpzCAAIInui.jpg",
      "id_str" : "363199505379753986",
      "id" : 363199505379753986,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQpYBpzCAAIInui.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1135
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1135
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1135
      } ],
      "display_url" : "pic.twitter.com\/KRTc3vqbJo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727259986, 8.627539493 ]
  },
  "id_str" : "363199505371365376",
  "text" : "I really hope one of the population geneticists is driving this car. http:\/\/t.co\/KRTc3vqbJo",
  "id" : 363199505371365376,
  "created_at" : "2013-08-02 07:28:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.169245624, 8.6228413135 ]
  },
  "id_str" : "363197282612965376",
  "text" : "w00tstrapping",
  "id" : 363197282612965376,
  "created_at" : "2013-08-02 07:19:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363190730614775808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1164374459, 8.681593491 ]
  },
  "id_str" : "363192750961086464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and put it on a pike in front of my office to make a point?",
  "id" : 363192750961086464,
  "in_reply_to_status_id" : 363190730614775808,
  "created_at" : "2013-08-02 07:01:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363190305295581185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1102419901, 8.6678083459 ]
  },
  "id_str" : "363190595361050624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer made me want to curl into fetal position and start crying.",
  "id" : 363190595361050624,
  "in_reply_to_status_id" : 363190305295581185,
  "created_at" : "2013-08-02 06:52:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363188386330189824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.109486299, 8.6589692227 ]
  },
  "id_str" : "363190139373514752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just yesterday a student said \u2018ah, i will just write my own file format for that output\u2019!",
  "id" : 363190139373514752,
  "in_reply_to_status_id" : 363188386330189824,
  "created_at" : "2013-08-02 06:50:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363188996761210880",
  "text" : "RT @PhilippBayer: When Agent Mulder said \"trust no one\" he actually meant implementations of bioinformatics file standards",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363188386330189824",
    "text" : "When Agent Mulder said \"trust no one\" he actually meant implementations of bioinformatics file standards",
    "id" : 363188386330189824,
    "created_at" : "2013-08-02 06:43:53 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 363188996761210880,
  "created_at" : "2013-08-02 06:46:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.103065176, 8.5632050783 ]
  },
  "id_str" : "363187890840666112",
  "text" : "Reading books published prior to finishing the human genome project is always fun: \u2018the HGP will give us raw sequences of 70-100k genes\u2019!",
  "id" : 363187890840666112,
  "created_at" : "2013-08-02 06:41:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097012475, 8.28305469 ]
  },
  "id_str" : "363069572666368000",
  "text" : "\u00ABWir k\u00F6nnten Hunde-Superhelden werden.\u00BB \u2013 \u00ABNeighbourwoof-watch!\u00BB",
  "id" : 363069572666368000,
  "created_at" : "2013-08-01 22:51:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097012475, 8.28305469 ]
  },
  "id_str" : "363060712702476289",
  "text" : "Im Pentabarf einen Slug f\u00FCr die #om13 vergeben: niedlichekatzen",
  "id" : 363060712702476289,
  "created_at" : "2013-08-01 22:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/mi5FPaqNNM",
      "expanded_url" : "http:\/\/instagram.com\/p\/ce2MFdBwjH\/",
      "display_url" : "instagram.com\/p\/ce2MFdBwjH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363015483756675072",
  "text" : "Oberlicht http:\/\/t.co\/mi5FPaqNNM",
  "id" : 363015483756675072,
  "created_at" : "2013-08-01 19:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ZWFDWBRBhD",
      "expanded_url" : "http:\/\/instagram.com\/p\/ce0HhsBwvn\/",
      "display_url" : "instagram.com\/p\/ce0HhsBwvn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "363011026612420608",
  "text" : "Ein weiter Weg hinab zum Strand http:\/\/t.co\/ZWFDWBRBhD",
  "id" : 363011026612420608,
  "created_at" : "2013-08-01 18:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096190522, 8.2829124103 ]
  },
  "id_str" : "362998958693421060",
  "text" : "TIL: Elsevier has a \u2018universal access\u2019 branch\/initiative. That\u2019s hilarious!",
  "id" : 362998958693421060,
  "created_at" : "2013-08-01 18:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/6imwAv1sLu",
      "expanded_url" : "http:\/\/instagram.com\/p\/ces0-tBwi2\/",
      "display_url" : "instagram.com\/p\/ces0-tBwi2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362995053452460032",
  "text" : "\u00ABAls ich auf dem Klo war musste ich an dich denken und hab dir was mitgebracht!\u00BB http:\/\/t.co\/6imwAv1sLu",
  "id" : 362995053452460032,
  "created_at" : "2013-08-01 17:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06565403, 8.61149234 ]
  },
  "id_str" : "362977369105391616",
  "text" : "Ach S-Bahn: Aus unbekannten Gr\u00FCnden verz\u00F6gert sich ihr Verkehr.",
  "id" : 362977369105391616,
  "created_at" : "2013-08-01 16:45:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362954223316508672",
  "text" : "\"Liest du schon wieder heimlich stats.stackexchange?!\"",
  "id" : 362954223316508672,
  "created_at" : "2013-08-01 15:13:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 58, 68 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/E4NJT5QY1c",
      "expanded_url" : "http:\/\/deepseanews.com\/2013\/08\/the-60-foot-long-jet-powered-animal-youve-probably-never-heard-of\/",
      "display_url" : "deepseanews.com\/2013\/08\/the-60\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1777974303, 8.6145484192 ]
  },
  "id_str" : "362937242760658944",
  "text" : "\u00ABsuck &amp; blow, are expert territory for these guys\u00BB MT @edyong209: The 60 ft jet powered animal you\u2019ve never heard of http:\/\/t.co\/E4NJT5QY1c",
  "id" : 362937242760658944,
  "created_at" : "2013-08-01 14:05:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723056373, 8.6276431967 ]
  },
  "id_str" : "362934469759475715",
  "text" : "\u00ABWe promise to take on no new grand projects, at least not immediately.\u00BB",
  "id" : 362934469759475715,
  "created_at" : "2013-08-01 13:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.175700827, 8.6196698354 ]
  },
  "id_str" : "362931030723805185",
  "text" : "\u00ABSorry, aber entgegen deiner Erwartung geht es bei Probabilistic Modeling nicht um die Wahrscheinlichkeit das du Model wirst\u2026\u00BB",
  "id" : 362931030723805185,
  "created_at" : "2013-08-01 13:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722952193, 8.6276508366 ]
  },
  "id_str" : "362928594877558784",
  "text" : "\u00ABBetet den neuen G\u00F6tzen an!\u00BB \u2014 \u00ABAh, der Elektrogrill ist angekommen?\u00BB",
  "id" : 362928594877558784,
  "created_at" : "2013-08-01 13:31:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/1UUuSbTVkk",
      "expanded_url" : "http:\/\/instagram.com\/p\/ceOeTShwip\/",
      "display_url" : "instagram.com\/p\/ceOeTShwip\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362928270645276673",
  "text" : "Beware, Ninja Turtles ahead. http:\/\/t.co\/1UUuSbTVkk",
  "id" : 362928270645276673,
  "created_at" : "2013-08-01 13:30:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722884456, 8.62765174 ]
  },
  "id_str" : "362927348590460928",
  "text" : "Not-so-Hidden Markov Fanboys",
  "id" : 362927348590460928,
  "created_at" : "2013-08-01 13:26:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172348719, 8.6275979456 ]
  },
  "id_str" : "362882626371067905",
  "text" : "\u00ABArbeitest du an deiner Thesis?\u00BB\u2014\u00ABJa: \u2018Galileo Mystery sagt die Platzierung dieser Organismen im Phylogenetic Tree ist ein Mysterium\u2019, ok?\u00BB",
  "id" : 362882626371067905,
  "created_at" : "2013-08-01 10:28:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1774602795, 8.6152874072 ]
  },
  "id_str" : "362880253531664386",
  "text" : "\u00ABJa, ich br\u00E4uchte auch noch einen Stuhl. Aber gerade habe ich einen Hund!\u00BB",
  "id" : 362880253531664386,
  "created_at" : "2013-08-01 10:19:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yJgd10dWXk",
      "expanded_url" : "http:\/\/noahpinionblog.blogspot.co.uk\/2013\/07\/what-is-payoff-structure-of-gold.html",
      "display_url" : "noahpinionblog.blogspot.co.uk\/2013\/07\/what-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362869492398833668",
  "text" : "'the entire world of modern fantasy role-playing is a subtle joke on gold's unsuitability as a medium of exchange.' http:\/\/t.co\/yJgd10dWXk",
  "id" : 362869492398833668,
  "created_at" : "2013-08-01 09:36:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/FPnpguvUbo",
      "expanded_url" : "http:\/\/instagram.com\/p\/cdyW-phwn8\/",
      "display_url" : "instagram.com\/p\/cdyW-phwn8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362866455647240192",
  "text" : "F\u00E4hrten lesen f\u00FCr Anf\u00E4nger http:\/\/t.co\/FPnpguvUbo",
  "id" : 362866455647240192,
  "created_at" : "2013-08-01 09:24:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362864649810616320",
  "text" : "RT @PhilippBayer: How comes there's nothing on pubmed about vim vs. emacs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362864527357919232",
    "text" : "How comes there's nothing on pubmed about vim vs. emacs",
    "id" : 362864527357919232,
    "created_at" : "2013-08-01 09:16:59 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 362864649810616320,
  "created_at" : "2013-08-01 09:17:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362839209628798976",
  "geo" : { },
  "id_str" : "362840515550523392",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju ich mache ein lautes \"Awww!\" in (angeblich) nur den 3 F\u00E4llen, in dem Fall war es ein Gel\u00E4ndewagen.",
  "id" : 362840515550523392,
  "in_reply_to_status_id" : 362839209628798976,
  "created_at" : "2013-08-01 07:41:34 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722944796, 8.6276505345 ]
  },
  "id_str" : "362836700294164481",
  "text" : "Eine 3-st\u00FCndige Brandschutzunterweisung an der auch die Bioinformatiker teilnehmen m\u00FCssen: \u2018Was tun wenn die GPU Feuer f\u00E4ngt\u2019?",
  "id" : 362836700294164481,
  "created_at" : "2013-08-01 07:26:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362833480515727361",
  "text" : "Aus dem Urlaub kommen und auf dem Schreibtisch liegt das Memo das man jetzt mehr Geld &amp; mehr Urlaubstage bekommt. \\o\/",
  "id" : 362833480515727361,
  "created_at" : "2013-08-01 07:13:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 95, 103 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0944579142, 8.606887987 ]
  },
  "id_str" : "362819034732969984",
  "text" : "\u00ABAwwww!\u00BB \u2014 \u00ABWenn du so niedliche Ger\u00E4usche machst: Hast du einen Hund, einen Gel\u00E4ndewagen oder @moeffju gesehen?\u00BB",
  "id" : 362819034732969984,
  "created_at" : "2013-08-01 06:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/1pM8v7QmSp",
      "expanded_url" : "http:\/\/instagram.com\/p\/cdY_Kwhwm1\/",
      "display_url" : "instagram.com\/p\/cdY_Kwhwm1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362810604546834432",
  "text" : "Ein &lt;3 f\u00FCr Hunde http:\/\/t.co\/1pM8v7QmSp",
  "id" : 362810604546834432,
  "created_at" : "2013-08-01 05:42:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]