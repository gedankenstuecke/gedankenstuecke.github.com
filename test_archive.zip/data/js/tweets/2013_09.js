Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009617433, 8.2830408868 ]
  },
  "id_str" : "384798403982798848",
  "text" : "\u00ABHast du das Problem in den Griff bekommen?\u00BB \u2014 \u00ABJa, wir nutzen jetzt ASCII-Emoticons.\u00BB \u2014 \u00ABWie die Tiere!\u00BB",
  "id" : 384798403982798848,
  "created_at" : "2013-09-30 21:54:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 81, 90 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/V9hcXsOqER",
      "expanded_url" : "http:\/\/m.theatlantic.com\/business\/archive\/2013\/01\/everything-you-need-to-know-about-the-crazy-plan-to-save-the-economy-with-a-trillion-dollar-coin\/266839\/",
      "display_url" : "m.theatlantic.com\/business\/archi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009661, 8.282965 ]
  },
  "id_str" : "384795423980154880",
  "text" : "\u00ABThe only thing we have to fear is fear of the trillion-dollar coin itself.\u00BB \/HT @senficon  http:\/\/t.co\/V9hcXsOqER",
  "id" : 384795423980154880,
  "created_at" : "2013-09-30 21:42:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/wAiVct3v6s",
      "expanded_url" : "http:\/\/instagram.com\/p\/e5kfKthwnE\/",
      "display_url" : "instagram.com\/p\/e5kfKthwnE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0179048827, 8.2572119565 ]
  },
  "id_str" : "384791380079673345",
  "text" : "Trollhafen @ Nordmole http:\/\/t.co\/wAiVct3v6s",
  "id" : 384791380079673345,
  "created_at" : "2013-09-30 21:26:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/m9NILJf02X",
      "expanded_url" : "http:\/\/instagram.com\/p\/e5jG9pBwlI\/",
      "display_url" : "instagram.com\/p\/e5jG9pBwlI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0142358056, 8.2625658538 ]
  },
  "id_str" : "384788253603540992",
  "text" : "Nordmole @ Zollhafen http:\/\/t.co\/m9NILJf02X",
  "id" : 384788253603540992,
  "created_at" : "2013-09-30 21:14:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/MMl4fYOwdh",
      "expanded_url" : "http:\/\/instagram.com\/p\/e5h2q8Bwjk\/",
      "display_url" : "instagram.com\/p\/e5h2q8Bwjk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "384785077034819584",
  "text" : "Fly http:\/\/t.co\/MMl4fYOwdh",
  "id" : 384785077034819584,
  "created_at" : "2013-09-30 21:01:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098031472, 8.2821538171 ]
  },
  "id_str" : "384753522769952768",
  "text" : "\u00ABHast du einen Bugreport geschrieben? Ihr k\u00F6nnt unm\u00F6glich die einzigen sein deren Beziehung fast an verschluckten Emoticons zerbrochen ist!\u00BB",
  "id" : 384753522769952768,
  "created_at" : "2013-09-30 18:56:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "louderthanhell",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9919787464, 8.4137905531 ]
  },
  "id_str" : "384731527156092928",
  "text" : "\u00ABTo me, heavy metal is like pornography. I couldn\u2019t tell you what it is, but when I see it, I know it.\u00BB \u2014 Leslie West #louderthanhell",
  "id" : 384731527156092928,
  "created_at" : "2013-09-30 17:28:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zrKaXTIM5d",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/abs\/10.1080\/19419899.2010.537674",
      "display_url" : "tandfonline.com\/doi\/abs\/10.108\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722894954, 8.6276546034 ]
  },
  "id_str" : "384584300215406592",
  "text" : "\u00AB\u2018Perversity\u2019 then becomes another luxury more readily available to those who are already members of dominant groups\u00BB http:\/\/t.co\/zrKaXTIM5d",
  "id" : 384584300215406592,
  "created_at" : "2013-09-30 07:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Chapman AO",
      "screen_name" : "SimonChapman6",
      "indices" : [ 3, 17 ],
      "id_str" : "88387950",
      "id" : 88387950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/QW7rdKJtrr",
      "expanded_url" : "http:\/\/blogs.bmj.com\/bmj\/2013\/09\/27\/simon-chapman-publishing-horror-stories-time-to-euthanase-paper-based-journals\/",
      "display_url" : "blogs.bmj.com\/bmj\/2013\/09\/27\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383741587987378176",
  "text" : "RT @SimonChapman6: Researchers, can you trump my saga here for the worst publishing delay of my career? http:\/\/t.co\/QW7rdKJtrr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/QW7rdKJtrr",
        "expanded_url" : "http:\/\/blogs.bmj.com\/bmj\/2013\/09\/27\/simon-chapman-publishing-horror-stories-time-to-euthanase-paper-based-journals\/",
        "display_url" : "blogs.bmj.com\/bmj\/2013\/09\/27\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383693449133703168",
    "text" : "Researchers, can you trump my saga here for the worst publishing delay of my career? http:\/\/t.co\/QW7rdKJtrr",
    "id" : 383693449133703168,
    "created_at" : "2013-09-27 20:43:41 +0000",
    "user" : {
      "name" : "Simon Chapman AO",
      "screen_name" : "SimonChapman6",
      "protected" : false,
      "id_str" : "88387950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721142018240421888\/azchN57X_normal.jpg",
      "id" : 88387950,
      "verified" : false
    }
  },
  "id" : 383741587987378176,
  "created_at" : "2013-09-27 23:54:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096704497, 8.2830727346 ]
  },
  "id_str" : "383738578876260352",
  "text" : "\u00ABWir k\u00F6nnen auch ohne Emoticons eine gl\u00FCckliche Beziehung f\u00FChren\u00BB\u2014\u00ABAls ob: \u2018Er hat mir keinen Gute-Nacht-Kuss gesendet &amp; liebt mich nicht\u2019\u2026\u00BB",
  "id" : 383738578876260352,
  "created_at" : "2013-09-27 23:43:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/ihGgXA7CdK",
      "expanded_url" : "http:\/\/littleblueship.com\/cabinet_of_saints\/cabinetsaints\/fevronia\/beard_drivers.jpeg",
      "display_url" : "littleblueship.com\/cabinet_of_sai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383591175305064448",
  "text" : "Mad ride!  http:\/\/t.co\/ihGgXA7CdK",
  "id" : 383591175305064448,
  "created_at" : "2013-09-27 13:57:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 11, 18 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "\u03BB",
      "screen_name" : "Lambda_",
      "indices" : [ 19, 27 ],
      "id_str" : "21659638",
      "id" : 21659638
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 28, 37 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tokei",
      "screen_name" : "tokei_",
      "indices" : [ 38, 45 ],
      "id_str" : "94819485",
      "id" : 94819485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383537414431440896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0946550425, 8.7521244189 ]
  },
  "id_str" : "383558962261807104",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ @TnaKng @Lambda_ @Senficon @tokei_ 10\/10 gerne wieder.",
  "id" : 383558962261807104,
  "in_reply_to_status_id" : 383537414431440896,
  "created_at" : "2013-09-27 11:49:17 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0947419003, 8.7520559825 ]
  },
  "id_str" : "383558828207640576",
  "text" : "\u00ABEntschuldige, ich wurde so erzogen: \u00DCber Emoticons spricht man nicht.\u00BB",
  "id" : 383558828207640576,
  "created_at" : "2013-09-27 11:48:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0971032121, 8.6364210025 ]
  },
  "id_str" : "383528365413892096",
  "text" : "\u00ABWhile drug use rates are pretty similar across classes, addiction\u2014like most other illnesses\u2014is not an equal-opportunity disorder.\u00BB",
  "id" : 383528365413892096,
  "created_at" : "2013-09-27 09:47:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068536681, 8.2825644594 ]
  },
  "id_str" : "383520417354645504",
  "text" : "\u00ABIch hatte noch nie Sex mit Gem\u00FCse.\u00BB \u2014 \u00ABDefiniere Gem\u00FCse.\u00BB \u2014 \u00ABK\u00FCrbisse z.B.\u00BB \u2014 \u00ABOkay, dann muss ich wohl doch trinken.\u00BB",
  "id" : 383520417354645504,
  "created_at" : "2013-09-27 09:16:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095341017, 8.2831006301 ]
  },
  "id_str" : "383514054293475328",
  "text" : "\u00ABWo sind die restlichen Vomex?\u00BB \u2014 \u00ABIch glaube noch in Bastians Labcoat.\u00BB",
  "id" : 383514054293475328,
  "created_at" : "2013-09-27 08:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    }, {
      "name" : "Quantenwelt",
      "screen_name" : "quantenwelt",
      "indices" : [ 10, 22 ],
      "id_str" : "38418484",
      "id" : 38418484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383509044297601024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0090048959, 8.2850716543 ]
  },
  "id_str" : "383509326914420737",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr @quantenwelt die Katze ist zwar klug. Aber was f\u00FCr eine w\u00E4ssrige L\u00F6sung ohne Wirkstoff ich ihr in den Mund spritze checkt sie nich",
  "id" : 383509326914420737,
  "in_reply_to_status_id" : 383509044297601024,
  "created_at" : "2013-09-27 08:32:03 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0076102527, 8.2913407313 ]
  },
  "id_str" : "383508560254349312",
  "text" : "\u00ABDanke, aber nein. Wir wissen das Hom\u00F6opathie nicht funktioniert.\u00BB \u2014 \u00ABAber der Placebo-Effekt!\u00BB \u2014 \u00ABDen kann ich selbst f\u00FCr 0 \u20AC herstellen\u2026\u00BB",
  "id" : 383508560254349312,
  "created_at" : "2013-09-27 08:29:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/rgoNvf2ItZ",
      "expanded_url" : "http:\/\/i.imgur.com\/subYWOv.jpg",
      "display_url" : "i.imgur.com\/subYWOv.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008829, 8.292527 ]
  },
  "id_str" : "383501039816957953",
  "text" : "Well played, Dewey Decimal System http:\/\/t.co\/rgoNvf2ItZ",
  "id" : 383501039816957953,
  "created_at" : "2013-09-27 07:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089128919, 8.292628331 ]
  },
  "id_str" : "383499872177250304",
  "text" : "\u00ABIst die Katze b\u00F6se?\u00BB \u2014 \u00ABNein, schwarz. Und deshalb nicht so gut zu sehen in der dunklen Box\u2026\u00BB",
  "id" : 383499872177250304,
  "created_at" : "2013-09-27 07:54:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096277846, 8.2828954607 ]
  },
  "id_str" : "383488612962422784",
  "text" : "\u00ABWie hast du die Sp\u00FClmaschine denn das letzte mal repariert als sie das gemacht hat?\u00BB\u2014\u00ABGar nicht, ich habe gewartet bis es von selbst ging!\u00BB",
  "id" : 383488612962422784,
  "created_at" : "2013-09-27 07:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    }, {
      "name" : "xpac",
      "screen_name" : "xpac",
      "indices" : [ 13, 18 ],
      "id_str" : "14326815",
      "id" : 14326815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383484074830364672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097005657, 8.2831624571 ]
  },
  "id_str" : "383487765092257792",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 @xpac das stimmt aber nur wenn die RBs &amp; REs ausnahmsweise mal fahren statt zu stehen. ;)",
  "id" : 383487765092257792,
  "in_reply_to_status_id" : 383484074830364672,
  "created_at" : "2013-09-27 07:06:22 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Sos7VD51UL",
      "expanded_url" : "http:\/\/www.theverge.com\/2013\/9\/24\/4698382\/second-lifes-strange-second-life",
      "display_url" : "theverge.com\/2013\/9\/24\/4698\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383232605115523072",
  "text" : "Second Life's strange second life http:\/\/t.co\/Sos7VD51UL",
  "id" : 383232605115523072,
  "created_at" : "2013-09-26 14:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383216369736491008",
  "text" : "\u00ABSag noch mal 'Stinkmorchel', das klingt so lustig in deiner ostdeutschen Aussprache!\u00BB \u2013 \u00ABPhallus impudicus\u2026\u00BB",
  "id" : 383216369736491008,
  "created_at" : "2013-09-26 13:07:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/WIFjIWpqgW",
      "expanded_url" : "http:\/\/images2.fanpop.com\/images\/photos\/7900000\/2x06-Afternoon-Delight-Animated-gif-Michael-What-No-no-no-no-arrested-development-7915781-300-167.gif",
      "display_url" : "images2.fanpop.com\/images\/photos\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383215850687168513",
  "text" : "Proofreading\u2026 http:\/\/t.co\/WIFjIWpqgW",
  "id" : 383215850687168513,
  "created_at" : "2013-09-26 13:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383199304866742272",
  "text" : "\u00ABIch stell nur mal schnell das Cluster auf eine andere Distribution um\u00BB \u2013 \u00ABYay, d.h. wir haben jetzt alle mindestens drei Wochen frei?\u00BB",
  "id" : 383199304866742272,
  "created_at" : "2013-09-26 12:00:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raychelle Burks",
      "screen_name" : "DrRubidium",
      "indices" : [ 3, 14 ],
      "id_str" : "196458749",
      "id" : 196458749
    }, {
      "name" : "JAYFK",
      "screen_name" : "theJAYFK",
      "indices" : [ 119, 128 ],
      "id_str" : "237079697",
      "id" : 237079697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/P0NbrMyOwP",
      "expanded_url" : "http:\/\/www.thejayfk.com\/?p=3112",
      "display_url" : "thejayfk.com\/?p=3112"
    } ]
  },
  "geo" : { },
  "id_str" : "383187928132108288",
  "text" : "RT @DrRubidium: Delusional Scientist Has Most Incredible List of Collaboration Requirements http:\/\/t.co\/P0NbrMyOwP via @theJAYFK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JAYFK",
        "screen_name" : "theJAYFK",
        "indices" : [ 103, 112 ],
        "id_str" : "237079697",
        "id" : 237079697
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/P0NbrMyOwP",
        "expanded_url" : "http:\/\/www.thejayfk.com\/?p=3112",
        "display_url" : "thejayfk.com\/?p=3112"
      } ]
    },
    "geo" : { },
    "id_str" : "383185941084385280",
    "text" : "Delusional Scientist Has Most Incredible List of Collaboration Requirements http:\/\/t.co\/P0NbrMyOwP via @theJAYFK",
    "id" : 383185941084385280,
    "created_at" : "2013-09-26 11:07:02 +0000",
    "user" : {
      "name" : "Raychelle Burks",
      "screen_name" : "DrRubidium",
      "protected" : false,
      "id_str" : "196458749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586676275953045504\/VhJ1hVZY_normal.jpg",
      "id" : 196458749,
      "verified" : true
    }
  },
  "id" : 383187928132108288,
  "created_at" : "2013-09-26 11:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/2y2Ll5oycn",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2497",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383186183611641856",
  "text" : "I like my women like I like my dogs\u2026 http:\/\/t.co\/2y2Ll5oycn",
  "id" : 383186183611641856,
  "created_at" : "2013-09-26 11:08:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383171060319158272",
  "geo" : { },
  "id_str" : "383171318696271873",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor nein, die Story ist zu d\u00FCnn: \"No layers in plot\"",
  "id" : 383171318696271873,
  "in_reply_to_status_id" : 383171060319158272,
  "created_at" : "2013-09-26 10:08:56 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383170737646751744",
  "text" : "ggplot(revenge)",
  "id" : 383170737646751744,
  "created_at" : "2013-09-26 10:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iKFOfVhn1e",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S1090023313004486",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383164686058786816",
  "text" : "Inbreeding Depression: Longevity in crossbred dogs exceeded purebred dogs by 1.2 years http:\/\/t.co\/iKFOfVhn1e",
  "id" : 383164686058786816,
  "created_at" : "2013-09-26 09:42:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/UxkMype0yB",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0076035",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383156845872812033",
  "text" : "Why Does Batrachochytrium dendrobatidis Not Occur Everywhere? http:\/\/t.co\/UxkMype0yB",
  "id" : 383156845872812033,
  "created_at" : "2013-09-26 09:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LtHrjpb9G0",
      "expanded_url" : "http:\/\/www.artifacting.com\/blog\/wp-content\/uploads\/2011\/09\/trainwreck.gif",
      "display_url" : "artifacting.com\/blog\/wp-conten\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722908558, 8.6276454461 ]
  },
  "id_str" : "383150634339676160",
  "text" : "Unfortunately that means going back to the wetlab to get more data\u2026 http:\/\/t.co\/LtHrjpb9G0",
  "id" : 383150634339676160,
  "created_at" : "2013-09-26 08:46:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/45IdrwSCS8",
      "expanded_url" : "http:\/\/i.imgur.com\/HteDi9T.gif",
      "display_url" : "i.imgur.com\/HteDi9T.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723302817, 8.6276412199 ]
  },
  "id_str" : "383150468748558336",
  "text" : "Results that support my initial hypothesis \\o\/ http:\/\/t.co\/45IdrwSCS8",
  "id" : 383150468748558336,
  "created_at" : "2013-09-26 08:46:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383144528367984640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723149551, 8.6276335865 ]
  },
  "id_str" : "383145126509703168",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng du bist also gut nach Hause gekommen. ;)",
  "id" : 383145126509703168,
  "in_reply_to_status_id" : 383144528367984640,
  "created_at" : "2013-09-26 08:24:51 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 65, 78 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 79, 89 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eDp5hQekC5",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0073791",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383144082643496960",
  "text" : "Personality, Gender, and Age in the Language of Social Media \/cc @PhilippBayer @eltonjohn http:\/\/t.co\/eDp5hQekC5",
  "id" : 383144082643496960,
  "created_at" : "2013-09-26 08:20:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/hqkZLom40s",
      "expanded_url" : "http:\/\/wurstsack.blogspot.de\/2013\/09\/zu-besuch-bei-den-supermarkt-tomaten.html",
      "display_url" : "wurstsack.blogspot.de\/2013\/09\/zu-bes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383142426832936960",
  "text" : "Zu Besuch bei den Supermarkt-Tomaten http:\/\/t.co\/hqkZLom40s",
  "id" : 383142426832936960,
  "created_at" : "2013-09-26 08:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QtlOINImAU",
      "expanded_url" : "http:\/\/www.united-academics.org\/magazine\/sex-society\/sex-4-days-per-week-will-raise-your-salary-up-to-5\/",
      "display_url" : "united-academics.org\/magazine\/sex-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383140946667270144",
  "text" : "Every time you ignore confounding variables and mix up cause &amp; effect some of my neurons die (may be vice versa\u2026) http:\/\/t.co\/QtlOINImAU",
  "id" : 383140946667270144,
  "created_at" : "2013-09-26 08:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723150877, 8.6276288122 ]
  },
  "id_str" : "383133643910418432",
  "text" : "\u00ABMachst du mir einen Kaffee mit? Ich mag ihn wie meine Software!\u00BB \u2014 \u00ABUnvorhersehbar, undokumentiert und voller Legacy-Zeug?\u00BB",
  "id" : 383133643910418432,
  "created_at" : "2013-09-26 07:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172302136, 8.6276476298 ]
  },
  "id_str" : "383128927843389440",
  "text" : "Angebot der innerbetrieblichen Weiterbildung: \u2018Vom Beenden und neu Anfangen - Workshop zum \u00DCbergang vom Beruf in den Ruhestand\u2019 Sounds Good!",
  "id" : 383128927843389440,
  "created_at" : "2013-09-26 07:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383010582925828096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096640651, 8.2829942451 ]
  },
  "id_str" : "383011131130122240",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I said pretty simple, not pretty!",
  "id" : 383011131130122240,
  "in_reply_to_status_id" : 383010582925828096,
  "created_at" : "2013-09-25 23:32:24 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vWtoGKeRWg",
      "expanded_url" : "http:\/\/biopython.org\/DIST\/docs\/tutorial\/Tutorial.html#htoc109",
      "display_url" : "biopython.org\/DIST\/docs\/tuto\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "383008970744414209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096833864, 8.2830737808 ]
  },
  "id_str" : "383010283595513856",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy none I know of, but coding against Entrez is pretty simple, e.g. in BioPython http:\/\/t.co\/vWtoGKeRWg",
  "id" : 383010283595513856,
  "in_reply_to_status_id" : 383008970744414209,
  "created_at" : "2013-09-25 23:29:02 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382998392718524416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096502901, 8.2829633541 ]
  },
  "id_str" : "382998594628104192",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Gute Nacht, Lass dich nicht von der Katze ankacken. ;)",
  "id" : 382998594628104192,
  "in_reply_to_status_id" : 382998392718524416,
  "created_at" : "2013-09-25 22:42:35 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382972446485143553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095702665, 8.2829893513 ]
  },
  "id_str" : "382981583986515968",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @Senficon the sweetest kiss I ever got is the one I\u2019ve never tasted!",
  "id" : 382981583986515968,
  "in_reply_to_status_id" : 382972446485143553,
  "created_at" : "2013-09-25 21:34:59 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382971855986241536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095796615, 8.2829850808 ]
  },
  "id_str" : "382972128339197952",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I lost my job, two weeks before Christmas!",
  "id" : 382972128339197952,
  "in_reply_to_status_id" : 382971855986241536,
  "created_at" : "2013-09-25 20:57:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095256313, 8.2830619242 ]
  },
  "id_str" : "382967584582549504",
  "text" : "\u00ABIch will noch mal Sugar Man h\u00F6ren. Und dann m\u00FCssen wir noch irgendwie die Beinst\u00FCmpfe einbauen.\u00BB",
  "id" : 382967584582549504,
  "created_at" : "2013-09-25 20:39:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382965814984712193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095847466, 8.2830384092 ]
  },
  "id_str" : "382966384873193472",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod das ist nicht \u00F6ffentlich verf\u00FCgbar. Aber ich widerspreche ebenfalls.",
  "id" : 382966384873193472,
  "in_reply_to_status_id" : 382965814984712193,
  "created_at" : "2013-09-25 20:34:35 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096443517, 8.2829999661 ]
  },
  "id_str" : "382964204195823616",
  "text" : "\u00ABDen Umschnalldildo zu zeigen ist \u00FCbrigens auch kein Flirten.\u00BB",
  "id" : 382964204195823616,
  "created_at" : "2013-09-25 20:25:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/F50tPk2E9I",
      "expanded_url" : "http:\/\/arialdomartini.wordpress.com\/2013\/05\/31\/how-to-spot-the-legacy-code-writer-in-your-company-hint-its-you\/",
      "display_url" : "arialdomartini.wordpress.com\/2013\/05\/31\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382954730164862977",
  "text" : "RT @helgerausch: How To Spot The Legacy Code Writer In Your Company (SPOILER: It's you!) http:\/\/t.co\/F50tPk2E9I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/F50tPk2E9I",
        "expanded_url" : "http:\/\/arialdomartini.wordpress.com\/2013\/05\/31\/how-to-spot-the-legacy-code-writer-in-your-company-hint-its-you\/",
        "display_url" : "arialdomartini.wordpress.com\/2013\/05\/31\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382954038167212032",
    "text" : "How To Spot The Legacy Code Writer In Your Company (SPOILER: It's you!) http:\/\/t.co\/F50tPk2E9I",
    "id" : 382954038167212032,
    "created_at" : "2013-09-25 19:45:32 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 382954730164862977,
  "created_at" : "2013-09-25 19:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095497072, 8.282753136 ]
  },
  "id_str" : "382952042077372416",
  "text" : "\u00ABIch find Public Displays of Affection widerlich\u00BB\u2014\u00ABDeshalb machst du das auch st\u00E4ndig, mit Hunden.\u00BB\u2014\u00ABDas ist immerhin nicht heteronormativ!\u00BB",
  "id" : 382952042077372416,
  "created_at" : "2013-09-25 19:37:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096228209, 8.2830173781 ]
  },
  "id_str" : "382946885147033600",
  "text" : "\u00ABTina verf\u00FChrt mich, mit Kuchen und K\u00E4se!\u00BB \u2014 \u00ABUnd soll ich eingreifen? Oder willst du mich nur informieren?\u00BB",
  "id" : 382946885147033600,
  "created_at" : "2013-09-25 19:17:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095814326, 8.2829933993 ]
  },
  "id_str" : "382936814212120576",
  "text" : "\u00ABNaja, wenn die Piratenpartei nun untergeht haben wir zumindest alle gut gev\u00F6gelt.\u00BB",
  "id" : 382936814212120576,
  "created_at" : "2013-09-25 18:37:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/3WrUl7eNpq",
      "expanded_url" : "http:\/\/instagram.com\/p\/esWr84hwpP\/",
      "display_url" : "instagram.com\/p\/esWr84hwpP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "382931046670827520",
  "text" : "\u00ABIch musste dem System ja irgendwie schaden. Also habe ich dir Kuchen geklaut!\u00BB @ Elfenbeinturm http:\/\/t.co\/3WrUl7eNpq",
  "id" : 382931046670827520,
  "created_at" : "2013-09-25 18:14:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382918369189826560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0625406838, 8.5244580083 ]
  },
  "id_str" : "382918873873657856",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon no wonder you\u2019re doing freq. over bay. stats. As the latter would take the data for fixed and adjust the hypothesis. :p",
  "id" : 382918873873657856,
  "in_reply_to_status_id" : 382918369189826560,
  "created_at" : "2013-09-25 17:25:48 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382917628849057792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0626650849, 8.5886537085 ]
  },
  "id_str" : "382918174825783296",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich vergesse immer das du pol-sci machst. Fudging data to fit the story. ;)",
  "id" : 382918174825783296,
  "in_reply_to_status_id" : 382917628849057792,
  "created_at" : "2013-09-25 17:23:01 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382916806706356224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0683484475, 8.6078744928 ]
  },
  "id_str" : "382917459181051904",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng good luck, mal schauen wer fr\u00FCher da ist. :p",
  "id" : 382917459181051904,
  "in_reply_to_status_id" : 382916806706356224,
  "created_at" : "2013-09-25 17:20:11 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382915904889450496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0679600671, 8.6090480308 ]
  },
  "id_str" : "382917398443352065",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon wir haben sie erst seit ~ einem Jahr glaube ich ;)",
  "id" : 382917398443352065,
  "in_reply_to_status_id" : 382915904889450496,
  "created_at" : "2013-09-25 17:19:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382914704005271553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0794277146, 8.6427582032 ]
  },
  "id_str" : "382915636739178496",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng tell me about it, ich musste nun die low 3G-coverage S9 nehmen statt der S1! Wie so ein Tier!",
  "id" : 382915636739178496,
  "in_reply_to_status_id" : 382914704005271553,
  "created_at" : "2013-09-25 17:12:56 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 90, 98 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/U8PR5u8d39",
      "expanded_url" : "http:\/\/www.queerstem.org\/2013\/09\/preliminary-results-out-of-lab-closet.html?m=1",
      "display_url" : "queerstem.org\/2013\/09\/prelim\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693758668, 8.6223214028 ]
  },
  "id_str" : "382905264623849472",
  "text" : "Queer in STEM \u2014 Preliminary results: Out of the lab closet? http:\/\/t.co\/U8PR5u8d39 Thanks @JBYoder!",
  "id" : 382905264623849472,
  "created_at" : "2013-09-25 16:31:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/G5VmI2UaEE",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/09\/25\/love-song-for-internet-trolls.html",
      "display_url" : "boingboing.net\/2013\/09\/25\/lov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382888636703703040",
  "text" : "Love Song for Internet Trolls http:\/\/t.co\/G5VmI2UaEE",
  "id" : 382888636703703040,
  "created_at" : "2013-09-25 15:25:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382880645996740608",
  "text" : "\u00ABAuch wenn du noch Badewasser auf offenem Feuer heiss machen musstest: F\u00FCr den Split 'Pilze\/Tiere von Pflanzen' brauchst du eine Citation.\u00BB",
  "id" : 382880645996740608,
  "created_at" : "2013-09-25 14:53:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 88, 100 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9KvqQip7OL",
      "expanded_url" : "http:\/\/www.timminchin.com\/2013\/09\/25\/occasional-address\/",
      "display_url" : "timminchin.com\/2013\/09\/25\/occ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722820378, 8.6276643333 ]
  },
  "id_str" : "382869243521679360",
  "text" : "\u00ABAnd here\u2019s my idea of romance: You will soon be dead.\u00BB &lt;3 http:\/\/t.co\/9KvqQip7OL HT @AkshatRathi",
  "id" : 382869243521679360,
  "created_at" : "2013-09-25 14:08:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "Tim Minchin",
      "screen_name" : "timminchin",
      "indices" : [ 18, 29 ],
      "id_str" : "18980276",
      "id" : 18980276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Z0x9RVzXle",
      "expanded_url" : "http:\/\/www.timminchin.com\/2013\/09\/25\/occasional-address\/",
      "display_url" : "timminchin.com\/2013\/09\/25\/occ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382866306409566208",
  "text" : "RT @AkshatRathi: .@timminchin gave a graduation speech. Of course you wanna hear he had to say: http:\/\/t.co\/Z0x9RVzXle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Minchin",
        "screen_name" : "timminchin",
        "indices" : [ 1, 12 ],
        "id_str" : "18980276",
        "id" : 18980276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Z0x9RVzXle",
        "expanded_url" : "http:\/\/www.timminchin.com\/2013\/09\/25\/occasional-address\/",
        "display_url" : "timminchin.com\/2013\/09\/25\/occ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382863276763131906",
    "text" : ".@timminchin gave a graduation speech. Of course you wanna hear he had to say: http:\/\/t.co\/Z0x9RVzXle",
    "id" : 382863276763131906,
    "created_at" : "2013-09-25 13:44:53 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 382866306409566208,
  "created_at" : "2013-09-25 13:56:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382864605061869568",
  "text" : "\u00ABWas ist eigentlich der \u2018watchdog\u2019-Prozess der auf allen Workstations l\u00E4uft?\u00BB \u2014 \u00ABDer subtile Hinweis vom Admin auf seinen Hund aufzupassen.\u00BB",
  "id" : 382864605061869568,
  "created_at" : "2013-09-25 13:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/90Ix5oQ533",
      "expanded_url" : "http:\/\/retractionwatch.wordpress.com\/2013\/09\/23\/a-serbian-sokal-authors-spoof-pub-with-ron-jeremy-and-michael-jackson-references\/",
      "display_url" : "retractionwatch.wordpress.com\/2013\/09\/23\/a-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382855227256229889",
  "text" : "Authors spoof pub with Ron Jeremy and Michael Jackson references http:\/\/t.co\/90Ix5oQ533",
  "id" : 382855227256229889,
  "created_at" : "2013-09-25 13:12:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5kw5BvYUKi",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/09\/24\/godspeed-you-black-emperor-co.html",
      "display_url" : "boingboing.net\/2013\/09\/24\/god\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382833987124592641",
  "text" : "Godspeed You! Black Emperor condemns music contest they won, vows to use money to buy instruments for prisoners http:\/\/t.co\/5kw5BvYUKi",
  "id" : 382833987124592641,
  "created_at" : "2013-09-25 11:48:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/CBEJgsysHe",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/en\/a\/ac\/LART.png",
      "display_url" : "upload.wikimedia.org\/wikipedia\/en\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382832371763929089",
  "text" : "\u00ABDas ist ein LART? Und was macht man damit?\u00BB \u2013 \u00ABDas kann dir unser Sysadmin nachher im dunklen Serverraum zeigen.\u00BB http:\/\/t.co\/CBEJgsysHe",
  "id" : 382832371763929089,
  "created_at" : "2013-09-25 11:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/jGD22tKQOe",
      "expanded_url" : "http:\/\/instagram.com\/p\/erhjdyBwpX\/",
      "display_url" : "instagram.com\/p\/erhjdyBwpX\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "382814560992124928",
  "text" : "Kink at the workplace @ Biologicum http:\/\/t.co\/jGD22tKQOe",
  "id" : 382814560992124928,
  "created_at" : "2013-09-25 10:31:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722879229, 8.627656519 ]
  },
  "id_str" : "382812960957407232",
  "text" : "\u00ABZitier dich einfach selbst mit \u2018On the Origin of Awesomeness\u2019, publiziert im Journal of Irreproducible Results.\u00BB",
  "id" : 382812960957407232,
  "created_at" : "2013-09-25 10:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Gu2aNLgfwU",
      "expanded_url" : "http:\/\/instagram.com\/p\/erVa0JhwhW\/",
      "display_url" : "instagram.com\/p\/erVa0JhwhW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382787509627138048",
  "text" : "\u00ABTja, ich glaube du wurdest ausgesetzt und wirst nicht mehr abgeholt\u2026\u00BB http:\/\/t.co\/Gu2aNLgfwU",
  "id" : 382787509627138048,
  "created_at" : "2013-09-25 08:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382782617302482945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722980338, 8.6276530525 ]
  },
  "id_str" : "382783051220406272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yeah, \u2018now\u2019, sure\u2026",
  "id" : 382783051220406272,
  "in_reply_to_status_id" : 382782617302482945,
  "created_at" : "2013-09-25 08:26:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jQW4ljacll",
      "expanded_url" : "http:\/\/xkcd.com\/1269\/",
      "display_url" : "xkcd.com\/1269\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382780325287313408",
  "text" : "As if anything I do means anything\u2026 http:\/\/t.co\/jQW4ljacll",
  "id" : 382780325287313408,
  "created_at" : "2013-09-25 08:15:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 0, 7 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382774640911065088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172314971, 8.6276334831 ]
  },
  "id_str" : "382775144311435264",
  "in_reply_to_user_id" : 15353398,
  "text" : "@zinken viel Erfolg. :)",
  "id" : 382775144311435264,
  "in_reply_to_status_id" : 382774640911065088,
  "created_at" : "2013-09-25 07:54:40 +0000",
  "in_reply_to_screen_name" : "zinken",
  "in_reply_to_user_id_str" : "15353398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382772839763296256",
  "text" : "Arbeitsbeginn: Kaffee \u2713 Hund auf den F\u00FC\u00DFen unter dem Schreibtisch \u2713 Kryptische Fehlermeldungen \u2713",
  "id" : 382772839763296256,
  "created_at" : "2013-09-25 07:45:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anorak",
      "screen_name" : "TheAnorak",
      "indices" : [ 3, 13 ],
      "id_str" : "4055701",
      "id" : 4055701
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheAnorak\/status\/382757277347770368\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Oio65r14Hn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU_TtzFCAAAE4Is.jpg",
      "id_str" : "382757277108666368",
      "id" : 382757277108666368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU_TtzFCAAAE4Is.jpg",
      "sizes" : [ {
        "h" : 423,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 306
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 306
      } ],
      "display_url" : "pic.twitter.com\/Oio65r14Hn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382758046021484544",
  "text" : "RT @TheAnorak: Meanwhile...in Barnsley http:\/\/t.co\/Oio65r14Hn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheAnorak\/status\/382757277347770368\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/Oio65r14Hn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BU_TtzFCAAAE4Is.jpg",
        "id_str" : "382757277108666368",
        "id" : 382757277108666368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU_TtzFCAAAE4Is.jpg",
        "sizes" : [ {
          "h" : 423,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/Oio65r14Hn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382757277347770368",
    "text" : "Meanwhile...in Barnsley http:\/\/t.co\/Oio65r14Hn",
    "id" : 382757277347770368,
    "created_at" : "2013-09-25 06:43:40 +0000",
    "user" : {
      "name" : "Anorak",
      "screen_name" : "TheAnorak",
      "protected" : false,
      "id_str" : "4055701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749860572636774400\/9ZFplj0A_normal.jpg",
      "id" : 4055701,
      "verified" : false
    }
  },
  "id" : 382758046021484544,
  "created_at" : "2013-09-25 06:46:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/hCIObo5iCu",
      "expanded_url" : "http:\/\/instagram.com\/p\/erDDxGBwmp\/",
      "display_url" : "instagram.com\/p\/erDDxGBwmp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382747097034141696",
  "text" : "\u00ABIch sage ja zum Flugl\u00E4rm!\u00BB http:\/\/t.co\/hCIObo5iCu",
  "id" : 382747097034141696,
  "created_at" : "2013-09-25 06:03:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044685805, 8.3506044088 ]
  },
  "id_str" : "382745091880022016",
  "text" : "\u00ABWir sollten ein gr\u00F6\u00DFeres Bett anschaffen? Damit mehr Katzen neben uns Crazy Cat People schlafen k\u00F6nnen?\u00BB \u2014 \u00ABIch dachte an Partner*innen\u2026\u00BB",
  "id" : 382745091880022016,
  "created_at" : "2013-09-25 05:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/cotuaNqj1Y",
      "expanded_url" : "http:\/\/i.imgur.com\/1tcUj4Y.gif",
      "display_url" : "i.imgur.com\/1tcUj4Y.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044685805, 8.3506044088 ]
  },
  "id_str" : "382744312397955072",
  "text" : "Stop fooling around! http:\/\/t.co\/cotuaNqj1Y",
  "id" : 382744312397955072,
  "created_at" : "2013-09-25 05:52:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/cO7nKagWxu",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/polyamory\/comments\/1n14iu\/youre_falling_in_love_with_someone_else_and_i\/",
      "display_url" : "reddit.com\/r\/polyamory\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096457424, 8.2829566439 ]
  },
  "id_str" : "382645472772775936",
  "text" : "\u00ABWhere someone else entering the picture isn\u2019t a cause for alarm or dismay, but a reason to celebrate\u2026\u00BB http:\/\/t.co\/cO7nKagWxu",
  "id" : 382645472772775936,
  "created_at" : "2013-09-24 23:19:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/QQy8F9uos6",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/62155322381\/when-i-fall-asleep-in-the-lab-and-dont-remember-where",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/621553223\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966202, 8.2829887133 ]
  },
  "id_str" : "382623544083222528",
  "text" : "What happens every other day in our office http:\/\/t.co\/QQy8F9uos6",
  "id" : 382623544083222528,
  "created_at" : "2013-09-24 21:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382617781092761600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966202, 8.2829887133 ]
  },
  "id_str" : "382618409449832448",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju Oh, das war single und nicht multipe choice?",
  "id" : 382618409449832448,
  "in_reply_to_status_id" : 382617781092761600,
  "created_at" : "2013-09-24 21:31:52 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 128, 137 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/W1TMEPruZl",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1xN1G5mkC7o",
      "display_url" : "youtube.com\/watch?v=1xN1G5\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966202, 8.2829887133 ]
  },
  "id_str" : "382618325513424896",
  "text" : "\u00ABWell damn those whiskey nights, when my visions are live wires\u2026\u00BB http:\/\/t.co\/W1TMEPruZl Thanks for the indirect recommendation @eramirez!",
  "id" : 382618325513424896,
  "created_at" : "2013-09-24 21:31:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966202, 8.2829887133 ]
  },
  "id_str" : "382614019007606784",
  "text" : "\u00ABWollen wir mal die Payload in der Katze deponieren?\u00BB \u2013 \u00AB\u2018Woran man merkt das du zu viele Afghan War Diaries gelesen hast\u2019 f\u00FCr 500.\u00BB",
  "id" : 382614019007606784,
  "created_at" : "2013-09-24 21:14:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/PgKNVZDkPB",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/tumblr_l9hnkdvT2L1qe0qyho1_500.gif",
      "display_url" : "24.media.tumblr.com\/tumblr_l9hnkdv\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382612191134097408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966202, 8.2829887133 ]
  },
  "id_str" : "382612734111928320",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju ( ) nur wenn du es als synonym f\u00FCr http:\/\/t.co\/PgKNVZDkPB verwendest",
  "id" : 382612734111928320,
  "in_reply_to_status_id" : 382612191134097408,
  "created_at" : "2013-09-24 21:09:19 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0099507313, 8.2789015444 ]
  },
  "id_str" : "382600148351975424",
  "text" : "\u00ABOh man, du bist du so zynisch!\u00BB \u2014 \u00ABUnd das f\u00E4llt dir nach \u00FCber 3 Jahren auf?!\u00BB",
  "id" : 382600148351975424,
  "created_at" : "2013-09-24 20:19:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095238617, 8.2829761383 ]
  },
  "id_str" : "382595675701395457",
  "text" : "If you use wc -l instead of -c you shouldn\u2019t be too surprised if your genome sizes are off by some order of magnitudes\u2026",
  "id" : 382595675701395457,
  "created_at" : "2013-09-24 20:01:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 4, 11 ],
      "id_str" : "19722699",
      "id" : 19722699
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 71, 77 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 78, 87 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/zKxs23ifvf",
      "expanded_url" : "http:\/\/www.popsci.com\/science\/article\/2013-09\/why-were-shutting-our-comments",
      "display_url" : "popsci.com\/science\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009660709, 8.2830294914 ]
  },
  "id_str" : "382554851345174528",
  "text" : "Why @popsci is shutting down their comments http:\/\/t.co\/zKxs23ifvf \/cc @Lobot @JP_Stich",
  "id" : 382554851345174528,
  "created_at" : "2013-09-24 17:19:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0064173674, 8.2891076039 ]
  },
  "id_str" : "382552163366752256",
  "text" : "\u00ABDu wirst auch auf unserer Hochzeit keinen Anzug tragen!?\u00BB \u2014 \u00ABQuatsch, wenn schon verkleiden dann richtig!\u00BB \u2014 \u00ABKilt oder Jedi-Kost\u00FCm?\u00BB",
  "id" : 382552163366752256,
  "created_at" : "2013-09-24 17:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382550045788102656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0048777797, 8.2896095685 ]
  },
  "id_str" : "382550590804754432",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng nur in dress. ;)",
  "id" : 382550590804754432,
  "in_reply_to_status_id" : 382550045788102656,
  "created_at" : "2013-09-24 17:02:22 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969724, 8.2831201889 ]
  },
  "id_str" : "382544249994375168",
  "text" : "\u00ABSolange der Tierarzt morgen nicht auch hom\u00F6opathisch r\u00F6ntgt und nur auf ein schwarzes Bild schaut\u2026\u00BB",
  "id" : 382544249994375168,
  "created_at" : "2013-09-24 16:37:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089091203, 8.2926808298 ]
  },
  "id_str" : "382531037928357888",
  "text" : "\u00ABIch wollt sagen \u2018Ich w\u00FCrde dich zum Beispiel nie mit Kot einschmieren\u2019, aber dann ist mir aufgefallen: Genau das habe ich gerade gemacht!\u00BB",
  "id" : 382531037928357888,
  "created_at" : "2013-09-24 15:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Rwcsk38OEF",
      "expanded_url" : "http:\/\/on.mash.to\/1algwi6",
      "display_url" : "on.mash.to\/1algwi6"
    } ]
  },
  "geo" : { },
  "id_str" : "382530865689276416",
  "text" : "RT @kaythaney: An open letter to science from John Slattery. Seriously, where are my robots. http:\/\/t.co\/Rwcsk38OEF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/Rwcsk38OEF",
        "expanded_url" : "http:\/\/on.mash.to\/1algwi6",
        "display_url" : "on.mash.to\/1algwi6"
      } ]
    },
    "geo" : { },
    "id_str" : "382525514705293312",
    "text" : "An open letter to science from John Slattery. Seriously, where are my robots. http:\/\/t.co\/Rwcsk38OEF",
    "id" : 382525514705293312,
    "created_at" : "2013-09-24 15:22:44 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 382530865689276416,
  "created_at" : "2013-09-24 15:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Havis",
      "screen_name" : "ShinZeldias",
      "indices" : [ 3, 15 ],
      "id_str" : "165576206",
      "id" : 165576206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382521942458523648",
  "text" : "RT @ShinZeldias: I may seek a dialectic to resolve the tensions of drama and play by revealing ludonarrative dissonance in Japanese RPGs.#s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shitacademicssay",
        "indices" : [ 120, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379677046806282241",
    "text" : "I may seek a dialectic to resolve the tensions of drama and play by revealing ludonarrative dissonance in Japanese RPGs.#shitacademicssay",
    "id" : 379677046806282241,
    "created_at" : "2013-09-16 18:43:56 +0000",
    "user" : {
      "name" : "Havis",
      "screen_name" : "ShinZeldias",
      "protected" : false,
      "id_str" : "165576206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1838427574\/2010-11-01_10.10.17_normal.jpg",
      "id" : 165576206,
      "verified" : false
    }
  },
  "id" : 382521942458523648,
  "created_at" : "2013-09-24 15:08:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0088786196, 8.292596332 ]
  },
  "id_str" : "382519138444668928",
  "text" : "Gel\u00E4chter im Wartezimmer: \u00ABUnd wie hei\u00DFt die Katze?\u00BB \u2014 \u00ABMiezi\u2026\u00BB",
  "id" : 382519138444668928,
  "created_at" : "2013-09-24 14:57:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Asr001H5hc",
      "expanded_url" : "http:\/\/instagram.com\/p\/epalNahwvT\/",
      "display_url" : "instagram.com\/p\/epalNahwvT\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008859, 8.292717 ]
  },
  "id_str" : "382517507015602176",
  "text" : "Seit 20 Minuten Gefangene der RAF. @ Tierarztpraxis Dr. Wiedick Puscasu http:\/\/t.co\/Asr001H5hc",
  "id" : 382517507015602176,
  "created_at" : "2013-09-24 14:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 39, 50 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095174672, 8.2832046518 ]
  },
  "id_str" : "382509241074208768",
  "text" : "\u00ABWas ist eigentlich deine Beziehung zu @spreeblick?\u00BB \u2014 \u00ABIch finde ihn sehr niedlich weil er einen Hintergrund-Hund im Podcast hatte.\u00BB",
  "id" : 382509241074208768,
  "created_at" : "2013-09-24 14:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/jQ6bEBDfn4",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/wmmUEcqVpH8\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382496852396216320",
  "text" : "Porn Comments on Instagram Pics http:\/\/t.co\/jQ6bEBDfn4",
  "id" : 382496852396216320,
  "created_at" : "2013-09-24 13:28:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1045119844, 8.6971596659 ]
  },
  "id_str" : "382495384272396288",
  "text" : "\u00ABSicheres Entfernen nun m\u00F6glich: Sie k\u00F6nnen ihre Partnerin jetzt rauswerfen.\u00BB",
  "id" : 382495384272396288,
  "created_at" : "2013-09-24 13:23:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.123154465, 8.6775905506 ]
  },
  "id_str" : "382449308660170752",
  "text" : "\u00ABWhen I was a boy I always assumed that I would grow up to be a scientist &amp; a Red. I\u2019d have had a difficult time trying to separate them.\u00BB",
  "id" : 382449308660170752,
  "created_at" : "2013-09-24 10:19:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ML Hipster",
      "screen_name" : "ML_Hipster",
      "indices" : [ 3, 14 ],
      "id_str" : "634406525",
      "id" : 634406525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382415878794797056",
  "text" : "RT @ML_Hipster: I was initially skeptical but every time I've used Bayes' rule it has given me the correct answer. Still can't completely t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361629871518138369",
    "text" : "I was initially skeptical but every time I've used Bayes' rule it has given me the correct answer. Still can't completely trust it though.",
    "id" : 361629871518138369,
    "created_at" : "2013-07-28 23:30:54 +0000",
    "user" : {
      "name" : "ML Hipster",
      "screen_name" : "ML_Hipster",
      "protected" : false,
      "id_str" : "634406525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2393561742\/image_normal.jpg",
      "id" : 634406525,
      "verified" : false
    }
  },
  "id" : 382415878794797056,
  "created_at" : "2013-09-24 08:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/382406829449310208\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PEj1mmfwXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU6U_DTCcAEB1Cw.jpg",
      "id_str" : "382406829310898177",
      "id" : 382406829310898177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU6U_DTCcAEB1Cw.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/PEj1mmfwXO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/VV7q0HPEXk",
      "expanded_url" : "http:\/\/i.imgur.com\/MWFgSfn.gif",
      "display_url" : "i.imgur.com\/MWFgSfn.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.170618, 8.62306 ]
  },
  "id_str" : "382406829449310208",
  "text" : "Having a first look at the results that took 2 weeks to compute.  http:\/\/t.co\/VV7q0HPEXk http:\/\/t.co\/PEj1mmfwXO",
  "id" : 382406829449310208,
  "created_at" : "2013-09-24 07:31:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382262553444757504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335525, 8.28299436 ]
  },
  "id_str" : "382262925551214592",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot just a well tailored selection of RSS feeds &amp; followings on Twitter.",
  "id" : 382262925551214592,
  "in_reply_to_status_id" : 382262553444757504,
  "created_at" : "2013-09-23 21:59:18 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/iTF2RmIyVm",
      "expanded_url" : "http:\/\/i.imgur.com\/w4mdb3H.jpg",
      "display_url" : "i.imgur.com\/w4mdb3H.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335525, 8.28299436 ]
  },
  "id_str" : "382255738162532352",
  "text" : "Theodizee http:\/\/t.co\/iTF2RmIyVm",
  "id" : 382255738162532352,
  "created_at" : "2013-09-23 21:30:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335525, 8.28299436 ]
  },
  "id_str" : "382243043237441536",
  "text" : "I wish someone would do a System Shock 2 remake. Where you awake on board of the De Bruijn, having accidentally lost your read identity.",
  "id" : 382243043237441536,
  "created_at" : "2013-09-23 20:40:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096476113, 8.2829632062 ]
  },
  "id_str" : "382221576969932800",
  "text" : "\u00ABWas, sie hat W\u00E4sche mit in die W\u00E4schetonne getan?! Meinen Verlobten kann sie ja haben so viel sie will, aber das Waschpulver ist meins!\u00BB",
  "id" : 382221576969932800,
  "created_at" : "2013-09-23 19:14:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lpXDXe8yUY",
      "expanded_url" : "http:\/\/cdn.themetapicture.com\/media\/funny-gif-bunnies-in-cups.gif",
      "display_url" : "cdn.themetapicture.com\/media\/funny-gi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335525, 8.28299436 ]
  },
  "id_str" : "382205127769477120",
  "text" : "\u00ABLass mal duschen. Deinen Geruch finde ich noch sehr angenehm. Aber meinen eigenen Gestank ertrage ich nicht mehr.\u00BB http:\/\/t.co\/lpXDXe8yUY",
  "id" : 382205127769477120,
  "created_at" : "2013-09-23 18:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/bJAVndM0Fw",
      "expanded_url" : "http:\/\/theamericanscholar.org\/is-there-a-word-for-that\/#.UkB4PWTIKXr",
      "display_url" : "theamericanscholar.org\/is-there-a-wor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335525, 8.28299436 ]
  },
  "id_str" : "382193882626547712",
  "text" : "\u00ABMockery turns out to be a first-rate incubator for lasting neologisms\u00BB http:\/\/t.co\/bJAVndM0Fw",
  "id" : 382193882626547712,
  "created_at" : "2013-09-23 17:24:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/mTOP5A9UnI",
      "expanded_url" : "http:\/\/instagram.com\/p\/enBLbLhwm8\/",
      "display_url" : "instagram.com\/p\/enBLbLhwm8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382180087099326465",
  "text" : "Selbstbildnis mit singender S\u00E4ge (solo) http:\/\/t.co\/mTOP5A9UnI",
  "id" : 382180087099326465,
  "created_at" : "2013-09-23 16:30:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382162430681296897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1478097377, 8.6617182206 ]
  },
  "id_str" : "382165953087565824",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog gern. :)",
  "id" : 382165953087565824,
  "in_reply_to_status_id" : 382162430681296897,
  "created_at" : "2013-09-23 15:33:58 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382155914301562881",
  "geo" : { },
  "id_str" : "382156280170680320",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog sie haben Post!",
  "id" : 382156280170680320,
  "in_reply_to_status_id" : 382155914301562881,
  "created_at" : "2013-09-23 14:55:31 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723037272, 8.6276376114 ]
  },
  "id_str" : "382123145911877632",
  "text" : "\u00ABBurning Man? Wenn ich ne Voodoo-Puppe anz\u00FCnde und auf den FKK-Strand werfe hab ich das gleiche!\u00BB",
  "id" : 382123145911877632,
  "created_at" : "2013-09-23 12:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/6Ntidr31NN",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/09\/20\/howto-make-hydrophobic-rain-on.html",
      "display_url" : "boingboing.net\/2013\/09\/20\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382121627284013056",
  "text" : "hydrophobic rain-only street art http:\/\/t.co\/6Ntidr31NN",
  "id" : 382121627284013056,
  "created_at" : "2013-09-23 12:37:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/FMWYBQIZ5n",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3122",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382120062422773760",
  "text" : "Hostile Environment http:\/\/t.co\/FMWYBQIZ5n",
  "id" : 382120062422773760,
  "created_at" : "2013-09-23 12:31:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/AhMqO3l2P1",
      "expanded_url" : "http:\/\/i.imgur.com\/Gj9b4Gm.gif",
      "display_url" : "i.imgur.com\/Gj9b4Gm.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "382118088948215808",
  "text" : "surprise me! http:\/\/t.co\/AhMqO3l2P1",
  "id" : 382118088948215808,
  "created_at" : "2013-09-23 12:23:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1792107376, 8.6221593303 ]
  },
  "id_str" : "382111926631034880",
  "text" : "\u00ABDu bist so ein Grobian, du bist mehr der Vorarbeiter unter den Fechtern.\u00BB",
  "id" : 382111926631034880,
  "created_at" : "2013-09-23 11:59:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 6, 14 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/NEBZWNoNZF",
      "expanded_url" : "http:\/\/instagram.com\/p\/emcj78Bwri\/",
      "display_url" : "instagram.com\/p\/emcj78Bwri\/"
    } ]
  },
  "geo" : { },
  "id_str" : "382099540968742912",
  "text" : "Paleo-@moeffju in ein paar Jahren http:\/\/t.co\/NEBZWNoNZF",
  "id" : 382099540968742912,
  "created_at" : "2013-09-23 11:10:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172321605, 8.6275944087 ]
  },
  "id_str" : "382097933224923136",
  "text" : "\u00ABBei\u00DF mir kleine Venn-Diagramme in den Arm!\u00BB",
  "id" : 382097933224923136,
  "created_at" : "2013-09-23 11:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609691, 8.2831208583 ]
  },
  "id_str" : "382074266185138176",
  "text" : "\u00ABIch lasse mich ja nur mit Kot einschmieren um mehr Follower zu bekommen.\u00BB",
  "id" : 382074266185138176,
  "created_at" : "2013-09-23 09:29:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381861589370281986",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097488193, 8.2830009889 ]
  },
  "id_str" : "381877204210442240",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj zwei M\u00E4nner gehen rein, Tina Turner\/Angela Merkel kommt raus?",
  "id" : 381877204210442240,
  "in_reply_to_status_id" : 381861589370281986,
  "created_at" : "2013-09-22 20:26:35 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0093384833, 8.2828121446 ]
  },
  "id_str" : "381862310987702272",
  "text" : "\u00ABIch habe Nachrichten f\u00FCr dich. Die Schlechte: Ich verlasse dich. Die Gute: Es ist noch kochendes Wasser da wenn du Tee willst.\u00BB",
  "id" : 381862310987702272,
  "created_at" : "2013-09-22 19:27:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095241985, 8.2829742709 ]
  },
  "id_str" : "381858636148264960",
  "text" : "\u00ABWolltest du vorhin nicht noch was twittern? Ich will dich mal wieder faven.\u00BB",
  "id" : 381858636148264960,
  "created_at" : "2013-09-22 19:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095546525, 8.2829418127 ]
  },
  "id_str" : "381852217164447745",
  "text" : "\u00ABIch hab dich.\u00BB \u2014 \u00ABIch wei\u00DF, du hasst mich\u2026\u00BB",
  "id" : 381852217164447745,
  "created_at" : "2013-09-22 18:47:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 13, 22 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Co8v9gLLhh",
      "expanded_url" : "http:\/\/instagram.com\/p\/ekr_qzBwpm\/",
      "display_url" : "instagram.com\/p\/ekr_qzBwpm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "381851989719908352",
  "text" : "Gefunden f\u00FCr @JP_Stich http:\/\/t.co\/Co8v9gLLhh",
  "id" : 381851989719908352,
  "created_at" : "2013-09-22 18:46:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/wo0FU5cDjs",
      "expanded_url" : "http:\/\/instagram.com\/p\/ekrdC3Bwo5\/",
      "display_url" : "instagram.com\/p\/ekrdC3Bwo5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "381850711983923200",
  "text" : "Claudia! http:\/\/t.co\/wo0FU5cDjs",
  "id" : 381850711983923200,
  "created_at" : "2013-09-22 18:41:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095871802, 8.2829538131 ]
  },
  "id_str" : "381848915219599360",
  "text" : "\u00ABDarf ich dich shampoonieren?\u00BB \u2014 \u00ABDu darfst mich auch gerne konditionieren wenn du willst.\u00BB",
  "id" : 381848915219599360,
  "created_at" : "2013-09-22 18:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095121563, 8.2828548923 ]
  },
  "id_str" : "381826934159990784",
  "text" : "\u00ABIch mag das wie du mir den Kopf t\u00E4tschelst wenn ich was dummes gesagt habe.\u00BB \u2014 \u00ABAch, deshalb machst du das immer\u2026\u00BB",
  "id" : 381826934159990784,
  "created_at" : "2013-09-22 17:06:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381785972725530624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095546525, 8.2829418127 ]
  },
  "id_str" : "381786892662226944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gestern hast du mir noch \u2018jede Wahrheit braucht einen Mutigen der sie ausspricht\u2019 vorgelebt!",
  "id" : 381786892662226944,
  "in_reply_to_status_id" : 381785972725530624,
  "created_at" : "2013-09-22 14:27:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095388527, 8.2829048485 ]
  },
  "id_str" : "381786089503326208",
  "text" : "\u00ABIch w\u00FCrde deinen Horizont ja gerne erweitern. Aber vielleicht lernst du erstmal wie man ihn gerade macht.\u00BB",
  "id" : 381786089503326208,
  "created_at" : "2013-09-22 14:24:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094255293, 8.2826047763 ]
  },
  "id_str" : "381782799122198529",
  "text" : "\u00ABSeit ich dir unangek\u00FCndigt einen Finger in den Hintern geschoben habe wird es weniger awkward.\u00BB\u2014\u00ABDu meinst nach Peak Awkwardness\u2026\u00BB",
  "id" : 381782799122198529,
  "created_at" : "2013-09-22 14:11:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/E5PlaSr4pY",
      "expanded_url" : "http:\/\/i.imgur.com\/xfBdbR3.jpg",
      "display_url" : "i.imgur.com\/xfBdbR3.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "381748651531726848",
  "text" : "Be brave http:\/\/t.co\/E5PlaSr4pY",
  "id" : 381748651531726848,
  "created_at" : "2013-09-22 11:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/gbgQOWq3in",
      "expanded_url" : "http:\/\/instagram.com\/p\/ej5Pb8hwjA\/",
      "display_url" : "instagram.com\/p\/ej5Pb8hwjA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "381740364853686272",
  "text" : "Wenn schon alle ihre Stimmzettel posten\u2026 http:\/\/t.co\/gbgQOWq3in",
  "id" : 381740364853686272,
  "created_at" : "2013-09-22 11:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/gDOAntf5ft",
      "expanded_url" : "http:\/\/instagram.com\/p\/ej4HkmBwh4\/",
      "display_url" : "instagram.com\/p\/ej4HkmBwh4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "381737920157466624",
  "text" : "Dem Kater aus dem Hinterkopf gezogen. http:\/\/t.co\/gDOAntf5ft",
  "id" : 381737920157466624,
  "created_at" : "2013-09-22 11:13:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381733389566750720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096644341, 8.2830957062 ]
  },
  "id_str" : "381734424481890304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot et tu, Bluterus?",
  "id" : 381734424481890304,
  "in_reply_to_status_id" : 381733389566750720,
  "created_at" : "2013-09-22 10:59:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ebsZnpZVm3",
      "expanded_url" : "http:\/\/i.imgur.com\/KRPWsrn.jpg",
      "display_url" : "i.imgur.com\/KRPWsrn.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009675, 8.283088 ]
  },
  "id_str" : "381711264726409216",
  "text" : "Nostalgia http:\/\/t.co\/ebsZnpZVm3",
  "id" : 381711264726409216,
  "created_at" : "2013-09-22 09:27:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381700669461504000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096979563, 8.2831250762 ]
  },
  "id_str" : "381709850302238720",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch tried again, same error, may this be a problem as you did the exceptional-thingy and the repo is in my GH?",
  "id" : 381709850302238720,
  "in_reply_to_status_id" : 381700669461504000,
  "created_at" : "2013-09-22 09:21:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096412233, 8.2829522213 ]
  },
  "id_str" : "381704842580078592",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon wo auf dem Zettel muss ich gleich noch mal die Kreutzchen machen?",
  "id" : 381704842580078592,
  "created_at" : "2013-09-22 09:01:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381695007360819200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095110467, 8.2829194767 ]
  },
  "id_str" : "381700359305306112",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch I would love to, but I keep getting a 404 while auth. See email.",
  "id" : 381700359305306112,
  "in_reply_to_status_id" : 381695007360819200,
  "created_at" : "2013-09-22 08:43:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009550294, 8.2830029167 ]
  },
  "id_str" : "381552869817987072",
  "text" : "\u00ABIch dachte Journalisten \u00FCberpr\u00FCfen sowas!\u00BB \u2014 \u00ABSagte sie w\u00E4hrend die Druckerschw\u00E4rze der BILD noch an ihren H\u00E4nden klebte\u2026\u00BB",
  "id" : 381552869817987072,
  "created_at" : "2013-09-21 22:57:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096399023, 8.2829911388 ]
  },
  "id_str" : "381519076587470848",
  "text" : "\u00ABWas hast du denn da f\u00FCr ein niedliches Tier?\u00BB \u2014 \u00ABDas ist eine Katze\u2026\u00BB",
  "id" : 381519076587470848,
  "created_at" : "2013-09-21 20:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melissa law",
      "screen_name" : "melini84",
      "indices" : [ 0, 9 ],
      "id_str" : "4822779237",
      "id" : 4822779237
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 10, 18 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096399023, 8.2829911388 ]
  },
  "id_str" : "381518159091892225",
  "text" : "@Melini84 @moeffju stehen ihm die Klamotten nicht?",
  "id" : 381518159091892225,
  "created_at" : "2013-09-21 20:39:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558677, 8.2829801292 ]
  },
  "id_str" : "381474338358431744",
  "text" : "\u00ABDu kannst keine Pornos schauen aber wichst zu Wikipedia-Artikeln. Suchst du da auch den Perfekten?\u00BB\u2014\u00ABCitation needed? Dazu kann ich nicht!\u00BB",
  "id" : 381474338358431744,
  "created_at" : "2013-09-21 17:45:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/rC7LEN5Uqa",
      "expanded_url" : "http:\/\/instagram.com\/p\/eh62GiBwuq\/",
      "display_url" : "instagram.com\/p\/eh62GiBwuq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "381462607460597761",
  "text" : "\u00ABWei\u00DFt du wer noch behauptet hat nur aus beruflichem Interesse zu recherchieren?\u00BB @ Elfenbeinturm http:\/\/t.co\/rC7LEN5Uqa",
  "id" : 381462607460597761,
  "created_at" : "2013-09-21 16:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095703686, 8.2828174252 ]
  },
  "id_str" : "381454924858802176",
  "text" : "\u00ABHier ist \u00FCberhaupt nichts video\u00FCberwacht, schlag mich!\u00BB",
  "id" : 381454924858802176,
  "created_at" : "2013-09-21 16:28:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 38, 46 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/tMMi8FDkzX",
      "expanded_url" : "http:\/\/instagram.com\/p\/eh2_T3hwme\/",
      "display_url" : "instagram.com\/p\/eh2_T3hwme\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095641241, 8.2829543017 ]
  },
  "id_str" : "381454255632441344",
  "text" : "Das ist also diese Paleo-Di\u00E4t von der @moeffju immer erz\u00E4hlt. http:\/\/t.co\/tMMi8FDkzX",
  "id" : 381454255632441344,
  "created_at" : "2013-09-21 16:25:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096718366, 8.283001646 ]
  },
  "id_str" : "381396912844591104",
  "text" : "\u00ABIch bin voll der Rebell. Ich bin sogar bei internationalen Spielen manchmal nicht f\u00FCr Deutschland.\u00BB",
  "id" : 381396912844591104,
  "created_at" : "2013-09-21 12:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/NlAdHmaAt3",
      "expanded_url" : "http:\/\/www.cbc.ca\/m\/touch\/canada\/new-brunswick\/story\/1.1702434",
      "display_url" : "cbc.ca\/m\/touch\/canada\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009668, 8.283083 ]
  },
  "id_str" : "381341560916701184",
  "text" : "\u00ABThat warning comes after some students reported their condom package had been punctured by a staple.\u00BB\n http:\/\/t.co\/NlAdHmaAt3",
  "id" : 381341560916701184,
  "created_at" : "2013-09-21 08:58:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 3, 10 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/M9NKNCwsLB",
      "expanded_url" : "http:\/\/bbc.in\/16fZkgo",
      "display_url" : "bbc.in\/16fZkgo"
    } ]
  },
  "geo" : { },
  "id_str" : "381340737834864640",
  "text" : "RT @McDawg: BBC News - US plane in 1961 'nuclear bomb near-miss' http:\/\/t.co\/M9NKNCwsLB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/M9NKNCwsLB",
        "expanded_url" : "http:\/\/bbc.in\/16fZkgo",
        "display_url" : "bbc.in\/16fZkgo"
      } ]
    },
    "geo" : { },
    "id_str" : "381340366001037312",
    "text" : "BBC News - US plane in 1961 'nuclear bomb near-miss' http:\/\/t.co\/M9NKNCwsLB",
    "id" : 381340366001037312,
    "created_at" : "2013-09-21 08:53:22 +0000",
    "user" : {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "protected" : false,
      "id_str" : "12432262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708707066026860544\/LnGGYNw1_normal.jpg",
      "id" : 12432262,
      "verified" : false
    }
  },
  "id" : 381340737834864640,
  "created_at" : "2013-09-21 08:54:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095314333, 8.2829909019 ]
  },
  "id_str" : "381331067120410624",
  "text" : "\u00ABIch glaube ich muss dich mehr faven f\u00FCr mein Seelenheil.\u00BB",
  "id" : 381331067120410624,
  "created_at" : "2013-09-21 08:16:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381095828267753472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1624597163, 8.6357560386 ]
  },
  "id_str" : "381096188919156736",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 nope, aber ich laufe auch nie \u00FCber den Campus. Immer nur von Niederursel aus zu meinem B\u00FCro und retour.",
  "id" : 381096188919156736,
  "in_reply_to_status_id" : 381095828267753472,
  "created_at" : "2013-09-20 16:43:06 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PttXQSGwhG",
      "expanded_url" : "http:\/\/instagram.com\/p\/efSiSFBwv1\/",
      "display_url" : "instagram.com\/p\/efSiSFBwv1\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "381093245247553537",
  "text" : "\u00ABDas der Riedberg zu Frankfurt geh\u00F6rt: Vanity. W\u00E4r doof f\u00FCr die Uni Frankfurt wenn ihr Campus nicht in\u2026 http:\/\/t.co\/PttXQSGwhG",
  "id" : 381093245247553537,
  "created_at" : "2013-09-20 16:31:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/XO8hAOGzVJ",
      "expanded_url" : "http:\/\/i.imgur.com\/nw3GIEp.gif",
      "display_url" : "i.imgur.com\/nw3GIEp.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "381057514210471936",
  "text" : "p = 0.06 http:\/\/t.co\/XO8hAOGzVJ",
  "id" : 381057514210471936,
  "created_at" : "2013-09-20 14:09:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/7OBQXOL5mB",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3118",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381054121253416961",
  "text" : "Nightmarish http:\/\/t.co\/7OBQXOL5mB",
  "id" : 381054121253416961,
  "created_at" : "2013-09-20 13:55:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/m5mBvO1qqM",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0076510",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381045823192055809",
  "text" : "Metabolic Rate Limits the Effect of Sperm Competition on Mammalian Spermatogenesis http:\/\/t.co\/m5mBvO1qqM",
  "id" : 381045823192055809,
  "created_at" : "2013-09-20 13:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENCODE",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/OTApKw0dRk",
      "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/61754773258\/encode-a-letter-form-a-cog",
      "display_url" : "judgestarling.tumblr.com\/post\/617547732\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381042871706845184",
  "text" : "RT @DanGraur: The threefold obscenity of Big Science, in general, and of #ENCODE, in particular. http:\/\/t.co\/OTApKw0dRk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENCODE",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/OTApKw0dRk",
        "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/61754773258\/encode-a-letter-form-a-cog",
        "display_url" : "judgestarling.tumblr.com\/post\/617547732\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381042430260174848",
    "text" : "The threefold obscenity of Big Science, in general, and of #ENCODE, in particular. http:\/\/t.co\/OTApKw0dRk",
    "id" : 381042430260174848,
    "created_at" : "2013-09-20 13:09:29 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 381042871706845184,
  "created_at" : "2013-09-20 13:11:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/b36Kzug6bd",
      "expanded_url" : "http:\/\/i.imgur.com\/c8g25lK.gif",
      "display_url" : "i.imgur.com\/c8g25lK.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "381041559573000194",
  "text" : "stuck in an infinite hoop http:\/\/t.co\/b36Kzug6bd",
  "id" : 381041559573000194,
  "created_at" : "2013-09-20 13:06:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Lrg3Mki5C0",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/61697945105\/sharing-the-dark-room",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/616979451\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381031730729066497",
  "text" : "If you've ever done a [\u2190\u2199\u2193\u2191\u2192]-ern blot\u2026 http:\/\/t.co\/Lrg3Mki5C0",
  "id" : 381031730729066497,
  "created_at" : "2013-09-20 12:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722861856, 8.6276578296 ]
  },
  "id_str" : "381005859108950016",
  "text" : "\u00ABEure Gruppe f\u00FCr den Staffelmarathon hei\u00DFt MC HaMStR.\u00BB",
  "id" : 381005859108950016,
  "created_at" : "2013-09-20 10:44:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722979022, 8.6276510176 ]
  },
  "id_str" : "381002966872121344",
  "text" : "\u00ABUnd dann hat die App so einen Google-\u00DCbersetzer der Sachen sagt wie 'tiefer!', 'schneller!'\u2026\u00BB \u2014 \u00ABBist du sicher das es um Fencing geht?\u00BB",
  "id" : 381002966872121344,
  "created_at" : "2013-09-20 10:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722880427, 8.6276561501 ]
  },
  "id_str" : "380994787908018176",
  "text" : "\u00ABWei\u00DFt du wo dieses Tool installiert ist?\u00BB \u2014 \u00ABAuf unserem Webserver, als fieses PHP-Gefrickel. Und das ist dazu auch gerade kaputt.\u00BB",
  "id" : 380994787908018176,
  "created_at" : "2013-09-20 10:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 4, 13 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/9Agr1DfEWr",
      "expanded_url" : "http:\/\/i.imgur.com\/E3geLBe.gif",
      "display_url" : "i.imgur.com\/E3geLBe.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "380988965248978944",
  "text" : "Wie @Senficon jeden Abend ins Bett geht http:\/\/t.co\/9Agr1DfEWr",
  "id" : 380988965248978944,
  "created_at" : "2013-09-20 09:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380983827797381120",
  "geo" : { },
  "id_str" : "380988350351429632",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot Das geht sehr gut, so hab ich meine BSc-Thesis zuende gecodet!",
  "id" : 380988350351429632,
  "in_reply_to_status_id" : 380983827797381120,
  "created_at" : "2013-09-20 09:34:35 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380981370752753664",
  "text" : "\u00ABSorry, it's 'all models are wrong, but some are useful', not 'all models are wrong, except mine'\u2026\u00BB",
  "id" : 380981370752753664,
  "created_at" : "2013-09-20 09:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722706508, 8.6276697088 ]
  },
  "id_str" : "380976539237879808",
  "text" : "\u00ABDas ist das bl\u00F6de an Suizid. Man merkt erst das es eine gute Idee gewesen w\u00E4re wenn es sich eigentlich schon nicht mehr lohnt.\u00BB",
  "id" : 380976539237879808,
  "created_at" : "2013-09-20 08:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722905901, 8.6276488802 ]
  },
  "id_str" : "380976265299517440",
  "text" : "\u00ABIch kann euch jetzt feierlich das Cluster \u00FCberlassen. Alle meine Jobs sind fertig. Holt den Sekt!\u00BB",
  "id" : 380976265299517440,
  "created_at" : "2013-09-20 08:46:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380958575314477056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108336757, 8.6879904306 ]
  },
  "id_str" : "380959390222016512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at least it\u2019s a good point, though I feel \u2018omg! Models are wrong!\u2019 is hardly new.",
  "id" : 380959390222016512,
  "in_reply_to_status_id" : 380958575314477056,
  "created_at" : "2013-09-20 07:39:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380956287007064064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0995092591, 8.653377204 ]
  },
  "id_str" : "380957147959660544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at 50% of BUI and it is getting boring. Feels like they had one point that they are now beating to death.",
  "id" : 380957147959660544,
  "in_reply_to_status_id" : 380956287007064064,
  "created_at" : "2013-09-20 07:30:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/380954746900598784\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/QktiN9QiGP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUlsUuzCUAAS4u0.jpg",
      "id_str" : "380954746904793088",
      "id" : 380954746904793088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUlsUuzCUAAS4u0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/QktiN9QiGP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.062707371, 8.5301296713 ]
  },
  "id_str" : "380954746900598784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer is \u2018the dialectic biologist' also only a repetition of this graph in each damn chapter? http:\/\/t.co\/QktiN9QiGP",
  "id" : 380954746900598784,
  "created_at" : "2013-09-20 07:21:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/WnlZbMPbLv",
      "expanded_url" : "http:\/\/instagram.com\/p\/eeQDcBhwsm\/",
      "display_url" : "instagram.com\/p\/eeQDcBhwsm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "380946118957613056",
  "text" : "Luftschacht offen halten http:\/\/t.co\/WnlZbMPbLv",
  "id" : 380946118957613056,
  "created_at" : "2013-09-20 06:46:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 98, 108 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/4S3nBXsUOD",
      "expanded_url" : "https:\/\/medium.com\/pop-of-culture\/f3c95013cfd3",
      "display_url" : "medium.com\/pop-of-culture\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0103164917, 8.2832794126 ]
  },
  "id_str" : "380837046832877568",
  "text" : "\u00ABI\u2019d recently lost my dog, and so I was tapping into a dark muse I\u2019d never tapped into before.\u00BB \u2014 @hughhowey  https:\/\/t.co\/4S3nBXsUOD",
  "id" : 380837046832877568,
  "created_at" : "2013-09-19 23:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1005012927, 8.5708784411 ]
  },
  "id_str" : "380811520726560768",
  "text" : "\u00ABFrag mal Google ob Socken Unterw\u00E4sche sind.\u00BB \u2014 \u00ABNein, frag Siri!\u00BB",
  "id" : 380811520726560768,
  "created_at" : "2013-09-19 21:51:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB",
      "screen_name" : "Lambda_",
      "indices" : [ 0, 8 ],
      "id_str" : "21659638",
      "id" : 21659638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380803777584193536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004638104, 8.5709090531 ]
  },
  "id_str" : "380804253004333056",
  "in_reply_to_user_id" : 21659638,
  "text" : "@Lambda_ h\u00E4tte man dir das nur fr\u00FCher gesagt!",
  "id" : 380804253004333056,
  "in_reply_to_status_id" : 380803777584193536,
  "created_at" : "2013-09-19 21:23:03 +0000",
  "in_reply_to_screen_name" : "Lambda_",
  "in_reply_to_user_id_str" : "21659638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 76, 83 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003223092, 8.5709772502 ]
  },
  "id_str" : "380796704372826112",
  "text" : "\u00ABWir h\u00E4tten uns einen Anwalt gegen die AfD nehmen oder ein Rad Parmesan f\u00FCr @TnaKng kaufen k\u00F6nnen.\u00BB \u2014 \u00ABGuten Appetit!\u00BB",
  "id" : 380796704372826112,
  "created_at" : "2013-09-19 20:53:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 75, 82 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004566939, 8.5709283929 ]
  },
  "id_str" : "380795177486798849",
  "text" : "\u00ABIch habe eine \u00E4rztliche Entscheidung. Ich darf kein Vomex nehmen.\u00BB \u2014 \u00ABDer @nplhse z\u00E4hlt nicht!\u00BB",
  "id" : 380795177486798849,
  "created_at" : "2013-09-19 20:46:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380788331971227648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003150763, 8.5709405481 ]
  },
  "id_str" : "380789025701130240",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ich hab das Gef\u00FChl \u2018The Blind Watchmaker\u2019 wird f\u00FCr dich nichts neues sein. \u2018The Ancestor\u2019s Tale\u2019 war auch noch ganz nett.",
  "id" : 380789025701130240,
  "in_reply_to_status_id" : 380788331971227648,
  "created_at" : "2013-09-19 20:22:33 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380788331971227648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.100461943, 8.5709026098 ]
  },
  "id_str" : "380788537945518080",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ich finde The Selfish Gene &amp; The Extended Phenotype lohnen sich auf jeden Fall heute noch.",
  "id" : 380788537945518080,
  "in_reply_to_status_id" : 380788331971227648,
  "created_at" : "2013-09-19 20:20:36 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bauchbinden",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004447835, 8.5709195305 ]
  },
  "id_str" : "380785237271515136",
  "text" : "\u00ABNa toll, wir haben hier \u2018Jurastudent\u2019, \u2018verr\u00FCckter Wissenschaftler\u2019 und ich? Ich bin einfach nur 'Angeklagter'\u2026\u00BB #bauchbinden",
  "id" : 380785237271515136,
  "created_at" : "2013-09-19 20:07:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dYUe2z8f5U",
      "expanded_url" : "http:\/\/instagram.com\/p\/edCyEWhwjZ\/",
      "display_url" : "instagram.com\/p\/edCyEWhwjZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "380776306033848320",
  "text" : "\u00ABDas ist keins von diesen Auseinandermach-Spielchen.\u00BB \u2014 \u00ABDoch, aber eines was du auch kannst!\u00BB http:\/\/t.co\/dYUe2z8f5U",
  "id" : 380776306033848320,
  "created_at" : "2013-09-19 19:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004783912, 8.5708329282 ]
  },
  "id_str" : "380758897885474816",
  "text" : "\u00ABI could make your bio, though you might end up as: an iron man competitor, drosophilia expert, &amp; 16th person to have ever climbed everest\u00BB",
  "id" : 380758897885474816,
  "created_at" : "2013-09-19 18:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0398087619, 8.45757891 ]
  },
  "id_str" : "380752937129373696",
  "text" : "\u00ABAlthough all theories are eventually wrong, some are not even temporarily right.\u00BB",
  "id" : 380752937129373696,
  "created_at" : "2013-09-19 17:59:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380748782537031680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0040200989, 8.2898708639 ]
  },
  "id_str" : "380749579148611584",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo -&gt; von allen Sites die sie als \u2018wird in RNA translatiert\u2019 identifiziert haben sind 95% non-coding.",
  "id" : 380749579148611584,
  "in_reply_to_status_id" : 380748782537031680,
  "created_at" : "2013-09-19 17:45:48 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380748782537031680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072374687, 8.2830232089 ]
  },
  "id_str" : "380749115074023424",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo \u00ABwe identify approximately 160,000 transcription initiation complexes [\u2026] Only about 5% associate with messenger RNA genes\u00BB",
  "id" : 380749115074023424,
  "in_reply_to_status_id" : 380748782537031680,
  "created_at" : "2013-09-19 17:43:57 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380748782537031680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072374687, 8.2830232089 ]
  },
  "id_str" : "380748965727436801",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo das Abstract des Paper sagt wo die 95% herkommen.",
  "id" : 380748965727436801,
  "in_reply_to_status_id" : 380748782537031680,
  "created_at" : "2013-09-19 17:43:22 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380746617315282944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070381957, 8.2823445182 ]
  },
  "id_str" : "380748338645463040",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo meh, the author mixed up non-coding fraction of genome and non-coding RNAs. ncRNA doesn\u2019t make up 95% of the human genome.",
  "id" : 380748338645463040,
  "in_reply_to_status_id" : 380746617315282944,
  "created_at" : "2013-09-19 17:40:52 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009681567, 8.2830756105 ]
  },
  "id_str" : "380740577975103488",
  "text" : "\u00ABThe [human] genome has only some 10^6 to 10^9 genes.\u00BB I guess this essay is a tad older\u2026",
  "id" : 380740577975103488,
  "created_at" : "2013-09-19 17:10:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0092491319, 8.2824716228 ]
  },
  "id_str" : "380737458402770944",
  "text" : "\u00ABFail early, fail often. You will fail often. And how early you fail depends on how much load is on the cluster.\u00BB",
  "id" : 380737458402770944,
  "created_at" : "2013-09-19 16:57:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1041392055, 8.6581204888 ]
  },
  "id_str" : "380717111783747584",
  "text" : "\u00ABInformieren sie das Zugpersonal \u00FCber ungew\u00F6hnliche Wahrnehmungen\u00BB klingt auch irgendwie trippig.",
  "id" : 380717111783747584,
  "created_at" : "2013-09-19 15:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/x7g9CvmLmu",
      "expanded_url" : "http:\/\/amzn.com\/k\/GuZCkB7UTfy9I3mi-heF1w",
      "display_url" : "amzn.com\/k\/GuZCkB7UTfy9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380713817682219008",
  "text" : "Physics Envy, they say it like it's only a bad thing! http:\/\/t.co\/x7g9CvmLmu Biologists suffer from a bad case of physics envy, and n...",
  "id" : 380713817682219008,
  "created_at" : "2013-09-19 15:23:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/GDYOElgIBP",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/bierologie\/biologie\/2011-07-15\/rettet-die-wirbellosen",
      "display_url" : "scilogs.de\/wblogs\/blog\/bi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "380700270088716288",
  "geo" : { },
  "id_str" : "380702229327388672",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Yep, hatte das richtig im Kopf http:\/\/t.co\/GDYOElgIBP",
  "id" : 380702229327388672,
  "in_reply_to_status_id" : 380700270088716288,
  "created_at" : "2013-09-19 14:37:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 3, 11 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/og4E22goLB",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G3QrhdfLCO8",
      "display_url" : "youtube.com\/watch?v=G3Qrhd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380701637204918275",
  "text" : "RT @BLugger: Flying eagle point of view  http:\/\/t.co\/og4E22goLB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/og4E22goLB",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G3QrhdfLCO8",
        "display_url" : "youtube.com\/watch?v=G3Qrhd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380701074820042752",
    "text" : "Flying eagle point of view  http:\/\/t.co\/og4E22goLB",
    "id" : 380701074820042752,
    "created_at" : "2013-09-19 14:33:03 +0000",
    "user" : {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "protected" : false,
      "id_str" : "14699615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664456759243874304\/UGZuDROe_normal.jpg",
      "id" : 14699615,
      "verified" : true
    }
  },
  "id" : 380701637204918275,
  "created_at" : "2013-09-19 14:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "The Paris Review",
      "screen_name" : "parisreview",
      "indices" : [ 84, 96 ],
      "id_str" : "71256932",
      "id" : 71256932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/2FRGH8YS9o",
      "expanded_url" : "http:\/\/www.booktryst.com\/2011\/06\/butterfly-art-of-vladimir-nabokov-love.html",
      "display_url" : "booktryst.com\/2011\/06\/butter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380699709192826880",
  "text" : "RT @JBYoder: Vladimir Nabokov's drawings of butterflies: http:\/\/t.co\/2FRGH8YS9o h\/t @parisreview",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Paris Review",
        "screen_name" : "parisreview",
        "indices" : [ 71, 83 ],
        "id_str" : "71256932",
        "id" : 71256932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/2FRGH8YS9o",
        "expanded_url" : "http:\/\/www.booktryst.com\/2011\/06\/butterfly-art-of-vladimir-nabokov-love.html",
        "display_url" : "booktryst.com\/2011\/06\/butter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380699264340344832",
    "text" : "Vladimir Nabokov's drawings of butterflies: http:\/\/t.co\/2FRGH8YS9o h\/t @parisreview",
    "id" : 380699264340344832,
    "created_at" : "2013-09-19 14:25:52 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 380699709192826880,
  "created_at" : "2013-09-19 14:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380693459788918784",
  "geo" : { },
  "id_str" : "380699113651593216",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick Ich hoffe bis dahin habt ihr auch Zombie drauf, wie letztes mal versprochen! ;)",
  "id" : 380699113651593216,
  "in_reply_to_status_id" : 380693459788918784,
  "created_at" : "2013-09-19 14:25:16 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 3, 15 ],
      "id_str" : "53560219",
      "id" : 53560219
    }, {
      "name" : "Alice Williamson \uD83C\uDF08",
      "screen_name" : "all_isee",
      "indices" : [ 82, 91 ],
      "id_str" : "385359974",
      "id" : 385359974
    }, {
      "name" : "Open Source Malaria",
      "screen_name" : "O_S_M",
      "indices" : [ 95, 101 ],
      "id_str" : "342023138",
      "id" : 342023138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 32, 44 ]
    }, {
      "text" : "OKCon",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380698232034054144",
  "text" : "RT @openscience: \"Maybe one day #openscience can just be called science again.\" - @all_isee of @O_S_M, at #OKCon [yes!]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alice Williamson \uD83C\uDF08",
        "screen_name" : "all_isee",
        "indices" : [ 65, 74 ],
        "id_str" : "385359974",
        "id" : 385359974
      }, {
        "name" : "Open Source Malaria",
        "screen_name" : "O_S_M",
        "indices" : [ 78, 84 ],
        "id_str" : "342023138",
        "id" : 342023138
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 15, 27 ]
      }, {
        "text" : "OKCon",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380692031427059712",
    "text" : "\"Maybe one day #openscience can just be called science again.\" - @all_isee of @O_S_M, at #OKCon [yes!]",
    "id" : 380692031427059712,
    "created_at" : "2013-09-19 13:57:07 +0000",
    "user" : {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "protected" : false,
      "id_str" : "53560219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459933268746317825\/wrEyqxhT_normal.png",
      "id" : 53560219,
      "verified" : false
    }
  },
  "id" : 380698232034054144,
  "created_at" : "2013-09-19 14:21:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ueoIaapaFt",
      "expanded_url" : "http:\/\/buttonpushingmonkey.files.wordpress.com\/2010\/02\/duckhunt-dog-laugh.gif",
      "display_url" : "\u2026ttonpushingmonkey.files.wordpress.com\/2010\/02\/duckhu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "380696239437656064",
  "geo" : { },
  "id_str" : "380696936967196674",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/ueoIaapaFt",
  "id" : 380696936967196674,
  "in_reply_to_status_id" : 380696239437656064,
  "created_at" : "2013-09-19 14:16:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/d4aIYe9dNl",
      "expanded_url" : "http:\/\/stackoverflow.com\/a\/186967",
      "display_url" : "stackoverflow.com\/a\/186967"
    } ]
  },
  "geo" : { },
  "id_str" : "380695148079763456",
  "text" : "\u00ABdedicate all this code to my wife who will have to support me &amp; our three children &amp; the dog once it gets released\u00BB http:\/\/t.co\/d4aIYe9dNl",
  "id" : 380695148079763456,
  "created_at" : "2013-09-19 14:09:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380669190517977088",
  "geo" : { },
  "id_str" : "380693012885422081",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Ich glaube ich hatte mich damals aber \u00FCber die Verteilung Vertebrates \/ Invertebrates aufgeregt. Da ist die Quote immer noch mies!",
  "id" : 380693012885422081,
  "in_reply_to_status_id" : 380669190517977088,
  "created_at" : "2013-09-19 14:01:01 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lFTKiLVSxL",
      "expanded_url" : "http:\/\/theweek.com\/article\/index\/249833\/a-brief-history-of-newspaper-lingo",
      "display_url" : "theweek.com\/article\/index\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380688972520779776",
  "text" : "A listicle: \u00ABgotcharazzi, in case you were wondering, are paparazzi who may say \"Gotcha!\" when photographing someone\u00BB http:\/\/t.co\/lFTKiLVSxL",
  "id" : 380688972520779776,
  "created_at" : "2013-09-19 13:44:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/NFZFZTV3If",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3117",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380686711581192193",
  "text" : "Economics 101 http:\/\/t.co\/NFZFZTV3If",
  "id" : 380686711581192193,
  "created_at" : "2013-09-19 13:35:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380686449869193216",
  "text" : "\u00ABWas siehst du in diesem Bild?\u00BB \u2013 \u00ABEinen Kaffeefleck!\u00BB \u2013 \u00ABMit dir machen Rorschachtests keinen Spass\u2026\u00BB",
  "id" : 380686449869193216,
  "created_at" : "2013-09-19 13:34:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 14, 19 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380646326246973440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723074174, 8.6276451555 ]
  },
  "id_str" : "380647411238305792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @li5a well it\u2019s the same problem from the bioethics point of view. :)",
  "id" : 380647411238305792,
  "in_reply_to_status_id" : 380646326246973440,
  "created_at" : "2013-09-19 10:59:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 6, 19 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380642088901017600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172288409, 8.6276515723 ]
  },
  "id_str" : "380642496101244928",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @PhilippBayer I already have my data through the PEP. They have consent forms.",
  "id" : 380642496101244928,
  "in_reply_to_status_id" : 380642088901017600,
  "created_at" : "2013-09-19 10:40:17 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380636739544825856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723042893, 8.6276384625 ]
  },
  "id_str" : "380636930247245824",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick die Tickets sind \u00FCbrigens geordert. Frankfurt steht also nichts im Wege. :)",
  "id" : 380636930247245824,
  "in_reply_to_status_id" : 380636739544825856,
  "created_at" : "2013-09-19 10:18:10 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 67, 76 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/qHLPEcO4dd",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075634",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380632123469615104",
  "text" : "E-Readers Are More Effective than Paper for Some with Dyslexia \/cc @Senficon http:\/\/t.co\/qHLPEcO4dd",
  "id" : 380632123469615104,
  "created_at" : "2013-09-19 09:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 64, 74 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ts1wwQ4sBR",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075129",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380622052450766848",
  "text" : "Using StarCraft 2 for Research into Complex Skill Learning. \/cc @Fischblog http:\/\/t.co\/ts1wwQ4sBR",
  "id" : 380622052450766848,
  "created_at" : "2013-09-19 09:19:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380620136723804160",
  "geo" : { },
  "id_str" : "380620407411195904",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick Ich hatte es bef\u00FCrchtet, wenn man seinen Feedreader nicht ordentlich liest\u2026 Aber ich wollte nicht das du es verpasst :)",
  "id" : 380620407411195904,
  "in_reply_to_status_id" : 380620136723804160,
  "created_at" : "2013-09-19 09:12:31 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 48, 59 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/z6fZB3VFKN",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/09\/18\/googles-5-part-documentary-a.html",
      "display_url" : "boingboing.net\/2013\/09\/18\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380618651079958529",
  "text" : "Google's 5-part documentary about The Clash \/cc @spreeblick http:\/\/t.co\/z6fZB3VFKN",
  "id" : 380618651079958529,
  "created_at" : "2013-09-19 09:05:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/jdMZ1a8Tph",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-6g",
      "display_url" : "wp.me\/p1PnkE-6g"
    } ]
  },
  "geo" : { },
  "id_str" : "380610914967638016",
  "text" : "RT @BioMickWatson: Should we sequence everyone at birth? http:\/\/t.co\/jdMZ1a8Tph (an argument against caution)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/jdMZ1a8Tph",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-6g",
        "display_url" : "wp.me\/p1PnkE-6g"
      } ]
    },
    "geo" : { },
    "id_str" : "380608584419008512",
    "text" : "Should we sequence everyone at birth? http:\/\/t.co\/jdMZ1a8Tph (an argument against caution)",
    "id" : 380608584419008512,
    "created_at" : "2013-09-19 08:25:32 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 380610914967638016,
  "created_at" : "2013-09-19 08:34:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0996510173, 8.5313842725 ]
  },
  "id_str" : "380605108402532352",
  "text" : "If your prime example for \u2018genuine altruism\u2019 is a mother sacrificing her life for her children you should take Sociobiology 101\u2026",
  "id" : 380605108402532352,
  "created_at" : "2013-09-19 08:11:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071303788, 8.2831064389 ]
  },
  "id_str" : "380603887549693952",
  "text" : "\u00ABSorry to break the news, aber Jesus war kein Buddhist.\u00BB \u2014 \u00ABOh, so weit bin ich in dem Buch dann wohl noch nicht.\u00BB",
  "id" : 380603887549693952,
  "created_at" : "2013-09-19 08:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0084290049, 8.2826090511 ]
  },
  "id_str" : "380594012174155776",
  "text" : "\u00ABZwei Browser-Fenster nebeneinander \u00F6ffnen um Songtexte ganz anzuzeigen ist ja eine gute Idee. Ich hab immer mit dem gro\u00DFen Zeh gescrollt!\u00BB",
  "id" : 380594012174155776,
  "created_at" : "2013-09-19 07:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380591558824706048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008514128, 8.2828878322 ]
  },
  "id_str" : "380593468894351360",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon viel Erfolg, Frau Wirtschaftsexpertin!",
  "id" : 380593468894351360,
  "in_reply_to_status_id" : 380591558824706048,
  "created_at" : "2013-09-19 07:25:28 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096733834, 8.2829097395 ]
  },
  "id_str" : "380481569754206208",
  "text" : "\u00ABIch fake ja auch nur das ich gerne mit dir schlafe weil ich hoffe dadurch irgendwann Illustrationen verkaufen zu k\u00F6nnen.\u00BB",
  "id" : 380481569754206208,
  "created_at" : "2013-09-19 00:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 3, 17 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/HT1IBcpEVB",
      "expanded_url" : "http:\/\/imgur.com\/a\/kH6yL",
      "display_url" : "imgur.com\/a\/kH6yL"
    } ]
  },
  "geo" : { },
  "id_str" : "380365504202158080",
  "text" : "RT @L3viathan2142: Shorts hacken http:\/\/t.co\/HT1IBcpEVB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETw\u0435\u0435tbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/HT1IBcpEVB",
        "expanded_url" : "http:\/\/imgur.com\/a\/kH6yL",
        "display_url" : "imgur.com\/a\/kH6yL"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 49.2763900404, 7.0237873279 ]
    },
    "id_str" : "380363907917152256",
    "text" : "Shorts hacken http:\/\/t.co\/HT1IBcpEVB",
    "id" : 380363907917152256,
    "created_at" : "2013-09-18 16:13:17 +0000",
    "user" : {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "protected" : false,
      "id_str" : "23305817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1416278793\/Night_Cat_Reloaded_by_l3viathan2142_normal.png",
      "id" : 23305817,
      "verified" : false
    }
  },
  "id" : 380365504202158080,
  "created_at" : "2013-09-18 16:19:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0076624548, 8.282813917 ]
  },
  "id_str" : "380364503726424064",
  "text" : "\u2018The Art of Happiness\u2019 feels a lot like \u2018Rationalizing your emotions without admitting that you used your brain.'",
  "id" : 380364503726424064,
  "created_at" : "2013-09-18 16:15:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0629624301, 8.5343939779 ]
  },
  "id_str" : "380358796071419904",
  "text" : "\u00ABWenn die Biologin dich wieder damit aufzieht das du \u2018Epitheton\u2019 nicht kanntest schlag zur\u00FCck: Frag nach ihrem Lieblings-Artkonzept!\u00BB",
  "id" : 380358796071419904,
  "created_at" : "2013-09-18 15:52:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/2nuP6aYNBa",
      "expanded_url" : "http:\/\/nblo.gs\/PaEHn",
      "display_url" : "nblo.gs\/PaEHn"
    } ]
  },
  "geo" : { },
  "id_str" : "380346509709303808",
  "text" : "RT @JBYoder: Nothing in Biology Makes Sense: Your dinner, or your life? http:\/\/t.co\/2nuP6aYNBa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/2nuP6aYNBa",
        "expanded_url" : "http:\/\/nblo.gs\/PaEHn",
        "display_url" : "nblo.gs\/PaEHn"
      } ]
    },
    "geo" : { },
    "id_str" : "380345981289508866",
    "text" : "Nothing in Biology Makes Sense: Your dinner, or your life? http:\/\/t.co\/2nuP6aYNBa",
    "id" : 380345981289508866,
    "created_at" : "2013-09-18 15:02:03 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 380346509709303808,
  "created_at" : "2013-09-18 15:04:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723135322, 8.6276393357 ]
  },
  "id_str" : "380343415072104448",
  "text" : "Caution: Reading Twitter while walking through a revolving door may cause an infinite loop.",
  "id" : 380343415072104448,
  "created_at" : "2013-09-18 14:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380340245826256896",
  "geo" : { },
  "id_str" : "380340437795348480",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Oh noes, but why?!",
  "id" : 380340437795348480,
  "in_reply_to_status_id" : 380340245826256896,
  "created_at" : "2013-09-18 14:40:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380339091969040385",
  "geo" : { },
  "id_str" : "380339717864054784",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy It's just a conspiracy to get you to download local copies of their dbs!",
  "id" : 380339717864054784,
  "in_reply_to_status_id" : 380339091969040385,
  "created_at" : "2013-09-18 14:37:09 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/uL9vHcgJeO",
      "expanded_url" : "http:\/\/bit.ly\/1br2IGp",
      "display_url" : "bit.ly\/1br2IGp"
    } ]
  },
  "geo" : { },
  "id_str" : "380328511258390528",
  "text" : "RT @PygmyLoris: Why you should never meet your idols, especially if your idol is Richard Dawkins... http:\/\/t.co\/uL9vHcgJeO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/uL9vHcgJeO",
        "expanded_url" : "http:\/\/bit.ly\/1br2IGp",
        "display_url" : "bit.ly\/1br2IGp"
      } ]
    },
    "geo" : { },
    "id_str" : "380326961199194112",
    "text" : "Why you should never meet your idols, especially if your idol is Richard Dawkins... http:\/\/t.co\/uL9vHcgJeO",
    "id" : 380326961199194112,
    "created_at" : "2013-09-18 13:46:28 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 380328511258390528,
  "created_at" : "2013-09-18 13:52:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722901908, 8.6276735781 ]
  },
  "id_str" : "380322487936237568",
  "text" : "\u00ABUff, ich war schon voll lange nicht mehr im Kino.\u00BB \u2014 \u00ABVorsicht, erschreck dich nicht. Die Filme sind jetzt in Farbe.\u00BB",
  "id" : 380322487936237568,
  "created_at" : "2013-09-18 13:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Brunning",
      "screen_name" : "brunns",
      "indices" : [ 3, 10 ],
      "id_str" : "14409295",
      "id" : 14409295
    }, {
      "name" : "EverydaySexism",
      "screen_name" : "EverydaySexism",
      "indices" : [ 119, 134 ],
      "id_str" : "540812894",
      "id" : 540812894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/gTxBeLDeVg",
      "expanded_url" : "http:\/\/bit.ly\/1aKr4bg",
      "display_url" : "bit.ly\/1aKr4bg"
    } ]
  },
  "geo" : { },
  "id_str" : "380307560819355648",
  "text" : "RT @brunns: Game Reviewer Does Her Job by Pointing Out Sexism in GTA 5, is Pilloried for It. http:\/\/t.co\/gTxBeLDeVg CC @everydaysexism",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EverydaySexism",
        "screen_name" : "EverydaySexism",
        "indices" : [ 107, 122 ],
        "id_str" : "540812894",
        "id" : 540812894
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/gTxBeLDeVg",
        "expanded_url" : "http:\/\/bit.ly\/1aKr4bg",
        "display_url" : "bit.ly\/1aKr4bg"
      } ]
    },
    "geo" : { },
    "id_str" : "380302565348761600",
    "text" : "Game Reviewer Does Her Job by Pointing Out Sexism in GTA 5, is Pilloried for It. http:\/\/t.co\/gTxBeLDeVg CC @everydaysexism",
    "id" : 380302565348761600,
    "created_at" : "2013-09-18 12:09:31 +0000",
    "user" : {
      "name" : "Simon Brunning",
      "screen_name" : "brunns",
      "protected" : false,
      "id_str" : "14409295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793123097222213632\/-8PD3aeR_normal.jpg",
      "id" : 14409295,
      "verified" : false
    }
  },
  "id" : 380307560819355648,
  "created_at" : "2013-09-18 12:29:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/03gar2GkNC",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2013\/09\/forget-good-cop-bad-cop-real-psychology.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+%28BPS+Research+Digest%29",
      "display_url" : "bps-research-digest.blogspot.de\/2013\/09\/forget\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380287989810606080",
  "text" : "\u00ABForget good cop, bad cop - here's the real psychology of two-person interrogation\u00BB http:\/\/t.co\/03gar2GkNC",
  "id" : 380287989810606080,
  "created_at" : "2013-09-18 11:11:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 108, 121 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/5ulCtEMKhN",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001661",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380287163499159552",
  "text" : "Generalization &amp; Dilution of Association Results from European GWAS in Pop. of Non-European Ancestry cc @PhilippBayer http:\/\/t.co\/5ulCtEMKhN",
  "id" : 380287163499159552,
  "created_at" : "2013-09-18 11:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172440035, 8.627254199 ]
  },
  "id_str" : "380284586967965696",
  "text" : "\u00ABThis should never happen, so I don\u2019t catch that exception\u00BB aka \u00ABThis will happen &amp; you will be confused because you dismissed that case\u00BB",
  "id" : 380284586967965696,
  "created_at" : "2013-09-18 10:58:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722951389, 8.6276425832 ]
  },
  "id_str" : "380276467734941696",
  "text" : "\u00ABWir k\u00F6nnten als Ersatz einen Papp-Meister Proper aufstellen &amp; \u2018In The Hall of the Mountain King\u2019 in Schleife abspielen lassen.\u00BB",
  "id" : 380276467734941696,
  "created_at" : "2013-09-18 10:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colm Ryan",
      "screen_name" : "colmr",
      "indices" : [ 3, 9 ],
      "id_str" : "14892799",
      "id" : 14892799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/XqM3T1VLV8",
      "expanded_url" : "http:\/\/bioinfo-casl.ucd.ie\/phdsymposium\/",
      "display_url" : "bioinfo-casl.ucd.ie\/phdsymposium\/"
    } ]
  },
  "geo" : { },
  "id_str" : "380273313710620673",
  "text" : "RT @colmr: UCD Computational Biology &amp; Innovation Biology Symposium call for abstracts: http:\/\/t.co\/XqM3T1VLV8 Good conference for PhD stud\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/XqM3T1VLV8",
        "expanded_url" : "http:\/\/bioinfo-casl.ucd.ie\/phdsymposium\/",
        "display_url" : "bioinfo-casl.ucd.ie\/phdsymposium\/"
      } ]
    },
    "geo" : { },
    "id_str" : "380273107857993728",
    "text" : "UCD Computational Biology &amp; Innovation Biology Symposium call for abstracts: http:\/\/t.co\/XqM3T1VLV8 Good conference for PhD students!",
    "id" : 380273107857993728,
    "created_at" : "2013-09-18 10:12:28 +0000",
    "user" : {
      "name" : "Colm Ryan",
      "screen_name" : "colmr",
      "protected" : false,
      "id_str" : "14892799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913503920185647104\/eko54QHf_normal.jpg",
      "id" : 14892799,
      "verified" : false
    }
  },
  "id" : 380273313710620673,
  "created_at" : "2013-09-18 10:13:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380269566951059456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722937226, 8.6276491954 ]
  },
  "id_str" : "380269865917235200",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo but this is also the version where piping some shell commands into each other secures you co-authorship. ;)",
  "id" : 380269865917235200,
  "in_reply_to_status_id" : 380269566951059456,
  "created_at" : "2013-09-18 09:59:35 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PoIJO4WsLJ",
      "expanded_url" : "http:\/\/images3.wikia.nocookie.net\/__cb20121021074139\/revengeristsconsortium\/images\/c\/c9\/Dagron3.jpg",
      "display_url" : "images3.wikia.nocookie.net\/__cb2012102107\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "380266968038649856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229165, 8.6276568206 ]
  },
  "id_str" : "380267481526726656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sorry, can\u2019t help with that, I\u2019m more of a dragon person http:\/\/t.co\/PoIJO4WsLJ",
  "id" : 380267481526726656,
  "in_reply_to_status_id" : 380266968038649856,
  "created_at" : "2013-09-18 09:50:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229165, 8.6276568206 ]
  },
  "id_str" : "380266452965945344",
  "text" : "Fellow commuter this morning: \u00ABYou look like you know a thing about data analysis. I have this project idea\u2026\u00BB",
  "id" : 380266452965945344,
  "created_at" : "2013-09-18 09:46:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721854391, 8.6276268086 ]
  },
  "id_str" : "380257460566888448",
  "text" : "\u00ABFr\u00FCher war es auf dem Riedberg viel sch\u00F6ner. Da hatten wir in den Brombeerhecken noch unsere Gras-Plantage, gew\u00E4ssert aus der Uni.\u00BB",
  "id" : 380257460566888448,
  "created_at" : "2013-09-18 09:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 15, 27 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380245784911818752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723024688, 8.6276370022 ]
  },
  "id_str" : "380246883081662464",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @terrorzicke \u2018\u2026or die trying\u2019?",
  "id" : 380246883081662464,
  "in_reply_to_status_id" : 380245784911818752,
  "created_at" : "2013-09-18 08:28:16 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380245530397253632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0108092436, 8.3597004346 ]
  },
  "id_str" : "380245733238403072",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke buddhistische Attent\u00E4ter vielleicht?",
  "id" : 380245733238403072,
  "in_reply_to_status_id" : 380245530397253632,
  "created_at" : "2013-09-18 08:23:42 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723059614, 8.6276370281 ]
  },
  "id_str" : "380245369973923840",
  "text" : "Wenn Autocomplete dich zu \u2018Mittlerweile bin ich ganz gut in Selbstmordattentaten\u2019 verbessern will\u2026",
  "id" : 380245369973923840,
  "created_at" : "2013-09-18 08:22:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/fOcWyG5Ysl",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/308403-blood\/",
      "display_url" : "radiolab.org\/story\/308403-b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09368, 8.519043 ]
  },
  "id_str" : "380218715151011840",
  "text" : "One hour of Radiolab on blood &lt;3 http:\/\/t.co\/fOcWyG5Ysl",
  "id" : 380218715151011840,
  "created_at" : "2013-09-18 06:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969994, 8.2830487167 ]
  },
  "id_str" : "380107468367732736",
  "text" : "\u00ABIch an deiner Stelle w\u00FCrde mir glauben, denn 4 von 4 Leuten w\u00FCrde gerne ihr Gehirn mit meinem tauschen.\u00BB",
  "id" : 380107468367732736,
  "created_at" : "2013-09-17 23:14:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380098660370878464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096750453, 8.2830822266 ]
  },
  "id_str" : "380102310908923904",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer could be, never visited it. :p",
  "id" : 380102310908923904,
  "in_reply_to_status_id" : 380098660370878464,
  "created_at" : "2013-09-17 22:53:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380096236553912321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096131926, 8.283089865 ]
  },
  "id_str" : "380097248761499648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx! :)",
  "id" : 380097248761499648,
  "in_reply_to_status_id" : 380096236553912321,
  "created_at" : "2013-09-17 22:33:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380096690620858368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096131926, 8.283089865 ]
  },
  "id_str" : "380097116913549312",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng ausnahmsweise habe ich auf deine Expertise verzichtet. Das n\u00E4chste mal wieder!",
  "id" : 380097116913549312,
  "in_reply_to_status_id" : 380096690620858368,
  "created_at" : "2013-09-17 22:33:09 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380096160297267200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722217, 8.2830818933 ]
  },
  "id_str" : "380096225741389824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sold! ;)",
  "id" : 380096225741389824,
  "in_reply_to_status_id" : 380096160297267200,
  "created_at" : "2013-09-17 22:29:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 81, 88 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722217, 8.2830818933 ]
  },
  "id_str" : "380096147853160448",
  "text" : "\u00ABSoll ich seine Krallen aus deinem Schritt entfernen? Oder soll ich daf\u00FCr lieber @TnaKng anrufen?\u00BB",
  "id" : 380096147853160448,
  "created_at" : "2013-09-17 22:29:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380094100277444608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096118564, 8.2830877849 ]
  },
  "id_str" : "380094367731826688",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau haha, okay. I guess doing a PhD is always risky. :p",
  "id" : 380094367731826688,
  "in_reply_to_status_id" : 380094100277444608,
  "created_at" : "2013-09-17 22:22:13 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380093526127558656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096118564, 8.2830877849 ]
  },
  "id_str" : "380094068342419456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in that case I will wait and look for another book out of your library. ;)",
  "id" : 380094068342419456,
  "in_reply_to_status_id" : 380093526127558656,
  "created_at" : "2013-09-17 22:21:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380093221423960064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722841, 8.2832293186 ]
  },
  "id_str" : "380093806781407232",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau wow, I didn\u2019t even know that there are programs for personal health informatics. :)",
  "id" : 380093806781407232,
  "in_reply_to_status_id" : 380093221423960064,
  "created_at" : "2013-09-17 22:19:59 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380093195079520256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722841, 8.2832293186 ]
  },
  "id_str" : "380093367008645121",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus ich warte auf das Wizard-Level. ;)",
  "id" : 380093367008645121,
  "in_reply_to_status_id" : 380093195079520256,
  "created_at" : "2013-09-17 22:18:15 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380092080439037952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722841, 8.2832293186 ]
  },
  "id_str" : "380092948656164864",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau sounds like fun. Already ideas for a PhD? :)",
  "id" : 380092948656164864,
  "in_reply_to_status_id" : 380092080439037952,
  "created_at" : "2013-09-17 22:16:35 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/PH6Ter1exf",
      "expanded_url" : "http:\/\/instagram.com\/p\/bbGrjHvBAD\/",
      "display_url" : "instagram.com\/p\/bbGrjHvBAD\/"
    } ]
  },
  "in_reply_to_status_id_str" : "380092030451318784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096722841, 8.2832293186 ]
  },
  "id_str" : "380092800706310144",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus http:\/\/t.co\/PH6Ter1exf nur mit etwas mehr Bart. ;)",
  "id" : 380092800706310144,
  "in_reply_to_status_id" : 380092030451318784,
  "created_at" : "2013-09-17 22:16:00 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380091534323879936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662904, 8.283004554 ]
  },
  "id_str" : "380092099192193024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: is The Dialectical Biologist good enough to buy a copy?",
  "id" : 380092099192193024,
  "in_reply_to_status_id" : 380091534323879936,
  "created_at" : "2013-09-17 22:13:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/XgVew0gg2j",
      "expanded_url" : "http:\/\/www.bio.uni-frankfurt.de\/43045195\/ak-ebersberger",
      "display_url" : "bio.uni-frankfurt.de\/43045195\/ak-eb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "380091424407949312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662904, 8.283004554 ]
  },
  "id_str" : "380091804450058240",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau Congrats! So you\u2019re doing Health Policy Research? I\u2019m in this group http:\/\/t.co\/XgVew0gg2j",
  "id" : 380091804450058240,
  "in_reply_to_status_id" : 380091424407949312,
  "created_at" : "2013-09-17 22:12:02 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/EMN0WHpKSA",
      "expanded_url" : "https:\/\/scontent-a-iad.xx.fbcdn.net\/hphotos-ash3\/1236086_705358372810935_1024889221_n.jpg",
      "display_url" : "scontent-a-iad.xx.fbcdn.net\/hphotos-ash3\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662904, 8.283004554 ]
  },
  "id_str" : "380091391269150720",
  "text" : "the unflattering valley https:\/\/t.co\/EMN0WHpKSA",
  "id" : 380091391269150720,
  "created_at" : "2013-09-17 22:10:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380090737775239168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662904, 8.283004554 ]
  },
  "id_str" : "380091136968511488",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau nearly a year! It\u2019s great, finished my Master\u2019s &amp; started my PhD in appl. Bioinformatics this May. How are things going for you?",
  "id" : 380091136968511488,
  "in_reply_to_status_id" : 380090737775239168,
  "created_at" : "2013-09-17 22:09:23 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 4, 10 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 41, 51 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "23andMe",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/czTTj0XI7e",
      "expanded_url" : "http:\/\/bit.ly\/1gva8pY",
      "display_url" : "bit.ly\/1gva8pY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662904, 8.283004554 ]
  },
  "id_str" : "380090161075585024",
  "text" : "Hey @dvzrv, that\u2019s something for you! RT @bogdanrau: Looks like my DNA just got a melody! Check it out on #23andMe: http:\/\/t.co\/czTTj0XI7e",
  "id" : 380090161075585024,
  "created_at" : "2013-09-17 22:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 3, 15 ],
      "id_str" : "228015307",
      "id" : 228015307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mac",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/QhL5nnAcyb",
      "expanded_url" : "http:\/\/www.nature.com\/ncomms\/2013\/130917\/ncomms3433\/full\/ncomms3433.html",
      "display_url" : "nature.com\/ncomms\/2013\/13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380088940608638978",
  "text" : "RT @drchriscole: A genome paper of interest to #Mac users ;) http:\/\/t.co\/QhL5nnAcyb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mac",
        "indices" : [ 30, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/QhL5nnAcyb",
        "expanded_url" : "http:\/\/www.nature.com\/ncomms\/2013\/130917\/ncomms3433\/full\/ncomms3433.html",
        "display_url" : "nature.com\/ncomms\/2013\/13\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380087137817075712",
    "text" : "A genome paper of interest to #Mac users ;) http:\/\/t.co\/QhL5nnAcyb",
    "id" : 380087137817075712,
    "created_at" : "2013-09-17 21:53:30 +0000",
    "user" : {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "protected" : false,
      "id_str" : "228015307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847466553230491650\/xGpg9aij_normal.jpg",
      "id" : 228015307,
      "verified" : false
    }
  },
  "id" : 380088940608638978,
  "created_at" : "2013-09-17 22:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096661, 8.2830799433 ]
  },
  "id_str" : "380077995069030400",
  "text" : "\u00ABDer Kater spielt mit dir das Rein-Raus-Spielchen.\u00BB \u2013 \u00ABDumm f\u00FCr ihn: Ich spiele nur das Raus-Spiel.\u00BB",
  "id" : 380077995069030400,
  "created_at" : "2013-09-17 21:17:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/reeder-2\/id697846300?mt=8&uo=4\" rel=\"nofollow\"\u003EReeder 2 on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/MFCgMxsEc6",
      "expanded_url" : "http:\/\/apps.seattletimes.com\/reports\/sea-change\/2013\/sep\/11\/pacific-ocean-perilous-turn-overview\/#.UjZiDGGuUwY.twitter",
      "display_url" : "apps.seattletimes.com\/reports\/sea-ch\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.003164, 8.354586 ]
  },
  "id_str" : "380053724129157120",
  "text" : "Acidification: The Pacific's Perilous Turn http:\/\/t.co\/MFCgMxsEc6",
  "id" : 380053724129157120,
  "created_at" : "2013-09-17 19:40:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 8, 16 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380050942387060736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1027105741, 8.5703504727 ]
  },
  "id_str" : "380051520060137472",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @insideX falsch, dann gibt es Spieleabende &amp; Orgien im Kanzleramt!",
  "id" : 380051520060137472,
  "in_reply_to_status_id" : 380050942387060736,
  "created_at" : "2013-09-17 19:31:58 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380048215694782465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1027105741, 8.5703504727 ]
  },
  "id_str" : "380048419282505728",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX ich nehme die Wahl an!",
  "id" : 380048419282505728,
  "in_reply_to_status_id" : 380048215694782465,
  "created_at" : "2013-09-17 19:19:38 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1041062503, 8.7140111905 ]
  },
  "id_str" : "380045246044069888",
  "text" : "\u00ABHell, your dog knows more about object persistence than this MySQL setup does.\u00BB",
  "id" : 380045246044069888,
  "created_at" : "2013-09-17 19:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380015803094925313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1002914398, 8.7170167665 ]
  },
  "id_str" : "380044123325337601",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Empfehlung f\u00FCrs Kanzleramt?",
  "id" : 380044123325337601,
  "in_reply_to_status_id" : 380015803094925313,
  "created_at" : "2013-09-17 19:02:34 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/0NfQ7CH4ed",
      "expanded_url" : "http:\/\/opinionator.blogs.nytimes.com\/2013\/09\/15\/the-banality-of-systemic-evil\/?hp&_r=1&",
      "display_url" : "opinionator.blogs.nytimes.com\/2013\/09\/15\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379933632900526080",
  "text" : "The Banality of Systemic Evil http:\/\/t.co\/0NfQ7CH4ed",
  "id" : 379933632900526080,
  "created_at" : "2013-09-17 11:43:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379929357159907328",
  "geo" : { },
  "id_str" : "379930837296226304",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab what were the biggest problems you encountered?",
  "id" : 379930837296226304,
  "in_reply_to_status_id" : 379929357159907328,
  "created_at" : "2013-09-17 11:32:25 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/l7C02ayYWT",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0073410",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379927489377619968",
  "text" : "Comprehensive Quantitative Analysis on Privacy Leak Behavior http:\/\/t.co\/l7C02ayYWT",
  "id" : 379927489377619968,
  "created_at" : "2013-09-17 11:19:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379903670051024896",
  "geo" : { },
  "id_str" : "379903963153199104",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab No problem, do you have any sequencing coming up? :)",
  "id" : 379903963153199104,
  "in_reply_to_status_id" : 379903670051024896,
  "created_at" : "2013-09-17 09:45:37 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379901792936407041",
  "geo" : { },
  "id_str" : "379902316960169984",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab for the analysis I had 454 &amp; Illumina, both have their own advantages &amp; disadvantages I'd say. Depends on your study what's better",
  "id" : 379902316960169984,
  "in_reply_to_status_id" : 379901792936407041,
  "created_at" : "2013-09-17 09:39:05 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379901792936407041",
  "geo" : { },
  "id_str" : "379901993013088256",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I've never done a library prep myself, neither for 454 nor Illumina, so I don't know how they compare in the wet lab.",
  "id" : 379901993013088256,
  "in_reply_to_status_id" : 379901792936407041,
  "created_at" : "2013-09-17 09:37:48 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379901453952761856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722749116, 8.6276524487 ]
  },
  "id_str" : "379901630805999616",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab do you mean on the wetlab side of things or on the analysis side?",
  "id" : 379901630805999616,
  "in_reply_to_status_id" : 379901453952761856,
  "created_at" : "2013-09-17 09:36:21 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379899915528204288",
  "geo" : { },
  "id_str" : "379900387404173312",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab Currently I'm working on a lichen genome, so I'm still working on fungi on at least some level!",
  "id" : 379900387404173312,
  "in_reply_to_status_id" : 379899915528204288,
  "created_at" : "2013-09-17 09:31:25 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379899915528204288",
  "geo" : { },
  "id_str" : "379900299768381440",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab Great, let me know if I can be of any help! If you're doing bioinformatics there's no need to be too picky about your organisms ;)",
  "id" : 379900299768381440,
  "in_reply_to_status_id" : 379899915528204288,
  "created_at" : "2013-09-17 09:31:04 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "entropy",
      "screen_name" : "en_tropy",
      "indices" : [ 0, 9 ],
      "id_str" : "583904348",
      "id" : 583904348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379891378840289281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722957292, 8.6276500804 ]
  },
  "id_str" : "379895171309379584",
  "in_reply_to_user_id" : 583904348,
  "text" : "@en_tropy nope, gerade getestet.",
  "id" : 379895171309379584,
  "in_reply_to_status_id" : 379891378840289281,
  "created_at" : "2013-09-17 09:10:41 +0000",
  "in_reply_to_screen_name" : "en_tropy",
  "in_reply_to_user_id_str" : "583904348",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 8, 18 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379890732095401984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722979179, 8.6276449421 ]
  },
  "id_str" : "379891065912057856",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma @prauscher unser Server im Cluster, von Bash direkt aus geht es. o_O",
  "id" : 379891065912057856,
  "in_reply_to_status_id" : 379890732095401984,
  "created_at" : "2013-09-17 08:54:22 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722979179, 8.6276449421 ]
  },
  "id_str" : "379890409109221376",
  "text" : "Python, MySQLdb: open conn -&gt; insert -&gt; select inserted data -&gt; works. After closing &amp; reopening the conn the table is empty. autocommit on\u2026",
  "id" : 379890409109221376,
  "created_at" : "2013-09-17 08:51:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 64, 74 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/pTWq3gDuKx",
      "expanded_url" : "http:\/\/mobile.reuters.com\/article\/idUSBRE98F0DI20130916?feedType=RSS&irpc=932",
      "display_url" : "mobile.reuters.com\/article\/idUSBR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379865538639724544",
  "text" : "\"Man shot in Russia in argument over Kant\" You better watch out @fischblog!  http:\/\/t.co\/pTWq3gDuKx",
  "id" : 379865538639724544,
  "created_at" : "2013-09-17 07:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/PSZ4Cgn3mA",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/FAyyaFfibmw\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379864795459354624",
  "text" : "The history of critical hits: \u00ABControlling the rulebooks does not enable you to stop a good idea\u00BB http:\/\/t.co\/PSZ4Cgn3mA",
  "id" : 379864795459354624,
  "created_at" : "2013-09-17 07:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/TIBx90Y444",
      "expanded_url" : "http:\/\/feedly.com\/k\/182g6xg",
      "display_url" : "feedly.com\/k\/182g6xg"
    } ]
  },
  "geo" : { },
  "id_str" : "379863557753831424",
  "text" : "I think this dog you sold me knows what I did http:\/\/t.co\/TIBx90Y444",
  "id" : 379863557753831424,
  "created_at" : "2013-09-17 07:05:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/GLbO1hNQtM",
      "expanded_url" : "http:\/\/instagram.com\/p\/eUts8IBwv1\/",
      "display_url" : "instagram.com\/p\/eUts8IBwv1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "379604128479334400",
  "text" : "My first look at Radix. Just 6 months after finishing my thesis on their transcriptomes! http:\/\/t.co\/GLbO1hNQtM",
  "id" : 379604128479334400,
  "created_at" : "2013-09-16 13:54:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379277304758681600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.098487651, 8.640235858 ]
  },
  "id_str" : "379277547256971264",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @Senficon S1 die gleich in Hbf Einf\u00E4hrt. Hinterher Wagen.",
  "id" : 379277547256971264,
  "in_reply_to_status_id" : 379277304758681600,
  "created_at" : "2013-09-15 16:16:28 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 8, 18 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/CcYy786wMT",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Pseudobiceros_bedfordi",
      "display_url" : "en.wikipedia.org\/wiki\/Pseudobic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.102929, 8.55869 ]
  },
  "id_str" : "379276077786755072",
  "text" : "One for @fischblog: Penis fencing in Pseudobiceros bedfordi http:\/\/t.co\/CcYy786wMT",
  "id" : 379276077786755072,
  "created_at" : "2013-09-15 16:10:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/6kwaFwWa0g",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Antechinus",
      "display_url" : "en.wikipedia.org\/wiki\/Antechinus"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.000338, 8.241665 ]
  },
  "id_str" : "379272786856124416",
  "text" : "Death by snu snu http:\/\/t.co\/6kwaFwWa0g",
  "id" : 379272786856124416,
  "created_at" : "2013-09-15 15:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378822084732157952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096422967, 8.28301612 ]
  },
  "id_str" : "378822599629111296",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng yay! Gratulation :)",
  "id" : 378822599629111296,
  "in_reply_to_status_id" : 378822084732157952,
  "created_at" : "2013-09-14 10:08:40 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sanjay Srivastava",
      "screen_name" : "hardsci",
      "indices" : [ 3, 11 ],
      "id_str" : "102768569",
      "id" : 102768569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378814442534096897",
  "text" : "RT @hardsci: Proposal: every scientific paper has to end with \"Or maybe this will turn out to be unreplicable noise\" in font size of (3000 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378606497900396545",
    "text" : "Proposal: every scientific paper has to end with \"Or maybe this will turn out to be unreplicable noise\" in font size of (3000 \u00F7 N)",
    "id" : 378606497900396545,
    "created_at" : "2013-09-13 19:49:57 +0000",
    "user" : {
      "name" : "Sanjay Srivastava",
      "screen_name" : "hardsci",
      "protected" : false,
      "id_str" : "102768569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598267444801634304\/p9_J7M8d_normal.jpg",
      "id" : 102768569,
      "verified" : false
    }
  },
  "id" : 378814442534096897,
  "created_at" : "2013-09-14 09:36:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095797853, 8.2831061658 ]
  },
  "id_str" : "378647094279811072",
  "text" : "\u00ABDu schaust mich an als sei ich Kuschel-Hitler!\u00BB \u2014 \u00ABEs war auch nicht alles schlecht unter Kuschel-Hitler. Der wollte ja auch das BGE!\u00BB",
  "id" : 378647094279811072,
  "created_at" : "2013-09-13 22:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096172296, 8.2828971377 ]
  },
  "id_str" : "378642178983346176",
  "text" : "\u00ABDie Wikipedia hat sogar schon einen Paragraph \u00FCber den recreational use von Vomex!\u00BB",
  "id" : 378642178983346176,
  "created_at" : "2013-09-13 22:11:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378589775185600512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095555057, 8.2829600892 ]
  },
  "id_str" : "378595399839543297",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj frag mal den @PhilippBayer, der hatte dazu mal gebloggt.",
  "id" : 378595399839543297,
  "in_reply_to_status_id" : 378589775185600512,
  "created_at" : "2013-09-13 19:05:51 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 3, 13 ],
      "id_str" : "16486812",
      "id" : 16486812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378587470260350976",
  "text" : "RT @DoctorZen: \"What was the biggest surprise of the research?\" \"We didn\u2019t expect this to be as depressing as it turned out to be.\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/QUpEL1Csbo",
        "expanded_url" : "http:\/\/nyti.ms\/1gbf1V3",
        "display_url" : "nyti.ms\/1gbf1V3"
      } ]
    },
    "geo" : { },
    "id_str" : "378586650017677313",
    "text" : "\"What was the biggest surprise of the research?\" \"We didn\u2019t expect this to be as depressing as it turned out to be.\" http:\/\/t.co\/QUpEL1Csbo",
    "id" : 378586650017677313,
    "created_at" : "2013-09-13 18:31:05 +0000",
    "user" : {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "protected" : false,
      "id_str" : "16486812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821882802064867329\/7dtVmJ-0_normal.jpg",
      "id" : 16486812,
      "verified" : false
    }
  },
  "id" : 378587470260350976,
  "created_at" : "2013-09-13 18:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6kMlcuxrwd",
      "expanded_url" : "http:\/\/www.stuartmcmillen.com\/comics_en\/rat-park\/",
      "display_url" : "stuartmcmillen.com\/comics_en\/rat-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378529999462346752",
  "text" : "A comic on the science of addiction: Rat Park http:\/\/t.co\/6kMlcuxrwd",
  "id" : 378529999462346752,
  "created_at" : "2013-09-13 14:45:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073734675, 8.2831479463 ]
  },
  "id_str" : "378508976205627393",
  "text" : "Die SPD macht in Mainz-Kastel damit Werbung das ihr Direktkandidat am 11.11. geboren ist\u2026",
  "id" : 378508976205627393,
  "created_at" : "2013-09-13 13:22:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378507535608606720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073734675, 8.2831479463 ]
  },
  "id_str" : "378507900228227072",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich to me that sounds like \u2018look people are idiots, everywhere!\u2019 I\u2019d love that!",
  "id" : 378507900228227072,
  "in_reply_to_status_id" : 378507535608606720,
  "created_at" : "2013-09-13 13:18:10 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/reeder-2\/id697846300?mt=8&uo=4\" rel=\"nofollow\"\u003EReeder 2 on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/nwKy2Ls0IY",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2013\/sep\/13\/friday-13th-flight-666-hel",
      "display_url" : "theguardian.com\/world\/2013\/sep\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.084188, 8.501605 ]
  },
  "id_str" : "378505958051569664",
  "text" : "Slightly jealous about that job title: 'professor of comparative folklore' sounds like lots of fun http:\/\/t.co\/nwKy2Ls0IY",
  "id" : 378505958051569664,
  "created_at" : "2013-09-13 13:10:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/reeder-2\/id697846300?mt=8&uo=4\" rel=\"nofollow\"\u003EReeder 2 on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 95, 104 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/VSWpFc37rC",
      "expanded_url" : "http:\/\/rss.sciam.com\/~r\/all-blogs\/feed\/~3\/ByXq2t_p5_I\/",
      "display_url" : "rss.sciam.com\/~r\/all-blogs\/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.087808, 8.512799 ]
  },
  "id_str" : "378502961317838848",
  "text" : "The Survival of Humanity: \u00ABInvest in space station research\u00BB (just ignore the EP bullshit) \/cc @drahflow  http:\/\/t.co\/VSWpFc37rC",
  "id" : 378502961317838848,
  "created_at" : "2013-09-13 12:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/DoAD2hftbN",
      "expanded_url" : "http:\/\/instagram.com\/p\/eMlgsNhwqj\/",
      "display_url" : "instagram.com\/p\/eMlgsNhwqj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1187630771, 8.6508889219 ]
  },
  "id_str" : "378459925632274432",
  "text" : "Breaking News @ Uni Campus Bockenheim http:\/\/t.co\/DoAD2hftbN",
  "id" : 378459925632274432,
  "created_at" : "2013-09-13 10:07:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/reeder-2\/id697846300?mt=8&uo=4\" rel=\"nofollow\"\u003EReeder 2 on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/W0CQtPbQl2",
      "expanded_url" : "http:\/\/cellularscale.blogspot.com\/2013\/09\/use-imposter-syndrome-to-become.html",
      "display_url" : "cellularscale.blogspot.com\/2013\/09\/use-im\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378448802568732672",
  "text" : "\u00ABUse Imposter Syndrome to become an excellent grad student\u00BB Please don't\u2026 m( http:\/\/t.co\/W0CQtPbQl2",
  "id" : 378448802568732672,
  "created_at" : "2013-09-13 09:23:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378442847822692352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085594331, 8.2830582457 ]
  },
  "id_str" : "378443692610428928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch I just hope it doesn\u2019t take another 4 months. We\u2019re already nearing year one of the PR limbo.",
  "id" : 378443692610428928,
  "in_reply_to_status_id" : 378442847822692352,
  "created_at" : "2013-09-13 09:03:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378440799056588801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096368372, 8.2830659606 ]
  },
  "id_str" : "378442494608154624",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer @helgerausch let\u2019s see whether all reviewers will read the right version this time\u2026",
  "id" : 378442494608154624,
  "in_reply_to_status_id" : 378440799056588801,
  "created_at" : "2013-09-13 08:58:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378441987571339264",
  "text" : "Yay, my exome is ready! \\o\/",
  "id" : 378441987571339264,
  "created_at" : "2013-09-13 08:56:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 64, 77 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 78, 87 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 88, 100 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378437509166153729",
  "text" : "In other words: I\u2019m slightly drunk, but the revision is out! cc @PhilippBayer @Senficon @helgerausch",
  "id" : 378437509166153729,
  "created_at" : "2013-09-13 08:38:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378434097565405184",
  "text" : "Editorial Manager\u2026 the best reason to have stiff drinks before 11am\u2026",
  "id" : 378434097565405184,
  "created_at" : "2013-09-13 08:24:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098160841, 8.283062093 ]
  },
  "id_str" : "378419564230754304",
  "text" : "\u00ABYeah, I know, I was quite absent over the last days. But only because I was mastering the high art of giving zero fucks.\u00BB",
  "id" : 378419564230754304,
  "created_at" : "2013-09-13 07:27:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/kpPrbvzlvF",
      "expanded_url" : "http:\/\/i.imgur.com\/xb0FU.gif",
      "display_url" : "i.imgur.com\/xb0FU.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378282005374701569",
  "text" : "train wreck relationships http:\/\/t.co\/kpPrbvzlvF",
  "id" : 378282005374701569,
  "created_at" : "2013-09-12 22:20:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378280776405504000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378280810312658944",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus okay, great :)",
  "id" : 378280810312658944,
  "in_reply_to_status_id" : 378280776405504000,
  "created_at" : "2013-09-12 22:15:47 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378278389150265344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378278892714614784",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus cheers! btw. no letter so far. let me know if it should come back to you. our postal workers tend to drive me into going postal\u2026",
  "id" : 378278892714614784,
  "in_reply_to_status_id" : 378278389150265344,
  "created_at" : "2013-09-12 22:08:10 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378275494023548928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009674814, 8.283011872 ]
  },
  "id_str" : "378275594557206528",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus oh noes, good luck that it will arrive tomorrow!",
  "id" : 378275594557206528,
  "in_reply_to_status_id" : 378275494023548928,
  "created_at" : "2013-09-12 21:55:04 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0051902218, 8.2899106273 ]
  },
  "id_str" : "378216678540468224",
  "text" : "De novo assembly: taking a trip down high memory lane",
  "id" : 378216678540468224,
  "created_at" : "2013-09-12 18:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085984819, 8.2830122392 ]
  },
  "id_str" : "378189703117565952",
  "text" : "Aushang an der katholischen Kirche gegen\u00FCber: \u00ABDie beste Art, die Welt in Brand zu setzen, ist, selbst zu Brennen.\u00BB",
  "id" : 378189703117565952,
  "created_at" : "2013-09-12 16:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377920461763387392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096606566, 8.2830226597 ]
  },
  "id_str" : "377921700064935936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I like the happiness one!",
  "id" : 377921700064935936,
  "in_reply_to_status_id" : 377920461763387392,
  "created_at" : "2013-09-11 22:28:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XEtpMU9dRb",
      "expanded_url" : "http:\/\/rigsomelight.com\/2013\/09\/09\/frameless-geodesic-dome.html",
      "display_url" : "rigsomelight.com\/2013\/09\/09\/fra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377773348521926656",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Wir k\u00F6nnten \u00FCbrigens eine Schlaftomate bauen auf die Buckminster Fuller stolz w\u00E4re! http:\/\/t.co\/XEtpMU9dRb",
  "id" : 377773348521926656,
  "created_at" : "2013-09-11 12:39:19 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/xAyNSvarYl",
      "expanded_url" : "http:\/\/movies.nytimes.com\/2012\/08\/24\/movies\/sleepwalk-with-me-by-the-comedian-mike-birbiglia.html?_r=0",
      "display_url" : "movies.nytimes.com\/2012\/08\/24\/mov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377772812447916032",
  "text" : "Speaking of! \u00ABI\u2019m not going to get married until I\u2019m sure that nothing else good can happen in my life\u00BB This was fun: http:\/\/t.co\/xAyNSvarYl",
  "id" : 377772812447916032,
  "created_at" : "2013-09-11 12:37:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377770929201242112",
  "text" : "\u00ABOh, facebook sagt, wir haben uns am 11. September verlobt! Well played!\u00BB",
  "id" : 377770929201242112,
  "created_at" : "2013-09-11 12:29:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377738956701728768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722676711, 8.6276222949 ]
  },
  "id_str" : "377744546182221825",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv I don\u2019t mind that, but traveling by train was too challenging iirc. :p",
  "id" : 377744546182221825,
  "in_reply_to_status_id" : 377738956701728768,
  "created_at" : "2013-09-11 10:44:52 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377730194184093696",
  "geo" : { },
  "id_str" : "377730530713694208",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv So I probably should someone with a car to drive me up there to listen to myself in 6chan :D",
  "id" : 377730530713694208,
  "in_reply_to_status_id" : 377730194184093696,
  "created_at" : "2013-09-11 09:49:11 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377728274342088704",
  "geo" : { },
  "id_str" : "377728587022868480",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv Awesome, Waldeck it is? And when exactly?",
  "id" : 377728587022868480,
  "in_reply_to_status_id" : 377728274342088704,
  "created_at" : "2013-09-11 09:41:27 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/PpnKQoAQpk",
      "expanded_url" : "http:\/\/www.reactiongifs.us\/wp-content\/uploads\/2013\/02\/fist_bump_shawn_gus_psych.gif",
      "display_url" : "reactiongifs.us\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377728153223176192",
  "geo" : { },
  "id_str" : "377728468726710272",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv http:\/\/t.co\/PpnKQoAQpk ;)",
  "id" : 377728468726710272,
  "in_reply_to_status_id" : 377728153223176192,
  "created_at" : "2013-09-11 09:40:59 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HhUN1DM0eh",
      "expanded_url" : "http:\/\/www.reactiongifs.us\/wp-content\/uploads\/2013\/06\/slap_psych.gif",
      "display_url" : "reactiongifs.us\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377722033695506432",
  "text" : "\u00ABOur next book will be called 'How to do Bioinformatics without developing the urge to slap someone'.\u00BB http:\/\/t.co\/HhUN1DM0eh",
  "id" : 377722033695506432,
  "created_at" : "2013-09-11 09:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377702067064041472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723827073, 8.627614855 ]
  },
  "id_str" : "377710014947155968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, great :)",
  "id" : 377710014947155968,
  "in_reply_to_status_id" : 377702067064041472,
  "created_at" : "2013-09-11 08:27:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377693969884254209",
  "geo" : { },
  "id_str" : "377694450840903680",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer probably! Btw: did you make progress with the revision? Though we were given yet another 45 days I'd rather make it quick",
  "id" : 377694450840903680,
  "in_reply_to_status_id" : 377693969884254209,
  "created_at" : "2013-09-11 07:25:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377691456221102081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722594545, 8.6276371002 ]
  },
  "id_str" : "377692561793875969",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer either Facebook\u2019s network analysis sucks or it\u2019s sentiment of how close afd\u2019s nonsense resembles that of some pirates.",
  "id" : 377692561793875969,
  "in_reply_to_status_id" : 377691456221102081,
  "created_at" : "2013-09-11 07:18:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "der LUSTIGE Wellensittich",
      "screen_name" : "FR31H31T",
      "indices" : [ 0, 9 ],
      "id_str" : "73747798",
      "id" : 73747798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/RPWzu7bwI0",
      "expanded_url" : "http:\/\/m.xkcd.com",
      "display_url" : "m.xkcd.com"
    } ]
  },
  "in_reply_to_status_id_str" : "377677252659777537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0940164845, 8.6069588366 ]
  },
  "id_str" : "377678621689020416",
  "in_reply_to_user_id" : 73747798,
  "text" : "@FR31H31T http:\/\/t.co\/RPWzu7bwI0",
  "id" : 377678621689020416,
  "in_reply_to_status_id" : 377677252659777537,
  "created_at" : "2013-09-11 06:22:55 +0000",
  "in_reply_to_screen_name" : "FR31H31T",
  "in_reply_to_user_id_str" : "73747798",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096975477, 8.2831079556 ]
  },
  "id_str" : "377544769402327040",
  "text" : "Related: The openSNP paper is doing 2nd round of revisions in part cause a reviewer sent comments on original instead of revised manuscript\u2026",
  "id" : 377544769402327040,
  "created_at" : "2013-09-10 21:31:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/3S35xHP6ya",
      "expanded_url" : "http:\/\/bjoern.brembs.net\/2013\/09\/the-cost-of-the-rejection-resubmission-cycle\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "bjoern.brembs.net\/2013\/09\/the-co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009698, 8.283108 ]
  },
  "id_str" : "377543319070720001",
  "text" : "And there is one more thing: The cost of the rejection-resubmission cycle http:\/\/t.co\/3S35xHP6ya",
  "id" : 377543319070720001,
  "created_at" : "2013-09-10 21:25:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/BgKMPlyNUP",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/absolutely-maybe\/2013\/09\/10\/opening-a-can-of-data-sharing-worms\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/absolutely-may\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009669, 8.28304 ]
  },
  "id_str" : "377542025547358208",
  "text" : "Continuing Doom &amp; Gloom in Research: Opening a can of data-sharing worms  http:\/\/t.co\/BgKMPlyNUP",
  "id" : 377542025547358208,
  "created_at" : "2013-09-10 21:20:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957417, 8.282940718 ]
  },
  "id_str" : "377509155810320384",
  "text" : "Good thing I have a csv-file describing all other csv-files generated during my master\u2019s thesis. Otherwise I\u2019d be lost writing the paper\u2026",
  "id" : 377509155810320384,
  "created_at" : "2013-09-10 19:09:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 0, 13 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377476937976795137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096961447, 8.283032851 ]
  },
  "id_str" : "377477362428153856",
  "in_reply_to_user_id" : 77907514,
  "text" : "@ejwillingham though academia is just turning into business without the benefit of getting paid money to make the suffering worthwhile. ;)",
  "id" : 377477362428153856,
  "in_reply_to_status_id" : 377476937976795137,
  "created_at" : "2013-09-10 17:03:11 +0000",
  "in_reply_to_screen_name" : "ejwillingham",
  "in_reply_to_user_id_str" : "77907514",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "377476738806464512",
  "text" : "After reading this I just want to curl up in bed and cry over the poor life decisions I made\u2026",
  "id" : 377476738806464512,
  "created_at" : "2013-09-10 17:00:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MZogEXk2uY",
      "expanded_url" : "http:\/\/crypto.junod.info\/2013\/09\/09\/an-aspiring-scientists-frustration-with-modern-day-academia-a-resignation\/",
      "display_url" : "crypto.junod.info\/2013\/09\/09\/an-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "377476342532816896",
  "text" : "The failed state of academia: \u00ABit\u2019s actually surprising that *any* scientific research still gets done these days.\u00BB http:\/\/t.co\/MZogEXk2uY",
  "id" : 377476342532816896,
  "created_at" : "2013-09-10 16:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0151422506, 8.2750978481 ]
  },
  "id_str" : "377174248437329920",
  "text" : "Publication-driven testing aka \u2018never compiled, even if it would the results would be off by a factor of 2\u2019\u2026",
  "id" : 377174248437329920,
  "created_at" : "2013-09-09 20:58:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377129002999107584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097071773, 8.2831187508 ]
  },
  "id_str" : "377130537837924352",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus that\u2019s dedication! :)",
  "id" : 377130537837924352,
  "in_reply_to_status_id" : 377129002999107584,
  "created_at" : "2013-09-09 18:05:01 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096606741, 8.2829759045 ]
  },
  "id_str" : "377128475540619264",
  "text" : "After a day\u2019s worth of debugging other people\u2019s R code I just want to die a quicker death &amp; promise I will never make fun of Perl again\u2026",
  "id" : 377128475540619264,
  "created_at" : "2013-09-09 17:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377084975197065216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096798231, 8.2830826918 ]
  },
  "id_str" : "377122267995852800",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus goodbye productivity for a couple of weeks? ;)",
  "id" : 377122267995852800,
  "in_reply_to_status_id" : 377084975197065216,
  "created_at" : "2013-09-09 17:32:09 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/hCd0loiOpW",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/sep\/08\/wall-street-versus-poor-in-america",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376983186418323456",
  "text" : "\u00ABWhen you're wealthy you make mistakes. When you are poor you go to jail\u00BB http:\/\/t.co\/hCd0loiOpW",
  "id" : 376983186418323456,
  "created_at" : "2013-09-09 08:19:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/BFRcN96qhp",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2013\/09\/08\/the-dignity-of-a-porn-star\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376975661719498752",
  "text" : "The Dignity of a Porn Star http:\/\/t.co\/BFRcN96qhp",
  "id" : 376975661719498752,
  "created_at" : "2013-09-09 07:49:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 22, 34 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376975159480958976",
  "geo" : { },
  "id_str" : "376975421662720000",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus @PhilippBayer @helgerausch Great, thanks a lot! I wished the university bureaucracy would work that fast! ;)",
  "id" : 376975421662720000,
  "in_reply_to_status_id" : 376975159480958976,
  "created_at" : "2013-09-09 07:48:39 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376833290931806208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009700504, 8.2831586629 ]
  },
  "id_str" : "376833607287197696",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng Doktor Rant (in memoriam Piraten-Wahlwerbespot 2009)",
  "id" : 376833607287197696,
  "in_reply_to_status_id" : 376833290931806208,
  "created_at" : "2013-09-08 22:25:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 3, 17 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Merkel",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "Greens",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376831098099343361",
  "text" : "RT @kai_arzheimer: #Merkel's inevitable victory? Featuring incredibly plummeting #Greens &amp; record readings on the Merkel-O-Meter http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Merkel",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Greens",
        "indices" : [ 62, 69 ]
      }, {
        "text" : "btw13",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/llNwXZBXUi",
        "expanded_url" : "http:\/\/buff.ly\/18NeRPs",
        "display_url" : "buff.ly\/18NeRPs"
      } ]
    },
    "geo" : { },
    "id_str" : "376799662646525952",
    "text" : "#Merkel's inevitable victory? Featuring incredibly plummeting #Greens &amp; record readings on the Merkel-O-Meter http:\/\/t.co\/llNwXZBXUi #btw13",
    "id" : 376799662646525952,
    "created_at" : "2013-09-08 20:10:14 +0000",
    "user" : {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "protected" : false,
      "id_str" : "16736320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74112233\/kai_1_normal.jpg",
      "id" : 16736320,
      "verified" : false
    }
  },
  "id" : 376831098099343361,
  "created_at" : "2013-09-08 22:15:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 10, 24 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376830032565764098",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376830691457380352",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @kai_arzheimer I don\u2019t really care for that. But seeing bayesian modeling &amp; R in the wild makes my statistics heart happy!",
  "id" : 376830691457380352,
  "in_reply_to_status_id" : 376830032565764098,
  "created_at" : "2013-09-08 22:13:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 10, 24 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376827788525076480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376829342124625920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @kai_arzheimer bayesian modeling &amp; ggplot2(?). Glad to see that you\u2019re reading the good stuff now! ;)",
  "id" : 376829342124625920,
  "in_reply_to_status_id" : 376827788525076480,
  "created_at" : "2013-09-08 22:08:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thesilenceofanimals",
      "indices" : [ 62, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/VHpYQyQOSg",
      "expanded_url" : "http:\/\/amzn.com\/k\/6j0kk-2iTRC_6n8WdMHvcA",
      "display_url" : "amzn.com\/k\/6j0kk-2iTRC_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376825625073709057",
  "text" : "On making the human animal unique: Knowledge &amp; Experience #thesilenceofanimals http:\/\/t.co\/VHpYQyQOSg If there is anything unique abo...",
  "id" : 376825625073709057,
  "created_at" : "2013-09-08 21:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "silenceofanimals",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376824632105775104",
  "text" : "\u00ABTo think of humans as freedom-loving you must be ready to view nearly all of history as a mistake.\u00BB #silenceofanimals",
  "id" : 376824632105775104,
  "created_at" : "2013-09-08 21:49:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376507900354519040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096956642, 8.2830417787 ]
  },
  "id_str" : "376508515508305920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay :)",
  "id" : 376508515508305920,
  "in_reply_to_status_id" : 376507900354519040,
  "created_at" : "2013-09-08 00:53:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376506843406671872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096998458, 8.2830732084 ]
  },
  "id_str" : "376506961279582209",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer this is for now because we want to add a bunch or in general?",
  "id" : 376506961279582209,
  "in_reply_to_status_id" : 376506843406671872,
  "created_at" : "2013-09-08 00:47:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376506680541851648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096998458, 8.2830732084 ]
  },
  "id_str" : "376506798075052032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, will start with those then. :)",
  "id" : 376506798075052032,
  "in_reply_to_status_id" : 376506680541851648,
  "created_at" : "2013-09-08 00:46:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376504736687472640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096964253, 8.2830330707 ]
  },
  "id_str" : "376506502573719552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good luck with the revision. Did you do anything in terms of phenotype models? I would start working in a couple of hours.",
  "id" : 376506502573719552,
  "in_reply_to_status_id" : 376504736687472640,
  "created_at" : "2013-09-08 00:45:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376493724697493504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097292704, 8.2832368108 ]
  },
  "id_str" : "376493946891157505",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer otherwise you would just cause traffic jams!",
  "id" : 376493946891157505,
  "in_reply_to_status_id" : 376493724697493504,
  "created_at" : "2013-09-07 23:55:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 32, 45 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ATSU7SMCIH",
      "expanded_url" : "http:\/\/i.imgur.com\/s3cx3J4.jpg",
      "display_url" : "i.imgur.com\/s3cx3J4.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "376462066208755712",
  "text" : "For a second I wondered whether @philippbayer is allowed to vote in AUS! http:\/\/t.co\/ATSU7SMCIH",
  "id" : 376462066208755712,
  "created_at" : "2013-09-07 21:48:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376410973072293888",
  "text" : "Just finished \u2018Shadowrun Returns\u2019. The overly linear gameplay bugged me too much to really enjoy it though\u2026",
  "id" : 376410973072293888,
  "created_at" : "2013-09-07 18:25:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376277627008327681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096697708, 8.283115593 ]
  },
  "id_str" : "376341644322557952",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did my first revision. Is already on GH.",
  "id" : 376341644322557952,
  "in_reply_to_status_id" : 376277627008327681,
  "created_at" : "2013-09-07 13:50:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 21, 31 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376315666141564928",
  "text" : "Der Unibib-Proxy der @goetheuni treibt mich noch in den Wahnsinn\u2026",
  "id" : 376315666141564928,
  "created_at" : "2013-09-07 12:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "376298517473812480",
  "text" : "\u00ABWas ist man denn wenn man auf genderqueer biologists steht?\u00BB \u2013 \u00ABCool!\u00BB",
  "id" : 376298517473812480,
  "created_at" : "2013-09-07 10:58:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376277627008327681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096690907, 8.2829985555 ]
  },
  "id_str" : "376284470883938304",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let me finish my literal milk run and then I\u2019ll start writing the revision.",
  "id" : 376284470883938304,
  "in_reply_to_status_id" : 376277627008327681,
  "created_at" : "2013-09-07 10:03:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376274727566073856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096661193, 8.2827790454 ]
  },
  "id_str" : "376275191342837760",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich danke, erk\u00E4lte dich nicht, mein Kind!",
  "id" : 376275191342837760,
  "in_reply_to_status_id" : 376274727566073856,
  "created_at" : "2013-09-07 09:26:11 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376273771377590272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376275100255145984",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let me know once you\u2019ve done the branch and pushed it, so I can pick up from there. :)",
  "id" : 376275100255145984,
  "in_reply_to_status_id" : 376273771377590272,
  "created_at" : "2013-09-07 09:25:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376273435850444800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376273560354164737",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich komm vorbei, wir fr\u00FChst\u00FCcken gerade. :)",
  "id" : 376273560354164737,
  "in_reply_to_status_id" : 376273435850444800,
  "created_at" : "2013-09-07 09:19:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376273299010887680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376273483250302976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, in that case I won\u2019t start to work on that today but work on the paper revision. :)",
  "id" : 376273483250302976,
  "in_reply_to_status_id" : 376273299010887680,
  "created_at" : "2013-09-07 09:19:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376272871443533824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376273166722936832",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yup, that\u2019s it.",
  "id" : 376273166722936832,
  "in_reply_to_status_id" : 376272871443533824,
  "created_at" : "2013-09-07 09:18:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376272426608230400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376272779307679744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer hope is ineffizient!",
  "id" : 376272779307679744,
  "in_reply_to_status_id" : 376272426608230400,
  "created_at" : "2013-09-07 09:16:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376272475383795712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376272611795533825",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer there\u2019s a feature-pad somewhere. Let me search for the link.",
  "id" : 376272611795533825,
  "in_reply_to_status_id" : 376272475383795712,
  "created_at" : "2013-09-07 09:15:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376271755054051328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376272119161978880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I guess you will like it as well. iirc you\u2019re a fan of all hope abandon. ;)",
  "id" : 376272119161978880,
  "in_reply_to_status_id" : 376271755054051328,
  "created_at" : "2013-09-07 09:13:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376271817662402561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540477, 8.2829544322 ]
  },
  "id_str" : "376271933656272896",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer look for the pad. There should be the discussion.",
  "id" : 376271933656272896,
  "in_reply_to_status_id" : 376271817662402561,
  "created_at" : "2013-09-07 09:13:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/nwkjjJvnqF",
      "expanded_url" : "http:\/\/instagram.com\/p\/d9AL24hwv0\/",
      "display_url" : "instagram.com\/p\/d9AL24hwv0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "376267209628471296",
  "text" : "\u00ABDer Kompost ist eine super Cepaea-Zuchtstation!\u00BB @ Elfenbeinturm http:\/\/t.co\/nwkjjJvnqF",
  "id" : 376267209628471296,
  "created_at" : "2013-09-07 08:54:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 10, 21 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376124884944158720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096761971, 8.2829975394 ]
  },
  "id_str" : "376125094344785920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @spreeblick dann nehme ich halt wen anderes mit. ;)",
  "id" : 376125094344785920,
  "in_reply_to_status_id" : 376124884944158720,
  "created_at" : "2013-09-06 23:29:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376111996984639488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096108475, 8.2829994058 ]
  },
  "id_str" : "376112663765721088",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick @Senficon da besorge ich doch gleich morgen Tickets. :)",
  "id" : 376112663765721088,
  "in_reply_to_status_id" : 376111996984639488,
  "created_at" : "2013-09-06 22:40:21 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376111125693480960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558469, 8.2829938536 ]
  },
  "id_str" : "376111579462651904",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick @Senficon und ich Schw\u00E4rmen immer noch von eurem Konzert in Frankfurt, wie man vielleicht merkt. :)",
  "id" : 376111579462651904,
  "in_reply_to_status_id" : 376111125693480960,
  "created_at" : "2013-09-06 22:36:03 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 20, 27 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376110661216260097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558469, 8.2829938536 ]
  },
  "id_str" : "376110986341933056",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon @TnaKng viel Erfolg :)",
  "id" : 376110986341933056,
  "in_reply_to_status_id" : 376110661216260097,
  "created_at" : "2013-09-06 22:33:41 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376110608548376576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096807098, 8.2829597247 ]
  },
  "id_str" : "376110841172856832",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick fair enough. Da haben wir einen Deal! ;)",
  "id" : 376110841172856832,
  "in_reply_to_status_id" : 376110608548376576,
  "created_at" : "2013-09-06 22:33:06 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 12, 22 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376107929776451585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096240844, 8.2829542866 ]
  },
  "id_str" : "376109113589395457",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA @Fischblog @Senficon drunken ramblings of mad (wo)men!",
  "id" : 376109113589395457,
  "in_reply_to_status_id" : 376107929776451585,
  "created_at" : "2013-09-06 22:26:15 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376107625999781888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097072589, 8.2830881293 ]
  },
  "id_str" : "376107768526422016",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Senficon solange wir nicht \u00FCber Kant diskutiert haben z\u00E4hlt es nicht. ;)",
  "id" : 376107768526422016,
  "in_reply_to_status_id" : 376107625999781888,
  "created_at" : "2013-09-06 22:20:54 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376104580867973120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097072589, 8.2830881293 ]
  },
  "id_str" : "376106923722309632",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Senficon \u201Eaber da war ich doch gar nicht richtig Blau!\u201C",
  "id" : 376106923722309632,
  "in_reply_to_status_id" : 376104580867973120,
  "created_at" : "2013-09-06 22:17:33 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376096783581335552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094724875, 8.2829103876 ]
  },
  "id_str" : "376104238625341440",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj kommst du mittwoch eigentlich mit?",
  "id" : 376104238625341440,
  "in_reply_to_status_id" : 376096783581335552,
  "created_at" : "2013-09-06 22:06:52 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376094712740200448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096797502, 8.2829835409 ]
  },
  "id_str" : "376097733264048128",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Feigheit ist verlorene Lebenszeit ;)",
  "id" : 376097733264048128,
  "in_reply_to_status_id" : 376094712740200448,
  "created_at" : "2013-09-06 21:41:01 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376096382249369600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096873238, 8.2830786972 ]
  },
  "id_str" : "376096466252857344",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj awww, ich freu mich drauf :)",
  "id" : 376096466252857344,
  "in_reply_to_status_id" : 376096382249369600,
  "created_at" : "2013-09-06 21:35:59 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376094338767650817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096873238, 8.2830786972 ]
  },
  "id_str" : "376096147913588737",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj wird es wieder Video geben?",
  "id" : 376096147913588737,
  "in_reply_to_status_id" : 376094338767650817,
  "created_at" : "2013-09-06 21:34:43 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 78, 89 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096800168, 8.2829897287 ]
  },
  "id_str" : "376088833433276416",
  "text" : "\u00ABMale Rockstars mit denen ich sofort ins Bett gehen w\u00FCrde? Eddie Vedder &amp; @spreeblick!\u00BB",
  "id" : 376088833433276416,
  "created_at" : "2013-09-06 21:05:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 28, 37 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376087846202793985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009692754, 8.2829933968 ]
  },
  "id_str" : "376088239561789440",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @Senficon ganz klar @JP_Stich! Der mag Videospiele, Metal-Eulen und hat einen super Bart!",
  "id" : 376088239561789440,
  "in_reply_to_status_id" : 376087846202793985,
  "created_at" : "2013-09-06 21:03:18 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 13, 20 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 21, 30 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376055673328766976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096811784, 8.2830056924 ]
  },
  "id_str" : "376055782309380096",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch @Seb666 @Senficon ditto",
  "id" : 376055782309380096,
  "in_reply_to_status_id" : 376055673328766976,
  "created_at" : "2013-09-06 18:54:19 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1117977583, 8.6746402335 ]
  },
  "id_str" : "376005301407059968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks for putting \u2018the silence of animals\u2019 on my read-list. Very bleak &amp; depressing in a fun way!",
  "id" : 376005301407059968,
  "created_at" : "2013-09-06 15:33:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "silenceofanimals",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150851279, 8.6835705491 ]
  },
  "id_str" : "376004834643963904",
  "text" : "\u00AB[\u2026] the idea that humans may one day be more rational requires a greater leap of faith than anything in religion.\u00BB #silenceofanimals",
  "id" : 376004834643963904,
  "created_at" : "2013-09-06 15:31:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bayer Grants4Apps",
      "screen_name" : "grants4apps",
      "indices" : [ 0, 12 ],
      "id_str" : "974130415",
      "id" : 974130415
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 13, 25 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375714994823766017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096922619, 8.2831564036 ]
  },
  "id_str" : "375731842030510080",
  "in_reply_to_user_id" : 974130415,
  "text" : "@grants4apps @helgerausch nice, how was it? :)",
  "id" : 375731842030510080,
  "in_reply_to_status_id" : 375714994823766017,
  "created_at" : "2013-09-05 21:27:06 +0000",
  "in_reply_to_screen_name" : "grants4apps",
  "in_reply_to_user_id_str" : "974130415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.017194703, 8.4311008287 ]
  },
  "id_str" : "375704739683786752",
  "text" : "\u00ABDas mit kein Alkohol nach der Blutspende ist bestimmt nur f\u00FCr Erstspender und nicht f\u00FCr Veteranen. Hier ist ein Bier f\u00FCr dich.\u00BB",
  "id" : 375704739683786752,
  "created_at" : "2013-09-05 19:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "silenceofanimals",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1194793048, 8.6770280437 ]
  },
  "id_str" : "375596041602887680",
  "text" : "\u00ABIf belief in human rationality was a scientific theory it would long have been abandoned.\u00BB #silenceofanimals",
  "id" : 375596041602887680,
  "created_at" : "2013-09-05 12:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/qA2dbWyxAH",
      "expanded_url" : "http:\/\/bps-occupational-digest.blogspot.com\/2013\/09\/racial-slurs-who-suffers-and-who-speaks.html",
      "display_url" : "bps-occupational-digest.blogspot.com\/2013\/09\/racial\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375578335696650241",
  "text" : "Racial slurs: who suffers and who speaks out against them http:\/\/t.co\/qA2dbWyxAH",
  "id" : 375578335696650241,
  "created_at" : "2013-09-05 11:17:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9928299849, 8.2627714878 ]
  },
  "id_str" : "375570074863939584",
  "text" : "\u00ABSind sie zufrieden mit meiner Laufleistung?\u00BB \u2014 \u00ABTotal, sie bluten sehr sch\u00F6n.\u00BB",
  "id" : 375570074863939584,
  "created_at" : "2013-09-05 10:44:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "375314334093959168",
  "text" : "Gew\u00E4schtag",
  "id" : 375314334093959168,
  "created_at" : "2013-09-04 17:48:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0139016066, 8.267551925 ]
  },
  "id_str" : "375297947464114177",
  "text" : "\u00ABVom PhD-Studenten zum Alkoholiker. In 3 einfachen Jahren.\u00BB",
  "id" : 375297947464114177,
  "created_at" : "2013-09-04 16:42:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375250762181672960",
  "geo" : { },
  "id_str" : "375257126160986113",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, it does.",
  "id" : 375257126160986113,
  "in_reply_to_status_id" : 375250762181672960,
  "created_at" : "2013-09-04 14:00:45 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/nAoyu09o0I",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/tumblr_m8qhnnFXRF1qlcuvqo1_500.gif",
      "display_url" : "31.media.tumblr.com\/tumblr_m8qhnnF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375241627683393537",
  "text" : "TIL: You can do degree in bioinformatics w\/o stats &amp; may use it as excuse for not understanding the arithmetic mean\u2026 http:\/\/t.co\/nAoyu09o0I",
  "id" : 375241627683393537,
  "created_at" : "2013-09-04 12:59:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375236621710655488",
  "geo" : { },
  "id_str" : "375238598498336768",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer slide 4 typo: \"ther\" -&gt; \"their\". Otherwise it's fine and should work fine for 3 minutes :)",
  "id" : 375238598498336768,
  "in_reply_to_status_id" : 375236621710655488,
  "created_at" : "2013-09-04 12:47:08 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375236621710655488",
  "geo" : { },
  "id_str" : "375238155596603393",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Nice! Minor thing: The market is not really fragmented, 23andMe is +\/- the only player. But shared data is fragm.",
  "id" : 375238155596603393,
  "in_reply_to_status_id" : 375236621710655488,
  "created_at" : "2013-09-04 12:45:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375227552501354496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723110098, 8.6276357209 ]
  },
  "id_str" : "375228967625977856",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks, I\u2019m currently drowning in work. Hope I can work on the paper and class. system on weekend.",
  "id" : 375228967625977856,
  "in_reply_to_status_id" : 375227552501354496,
  "created_at" : "2013-09-04 12:08:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 72, 83 ]
    }, {
      "text" : "opendata",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/fk7y1WRc7o",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001636?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosbiology%2FNewArticles+%28PLOS+Biology+-+New+Articles%29",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172311, 8.627636 ]
  },
  "id_str" : "375228103133765632",
  "text" : "Lost Branches on the Tree of Life: Data Sharing in Evolutionary Biology #openaccess #opendata http:\/\/t.co\/fk7y1WRc7o",
  "id" : 375228103133765632,
  "created_at" : "2013-09-04 12:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 11, 22 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 23, 30 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374852903984701440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1777018336, 8.6144390911 ]
  },
  "id_str" : "374853644816244736",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @HansZauner @Evo2Me naja, Haber h\u00E4tte ihn f\u00FCr den HB-Prozess vielleicht sogar ein bisschen mehr verdient\u2026",
  "id" : 374853644816244736,
  "in_reply_to_status_id" : 374852903984701440,
  "created_at" : "2013-09-03 11:17:28 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 11, 22 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 23, 30 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374852617098510336",
  "geo" : { },
  "id_str" : "374852813680934913",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @HansZauner @Evo2Me Heute w\u00FCrde er vermutlich nur den f\u00FCr Frieden bekommen.",
  "id" : 374852813680934913,
  "in_reply_to_status_id" : 374852617098510336,
  "created_at" : "2013-09-03 11:14:09 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723097226, 8.6276372404 ]
  },
  "id_str" : "374832006779383808",
  "text" : "Next for the Journal of Negative Results: \u00ABThings I\u2019ve tried and that utterly went wrong. Do not try this at \/home\u00BB",
  "id" : 374832006779383808,
  "created_at" : "2013-09-03 09:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feedly\/id396069556?mt=8&uo=4\" rel=\"nofollow\"\u003Efeedly on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/rsPN4quwEI",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/Xt4zV6FlIMI\/info%3Adoi%2F10.1371%2Fjournal.pone.0073560",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374780447492145152",
  "text" : "Evolutionary History of Chordate PAX Genes: Dynamics of Change in a Complex Gene Family http:\/\/t.co\/rsPN4quwEI",
  "id" : 374780447492145152,
  "created_at" : "2013-09-03 06:26:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374779686645014528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1523650943, 8.6617256165 ]
  },
  "id_str" : "374780074287169536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my guess is that the intersection is quite high: \u2018freedom is awesome if it means going 200 kph but sucks when ppl enter'",
  "id" : 374780074287169536,
  "in_reply_to_status_id" : 374779686645014528,
  "created_at" : "2013-09-03 06:25:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374775973830336512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1109864095, 8.6881152699 ]
  },
  "id_str" : "374776333236465664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I fear Germans would adopt the opposite stance\u2026",
  "id" : 374776333236465664,
  "in_reply_to_status_id" : 374775973830336512,
  "created_at" : "2013-09-03 06:10:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374774517593145344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1056359553, 8.640118778 ]
  },
  "id_str" : "374775332425175040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s just because there\u2019s no general speed limit! :p",
  "id" : 374775332425175040,
  "in_reply_to_status_id" : 374774517593145344,
  "created_at" : "2013-09-03 06:06:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/2i2mxn7HvE",
      "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/16718273",
      "display_url" : "goodreads.com\/book\/show\/1671\u2026"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/V8nMbisUuS",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Spam_Lit",
      "display_url" : "en.wikipedia.org\/wiki\/Spam_Lit"
    } ]
  },
  "in_reply_to_status_id_str" : "374771496029138946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.066536409, 8.6357182577 ]
  },
  "id_str" : "374772630743953408",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara the book (http:\/\/t.co\/2i2mxn7HvE) actually discusses lit spam (http:\/\/t.co\/V8nMbisUuS) in length :)",
  "id" : 374772630743953408,
  "in_reply_to_status_id" : 374771496029138946,
  "created_at" : "2013-09-03 05:55:32 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spam",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9945447925, 8.4006446132 ]
  },
  "id_str" : "374768632368484352",
  "text" : "\u00ABa post-scarcity manufact. model of fantastic profligacy, recalling The Library of Babel as a study in Borgesian publishing economics\u00BB #spam",
  "id" : 374768632368484352,
  "created_at" : "2013-09-03 05:39:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374766184148639745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9849326389, 8.3652438592 ]
  },
  "id_str" : "374766432753823744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay for easy bug fixes. :)",
  "id" : 374766432753823744,
  "in_reply_to_status_id" : 374766184148639745,
  "created_at" : "2013-09-03 05:30:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374764882656124929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9933427945, 8.357559694 ]
  },
  "id_str" : "374765215692644352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good point, or do those need to be escaped somewhere? (Though it\u2019s probably a JS thing of bootstrap)",
  "id" : 374765215692644352,
  "in_reply_to_status_id" : 374764882656124929,
  "created_at" : "2013-09-03 05:26:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374763868825731072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0016183588, 8.2944245648 ]
  },
  "id_str" : "374764161672413185",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks :)",
  "id" : 374764161672413185,
  "in_reply_to_status_id" : 374763868825731072,
  "created_at" : "2013-09-03 05:21:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374763158138654720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070390758, 8.2828206103 ]
  },
  "id_str" : "374763241790255104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer right, we did!",
  "id" : 374763241790255104,
  "in_reply_to_status_id" : 374763158138654720,
  "created_at" : "2013-09-03 05:18:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Thomas Down",
      "screen_name" : "dasmoth",
      "indices" : [ 87, 95 ],
      "id_str" : "71291461",
      "id" : 71291461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/kPjiMIzDCA",
      "expanded_url" : "http:\/\/opensnp.org\/snps\/rs1801133",
      "display_url" : "opensnp.org\/snps\/rs1801133"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096696622, 8.2830277117 ]
  },
  "id_str" : "374760065213169664",
  "text" : "MT @PhilippBayer: The new dalliance looks very, very nice :) http:\/\/t.co\/kPjiMIzDCA cc @dasmoth :)",
  "id" : 374760065213169664,
  "created_at" : "2013-09-03 05:05:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374666432228773890",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096777775, 8.2830114122 ]
  },
  "id_str" : "374666526714245120",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer not before the end of the week. ;)",
  "id" : 374666526714245120,
  "in_reply_to_status_id" : 374666432228773890,
  "created_at" : "2013-09-02 22:53:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/y36I5WBvV6",
      "expanded_url" : "http:\/\/www.biocodershub.net\/community\/words-a-bioinformatician-never-wants-to-hear\/",
      "display_url" : "biocodershub.net\/community\/word\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374661701695967232",
  "text" : "RT @PhilippBayer: Words a bioinformatician never wants to hear http:\/\/t.co\/y36I5WBvV6\n\n\u201CThe data is all in these [proprietary and undocumen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/y36I5WBvV6",
        "expanded_url" : "http:\/\/www.biocodershub.net\/community\/words-a-bioinformatician-never-wants-to-hear\/",
        "display_url" : "biocodershub.net\/community\/word\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374661277424947201",
    "text" : "Words a bioinformatician never wants to hear http:\/\/t.co\/y36I5WBvV6\n\n\u201CThe data is all in these [proprietary and undocumented format] files.\"",
    "id" : 374661277424947201,
    "created_at" : "2013-09-02 22:33:04 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 374661701695967232,
  "created_at" : "2013-09-02 22:34:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 22, 35 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374658309724180480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "374659320417644544",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch oh noes! @PhilippBayer",
  "id" : 374659320417644544,
  "in_reply_to_status_id" : 374658309724180480,
  "created_at" : "2013-09-02 22:25:17 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/K5GDUQ63e2",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=CCVmLHhB6aw",
      "display_url" : "youtube.com\/watch?v=CCVmLH\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0149524725, 8.2745850552 ]
  },
  "id_str" : "374647242336251904",
  "text" : "LOL, Internet http:\/\/t.co\/K5GDUQ63e2",
  "id" : 374647242336251904,
  "created_at" : "2013-09-02 21:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/b8uZ0L0FTJ",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/09\/02\/the-tenuous-beginnings-of-men\/",
      "display_url" : "phenomena.nationalgeographic.com\/2013\/09\/02\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374641564485947392",
  "text" : "RT @edyong209: In which I explain the precarious genetic beginnings of maleness. http:\/\/t.co\/b8uZ0L0FTJ I will call this \"mansplaining\". Wa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/b8uZ0L0FTJ",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/09\/02\/the-tenuous-beginnings-of-men\/",
        "display_url" : "phenomena.nationalgeographic.com\/2013\/09\/02\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374640332165500928",
    "text" : "In which I explain the precarious genetic beginnings of maleness. http:\/\/t.co\/b8uZ0L0FTJ I will call this \"mansplaining\". Wait...",
    "id" : 374640332165500928,
    "created_at" : "2013-09-02 21:09:50 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 374641564485947392,
  "created_at" : "2013-09-02 21:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazneen Rahman",
      "screen_name" : "rahman_nazneen",
      "indices" : [ 3, 18 ],
      "id_str" : "760065560",
      "id" : 760065560
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 90, 104 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374606929576079360",
  "text" : "RT @rahman_nazneen: 'There is no sequencing technology that can deliver a $1000 genome'. \u201C@BioMickWatson: The $1000 myth http:\/\/t.co\/VmjiML\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mick Watson",
        "screen_name" : "BioMickWatson",
        "indices" : [ 70, 84 ],
        "id_str" : "228586748",
        "id" : 228586748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/VmjiMLYSQz",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-4U",
        "display_url" : "wp.me\/p1PnkE-4U"
      } ]
    },
    "in_reply_to_status_id_str" : "374598666654187522",
    "geo" : { },
    "id_str" : "374605497296773121",
    "in_reply_to_user_id" : 228586748,
    "text" : "'There is no sequencing technology that can deliver a $1000 genome'. \u201C@BioMickWatson: The $1000 myth http:\/\/t.co\/VmjiMLYSQz",
    "id" : 374605497296773121,
    "in_reply_to_status_id" : 374598666654187522,
    "created_at" : "2013-09-02 18:51:25 +0000",
    "in_reply_to_screen_name" : "BioMickWatson",
    "in_reply_to_user_id_str" : "228586748",
    "user" : {
      "name" : "Nazneen Rahman",
      "screen_name" : "rahman_nazneen",
      "protected" : false,
      "id_str" : "760065560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2816621149\/23da1b48878311ce48d5154b450a3a51_normal.jpeg",
      "id" : 760065560,
      "verified" : false
    }
  },
  "id" : 374606929576079360,
  "created_at" : "2013-09-02 18:57:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ULccqCbQjI",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/60079502557\/going-home-after-a-big-experiment-fails",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/600795025\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678095, 8.2830130833 ]
  },
  "id_str" : "374596278082367488",
  "text" : "aka every day http:\/\/t.co\/ULccqCbQjI",
  "id" : 374596278082367488,
  "created_at" : "2013-09-02 18:14:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 22, 34 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/374587597982818304\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Qyp42GdDOw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTLNb4dIAAE9_LA.jpg",
      "id_str" : "374587597919879169",
      "id" : 374587597919879169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTLNb4dIAAE9_LA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/Qyp42GdDOw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0087480201, 8.2862603758 ]
  },
  "id_str" : "374587597982818304",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus @PhilippBayer @helgerausch just a day later than expected. ;) http:\/\/t.co\/Qyp42GdDOw",
  "id" : 374587597982818304,
  "created_at" : "2013-09-02 17:40:17 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spam",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.045218892, 8.5022034615 ]
  },
  "id_str" : "374566275147911168",
  "text" : "\u00ABBroadcasts from Borges\u2019s Library of Babel: A way of taking words hostage. \u201CEither #spam continues to move, or say goodbye to \u2018laughed\u2019\u201D\u00BB",
  "id" : 374566275147911168,
  "created_at" : "2013-09-02 16:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Luckhurst",
      "screen_name" : "TheProfRog",
      "indices" : [ 3, 14 ],
      "id_str" : "142043471",
      "id" : 142043471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374502626010071040",
  "text" : "RT @TheProfRog: Daft Punk for academics: We're up all night with work-related anxiety, We're up all night with work-related anxiety",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374477317432569856",
    "text" : "Daft Punk for academics: We're up all night with work-related anxiety, We're up all night with work-related anxiety",
    "id" : 374477317432569856,
    "created_at" : "2013-09-02 10:22:04 +0000",
    "user" : {
      "name" : "Roger Luckhurst",
      "screen_name" : "TheProfRog",
      "protected" : false,
      "id_str" : "142043471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000218672801\/3d11e19f32b3bbca8ef4d5178c06e7e4_normal.jpeg",
      "id" : 142043471,
      "verified" : false
    }
  },
  "id" : 374502626010071040,
  "created_at" : "2013-09-02 12:02:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374485480571551745",
  "text" : "Now: ELI5 \u2013 Creative Commons &amp; Public Domain\u2026",
  "id" : 374485480571551745,
  "created_at" : "2013-09-02 10:54:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/znogg1yV5N",
      "expanded_url" : "http:\/\/i.imgur.com\/FSgxGU1.gif",
      "display_url" : "i.imgur.com\/FSgxGU1.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726729635, 8.6274963994 ]
  },
  "id_str" : "374474518125117440",
  "text" : "Staring at my results http:\/\/t.co\/znogg1yV5N",
  "id" : 374474518125117440,
  "created_at" : "2013-09-02 10:10:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722859853, 8.6276581043 ]
  },
  "id_str" : "374467589508169728",
  "text" : "\u00ABOn second look: How does this work in the first place?\u00BB &lt;3",
  "id" : 374467589508169728,
  "created_at" : "2013-09-02 09:43:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723065305, 8.6276301914 ]
  },
  "id_str" : "374449340674498560",
  "text" : "\u00ABUnd was hat er gesagt was der Fehler ist?\u00BB \u2014 \u00ABJava\u2026\u00BB \u2014 \u00ABIn dem Fall verabschiedest du dich wohl besser von deiner Bachelorarbeit\u2026\u00BB",
  "id" : 374449340674498560,
  "created_at" : "2013-09-02 08:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.003657816, 8.3627749141 ]
  },
  "id_str" : "374409219103272960",
  "text" : "\u00ABIt was the beginning of a constant state of siege, an \u2018eternal September\u2019 soon memorized by, among others, the \u2018alt.aol-sucks\u2019 newsgroup.\u00BB",
  "id" : 374409219103272960,
  "created_at" : "2013-09-02 05:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069700089, 8.2824685704 ]
  },
  "id_str" : "374406645163765760",
  "text" : "Getr\u00E4umt ich h\u00E4tte in irgendeinem Pleistoz\u00E4n-Wald Terrorv\u00F6gel gejagt. o_O",
  "id" : 374406645163765760,
  "created_at" : "2013-09-02 05:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 62, 69 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096810823, 8.2830114302 ]
  },
  "id_str" : "374307275412086784",
  "text" : "\u00ABIch frag mich ob die Hater jetzt unsere Wohnung oder die von @Seb666 ausr\u00E4umen wollen. Unser Keller h\u00E4tte es wirklich mal n\u00F6tig\u2026\u00BB",
  "id" : 374307275412086784,
  "created_at" : "2013-09-01 23:06:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Bw1ExmcidH",
      "expanded_url" : "http:\/\/medias.omgif.net\/wp-content\/uploads\/2011\/02\/Cupcake_dog_flashback.gif",
      "display_url" : "medias.omgif.net\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097058048, 8.2830949629 ]
  },
  "id_str" : "374294623944200192",
  "text" : "\u00ABK\u00F6nnen wir die echte Version singen und nicht die von Echt?\u00BB http:\/\/t.co\/Bw1ExmcidH",
  "id" : 374294623944200192,
  "created_at" : "2013-09-01 22:16:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374294151874871296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097058048, 8.2830949629 ]
  },
  "id_str" : "374294303587450881",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch great. I will keep my hands of the server (as usual ;))",
  "id" : 374294303587450881,
  "in_reply_to_status_id" : 374294151874871296,
  "created_at" : "2013-09-01 22:14:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/LCVessd87D",
      "expanded_url" : "http:\/\/instagram.com\/p\/du2y4jBwsW\/",
      "display_url" : "instagram.com\/p\/du2y4jBwsW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "374275872779669504",
  "text" : "Nomnomnom! http:\/\/t.co\/LCVessd87D",
  "id" : 374275872779669504,
  "created_at" : "2013-09-01 21:01:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096379293, 8.2829819618 ]
  },
  "id_str" : "374269153085255680",
  "text" : "\u00ABEr sieht aus wie Catweazle ohne Bart. Also wie Bastian in blond!\u00BB",
  "id" : 374269153085255680,
  "created_at" : "2013-09-01 20:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096241858, 8.2829328065 ]
  },
  "id_str" : "374262341288099840",
  "text" : "\u00ABIch kann auch ohne Strap-On. Aber nimm ruhig noch ein St\u00FCck Lasagne!\u00BB",
  "id" : 374262341288099840,
  "created_at" : "2013-09-01 20:07:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095837301, 8.2828864588 ]
  },
  "id_str" : "374240806150078464",
  "text" : "\u00ABImmer wenn es um abgetrennte Gliedma\u00DFen geht muss ich an dich denken. Ist das nicht romantisch?\u00BB",
  "id" : 374240806150078464,
  "created_at" : "2013-09-01 18:42:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 5, 12 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374239818441818112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095837301, 8.2828864588 ]
  },
  "id_str" : "374240464339484673",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @Seb666 klar, steht hier nicht im weg rum. :)",
  "id" : 374240464339484673,
  "in_reply_to_status_id" : 374239818441818112,
  "created_at" : "2013-09-01 18:40:54 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097139199, 8.2832191451 ]
  },
  "id_str" : "374236959562297344",
  "text" : "\u00ABDu darfst doch nicht alles klein h\u00E4ckseln! Was sollen die Maskutrolle sonst noch aus der Wohnung tragen?!\u00BB",
  "id" : 374236959562297344,
  "created_at" : "2013-09-01 18:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 36, 43 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096464534, 8.2829799893 ]
  },
  "id_str" : "374235931353833473",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Dein kleines Schwarzes hat der @seb666 jetzt zu uns gebracht. :)",
  "id" : 374235931353833473,
  "created_at" : "2013-09-01 18:22:53 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095855239, 8.2829489913 ]
  },
  "id_str" : "374225747961188352",
  "text" : "Gee, I wish we had one of them dummsday machines!",
  "id" : 374225747961188352,
  "created_at" : "2013-09-01 17:42:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096171468, 8.2829685325 ]
  },
  "id_str" : "374223015401508864",
  "text" : "\u00ABSorry, der Kuchen ist ihnen drin noch etwas weich.\u00BB \u2014 \u00ABOh, ist das Geil!\u00BB",
  "id" : 374223015401508864,
  "created_at" : "2013-09-01 17:31:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374218468830494720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089460845, 8.2830926869 ]
  },
  "id_str" : "374218739753189376",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch great, let me know if you want to have me a look at your deck once you\u2019re done :)",
  "id" : 374218739753189376,
  "in_reply_to_status_id" : 374218468830494720,
  "created_at" : "2013-09-01 17:14:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 8, 14 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374216984411779072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0087417837, 8.2811435468 ]
  },
  "id_str" : "374217127789883393",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @_Rya_ aber nur die Hausfassade bitte. ;)",
  "id" : 374217127789883393,
  "in_reply_to_status_id" : 374216984411779072,
  "created_at" : "2013-09-01 17:08:10 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 73, 80 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om13",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374216057793556481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01299534, 8.2761559915 ]
  },
  "id_str" : "374216384471117824",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ und schon sind mein Klarname und Adresse geleakt. Kein Wunder das @Seb666 in der #om13 Orga ist!",
  "id" : 374216384471117824,
  "in_reply_to_status_id" : 374216057793556481,
  "created_at" : "2013-09-01 17:05:13 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096949783, 8.2830424249 ]
  },
  "id_str" : "374211537621483520",
  "text" : "Wow: Light top\/medium bottom string sets are awesome. I should have tested those 10 years ago\u2026",
  "id" : 374211537621483520,
  "created_at" : "2013-09-01 16:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/3CFSjM56TJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/duVo-lBwkF\/",
      "display_url" : "instagram.com\/p\/duVo-lBwkF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "374203135369441280",
  "text" : "Rusty @ Elfenbeinturm http:\/\/t.co\/3CFSjM56TJ",
  "id" : 374203135369441280,
  "created_at" : "2013-09-01 16:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374191185411452928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958064, 8.2829391567 ]
  },
  "id_str" : "374193386594791424",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Ja, ich liebe ihn so wie er ist, ein special-needs-robot!",
  "id" : 374193386594791424,
  "in_reply_to_status_id" : 374191185411452928,
  "created_at" : "2013-09-01 15:33:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958064, 8.2829391567 ]
  },
  "id_str" : "374188400003518464",
  "text" : "(Zum Einschlafen liest @Senficon dem Roomba \u2018Die kleine Raupe Nimmersatt\u2019 vor.)",
  "id" : 374188400003518464,
  "created_at" : "2013-09-01 15:14:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958064, 8.2829391567 ]
  },
  "id_str" : "374187154865668096",
  "text" : "Den Roomba erfolgreich auf die Ladestation fahren zu sehen mach mich als Elternteil so gl\u00FCcklich!",
  "id" : 374187154865668096,
  "created_at" : "2013-09-01 15:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 13, 20 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374156718525403136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096939319, 8.2830239734 ]
  },
  "id_str" : "374158399115911168",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @yeysus let me know if my previous slides of any help. :)",
  "id" : 374158399115911168,
  "in_reply_to_status_id" : 374156718525403136,
  "created_at" : "2013-09-01 13:14:48 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096939319, 8.2830239734 ]
  },
  "id_str" : "374158167145725952",
  "text" : "\u00ABMost of our tactical military problems can be solved by our buying a Homicide Pact Machine. It\u2019s a new kind of \u2018Maginot mentality\u2019.\u00BB #otnw",
  "id" : 374158167145725952,
  "created_at" : "2013-09-01 13:13:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 13, 25 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374155597295267840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096431696, 8.2830079517 ]
  },
  "id_str" : "374155831165865984",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus yes, @helgerausch already started working on the slides iirc. :)",
  "id" : 374155831165865984,
  "in_reply_to_status_id" : 374155597295267840,
  "created_at" : "2013-09-01 13:04:36 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374154807532990465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096431696, 8.2830079517 ]
  },
  "id_str" : "374155000496545792",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus okay, for those I will wait until I receive an email about it. :)",
  "id" : 374155000496545792,
  "in_reply_to_status_id" : 374154807532990465,
  "created_at" : "2013-09-01 13:01:18 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374153363195043840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096860997, 8.2830547509 ]
  },
  "id_str" : "374153633832906753",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus enjoy your Sunday. I will send out the contracts today. :)",
  "id" : 374153633832906753,
  "in_reply_to_status_id" : 374153363195043840,
  "created_at" : "2013-09-01 12:55:52 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "otnw",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096804649, 8.2830574829 ]
  },
  "id_str" : "374152282092617728",
  "text" : "\u00ABIf you do not know about a problem, it\u2019s very hard to worry about it.\u00BB Unknown unknowns, 1960 #otnw",
  "id" : 374152282092617728,
  "created_at" : "2013-09-01 12:50:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374141066372337665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097175118, 8.2831036655 ]
  },
  "id_str" : "374142293839982592",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus it\u2019s like office desperately wants you to stab(w) someone. ;)",
  "id" : 374142293839982592,
  "in_reply_to_status_id" : 374141066372337665,
  "created_at" : "2013-09-01 12:10:48 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374138602029989889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "374138978121023488",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus STABW ;)",
  "id" : 374138978121023488,
  "in_reply_to_status_id" : 374138602029989889,
  "created_at" : "2013-09-01 11:57:38 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 118, 131 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AABOfLxnof",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0072742",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "374127867577507840",
  "text" : "The Relationship between Gene Isoform Multiplicity, Number of Exons and Protein Divergence http:\/\/t.co\/AABOfLxnof \/cc @PhilippBayer",
  "id" : 374127867577507840,
  "created_at" : "2013-09-01 11:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374114744342282241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096546921, 8.2830337174 ]
  },
  "id_str" : "374115050161963008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I somehow doubt that they will approve you given your motivation.",
  "id" : 374115050161963008,
  "in_reply_to_status_id" : 374114744342282241,
  "created_at" : "2013-09-01 10:22:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374112866669834240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096939123, 8.2830153577 ]
  },
  "id_str" : "374113263002611712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and you already moved to the end of the world to outrun them!",
  "id" : 374113263002611712,
  "in_reply_to_status_id" : 374112866669834240,
  "created_at" : "2013-09-01 10:15:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374111295571623936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009675423, 8.2830852341 ]
  },
  "id_str" : "374112033828241408",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng sowohl als auch: Das du nackt auftauchst und ich dir deshalb mein Shirt geben muss. :p",
  "id" : 374112033828241408,
  "in_reply_to_status_id" : 374111295571623936,
  "created_at" : "2013-09-01 10:10:34 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374108157447925760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097014866, 8.2830447725 ]
  },
  "id_str" : "374110337597194240",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng das Risiko bin ich bereit zu tragen. :)",
  "id" : 374110337597194240,
  "in_reply_to_status_id" : 374108157447925760,
  "created_at" : "2013-09-01 10:03:49 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097014866, 8.2830447725 ]
  },
  "id_str" : "374109504931364864",
  "text" : "\u00ABDu planst gerade an einer Konferenz f\u00FCr die Jungen Piraten die Euro-Dicks hei\u00DFt?!\u00BB",
  "id" : 374109504931364864,
  "created_at" : "2013-09-01 10:00:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374107729616330752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096595266, 8.283010866 ]
  },
  "id_str" : "374107851830349824",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng daf\u00FCr m\u00FCsstest du schon nackt kommen ;)",
  "id" : 374107851830349824,
  "in_reply_to_status_id" : 374107729616330752,
  "created_at" : "2013-09-01 09:53:57 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374106695993028608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096718939, 8.2830015851 ]
  },
  "id_str" : "374107552457707520",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng aww, so gern &lt;3 (du hoffst doch nur mein T-Shirt zu bekommen!)",
  "id" : 374107552457707520,
  "in_reply_to_status_id" : 374106695993028608,
  "created_at" : "2013-09-01 09:52:45 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096305507, 8.2832532004 ]
  },
  "id_str" : "374106253578219521",
  "text" : "\u00ABWenn der @Seb666 heute Abend zum Essen kommt sollten wir aber noch Cola Light kaufen!\u00BB",
  "id" : 374106253578219521,
  "created_at" : "2013-09-01 09:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096969548, 8.2830298059 ]
  },
  "id_str" : "373960597916102656",
  "text" : "\u00ABAnd make sure your beard is dry, you can develop trench-foot on your face if you don\u2019t dry it properly!\u00BB",
  "id" : 373960597916102656,
  "created_at" : "2013-09-01 00:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/5Y7vzEUNuO",
      "expanded_url" : "http:\/\/instagram.com\/p\/dsiAARhwuv\/",
      "display_url" : "instagram.com\/p\/dsiAARhwuv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "373949054352650241",
  "text" : "SSC for dogs: \u00ABWiesenregeln: Zustimmung, Verantwortung, Vernunft.\u00BB http:\/\/t.co\/5Y7vzEUNuO",
  "id" : 373949054352650241,
  "created_at" : "2013-08-31 23:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 103, 116 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/GZzDZxjKGX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=AHZr8YoRFmU",
      "display_url" : "youtube.com\/watch?v=AHZr8Y\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373946130973069312",
  "text" : "\u00ABYou\u2019re in a strange part of the Internet!\u00BB\u2013\u00ABIt started w\/ reading reddit &amp; ended up down under w\/ @PhilippBayer!\u00BB https:\/\/t.co\/GZzDZxjKGX",
  "id" : 373946130973069312,
  "created_at" : "2013-08-31 23:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastiaan de With",
      "screen_name" : "sdw",
      "indices" : [ 3, 7 ],
      "id_str" : "6503412",
      "id" : 6503412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/5pieiySoCZ",
      "expanded_url" : "http:\/\/dev.citysdk.waag.org\/buildings\/#53.2418,6.5877,11",
      "display_url" : "dev.citysdk.waag.org\/buildings\/#53.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373938769520754688",
  "text" : "RT @sdw: All 9,866,539 buildings in the Netherlands, shaded according to year of construction. Super cool. http:\/\/t.co\/5pieiySoCZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/5pieiySoCZ",
        "expanded_url" : "http:\/\/dev.citysdk.waag.org\/buildings\/#53.2418,6.5877,11",
        "display_url" : "dev.citysdk.waag.org\/buildings\/#53.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373880632109060096",
    "text" : "All 9,866,539 buildings in the Netherlands, shaded according to year of construction. Super cool. http:\/\/t.co\/5pieiySoCZ",
    "id" : 373880632109060096,
    "created_at" : "2013-08-31 18:51:03 +0000",
    "user" : {
      "name" : "Sebastiaan de With",
      "screen_name" : "sdw",
      "protected" : false,
      "id_str" : "6503412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920006896723091456\/CnqUgW3r_normal.png",
      "id" : 6503412,
      "verified" : true
    }
  },
  "id" : 373938769520754688,
  "created_at" : "2013-08-31 22:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/8LRDepB1aR",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1lghn7\/what_reddit_fad_are_you_glad_died_out\/cbz180v",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373931771207094272",
  "text" : "All of Reddit condensed into a single comment http:\/\/t.co\/8LRDepB1aR",
  "id" : 373931771207094272,
  "created_at" : "2013-08-31 22:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096541917, 8.28301383 ]
  },
  "id_str" : "373931608010940417",
  "text" : "\u00ABI can't fap to this. No true scotsman could see that this relevant XKCD was bad, and you should feel bad. You must be new to reddit\u2026\u00BB",
  "id" : 373931608010940417,
  "created_at" : "2013-08-31 22:13:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]