Grailbird.data.tweets_2009_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660597545",
  "geo" : { },
  "id_str" : "1660604312",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Bist halt beliebt :)",
  "id" : 1660604312,
  "in_reply_to_status_id" : 1660597545,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660597545",
  "geo" : { },
  "id_str" : "1660608145",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Alternativ hat meine Werbung was gebracht ;)",
  "id" : 1660608145,
  "in_reply_to_status_id" : 1660597545,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660700900",
  "geo" : { },
  "id_str" : "1660715887",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Cool, die scheinen neu zu sein. Ich hab von den kleinen so 5-6 gut gef\u00FCllte :)",
  "id" : 1660715887,
  "in_reply_to_status_id" : 1660700900,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660726111",
  "geo" : { },
  "id_str" : "1661010149",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, aber meine Leserschaft ist sehr unregelm\u00E4ssig. Sprich nicht die Poweruser ;)",
  "id" : 1661010149,
  "in_reply_to_status_id" : 1660726111,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660735133",
  "geo" : { },
  "id_str" : "1661016132",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Ein gro\u00DFes hab ich auch. Aber alle gro\u00DFen sind zu riesig f\u00FCr meine Hosentaschen ;)",
  "id" : 1661016132,
  "in_reply_to_status_id" : 1660735133,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657108908",
  "geo" : { },
  "id_str" : "1657167403",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin das ist so ziemlich mein Bild von Berlin ;)",
  "id" : 1657167403,
  "in_reply_to_status_id" : 1657108908,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657167559",
  "geo" : { },
  "id_str" : "1657313728",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog nach dem Spiel sollten wir alle fix nach Madagaskar auswandern!!",
  "id" : 1657313728,
  "in_reply_to_status_id" : 1657167559,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657330112",
  "text" : "Ach #nature Erst 2x die gleichen Mails versenden und nun 2x die gleiche Ausgabe? Euer Abosystem ist wohl fucked.  http:\/\/twitpic.com\/49gc3",
  "id" : 1657330112,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657338429",
  "geo" : { },
  "id_str" : "1657347720",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ne, ich glaube sie haben das mit der Erneuerung des Abos versaut und eine Ausgabe zu fr\u00FCh verl\u00E4ngert, und deshalb 2x geliefert.",
  "id" : 1657347720,
  "in_reply_to_status_id" : 1657338429,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1656813635",
  "geo" : { },
  "id_str" : "1657350768",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Na dann ists ja auch v\u00F6llig egal. Wobei wer ein bisschen englisch kann der kann auch in Python programmieren ;)",
  "id" : 1657350768,
  "in_reply_to_status_id" : 1656813635,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657400794",
  "geo" : { },
  "id_str" : "1657413070",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Okay, http:\/\/tr.im\/k53A und http:\/\/tr.im\/k53B sind sonst auch ganz empfehlenswerte Tutorials f\u00FCr den Einstieg",
  "id" : 1657413070,
  "in_reply_to_status_id" : 1657400794,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657416530",
  "geo" : { },
  "id_str" : "1657429117",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Damit haben Philipp & ich uns die Grundlagen beigebracht :) Als Nachschlagwerk f\u00FCr einzelne Befehle ist http:\/\/tr.im\/k54c gut. :)",
  "id" : 1657429117,
  "in_reply_to_status_id" : 1657416530,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657444216",
  "geo" : { },
  "id_str" : "1657457540",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Schade, da bin ich schon wieder Zelten, sonst w\u00E4re ich glatt vorbeigekommen.",
  "id" : 1657457540,
  "in_reply_to_status_id" : 1657444216,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657491615",
  "text" : "Auf das Riff steh ich total \u266B http:\/\/blip.fm\/~59h7y",
  "id" : 1657491615,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657504721",
  "geo" : { },
  "id_str" : "1657523164",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina H\u00E4ttest du Verwendung f\u00FCr so eine doppelte Ausgabe? ;)",
  "id" : 1657523164,
  "in_reply_to_status_id" : 1657504721,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657526010",
  "text" : "@JoergR Damit hab ich mich noch gar nicht besch\u00E4ftigt. Hab das Buch aber auch gerade nicht da.",
  "id" : 1657526010,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 8, 17 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657532561",
  "text" : "@JoergR @Argent23 Dieser MIT-Kurs ist auch noch ganz gut weil er eingebaute Algorithmen von Python tempom\u00E4ssig vergleicht http:\/\/tr.im\/k582",
  "id" : 1657532561,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frueherwarallesbesser",
      "indices" : [ 72, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657551800",
  "text" : "Ich muss sagen das neue Layout von Friendfeed finde ich ganz gr\u00E4sslich. #frueherwarallesbesser",
  "id" : 1657551800,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657550316",
  "geo" : { },
  "id_str" : "1657552949",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Dann DM mir mal wohin die Reise genau gehen soll :)",
  "id" : 1657552949,
  "in_reply_to_status_id" : 1657550316,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    }, {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 51, 59 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1657632116",
  "geo" : { },
  "id_str" : "1657640628",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Cool! Viel Spa\u00DF bei den Scienceblogs @joergfr :)",
  "id" : 1657640628,
  "in_reply_to_status_id" : 1657632116,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 10, 17 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Martin Thielecke",
      "screen_name" : "mthie",
      "indices" : [ 21, 27 ],
      "id_str" : "3253641",
      "id" : 3253641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657698481",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 @JoergR RT @mthie: Perl is the only language that looks the same: before and after RSA encryption",
  "id" : 1657698481,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657738519",
  "text" : "@JoergR Ja, aber ich glaube Perl h\u00E4lt einen einfach nicht dazu an sauber zu schreiben sondern sieht das mehr als optional an ;)",
  "id" : 1657738519,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657773960",
  "text" : "@JoergR Das ist ja so in etwa was ich meine ;)",
  "id" : 1657773960,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "science",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657777307",
  "text" : "Neuer W&W-Post: Wieso ehrlich sein wenn wir keinen freien Willen haben? Determinismus als Ausrede. http:\/\/tr.im\/k5h9 #wundw #science",
  "id" : 1657777307,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657785392",
  "text" : "@JoergR Ja, aber das kommt eben von den Konzepten dass man es einfach so runterschreiben kann. Hat durchaus seine Vorteile :)",
  "id" : 1657785392,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657851435",
  "text" : "Oha, heute vor 20 Jahren ist Gro\u00DFmeister Sergio Leone verstorben!",
  "id" : 1657851435,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1657995857",
  "text" : "Festgestellt dass ich am Windows-Desktoprechner nur eine Tastatur habe. \u00DCber Tastatur Logmein installiert um per iPhone Maus zu schubsen...",
  "id" : 1657995857,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658022950",
  "geo" : { },
  "id_str" : "1658053299",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Und du hast die Idioten noch nicht einfach unfollowt?",
  "id" : 1658053299,
  "in_reply_to_status_id" : 1658022950,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658060779",
  "geo" : { },
  "id_str" : "1658078177",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Die Idioten werden als t\u00E4glich mehr? \u00DCberrascht mich nicht...",
  "id" : 1658078177,
  "in_reply_to_status_id" : 1658060779,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1658079476",
  "text" : "I iz in ur twitter sendin adz!",
  "id" : 1658079476,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658079696",
  "geo" : { },
  "id_str" : "1658103412",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Daf\u00FCr muss die Post aber viele Briefmarken verticken!",
  "id" : 1658103412,
  "in_reply_to_status_id" : 1658079696,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1658115973",
  "text" : "Danke Californication-Soundtrack! Cooler Typ! \u266B http:\/\/blip.fm\/~59mre",
  "id" : 1658115973,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658115603",
  "geo" : { },
  "id_str" : "1658134187",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Stimmt, aber wer nicht sauber coden kann dem ist auch einfach egal ob es andere Menschen lesen k\u00F6nnen ;)",
  "id" : 1658134187,
  "in_reply_to_status_id" : 1658115603,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee B",
      "screen_name" : "reneeb_perl",
      "indices" : [ 0, 12 ],
      "id_str" : "23204522",
      "id" : 23204522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658137267",
  "geo" : { },
  "id_str" : "1658147279",
  "in_reply_to_user_id" : 23204522,
  "text" : "@reneeb_perl Okay, so weit bin ich nicht in Perl eingestiegen. Und mein Chef dessen Code ich lesen wollte offensichtlich auch nicht :D",
  "id" : 1658147279,
  "in_reply_to_status_id" : 1658137267,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "reneeb_perl",
  "in_reply_to_user_id_str" : "23204522",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658179945",
  "geo" : { },
  "id_str" : "1658189865",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das sagst du jetzt, aber vielleicht hat bald jemand ein \u00E4hnliches Problem und es m\u00FCssen nur wenige Zeilen Code angepasst werden?",
  "id" : 1658189865,
  "in_reply_to_status_id" : 1658179945,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658165413",
  "geo" : { },
  "id_str" : "1658197122",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Na, das hab ich doch schon gemeistert ;)",
  "id" : 1658197122,
  "in_reply_to_status_id" : 1658165413,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee B",
      "screen_name" : "reneeb_perl",
      "indices" : [ 0, 12 ],
      "id_str" : "23204522",
      "id" : 23204522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658192732",
  "geo" : { },
  "id_str" : "1658215945",
  "in_reply_to_user_id" : 23204522,
  "text" : "@reneeb_perl Na das sieht doch wundersch\u00F6n und vor allem lesbar aus. :)",
  "id" : 1658215945,
  "in_reply_to_status_id" : 1658192732,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "reneeb_perl",
  "in_reply_to_user_id_str" : "23204522",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1658339688",
  "geo" : { },
  "id_str" : "1658369533",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 BioPython ist auch sehr m\u00E4chtig ;)",
  "id" : 1658369533,
  "in_reply_to_status_id" : 1658339688,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1660040413",
  "text" : "Alle als gelesen markieren ist das Killerfeature von Eventbox ;)",
  "id" : 1660040413,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1660216141",
  "text" : "Wie cool, der Atheistbus f\u00E4hrt auch durch M\u00FCnster! http:\/\/tr.im\/k7hx",
  "id" : 1660216141,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1660267240",
  "text" : "Seehr cooler Artikel von SJ Gould \u00FCber seinen Krebs und Statistik: http:\/\/tr.im\/k7jJ via Philipp :)",
  "id" : 1660267240,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1660475965",
  "text" : "@dasblogt Ja, das ist mir auch schon aufgefallen. Wird sicher gepatcht ;)",
  "id" : 1660475965,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1660569048",
  "geo" : { },
  "id_str" : "1660591255",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Seit wann gibt es die in A4? :)",
  "id" : 1660591255,
  "in_reply_to_status_id" : 1660569048,
  "created_at" : "2009-04-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1648029543",
  "text" : "Langsam sollte ich mir doch mal einen USB-Hub zulegen, die 2 Ports des MBP reichen einfach doch nicht.",
  "id" : 1648029543,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1648138701",
  "geo" : { },
  "id_str" : "1648194275",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ich w\u00E4re auch dabei :)",
  "id" : 1648194275,
  "in_reply_to_status_id" : 1648138701,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1648446857",
  "geo" : { },
  "id_str" : "1648496250",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX epic fail!",
  "id" : 1648496250,
  "in_reply_to_status_id" : 1648446857,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Fischer",
      "screen_name" : "phomac",
      "indices" : [ 0, 7 ],
      "id_str" : "15147217",
      "id" : 15147217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1648523158",
  "geo" : { },
  "id_str" : "1648547650",
  "in_reply_to_user_id" : 15147217,
  "text" : "@phomac Okay werd ich mir mal anschauen. :)",
  "id" : 1648547650,
  "in_reply_to_status_id" : 1648523158,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "phomac",
  "in_reply_to_user_id_str" : "15147217",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Fischer",
      "screen_name" : "phomac",
      "indices" : [ 0, 7 ],
      "id_str" : "15147217",
      "id" : 15147217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1648523158",
  "geo" : { },
  "id_str" : "1648551052",
  "in_reply_to_user_id" : 15147217,
  "text" : "@phomac Ohne ist echt doof, Timemachine-Volume & iPhone dran. Und keine M\u00F6glichkeit fix Daten auf den USB-Stick zu schieben ;)",
  "id" : 1648551052,
  "in_reply_to_status_id" : 1648523158,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "phomac",
  "in_reply_to_user_id_str" : "15147217",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1650939139",
  "geo" : { },
  "id_str" : "1651131381",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 igitt, Perl!! Nimm Python! ;)",
  "id" : 1651131381,
  "in_reply_to_status_id" : 1650939139,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1651966795",
  "text" : "@JoergR Nachdem ich mit Code konfrontiert war der zu 90% aus REs bestand und nur in Spanisch kommentiert war bin ich Perl-Traumatisiert ;)",
  "id" : 1651966795,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1652179190",
  "text" : "@JoergR ja, wobei selbst wenn ich spanisch k\u00F6nnte h\u00E4tte ich vermutlich wenig begriffen. Einmal schreiben, nie wieder verstehen == Perl ;)",
  "id" : 1652179190,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1652762706",
  "text" : "Hab heut dank Besuch doch nicht die Zeit zum Bloggen gefunden. Morgen dann wieder W&W. Hoffentlich ;)",
  "id" : 1652762706,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1652802381",
  "text" : "Er will nicht einsehen dass er zu gro\u00DF geworden ist! http:\/\/twitpic.com\/48g5q",
  "id" : 1652802381,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1652829169",
  "text" : "Die bekloppte R\u00FCgenwalder-Werbung klaut auch wenig subtil Songfragmente aus Scarbourough Fair. Aber auf typisch Deutsch machen wollen...",
  "id" : 1652829169,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1652894153",
  "text" : "Nat\u00FCrlich nur \u201EScarborough\u201C, ohne das erste \u201Eou\u201C. mea culpa!",
  "id" : 1652894153,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1646751296",
  "text" : "Guten Morgen Statistiken!",
  "id" : 1646751296,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1646807137",
  "text" : "@Taxipilot im schwummrigen H\u00F6rsaal. Werde wieder m\u00FCde ;)",
  "id" : 1646807137,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1643111617",
  "geo" : { },
  "id_str" : "1646810652",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em ne, hatte das Plakat nicht gesehen. Nehme morgens so wenig von meiner Umwelt wahr ;)",
  "id" : 1646810652,
  "in_reply_to_status_id" : 1643111617,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1646824821",
  "geo" : { },
  "id_str" : "1646906186",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX das kann sein. Hab nicht drauf geachtet. Aber nur zu, geht auch mit dem Barcampomaten :)",
  "id" : 1646906186,
  "in_reply_to_status_id" : 1646824821,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1646937612",
  "text" : "Die meisten Studenten sollten einfach nicht studieren....",
  "id" : 1646937612,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647189499",
  "text" : "Also das Byline-Update finde ich Klasse. H\u00FCbsches neues Icon und auch das Interface hat das h\u00E4ssliche Holzimitat abgelegt!",
  "id" : 1647189499,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1647385640",
  "geo" : { },
  "id_str" : "1647426504",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu dito!",
  "id" : 1647426504,
  "in_reply_to_status_id" : 1647385640,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1647482739",
  "geo" : { },
  "id_str" : "1647539672",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu bin schon dabei :)",
  "id" : 1647539672,
  "in_reply_to_status_id" : 1647482739,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647595936",
  "text" : "Was f\u00E4llt dem Schornsteinfeger eigentlich ein morgen Abend um 19 Uhr vorbeikommen zu wollen? Freitag ist doch Feiertag!",
  "id" : 1647595936,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647697198",
  "text" : "Sowohl Unterst\u00FCtzer-Formular f\u00FCr die Piraten ist ausgef\u00FCllt. Gleich dann mal zum Briefkasten.",
  "id" : 1647697198,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647961566",
  "text" : "Einseitiges Blippen, ich weiss ;) \u266B http:\/\/blip.fm\/~573qa",
  "id" : 1647961566,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647972480",
  "text" : "Hab das neue Dylan-Album nun auch ein paar mal geh\u00F6rt. Solide, haut mich aber nicht so wirklich vom Hocker.",
  "id" : 1647972480,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1647999084",
  "text" : "Rickrollin ist ja sowas von 2008! http:\/\/tr.im\/k0vD",
  "id" : 1647999084,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1648002444",
  "geo" : { },
  "id_str" : "1648015118",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Mein Pfadfindermitleiter hat mich gestern sogar per Telefon bennyrolled und nur daf\u00FCr angerufen ;)",
  "id" : 1648015118,
  "in_reply_to_status_id" : 1648002444,
  "created_at" : "2009-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1633666798",
  "geo" : { },
  "id_str" : "1637051459",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Danke f\u00FCr den Link :)",
  "id" : 1637051459,
  "in_reply_to_status_id" : 1633666798,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Sommer",
      "screen_name" : "csommer",
      "indices" : [ 0, 8 ],
      "id_str" : "14436873",
      "id" : 14436873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greenpeace",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637006123",
  "geo" : { },
  "id_str" : "1637083271",
  "in_reply_to_user_id" : 14436873,
  "text" : "@csommer Interessant wie er vom Agrar- zum Gentechnik-Experten wird. Darf man da auch fragen mit welcher Qualifikation? #greenpeace",
  "id" : 1637083271,
  "in_reply_to_status_id" : 1637006123,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "csommer",
  "in_reply_to_user_id_str" : "14436873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637117832",
  "geo" : { },
  "id_str" : "1637132214",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Bin voll f\u00FCr das PierHouse, abe nur weil ich fast \u00FCber dem Ding wohne ;)",
  "id" : 1637132214,
  "in_reply_to_status_id" : 1637117832,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1637327975",
  "text" : "Die neue Version von To-Do finde ich echt Super. Endlich Projekte & Checklisten.",
  "id" : 1637327975,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Greenpeace",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637389961",
  "geo" : { },
  "id_str" : "1637401827",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ach #Greenpeace, deren \u201CExperten\u201D find ich pers\u00F6nlich auch nur knuffig.",
  "id" : 1637401827,
  "in_reply_to_status_id" : 1637389961,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1637436401",
  "text" : "@JoergR Das Problem mit den meisten Umweltsch\u00FCtzern ist doch einfach dass sie viel zu dogmatisch und extrem sind...",
  "id" : 1637436401,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1637785850",
  "text" : "Mach ich halt mein eigenes Barcamp. Mit Blackjack & Nutten!",
  "id" : 1637785850,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637805712",
  "geo" : { },
  "id_str" : "1637824715",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Immer bei Greenpeace? :)",
  "id" : 1637824715,
  "in_reply_to_status_id" : 1637805712,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637853828",
  "geo" : { },
  "id_str" : "1637872976",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Sollten mal ein WissenschaftsbloggingCamp organisieren ;)",
  "id" : 1637872976,
  "in_reply_to_status_id" : 1637853828,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1637882509",
  "geo" : { },
  "id_str" : "1637919762",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Ok,ich hab nur den Eindruck dass sowas meist nur einseitig gefeatured wird und auch Experten nicht besser sind, daher die Skeptik",
  "id" : 1637919762,
  "in_reply_to_status_id" : 1637882509,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1638054307",
  "text" : "Neuer W&W-Post: Inzucht im Adel - F\u00FChrt Inzucht wirklich zu mehr genetisch bedingten Krankheiten? http:\/\/tr.im\/jUcQ #science #wissenschaft",
  "id" : 1638054307,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638175196",
  "geo" : { },
  "id_str" : "1638204045",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja, warum nicht. Und Blackjack gerne ;)",
  "id" : 1638204045,
  "in_reply_to_status_id" : 1638175196,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638072826",
  "geo" : { },
  "id_str" : "1638207911",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Ja, aber in dem Fall ging es um autosomal vererbte Krankheiten :)",
  "id" : 1638207911,
  "in_reply_to_status_id" : 1638072826,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638250291",
  "geo" : { },
  "id_str" : "1638322615",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Das war aber nicht an mich gedacht oder? ;) Making Of-Video zur Erbkrankheiten? Pornos? ;)",
  "id" : 1638322615,
  "in_reply_to_status_id" : 1638250291,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638258406",
  "geo" : { },
  "id_str" : "1638329541",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Und ja die Wahrscheinlichkeiten bei Inzucht sinken wenn man von Geschlechtschromosomen zu den Autosomen geht.Bin aber rechenfaul ;)",
  "id" : 1638329541,
  "in_reply_to_status_id" : 1638258406,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638361249",
  "geo" : { },
  "id_str" : "1638368535",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Kommt auf den Client an, mit Eventbox & Twitterfon und deren Konversationsansichten geht\u2019s super :)",
  "id" : 1638368535,
  "in_reply_to_status_id" : 1638361249,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638392088",
  "geo" : { },
  "id_str" : "1638405279",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Stimmt, zumindest als ich noch Ubuntu benutzt habe war ich da auch nicht zufrieden mit dem Angebot unter Linux.",
  "id" : 1638405279,
  "in_reply_to_status_id" : 1638392088,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unfollows",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "verlosung",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1638526164",
  "text" : "Ich verlose heute noch einmal zwei #unfollows. F\u00FCr die Teilnahme bitte einfach diesen Tweet retweeten! #verlosung",
  "id" : 1638526164,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1638532660",
  "geo" : { },
  "id_str" : "1638605215",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Soll ich das als Teilnahme werten? ;)",
  "id" : 1638605215,
  "in_reply_to_status_id" : 1638532660,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Das 15Talents Team",
      "screen_name" : "15Talents",
      "indices" : [ 67, 77 ],
      "id_str" : "16009370",
      "id" : 16009370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1638776709",
  "text" : "Passt zu Bologna vs. Bolognese: RT @Annellchen: Fazit Bachelor via @15Talents http:\/\/www.sueddeutsche.de\/jobkarriere\/14\/466594\/text\/",
  "id" : 1638776709,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1639057979",
  "text" : "Neuer W&W-Post: Kein Sex vor der Ehe! Enthaltsamkeit funktioniert. NICHT! http:\/\/tr.im\/jUSS",
  "id" : 1639057979,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 3, 10 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1639208660",
  "text" : "RT @JoergR: Die Kirche des Fliegenden Spaghettimonsters Uckermark fordert noch mehr freie Wahl http:\/\/tr.im\/jUYq",
  "id" : 1639208660,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1639277251",
  "text" : "Yeah: https:\/\/twitter.com\/343max\/statuses\/1639199307",
  "id" : 1639277251,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1639373589",
  "geo" : { },
  "id_str" : "1639381128",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten In GoogleEarth kann man doch Pfade angeben ;)",
  "id" : 1639381128,
  "in_reply_to_status_id" : 1639373589,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexsells",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1639611491",
  "text" : "Kaum berichtet man im Blog \u00FCber Inzucht & Unzucht steigen die Besucherzahlen wieder #sexsells",
  "id" : 1639611491,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1639998235",
  "geo" : { },
  "id_str" : "1640052278",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Jetzt will Philipp bestimmt ein Kind von dir weil er sonst niemanden kennt der das mag :D",
  "id" : 1640052278,
  "in_reply_to_status_id" : 1639998235,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1640357687",
  "geo" : { },
  "id_str" : "1640378676",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ah das ist das Poken-Logo :)",
  "id" : 1640378676,
  "in_reply_to_status_id" : 1640357687,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1640553255",
  "text" : "@rajue ist M\u00FCnster noch Umgebung? ;)",
  "id" : 1640553255,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1641961117",
  "text" : "Hab dank Linus Paper \u00FCber die ich morgen schreiben kann!",
  "id" : 1641961117,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1642078159",
  "text" : "Mitautoren die zu wenig Zeit haben um Paper zu lesen und zu verbloggen sind auch eine Hilfe, irgendwie ;)",
  "id" : 1642078159,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1642251345",
  "geo" : { },
  "id_str" : "1642289533",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Wieso l\u00E4dt mich denn niemand zu sowas ein? ;)",
  "id" : 1642289533,
  "in_reply_to_status_id" : 1642251345,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1642722885",
  "text" : "Wieso darf ich gerade nicht per iPhone Programme laden?",
  "id" : 1642722885,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1631823439",
  "text" : "Kommt eigentlich was gutes im TV?",
  "id" : 1631823439,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1632163284",
  "text" : "Damn, schon wieder bei Ebay nach \u201CFedora\u201D gesucht und nur Linux aber keinen Hut gefunden!",
  "id" : 1632163284,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BC\u03AE\u03BD\u03B5\u03C2 \u03BD\u03C4\u03BF\u03C5\u03BB\u03AC\u03C0\u03B1",
      "screen_name" : "x1598",
      "indices" : [ 0, 6 ],
      "id_str" : "2789563142",
      "id" : 2789563142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1632235071",
  "text" : "@x1598 adding \u201Chat\u201D to the search query improves results a lot :)",
  "id" : 1632235071,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaputt",
      "screen_name" : "kaputt",
      "indices" : [ 3, 10 ],
      "id_str" : "14453931",
      "id" : 14453931
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cdu",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "fail",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1632444907",
  "text" : "RT @kaputt: \"Die Homosexualit\u00E4t als gesamtgesellschaftliches Problem k\u00F6nnte bald einged\u00E4mmt werden.\" http:\/\/is.gd\/uVyO #cdu #fail",
  "id" : 1632444907,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1627028624",
  "geo" : { },
  "id_str" : "1627115947",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em hast du deine Install-CD mittlerweile? ;)",
  "id" : 1627115947,
  "in_reply_to_status_id" : 1627028624,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627251210",
  "in_reply_to_user_id" : 13823092,
  "text" : "@skl8em Okay, dann meld dich mal wenn du noch Hilfe brauchst :)",
  "id" : 1627251210,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627255636",
  "text" : "Btte RT: Es gibt keinen Grund nicht mehr vermisste Fotografen weiterhin per RT zu suchen!",
  "id" : 1627255636,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1627267551",
  "geo" : { },
  "id_str" : "1627275851",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Siehe beim Ausl\u00F6ser: http:\/\/tr.im\/jNgf",
  "id" : 1627275851,
  "in_reply_to_status_id" : 1627267551,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627297251",
  "text" : "Wieso kann man bei Researchblogging nicht eigentlich auch mal deutsche & englische Posts simultan anzeigen lassen?",
  "id" : 1627297251,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "wundw",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627647998",
  "text" : "Kurzer W&W-Post: Google & Die Grippe http:\/\/tr.im\/jNzL #science #wissenschaft #wundw",
  "id" : 1627647998,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627677766",
  "text" : "Leute die glauben sie seien Experte f\u00FCr irgendwas nur weil sie den Wikipedia-Artikel gelesen haben...",
  "id" : 1627677766,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1627701293",
  "geo" : { },
  "id_str" : "1627718255",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Das frag ich mich auch ;) Vor allem werden die Hits \u00FCber Researchblogging immer weniger.",
  "id" : 1627718255,
  "in_reply_to_status_id" : 1627701293,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1627696431",
  "geo" : { },
  "id_str" : "1627719263",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Wow, den kannte ich noch gar nicht. Danke! :)",
  "id" : 1627719263,
  "in_reply_to_status_id" : 1627696431,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627750804",
  "text" : "@JoergR Die letzten Artikel haben alle so maximal 10 Hits \u00FCber RB gebracht. Und das innerhalb von 2-3 Wochen",
  "id" : 1627750804,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1627773393",
  "geo" : { },
  "id_str" : "1627783408",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ich seh gerade erst: Unsere Posts sind im RB-Feed auch gar nicht im Volltext, ich weiss aber nicht wieso :(",
  "id" : 1627783408,
  "in_reply_to_status_id" : 1627773393,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627850147",
  "text" : "@JoergR Ja gut, das einzige was ich erledigen muss ist auf RB die Citation zu erstellen und dann dauert es etwas bis es da auftaucht.",
  "id" : 1627850147,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1627851269",
  "text" : "@JoergR Aber das sollte ja nichts an den Zugriffszahlen \u00E4ndern. :)",
  "id" : 1627851269,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1628520106",
  "text" : "Auch \u00C4rzte sollten schreiben k\u00F6nnen. Vor allem die Briefe an Kollegen & Patienten...",
  "id" : 1628520106,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1628537464",
  "geo" : { },
  "id_str" : "1628574499",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Ja, aber nicht nur das Schriftbild. Entweder zu viel Fachchinesisch oder so f\u00FCr Dumme geschrieben dass Infowert == 0",
  "id" : 1628574499,
  "in_reply_to_status_id" : 1628537464,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn",
      "screen_name" : "johnny_cash",
      "indices" : [ 0, 12 ],
      "id_str" : "15582200",
      "id" : 15582200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1628934979",
  "geo" : { },
  "id_str" : "1628959404",
  "in_reply_to_user_id" : 15582200,
  "text" : "@johnny_cash Die \u201CZur\u00FCck in die Zukunft\u201D-Fans m\u00FCssen damit schon lange leben ;)",
  "id" : 1628959404,
  "in_reply_to_status_id" : 1628934979,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "johnny_cash",
  "in_reply_to_user_id_str" : "15582200",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1629122218",
  "text" : "Manchmal ist Wordpress einfach nur schwarze Magie oder?",
  "id" : 1629122218,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1630085832",
  "text" : "Hab endlich 2 coole Paper zum verbloggen gefunden!",
  "id" : 1630085832,
  "created_at" : "2009-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1619448100",
  "text" : "Was freue ich mich gleich auf eine Badewanne!",
  "id" : 1619448100,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1619982131",
  "text" : "Frisch aus der Wanne f\u00FChlt man sich gleich viel besser.",
  "id" : 1619982131,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620071786",
  "text" : "Wunderte mich gerade wieso der Akku vom MBP nur so kurz h\u00E4lt. Dann gemerkt: Das iPhone wird ja auch dr\u00FCber geladen!",
  "id" : 1620071786,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620086093",
  "text" : "listening to \"Van_Morrison_Bob_Dylan-_Crazy_Love - \" \u266B http:\/\/blip.fm\/~5028r",
  "id" : 1620086093,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620090270",
  "text" : "Hab vergessen den Text zum blip einzugeben, aber das klappt ja auch so ganz gro\u00DFartig. Geilste Bootleg-CD mit besten Duets ever.",
  "id" : 1620090270,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save_the_wolves",
      "screen_name" : "Save_the_wolves",
      "indices" : [ 0, 16 ],
      "id_str" : "24501743",
      "id" : 24501743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620113174",
  "in_reply_to_user_id" : 24501743,
  "text" : "@save_the_wolves Together Through Life meinste? Kommt das nicht erst in 2 Tagen raus?  \u266B http:\/\/blip.fm\/~502h4",
  "id" : 1620113174,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Save_the_wolves",
  "in_reply_to_user_id_str" : "24501743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save_the_wolves",
      "screen_name" : "Save_the_wolves",
      "indices" : [ 0, 16 ],
      "id_str" : "24501743",
      "id" : 24501743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620148535",
  "in_reply_to_user_id" : 24501743,
  "text" : "@save_the_wolves Verstehe, verstehe. Das Internet war mal wieder schneller als die offizielle Ver\u00F6ffentlichung. H\u00E4tte ich mir denken k\u00F6nnen.",
  "id" : 1620148535,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Save_the_wolves",
  "in_reply_to_user_id_str" : "24501743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620308645",
  "text" : "Ganz sch\u00F6n coole Fotos vom Lager gemacht. Gleich mal in Lightroom entwickeln.",
  "id" : 1620308645,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1620410938",
  "text" : "Oh, seit wann ist das flickr-Plugin f\u00FCr Lightroom denn Donationware mit Trialperiode? Wohl zu lang nichts hochgeladen.",
  "id" : 1620410938,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1621747908",
  "text" : "Neuer Blogpost: Fotos aus dem Roverlager http:\/\/tr.im\/jKHQ",
  "id" : 1621747908,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1621751907",
  "text" : "Hab den Eindruck dass die SMS-Systeme von T-Mobile heute \u00FCberlastet sind. Senden dauert ewig und die Nachrichten kommen mit Verz\u00F6gerung an.",
  "id" : 1621751907,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1621789674",
  "geo" : { },
  "id_str" : "1621815874",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ich weiss auch nicht ;)",
  "id" : 1621815874,
  "in_reply_to_status_id" : 1621789674,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1621839431",
  "geo" : { },
  "id_str" : "1622307616",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch ne wundert mich \u00FCberhaupt nicht...",
  "id" : 1622307616,
  "in_reply_to_status_id" : 1621839431,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wunschkonzert",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1622651757",
  "text" : "Hat wer einen Tipp wor\u00FCber wir bei W&W morgen mal bloggen sollten? #Wunschkonzert",
  "id" : 1622651757,
  "created_at" : "2009-04-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1611339573",
  "text" : "Moin moin. So verkatert ist hier niemand. Das wundert mich!",
  "id" : 1611339573,
  "created_at" : "2009-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1612019978",
  "text" : "Mein Beitrag bei W&W zum Weltmalariatag: http:\/\/tinyurl.com\/dz3m3o",
  "id" : 1612019978,
  "created_at" : "2009-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1612028430",
  "text" : "Und Philipps Beitrag zu Malaria jetzt bei W&W: http:\/\/tinyurl.com\/c5fn4o :)",
  "id" : 1612028430,
  "created_at" : "2009-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1612239414",
  "text" : "Der n\u00E4chste Pfadfinderfilm wird ein Krimi. Die \u201EDreharbeiten\u201C laufen.",
  "id" : 1612239414,
  "created_at" : "2009-04-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602326460",
  "text" : "@houellebeck Schade drum ;)",
  "id" : 1602326460,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602351964",
  "text" : "Wof\u00FCr hab ich beim Nature-Abo eigentlich Bezahlung auf Rechnung angegeben wenn sie das Geld nun doch einfach einziehen?",
  "id" : 1602351964,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1602380899",
  "geo" : { },
  "id_str" : "1602396020",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Du hast Mail :)",
  "id" : 1602396020,
  "in_reply_to_status_id" : 1602380899,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602417756",
  "text" : "user-generated-fail: http:\/\/tr.im\/jAMQ",
  "id" : 1602417756,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1602403112",
  "geo" : { },
  "id_str" : "1602420513",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja, ganz praktisch dieser Austausch. Sonst hilft aber auch die Blogsearch\/Researchblogging und die Blogautoren anschreiben ;)",
  "id" : 1602420513,
  "in_reply_to_status_id" : 1602403112,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1602415392",
  "geo" : { },
  "id_str" : "1602423530",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Immerhin besser als um 5 Uhr morgens anfangen weil man sonst keinen Termin f\u00FCrs Konfokalmikroskop bekommt :P",
  "id" : 1602423530,
  "in_reply_to_status_id" : 1602415392,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1602437590",
  "geo" : { },
  "id_str" : "1602449486",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Kann gut sein, Yahoo-Questions l\u00E4d ja gerade dazu ein Fakes zu machen :)",
  "id" : 1602449486,
  "in_reply_to_status_id" : 1602437590,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1602570956",
  "geo" : { },
  "id_str" : "1602583731",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Wie das halt ist wenn der Chef nicht weiss dass die Slides pr\u00E4perieren einfach mal 6 Stunden dauert.Und einen Termin um 12 ansetzt",
  "id" : 1602583731,
  "in_reply_to_status_id" : 1602570956,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1603779381",
  "text" : "Prinzipiell ist eingekauft und gepackt. Das Gehenteil wird sich heute Abend zeigen",
  "id" : 1603779381,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1603937018",
  "text" : "RT @Fischblog: Fun fact: Ein Facebook-Nutzer ist 17-mal so viel wert wie jemand, der in einem Malaria-Gebiet wohnt.",
  "id" : 1603937018,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1604038459",
  "text" : "Was ich \u00FCbrigens als erste gepackt habe: iPhone-Ladeger\u00E4t!",
  "id" : 1604038459,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1605913092",
  "text" : "Grillen!",
  "id" : 1605913092,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1606034713",
  "geo" : { },
  "id_str" : "1606383495",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex danke, das machen wir! :)",
  "id" : 1606383495,
  "in_reply_to_status_id" : 1606034713,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1606403363",
  "text" : "Wikingerschach aka Flunkyball ohne saufen!  http:\/\/twitpic.com\/3wqst",
  "id" : 1606403363,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1601491904",
  "text" : "Ausnahmsweise mal nicht verschlafen, aber womit Fang ich nun an?",
  "id" : 1601491904,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1601539063",
  "text" : "\u201EWir sind im Krieg\u201CAch die christ. Extremisten. Abtreibungs\u00E4rzte am liebsten abknallen aber selbst Kinder knallen. http:\/\/tinyurl.com\/ccj3fm",
  "id" : 1601539063,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1601653643",
  "text" : "Als erste Aktion: Badewanne. Gute Wahl, danach hei\u00DFt es schreiben und dann packen.",
  "id" : 1601653643,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602116491",
  "text" : "Beitrag zum Malaria-Tag ist schonmal fertig und vorgemerkt. Nun kann ich mal schonmal meine Sachen packen.",
  "id" : 1602116491,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602254358",
  "text" : "@houellebeck Biste unter die Piraten gegangen? :)",
  "id" : 1602254358,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602282324",
  "text" : "@houellebeck Okay. Willst im Film mitspielen? :)",
  "id" : 1602282324,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1602303291",
  "text" : "@houellebeck Und danach darf es dann die Weltherrschaft sein oder wie? ;)",
  "id" : 1602303291,
  "created_at" : "2009-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1592354895",
  "text" : "Aufstehen und keine Zigaretten haben ist M\u00FCll. Noch schlimmer: Nichtmal Kleingeld f\u00FCr den Automaten haben.",
  "id" : 1592354895,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Peel",
      "screen_name" : "EmmaPeel_",
      "indices" : [ 0, 10 ],
      "id_str" : "17408013",
      "id" : 17408013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1592415118",
  "geo" : { },
  "id_str" : "1592421494",
  "in_reply_to_user_id" : 17408013,
  "text" : "@EmmaPeel_ 17 ist perfekt :) 14 geht aber im Sommer f\u00FCr eine Woche ;)",
  "id" : 1592421494,
  "in_reply_to_status_id" : 1592415118,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "EmmaPeel_",
  "in_reply_to_user_id_str" : "17408013",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sucht",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1592376342",
  "geo" : { },
  "id_str" : "1592423377",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ja. Deshalb Fahr ich nun zur Tankstelle #sucht",
  "id" : 1592423377,
  "in_reply_to_status_id" : 1592376342,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1592646235",
  "text" : "Oh verdammt, das hier ist der langweiligste Kurs ever...",
  "id" : 1592646235,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fragezeichner",
      "screen_name" : "fragezeichner",
      "indices" : [ 3, 17 ],
      "id_str" : "22900501",
      "id" : 22900501
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensursula",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1592737314",
  "text" : "RT @fragezeichner: \"Und wie in alten Schultagen f\u00FChl ich beklommen: Wir haben eine miserable Zensur bekommen!\" (Kurt Tucholsky) #zensursula",
  "id" : 1592737314,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593126668",
  "text" : "Ich kenne da eine Vorlesung die ich nicht mehr besuchen werde.",
  "id" : 1593126668,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593307264",
  "text" : "@JoergR Eine gute Wahl! :)",
  "id" : 1593307264,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593326734",
  "text" : "Heute vor 25 Jahren: HIV-Entdeckung von US-Ministerin bekanntgegeben. \u201CInnerhalb von 2 Jahren wird es sicher einen Impfstoff geben\u201D #fail",
  "id" : 1593326734,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "science",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593488990",
  "text" : "Neuer W&W-Post: Experimente im Internet - Anthropogener Allee-Effekt http:\/\/tr.im\/jvfC #PRLit #science #wissenschaft",
  "id" : 1593488990,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593497634",
  "text" : "Und schon wieder eine Frage: Hat jemand den Zugriff auf Enviromental Microbiology Reports? DOI 10.1111\/j.1758-2229.2009.00014.x",
  "id" : 1593497634,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn",
      "screen_name" : "johnny_cash",
      "indices" : [ 3, 15 ],
      "id_str" : "15582200",
      "id" : 15582200
    }, {
      "name" : "aptgetupdateDE",
      "screen_name" : "aptgetupdate",
      "indices" : [ 72, 85 ],
      "id_str" : "190200978",
      "id" : 190200978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593667663",
  "text" : "RT @johnny_cash: leaked: der Leyenfilter http:\/\/tinyurl.com\/dhbvk7 (via @aptgetupdate)",
  "id" : 1593667663,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1593816937",
  "geo" : { },
  "id_str" : "1593947089",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Schade, aber man kann ja nicht immer Gl\u00FCck haben :)",
  "id" : 1593947089,
  "in_reply_to_status_id" : 1593816937,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1593982603",
  "text" : "TimeMachine hat mir gerade den Arsch gerettet. Sch\u00F6n wichtige Dokumente doch noch zu haben.",
  "id" : 1593982603,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1594048032",
  "geo" : { },
  "id_str" : "1594112147",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Fail as fail can be! ;)",
  "id" : 1594112147,
  "in_reply_to_status_id" : 1594048032,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1594292629",
  "text" : "Magpie-User werden dann mal unfollowt. Werbung brauch ich nicht im Stream hier.",
  "id" : 1594292629,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PZ Myers",
      "screen_name" : "pzmyers",
      "indices" : [ 18, 26 ],
      "id_str" : "8005492",
      "id" : 8005492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1594697964",
  "text" : "Sch\u00F6ne Idee :) RT @pzmyers: Help me win an iPod....from Eric Hovind!  http:\/\/tr.im\/jw5B",
  "id" : 1594697964,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1594596225",
  "geo" : { },
  "id_str" : "1594739385",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt das bezieht sich aber nur auf Deutschland oder?",
  "id" : 1594739385,
  "in_reply_to_status_id" : 1594596225,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1594826266",
  "geo" : { },
  "id_str" : "1595169963",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt ja, aber Weltweit w\u00E4re es noch krasser :)",
  "id" : 1595169963,
  "in_reply_to_status_id" : 1594826266,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1596606645",
  "geo" : { },
  "id_str" : "1596634396",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Was f\u00FCr eine seltsame App ist das? ;)",
  "id" : 1596634396,
  "in_reply_to_status_id" : 1596606645,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1596639970",
  "text" : "Boah was geht mir Valve auf die Nerven. Wieso kann Steam eigentlich nicht funktionieren wenn man es benutzen will?",
  "id" : 1596639970,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1596721912",
  "geo" : { },
  "id_str" : "1596726724",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ok, dann bleib ich bei texxas ;)",
  "id" : 1596726724,
  "in_reply_to_status_id" : 1596721912,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1597235340",
  "text" : "Morgen viel zu tun mit den letzten Lagervorbereitungen! Und der Malaria-Artikel muss auch noch zu ende geschrieben werden!",
  "id" : 1597235340,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1597504436",
  "geo" : { },
  "id_str" : "1597709804",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger ist doch nah an der Wahrheit dran ;)",
  "id" : 1597709804,
  "in_reply_to_status_id" : 1597504436,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1584253900",
  "text" : "Epic Fail: BioInformatics packt in die PDFs keinen DOI rein. Bei jedem anderen Journal h\u00E4tte ich mehr Verst\u00E4ndnis...",
  "id" : 1584253900,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "PRLit",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "science",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1584266147",
  "text" : "Neuer W&W-Post: Ein Genombrowser f\u00FCr jeden, GBrowse jetzt als Webdienst. http:\/\/tr.im\/jpzA #wundw #PRLit #science #wissenschaft",
  "id" : 1584266147,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rummaulen",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1584307146",
  "text" : "Und sowieso: BioInformatics sollte mal auf Open Access umstellen #rummaulen",
  "id" : 1584307146,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584329470",
  "geo" : { },
  "id_str" : "1584344455",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Stimmt, aber dazu muss man ja auch nicht ellenlang schreiben. Interessiert eh nur Biologen die das Grundprinzip kennen :)",
  "id" : 1584344455,
  "in_reply_to_status_id" : 1584329470,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584329470",
  "geo" : { },
  "id_str" : "1584350497",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Abgesehen davon ist das dazugeh\u00F6rige \u201CPaper\u201D auch nur 2 Seiten lang und umfasst fast keinerlei Infos zur technischen Umsetzung",
  "id" : 1584350497,
  "in_reply_to_status_id" : 1584329470,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584358938",
  "geo" : { },
  "id_str" : "1584384931",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Werden die Forscher auch die Absolution bekommen weil sie im Auftrag der Regierung gehandelt haben? ;)",
  "id" : 1584384931,
  "in_reply_to_status_id" : 1584358938,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584393362",
  "geo" : { },
  "id_str" : "1584400572",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog An welchen Terroranschl\u00E4gen waren die denn beteiligt? Der letzte mir bekannte war 1955: Tarantula! :)",
  "id" : 1584400572,
  "in_reply_to_status_id" : 1584393362,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584393738",
  "geo" : { },
  "id_str" : "1584404765",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Hat schon fast mehr etwas von Pressemitteilung. Aber von denen hat man als Wissenschaftler ja nix ;)",
  "id" : 1584404765,
  "in_reply_to_status_id" : 1584393738,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 75, 87 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1584424438",
  "text" : "\u201CGlobal warming is just a theory, like evolution. Or the metric system\u201D RT @gillyberlin: F*ck the Earth Day http:\/\/tr.im\/jpFy",
  "id" : 1584424438,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Monster",
      "screen_name" : "sally_monster",
      "indices" : [ 0, 14 ],
      "id_str" : "9014892",
      "id" : 9014892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584502121",
  "geo" : { },
  "id_str" : "1584517363",
  "in_reply_to_user_id" : 9014892,
  "text" : "@sally_monster I just started downloading it :)",
  "id" : 1584517363,
  "in_reply_to_status_id" : 1584502121,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "sally_monster",
  "in_reply_to_user_id_str" : "9014892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1586186794",
  "text" : "Der Hund hat sich erk\u00E4ltet. Nun w\u00FCrgt und niest er vor sich hin. Was geht er auch immer so viel baden? ;)",
  "id" : 1586186794,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1586212472",
  "text" : "Sind hier denn keine Studenten mehr die \u00FCber ihre Erfahrungen mit Bologna erz\u00E4hlen m\u00F6chten?",
  "id" : 1586212472,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583797181",
  "geo" : { },
  "id_str" : "1586542427",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist ganz okay, aber der Witz von WNYC fehlt etwas. Ist doch ehr typisch deutsch ;)",
  "id" : 1586542427,
  "in_reply_to_status_id" : 1583797181,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mendeley",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1586596143",
  "text" : "Gerade mal alle Paper in #mendeley konsequent getaggt. Ohne ordentliche Tags hilft auch die beste Software dann nicht mehr.",
  "id" : 1586596143,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1586609462",
  "geo" : { },
  "id_str" : "1586639304",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, aber diese Art von Moderation ist es die WNYC aus der Menge abhebt und besonders macht. Sowas haben wir nicht. :(",
  "id" : 1586639304,
  "in_reply_to_status_id" : 1586609462,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1586695052",
  "geo" : { },
  "id_str" : "1587570138",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Weil es k\u00FCrzer ist :P",
  "id" : 1587570138,
  "in_reply_to_status_id" : 1586695052,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1587698438",
  "geo" : { },
  "id_str" : "1588211227",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Spricht da was gegen? ;)",
  "id" : 1588211227,
  "in_reply_to_status_id" : 1587698438,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1588253397",
  "text" : "Wow, es kommen doch am Wochenende in der Tat 10 Kinder mit Ins Roverlager der Pfadfinder. Ich bin positiv \u00FCberrascht.",
  "id" : 1588253397,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Peel",
      "screen_name" : "EmmaPeel_",
      "indices" : [ 0, 10 ],
      "id_str" : "17408013",
      "id" : 17408013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1588279379",
  "geo" : { },
  "id_str" : "1588351593",
  "in_reply_to_user_id" : 17408013,
  "text" : "@EmmaPeel_ Wenn sie so um die 16 Jahre alt sind ja. Sonst muss ich dich leider an die anderen Stufen verweisen ;)",
  "id" : 1588351593,
  "in_reply_to_status_id" : 1588279379,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "EmmaPeel_",
  "in_reply_to_user_id_str" : "17408013",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verein MOGiS",
      "screen_name" : "mogisverein",
      "indices" : [ 0, 12 ],
      "id_str" : "31711197",
      "id" : 31711197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1588290566",
  "geo" : { },
  "id_str" : "1588367527",
  "in_reply_to_user_id" : 31711197,
  "text" : "@mogisverein Ja,alles sehr subversive Elemente die sich da bei uns rumtreiben.Kath. Jugendgruppe, findet den Atheistbus gut, Gott bl\u00F6d. :P",
  "id" : 1588367527,
  "in_reply_to_status_id" : 1588290566,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mogisverein",
  "in_reply_to_user_id_str" : "31711197",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1582350665",
  "text" : "Morgen! Und ab geht es zur Mathevorlesung.",
  "id" : 1582350665,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1582398700",
  "geo" : { },
  "id_str" : "1582533221",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em daf\u00FCr muss ich zur Zeit nur an 2 Tagen in die Uni :)",
  "id" : 1582533221,
  "in_reply_to_status_id" : 1582398700,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1582615442",
  "geo" : { },
  "id_str" : "1582682885",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em wenn man schon so fr\u00FCh aufgestanden ist kann man die Zeit auch nutzen!",
  "id" : 1582682885,
  "in_reply_to_status_id" : 1582615442,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immernochbegeistert",
      "indices" : [ 62, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1583449175",
  "text" : "Hab ich schonmal gesagt wie toll ich die WNYC-Podcasts finde? #immernochbegeistert",
  "id" : 1583449175,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583569075",
  "geo" : { },
  "id_str" : "1583607487",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Gerade hab ich mich \u00FCber die aktuelle Sendung von RadioLab gefreut. Die sind mit so viel Liebe zum Detail produziert.",
  "id" : 1583607487,
  "in_reply_to_status_id" : 1583569075,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583666370",
  "geo" : { },
  "id_str" : "1583671194",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich hatte die noch nicht geh\u00F6rt, von daher bin ich \u00FCber die Reposts von Zeit zu Zeit ganz gl\u00FCcklich.",
  "id" : 1583671194,
  "in_reply_to_status_id" : 1583666370,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583670812",
  "geo" : { },
  "id_str" : "1583683396",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ne, \u00FCberlege auch denen was f\u00FCr ihre wirklich gute Arbeit zu spenden. F\u00FCr sowas in Deutschland w\u00FCrde man ja auch gern GEZ zahlen.",
  "id" : 1583683396,
  "in_reply_to_status_id" : 1583670812,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583704994",
  "geo" : { },
  "id_str" : "1583760027",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das kenne ich noch nicht. Gleich mal suchen.",
  "id" : 1583760027,
  "in_reply_to_status_id" : 1583704994,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583797181",
  "geo" : { },
  "id_str" : "1583824042",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Danke, werd ich gleich abonnieren.",
  "id" : 1583824042,
  "in_reply_to_status_id" : 1583797181,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583889538",
  "geo" : { },
  "id_str" : "1583910451",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Mit was genau arbeitest denn? :)",
  "id" : 1583910451,
  "in_reply_to_status_id" : 1583889538,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583934528",
  "geo" : { },
  "id_str" : "1583937927",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Und was hast du sch\u00F6nes radioaktives zum spielen? :)",
  "id" : 1583937927,
  "in_reply_to_status_id" : 1583934528,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1584135844",
  "text" : "Cool: WebGBrowse, f\u00FCr jeden der nicht selber frickeln will. Gleich mal dr\u00FCber bloggen. http:\/\/tr.im\/jpuN",
  "id" : 1584135844,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1584200238",
  "geo" : { },
  "id_str" : "1584240634",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja, aber da kannst du deine Sequenzen nur zum Referenzgenom sehen. Nicht zu einem eigenen was du hochladen kannst?",
  "id" : 1584240634,
  "in_reply_to_status_id" : 1584200238,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mutagene",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1583941835",
  "geo" : { },
  "id_str" : "1584244093",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das w\u00E4re ne coole Idee #mutagene",
  "id" : 1584244093,
  "in_reply_to_status_id" : 1583941835,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1573523425",
  "text" : "Verdammt, wof\u00FCr stell ich den Wecker wenn ich dann doch wieder einschlafe!",
  "id" : 1573523425,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bologna",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1573539975",
  "text" : "Neuer W&W Post von Linus (kennt ihr den noch?): Bologna vs Bolognese - Teil 5, wie sieht es in Cambridge aus? http:\/\/tr.im\/jiWL #bologna",
  "id" : 1573539975,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573531414",
  "geo" : { },
  "id_str" : "1573541251",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Peter Lustig? :)",
  "id" : 1573541251,
  "in_reply_to_status_id" : 1573531414,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetie",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573596025",
  "geo" : { },
  "id_str" : "1573632437",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Sieht nett aus, kann ein bisschen was. Wird bei mir aber in der Form noch nicht Eventbox abl\u00F6sen k\u00F6nnen. #tweetie",
  "id" : 1573632437,
  "in_reply_to_status_id" : 1573596025,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 3, 15 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1573708704",
  "text" : "RT @houellebeck: Evolution und Kirche sind kein Widerspruch, wie dieses Bildzeugnis beweist: http:\/\/tr.im\/jj5b :-)",
  "id" : 1573708704,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573745419",
  "geo" : { },
  "id_str" : "1573750796",
  "in_reply_to_user_id" : 14699615,
  "text" : "@Blugger Ich glaube das w\u00E4re mir recht egal wenn ich tot bin ;)",
  "id" : 1573750796,
  "in_reply_to_status_id" : 1573745419,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1573758647",
  "text" : "Und da sag nochmal einer \u00D6kologie w\u00E4re nicht was sinnvolles! http:\/\/tr.im\/jj8o",
  "id" : 1573758647,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1573767604",
  "in_reply_to_user_id" : 13823092,
  "text" : "@skl8em at work! http:\/\/tr.im\/jj8W :)",
  "id" : 1573767604,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573826643",
  "geo" : { },
  "id_str" : "1573847407",
  "in_reply_to_user_id" : 14699615,
  "text" : "@Blugger \u00DCberhaupt nicht. Aber ich bezweifle nur das man nach seinem eigenem Tod etwas davon mitbekommt was der Rest so treibt.",
  "id" : 1573847407,
  "in_reply_to_status_id" : 1573826643,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573881879",
  "geo" : { },
  "id_str" : "1573887774",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Yeah kein Spam mehr in Eventbox ;)",
  "id" : 1573887774,
  "in_reply_to_status_id" : 1573881879,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1573902304",
  "geo" : { },
  "id_str" : "1573910001",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ist ja kein Problem, gibt ja den praktischen Mark all As Read-Button ;)",
  "id" : 1573910001,
  "in_reply_to_status_id" : 1573902304,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1574150419",
  "text" : "Neuer W&W-Post: Die Bilder der NASA - http:\/\/tr.im\/jjsQ",
  "id" : 1574150419,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "As df",
      "screen_name" : "dreisechzig",
      "indices" : [ 0, 12 ],
      "id_str" : "226525627",
      "id" : 226525627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1574397387",
  "text" : "@dreisechzig gilt das auch f\u00FCr PC?",
  "id" : 1574397387,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1575043286",
  "text" : "@houellebeck Ausgezeichnete Idee! Morgen fr\u00FCh vor dem Dom? ;)",
  "id" : 1575043286,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1575225999",
  "text" : "M\u00F6chte eigentlich noch wer bei unserer Bologna-Serie Mitmachen? Wir Freuen uns \u00FCber jede Meinung und jeden Erfahrungsbericht!",
  "id" : 1575225999,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1575342835",
  "text" : "Was in der Post war!  http:\/\/twitpic.com\/3pqfw",
  "id" : 1575342835,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1575377959",
  "geo" : { },
  "id_str" : "1575445491",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hab die Vorlage f\u00FCr den Druck selbst zusammengebastelt und vom Druckmenschen ins passende Format konvertieren lassen.",
  "id" : 1575445491,
  "in_reply_to_status_id" : 1575377959,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1576150702",
  "geo" : { },
  "id_str" : "1576362576",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 das ist selbst nachgemacht nach den originalen Shirts, hab es bei www.druffgedruckt.de machen lassen.",
  "id" : 1576362576,
  "in_reply_to_status_id" : 1576150702,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 3, 8 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1576578720",
  "text" : "RT @U9TA: Anti-Kinderpornoverordnung von vdLeyen wirkt bereits. Nach Oben-Ohne-MMS einer 14j wurde T-Offline erfolgreich gesperrt.",
  "id" : 1576578720,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1576582134",
  "text" : "@JoergR Du wolltest es ja nicht anders :)",
  "id" : 1576582134,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1576618051",
  "geo" : { },
  "id_str" : "1576627920",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Falsch, korrekt w\u00E4re gewesen: \u201CWas ist schwarzer Humor?\u201D ;)",
  "id" : 1576627920,
  "in_reply_to_status_id" : 1576618051,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bologna",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "science",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 109, 122 ]
    }, {
      "text" : "wundw",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1576806528",
  "text" : "Neuer Post bei W&W: Bologna vs. Bolognese - Teil 6: Noch mehr Interviews http:\/\/tr.im\/jlgf #bologna #science #wissenschaft #wundw",
  "id" : 1576806528,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Sommer",
      "screen_name" : "csommer",
      "indices" : [ 0, 8 ],
      "id_str" : "14436873",
      "id" : 14436873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1576905893",
  "geo" : { },
  "id_str" : "1576927558",
  "in_reply_to_user_id" : 14436873,
  "text" : "@csommer Bundesweit kann nicht sein, denn hier geht es tadellos :D #muenster",
  "id" : 1576927558,
  "in_reply_to_status_id" : 1576905893,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "csommer",
  "in_reply_to_user_id_str" : "14436873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Sommer",
      "screen_name" : "csommer",
      "indices" : [ 0, 8 ],
      "id_str" : "14436873",
      "id" : 14436873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1576955013",
  "geo" : { },
  "id_str" : "1576983165",
  "in_reply_to_user_id" : 14436873,
  "text" : "@csommer Ja, aber hier war den ganzen Nachmittag das Netz nicht weg. War die ganze Zeit mit dem iPhone \u00FCber EDGE online.",
  "id" : 1576983165,
  "in_reply_to_status_id" : 1576955013,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "csommer",
  "in_reply_to_user_id_str" : "14436873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1576983750",
  "geo" : { },
  "id_str" : "1577011390",
  "in_reply_to_user_id" : 14699615,
  "text" : "@Blugger Das ist mal eine vern\u00FCnftige Abwrackpr\u00E4mie. :)",
  "id" : 1577011390,
  "in_reply_to_status_id" : 1576983750,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till Achinger",
      "screen_name" : "pfandtasse",
      "indices" : [ 0, 11 ],
      "id_str" : "7147062",
      "id" : 7147062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1577305723",
  "geo" : { },
  "id_str" : "1577326051",
  "in_reply_to_user_id" : 7147062,
  "text" : "@pfandtasse K\u00F6nnen uns ja mal zum Poken treffen ;)",
  "id" : 1577326051,
  "in_reply_to_status_id" : 1577305723,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfandtasse",
  "in_reply_to_user_id_str" : "7147062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 62, 69 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1578034054",
  "text" : "Was passiert wenn man seine Moral aus der Bibel bezieht... RT @ComPod: Mir wird schon wieder kotz\u00FCbel. http:\/\/tr.im\/jm4h",
  "id" : 1578034054,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till",
      "screen_name" : "tillemann",
      "indices" : [ 0, 10 ],
      "id_str" : "21517169",
      "id" : 21517169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1578118308",
  "geo" : { },
  "id_str" : "1578135519",
  "in_reply_to_user_id" : 21517169,
  "text" : "@tillemann Das nennt man Abwrackpr\u00E4mie 2.0 ;)",
  "id" : 1578135519,
  "in_reply_to_status_id" : 1578118308,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "tillemann",
  "in_reply_to_user_id_str" : "21517169",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till",
      "screen_name" : "tillemann",
      "indices" : [ 0, 10 ],
      "id_str" : "21517169",
      "id" : 21517169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1578151472",
  "geo" : { },
  "id_str" : "1578162476",
  "in_reply_to_user_id" : 21517169,
  "text" : "@tillemann Stimmt, aber auch ziemlich nah an der Realit\u00E4t gleichzeitig ;)",
  "id" : 1578162476,
  "in_reply_to_status_id" : 1578151472,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "tillemann",
  "in_reply_to_user_id_str" : "21517169",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1578184405",
  "text" : "Die Besucherstatistiken von W&W sehen stark nach S\u00E4gezahnschwingungen aus. Lustiges Bild.",
  "id" : 1578184405,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1578362478",
  "text" : "Da Twitpic down ist nun so: Religion, now inclues: Pedo Bear - Seal Of Approval! http:\/\/yfrog.com\/09l9yj",
  "id" : 1578362478,
  "created_at" : "2009-04-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1568010587",
  "text" : "Den Zug nach M\u00FCnster gerade noch so bekommen. Also so Arbeitskreise == Tierisch Ineffizient",
  "id" : 1568010587,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 17, 24 ],
      "id_str" : "13823092",
      "id" : 13823092
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 43, 59 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ms",
      "indices" : [ 105, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1568075981",
  "text" : "Will wer mit? RT @Skl8em: Gleich gehts mit @gedankenstuecke den hafen fotografieren! Freue mich schon :) #ms",
  "id" : 1568075981,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 37, 44 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1569355848",
  "text" : "Und wieder da von der Fotosafari mit @skl8em :)",
  "id" : 1569355848,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1569729289",
  "text" : "Ach Lightroom, jetzt zick mal nicht so rum und exportier brav die Fotos zu Flickr!",
  "id" : 1569729289,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1569940508",
  "text" : "Die 2.5 Zoll Platte mit FW-Anschluss war die beste Investition seit l\u00E4ngerem. Und jetzt #gn8",
  "id" : 1569940508,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564043411",
  "text" : "Moin moin!",
  "id" : 1564043411,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 62, 71 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "bologna",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "science",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564097068",
  "text" : "Neuer W&W-Post: Bologna vs. Bolognese - Teil 4, Interview mit @Argent23 http:\/\/tr.im\/jddb #wundw #bologna #science #wissenschaft",
  "id" : 1564097068,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klisch",
      "screen_name" : "klischnet",
      "indices" : [ 0, 10 ],
      "id_str" : "5744062",
      "id" : 5744062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564112433",
  "geo" : { },
  "id_str" : "1564116600",
  "in_reply_to_user_id" : 5744062,
  "text" : "@klischnet K\u00FChlschrank, Waschmaschine etc? ;)",
  "id" : 1564116600,
  "in_reply_to_status_id" : 1564112433,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "klischnet",
  "in_reply_to_user_id_str" : "5744062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564178805",
  "geo" : { },
  "id_str" : "1564207997",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Danke :)",
  "id" : 1564207997,
  "in_reply_to_status_id" : 1564178805,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564236788",
  "geo" : { },
  "id_str" : "1564247594",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ne, ganz im Gegenteil. Ist ganz nett zu sehen wenn Leute auch lesen was man so an Inhalten produziert :)",
  "id" : 1564247594,
  "in_reply_to_status_id" : 1564236788,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564242682",
  "geo" : { },
  "id_str" : "1564250049",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Fernausleihe 2.0? :)",
  "id" : 1564250049,
  "in_reply_to_status_id" : 1564242682,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564298329",
  "text" : "JU stand doch f\u00FCr Junge Unterbelichtete oder? http:\/\/tr.im\/jdmM",
  "id" : 1564298329,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564303796",
  "text" : "Ich k\u00F6nnte das komplette Album st\u00E4ndig blippen. \u266B http:\/\/blip.fm\/~4mlh1",
  "id" : 1564303796,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564332516",
  "geo" : { },
  "id_str" : "1564341334",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Gar nicht aktiv. Lasse Twitter reinlaufen und logge h\u00F6chstens bei Nachrichten und so Zeugs ein.",
  "id" : 1564341334,
  "in_reply_to_status_id" : 1564332516,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564480141",
  "text" : "Hund ist frisch im Brackwasser gebadet. Kann nun in der Sonne trocknen.",
  "id" : 1564480141,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564503353",
  "text" : "Oder er zerlegt seine Stofftiere weiter, zumindest in der Sonne.",
  "id" : 1564503353,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564527824",
  "geo" : { },
  "id_str" : "1564547448",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Cooles Feature! \u201C[...]twitter client that can point you to the right journal article or book when a friend posts a DOI[...]\u201D",
  "id" : 1564547448,
  "in_reply_to_status_id" : 1564527824,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564564203",
  "text" : "Ich muss sagen Tweetie f\u00FCr den Mac reisst mich jetzt wirklich nicht vom Hocker.",
  "id" : 1564564203,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564583525",
  "text" : "Au\u00DFer der Fotoansicht nichts was Eventbox nicht auch kann. Sonst aber sehr Basic an sich.",
  "id" : 1564583525,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DonDahlmann",
      "screen_name" : "DonDahlmann",
      "indices" : [ 0, 12 ],
      "id_str" : "1151281",
      "id" : 1151281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1564556989",
  "geo" : { },
  "id_str" : "1564598112",
  "in_reply_to_user_id" : 1151281,
  "text" : "@DonDahlmann Auch Bio-Produkte sind voller Chemikalien ;)",
  "id" : 1564598112,
  "in_reply_to_status_id" : 1564556989,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "DonDahlmann",
  "in_reply_to_user_id_str" : "1151281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atheist Bus",
      "screen_name" : "AtheistBus",
      "indices" : [ 3, 14 ],
      "id_str" : "18632045",
      "id" : 18632045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564625548",
  "text" : "RT @AtheistBus: http:\/\/twitpic.com\/3nfl6 - South London church has a go at us buses - but at least they have sense of humour.",
  "id" : 1564625548,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564825491",
  "text" : "Ich finde den gelesen-Status von Tweets in Eventbox super. Auch wenn es ein Hack ist.",
  "id" : 1564825491,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564835733",
  "text" : "Wie viele B\u00E4ume spart man wohl dadurch dass man die References nicht ausdruckt bei #PRLit ?",
  "id" : 1564835733,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564926236",
  "text" : "@JoergR DOI? ;)",
  "id" : 1564926236,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1564984443",
  "text" : "@JoergR DM mir mal deine Mailadresse :)",
  "id" : 1564984443,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1566722915",
  "text" : "Sommerlagervorbereitung!",
  "id" : 1566722915,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1556649367",
  "text" : "Heute morgen von bellenden Nachbarshunden geweckt. Bl\u00F6d.",
  "id" : 1556649367,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1556844789",
  "text" : "Hat eigentlich noch wer aus #muenster Lust morgen Abend ein bisschen zum fotografieren umherzustreunen?",
  "id" : 1556844789,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1556934274",
  "text" : "@rajue Kannst du die betroffenen Tweets nicht bei Tweetdeck ausfiltern lassen?",
  "id" : 1556934274,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1557470724",
  "geo" : { },
  "id_str" : "1557555505",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum ne, die verdammten Glocken haben die Hunde geweckt...",
  "id" : 1557555505,
  "in_reply_to_status_id" : 1557470724,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1557470724",
  "geo" : { },
  "id_str" : "1557560041",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Abgesehen davon: Ja ich finde dass das Glockenl\u00E4uten nichts anderes als Ruhest\u00F6rung ist. Als Privatmensch darf ich das nicht.",
  "id" : 1557560041,
  "in_reply_to_status_id" : 1557470724,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till Achinger",
      "screen_name" : "pfandtasse",
      "indices" : [ 0, 11 ],
      "id_str" : "7147062",
      "id" : 7147062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1557574813",
  "geo" : { },
  "id_str" : "1557577954",
  "in_reply_to_user_id" : 7147062,
  "text" : "@pfandtasse Ich hab auch schon :)",
  "id" : 1557577954,
  "in_reply_to_status_id" : 1557574813,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfandtasse",
  "in_reply_to_user_id_str" : "7147062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1557993182",
  "text" : "Heut ist Twitter ja so langsam. Also das Tempo in dem die Tweets vor den Augen vorbeiziehen!",
  "id" : 1557993182,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1558021335",
  "text" : "WTF? Wieso verfolgen nich heute so viele Esoterik-Freaks?",
  "id" : 1558021335,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1558283966",
  "geo" : { },
  "id_str" : "1558303281",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich mag ja vieles sein, aber das ganz sicher nicht :D",
  "id" : 1558303281,
  "in_reply_to_status_id" : 1558283966,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1558333656",
  "geo" : { },
  "id_str" : "1558345181",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Bin doch kein Windows-User mehr, da wird man vermutlich zwangsl\u00E4ufig zum Esoteriker.",
  "id" : 1558345181,
  "in_reply_to_status_id" : 1558333656,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1558507765",
  "text" : "Yeah, morgen geht mein \u201Cscience flies you to the moon. religion flies you into buildings\u201D-Shirt mit der Post raus!",
  "id" : 1558507765,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1558531812",
  "geo" : { },
  "id_str" : "1558569739",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist deine Standardantwort f\u00FCr unerkl\u00E4rliche Ph\u00E4nomene unter Windows etwa nicht: Neustarten? :D",
  "id" : 1558569739,
  "in_reply_to_status_id" : 1558531812,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1558569162",
  "geo" : { },
  "id_str" : "1558574280",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Humor gibt\u2019s auch so und so. Siehe auch den taz-Fall :)",
  "id" : 1558574280,
  "in_reply_to_status_id" : 1558569162,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1559168141",
  "geo" : { },
  "id_str" : "1559425167",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum das mag ich an dir!",
  "id" : 1559425167,
  "in_reply_to_status_id" : 1559168141,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bologna",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "wundw",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "science",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1559739672",
  "text" : "Neuer W&W-Post von Philipp: Bologna vs. Bolognese - Teil 3 - http:\/\/tr.im\/jb7G #bologna #wundw #science #wissenschaft",
  "id" : 1559739672,
  "created_at" : "2009-04-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verein MOGiS",
      "screen_name" : "mogisverein",
      "indices" : [ 0, 12 ],
      "id_str" : "31711197",
      "id" : 31711197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549615632",
  "geo" : { },
  "id_str" : "1549639380",
  "in_reply_to_user_id" : 31711197,
  "text" : "@mogisverein Ja, das ist mir bewusst. Das sind genau die Menschen vor denen sich eine Demokratie f\u00FCrchten sollte.",
  "id" : 1549639380,
  "in_reply_to_status_id" : 1549615632,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mogisverein",
  "in_reply_to_user_id_str" : "31711197",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1549651878",
  "text" : "Ach wie s\u00FC\u00DF der Hund doch ist: http:\/\/tr.im\/j6L3",
  "id" : 1549651878,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549736956",
  "geo" : { },
  "id_str" : "1549877616",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ja, wenn er das Teil nicht gerade begatten will ;)",
  "id" : 1549877616,
  "in_reply_to_status_id" : 1549736956,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1549936089",
  "text" : "Am Wochenende bloggen lohnt irgendwie NICHT, liest ja doch keiner. Vor allem bei dem Wetter.",
  "id" : 1549936089,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549940892",
  "geo" : { },
  "id_str" : "1549970797",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Hier ist warmer Sonnenschein. Besucherzahlen == 0 :)",
  "id" : 1549970797,
  "in_reply_to_status_id" : 1549940892,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549984024",
  "geo" : { },
  "id_str" : "1549986865",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ne ist allgemein so meine Erfahrung dass am Wochenende der Traffic stark runtergeht :)",
  "id" : 1549986865,
  "in_reply_to_status_id" : 1549984024,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549994721",
  "geo" : { },
  "id_str" : "1550020400",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Vielleicht ein Unterschied zwischen h\u00F6ren & lesen?",
  "id" : 1550020400,
  "in_reply_to_status_id" : 1549994721,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1550026553",
  "geo" : { },
  "id_str" : "1550362902",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Oder so :)",
  "id" : 1550362902,
  "in_reply_to_status_id" : 1550026553,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 109, 115 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 116, 129 ]
    }, {
      "text" : "science",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1551183145",
  "text" : "Neuer W&W-Post: Ein einfacher Trick zur Ged\u00E4chtnisverbesserung - Aber nur f\u00FCr Rechtsh\u00E4nder http:\/\/tr.im\/j7xH #wundw #wissenschaft #science",
  "id" : 1551183145,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1552090815",
  "text" : "tr.im ist ja echt ganz cool. Sehen zu k\u00F6nnen wie viele Leute so klicken ist nett.",
  "id" : 1552090815,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1552099916",
  "geo" : { },
  "id_str" : "1552121581",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Okay, aber im Endeffekt ist es auch v\u00F6llig egal welcher Dienst die URL kurz macht ;)",
  "id" : 1552121581,
  "in_reply_to_status_id" : 1552099916,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1552120424",
  "geo" : { },
  "id_str" : "1552132282",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Seh jetzt keinen so gro\u00DFen Unterschied zwischen bit.ly und tr.im. :)",
  "id" : 1552132282,
  "in_reply_to_status_id" : 1552120424,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1552157860",
  "geo" : { },
  "id_str" : "1552239267",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Ich glaube nicht, aber das interessiert mich auch nicht so :)",
  "id" : 1552239267,
  "in_reply_to_status_id" : 1552157860,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1552588755",
  "text" : "Also ich schau arte!",
  "id" : 1552588755,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Rudorfer",
      "screen_name" : "Bigod",
      "indices" : [ 0, 6 ],
      "id_str" : "3499741",
      "id" : 3499741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1546711535",
  "geo" : { },
  "id_str" : "1549426068",
  "in_reply_to_user_id" : 3499741,
  "text" : "@Bigod Frittierpalast? ;)",
  "id" : 1549426068,
  "in_reply_to_status_id" : 1546711535,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "Bigod",
  "in_reply_to_user_id_str" : "3499741",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1546039562",
  "geo" : { },
  "id_str" : "1549428371",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ok, dann halt nicht",
  "id" : 1549428371,
  "in_reply_to_status_id" : 1546039562,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1549562270",
  "text" : "F\u00FChle mich so nach Entropie in letzter Zeit: Nehme stetig zu!",
  "id" : 1549562270,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zensur",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1549578690",
  "text" : "War klar dass Die mit am wenigsten Ahnung vom Internets (aber viel Erfahrung mit P\u00E4dophilie) sich \u00FCber #Zensur freuen: http:\/\/tr.im\/j6Id",
  "id" : 1549578690,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1549590574",
  "geo" : { },
  "id_str" : "1549613641",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ich glaube das ist, neben in der Zensurbeh\u00F6rde zu arbeiten, der beste Job um an KiPo zu kommen.",
  "id" : 1549613641,
  "in_reply_to_status_id" : 1549590574,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541213992",
  "text" : "Neuer W&W-Post: Open Access - Teil 5: http:\/\/is.gd\/sVqS",
  "id" : 1541213992,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541218449",
  "text" : "Achja, ich hab nun rechts bei W&W mal eine kleine \"Feature-Leiste\u201D eingebaut die zu den Kategorien linkt. Noch nicht ganz ideal. #wundw",
  "id" : 1541218449,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541318435",
  "text" : "Perfekte Argumentation: http:\/\/is.gd\/sVCX",
  "id" : 1541318435,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541400329",
  "text" : "@njeppo Oder der Baggerfahrer den Kabelstrang erwischt?",
  "id" : 1541400329,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541414357",
  "text" : "@njeppo Hach es gibt ja so viele sch\u00F6ne M\u00F6glichkeiten das Internet stellenweise kaputt zu machen.",
  "id" : 1541414357,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541433900",
  "geo" : { },
  "id_str" : "1541449403",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Epic Fail-Kommentar w\u00FCrde ich sagen.",
  "id" : 1541449403,
  "in_reply_to_status_id" : 1541433900,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541463236",
  "geo" : { },
  "id_str" : "1541483872",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Versuch es doch, ein Blogbeitrag f\u00FCr dich springt doch in beiden F\u00E4llen raus :)",
  "id" : 1541483872,
  "in_reply_to_status_id" : 1541463236,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541496341",
  "geo" : { },
  "id_str" : "1541529050",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Dann bloggste es halt morgen",
  "id" : 1541529050,
  "in_reply_to_status_id" : 1541496341,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541647630",
  "text" : "Ah Fr\u00FChling. Dem Hund die erste Zecke des Jahres entfernt.",
  "id" : 1541647630,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 3, 10 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541650774",
  "text" : "RT @343max: Spon Hat den gro\u00DFartigen c't Artikel \u00FCber die Unwirksamkeit der Kinderpornosperren ver\u00F6ffentlicht. http:\/\/tr.im\/j2xL",
  "id" : 1541650774,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541682499",
  "text" : "@dasblogt Autsch, dem bin ich auch nur ganz knapp entgangen.",
  "id" : 1541682499,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541781927",
  "geo" : { },
  "id_str" : "1541961720",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Danke f\u00FCrs weiterlinken :)",
  "id" : 1541961720,
  "in_reply_to_status_id" : 1541781927,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1541992554",
  "text" : "Neuer W&W-Post: \u201CL\u00E4cheln!\u201D, sonst gibt es die Scheidung. Was Fotos nicht alles \u00FCber uns Aussagen. http:\/\/tr.im\/j2N7",
  "id" : 1541992554,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Fiene",
      "screen_name" : "fiene",
      "indices" : [ 0, 6 ],
      "id_str" : "1303281",
      "id" : 1303281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541973454",
  "geo" : { },
  "id_str" : "1541996648",
  "in_reply_to_user_id" : 1303281,
  "text" : "@fiene Das passt doch perfekt zu iTunes was in etwa genauso schnell ist...",
  "id" : 1541996648,
  "in_reply_to_status_id" : 1541973454,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "fiene",
  "in_reply_to_user_id_str" : "1303281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensur",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541993010",
  "geo" : { },
  "id_str" : "1542004922",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ich w\u00FCrde sagen erstmal sperren wir alle Kritik an der Regierung #zensur",
  "id" : 1542004922,
  "in_reply_to_status_id" : 1541993010,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1542017772",
  "text" : "Awesome creation timeline: http:\/\/tr.im\/j2NP",
  "id" : 1542017772,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1542256397",
  "text" : "Hallo Mr. Zahnarzt! Nichts gegen sie, ich vertraue nur Dentisten an sich nicht seitdem ich die Zahnmedizinstuden... - http:\/\/bkite.com\/06zbH",
  "id" : 1542256397,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horror",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1542303276",
  "geo" : { },
  "id_str" : "1542437022",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Oh ja, ich hatte mit beiden zusammen meine Physik-Kurse #horror",
  "id" : 1542437022,
  "in_reply_to_status_id" : 1542303276,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1542465504",
  "geo" : { },
  "id_str" : "1542598199",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina richtig. Man kann nur hoffen das alle ganz unf\u00E4higen noch vor Ende ausgesiebt werden ;)",
  "id" : 1542598199,
  "in_reply_to_status_id" : 1542465504,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1542633377",
  "geo" : { },
  "id_str" : "1542706794",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Deshalb versuche ich gesund zu bleiben ;)",
  "id" : 1542706794,
  "in_reply_to_status_id" : 1542633377,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1542723522",
  "text" : "Achja: K\u00FCrzester Zahnarztbesuch ever: 30 Min: Rein, Zahnstein entfernen, raus",
  "id" : 1542723522,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1544653876",
  "text" : "Termine ohne Eintrag im iPhone und ohne Erinnerungspiep vergesse ich ganz galant. Mist!",
  "id" : 1544653876,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1544696593",
  "geo" : { },
  "id_str" : "1544742040",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Doch das w\u00FCrde gehen, wenn man Konsequent alles eintr\u00E4gt. Und kommende Termine auf dem Homescreen stehen w\u00FCrden ;)",
  "id" : 1544742040,
  "in_reply_to_status_id" : 1544696593,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1544688240",
  "geo" : { },
  "id_str" : "1544748245",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Die Frage ist: Wieso haben wir noch keins, wo doch Kontakte & Kalender schon gepusht werden...",
  "id" : 1544748245,
  "in_reply_to_status_id" : 1544688240,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wechselnwill",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1544837450",
  "text" : "Serendipity ich verabscheue dich. Gibt es eine L\u00F6sung um den ganzen S9Y-Quatsch in Wordpress zu importieren? #wechselnwill",
  "id" : 1544837450,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1544820369",
  "geo" : { },
  "id_str" : "1544849035",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Stimmt, Kontakte hat Probleme mit den Kontaktfotos.Aber deshalb Apple f\u00FCr das auch nicht ideale mobile-me Geld in den Rachen werfen?",
  "id" : 1544849035,
  "in_reply_to_status_id" : 1544820369,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1544885638",
  "text" : "Nachdem meine Freundin umger\u00E4umt hat steht ihr Drucker so geschickt das er alle bedruckten Zettel auf den Boden wirft....",
  "id" : 1544885638,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1544917360",
  "text" : "@houellebeck Das Internet ist seit heute zum Tode verurteilt, aber sonst?",
  "id" : 1544917360,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1544909090",
  "geo" : { },
  "id_str" : "1544920765",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Dass ich nun auf dem Boden rumkriechen kann um meine Paper einzusammeln? Grandios!",
  "id" : 1544920765,
  "in_reply_to_status_id" : 1544909090,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1544944319",
  "text" : "@houellebeck Der bin ich zum Gl\u00FCck entgangen, gab doch sogar heute noch einen ganz guten Kommentar auf irgendeiner Newsseite dazu.",
  "id" : 1544944319,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545004762",
  "geo" : { },
  "id_str" : "1545022871",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ich glaube Google wird da bald irgendwas bringen. Mobileme find ich bl\u00F6d weil man gezwungen ist deren Adresse zu nutzen.",
  "id" : 1545022871,
  "in_reply_to_status_id" : 1545004762,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545012697",
  "geo" : { },
  "id_str" : "1545027542",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Super, aber Paper am Monitor lesen ist doof, mag analoges markieren und anmerkungen auf den Rand kritzeln noch zu gerne.",
  "id" : 1545027542,
  "in_reply_to_status_id" : 1545012697,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545086650",
  "text" : "Wenn wir schon Zensur haben, k\u00F6nnten wir dann bitte Mario Barth als N\u00E4chstes verbieten?",
  "id" : 1545086650,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Thomalla",
      "screen_name" : "digicamclub",
      "indices" : [ 12, 24 ],
      "id_str" : "126312409",
      "id" : 126312409
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 30, 36 ],
      "id_str" : "19397785",
      "id" : 19397785
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 80, 91 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545092130",
  "text" : "RT EPIC WIN @digicamclub: The @Oprah fail whale - http:\/\/twitpic.com\/3gexl (via @TechCrunch)",
  "id" : 1545092130,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "frank l.",
      "screen_name" : "frank93",
      "indices" : [ 0, 8 ],
      "id_str" : "11946872",
      "id" : 11946872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545167398",
  "geo" : { },
  "id_str" : "1545214770",
  "in_reply_to_user_id" : 11946872,
  "text" : "@frank93 Jaja, als K\u00FCnstler hat man es schon nicht leicht.",
  "id" : 1545214770,
  "in_reply_to_status_id" : 1545167398,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "frank93",
  "in_reply_to_user_id_str" : "11946872",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545248806",
  "text" : "PR-Menschen die einem nur followen um ihre Werbung an den Mann zu bringen gleich mitwegzensieren.",
  "id" : 1545248806,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545273579",
  "geo" : { },
  "id_str" : "1545322410",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Stimmt, direkt ma die Seiten melden.",
  "id" : 1545322410,
  "in_reply_to_status_id" : 1545273579,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545348497",
  "geo" : { },
  "id_str" : "1545367011",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, aber in PDFs Anmerkungen schreiben find ich doof. Geht das mit Vorschau \u00FCberhaupt? ;)",
  "id" : 1545367011,
  "in_reply_to_status_id" : 1545348497,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545520817",
  "geo" : { },
  "id_str" : "1545549132",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wieso nicht?",
  "id" : 1545549132,
  "in_reply_to_status_id" : 1545520817,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545652351",
  "text" : "@houellebeck ist doch eh alles das Gleiche!",
  "id" : 1545652351,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545710421",
  "text" : "@houellebeck f\u00FCr die Kinder? Empfehle Religulous zu schauen ;)",
  "id" : 1545710421,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545871655",
  "text" : "@houellebeck gut gerettet :)",
  "id" : 1545871655,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545848896",
  "geo" : { },
  "id_str" : "1545874257",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Aber wieso nicht?",
  "id" : 1545874257,
  "in_reply_to_status_id" : 1545848896,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1545885780",
  "text" : "Wer hat da denn einen dicken B\u00E4ren als Spielkameraden?! http:\/\/twitpic.com\/3haen",
  "id" : 1545885780,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1545930522",
  "geo" : { },
  "id_str" : "1545988786",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Anmerkungen, Notizen, sowas?",
  "id" : 1545988786,
  "in_reply_to_status_id" : 1545930522,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540431640",
  "text" : "Aus der Reihe \u201CMenschen die ich f\u00FCr dumm halte\u201D: Studentinnen die im StudiVZ ganz stolz damit prahlen dass sie nicht lesen. #fail",
  "id" : 1540431640,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Maier",
      "screen_name" : "weitergen",
      "indices" : [ 61, 71 ],
      "id_str" : "14717573",
      "id" : 14717573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "bologna",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 106, 119 ]
    }, {
      "text" : "studium",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540455844",
  "text" : "Neuer W&W-Post: Bologna vs. Bolognese Teil 2 - Interview mit @weitergen http:\/\/is.gd\/sU6W #wundw #bologna #wissenschaft #studium",
  "id" : 1540455844,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540646878",
  "text" : "@houellebeck Recht hast du, Zeit wird\u2019s! :)",
  "id" : 1540646878,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540704177",
  "text" : "Warum OpenAccess geil ist: Ich muss schon wieder fragen, hat jemand Zugriff auf dieses Paper? http:\/\/is.gd\/sUy5 #PRLit",
  "id" : 1540704177,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540720801",
  "geo" : { },
  "id_str" : "1540730176",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX So richtig geil wird es aber erst wenn ich f\u00FCr einzelne Paper nicht mehr 15 $ zahlen soll sondern runterladen darf. ;)",
  "id" : 1540730176,
  "in_reply_to_status_id" : 1540720801,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540747228",
  "geo" : { },
  "id_str" : "1540754158",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Absolut, dar\u00FCber hab ich mich vor kurzem auch ausf\u00FChrlich ausgelassen: http:\/\/is.gd\/sUDG",
  "id" : 1540754158,
  "in_reply_to_status_id" : 1540747228,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540761305",
  "geo" : { },
  "id_str" : "1540766098",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Und ich kenne niemanden der froh dar\u00FCber ist. H\u00F6chstens Leute denen es egal ist oder die Glauben dass OpenAccess nicht machbar ist.",
  "id" : 1540766098,
  "in_reply_to_status_id" : 1540761305,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540780031",
  "geo" : { },
  "id_str" : "1540791239",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Da bin ich gespannt ob Tweetie dann in Kombination mit der Desktop-App TwitterFon & Eventbox abl\u00F6sen k\u00F6nnte. Bin sync-s\u00FCchtig!",
  "id" : 1540791239,
  "in_reply_to_status_id" : 1540780031,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540796722",
  "text" : "Ich hab so das Gef\u00FChl das Twitter gerade ein paar Tweets verschluckt. Kann das wer best\u00E4tigen?",
  "id" : 1540796722,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540802781",
  "geo" : { },
  "id_str" : "1540813712",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Schade, hab aber jemanden gefunden der schon einen Blogpost dr\u00FCber verfasst hat und angeschrieben. Ist nur nicht so twitterschnell",
  "id" : 1540813712,
  "in_reply_to_status_id" : 1540802781,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540811932",
  "geo" : { },
  "id_str" : "1540815884",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Ja, aber f\u00FCr einen Sync des gelesen-Status w\u00FCrde ich Twitter aus Eventbox rauswerfen.",
  "id" : 1540815884,
  "in_reply_to_status_id" : 1540811932,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540803693",
  "geo" : { },
  "id_str" : "1540816991",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Davon hab ich noch nichts geh\u00F6rt. Warten wir es mal ab. :)",
  "id" : 1540816991,
  "in_reply_to_status_id" : 1540803693,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540819913",
  "geo" : { },
  "id_str" : "1540832669",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Nicht zum iPhone und das ist genau das was ich brauche\/will. Hab nur einen Mac, von daher ist zwischen Macs syncen unn\u00F6tig. :)",
  "id" : 1540832669,
  "in_reply_to_status_id" : 1540819913,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540822579",
  "geo" : { },
  "id_str" : "1540834080",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Ah cool, da bleib ich mal gespannt. F\u00E4nde ich sehr praktisch :)",
  "id" : 1540834080,
  "in_reply_to_status_id" : 1540822579,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540864335",
  "geo" : { },
  "id_str" : "1540871798",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Sonst bin ich auch Fan von Eventbox, aber es nervt immer auf dem iPhone schauen zu m\u00FCssen was ich schon am Mac gelesen habe.",
  "id" : 1540871798,
  "in_reply_to_status_id" : 1540864335,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540864335",
  "geo" : { },
  "id_str" : "1540873420",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Und nat\u00FCrlich auch vice versa. Da fehlt noch eine ordentliche L\u00F6sung f\u00FCr. F\u00FCr RSS geht es ja via GoogleReader :)",
  "id" : 1540873420,
  "in_reply_to_status_id" : 1540864335,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540869816",
  "geo" : { },
  "id_str" : "1540877304",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Wie sieht es eigentlich mit den Piraten in NRW aus? :)",
  "id" : 1540877304,
  "in_reply_to_status_id" : 1540869816,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "science",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540942718",
  "text" : "Neu bei W&W: Bio-Rapper \u00FCber Membranen http:\/\/is.gd\/sUXz #wundw #science #wissenschaft",
  "id" : 1540942718,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540890293",
  "geo" : { },
  "id_str" : "1540984540",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Dem Rest der Welt geht es da wenig mit den NRW-Piraten.",
  "id" : 1540984540,
  "in_reply_to_status_id" : 1540890293,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1540990357",
  "text" : "Hat heute morgen etwa niemand Lust \u00FCber den Bologna-Prozess zu diskutieren?",
  "id" : 1540990357,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1540989865",
  "geo" : { },
  "id_str" : "1540996834",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Machen recht wenig Werbung und sind sonst wenig Pr\u00E4sent. Ich wei\u00DF mehr dar\u00FCber was bei euch in Hessen los ist als bei mir in NRW.",
  "id" : 1540996834,
  "in_reply_to_status_id" : 1540989865,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541008600",
  "geo" : { },
  "id_str" : "1541024322",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten In den Naturwissenschaften stimmt die Aussage des Artikels leider nicht f\u00FCr die Wirtschaft.",
  "id" : 1541024322,
  "in_reply_to_status_id" : 1541008600,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541002762",
  "geo" : { },
  "id_str" : "1541026662",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Das glaube ich gerne. Aber gerade da w\u00E4re es doch gut Mitgliederwerbung zu machen um Arbeit dann mehr verteilen zu k\u00F6nnen.",
  "id" : 1541026662,
  "in_reply_to_status_id" : 1541002762,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1541032193",
  "geo" : { },
  "id_str" : "1541051688",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Das sollte ja auch gar keine Forderung sein. Nur ein kleiner Vorschlag was man noch verbessern k\u00F6nnte. :)",
  "id" : 1541051688,
  "in_reply_to_status_id" : 1541032193,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532012946",
  "geo" : { },
  "id_str" : "1532297337",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ja das kann ich verstehen. Dann halt auf ein neues mit der Terminfindung.",
  "id" : 1532297337,
  "in_reply_to_status_id" : 1532012946,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532329979",
  "text" : "Manche Menschen haben echt Stimmen, die so grausig sind das sie das geschriebene Wort deutlich bevorzugen sollten.",
  "id" : 1532329979,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "muenster",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532488973",
  "text" : "Kommt nun eigentlich irgendwer heute Abend zur #pl0gbar heute Abend in #muenster ? Bei mixxt sieht es ja noch sehr leer aus.",
  "id" : 1532488973,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532507555",
  "geo" : { },
  "id_str" : "1532525374",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt L\u00E4ngere Texte im Feed? :)",
  "id" : 1532525374,
  "in_reply_to_status_id" : 1532507555,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    }, {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 6, 14 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532491635",
  "geo" : { },
  "id_str" : "1532527251",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu @stelten Na da bin ich dann mal gespannt wer es schafft.",
  "id" : 1532527251,
  "in_reply_to_status_id" : 1532491635,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532530031",
  "text" : "Neuer W&W-Post: Bio-Rad legt noch einen drauf. http:\/\/is.gd\/sILO",
  "id" : 1532530031,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Schwehn",
      "screen_name" : "jschwehn",
      "indices" : [ 0, 9 ],
      "id_str" : "777527",
      "id" : 777527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532536957",
  "geo" : { },
  "id_str" : "1532551428",
  "in_reply_to_user_id" : 777527,
  "text" : "@jschwehn Okay, sind wir also 2 Leute :D",
  "id" : 1532551428,
  "in_reply_to_status_id" : 1532536957,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "jschwehn",
  "in_reply_to_user_id_str" : "777527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532547180",
  "geo" : { },
  "id_str" : "1532556547",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Dieses \u201Cweitere Artikel\u201D-K\u00E4stchen?",
  "id" : 1532556547,
  "in_reply_to_status_id" : 1532547180,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532604761",
  "geo" : { },
  "id_str" : "1532670544",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Ja sieht schick aus. Was cool w\u00E4re wenn bei den Social-Dings noch Twitter & Digg dabei w\u00E4ren, so in 10 Monaten vielleicht? ;)",
  "id" : 1532670544,
  "in_reply_to_status_id" : 1532604761,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532764943",
  "text" : "Gibt es eigentlich ein cooles Plugin f\u00FCr Wordpress um eine reply-Funktion f\u00FCr Kommentare zu bekommen?",
  "id" : 1532764943,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532769806",
  "text" : "Ganz alternativ ;) \u266B http:\/\/blip.fm\/~4ev5c",
  "id" : 1532769806,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532812316",
  "text" : "\u266B http:\/\/blip.fm\/~4evgh",
  "id" : 1532812316,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1532861579",
  "text" : "Frauen die im Umr\u00E4um-Wahn die Wohnung verw\u00FCsten sind grausig.",
  "id" : 1532861579,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532877968",
  "geo" : { },
  "id_str" : "1532928903",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich kenne wenige Kerle die alle paar Wochen das verlangen haben ihre Wohnung umzugestalten.",
  "id" : 1532928903,
  "in_reply_to_status_id" : 1532877968,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1532990398",
  "geo" : { },
  "id_str" : "1533005418",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod In geringerem Ausma\u00DF w\u00FCrde ich sagen.",
  "id" : 1533005418,
  "in_reply_to_status_id" : 1532990398,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1533086766",
  "geo" : { },
  "id_str" : "1533102853",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Nun doch die kompletten Feeds? Ich k\u00F6nnt euch knutschen wenn das stimmt :)",
  "id" : 1533102853,
  "in_reply_to_status_id" : 1533086766,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1533152424",
  "geo" : { },
  "id_str" : "1533157739",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Ja, aber da war ja noch im Gespr\u00E4ch die Feeds nur zu verl\u00E4ngern aber immer noch nicht auf Komplettfeeds. Super Schritt!",
  "id" : 1533157739,
  "in_reply_to_status_id" : 1533152424,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1533376235",
  "text" : "Battle Of The Beanfield. \u266B http:\/\/blip.fm\/~4ezpq",
  "id" : 1533376235,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1533181973",
  "geo" : { },
  "id_str" : "1533427601",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Jeder der 3000 Feedleser d\u00FCrfte daf\u00FCr dankbar sein. :)",
  "id" : 1533427601,
  "in_reply_to_status_id" : 1533181973,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1533810948",
  "text" : "Ich werd es heute nun auch nicht zur #pl0gbar schaffen. Das n\u00E4chste mal dann wieder. Oder zum n\u00E4chsten Tweetup. Je nachdem was fr\u00FCher kommt.",
  "id" : 1533810948,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1534385540",
  "geo" : { },
  "id_str" : "1534733129",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero niemand da au\u00DFer dir. Kannste dir also sparen.",
  "id" : 1534733129,
  "in_reply_to_status_id" : 1534385540,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1534821707",
  "geo" : { },
  "id_str" : "1534859197",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Mein letzter Stand war: Du & Ich. Nur ohne ich. Und laut mixxt kam niemand au\u00DFer mir.",
  "id" : 1534859197,
  "in_reply_to_status_id" : 1534821707,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1534960926",
  "geo" : { },
  "id_str" : "1534976864",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero W\u00E4re vielleicht cool wenn man sich etwas mehr drauf verlassen k\u00F6nnte. H\u00E4tte ich das gewusst h\u00E4tte ich nicht abgesagt. :(",
  "id" : 1534976864,
  "in_reply_to_status_id" : 1534960926,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1536573033",
  "text" : "Hunger!",
  "id" : 1536573033,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pritlove",
      "screen_name" : "timpritlove",
      "indices" : [ 0, 12 ],
      "id_str" : "11268812",
      "id" : 11268812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1536574922",
  "geo" : { },
  "id_str" : "1536601317",
  "in_reply_to_user_id" : 11268812,
  "text" : "@timpritlove das ist vor Allem nicht schlimm!",
  "id" : 1536601317,
  "in_reply_to_status_id" : 1536574922,
  "created_at" : "2009-04-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "timpritlove",
  "in_reply_to_user_id_str" : "11268812",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Motivation",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1528863342",
  "text" : "K\u00F6nnte euch momentan mit W&W-Poste vollspammen. Man was ist #Motivation cool.",
  "id" : 1528863342,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1523388143",
  "text" : "Jetzt wird es spannend ob ich gleich Statistik h\u00F6ren darf.",
  "id" : 1523388143,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MS",
      "indices" : [ 55, 58 ]
    }, {
      "text" : "Tweetup",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1523887961",
  "text" : "Und nochmal, Heute! RT @lorXsion: Nochmal f\u00FCr alle aus #MS. Heute ist #Tweetup im Pierhouse. Hier das Twtvite. http:\/\/tr.im\/iOt0 bitte RT!",
  "id" : 1523887961,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1523816652",
  "geo" : { },
  "id_str" : "1523891566",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Ich schaff es zur #pl0gbar. Wie siegt es mit dem Tweetup heute aus?",
  "id" : 1523891566,
  "in_reply_to_status_id" : 1523816652,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1523924237",
  "geo" : { },
  "id_str" : "1523963079",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih cool. Noch ein bioinformatiker. Dann bin ich nicht so einsam ;)",
  "id" : 1523963079,
  "in_reply_to_status_id" : 1523924237,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1523936405",
  "geo" : { },
  "id_str" : "1523964327",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz und pl0gbar? ;)",
  "id" : 1523964327,
  "in_reply_to_status_id" : 1523936405,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524224160",
  "text" : "Gebt mal einen Tipp f\u00FCr ein WP-Plugin was das Blog auf iPhone und Konsorten freundlich darstellt.",
  "id" : 1524224160,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524245405",
  "text" : "RT @Fischblog: Weitersagen: Blog-Karneval zum Welt-Malaria-Tag am 25. April. http:\/\/is.gd\/swXu",
  "id" : 1524245405,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1524227226",
  "geo" : { },
  "id_str" : "1524245983",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Super, vielen Dank f\u00FCr den Link, genau was ich gesucht habe :)",
  "id" : 1524245983,
  "in_reply_to_status_id" : 1524227226,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1524253945",
  "geo" : { },
  "id_str" : "1524260036",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Installation war ja super easy und jetzt l\u00E4uft es schon bei uns. Sehr coole Sache :)",
  "id" : 1524260036,
  "in_reply_to_status_id" : 1524253945,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1524253223",
  "geo" : { },
  "id_str" : "1524260276",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Danke trotzdem f\u00FCr den Tipp :)",
  "id" : 1524260276,
  "in_reply_to_status_id" : 1524253223,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524339667",
  "text" : "Kleiner Blogbeitrag bei W&W: Mehr zum Umzug: http:\/\/is.gd\/sx8R #wundw",
  "id" : 1524339667,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524363295",
  "text" : "Ich glaube eigentlich will ich ein Theme f\u00FCr W&W das Magazinm\u00E4ssig die Serien die wir einf\u00FChren anzeigen.",
  "id" : 1524363295,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till Achinger",
      "screen_name" : "pfandtasse",
      "indices" : [ 0, 11 ],
      "id_str" : "7147062",
      "id" : 7147062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1524429070",
  "geo" : { },
  "id_str" : "1524438716",
  "in_reply_to_user_id" : 7147062,
  "text" : "@pfandtasse \u00DCberschneidet sich ja bl\u00F6d mit dem Tweetup im pierhouse.",
  "id" : 1524438716,
  "in_reply_to_status_id" : 1524429070,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "pfandtasse",
  "in_reply_to_user_id_str" : "7147062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524441863",
  "text" : "Oldies but Goldies ;) \u266B http:\/\/blip.fm\/~4cuec",
  "id" : 1524441863,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524614810",
  "text" : "@JoergR Gl\u00FCck gehabt w\u00FCrde ich sagen :)",
  "id" : 1524614810,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "studium",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "bachelor",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "science",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524651085",
  "text" : "Neuer Blogpost bei W&W: Bologna vs. Bolognese - Teil 1 http:\/\/is.gd\/sxM2 #studium #bachelor #science #wissenschaft",
  "id" : 1524651085,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1524976714",
  "text" : "Gerade gedacht: Wow, schon 17 Uhr, das ging ja auf einmal fix! Dann gemerkt dass ich Windows gebootet hatte und es mir die Zeit zerst\u00F6rt.",
  "id" : 1524976714,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525205501",
  "geo" : { },
  "id_str" : "1525218764",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Das WLAN im Pierhouse ist aber seeeehr zickig",
  "id" : 1525218764,
  "in_reply_to_status_id" : 1525205501,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1525256259",
  "text" : "Das man auch immer was schreiben muss zu blips. \u266B http:\/\/blip.fm\/~4d0rl",
  "id" : 1525256259,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "science",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1525475623",
  "text" : "Neuer W&W-Post: Glow-In-The-Dark-Dog, der erste fluoreszierende Hund http:\/\/is.gd\/sz6v #PRLit #science #wissenschaft",
  "id" : 1525475623,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1525528484",
  "text" : "Und noch ein Blogpost: Statistiken - Noch mehr Hundecontent! http:\/\/is.gd\/szcq",
  "id" : 1525528484,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525516191",
  "geo" : { },
  "id_str" : "1525531339",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Und das sind auch leider fast noch alle Journals...",
  "id" : 1525531339,
  "in_reply_to_status_id" : 1525516191,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525605141",
  "geo" : { },
  "id_str" : "1525625707",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Ja, aber im Zweifel hilft auch eine Frage in Twitter nach dem Paper ;)",
  "id" : 1525625707,
  "in_reply_to_status_id" : 1525605141,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525644097",
  "geo" : { },
  "id_str" : "1525668495",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Weil er damit was gemacht hat?",
  "id" : 1525668495,
  "in_reply_to_status_id" : 1525644097,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525682468",
  "geo" : { },
  "id_str" : "1525689790",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Und dann hat er es ver\u00F6ffentlicht?",
  "id" : 1525689790,
  "in_reply_to_status_id" : 1525682468,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525703454",
  "geo" : { },
  "id_str" : "1525726527",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Jo, bei uns geht das auch nur alles mit Passwortschutz, dann scheint es aus unerfindlichen Gr\u00FCnden okay zu sein.",
  "id" : 1525726527,
  "in_reply_to_status_id" : 1525703454,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1525779018",
  "text" : "Chatte mit irgendeinem wildfremden Chinesen via http:\/\/omegle.com\/",
  "id" : 1525779018,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1525753229",
  "geo" : { },
  "id_str" : "1525788661",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Ja, das ist schon albern. \u00DCber diesen ganzen Copyright-Kram f\u00FCr Forschung und Bildung kann man nur mit dem Kopf sch\u00FCtteln",
  "id" : 1525788661,
  "in_reply_to_status_id" : 1525753229,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OlafBathke",
      "screen_name" : "OlafBathke",
      "indices" : [ 3, 14 ],
      "id_str" : "16809875",
      "id" : 16809875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1525995511",
  "text" : "RT @OlafBathke: Ich bitte um eine Weiterverbreitung: Der Jahreszeiten Verlag und die Vertr\u00E4ge f\u00FCr Fotografen: http:\/\/twurl.nl\/iwzqei",
  "id" : 1525995511,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1526205996",
  "geo" : { },
  "id_str" : "1526557770",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Ja, die Idee ist total witzig. Man lernt da mit etwas Gl\u00FCck wirklich interessante Menschen kennen.",
  "id" : 1526557770,
  "in_reply_to_status_id" : 1526205996,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1526656142",
  "text" : "Noch niemand da beim Tweetup?",
  "id" : 1526656142,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 14, 21 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1527054745",
  "geo" : { },
  "id_str" : "1527317779",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ne, @skl8em ist auch da.",
  "id" : 1527317779,
  "in_reply_to_status_id" : 1527054745,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 10, 22 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    }, {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 63, 70 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1527428730",
  "geo" : { },
  "id_str" : "1528495199",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion @danishkirel war auch da. War sehr nett. H\u00E4ttest mit @skl8em und mir \u00FCber Fotografie fachsimpeln k\u00F6nnen. :)",
  "id" : 1528495199,
  "in_reply_to_status_id" : 1527428730,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1528586226",
  "geo" : { },
  "id_str" : "1528609772",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Wieso? Werden die per Hand nach M\u00FCnster gerollt? ;)",
  "id" : 1528609772,
  "in_reply_to_status_id" : 1528586226,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1528614840",
  "geo" : { },
  "id_str" : "1528635801",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Och DPD, die sind wirklich ein seltsamer Verein, siehe auch hier bei mir im Blog: http:\/\/is.gd\/sDsi",
  "id" : 1528635801,
  "in_reply_to_status_id" : 1528614840,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1528666730",
  "geo" : { },
  "id_str" : "1528679307",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Morgen ja, aber was ist am 29. am Aasee? Auch wenn ich da potentiell ehr nicht kann wegen meiner Pfadfinder Gruppe.",
  "id" : 1528679307,
  "in_reply_to_status_id" : 1528666730,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1528678132",
  "geo" : { },
  "id_str" : "1528683953",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Die Diskussion dazu ist auch ganz spannend, in dem Fall wohl wirklich \u201Ckorrekte\u201D Lieferung.",
  "id" : 1528683953,
  "in_reply_to_status_id" : 1528678132,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1528696242",
  "geo" : { },
  "id_str" : "1528719460",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Gibt es dazu auch einen Link? Ist vermutlich haupts\u00E4chlich was f\u00FCr Business-Leute oder? Da ist mein Interesse nicht so gro\u00DF.",
  "id" : 1528719460,
  "in_reply_to_status_id" : 1528696242,
  "created_at" : "2009-04-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1519038721",
  "text" : "Wieso st\u00FCrzt Mail beim beenden eigentlich seit einiger Zeit ganz konsequent ab? Ein Mistst\u00FCck von Software.",
  "id" : 1519038721,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519085956",
  "geo" : { },
  "id_str" : "1519105602",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Doch iTunes geht immer noch problemlos zu. Nur das doofe Mail nicht. Und IMAP kann es auch nicht ordentlich...",
  "id" : 1519105602,
  "in_reply_to_status_id" : 1519085956,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1519178584",
  "text" : "Das RTL-Quiz ist vom Niveau her genau richtig f\u00FCr Leute die bei der Supernanny zu sehen sind vermute ich.",
  "id" : 1519178584,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519193662",
  "geo" : { },
  "id_str" : "1519221943",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger Da w\u00E4re ich mir nicht so sicher, vielleicht raten die Teilnehme auch einfach nur.",
  "id" : 1519221943,
  "in_reply_to_status_id" : 1519193662,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519229564",
  "geo" : { },
  "id_str" : "1519250843",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger Besser schlecht geraten als gar nicht teilgenommen was? ;)",
  "id" : 1519250843,
  "in_reply_to_status_id" : 1519229564,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519237921",
  "geo" : { },
  "id_str" : "1519260259",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Vor allem weil IMAP in Mail auf dem iPhone so tadellos funktioniert und dann das Mail unter dem normalen Mac OS ist M\u00FCll. Strange",
  "id" : 1519260259,
  "in_reply_to_status_id" : 1519237921,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MS",
      "indices" : [ 35, 38 ]
    }, {
      "text" : "Tweetup",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1519562802",
  "text" : "RT @lorXsion: Nochmal f\u00FCr alle aus #MS. Morgen ist #Tweetup im Pierhouse. Hier das Twtvite. http:\/\/tr.im\/iOt0 bitte RT!",
  "id" : 1519562802,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyAtheist",
      "screen_name" : "DailyAtheist",
      "indices" : [ 3, 16 ],
      "id_str" : "20831583",
      "id" : 20831583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1519671287",
  "text" : "RT @DailyAtheist: Gods don't kill people; people with gods kill people! -- Unknown",
  "id" : 1519671287,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519755458",
  "geo" : { },
  "id_str" : "1519803115",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry gibt es sicherlich auch irgendwo komplett aufgelistet. Wette auf atheistische Langzeitstudenten.",
  "id" : 1519803115,
  "in_reply_to_status_id" : 1519755458,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519792740",
  "geo" : { },
  "id_str" : "1519827697",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry in der Tat, finde die Berechnungen in den Kommentaren auch nett :)",
  "id" : 1519827697,
  "in_reply_to_status_id" : 1519792740,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1519823134",
  "geo" : { },
  "id_str" : "1519833560",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Weil mit dem Finger auf andere zu zeigen bequemer ist.",
  "id" : 1519833560,
  "in_reply_to_status_id" : 1519823134,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1519861140",
  "text" : "Nicht auf dem Foto: Der Pudding den er anstarrt.  http:\/\/twitpic.com\/3bn04",
  "id" : 1519861140,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1515616379",
  "text" : "Weissbier & Wissenschaft ist nun endlich umgezogen. Unser Blog kann man jetzt unter http:\/\/www.bierologie.org lesen :)",
  "id" : 1515616379,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1515657538",
  "geo" : { },
  "id_str" : "1515669517",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Danke. Ich bin mal so frei und gehe einfach davon aus, dass es noch zu dem letzten Tweet geh\u00F6ren sollte ;)",
  "id" : 1515669517,
  "in_reply_to_status_id" : 1515657538,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deef Pirmasens",
      "screen_name" : "Deef",
      "indices" : [ 0, 5 ],
      "id_str" : "2565121",
      "id" : 2565121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1515703071",
  "in_reply_to_user_id" : 2565121,
  "text" : "@Deef http:\/\/twitpic.com\/3au9d - Das ist ja affig!",
  "id" : 1515703071,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Deef",
  "in_reply_to_user_id_str" : "2565121",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516042582",
  "text" : "Genmais ist ein so dummer Begriff das man gleich alle Artikel die den Ausdruck ohne Anf\u00FChrungszeichen benutzen wegschmeissen kann.",
  "id" : 1516042582,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1516063509",
  "geo" : { },
  "id_str" : "1516074926",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Nat\u00FCrlich nicht, und Gentechnik ist sowieso b\u00F6se. Gut das normale Saatzucht so was ganz anderes ist.",
  "id" : 1516074926,
  "in_reply_to_status_id" : 1516063509,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1516094806",
  "geo" : { },
  "id_str" : "1516100880",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja, und strenggenommen ist es auch schon Gentechnik wenn man k\u00FCnstlich zur Zucht selektiert. Sollte man auch verbieten...",
  "id" : 1516100880,
  "in_reply_to_status_id" : 1516094806,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 99, 112 ]
    }, {
      "text" : "gentechnik",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516208800",
  "text" : "Neuer Post bei W&W: Wissenschaft & Medien I - F\u00FCr mehr genfreies Essen: http:\/\/is.gd\/slm8 #science #wissenschaft #gentechnik",
  "id" : 1516208800,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516280105",
  "text" : "Ich muss gerade nochmal die Twitter-Integration in unser WP-Blog testen: http:\/\/is.gd\/slm8",
  "id" : 1516280105,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516344096",
  "text" : "Was? Ich muss morgen schon wieder zu einer Vorlesung! So ein Mist aber auch! :)",
  "id" : 1516344096,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialfreak",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516355054",
  "text" : "Cool, Tweetback postet Tweets zu Blogposts unter die Beitr\u00E4ge und per BacktypeConnect l\u00E4sst sich noch mehr Zeug aggregieren. #socialfreak",
  "id" : 1516355054,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwischenrufer",
      "screen_name" : "Zwischenrufer",
      "indices" : [ 0, 14 ],
      "id_str" : "16046470",
      "id" : 16046470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1516447325",
  "geo" : { },
  "id_str" : "1516472212",
  "in_reply_to_user_id" : 16046470,
  "text" : "@Zwischenrufer Hatte PC nur in der Variante f\u00FCr Biologen. Und da war es genauso. Ich glaube das muss so :)",
  "id" : 1516472212,
  "in_reply_to_status_id" : 1516447325,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zwischenrufer",
  "in_reply_to_user_id_str" : "16046470",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1516600771",
  "text" : "Jetzt gerade mal noch ein kleines Favicon bei W&W eingebunden.",
  "id" : 1516600771,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "henrik greger",
      "screen_name" : "henrikgreger",
      "indices" : [ 0, 13 ],
      "id_str" : "10768042",
      "id" : 10768042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1516800576",
  "geo" : { },
  "id_str" : "1516811222",
  "in_reply_to_user_id" : 10768042,
  "text" : "@henrikgreger Du rauchst offensichtlich nicht. Sonst w\u00FCrdest du dich das wohl gar nicht erst fragen ;)",
  "id" : 1516811222,
  "in_reply_to_status_id" : 1516800576,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "henrikgreger",
  "in_reply_to_user_id_str" : "10768042",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "henrik greger",
      "screen_name" : "henrikgreger",
      "indices" : [ 0, 13 ],
      "id_str" : "10768042",
      "id" : 10768042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1516815432",
  "geo" : { },
  "id_str" : "1516910433",
  "in_reply_to_user_id" : 10768042,
  "text" : "@henrikgreger Daf\u00FCr kriegt man aber einen netten Eisbecher, d\u00FCrfte bei dem Wetter doch eine gute Investition sein :)",
  "id" : 1516910433,
  "in_reply_to_status_id" : 1516815432,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "henrikgreger",
  "in_reply_to_user_id_str" : "10768042",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "PRLit",
      "indices" : [ 112, 118 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 119, 132 ]
    }, {
      "text" : "wundw",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1517239063",
  "text" : "Neuer W&W-Post (heute hab ich es so richtig vor!): Sollte man Hummer lebendig essen? http:\/\/is.gd\/snbH #science #PRLit #wissenschaft #wundw",
  "id" : 1517239063,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517285367",
  "geo" : { },
  "id_str" : "1517548485",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Jo, aber das \u00E4ndert ja nichts daran dass es verdammt fies ist sie lebendig ins kochende Wasser zu werfen.",
  "id" : 1517548485,
  "in_reply_to_status_id" : 1517285367,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517602470",
  "geo" : { },
  "id_str" : "1517626301",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Gibt es da Quellen?",
  "id" : 1517626301,
  "in_reply_to_status_id" : 1517602470,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    }, {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 12, 20 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517650480",
  "geo" : { },
  "id_str" : "1517671227",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur @p_j_fry die Wikipedia erz\u00E4hlt auch noch von Einlegen in Salzl\u00F6sung, zitiert eine \u201Cnorwegische Studie\u201D aber ohne Link oder Name.",
  "id" : 1517671227,
  "in_reply_to_status_id" : 1517650480,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    }, {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 12, 20 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517650480",
  "geo" : { },
  "id_str" : "1517688753",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur @p_j_fry hier auch noch anekdotische \u201CBeweise\u201D ;) http:\/\/is.gd\/snVA",
  "id" : 1517688753,
  "in_reply_to_status_id" : 1517650480,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517602470",
  "geo" : { },
  "id_str" : "1517696196",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Im Endeffekt ist das f\u00FCr mich auch nicht so wichtig. Ich mag Meerestiere allgemein gar nicht ;)",
  "id" : 1517696196,
  "in_reply_to_status_id" : 1517602470,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1517775180",
  "geo" : { },
  "id_str" : "1517919736",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Ja sollte jeder der das nicht kann. Heisst ja nur nicht dass man nicht dr\u00FCber diskutieren sollte was die beste Methode ist.",
  "id" : 1517919736,
  "in_reply_to_status_id" : 1517775180,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1518708812",
  "text" : "Endlich mit Herrn Philipp zwecks W&W-Planung getroffen.",
  "id" : 1518708812,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1508419103",
  "text" : "So, die Reste vom Osterfeuer sind abgebaut. Jetzt erstmal Duschen.",
  "id" : 1508419103,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1508523621",
  "text" : "Irgendwer hier anwesend der Zugriff auf \u201CApplied Animal Behaviour Sciences\u201D hat? #PRLit",
  "id" : 1508523621,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1508764492",
  "geo" : { },
  "id_str" : "1509800595",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 ich such dir gleich den DOI raus :)",
  "id" : 1509800595,
  "in_reply_to_status_id" : 1508764492,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 6, 15 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1511249902",
  "text" : "Danke @Argent23 f\u00FCr die freundliche Hilfe beim Stoff beschaffen :) #PRLit",
  "id" : 1511249902,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nugent",
      "screen_name" : "micknugent",
      "indices" : [ 9, 20 ],
      "id_str" : "27151738",
      "id" : 27151738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1511547878",
  "text" : "LOOOL RT @micknugent: Careful now. Satan can enter your house through Smurfs, My Little Pony, CareBears and Ouija Boards http:\/\/is.gd\/sdNS",
  "id" : 1511547878,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1511566093",
  "text" : "Dabei ist  heute doch gar nicht Freitag, Betrug! Grossartige Coverversionen von den M\u00E4dels. \u266B http:\/\/blip.fm\/~49lfs",
  "id" : 1511566093,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1511579520",
  "text" : "Re-Blipping ist auch eine feine Erfindung. \u266B http:\/\/blip.fm\/~49lla",
  "id" : 1511579520,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1501961411",
  "text" : "Guten Morgen zusammen.",
  "id" : 1501961411,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1501952107",
  "geo" : { },
  "id_str" : "1501962226",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Hast du denn f\u00FCr den Darwin-Tag deine Unterschrift hergegeben? :)",
  "id" : 1501962226,
  "in_reply_to_status_id" : 1501952107,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1502028957",
  "text" : "Grad cooles Paper gefunden, wollt es runterladen, Uni hat das Abo der Zeitschrift nicht. F\u00FCr nur 45 \u20AC darf ich es trotzdem lesen.... #PRLit",
  "id" : 1502028957,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1502033331",
  "geo" : { },
  "id_str" : "1502044214",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja, ich habs ja auch drauf angelegt. :)",
  "id" : 1502044214,
  "in_reply_to_status_id" : 1502033331,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1502047707",
  "text" : "TimeMachine l\u00E4uft nun auch, ein gutes Gef\u00FChl das System komplett gesichert zu haben.",
  "id" : 1502047707,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1502066740",
  "geo" : { },
  "id_str" : "1502085754",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Gut gut, aber ich glaube trotzdem nicht dass was draus wird ;)",
  "id" : 1502085754,
  "in_reply_to_status_id" : 1502066740,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1502090173",
  "text" : "Sehr cool, die neue FW-Platte ist fast doppelt so fix wie die alte USB-Platte. So ist arbeiten doch gleich viel angenehmer.",
  "id" : 1502090173,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1502101273",
  "geo" : { },
  "id_str" : "1502111610",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Absolut, der Aufpreis hat sich auf jedenfall gelohnt.",
  "id" : 1502111610,
  "in_reply_to_status_id" : 1502101273,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wixa",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "mixa",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1502633145",
  "geo" : { },
  "id_str" : "1502723874",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Ein radikaler Vollidiot im Bischofsgewand, kurz auch #wixa dieser #mixa",
  "id" : 1502723874,
  "in_reply_to_status_id" : 1502633145,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1503405158",
  "text" : "Grills sind an. G\u00E4ste k\u00F6nnen kommen.",
  "id" : 1503405158,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1503458225",
  "geo" : { },
  "id_str" : "1503476170",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten ja hier. #pl0gbar",
  "id" : 1503476170,
  "in_reply_to_status_id" : 1503458225,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1503730843",
  "geo" : { },
  "id_str" : "1505478195",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ne, ich bin ein ganz normaler Mensch der seinen Verstand nicht Am Portal der Kirche abgibt.",
  "id" : 1505478195,
  "in_reply_to_status_id" : 1503730843,
  "created_at" : "2009-04-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Baron",
      "screen_name" : "Philbertus",
      "indices" : [ 0, 11 ],
      "id_str" : "22300791",
      "id" : 22300791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496703452",
  "geo" : { },
  "id_str" : "1496928130",
  "in_reply_to_user_id" : 22300791,
  "text" : "@Philbertus ein bisschen ;)",
  "id" : 1496928130,
  "in_reply_to_status_id" : 1496703452,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Philbertus",
  "in_reply_to_user_id_str" : "22300791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496934959",
  "text" : "Zelt steht!  http:\/\/twitpic.com\/35hok",
  "id" : 1496934959,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1497036138",
  "text" : "Men at Work  http:\/\/twitpic.com\/35ira",
  "id" : 1497036138,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1497712197",
  "text" : "Mal die neue Festplatte bespielen und TimeMachine einrichten.",
  "id" : 1497712197,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1497763367",
  "geo" : { },
  "id_str" : "1497804637",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Erstmal die Festplatte die ich daf\u00FCr vorgesehen habe freimachen :)",
  "id" : 1497804637,
  "in_reply_to_status_id" : 1497763367,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyAtheist",
      "screen_name" : "DailyAtheist",
      "indices" : [ 4, 17 ],
      "id_str" : "20831583",
      "id" : 20831583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1497879608",
  "text" : "Dem @DailyAtheist zu folgen ist prima. Jede Menge nette Spr\u00FCche \u00FCber glauben und nichtglauben.",
  "id" : 1497879608,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1498035811",
  "text" : "http:\/\/twitpic.com\/35ufx - Laangweilig!",
  "id" : 1498035811,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Thomalla",
      "screen_name" : "digicamclub",
      "indices" : [ 0, 12 ],
      "id_str" : "126312409",
      "id" : 126312409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1498083332",
  "geo" : { },
  "id_str" : "1498097432",
  "in_reply_to_user_id" : 15352789,
  "text" : "@digicamclub Die Lottozahlen f\u00FCr n\u00E4chsten Samstag?",
  "id" : 1498097432,
  "in_reply_to_status_id" : 1498083332,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcthomalla",
  "in_reply_to_user_id_str" : "15352789",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1498794202",
  "geo" : { },
  "id_str" : "1498885848",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU aber wieso das denn nicht?",
  "id" : 1498885848,
  "in_reply_to_status_id" : 1498794202,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 3, 15 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496011988",
  "text" : "RT @herr_schrat: f\u00E4hrt heute abend irgendwer von Frankfurt nach M\u00FCnster?",
  "id" : 1496011988,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rune Simonsen",
      "screen_name" : "rusimons",
      "indices" : [ 3, 12 ],
      "id_str" : "15071986",
      "id" : 15071986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496058403",
  "text" : "RT @rusimons: I'm not a-twitter by Facebook in my space http:\/\/ow.ly\/2AMg An article about keeping focus on what's important. Very good.",
  "id" : 1496058403,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496182003",
  "text" : "Laut DHL sollte meine neue Festplatte heute noch geliefert werden. Ich bin gespannt.",
  "id" : 1496182003,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496221864",
  "text" : "Tippfehler f\u00FChrt zu neuer Gesch\u00E4ftsidee: GoogleAnalyrics",
  "id" : 1496221864,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "indices" : [ 0, 12 ],
      "id_str" : "16945253",
      "id" : 16945253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496226373",
  "geo" : { },
  "id_str" : "1496229350",
  "in_reply_to_user_id" : 16945253,
  "text" : "@HerrKaliban Schonmal M\u00E4nner bei H&M beobachtet die als Anhang mitgeschleift wurden?",
  "id" : 1496229350,
  "in_reply_to_status_id" : 1496226373,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrKaliban",
  "in_reply_to_user_id_str" : "16945253",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496229289",
  "geo" : { },
  "id_str" : "1496231263",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod F\u00FCr mich auch nicht. Der Tippfehler f\u00FCr auch ins digitale Nirvana",
  "id" : 1496231263,
  "in_reply_to_status_id" : 1496229289,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496272272",
  "geo" : { },
  "id_str" : "1496277442",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Bleibt abzuwarten was Google in seinen Labs so lustiges entwickelt",
  "id" : 1496277442,
  "in_reply_to_status_id" : 1496272272,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496503219",
  "text" : "Das war gerade eine Super Runde Left4Dead: 7000 zu 360 gewonnen.",
  "id" : 1496503219,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496519025",
  "geo" : { },
  "id_str" : "1496532676",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Das ist etwas was wir unbedingt auf das amerikanische System umstellen sollten.",
  "id" : 1496532676,
  "in_reply_to_status_id" : 1496519025,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496543724",
  "text" : "Mit ColorCanvas kann man auf dem iPhone ColorKeys erstellen. Coole Sache f\u00FCr zwischendurch.",
  "id" : 1496543724,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1496558363",
  "text" : "Kleines Testbild aus ColorCanvas:  http:\/\/twitpic.com\/35dsw",
  "id" : 1496558363,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1496584538",
  "geo" : { },
  "id_str" : "1496599591",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod jo, aber Rot eignet sich so gut f\u00FCr Colorkeys. Ganz abgesehen davon dass sie da waren.",
  "id" : 1496599591,
  "in_reply_to_status_id" : 1496584538,
  "created_at" : "2009-04-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1489181778",
  "geo" : { },
  "id_str" : "1489188735",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Solange du nicht selbst p\u00FCnktlich sein muss? ;)",
  "id" : 1489188735,
  "in_reply_to_status_id" : 1489181778,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489239647",
  "text" : "Ich steh ja nicht so auf Feiertage.",
  "id" : 1489239647,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489274923",
  "text" : "Chillig \u266B http:\/\/blip.fm\/~42ycm",
  "id" : 1489274923,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489353382",
  "text" : "@Taxipilot Apropos Desperado ;) \u266B http:\/\/blip.fm\/~42z78",
  "id" : 1489353382,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489424425",
  "text" : "@Taxipilot Ich kann auch kein spanisch, das h\u00E4lt mich allerdings auch nicht auf :)",
  "id" : 1489424425,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 0, 4 ],
      "id_str" : "18424055",
      "id" : 18424055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1489367752",
  "geo" : { },
  "id_str" : "1489427526",
  "in_reply_to_user_id" : 18424055,
  "text" : "@p9y Du hast doch hoffentlich Mario Kart gleich mitersteigert oder? Das spiele ich heute noch regelm\u00E4ssig mit Freunden :)",
  "id" : 1489427526,
  "in_reply_to_status_id" : 1489367752,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "p9y",
  "in_reply_to_user_id_str" : "18424055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 0, 4 ],
      "id_str" : "18424055",
      "id" : 18424055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1489452027",
  "geo" : { },
  "id_str" : "1489554578",
  "in_reply_to_user_id" : 18424055,
  "text" : "@p9y Oh ja. Street Fighter war auch cool. Und Secret Of Mana und Konsorten!",
  "id" : 1489554578,
  "in_reply_to_status_id" : 1489452027,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "p9y",
  "in_reply_to_user_id_str" : "18424055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489555379",
  "text" : "@Taxipilot Darf man nicht singen?",
  "id" : 1489555379,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489824126",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog ich denke wir werden da auch gerne noch etwas zu beitragen.",
  "id" : 1489824126,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 8, 17 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 18, 28 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Malaria",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1489881448",
  "text" : "@JoergR @Argent23 @Fischblog na da freu ich mich ja auf #Malaria :)",
  "id" : 1489881448,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1490321783",
  "text" : "Oh, gleich ist vorbei mit dem Strohwitwer-Dasein.",
  "id" : 1490321783,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1490407585",
  "text" : "Hund freut sich zu Tode \u00FCber Frauchen. Ich Wette er pinkelt gleich vor lauter Begeisterung.",
  "id" : 1490407585,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1491092978",
  "text" : "Neuer W&W-Post: Umzug - http:\/\/is.gd\/rMV4 Neuer privater Blogpost: Umzugsprobleme! http:\/\/is.gd\/rMVl Zusammenh\u00E4nge sind gar nicht zuf\u00E4llig.",
  "id" : 1491092978,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PZ Myers",
      "screen_name" : "pzmyers",
      "indices" : [ 129, 137 ],
      "id_str" : "8005492",
      "id" : 8005492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1491333109",
  "text" : "Hab ich es \u00FCberlesen oder hat wirklich noch niemand \u00FCber den Tod des D&D-Coautors Dave Arneson getwittert? http:\/\/is.gd\/rMzP via @pzmyers",
  "id" : 1491333109,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1491695616",
  "text" : "http:\/\/is.gd\/rNJN #fail",
  "id" : 1491695616,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1491688856",
  "geo" : { },
  "id_str" : "1491702242",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Tweets \u00FCber peer-review-Artikel? zeigen die nicht meist eh zu Blogposts die per @ResearchBlogging aggregiert werden? :)",
  "id" : 1491702242,
  "in_reply_to_status_id" : 1491688856,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1491723413",
  "geo" : { },
  "id_str" : "1491728884",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Bis ich das gebrauchen k\u00F6nnte hab ich das passende Tag schon wieder vergessen. :P",
  "id" : 1491728884,
  "in_reply_to_status_id" : 1491723413,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1491846456",
  "text" : "@JoergR Jo kann man, schade dass ich keinen Client kenne der sich verwendete Hashtags oder Tag-Favoriten speichert.",
  "id" : 1491846456,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1491882672",
  "geo" : { },
  "id_str" : "1491906491",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das nutzt mir ja nicht wirklich um Tags aktiv selbst zu nutzen.",
  "id" : 1491906491,
  "in_reply_to_status_id" : 1491882672,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1491913528",
  "text" : "@Taxipilot ich dachte die Polizei h\u00E4lt einen auf.",
  "id" : 1491913528,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killerspiele",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "karfreitag",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1492207934",
  "text" : "#killerspiele am #karfreitag Gehen sie direkt in die H\u00F6lle, gehen sie nicht \u00FCber Los, ziehen sie keine 2000 DM ein.",
  "id" : 1492207934,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "diazis123",
      "screen_name" : "tomaschek",
      "indices" : [ 0, 10 ],
      "id_str" : "2533280498",
      "id" : 2533280498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1492334190",
  "text" : "@tomaschek Ich w\u00FCrd sagen nein.",
  "id" : 1492334190,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP",
      "screen_name" : "taxipilot",
      "indices" : [ 0, 10 ],
      "id_str" : "517501013",
      "id" : 517501013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1492497220",
  "text" : "@Taxipilot Nun hab ichs :)",
  "id" : 1492497220,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1492932397",
  "text" : "B\u00E4h, morgen ist aufbauen f\u00FCr das Osterfeuer der Pfadfinder. Meine Motivation strebt gen 0.",
  "id" : 1492932397,
  "created_at" : "2009-04-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482981404",
  "text" : "Der dicke Hund liegt unter dem Schreibtisch mit seinem Kopf auf meinen F\u00FC\u00DFen. W\u00FCrde mich langsam gern bewegen k\u00F6nnen.",
  "id" : 1482981404,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1483639524",
  "text" : "Sau starker Song um entspannt Autozufahren. Der Mix aus Gitarren-Riff & Piano ist genial. \u266B http:\/\/blip.fm\/~418df",
  "id" : 1483639524,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1484691303",
  "text" : "@houellebeck das ist gut zu h\u00F6ren!",
  "id" : 1484691303,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1484876509",
  "text" : "\u00DCbrigens: Wir ziehen mit Weissbier und Wissenschaft bald um! :)",
  "id" : 1484876509,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1484893409",
  "text" : "Machen sie eine typische Hundepose:  http:\/\/twitpic.com\/320vj",
  "id" : 1484893409,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1484937076",
  "geo" : { },
  "id_str" : "1485281274",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Hosten selber :)",
  "id" : 1485281274,
  "in_reply_to_status_id" : 1484937076,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1485984409",
  "text" : "Meine alte 2-Tasten-Scrollrad-MS-Maus hat gerade nach Jahren ihren Dienst versagt :(",
  "id" : 1485984409,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rip",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "mouse",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486030898",
  "text" : "Es war dieses Ding, eine der ersten Generation. Hat 2 Laptops und ein paar Desktoprechner \u00FCberlegt. http:\/\/is.gd\/nJYm #rip #mouse",
  "id" : 1486030898,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486214151",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 http:\/\/twitpic.com\/32ebl - Sehr coole Idee, das Sch\u00E4tzchen ist ja auch schon etwas \u00E4lter. So eine hatte ich auch mal, war aber  ...",
  "id" : 1486214151,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486294610",
  "text" : "Awesome: Jason Statham in \u201CDiabetes\u201D - http:\/\/is.gd\/r3en",
  "id" : 1486294610,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "umzug",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486402948",
  "text" : "Man was ist Wordpress mittlerweile cool geworden. Idiotensicher zu installieren und der Export\/Import ist genauso super gel\u00F6st. #umzug",
  "id" : 1486402948,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486650526",
  "text" : "Abgefuckte Psychomusik die sich anh\u00F6rt als w\u00FCrde sie direkt aus den 70ern auf Drogen kommen. \u266B http:\/\/blip.fm\/~425z1",
  "id" : 1486650526,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1486656866",
  "geo" : { },
  "id_str" : "1486680854",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Und ich dachte Godzilla w\u00FCrde einfach nur widerspiegeln dass Japaner batshit crazy sind.",
  "id" : 1486680854,
  "in_reply_to_status_id" : 1486656866,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1486903767",
  "text" : "Also ich sag jetzt #gn8",
  "id" : 1486903767,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482049054",
  "text" : "Guten morgen zsammen!",
  "id" : 1482049054,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482120490",
  "text" : "Gerade aufgestanden und nun ist mir ob christlicher Propaganda schon wieder schlecht: http:\/\/is.gd\/ry2e",
  "id" : 1482120490,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1482136455",
  "geo" : { },
  "id_str" : "1482148618",
  "in_reply_to_user_id" : 5692812,
  "text" : "@Canikon_Mark Das Haufen-Prinzip? :)",
  "id" : 1482148618,
  "in_reply_to_status_id" : 1482136455,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "mqpics",
  "in_reply_to_user_id_str" : "5692812",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482184059",
  "text" : "Leute die ohne sichtbare Rufnummer anrufen haben bei mir verkackt. Die Chance f\u00FCr Telefonspam ist zu hoch",
  "id" : 1482184059,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482349496",
  "text" : "Doch, bin im gro\u00DFen & ganzen zufrieden mit Byline. Nur wieso muss das Icon so h\u00E4sslich sein? ;)",
  "id" : 1482349496,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tanzverbot",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482413438",
  "text" : "Ist es nicht sch\u00F6n dass man morgen nicht feiern darf? #tanzverbot",
  "id" : 1482413438,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weissbierundwissenschaft",
      "indices" : [ 91, 116 ]
    }, {
      "text" : "science",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482453097",
  "text" : "Ein neuer W&W-Blogpost: Open Access - Teil 4 - Ein kleines Video \u00FCber OA http:\/\/is.gd\/ryJE #weissbierundwissenschaft #science #wissenschaft",
  "id" : 1482453097,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "140km",
      "screen_name" : "140km",
      "indices" : [ 0, 6 ],
      "id_str" : "16423904",
      "id" : 16423904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1482686470",
  "geo" : { },
  "id_str" : "1482703536",
  "in_reply_to_user_id" : 16423904,
  "text" : "@140km Frankreich ist ja auch der einzige wirkliche laizistische Staat in Europa. Bin neidisch :)",
  "id" : 1482703536,
  "in_reply_to_status_id" : 1482686470,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "140km",
  "in_reply_to_user_id_str" : "16423904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1482803443",
  "text" : "Kann es sein dass der GoogleReader manchmal ewig braucht um neue Items in Feeds zu finden?",
  "id" : 1482803443,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1482841589",
  "geo" : { },
  "id_str" : "1482849261",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Schade das es f\u00FCr so etwas immer noch keine ordentliche L\u00F6sung gibt.",
  "id" : 1482849261,
  "in_reply_to_status_id" : 1482841589,
  "created_at" : "2009-04-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475641016",
  "text" : "Und weiter geht\u2019s bei W&W mit dem Teil 3 der Open Access-Reihe: http:\/\/is.gd\/rmRh",
  "id" : 1475641016,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1475819425",
  "geo" : { },
  "id_str" : "1475888490",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod gut das es nur die geschriebenen und nicht gelesene ber\u00FCcksichtigt.",
  "id" : 1475888490,
  "in_reply_to_status_id" : 1475819425,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476003657",
  "geo" : { },
  "id_str" : "1476018176",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Und dann? Ist Wochenende?",
  "id" : 1476018176,
  "in_reply_to_status_id" : 1476003657,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476023269",
  "text" : "Hab mir gerade selbst jetzt die WD My Passport Studio bestellt. Mobilen Speicherplatz kann man nie genug haben.",
  "id" : 1476023269,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476003459",
  "geo" : { },
  "id_str" : "1476029662",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Bei dem Nachnamen kannst du froh sein dass er dich bestochen hat und dir nicht die Kniescheiben zertr\u00FCmmert hat ;)",
  "id" : 1476029662,
  "in_reply_to_status_id" : 1476003459,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476052964",
  "text" : "Gibt es eigentlich ne Alternative zu NetNewsWire als Feedreader der Sync zwischen MacOS & iPhone kann?",
  "id" : 1476052964,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476062872",
  "text" : "Australiens Umweltminister rockt \u266B http:\/\/blip.fm\/~3z3aw",
  "id" : 1476062872,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer | DMs are open",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476069813",
  "geo" : { },
  "id_str" : "1476079201",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca \u00FCber Byline hab ich bislang sehr unterschiedliche Aussagen geh\u00F6rt. Nutzt du es selbst und bist zufrieden?",
  "id" : 1476079201,
  "in_reply_to_status_id" : 1476069813,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476062387",
  "geo" : { },
  "id_str" : "1476090159",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight da bin ich noch etwas unschl\u00FCssig ob ich das alles \u00FCber Google wirklich will. Die Integration von Eventbox muss ich mal testen.",
  "id" : 1476090159,
  "in_reply_to_status_id" : 1476062387,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476097971",
  "geo" : { },
  "id_str" : "1476105882",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ich schau mir grad mal die Reader-Integration an. Sieht gar nicht so \u00FCbel aus. Vor allem weil alles in einem Programm.",
  "id" : 1476105882,
  "in_reply_to_status_id" : 1476097971,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476092782",
  "geo" : { },
  "id_str" : "1476111828",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Ich nutze zur Zeit Newsstand. Das hat als nette Features Twitter & Delicious-Integration.",
  "id" : 1476111828,
  "in_reply_to_status_id" : 1476092782,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476089758",
  "geo" : { },
  "id_str" : "1476114239",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt W\u00FCrde bei mir auch genauso funktionieren.",
  "id" : 1476114239,
  "in_reply_to_status_id" : 1476089758,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476153926",
  "text" : "LOL, die CSI Printifuge: http:\/\/is.gd\/rnZj (via http:\/\/is.gd\/rnZD )",
  "id" : 1476153926,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476151110",
  "geo" : { },
  "id_str" : "1476155934",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Was st\u00F6rt dich am GoogleReader in Eventbox denn?",
  "id" : 1476155934,
  "in_reply_to_status_id" : 1476151110,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 13, 19 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 52, 64 ],
      "id_str" : "107803659",
      "id" : 107803659
    }, {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 65, 72 ],
      "id_str" : "12408302",
      "id" : 12408302
    }, {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 73, 85 ],
      "id_str" : "428633",
      "id" : 428633
    }, {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 86, 100 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476158121",
  "text" : "According to @klout, I'm influenced by these peeps: @houellebeck @ComPod @kwerfeldein @germanstudent . http:\/\/bit.ly\/wLFR",
  "id" : 1476158121,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "googlereader",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476250658",
  "text" : "Oehm, kann der Google-Reader keine Unterordner in Ordnern oder bin ich zu bl\u00F6d? Tippe ja eigentlich auf zweiteres... #googlereader",
  "id" : 1476250658,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer | DMs are open",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476258112",
  "geo" : { },
  "id_str" : "1476274249",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Ich kann also Tags & \"Ordner\" vergeben die eigentlich Label sind. Hab gerade meine OPML importiert und Google hat alles zerschossen.",
  "id" : 1476274249,
  "in_reply_to_status_id" : 1476258112,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476293163",
  "geo" : { },
  "id_str" : "1476302875",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ich habs gerade erst im Feedreader entdeckt. :)",
  "id" : 1476302875,
  "in_reply_to_status_id" : 1476293163,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer | DMs are open",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476307354",
  "geo" : { },
  "id_str" : "1476333523",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Das ist schade, hab es mir gerade mal umgebastelt und werd nun mal schauen wie mir der GoogleReader in Eventbox gef\u00E4llt.",
  "id" : 1476333523,
  "in_reply_to_status_id" : 1476307354,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476487566",
  "text" : "Okay der Googlereader in Eventbox sieht okay aus. Delicious fehlt leider auch.",
  "id" : 1476487566,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476624075",
  "text" : "1A Zungenbrecher als Titel und Lyrics. \u266B http:\/\/blip.fm\/~3z7xb",
  "id" : 1476624075,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1476661007",
  "text" : "Mittagessen http:\/\/twitpic.com\/300qi",
  "id" : 1476661007,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476708086",
  "geo" : { },
  "id_str" : "1476783038",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Die \"i was dead for 7 weeks in the city of angels\"-dover? :)",
  "id" : 1476783038,
  "in_reply_to_status_id" : 1476708086,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476797338",
  "geo" : { },
  "id_str" : "1476812260",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Na genau das sag ich doch. Letztere beiden sind ja auf dem Album drauf :)",
  "id" : 1476812260,
  "in_reply_to_status_id" : 1476797338,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1476990679",
  "geo" : { },
  "id_str" : "1477194083",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz hab ja gerade deine Blip-Tracks durchgeschaut. Solider Geschmack. :)",
  "id" : 1477194083,
  "in_reply_to_status_id" : 1476990679,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1477389183",
  "geo" : { },
  "id_str" : "1477660636",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Bin mehr der last.fm-User weil man da nichts aktiv machen muss. blip nutze ich tagelang gar nicht und dann zwischendurch viel.",
  "id" : 1477660636,
  "in_reply_to_status_id" : 1477389183,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1477817120",
  "text" : "Willkommen in den tiefsten, fiesesten 90ern.  \u266B http:\/\/blip.fm\/~3zk8s",
  "id" : 1477817120,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Sons",
      "screen_name" : "FrankS",
      "indices" : [ 3, 10 ],
      "id_str" : "6028602",
      "id" : 6028602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1477827235",
  "text" : "RT @FrankS This was a triumph...  \u266B http:\/\/blip.fm\/~3zkdg",
  "id" : 1477827235,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1477889785",
  "text" : "Wir \u00FCberlegen uns f\u00FCr Weissbier & Wissenschaft eine Domain zu nehmen.Kurz soll sie sein, Vorschl\u00E4ge? W&W muss nicht explizit drin erscheinen",
  "id" : 1477889785,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weissbierundwissenschaft",
      "indices" : [ 79, 104 ]
    }, {
      "text" : "science",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1477961251",
  "text" : "Ein neuer W&W-Post von Philipp: Wettlauf mit der Evolution - http:\/\/is.gd\/rrIi #weissbierundwissenschaft #science #wissenschaft",
  "id" : 1477961251,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1478127926",
  "text" : "Man sollte mal ein Quiz machen: Bild-\u00DCberschrift vs. Spiegel-\u00DCberschrift. Die User erraten lassen welche zu welcher geh\u00F6rt. Impossible!",
  "id" : 1478127926,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1478142724",
  "text" : "Multi-Akustik-Gitarren-Porn \u266B http:\/\/blip.fm\/~3zoch",
  "id" : 1478142724,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1478160608",
  "geo" : { },
  "id_str" : "1478173493",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Jo, kleines Beispiel: \u201CSEX F\u00DCR BEUTE Affen tauschen Futter gegen Fleischeslust\u201D, Sex sells",
  "id" : 1478173493,
  "in_reply_to_status_id" : 1478160608,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1478161568",
  "geo" : { },
  "id_str" : "1478181905",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Sowohl als auch, wobei es bei SpOn noch etwas schlimmer ist finde ich.",
  "id" : 1478181905,
  "in_reply_to_status_id" : 1478161568,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1478184998",
  "text" : "Sorry f\u00FCr den blip-Spam heute. Den hier noch und dann ist gut f\u00FCr heute ;) \u266B http:\/\/blip.fm\/~3zouh",
  "id" : 1478184998,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Lippert",
      "screen_name" : "ChrisLippert",
      "indices" : [ 0, 13 ],
      "id_str" : "148401506",
      "id" : 148401506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1478789424",
  "text" : "@chrislippert Danke f\u00FCr den Vorschlag. Find ich aber nicht ganz so ideal. Bierolog.ie f\u00E4nd ich gut.  ;)",
  "id" : 1478789424,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1478875640",
  "geo" : { },
  "id_str" : "1478931728",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin Und auch hier nicht in allen. Island spart sich den Quatsch mit der Sommerzeit bespielsweise auch.",
  "id" : 1478931728,
  "in_reply_to_status_id" : 1478875640,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1479129016",
  "text" : "Werd nun doch mal Byline kaufen. Im schlimmsten Fall vermisse ich halt eine Schachtel Zigaretten.",
  "id" : 1479129016,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1479224630",
  "text" : "Neuer Blogpost: Peinlich - Manchmal meckert man halt auch zu Unrecht: http:\/\/is.gd\/rtKx",
  "id" : 1479224630,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1479613374",
  "text" : "Okay der Sync von Byline ist schon super im Vergleich zu Newsstand. Aber man kann nicht einzelne Feeds anzeigen sondern nur Ordner\/Tagweise?",
  "id" : 1479613374,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1474413052",
  "geo" : { },
  "id_str" : "1474936390",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Jo davon bekomme ich jede Menge.",
  "id" : 1474936390,
  "in_reply_to_status_id" : 1474413052,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1474989054",
  "text" : "Aufgestanden, dem Hund Fr\u00FChst\u00FCck gegeben, Gassi gewesen. Konnte jetzt schon wieder ins Bett!",
  "id" : 1474989054,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475244676",
  "text" : "Ich so: Schlafen! Hund so: No Way!",
  "id" : 1475244676,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475280043",
  "text" : "Wach werden! \u266B http:\/\/blip.fm\/~3yze0",
  "id" : 1475280043,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475293618",
  "text" : "Sp\u00E4testens damit wird es was mit dem Wachwerden. \u266B http:\/\/blip.fm\/~3yzin",
  "id" : 1475293618,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1475338189",
  "geo" : { },
  "id_str" : "1475345266",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic Wieso nicht die Studio-Variante die auch noch Firewire hat? ;)",
  "id" : 1475345266,
  "in_reply_to_status_id" : 1475338189,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1475367393",
  "geo" : { },
  "id_str" : "1475374900",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic Genug Geschwindigkeit bei Festplatten kann man doch nie haben! Au\u00DFerdem d\u00FCrfte die Stromversorgung kein Problem sein bei der :)",
  "id" : 1475374900,
  "in_reply_to_status_id" : 1475367393,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475468307",
  "text" : "Hey, diesen Monat hab ich einj\u00E4hriges auf Twitter. Wie viel Lebenszeit ich wohl hiermit verschwendet habe? ;)",
  "id" : 1475468307,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475476290",
  "text" : "Hab eine Pseudoantwort gefunden: I've wasted 2,162 Minutes or 36.03 Hours or 1.5 Days with 4,323 Tweets on Twitter!  http:\/\/tweetwasters.com",
  "id" : 1475476290,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1475567790",
  "text" : "Sehr cooles Remix-Mashup-Video \u00FCber das amerikanische Copyright: http:\/\/is.gd\/rmFn",
  "id" : 1475567790,
  "created_at" : "2009-04-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468548929",
  "text" : "Neuer Blogpost: Crazy - \u00DCber Bill Mahers Religulous http:\/\/is.gd\/ramL",
  "id" : 1468548929,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NERDCORE",
      "screen_name" : "NerdcoreBlog",
      "indices" : [ 0, 13 ],
      "id_str" : "984701",
      "id" : 984701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468551563",
  "geo" : { },
  "id_str" : "1468561261",
  "in_reply_to_user_id" : 984701,
  "text" : "@nerdcoreblog Das kommt auf den Hund an.Meiner findet es noch etwas toller wenn man mit ihm kuschelt und sich das Gesicht abschlabbern l\u00E4sst",
  "id" : 1468561261,
  "in_reply_to_status_id" : 1468551563,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "NerdcoreBlog",
  "in_reply_to_user_id_str" : "984701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468566724",
  "text" : "Und nochmal wundersch\u00F6ne Musik die ich vor kurzem erst kennengelernt habe. \u266B http:\/\/blip.fm\/~3xamz",
  "id" : 1468566724,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NERDCORE",
      "screen_name" : "NerdcoreBlog",
      "indices" : [ 0, 13 ],
      "id_str" : "984701",
      "id" : 984701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468563870",
  "geo" : { },
  "id_str" : "1468579542",
  "in_reply_to_user_id" : 984701,
  "text" : "@nerdcoreblog Ne ne, f\u00FCr mich l\u00E4sst der sogar seinen Futternapf stehen :)",
  "id" : 1468579542,
  "in_reply_to_status_id" : 1468563870,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "NerdcoreBlog",
  "in_reply_to_user_id_str" : "984701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468584219",
  "text" : "Vorsicht Ironie! http:\/\/is.gd\/r4BV",
  "id" : 1468584219,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1\uD83C\uDD5B\uD83C\uDD50\uD83C\uDD61\uD83C\uDD62\u26A1",
      "screen_name" : "Lars",
      "indices" : [ 0, 5 ],
      "id_str" : "29044240",
      "id" : 29044240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468595666",
  "geo" : { },
  "id_str" : "1468627118",
  "in_reply_to_user_id" : 6338182,
  "text" : "@lars Wie schade das der Tweet zu lang zum retweeten ist.",
  "id" : 1468627118,
  "in_reply_to_status_id" : 1468595666,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468646529",
  "geo" : { },
  "id_str" : "1468652377",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Gilt f\u00FCr Homo sapiens in den allermeisten F\u00E4llen ebenso.",
  "id" : 1468652377,
  "in_reply_to_status_id" : 1468646529,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468661526",
  "geo" : { },
  "id_str" : "1468672413",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Das kann gut sein. Und jetzt darf ich mit dem Hund raus ;)",
  "id" : 1468672413,
  "in_reply_to_status_id" : 1468661526,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468695580",
  "text" : "K\u00F6nnte jetzt mal einkaufen gehen. Nur was? Zigaretten machen auf Dauer so eine schlechte Ern\u00E4hrungsgrundlage.",
  "id" : 1468695580,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dortmundistdoof",
      "indices" : [ 26, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468698895",
  "text" : "Dortmund hat doofe Ohren! #dortmundistdoof",
  "id" : 1468698895,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468706928",
  "geo" : { },
  "id_str" : "1468749750",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Auch ein Fehler zwischen Imperialem und Dezimalem System? ;)",
  "id" : 1468749750,
  "in_reply_to_status_id" : 1468706928,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468793266",
  "geo" : { },
  "id_str" : "1468816268",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu BusySync kann das. Und SpanningSync soll das gleiche k\u00F6nnen.",
  "id" : 1468816268,
  "in_reply_to_status_id" : 1468793266,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468793266",
  "geo" : { },
  "id_str" : "1468835658",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu Ich selbst nutze BusySync und synchronisiere iPhone \u00FCber Google mit iCal http:\/\/is.gd\/rb3w",
  "id" : 1468835658,
  "in_reply_to_status_id" : 1468793266,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468879855",
  "geo" : { },
  "id_str" : "1468892965",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Endlich was zu gaffen f\u00FCr die Massen oder wie?",
  "id" : 1468892965,
  "in_reply_to_status_id" : 1468879855,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468890836",
  "geo" : { },
  "id_str" : "1468895763",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Did you hear about this cool new thing, what did they call it? Folders? ;)",
  "id" : 1468895763,
  "in_reply_to_status_id" : 1468890836,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468898397",
  "text" : "@rajue Den Direktlink zum Tweet durch tinyurl oder Konsorten jagen und diesen Twittern?",
  "id" : 1468898397,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468898618",
  "geo" : { },
  "id_str" : "1468919282",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Na dann kommt es auf ein paar Ordner mehr doch nicht mehr an. Die leere Inbox macht es so viel einfacher.",
  "id" : 1468919282,
  "in_reply_to_status_id" : 1468898618,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468931052",
  "geo" : { },
  "id_str" : "1468944022",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Das kenn ich, diese ganze Finanzwelt finde ich auch v\u00F6llig befremdlich. Ahja: Umlaute machen Hashtags traurig.",
  "id" : 1468944022,
  "in_reply_to_status_id" : 1468931052,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468950816",
  "geo" : { },
  "id_str" : "1468996532",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Das ist ja auch das Sch\u00F6ne an der Technik. Wenn es nicht klappt gibt es Undo :)",
  "id" : 1468996532,
  "in_reply_to_status_id" : 1468950816,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468994233",
  "geo" : { },
  "id_str" : "1469000140",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat \u201CBio\u201D ist halt nicht automatisch auch \u201CGut\u201D oder \u201CGesund\u201D, meist ist das Gegenteil der Fall ;)",
  "id" : 1469000140,
  "in_reply_to_status_id" : 1468994233,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469012899",
  "geo" : { },
  "id_str" : "1469025503",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Dann ist ja gut. Ich hab mir gerade die gute T\u00FCtensuppe geholt und nun ist mir zu warm um die zu essen.",
  "id" : 1469025503,
  "in_reply_to_status_id" : 1469012899,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469055286",
  "geo" : { },
  "id_str" : "1469084238",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Aber die Ank\u00FCndigung mit \u201Cjetzt gibt\u2019s endlich...\u201D zeigt schon ein seltsames Verst\u00E4ndnis was f\u00FCr Leser ihr erwartet.",
  "id" : 1469084238,
  "in_reply_to_status_id" : 1469055286,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469106407",
  "geo" : { },
  "id_str" : "1469223331",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Na wenn es die Kontrolle gibt ist ja alles gut. Oft fehlt genau dass doch in den Redaktionen heute...",
  "id" : 1469223331,
  "in_reply_to_status_id" : 1469106407,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1469256203",
  "text" : "Wow, schon wieder ein neuer Weissbier & Wissenschaft-Post: Teil 2 der Artikelreihe zu Open Access http:\/\/is.gd\/rbUC",
  "id" : 1469256203,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469270545",
  "geo" : { },
  "id_str" : "1469282403",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Wenn die meisten Journalisten auf dem Niveau auf dem sie angekommen sind weitermachen ist die Antwort: So brauchen wir sie nicht!",
  "id" : 1469282403,
  "in_reply_to_status_id" : 1469270545,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1469467493",
  "text" : "Sachen gibts... http:\/\/yfrog.com\/5xmfej",
  "id" : 1469467493,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469615891",
  "geo" : { },
  "id_str" : "1469757250",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Das sind die besten 100 Euro die man als Canon-Fotograf ausgeben kann :)",
  "id" : 1469757250,
  "in_reply_to_status_id" : 1469615891,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469420173",
  "geo" : { },
  "id_str" : "1469767805",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Na schau dir doch den letzten Amoklauf an in einschl\u00E4gigen deutschen Medien. Wie viel Qualit\u00E4tsjournalismus war denn dabei?",
  "id" : 1469767805,
  "in_reply_to_status_id" : 1469420173,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1469770273",
  "geo" : { },
  "id_str" : "1469788333",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Na um so besser, das Ding kann man ob des g\u00FCnstigen Preises auch einfach benutzen ohne Angst zu haben das was passiert ;)",
  "id" : 1469788333,
  "in_reply_to_status_id" : 1469770273,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1469890811",
  "text" : "What If The Beatles Were Irish? Awesome! http:\/\/is.gd\/rdfs",
  "id" : 1469890811,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1471522626",
  "text" : "Wieso stellt MacOS beim Reboot bittesch\u00F6n die Uhrzeit 2 Stunden vor und Mausklick per Tap geht nicht mehr obwohl der Haken gesetzt ist?",
  "id" : 1471522626,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1\uD83C\uDD5B\uD83C\uDD50\uD83C\uDD61\uD83C\uDD62\u26A1",
      "screen_name" : "Lars",
      "indices" : [ 0, 5 ],
      "id_str" : "29044240",
      "id" : 29044240
    }, {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 6, 13 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1471509672",
  "geo" : { },
  "id_str" : "1471528568",
  "in_reply_to_user_id" : 6338182,
  "text" : "@lars @343max Ja, mir geht es auch total so. Frische Motivation was zu tun. Finde ich super.",
  "id" : 1471528568,
  "in_reply_to_status_id" : 1471509672,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1471618087",
  "geo" : { },
  "id_str" : "1471627436",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Jau hab ich. Aber was hat das bittesch\u00F6n mit meinen Mac OS-Settings zu schaffen? ;)",
  "id" : 1471627436,
  "in_reply_to_status_id" : 1471618087,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1471643414",
  "geo" : { },
  "id_str" : "1471674658",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ja mir sonst auch nicht, und auch dann nicht immer.Wobei sonst boote ich die Kiste auch nicht neu.Aber ohne Bootcamp keine Spiele",
  "id" : 1471674658,
  "in_reply_to_status_id" : 1471643414,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henning Gro\u00DF",
      "screen_name" : "HASENFARM",
      "indices" : [ 0, 10 ],
      "id_str" : "14197888",
      "id" : 14197888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1471904262",
  "geo" : { },
  "id_str" : "1471922965",
  "in_reply_to_user_id" : 14197888,
  "text" : "@HASENFARM Fotografen k\u00F6nnen auch keine Magie, die machen schon ihr bestes. Aber mach mal aus Scheisse Gold :P",
  "id" : 1471922965,
  "in_reply_to_status_id" : 1471904262,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "HASENFARM",
  "in_reply_to_user_id_str" : "14197888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1471956081",
  "geo" : { },
  "id_str" : "1471965956",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ja das geht auch",
  "id" : 1471965956,
  "in_reply_to_status_id" : 1471956081,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1471985225",
  "text" : "Dropbox hat gerade angeblich ein 700 mb-Video in gut 30 Sek. via DSL hochgeladen und es funktioniert sogar auf der anderen Seite. Magic?",
  "id" : 1471985225,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1472024511",
  "geo" : { },
  "id_str" : "1472038644",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ne, zumindest von mir nicht weil ich noch nie den Upload gestartet habe. Ganz frisch reingezogen.",
  "id" : 1472038644,
  "in_reply_to_status_id" : 1472024511,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1472024511",
  "geo" : { },
  "id_str" : "1472045379",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ich glaube er hat einfach erkannt dass genau diese Datei ein anderer User bereits hochgeladen hatte und mir den Upload deshalb erspart",
  "id" : 1472045379,
  "in_reply_to_status_id" : 1472024511,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1472164609",
  "text" : "Wieso folgen mir eigentlich immer mehr PR-Accounts aus dem Bereich Kosmetik\/Beauty? Seh ich so scheisse aus?",
  "id" : 1472164609,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468137923",
  "text" : "Walker sind witzig, Hund und ich \u00FCberholen sie beim spazieren gehen regelm\u00E4ssig. Schauen dann immer so verdutzt und angepisst.",
  "id" : 1468137923,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Smith",
      "screen_name" : "tilmar",
      "indices" : [ 0, 7 ],
      "id_str" : "2163562470",
      "id" : 2163562470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468177264",
  "text" : "@TilMar Also bei uns laufen die immer noch rum.",
  "id" : 1468177264,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468322194",
  "text" : "blip.fm soll mal wieder funktionieren",
  "id" : 1468322194,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468459771",
  "text" : "Gestern erst kennengelernt und schon verliebt \u266B http:\/\/blip.fm\/~3x9x7",
  "id" : 1468459771,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1468484241",
  "text" : "Langsam trudeln ja mal mehr Reviews zur #rp09 ein. Gibt es eigentlich irgendwo einen zentralen Pressespiegel abseits Technorati et al?",
  "id" : 1468484241,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NERDCORE",
      "screen_name" : "NerdcoreBlog",
      "indices" : [ 0, 13 ],
      "id_str" : "984701",
      "id" : 984701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1468526556",
  "geo" : { },
  "id_str" : "1468547137",
  "in_reply_to_user_id" : 984701,
  "text" : "@nerdcoreblog Das ist der beste Weg des Hundes Freund zu werden.",
  "id" : 1468547137,
  "in_reply_to_status_id" : 1468526556,
  "created_at" : "2009-04-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "NerdcoreBlog",
  "in_reply_to_user_id_str" : "984701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461599785",
  "text" : "StudiVZ ist so peinlich das ich das nur noch im Porn-Mode vom Firefox besuche um keine Spuren in der History zu hinterlassen.",
  "id" : 1461599785,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shadaim Shirts",
      "screen_name" : "shadaimshirts",
      "indices" : [ 0, 14 ],
      "id_str" : "16159560",
      "id" : 16159560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1461620562",
  "geo" : { },
  "id_str" : "1461632934",
  "in_reply_to_user_id" : 16159560,
  "text" : "@shadaimshirts Zumindest die Beta von 3.1 die ich nutze. \uF8FF+Shift+P und schau was passiert.",
  "id" : 1461632934,
  "in_reply_to_status_id" : 1461620562,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "shadaimshirts",
  "in_reply_to_user_id_str" : "16159560",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Lippert",
      "screen_name" : "ChrisLippert",
      "indices" : [ 0, 13 ],
      "id_str" : "148401506",
      "id" : 148401506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461634726",
  "text" : "@chrislippert Ich logge da eh nur noch ein wenn ich Nachrichten bekomme weil Menschen zu bl\u00F6d sind normale Mails zu schreiben...",
  "id" : 1461634726,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461651398",
  "text" : "Werde mir heute Religulous anschauen.",
  "id" : 1461651398,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Lippert",
      "screen_name" : "ChrisLippert",
      "indices" : [ 0, 13 ],
      "id_str" : "148401506",
      "id" : 148401506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461675565",
  "text" : "@chrislippert Ja. Die iPhone-App ist ein Witz, sieht aus als h\u00E4tte es ein 12 J\u00E4hriger an einem versoffenem Abend gecoded.",
  "id" : 1461675565,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461678979",
  "text" : "http:\/\/twitpic.com\/2wo8j - Auch Hunde stehen auf Videochatting.",
  "id" : 1461678979,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1461853380",
  "text" : "Jetzt anfangen noch einen Artikel zu schreiben oder doch lieber ne Runde Left 4 Dead spielen vorher?",
  "id" : 1461853380,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1461925333",
  "geo" : { },
  "id_str" : "1462178036",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Aber das heisst ja nicht das sie es nicht doch tun...",
  "id" : 1462178036,
  "in_reply_to_status_id" : 1461925333,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1462207769",
  "text" : "@rajue Gl\u00FCckwunsch! Und wird nun noch gro\u00DF gefeiert? :)",
  "id" : 1462207769,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "diazis123",
      "screen_name" : "tomaschek",
      "indices" : [ 0, 10 ],
      "id_str" : "2533280498",
      "id" : 2533280498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1462324307",
  "text" : "@tomaschek Wie knuffig. Der sieht ja auch noch jung aus :)",
  "id" : 1462324307,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1462354700",
  "text" : "Gibt\u2019s eine nette Freeware um einfache Flowcharts zu erstellen f\u00FCr den Mac?",
  "id" : 1462354700,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "diazis123",
      "screen_name" : "tomaschek",
      "indices" : [ 0, 10 ],
      "id_str" : "2533280498",
      "id" : 2533280498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1462444067",
  "text" : "@tomaschek Oh wie cool. Mein dicker Kerl liegt hier wieder faul unter dem Schreibtisch :)",
  "id" : 1462444067,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1462468926",
  "geo" : { },
  "id_str" : "1462656147",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin Wir haben in der WG Versatel, seit fast 2 Jahren ohne St\u00F6rungen.",
  "id" : 1462656147,
  "in_reply_to_status_id" : 1462468926,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1462448974",
  "geo" : { },
  "id_str" : "1462673361",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Werd ich mal schauen ob man den finden kann.",
  "id" : 1462673361,
  "in_reply_to_status_id" : 1462448974,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1462743355",
  "geo" : { },
  "id_str" : "1462756380",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih H\u00F6rt sich nach #rp09 an! ;)",
  "id" : 1462756380,
  "in_reply_to_status_id" : 1462743355,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1462733916",
  "geo" : { },
  "id_str" : "1462757240",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Danke f\u00FCr die Links!",
  "id" : 1462757240,
  "in_reply_to_status_id" : 1462733916,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wissenschaft",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "science",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1462917621",
  "text" : "Neuer Weissbier & Wissenschaft-Beitrag: Open Access - Teil 1 http:\/\/is.gd\/r0nu #wissenschaft #science",
  "id" : 1462917621,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1464645602",
  "text" : "Religulous war super. Kann ich jedem Nicht-Fundamentalisten nur empfehlen.",
  "id" : 1464645602,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1465147733",
  "text" : "Seitdem ich von der #rp09 wieder da bin followt der Hund mir auf Schritt und Tritt. Steht bevorzugt zwischen meinen Beinen rum.",
  "id" : 1465147733,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1465684994",
  "geo" : { },
  "id_str" : "1465693891",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu Dann gibt es bald pro-Accounts deren Besitzer dann mit stabileren Accounts verw\u00F6hnt werden? ;)",
  "id" : 1465693891,
  "in_reply_to_status_id" : 1465684994,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1465744333",
  "text" : "Twitter stirbt weg.  Ich sage #gn8",
  "id" : 1465744333,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457277635",
  "geo" : { },
  "id_str" : "1457285423",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, ich bin der Hundetyp, deshalb geh\u00F6rt die Katze auch nicht mir. Aber meine Freundin ist Beides. Deshalb hat das Tier Asyl.",
  "id" : 1457285423,
  "in_reply_to_status_id" : 1457277635,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457330971",
  "geo" : { },
  "id_str" : "1457344011",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora Das Solo find ich ja so genial!",
  "id" : 1457344011,
  "in_reply_to_status_id" : 1457330971,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457361807",
  "geo" : { },
  "id_str" : "1457382231",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Vertragen ist zu viel gesagt. Leben & Leben lassen w\u00FCrd ich sagen. Der Hund will mit der Katze spielen, sie kriegt Angst und haut zu",
  "id" : 1457382231,
  "in_reply_to_status_id" : 1457361807,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457348857",
  "geo" : { },
  "id_str" : "1457384550",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora uh uh! ;)",
  "id" : 1457384550,
  "in_reply_to_status_id" : 1457348857,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457391551",
  "geo" : { },
  "id_str" : "1457394984",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora Davon w\u00FCrd ich ja nun zugerne einen Mitschnitt haben :)",
  "id" : 1457394984,
  "in_reply_to_status_id" : 1457391551,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457402567",
  "geo" : { },
  "id_str" : "1457433393",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Hier ist ein Archivbild: http:\/\/is.gd\/qRa3",
  "id" : 1457433393,
  "in_reply_to_status_id" : 1457402567,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457399022",
  "geo" : { },
  "id_str" : "1457434211",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora Wie schade!",
  "id" : 1457434211,
  "in_reply_to_status_id" : 1457399022,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457437132",
  "geo" : { },
  "id_str" : "1457448193",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora Davon bin ich noch nicht \u00FCberzeugt. :)",
  "id" : 1457448193,
  "in_reply_to_status_id" : 1457437132,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1457455887",
  "text" : "Oha, ein neuer Blogpost auf Weissbier & Wissenschaft von Philipp: Alternatives Splicing in Pflanzen http:\/\/is.gd\/qRc9 #science",
  "id" : 1457455887,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457523093",
  "geo" : { },
  "id_str" : "1457980199",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod jo, ist schon okay :)",
  "id" : 1457980199,
  "in_reply_to_status_id" : 1457523093,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457999224",
  "geo" : { },
  "id_str" : "1458027891",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich kann dir verraten sie hat gr\u00FCne Augen und ist sonst genauso schwarz wie auf dem Foto zu sehen ist :)",
  "id" : 1458027891,
  "in_reply_to_status_id" : 1457999224,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diss2",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1457872685",
  "geo" : { },
  "id_str" : "1458047205",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Klar, mach ich gerne #diss2.0",
  "id" : 1458047205,
  "in_reply_to_status_id" : 1457872685,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "rp09",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1458516095",
  "text" : "Neuer Blogpost zu diesem ( http:\/\/is.gd\/qQMg )#fail Artikel \u00FCber die #rp09 der bei FAZ erschienen ist : http:\/\/is.gd\/qSHK",
  "id" : 1458516095,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1458546043",
  "text" : "Ich seh gerade s9y hat den Blogpost total zerschossen. Editor und ich auf Kriegsfu\u00DF. W\u00E4re ich nicht so faul w\u00FCrde ich zu Wordpress switchen.",
  "id" : 1458546043,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458551126",
  "geo" : { },
  "id_str" : "1458574768",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das Bild ist schon so alt, da gab es noch gar keine LOLCatz!",
  "id" : 1458574768,
  "in_reply_to_status_id" : 1458551126,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458574452",
  "geo" : { },
  "id_str" : "1458583256",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Sch\u00F6n zu lesen das auch andere Leute das so sehen und ich nicht alleine bin.",
  "id" : 1458583256,
  "in_reply_to_status_id" : 1458574452,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458593283",
  "geo" : { },
  "id_str" : "1458616279",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Jo, seltsame Auswahl an Themen die er da in seinen Artikel packt. Und ich finde Wales hat sogar sehr viel Aufmerksamkeit bekommen",
  "id" : 1458616279,
  "in_reply_to_status_id" : 1458593283,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458602033",
  "geo" : { },
  "id_str" : "1458621350",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Zumindest was ich so gesehen habe im Vortrag waren die Leute die ich sehen konnte sehr interessiert bei Wales #rp09",
  "id" : 1458621350,
  "in_reply_to_status_id" : 1458602033,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458636152",
  "geo" : { },
  "id_str" : "1458663030",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Das kritisiert er in dem Artikel allerdings \u00FCberhaupt nicht ;) #rp09",
  "id" : 1458663030,
  "in_reply_to_status_id" : 1458636152,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458643012",
  "geo" : { },
  "id_str" : "1458668484",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod pics or it didn't happen!",
  "id" : 1458668484,
  "in_reply_to_status_id" : 1458643012,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1458672737",
  "geo" : { },
  "id_str" : "1458682817",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Was ist denn noch \u00FCbergeblieben?",
  "id" : 1458682817,
  "in_reply_to_status_id" : 1458672737,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1458686384",
  "text" : "Bin ich einfach nur blind oder kann man die #rp09 Videos von make wirklich nicht embedden?",
  "id" : 1458686384,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1459233895",
  "text" : "Wir sagen #gn8",
  "id" : 1459233895,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1455921000",
  "text" : "Guten Morgen. Der Hund hat mich wachgeschlabbert. Jetzt erstmal Fr\u00FChst\u00FCck und dann Gassi.",
  "id" : 1455921000,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1455951652",
  "geo" : { },
  "id_str" : "1455988188",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das kommt, wenn auch selten, Vor. Dann wenn er es so n\u00F6tig hat das er mich hinter sich herzieht ;)",
  "id" : 1455988188,
  "in_reply_to_status_id" : 1455951652,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1455999339",
  "geo" : { },
  "id_str" : "1456006096",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ne, das hab ich nur mal gemacht um dem Hund zu zeigen wie es geht ;)",
  "id" : 1456006096,
  "in_reply_to_status_id" : 1455999339,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1456017444",
  "geo" : { },
  "id_str" : "1456021196",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ja, mittlerweile kann er es.",
  "id" : 1456021196,
  "in_reply_to_status_id" : 1456017444,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1456232020",
  "text" : "Ich glaube ich hab schon lange nicht mehr so viele Mails rausgehauen wie heute morgen.",
  "id" : 1456232020,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1456462792",
  "text" : "Lecker Mittagessen f\u00FCr Hund und mich bei meinen Eltern.",
  "id" : 1456462792,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1456507727",
  "geo" : { },
  "id_str" : "1456511079",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto Hat er sein Abendessen wohl nicht so gut verarbeitet?",
  "id" : 1456511079,
  "in_reply_to_status_id" : 1456507727,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1456517426",
  "geo" : { },
  "id_str" : "1456531506",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto Ah das sch\u00F6ne Brackwasser. Was k\u00F6nnte einem Hund auch besser schmecken. Nicht dieses bl\u00F6de, frische Wasser was es zuhause gibt. :)",
  "id" : 1456531506,
  "in_reply_to_status_id" : 1456517426,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1456560617",
  "geo" : { },
  "id_str" : "1456563398",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Stimmt absolut. Ich mach dem Hund ja auch keinen Vorwurf deshalb :)",
  "id" : 1456563398,
  "in_reply_to_status_id" : 1456560617,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1456547381",
  "geo" : { },
  "id_str" : "1456564376",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Sehr cooles Paper, ich frage mich was mit Tolkiens Sprachen ist. Haben sie die f\u00FCr Folge-Ver\u00F6ffentlichungen aufgehoben?",
  "id" : 1456564376,
  "in_reply_to_status_id" : 1456547381,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1456595349",
  "text" : "Einfach zu geil der Typ. \u266B http:\/\/blip.fm\/~3ugxy",
  "id" : 1456595349,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1456625754",
  "text" : "Schon ewig nicht mehr geh\u00F6rt. \u266B http:\/\/blip.fm\/~3uh6h",
  "id" : 1456625754,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1457068145",
  "text" : "Der Hund hatte nun den ganzen Nachmittag einen vierbeinigen Freund zum spielen da. Jetzt liegt er unter dem Schreibtisch und hechelt endlos.",
  "id" : 1457068145,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1457079536",
  "text" : "Von dem Song gibt\u2019s auch fast endlos viele Versionen von Dylan selber. \u266B http:\/\/blip.fm\/~3uljt",
  "id" : 1457079536,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1457261149",
  "text" : "Katze, Hund und ich im max. 4 Quadratmeter gro\u00DFem Badezimmer. Diese Badezimmer ist zu klein f\u00FCr uns Beide, aehm dieses Trio!",
  "id" : 1457261149,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1450902237",
  "text" : "Sitze gerade an meinem n\u00E4chsten Artikel zur re:publica w\u00E4hrend ich im Hintergrund die Podcasts wegh\u00F6re.",
  "id" : 1450902237,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1450902495",
  "geo" : { },
  "id_str" : "1450904346",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Ah, hast du deine Daten in deinen Poken eingetragen? Weil als ich meinen gerade angeschlossen habe warst du der ohne Details.",
  "id" : 1450904346,
  "in_reply_to_status_id" : 1450902495,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1450905942",
  "geo" : { },
  "id_str" : "1450911554",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Okay, da bin ich dann gespannt :) Hast denn noch viele Leute angepokt?",
  "id" : 1450911554,
  "in_reply_to_status_id" : 1450905942,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1450915969",
  "geo" : { },
  "id_str" : "1450922341",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Schade, aber das n\u00E4chste Tweetup oder die n\u00E4chste pl0gbar etc. kommt ja bestimmt.",
  "id" : 1450922341,
  "in_reply_to_status_id" : 1450915969,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poken",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1450924808",
  "geo" : { },
  "id_str" : "1450928896",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Bestimmt, zur Not wechselst du sie halt selbst :) #poken",
  "id" : 1450928896,
  "in_reply_to_status_id" : 1450924808,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1450983116",
  "text" : "Wieso meldet sich die alte Canon 350D eigentlich in Lightroom als Canon 99D an?",
  "id" : 1450983116,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451028790",
  "text" : "Noch ein Blogpost von mir zur #rp09 http:\/\/is.gd\/qH9g Mit Tag 2, Tag 3 ein wenig Foto und ein bisschen Fazit oder so.",
  "id" : 1451028790,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451103559",
  "geo" : { },
  "id_str" : "1451117489",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ich glaube das l\u00E4sst sich heute nicht mehr klar trennen. Ist mein iPhone noch ein Telefon oder schon Computer per Definition?",
  "id" : 1451117489,
  "in_reply_to_status_id" : 1451103559,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451198106",
  "geo" : { },
  "id_str" : "1451239753",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Tolle Wurst.",
  "id" : 1451239753,
  "in_reply_to_status_id" : 1451198106,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451363182",
  "geo" : { },
  "id_str" : "1451368097",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Was soll denn besser sein als eneloops?",
  "id" : 1451368097,
  "in_reply_to_status_id" : 1451363182,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451406687",
  "text" : "Mit Leuten skypen die ihre Musik so laut haben das sie Shazam noch problemlos identifizieren ist macht wenig Spa\u00DF.",
  "id" : 1451406687,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Smith",
      "screen_name" : "tilmar",
      "indices" : [ 0, 7 ],
      "id_str" : "2163562470",
      "id" : 2163562470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451425805",
  "text" : "@TilMar Das hab ich schon vermutet. Hab mir die Conversation-View angesehen und gar nicht verstanden was das soll :)",
  "id" : 1451425805,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451444464",
  "geo" : { },
  "id_str" : "1451451618",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Daf\u00FCr sind die eneloops einfach genial was ihre Lagerm\u00F6glichkeiten betrifft. Ich hab die Teile hier \u00FCberall im Einsatz als Backups.",
  "id" : 1451451618,
  "in_reply_to_status_id" : 1451444464,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451463459",
  "geo" : { },
  "id_str" : "1451474004",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Keine Ahnung, ich nutz die eneloops in meiner Taschenlampe wo sie ordentlich lange halten und halt im Kamerakoffer f\u00FCr den Notfall.",
  "id" : 1451474004,
  "in_reply_to_status_id" : 1451463459,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gwup | die skeptiker",
      "screen_name" : "gwup",
      "indices" : [ 3, 8 ],
      "id_str" : "19903466",
      "id" : 19903466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dortmund",
      "indices" : [ 42, 51 ]
    }, {
      "text" : "Buskampagne",
      "indices" : [ 53, 65 ]
    }, {
      "text" : "Atheismus",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451487128",
  "text" : "RT @gwup: sieht keine Meinungsfreiheit in #Dortmund: #Buskampagne pro Religion erlaubt, pro #Atheismus verboten: http:\/\/is.gd\/qH0o",
  "id" : 1451487128,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451487532",
  "geo" : { },
  "id_str" : "1451499226",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Naja ich brauche meine ( http:\/\/is.gd\/qI6w ) jeden Tag. Da ist Sch\u00FCtteln etwas unpraktisch.",
  "id" : 1451499226,
  "in_reply_to_status_id" : 1451487532,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451531493",
  "text" : "Neuer W&W-Post: Sind Killerspiele gut f\u00FCr die Augen? 3D-Shooter verbessern das Kontrastsehen http:\/\/is.gd\/qIaz #science #wissenschaft",
  "id" : 1451531493,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451569215",
  "geo" : { },
  "id_str" : "1451575986",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Absolut! Aber ich w\u00FCrd sagen gestern war von den Talks etc. her auch der st\u00E4rkste Tag. #rp09",
  "id" : 1451575986,
  "in_reply_to_status_id" : 1451569215,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451601046",
  "geo" : { },
  "id_str" : "1451765124",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Die w\u00FCrd ich aber nicht t\u00E4glich am G\u00FCrtel tragen wollen daf\u00FCr. Ist sie denn ordentlich hell?",
  "id" : 1451765124,
  "in_reply_to_status_id" : 1451601046,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451767628",
  "geo" : { },
  "id_str" : "1451772912",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Du meinst re:bell oder? #rp09",
  "id" : 1451772912,
  "in_reply_to_status_id" : 1451767628,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1451847000",
  "geo" : { },
  "id_str" : "1451901867",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Na denn ists f\u00FCr Nicht-immer-Dabei super :)",
  "id" : 1451901867,
  "in_reply_to_status_id" : 1451847000,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kirche21",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451978870",
  "text" : "#kirche21 ? Selten sowas nutzloses geh\u00F6rt. Religion soll sich einfach endlich in Ruhe zum sterben hinlegen. M\u00E4rchen sind out.",
  "id" : 1451978870,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1453376268",
  "geo" : { },
  "id_str" : "1453426191",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Bei dem Kommentar dachte ich zuerst noch der Gute w\u00FCrde nur Spa\u00DF machen. Aber seine Webseite ist ja noch verr\u00FCckter.",
  "id" : 1453426191,
  "in_reply_to_status_id" : 1453376268,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LarsAlberth",
      "screen_name" : "LarsAlberth",
      "indices" : [ 0, 12 ],
      "id_str" : "14473421",
      "id" : 14473421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1453424926",
  "geo" : { },
  "id_str" : "1453452110",
  "in_reply_to_user_id" : 14473421,
  "text" : "@LarsAlberth Solange du wenigstens ein paar spannende Talks geh\u00F6rt hast :)",
  "id" : 1453452110,
  "in_reply_to_status_id" : 1453424926,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "LarsAlberth",
  "in_reply_to_user_id_str" : "14473421",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1453458724",
  "geo" : { },
  "id_str" : "1453465505",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ja die Dinger kenn ich auch, es ist immer wieder eine Freude die Kleinanzeigen der nadann zu durchst\u00F6bern.",
  "id" : 1453465505,
  "in_reply_to_status_id" : 1453458724,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "re:publica",
      "screen_name" : "republica",
      "indices" : [ 54, 64 ],
      "id_str" : "9824472",
      "id" : 9824472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453504349",
  "text" : "Lustig auch das die Fotos im eigenen Flickrstream von @republica nicht mit den richtigen\/vorgeschlagenen #rp09 Tags versehen sind. ;)",
  "id" : 1453504349,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1453477857",
  "geo" : { },
  "id_str" : "1453535257",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Bist du eigentlich bei der n\u00E4chsten pl0gbar wieder dabei?",
  "id" : 1453535257,
  "in_reply_to_status_id" : 1453477857,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1453541465",
  "geo" : { },
  "id_str" : "1453551080",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Stimmt ja, irgendwer muss ja die Quote kaputt machen ;)",
  "id" : 1453551080,
  "in_reply_to_status_id" : 1453541465,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Rudorfer",
      "screen_name" : "Bigod",
      "indices" : [ 0, 6 ],
      "id_str" : "3499741",
      "id" : 3499741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453572616",
  "in_reply_to_user_id" : 3499741,
  "text" : "@bigod Klasse Interview was du da 3sat.neues gegeben hast. http:\/\/is.gd\/qLI3",
  "id" : 1453572616,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Bigod",
  "in_reply_to_user_id_str" : "3499741",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Thielecke",
      "screen_name" : "mthie",
      "indices" : [ 3, 9 ],
      "id_str" : "3253641",
      "id" : 3253641
    }, {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 14, 26 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tinychat",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453591544",
  "text" : "RT @mthie: RT @lirontocker: (Probably the first) Spontaneous online tweetup! Join! #tinychat http:\/\/www.tinychat.com\/8n5t",
  "id" : 1453591544,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453751566",
  "text" : "Eine Runde WTF?!?! via 4chan - Einstein vs. Ninjas: http:\/\/is.gd\/qLXd",
  "id" : 1453751566,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453893634",
  "text" : "Die Katze ist ein Mistst\u00FCck: Verfolgt den Hund und mich beim Gassi-Gehen, mit genug Abstand das der Hund sie sieht aber nicht zu ihr kann.",
  "id" : 1453893634,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1453996139",
  "text" : "Da Hund und ich zur Zeit Strohwitwer sind legen wir uns nun ins Bett. #gn8",
  "id" : 1453996139,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 23, 31 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1448329943",
  "text" : "Dank dem fantastischem @stelten bin ich super heim gekommen von der #rp09 Nun 3 Tage WLAN und Schlaf nachholen. In der Reihenfolge?",
  "id" : 1448329943,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1448341897",
  "text" : "In 3 Tagen angesammelt: 400 Blogposts im Reader und 20 Podcasts in iTunes. Das spricht f\u00FCr Info-Junkie w\u00FCrd ich sagen.",
  "id" : 1448341897,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1443737900",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt http:\/\/twitpic.com\/2qo34 - Das sieht ja fast mehr nach high-ISO-Bildrauschen aus :)",
  "id" : 1443737900,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1443984071",
  "text" : "Und die BVG-Schweine verbieten die Atheist-Bus-Campaign in L:Berlin weil sie keine weltanschauliche Werbung wollen? http:\/\/twitpic.com\/2r6sk",
  "id" : 1443984071,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1444094777",
  "text" : "Letzter Tag - Photo: http:\/\/bkite.com\/067Yg",
  "id" : 1444094777,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1444560723",
  "text" : "Die Frage was Wiki in Wikipedia heisst h\u00E4tte man auch einfach per selbiger beantworten k\u00F6nnen. #rp09",
  "id" : 1444560723,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1444940966",
  "geo" : { },
  "id_str" : "1445146310",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ich hatte nachschlagen m\u00FCssen. Allerdings war ich auch nicht bl\u00F6d genug genau das in der Discussion zu Fragen ;)",
  "id" : 1445146310,
  "in_reply_to_status_id" : 1444940966,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atheist Bus",
      "screen_name" : "AtheistBus",
      "indices" : [ 0, 11 ],
      "id_str" : "18632045",
      "id" : 18632045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1445146131",
  "geo" : { },
  "id_str" : "1445155714",
  "in_reply_to_user_id" : 18632045,
  "text" : "@AtheistBus Great, I'm waiting for you :)",
  "id" : 1445155714,
  "in_reply_to_status_id" : 1445146131,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "AtheistBus",
  "in_reply_to_user_id_str" : "18632045",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 0, 9 ],
      "id_str" : "17442320",
      "id" : 17442320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1444770529",
  "geo" : { },
  "id_str" : "1445361656",
  "in_reply_to_user_id" : 17442320,
  "text" : "@jonworth well done talk! Loved to hear about your success. Let's hope the german campaign may start soon.",
  "id" : 1445361656,
  "in_reply_to_status_id" : 1444770529,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "jonworth",
  "in_reply_to_user_id_str" : "17442320",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 0, 9 ],
      "id_str" : "17442320",
      "id" : 17442320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1445620516",
  "geo" : { },
  "id_str" : "1445668118",
  "in_reply_to_user_id" : 17442320,
  "text" : "@jonworth what do you think of the\nGerman slogans?",
  "id" : 1445668118,
  "in_reply_to_status_id" : 1445620516,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "jonworth",
  "in_reply_to_user_id_str" : "17442320",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1445905403",
  "text" : "Um wieviele Stunden ist nun eigentlich alles Verschoben bei der #rp09 ?",
  "id" : 1445905403,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1445892233",
  "geo" : { },
  "id_str" : "1445943566",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Ist ordentlich Zeitverzug in allem. Gut eine Stunde w\u00FCrde ich sagen.",
  "id" : 1445943566,
  "in_reply_to_status_id" : 1445892233,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1446000833",
  "text" : "Violetter Text auf schwarzem Hintergrund = Augenkrebs #rp09",
  "id" : 1446000833,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1446537311",
  "text" : "W\u00FCrde jetzt gern mal einen Tag schlafen. Wird wohl nichts!",
  "id" : 1446537311,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1446632781",
  "text" : "Mist. Twitter ist schon wieder fubar. 15 min Verz\u00F6gerung. Ich kann so nicht nicht-arbeiten",
  "id" : 1446632781,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1446685840",
  "geo" : { },
  "id_str" : "1446802946",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ich h\u00F6re :p",
  "id" : 1446802946,
  "in_reply_to_status_id" : 1446685840,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1446986922",
  "geo" : { },
  "id_str" : "1447169011",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ich glaube nicht. Aber falls nur ich h\u00F6re k\u00F6nnen wir auch einfach skypen ;)",
  "id" : 1447169011,
  "in_reply_to_status_id" : 1446986922,
  "created_at" : "2009-04-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1436970084",
  "text" : "Guten Morgen Berlin. Wieso fahren die S-Bahnen um halb 4 eigentlich nicht mehr? Und wieso hab ich so Kopfschmerzen? #rp09",
  "id" : 1436970084,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437039036",
  "geo" : { },
  "id_str" : "1437050499",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Das gabs leider nicht. Daf\u00FCr dann aber ein normales Taxi :)",
  "id" : 1437050499,
  "in_reply_to_status_id" : 1437039036,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437128930",
  "text" : "Das #rp09 WLAN ist heute morgen immer noch epic fail.",
  "id" : 1437128930,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437155323",
  "text" : "@rajue na aber selbstverst\u00E4ndlich!",
  "id" : 1437155323,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437214695",
  "geo" : { },
  "id_str" : "1437230710",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Hab das gleiche Problem mit Eventbox. Hast schon einen fix gefunden?",
  "id" : 1437230710,
  "in_reply_to_status_id" : 1437214695,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andi portmann",
      "screen_name" : "wirgestalter",
      "indices" : [ 0, 13 ],
      "id_str" : "22899387",
      "id" : 22899387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437238095",
  "geo" : { },
  "id_str" : "1437245830",
  "in_reply_to_user_id" : 5654742,
  "text" : "@wirgestalter Mist. Naja solange auf der republica das WLAN nicht geht muss ich sowieso vom iPhone twittern ;)",
  "id" : 1437245830,
  "in_reply_to_status_id" : 1437238095,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "aportmann",
  "in_reply_to_user_id_str" : "5654742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1\uD83C\uDD5B\uD83C\uDD50\uD83C\uDD61\uD83C\uDD62\u26A1",
      "screen_name" : "Lars",
      "indices" : [ 0, 5 ],
      "id_str" : "29044240",
      "id" : 29044240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437249596",
  "geo" : { },
  "id_str" : "1437256078",
  "in_reply_to_user_id" : 6338182,
  "text" : "@lars Bei dem Job vergeht einem der Humor sicherlich recht schnell oder? #rp09",
  "id" : 1437256078,
  "in_reply_to_status_id" : 1437249596,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437276404",
  "geo" : { },
  "id_str" : "1437290026",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu das gibt es schon l\u00E4nger zumindest f\u00FCr Updates pro Tag. Limit 2500\/Tag glaube ich. Das Wiki hilft.",
  "id" : 1437290026,
  "in_reply_to_status_id" : 1437276404,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EventBox",
      "screen_name" : "eventbox",
      "indices" : [ 3, 12 ],
      "id_str" : "17113787",
      "id" : 17113787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437397064",
  "text" : "Go @eventbox Go!",
  "id" : 1437397064,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437475108",
  "geo" : { },
  "id_str" : "1437493399",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Gibt es so glaube ich nicht. Wild rumlaufen und Leute begrabbeln ist angesagt!",
  "id" : 1437493399,
  "in_reply_to_status_id" : 1437475108,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437523976",
  "text" : "Wer hier hat den Lust so um 1300 mit mir essen zu gehen? #rp09",
  "id" : 1437523976,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437540466",
  "geo" : { },
  "id_str" : "1437549395",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g wollte ich eigentlich nicht, au\u00DFer du bist pl\u00F6tzlich weiblich und attraktiv ;)",
  "id" : 1437549395,
  "in_reply_to_status_id" : 1437540466,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437553589",
  "geo" : { },
  "id_str" : "1437573418",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Los, Foto vom Shirt :)",
  "id" : 1437573418,
  "in_reply_to_status_id" : 1437553589,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437575662",
  "text" : "@rajue Wir sind in Berlin. Also D\u00F6ner :)",
  "id" : 1437575662,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437573872",
  "geo" : { },
  "id_str" : "1437578331",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g Da hab ich noch gar keine Idee. Deshalb such ich ja :)",
  "id" : 1437578331,
  "in_reply_to_status_id" : 1437573872,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437595043",
  "geo" : { },
  "id_str" : "1437598074",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Den Spruch solltest du meine Freundin nicht lesen lassen. ;)",
  "id" : 1437598074,
  "in_reply_to_status_id" : 1437595043,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit van Aaken",
      "screen_name" : "gerritvanaaken",
      "indices" : [ 3, 18 ],
      "id_str" : "1002981",
      "id" : 1002981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437609593",
  "text" : "RT @gerritvanaaken: Kinderprostitution in second life? Das ist soooo 2007! #rp09",
  "id" : 1437609593,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1437608873",
  "geo" : { },
  "id_str" : "1437622759",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod da liegst du in der Tat falsch. :)",
  "id" : 1437622759,
  "in_reply_to_status_id" : 1437608873,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437793367",
  "text" : "Mittag - Photo: http:\/\/bkite.com\/066ld",
  "id" : 1437793367,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1437996624",
  "text" : "Und wer will noch was \u00FCber Afrika h\u00F6ren? #rp09",
  "id" : 1437996624,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1439014171",
  "geo" : { },
  "id_str" : "1439052625",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju verdammt, re:turn to castle Wolfenstein w\u00E4re noch cooler als mein fre:edom gewesen.",
  "id" : 1439052625,
  "in_reply_to_status_id" : 1439014171,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1439286334",
  "geo" : { },
  "id_str" : "1439455577",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat geile Scheisse! Sehr cool!",
  "id" : 1439455577,
  "in_reply_to_status_id" : 1439286334,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 3, 9 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterlesung",
      "indices" : [ 68, 82 ]
    }, {
      "text" : "rp09",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1440235007",
  "text" : "RT @rajue: Wir kommen 15 Minuten sp\u00E4ter, bitte noch nicht anfangen! #twitterlesung #rp09",
  "id" : 1440235007,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1440385077",
  "text" : "Jetzt lecker mit Mate der Twitterlesung lauschen. #rp09",
  "id" : 1440385077,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1440459679",
  "text" : "Sind eigentlich die verlorenen Mitfrittierer wieder aufgetaucht? #rp09",
  "id" : 1440459679,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1440545408",
  "text" : "Vor lauter #rp09 und Twitter fast den Geburtstag der Mama verpasst. iPhone ich danke dir.",
  "id" : 1440545408,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1441727335",
  "text" : "Ohne GoogleMaps auf dem fuckin' Handy w\u00E4re ich nicht in meinen Schlafplatz gekommen! - http:\/\/bkite.com\/067lZ",
  "id" : 1441727335,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1441787534",
  "text" : "Gerade mal den Poken leergemacht und nun ins Bett. Morgen will Ding aber an noch mehr Leuten rumreiben!",
  "id" : 1441787534,
  "created_at" : "2009-04-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1432358813",
  "geo" : { },
  "id_str" : "1432372866",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry N\u00F6, aber auch nicht drauf geachtet. Ich hab meinen ja. M\u00FCssen dann bald mal knuddeln.",
  "id" : 1432372866,
  "in_reply_to_status_id" : 1432358813,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1432418729",
  "geo" : { },
  "id_str" : "1432426622",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry also ich hab heut schon ein paar Leute gepoked. Es gibt die Leute mit also.",
  "id" : 1432426622,
  "in_reply_to_status_id" : 1432418729,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1432770224",
  "geo" : { },
  "id_str" : "1432881624",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Den wird\u2019s von mir heute nicht geben, daf\u00FCr bin ich jetzt zu m\u00FCde :)",
  "id" : 1432881624,
  "in_reply_to_status_id" : 1432770224,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1432887575",
  "geo" : { },
  "id_str" : "1432903199",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Hab daf\u00FCr in einer Pause angefangen einen Blogbeitrag f\u00FCr mein Wissenschaftsblog zu schreiben. ;)",
  "id" : 1432903199,
  "in_reply_to_status_id" : 1432887575,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1433019395",
  "text" : "Na gut, hab doch noch fix ein wenig \u00FCber die re:publica geschrieben bevor ich umfalle: http:\/\/is.gd\/q8oM Bis morgen alle #rp09 Besucher.",
  "id" : 1433019395,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1433042512",
  "text" : "Oh, die Kamera ist noch gar nicht auf Sommerzeit eingestellt.",
  "id" : 1433042512,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cspannagel",
      "screen_name" : "cspannagel",
      "indices" : [ 0, 11 ],
      "id_str" : "578512158",
      "id" : 578512158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1433095234",
  "text" : "@cspannagel ne in der Kamera verwirrt mich das sonst zu sehr. Passt dann in Lightroom alles nicht mehr.",
  "id" : 1433095234,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1428986626",
  "text" : "Damn, guten Morgen! Schon gepackt und frisch gemacht f\u00FCr die #rp09. Jetzt noch ne Zigarette fr\u00FChst\u00FCcken und dann geht\u2019s gleich los.",
  "id" : 1428986626,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1429892731",
  "text" : "Ankunft in Berlin: Grob 11 Uhr.",
  "id" : 1429892731,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1429959024",
  "text" : "Was ist eigentlich das beste Ticket f\u00FCr U\/S-Bahn f\u00FCr die #rp09 Zeit?",
  "id" : 1429959024,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1430291482",
  "text" : "@rajue um dich zu finden also nach jemanden Ausschau halten der andere mit B\u00E4llen bedroht?",
  "id" : 1430291482,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1430429099",
  "text" : "Schlage mich mit Ubahn und Fahrinfo zur re:publica durch. Sollte gleich da sein.",
  "id" : 1430429099,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1430433222",
  "geo" : { },
  "id_str" : "1430499660",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g danke Hans gefunden. ;)",
  "id" : 1430499660,
  "in_reply_to_status_id" : 1430433222,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1430515825",
  "text" : "Ganz offensichtlich den falschen Eingang erwischt. Sehe Sitzpl\u00E4tze nur in weiter Ferne.",
  "id" : 1430515825,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1430633617",
  "text" : "Zigarettenpause!",
  "id" : 1430633617,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1430768680",
  "geo" : { },
  "id_str" : "1430792305",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca hier! Sitze drau\u00DFen mit Hut",
  "id" : 1430792305,
  "in_reply_to_status_id" : 1430768680,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1430956445",
  "geo" : { },
  "id_str" : "1431019554",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Hier ist ein Leser der sich gerade das Open Moon-Projekt anh\u00F6rt. Danach gern!",
  "id" : 1431019554,
  "in_reply_to_status_id" : 1430956445,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431198218",
  "text" : "Hallo Mama, ich bin im Fernsehen! #rp09",
  "id" : 1431198218,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431291467",
  "text" : "Was kann Zeitung was Web nicht kann? Hintern abwischen? #rp09",
  "id" : 1431291467,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431402486",
  "text" : "Jetzt ist die Twitterwall nicht nur zu klein sondern auch zu schnell. Irgendwas zu meckern muss es geben. #rp09",
  "id" : 1431402486,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 0, 7 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1431426205",
  "geo" : { },
  "id_str" : "1431441190",
  "in_reply_to_user_id" : 2284151,
  "text" : "@343max Super Idee. Also beides.",
  "id" : 1431441190,
  "in_reply_to_status_id" : 1431426205,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "343max",
  "in_reply_to_user_id_str" : "2284151",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1431466201",
  "geo" : { },
  "id_str" : "1431492458",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Also meine Option ist jetzt drau\u00DFen eine zu rauchen.",
  "id" : 1431492458,
  "in_reply_to_status_id" : 1431466201,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1431466201",
  "geo" : { },
  "id_str" : "1431498417",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Bin schon da. Atheistshirt und Hut!",
  "id" : 1431498417,
  "in_reply_to_status_id" : 1431466201,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1431466201",
  "geo" : { },
  "id_str" : "1431617838",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Achja und das mit den DMs geht besser wenn du mir auch folgst, sonst kann ich nicht antworten.",
  "id" : 1431617838,
  "in_reply_to_status_id" : 1431466201,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bueche",
      "screen_name" : "baustein",
      "indices" : [ 19, 28 ],
      "id_str" : "69088180",
      "id" : 69088180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431623108",
  "text" : "Die Botanifons von @baustein finde ich sehr spannend. Leider habe ich keine Pflanzen. Geht das auch mit Tieren?",
  "id" : 1431623108,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431627100",
  "text" : "Jetzt der 4chan-Vortrag. Deshalb bin ich doch eigentlich hier.",
  "id" : 1431627100,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1431688431",
  "text" : "Heiratsantrag auf Twitterwall is shooped! #rp09",
  "id" : 1431688431,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1432354450",
  "text" : "Das Panel hier ist so spannend das neben mir die ersten einschlafen #rp09",
  "id" : 1432354450,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]