Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11418152244801, 8.750198364944868 ]
  },
  "id_str" : "528292121955278848",
  "text" : "\u00ABIch fand das gestern Abend sehr sch\u00F6n. Wollen wir das jetzt monatlich machen? Ein Trennungsgespr\u00E4ch f\u00FChren und dann nicht trennen?\u00BB",
  "id" : 528292121955278848,
  "created_at" : "2014-10-31 21:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/mrr4te3a8B",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1753-6561\/8\/S2\/S8",
      "display_url" : "biomedcentral.com\/1753-6561\/8\/S2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11521861138061, 8.75038138063886 ]
  },
  "id_str" : "528287169677631488",
  "text" : "Sequence Bundles seem to be a cool way to visualize conservation on the AA level http:\/\/t.co\/mrr4te3a8B",
  "id" : 528287169677631488,
  "created_at" : "2014-10-31 20:47:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hover",
      "screen_name" : "hover",
      "indices" : [ 3, 9 ],
      "id_str" : "15399101",
      "id" : 15399101
    }, {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 11, 21 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528278505151533056",
  "text" : "RT @hover: @romanmars New challenge: If Roman Mars can eat 20,000 fruit flavored Tootsie Rolls then we'll donate 25,000 more for him to eat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roman Mars",
        "screen_name" : "romanmars",
        "indices" : [ 0, 10 ],
        "id_str" : "8198012",
        "id" : 8198012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "528239688511811584",
    "geo" : { },
    "id_str" : "528241664507133952",
    "in_reply_to_user_id" : 8198012,
    "text" : "@romanmars New challenge: If Roman Mars can eat 20,000 fruit flavored Tootsie Rolls then we'll donate 25,000 more for him to eat.",
    "id" : 528241664507133952,
    "in_reply_to_status_id" : 528239688511811584,
    "created_at" : "2014-10-31 17:46:41 +0000",
    "in_reply_to_screen_name" : "romanmars",
    "in_reply_to_user_id_str" : "8198012",
    "user" : {
      "name" : "Hover",
      "screen_name" : "hover",
      "protected" : false,
      "id_str" : "15399101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893119004184723456\/j3C19SvC_normal.jpg",
      "id" : 15399101,
      "verified" : true
    }
  },
  "id" : 528278505151533056,
  "created_at" : "2014-10-31 20:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 0, 9 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528261575388712960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599048356, 8.759447298374823 ]
  },
  "id_str" : "528261713142218752",
  "in_reply_to_user_id" : 42414621,
  "text" : "@DHLPaket solltet ihr schon haben ;)",
  "id" : 528261713142218752,
  "in_reply_to_status_id" : 528261575388712960,
  "created_at" : "2014-10-31 19:06:21 +0000",
  "in_reply_to_screen_name" : "DHLPaket",
  "in_reply_to_user_id_str" : "42414621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 0, 9 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528225524943192064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11418151859807, 8.750198364265469 ]
  },
  "id_str" : "528225748285657089",
  "in_reply_to_user_id" : 42414621,
  "text" : "@DHLPaket in einer von 2 Filialen. Gibt es irgendjemanden der das in Erfahrung bringen kann oder muss ich raten?",
  "id" : 528225748285657089,
  "in_reply_to_status_id" : 528225524943192064,
  "created_at" : "2014-10-31 16:43:27 +0000",
  "in_reply_to_screen_name" : "DHLPaket",
  "in_reply_to_user_id_str" : "42414621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/o3GlRbliYQ",
      "expanded_url" : "http:\/\/f1000.com\/posters\/browse\/summary\/1097136",
      "display_url" : "f1000.com\/posters\/browse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528213576834875392",
  "text" : "Ten simple rules for a bioinformatics journal club http:\/\/t.co\/o3GlRbliYQ",
  "id" : 528213576834875392,
  "created_at" : "2014-10-31 15:55:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 50, 59 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528208955382960129",
  "geo" : { },
  "id_str" : "528211783174324224",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb genauso faszinierend wie der Umstand das @DHLPaket sich dazu bedeckt h\u00E4lt\u2026",
  "id" : 528211783174324224,
  "in_reply_to_status_id" : 528208955382960129,
  "created_at" : "2014-10-31 15:47:57 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 81, 87 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xxq9NY2adJ",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/food-matters\/2014\/10\/31\/evil-spirit-the-lore-and-lure-of-absinthe\/",
      "display_url" : "blogs.scientificamerican.com\/food-matters\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528209447492284416",
  "text" : "Dank Zeilenumbruch gelesen: \u00ABEvil Spirit? The Lore\u00BB Darauf erstmal einen Absinth @Lobot http:\/\/t.co\/xxq9NY2adJ",
  "id" : 528209447492284416,
  "created_at" : "2014-10-31 15:38:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 9, 18 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/gMv6lLutah",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/528198873702223872",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "528203944661897217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966645536891, 8.28291037345985 ]
  },
  "id_str" : "528207773197430785",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb @DHLPaket gleichzeitig an der gleichen Adresse: https:\/\/t.co\/gMv6lLutah",
  "id" : 528207773197430785,
  "in_reply_to_status_id" : 528203944661897217,
  "created_at" : "2014-10-31 15:32:01 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528202277858050048",
  "text" : "\u00ABWir sind eine sehr kompetitive Arbeitsgruppe.\u00BB \u2013 \u00ABJa, wir betreiben hier P\u00F6belationsgenomik!\u00BB",
  "id" : 528202277858050048,
  "created_at" : "2014-10-31 15:10:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 0, 9 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528198873702223872",
  "in_reply_to_user_id" : 42414621,
  "text" : "@DHLPaket Sendung JJD000390000781811712 ist in einer Filiale gelandet, habe aber keine Benachrichtigung bekommen. Welche Filiale ist es?",
  "id" : 528198873702223872,
  "created_at" : "2014-10-31 14:56:39 +0000",
  "in_reply_to_screen_name" : "DHLPaket",
  "in_reply_to_user_id_str" : "42414621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/XiVDZFYRkE",
      "expanded_url" : "http:\/\/instagram.com\/p\/u0eioeBwnl\/",
      "display_url" : "instagram.com\/p\/u0eioeBwnl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "528189283669008385",
  "text" : "Little Fritz http:\/\/t.co\/XiVDZFYRkE",
  "id" : 528189283669008385,
  "created_at" : "2014-10-31 14:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11671238100315, 8.65163077998585 ]
  },
  "id_str" : "528159494778281985",
  "text" : "\u00ABI can\u2019t seem to find the raw reads. But we could always just simulate some from the assembly.\u00BB",
  "id" : 528159494778281985,
  "created_at" : "2014-10-31 12:20:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527955709754109952",
  "text" : "RT @mrgunn: \"Most scientists believe that it is career suicide not to chase the glam publication. Most scientists are wrong.\" http:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/wYvJayJDId",
        "expanded_url" : "http:\/\/www.thespectroscope.com\/read\/its-not-publish-or-perish-but-rather-do-great-science-by-lenny-teytelman-258",
        "display_url" : "thespectroscope.com\/read\/its-not-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527932467726938113",
    "text" : "\"Most scientists believe that it is career suicide not to chase the glam publication. Most scientists are wrong.\" http:\/\/t.co\/wYvJayJDId",
    "id" : 527932467726938113,
    "created_at" : "2014-10-30 21:18:03 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 527955709754109952,
  "created_at" : "2014-10-30 22:50:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11367662348795, 8.753072703265355 ]
  },
  "id_str" : "527930145915801600",
  "text" : "\u00ABI don\u2019t agree without knowing in which kind of trouble it\u2019ll get me into. Learned that the hard way.\u00BB \u2014 \u00ABIt won\u2019t require invading Poland\u2026\u00BB",
  "id" : 527930145915801600,
  "created_at" : "2014-10-30 21:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/jt329GzqOc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Kppx4bzfAaE",
      "display_url" : "youtube.com\/watch?v=Kppx4b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527896690570067968",
  "text" : "Rappin\u2019 for Jesus. I guess they were inspired by Patti Smith https:\/\/t.co\/jt329GzqOc",
  "id" : 527896690570067968,
  "created_at" : "2014-10-30 18:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/arBfF8GAkm",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/30\/the-joy-of-fix-fixing-and-mak.html",
      "display_url" : "boingboing.net\/2014\/10\/30\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527795873108230144",
  "text" : "The Joy of Fix http:\/\/t.co\/arBfF8GAkm",
  "id" : 527795873108230144,
  "created_at" : "2014-10-30 12:15:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527777226193137664",
  "text" : "Today my students learned: spending an hour on bug fixing. Only to then learn that the problem is that the HDDs ran out of space\u2026",
  "id" : 527777226193137664,
  "created_at" : "2014-10-30 11:01:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Rej7Nes4dy",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/28\/every-artists-how-i-made-i.html",
      "display_url" : "boingboing.net\/2014\/10\/28\/eve\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11751993563968, 8.732020547621634 ]
  },
  "id_str" : "527720722425454592",
  "text" : "Every artist\u2019s \u201Chow I made it\u201D talk, ever http:\/\/t.co\/Rej7Nes4dy",
  "id" : 527720722425454592,
  "created_at" : "2014-10-30 07:16:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527562292406542336",
  "text" : "RT @DanGraur: How to lie with statistics? Much better! How to pretend not to lie with statistics &amp; yet lie with statistics. https:\/\/t.co\/7F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7FH3FSRwo4",
        "expanded_url" : "https:\/\/plus.google.com\/103530621949492999968\/posts\/UzMMmPgyyaV",
        "display_url" : "plus.google.com\/10353062194949\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527558560969162753",
    "text" : "How to lie with statistics? Much better! How to pretend not to lie with statistics &amp; yet lie with statistics. https:\/\/t.co\/7FH3FSRwo4",
    "id" : 527558560969162753,
    "created_at" : "2014-10-29 20:32:17 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 527562292406542336,
  "created_at" : "2014-10-29 20:47:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527510656611012608",
  "text" : "\u00ABMoment, die werben damit frei von Gluten und Gelatine zu sein aber benutzen gleichzeitig Farbstoffe die ein Xn-Label tragen m\u00FCssen?\u00BB",
  "id" : 527510656611012608,
  "created_at" : "2014-10-29 17:21:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527503461492215808",
  "text" : "\u00ABIch wusste nicht das man sich bei der Uni bewerben kann sondern hab das Losverfahren genutzt. In 5 von 7 F\u00E4chern wurde ich sogar gezogen.\u00BB",
  "id" : 527503461492215808,
  "created_at" : "2014-10-29 16:53:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527435560177377280",
  "text" : "\u00ABBtw: you will teach tomorrow.\u00BB\u2013\u00ABI do?!\u00BB\u2013\u00ABWell, I only heard that \u2018someone\u2019 of the group would and figured you are always that \u2018someone\u2019.\u00BB",
  "id" : 527435560177377280,
  "created_at" : "2014-10-29 12:23:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/VIWtiut4on",
      "expanded_url" : "http:\/\/instagram.com\/p\/uvGC5SBwhr\/",
      "display_url" : "instagram.com\/p\/uvGC5SBwhr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "527431728344731648",
  "text" : "Baustellenhumor http:\/\/t.co\/VIWtiut4on",
  "id" : 527431728344731648,
  "created_at" : "2014-10-29 12:08:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527390107037614080",
  "text" : "\u00ABOrr, LaTeX. Da ist man ja froh wenn einem die Augen zuschwellen. Dan muss man das Elend wenigstens nicht mehr sehen.\u00BB",
  "id" : 527390107037614080,
  "created_at" : "2014-10-29 09:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/FlCwpFywfi",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/10\/29\/no-one-quite-sure-what-the-point-is-anymore-survey-finds\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/10\/29\/no-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527388864936423424",
  "text" : "\u201CI thought the PI knew why we did it\u201D http:\/\/t.co\/FlCwpFywfi",
  "id" : 527388864936423424,
  "created_at" : "2014-10-29 09:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Future Tense",
      "screen_name" : "FutureTenseNow",
      "indices" : [ 120, 135 ],
      "id_str" : "326184086",
      "id" : 326184086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/NVKfnFCYrl",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2014\/10\/28\/google_has_a_patent_for_google_doodles_salk_didn_t_patent_the_polio_vaccine.html?wpsrc=sh_all_tab_tw_top",
      "display_url" : "slate.com\/blogs\/future_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527226535896698882",
  "text" : "RT @EffyVayena: Today\u2019s Google Doodle About Jonas Salk Is Patented. The Polio Vaccine Isn\u2019t. http:\/\/t.co\/NVKfnFCYrl via @FutureTenseNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Future Tense",
        "screen_name" : "FutureTenseNow",
        "indices" : [ 104, 119 ],
        "id_str" : "326184086",
        "id" : 326184086
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/NVKfnFCYrl",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2014\/10\/28\/google_has_a_patent_for_google_doodles_salk_didn_t_patent_the_polio_vaccine.html?wpsrc=sh_all_tab_tw_top",
        "display_url" : "slate.com\/blogs\/future_t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527223838950453250",
    "text" : "Today\u2019s Google Doodle About Jonas Salk Is Patented. The Polio Vaccine Isn\u2019t. http:\/\/t.co\/NVKfnFCYrl via @FutureTenseNow",
    "id" : 527223838950453250,
    "created_at" : "2014-10-28 22:22:13 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 527226535896698882,
  "created_at" : "2014-10-28 22:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/xhLTj4dNyY",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/a0Xa7DN_rMA\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527225062525784064",
  "text" : "Poor George Price http:\/\/t.co\/xhLTj4dNyY",
  "id" : 527225062525784064,
  "created_at" : "2014-10-28 22:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/8svzmi8cQm",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/52",
      "display_url" : "existentialcomics.com\/comic\/52"
    } ]
  },
  "geo" : { },
  "id_str" : "527224525587755008",
  "text" : "Radical Freedom! http:\/\/t.co\/8svzmi8cQm",
  "id" : 527224525587755008,
  "created_at" : "2014-10-28 22:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/t1XGX50s0S",
      "expanded_url" : "http:\/\/timotheepoisot.fr\/2014\/09\/30\/busy-no-myth\/",
      "display_url" : "timotheepoisot.fr\/2014\/09\/30\/bus\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096664927, 8.2829104525 ]
  },
  "id_str" : "527170067562528768",
  "text" : "\u00ABBusy is no myth, busy is a statistical effect\u00BB http:\/\/t.co\/t1XGX50s0S",
  "id" : 527170067562528768,
  "created_at" : "2014-10-28 18:48:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527078499224657920",
  "geo" : { },
  "id_str" : "527079087224156161",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke too bad that the saying isn\u2019t about being on the same sheet!",
  "id" : 527079087224156161,
  "in_reply_to_status_id" : 527078499224657920,
  "created_at" : "2014-10-28 12:47:01 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527067358683488256",
  "geo" : { },
  "id_str" : "527072301792395264",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke it\u2019s always wise to pick your fights ;)",
  "id" : 527072301792395264,
  "in_reply_to_status_id" : 527067358683488256,
  "created_at" : "2014-10-28 12:20:03 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527066747606937601",
  "geo" : { },
  "id_str" : "527067049886244864",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke I refute the \u201Cnow\u201D.",
  "id" : 527067049886244864,
  "in_reply_to_status_id" : 527066747606937601,
  "created_at" : "2014-10-28 11:59:11 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/wp0pAzqPjN",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3525",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527066493427937280",
  "text" : "On Virginity http:\/\/t.co\/wp0pAzqPjN",
  "id" : 527066493427937280,
  "created_at" : "2014-10-28 11:56:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527066043744006145",
  "geo" : { },
  "id_str" : "527066311411908608",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke I see what you did there ;)",
  "id" : 527066311411908608,
  "in_reply_to_status_id" : 527066043744006145,
  "created_at" : "2014-10-28 11:56:15 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527065578734092288",
  "geo" : { },
  "id_str" : "527065717414584320",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke I\u2019m so glad I can count on your dirty mindedness!",
  "id" : 527065717414584320,
  "in_reply_to_status_id" : 527065578734092288,
  "created_at" : "2014-10-28 11:53:54 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/5OMyjpJ2pi",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/27\/how-to-make-vibrating-alarm-cl.html",
      "display_url" : "boingboing.net\/2014\/10\/27\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527065494869004288",
  "text" : "Not sure if that would help me get up: How to make vibrating alarm clock\u00A0underwear http:\/\/t.co\/5OMyjpJ2pi",
  "id" : 527065494869004288,
  "created_at" : "2014-10-28 11:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527020545607757824",
  "text" : "my main task for today: keeping an eye on the memory usage graphs of our cluster\u2026",
  "id" : 527020545607757824,
  "created_at" : "2014-10-28 08:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/5LlJDql0mG",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-3B",
      "display_url" : "wp.me\/p4ik2k-3B"
    } ]
  },
  "geo" : { },
  "id_str" : "526829962188558336",
  "text" : "RT @TheScienceWeb: NIH announces all funding decisions to be made by someone who hates you http:\/\/t.co\/5LlJDql0mG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/5LlJDql0mG",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-3B",
        "display_url" : "wp.me\/p4ik2k-3B"
      } ]
    },
    "geo" : { },
    "id_str" : "526816543611445249",
    "text" : "NIH announces all funding decisions to be made by someone who hates you http:\/\/t.co\/5LlJDql0mG",
    "id" : 526816543611445249,
    "created_at" : "2014-10-27 19:23:46 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 526829962188558336,
  "created_at" : "2014-10-27 20:17:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan White",
      "screen_name" : "ethanwhite",
      "indices" : [ 3, 14 ],
      "id_str" : "34540379",
      "id" : 34540379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/sxEQmKLd5o",
      "expanded_url" : "http:\/\/dynamicecology.wordpress.com\/2014\/10\/27\/non-academic-careers-for-ecologists-data-science-guest-post\/",
      "display_url" : "dynamicecology.wordpress.com\/2014\/10\/27\/non\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526785835132551168",
  "text" : "RT @ethanwhite: \"A PhD in ecology or evolution is good preparation for a career in data science.\" http:\/\/t.co\/sxEQmKLd5o Great post by @Dis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Hart",
        "screen_name" : "distribecology",
        "indices" : [ 119, 134 ],
        "id_str" : "2898107700",
        "id" : 2898107700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/sxEQmKLd5o",
        "expanded_url" : "http:\/\/dynamicecology.wordpress.com\/2014\/10\/27\/non-academic-careers-for-ecologists-data-science-guest-post\/",
        "display_url" : "dynamicecology.wordpress.com\/2014\/10\/27\/non\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526785204929564673",
    "text" : "\"A PhD in ecology or evolution is good preparation for a career in data science.\" http:\/\/t.co\/sxEQmKLd5o Great post by @DistribEcology!",
    "id" : 526785204929564673,
    "created_at" : "2014-10-27 17:19:14 +0000",
    "user" : {
      "name" : "Ethan White",
      "screen_name" : "ethanwhite",
      "protected" : false,
      "id_str" : "34540379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875364025005096961\/8_fgpYGC_normal.jpg",
      "id" : 34540379,
      "verified" : false
    }
  },
  "id" : 526785835132551168,
  "created_at" : "2014-10-27 17:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526773714336358400",
  "geo" : { },
  "id_str" : "526774086039781376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let\u2019s see what happens, trying it now :D",
  "id" : 526774086039781376,
  "in_reply_to_status_id" : 526773714336358400,
  "created_at" : "2014-10-27 16:35:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526773280586620928",
  "geo" : { },
  "id_str" : "526773589715206144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch otherwise it won\u2019t allow me to open a shell.",
  "id" : 526773589715206144,
  "in_reply_to_status_id" : 526773280586620928,
  "created_at" : "2014-10-27 16:33:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526773280586620928",
  "geo" : { },
  "id_str" : "526773516600086528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch btw: can I run bundle install w\/o problem for the \/current thingy so that pg_search will be installed?",
  "id" : 526773516600086528,
  "in_reply_to_status_id" : 526773280586620928,
  "created_at" : "2014-10-27 16:32:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/niTqxtRSei",
      "expanded_url" : "http:\/\/www.wellcomecollection.org\/exhibitions\/institute-sexology",
      "display_url" : "wellcomecollection.org\/exhibitions\/in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526757442617876480",
  "text" : "I think I will have to visit the Wellcome Collection some time next year, to see \u00ABThe Institute of Sexology\u00BB exhibit http:\/\/t.co\/niTqxtRSei",
  "id" : 526757442617876480,
  "created_at" : "2014-10-27 15:28:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526727925799063553",
  "geo" : { },
  "id_str" : "526728295703134208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer 14 mio 250bp read pairs, ~14 GB for the fastqs. depending on k-size our 192 GB machines are just a couple of GB too small\u2026",
  "id" : 526728295703134208,
  "in_reply_to_status_id" : 526727925799063553,
  "created_at" : "2014-10-27 13:33:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526727689378754560",
  "geo" : { },
  "id_str" : "526727862515412992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I have, but that would fuck up the assembler comparisons I want to do.",
  "id" : 526727862515412992,
  "in_reply_to_status_id" : 526727689378754560,
  "created_at" : "2014-10-27 13:31:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526727303402094593",
  "geo" : { },
  "id_str" : "526727510214860800",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer do you know how full the queue is? i.e. how long would the wait probably be?",
  "id" : 526727510214860800,
  "in_reply_to_status_id" : 526727303402094593,
  "created_at" : "2014-10-27 13:29:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526726557004726273",
  "geo" : { },
  "id_str" : "526727031212769280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the 3 1TB nodes look up for the job, should actually be able to run 2 of my velvet jobs in parallel ;)",
  "id" : 526727031212769280,
  "in_reply_to_status_id" : 526726557004726273,
  "created_at" : "2014-10-27 13:28:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526726120658731008",
  "geo" : { },
  "id_str" : "526726157497282560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer each :3",
  "id" : 526726157497282560,
  "in_reply_to_status_id" : 526726120658731008,
  "created_at" : "2014-10-27 13:24:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526725681871618048",
  "geo" : { },
  "id_str" : "526725903846764544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. you don\u2019t happen to have access to ~10 nodes w\/ 256+ GB memory that are free right now, do you? :D",
  "id" : 526725903846764544,
  "in_reply_to_status_id" : 526725681871618048,
  "created_at" : "2014-10-27 13:23:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526725681871618048",
  "geo" : { },
  "id_str" : "526725720283049984",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks :)",
  "id" : 526725720283049984,
  "in_reply_to_status_id" : 526725681871618048,
  "created_at" : "2014-10-27 13:22:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saga",
      "screen_name" : "naja_xaoticca",
      "indices" : [ 0, 14 ],
      "id_str" : "20141686",
      "id" : 20141686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526707632363827202",
  "geo" : { },
  "id_str" : "526721782846615552",
  "in_reply_to_user_id" : 20141686,
  "text" : "@naja_xaoticca ja, derjenige der sich unsicher war hat dann auch lieber ganz verzichtet. ;-)",
  "id" : 526721782846615552,
  "in_reply_to_status_id" : 526707632363827202,
  "created_at" : "2014-10-27 13:07:13 +0000",
  "in_reply_to_screen_name" : "naja_xaoticca",
  "in_reply_to_user_id_str" : "20141686",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526697955815075840",
  "geo" : { },
  "id_str" : "526699711437496321",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot von Team Random Walk zu Team Funny Walks mit nur einem Einlauf?",
  "id" : 526699711437496321,
  "in_reply_to_status_id" : 526697955815075840,
  "created_at" : "2014-10-27 11:39:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723237604, 8.6275129939 ]
  },
  "id_str" : "526696645988462592",
  "text" : "\u00ABIch wollte gestern ja was von dem Powergel nehmen. Aber dann war ich mir nicht sicher ob man das schluckt oder auf die Beine schmiert.\u00BB",
  "id" : 526696645988462592,
  "created_at" : "2014-10-27 11:27:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138283927, 8.7527107988 ]
  },
  "id_str" : "526635794212352000",
  "text" : "\u00ABBad plumbing really brings out my eyes\u00BB \u2014 \u00ABSo beautiful. As brown as the dirt behind the wall tiling!\u00BB",
  "id" : 526635794212352000,
  "created_at" : "2014-10-27 07:25:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visit Avebury",
      "screen_name" : "VisitAvebury",
      "indices" : [ 3, 16 ],
      "id_str" : "605709381",
      "id" : 605709381
    }, {
      "name" : "Avebury NT",
      "screen_name" : "AveburyNT",
      "indices" : [ 115, 125 ],
      "id_str" : "199345856",
      "id" : 199345856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526629981661962241",
  "text" : "RT @VisitAvebury: Putting the clock back at Avebury Stone Circle: Repositioning the stones for British Summer Time @AveburyNT http:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Avebury NT",
        "screen_name" : "AveburyNT",
        "indices" : [ 97, 107 ],
        "id_str" : "199345856",
        "id" : 199345856
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VisitAvebury\/status\/526021009661784064\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/mSLFPq3eUj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0zNUT1CMAIRI-m.jpg",
        "id_str" : "526021005299298306",
        "id" : 526021005299298306,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0zNUT1CMAIRI-m.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mSLFPq3eUj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526021009661784064",
    "text" : "Putting the clock back at Avebury Stone Circle: Repositioning the stones for British Summer Time @AveburyNT http:\/\/t.co\/mSLFPq3eUj",
    "id" : 526021009661784064,
    "created_at" : "2014-10-25 14:42:36 +0000",
    "user" : {
      "name" : "Visit Avebury",
      "screen_name" : "VisitAvebury",
      "protected" : false,
      "id_str" : "605709381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2299447093\/ghx55iiduxiz8i5ad7aa_normal.jpeg",
      "id" : 605709381,
      "verified" : false
    }
  },
  "id" : 526629981661962241,
  "created_at" : "2014-10-27 07:02:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodrigo Esparza",
      "screen_name" : "RodrigoEsparza",
      "indices" : [ 3, 18 ],
      "id_str" : "2887589716",
      "id" : 2887589716
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RodrigoEsparza\/status\/526378241599496192\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Pe6zar2qDR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B04SOF4CYAEBqyF.jpg",
      "id_str" : "526378239753609217",
      "id" : 526378239753609217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B04SOF4CYAEBqyF.jpg",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Pe6zar2qDR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526460334648070145",
  "text" : "RT @RodrigoEsparza: What do most people think science is about. http:\/\/t.co\/Pe6zar2qDR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RodrigoEsparza\/status\/526378241599496192\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Pe6zar2qDR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B04SOF4CYAEBqyF.jpg",
        "id_str" : "526378239753609217",
        "id" : 526378239753609217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B04SOF4CYAEBqyF.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Pe6zar2qDR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526378241599496192",
    "text" : "What do most people think science is about. http:\/\/t.co\/Pe6zar2qDR",
    "id" : 526378241599496192,
    "created_at" : "2014-10-26 14:22:07 +0000",
    "user" : {
      "name" : "Rod",
      "screen_name" : "DonRorro",
      "protected" : false,
      "id_str" : "76193310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642615649047412736\/Mp7E03bx_normal.png",
      "id" : 76193310,
      "verified" : false
    }
  },
  "id" : 526460334648070145,
  "created_at" : "2014-10-26 19:48:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/QZG0Id4fSp",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=9IhgwCB14To",
      "display_url" : "m.youtube.com\/watch?v=9IhgwC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526450214811750400",
  "text" : "If Buying Condoms Was Like Buying Birth Control https:\/\/t.co\/QZG0Id4fSp",
  "id" : 526450214811750400,
  "created_at" : "2014-10-26 19:08:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/UnlwX45Hwq",
      "expanded_url" : "http:\/\/live.bmw-frankfurt-marathon.com\/2014\/?content=detail&fpid=search&pid=search&idp=9999990AEF466A00005946C1&lang=EN&event=STA",
      "display_url" : "live.bmw-frankfurt-marathon.com\/2014\/?content=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526431200760836096",
  "text" : "This year our relay marathon team actually finished \\o\/ http:\/\/t.co\/UnlwX45Hwq",
  "id" : 526431200760836096,
  "created_at" : "2014-10-26 17:52:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "swardley",
      "screen_name" : "swardley",
      "indices" : [ 3, 12 ],
      "id_str" : "8592732",
      "id" : 8592732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/swardley\/status\/526074463175966720\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/sigX2000EF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0z976CCAAAZqC8.jpg",
      "id_str" : "526074462127390720",
      "id" : 526074462127390720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0z976CCAAAZqC8.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 631
      } ],
      "display_url" : "pic.twitter.com\/sigX2000EF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526312975154819072",
  "text" : "RT @swardley: Everything you need to know about Knowledge and Expertise in one handy graph http:\/\/t.co\/sigX2000EF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/swardley\/status\/526074463175966720\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/sigX2000EF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0z976CCAAAZqC8.jpg",
        "id_str" : "526074462127390720",
        "id" : 526074462127390720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0z976CCAAAZqC8.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 631
        } ],
        "display_url" : "pic.twitter.com\/sigX2000EF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526074463175966720",
    "text" : "Everything you need to know about Knowledge and Expertise in one handy graph http:\/\/t.co\/sigX2000EF",
    "id" : 526074463175966720,
    "created_at" : "2014-10-25 18:15:00 +0000",
    "user" : {
      "name" : "swardley",
      "screen_name" : "swardley",
      "protected" : false,
      "id_str" : "8592732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/180727117\/Simon_normal.jpg",
      "id" : 8592732,
      "verified" : false
    }
  },
  "id" : 526312975154819072,
  "created_at" : "2014-10-26 10:02:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526295257051574273",
  "text" : "\u00ABWalk past your pain. Free your souls from the shackles &amp; borders of your bodies\u00BB \u2014 \u00ABI thought we wanted to run, not blow ourselves up!\u00BB",
  "id" : 526295257051574273,
  "created_at" : "2014-10-26 08:52:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/9wX3BlgoNY",
      "expanded_url" : "http:\/\/www.sssscomic.com\/comic.php?page=195",
      "display_url" : "sssscomic.com\/comic.php?page\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113538724, 8.7572125092 ]
  },
  "id_str" : "525971034995163136",
  "text" : "The Nordic Languages http:\/\/t.co\/9wX3BlgoNY",
  "id" : 525971034995163136,
  "created_at" : "2014-10-25 11:24:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525968359897440256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111736071, 8.7558584338 ]
  },
  "id_str" : "525969062724370432",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot ja, \u2018How Politics Destroyed My Love Life. Again.\u2019",
  "id" : 525969062724370432,
  "in_reply_to_status_id" : 525968359897440256,
  "created_at" : "2014-10-25 11:16:11 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 36, 42 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525966971423428608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111736071, 8.7558584338 ]
  },
  "id_str" : "525967338513137664",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ich hab ja immer gesagt das @Lobot eine IM war.",
  "id" : 525967338513137664,
  "in_reply_to_status_id" : 525966971423428608,
  "created_at" : "2014-10-25 11:09:20 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/RGulMFtqqy",
      "expanded_url" : "http:\/\/instagram.com\/p\/ukqknyhwmS\/",
      "display_url" : "instagram.com\/p\/ukqknyhwmS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525963938983575553",
  "text" : "Vorsicht mit den Chatlogs! http:\/\/t.co\/RGulMFtqqy",
  "id" : 525963938983575553,
  "created_at" : "2014-10-25 10:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 61, 74 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 75, 81 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/1wQCW0DbTm",
      "expanded_url" : "http:\/\/m.mentalfloss.com\/article.php?id=59665",
      "display_url" : "m.mentalfloss.com\/article.php?id\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106719971, 8.7596282645 ]
  },
  "id_str" : "525933257331052544",
  "text" : "Feast Your Eyes on This Beautiful Linguistic Family Tree \/cc @PhilippBayer @Lobot http:\/\/t.co\/1wQCW0DbTm",
  "id" : 525933257331052544,
  "created_at" : "2014-10-25 08:53:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106719876, 8.7589503676 ]
  },
  "id_str" : "525757651087810561",
  "text" : "Die Liebe in den Zeiten der Twitter Soap Opera.",
  "id" : 525757651087810561,
  "created_at" : "2014-10-24 21:16:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "olivia pope",
      "screen_name" : "freebsdgirl",
      "indices" : [ 37, 49 ],
      "id_str" : "429470016",
      "id" : 429470016
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CW2046\/status\/525698252063383553\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/7C60aG22Fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0unxYfCUAAZl7t.png",
      "id_str" : "525698248346849280",
      "id" : 525698248346849280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0unxYfCUAAZl7t.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/7C60aG22Fg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525726620909576193",
  "text" : "RT @jcmanous: http:\/\/t.co\/7C60aG22Fg @freebsdgirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "olivia pope",
        "screen_name" : "freebsdgirl",
        "indices" : [ 23, 35 ],
        "id_str" : "429470016",
        "id" : 429470016
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CW2046\/status\/525698252063383553\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/7C60aG22Fg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0unxYfCUAAZl7t.png",
        "id_str" : "525698248346849280",
        "id" : 525698248346849280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0unxYfCUAAZl7t.png",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/7C60aG22Fg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525710150464978944",
    "text" : "http:\/\/t.co\/7C60aG22Fg @freebsdgirl",
    "id" : 525710150464978944,
    "created_at" : "2014-10-24 18:07:21 +0000",
    "user" : {
      "name" : "Jason Manous",
      "screen_name" : "oldstrongguy",
      "protected" : false,
      "id_str" : "35826963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772819177883176960\/JxZ36h3O_normal.jpg",
      "id" : 35826963,
      "verified" : false
    }
  },
  "id" : 525726620909576193,
  "created_at" : "2014-10-24 19:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s\u0254\u1D09s\u028E\u0265dp\u0250q \uD83E\uDD98\u200F\u2067\uD83E\uDD98\u200F",
      "screen_name" : "BadPhysics",
      "indices" : [ 3, 14 ],
      "id_str" : "453294225",
      "id" : 453294225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525725488158097408",
  "text" : "RT @BadPhysics: \"There are more things in your results and conclusions, Horatio, than are within the scope of your experiment.\" #ShakesPeer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakesPeerReview",
        "indices" : [ 112, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525700735045214208",
    "text" : "\"There are more things in your results and conclusions, Horatio, than are within the scope of your experiment.\" #ShakesPeerReview",
    "id" : 525700735045214208,
    "created_at" : "2014-10-24 17:29:56 +0000",
    "user" : {
      "name" : "s\u0254\u1D09s\u028E\u0265dp\u0250q \uD83E\uDD98\u200F\u2067\uD83E\uDD98\u200F",
      "screen_name" : "BadPhysics",
      "protected" : false,
      "id_str" : "453294225",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686457584572706816\/-V52emth_normal.png",
      "id" : 453294225,
      "verified" : false
    }
  },
  "id" : 525725488158097408,
  "created_at" : "2014-10-24 19:08:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/PkwvzsDCq1",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-3z",
      "display_url" : "wp.me\/p4ik2k-3z"
    } ]
  },
  "geo" : { },
  "id_str" : "525657102199832576",
  "text" : "RT @TheScienceWeb: University administrator demands new email emphasis tool http:\/\/t.co\/PkwvzsDCq1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/PkwvzsDCq1",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-3z",
        "display_url" : "wp.me\/p4ik2k-3z"
      } ]
    },
    "geo" : { },
    "id_str" : "525652190702997504",
    "text" : "University administrator demands new email emphasis tool http:\/\/t.co\/PkwvzsDCq1",
    "id" : 525652190702997504,
    "created_at" : "2014-10-24 14:17:03 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 525657102199832576,
  "created_at" : "2014-10-24 14:36:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 0, 12 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525644395023175680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237072, 8.6275294203 ]
  },
  "id_str" : "525646034312364032",
  "in_reply_to_user_id" : 7612412,
  "text" : "@lirontocker even with flags I mix up English, German &amp; \u05E2\u05D1\u05E8\u05D9\u05EA. guess for me it wouldn\u2019t make too much of a diff, but colors in menu bar=ugly",
  "id" : 525646034312364032,
  "in_reply_to_status_id" : 525644395023175680,
  "created_at" : "2014-10-24 13:52:35 +0000",
  "in_reply_to_screen_name" : "lirontocker",
  "in_reply_to_user_id_str" : "7612412",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 0, 12 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525638439342206976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172385079, 8.627559065 ]
  },
  "id_str" : "525644030475255808",
  "in_reply_to_user_id" : 7612412,
  "text" : "@lirontocker \u2018A (de)\u2018",
  "id" : 525644030475255808,
  "in_reply_to_status_id" : 525638439342206976,
  "created_at" : "2014-10-24 13:44:37 +0000",
  "in_reply_to_screen_name" : "lirontocker",
  "in_reply_to_user_id_str" : "7612412",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 0, 12 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525637847349739520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723455772, 8.6275222586 ]
  },
  "id_str" : "525638278117347328",
  "in_reply_to_user_id" : 7612412,
  "text" : "@lirontocker I would rather have an \u201Ea\u201C there ;)",
  "id" : 525638278117347328,
  "in_reply_to_status_id" : 525637847349739520,
  "created_at" : "2014-10-24 13:21:46 +0000",
  "in_reply_to_screen_name" : "lirontocker",
  "in_reply_to_user_id_str" : "7612412",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 0, 12 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525635649576394752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723455772, 8.6275222586 ]
  },
  "id_str" : "525637708627337216",
  "in_reply_to_user_id" : 7612412,
  "text" : "@lirontocker m( and i guess the ugly german flag will still be there?",
  "id" : 525637708627337216,
  "in_reply_to_status_id" : 525635649576394752,
  "created_at" : "2014-10-24 13:19:30 +0000",
  "in_reply_to_screen_name" : "lirontocker",
  "in_reply_to_user_id_str" : "7612412",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 0, 12 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525634863593177088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1824193051, 8.6196736468 ]
  },
  "id_str" : "525635520609923072",
  "in_reply_to_user_id" : 7612412,
  "text" : "@lirontocker what does it show instead?",
  "id" : 525635520609923072,
  "in_reply_to_status_id" : 525634863593177088,
  "created_at" : "2014-10-24 13:10:48 +0000",
  "in_reply_to_screen_name" : "lirontocker",
  "in_reply_to_user_id_str" : "7612412",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/L0PWqWDdud",
      "expanded_url" : "http:\/\/joepickrell.wordpress.com\/2014\/10\/22\/the-burden-of-the-multiple-testing-burden\/",
      "display_url" : "joepickrell.wordpress.com\/2014\/10\/22\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525576958646972416",
  "text" : "The burden of the \"multiple testing burden\" http:\/\/t.co\/L0PWqWDdud \/cc @PhilippBayer",
  "id" : 525576958646972416,
  "created_at" : "2014-10-24 09:18:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525572924963844097",
  "geo" : { },
  "id_str" : "525574214657789952",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick thanks, hadn\u2019t read the comments so far. Should have done that before presenting. ;)",
  "id" : 525574214657789952,
  "in_reply_to_status_id" : 525572924963844097,
  "created_at" : "2014-10-24 09:07:12 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525572752817016832",
  "geo" : { },
  "id_str" : "525573088470388737",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick great, that was my answer as well. fingerprints of different kits seems to make that unlikely.",
  "id" : 525573088470388737,
  "in_reply_to_status_id" : 525572752817016832,
  "created_at" : "2014-10-24 09:02:43 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525572438353281024",
  "geo" : { },
  "id_str" : "525572629592555520",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick only real question that came up was whether the contamination might be introduced within the dilution series.",
  "id" : 525572629592555520,
  "in_reply_to_status_id" : 525572438353281024,
  "created_at" : "2014-10-24 09:00:54 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525572035934945280",
  "geo" : { },
  "id_str" : "525572317972561920",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick directly related: your reagent contamination paper gave us some good laughs in the journal club this week!",
  "id" : 525572317972561920,
  "in_reply_to_status_id" : 525572035934945280,
  "created_at" : "2014-10-24 08:59:39 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/FmG8JKMd8f",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0110152#s4",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525571220646154240",
  "text" : "After making fun of the \u2018metagenome sequence everything\u2019-attitude all week: \u00ABBacterial Communities in Semen\u00BB http:\/\/t.co\/FmG8JKMd8f",
  "id" : 525571220646154240,
  "created_at" : "2014-10-24 08:55:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/wNJzM6Astt",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003858",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525570009037549568",
  "text" : "\u00ABTen Simple Rules for Writing a PLOS Ten Simple Rules Article\u00BB http:\/\/t.co\/wNJzM6Astt",
  "id" : 525570009037549568,
  "created_at" : "2014-10-24 08:50:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/xdSGxSQ0cD",
      "expanded_url" : "http:\/\/instagram.com\/p\/uh2SDdBwmq\/",
      "display_url" : "instagram.com\/p\/uh2SDdBwmq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525567476940042240",
  "text" : "\u00ABAre you still waiting for that jobs to finish?\u00BB http:\/\/t.co\/xdSGxSQ0cD",
  "id" : 525567476940042240,
  "created_at" : "2014-10-24 08:40:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525379257804271616",
  "geo" : { },
  "id_str" : "525552719046930432",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer crashed due to lack of memory. seems to be the story of my life.",
  "id" : 525552719046930432,
  "in_reply_to_status_id" : 525379257804271616,
  "created_at" : "2014-10-24 07:41:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525247070245257216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152801514, 8.7503814697 ]
  },
  "id_str" : "525408162170806272",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat yay! das n\u00E4chste mal dann im Partnerlook!",
  "id" : 525408162170806272,
  "in_reply_to_status_id" : 525247070245257216,
  "created_at" : "2014-10-23 22:07:22 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 3, 19 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/xtd0LRLJ00",
      "expanded_url" : "http:\/\/www.theatlantic.com\/national\/archive\/2013\/01\/theres-more-to-life-than-being-happy\/266805\/?single_page=true",
      "display_url" : "theatlantic.com\/national\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525404417999515648",
  "text" : "RT @The_Smoking_GNU: \"It is the very pursuit of happiness that thwarts happiness.\" http:\/\/t.co\/xtd0LRLJ00",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/xtd0LRLJ00",
        "expanded_url" : "http:\/\/www.theatlantic.com\/national\/archive\/2013\/01\/theres-more-to-life-than-being-happy\/266805\/?single_page=true",
        "display_url" : "theatlantic.com\/national\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "525403758692696064",
    "text" : "\"It is the very pursuit of happiness that thwarts happiness.\" http:\/\/t.co\/xtd0LRLJ00",
    "id" : 525403758692696064,
    "created_at" : "2014-10-23 21:49:52 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "protected" : false,
      "id_str" : "14535787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2761947084\/9f21f669a1629e0af7949d685517ee66_normal.jpeg",
      "id" : 14535787,
      "verified" : false
    }
  },
  "id" : 525404417999515648,
  "created_at" : "2014-10-23 21:52:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/VUUXHnkPGz",
      "expanded_url" : "http:\/\/taz.de\/Die-Wahrheit\/!148039;m\/",
      "display_url" : "taz.de\/Die-Wahrheit\/!\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106719971, 8.7525583569 ]
  },
  "id_str" : "525399090944032768",
  "text" : "\u00ABPrinzipiell befinde man sich immer noch im Drei\u00DFigj\u00E4hrigen Krieg, behauptet Reichsb\u00FCrger Lars Dietrich\u00BB http:\/\/t.co\/VUUXHnkPGz",
  "id" : 525399090944032768,
  "created_at" : "2014-10-23 21:31:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHD Comics",
      "screen_name" : "PHDcomics",
      "indices" : [ 3, 13 ],
      "id_str" : "15521075",
      "id" : 15521075
    }, {
      "name" : "SciAm Mind",
      "screen_name" : "sciammind",
      "indices" : [ 85, 95 ],
      "id_str" : "29328707",
      "id" : 29328707
    }, {
      "name" : "Dwayne Godwin",
      "screen_name" : "BrainyActs",
      "indices" : [ 96, 107 ],
      "id_str" : "84525427",
      "id" : 84525427
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/phdcomics\/status\/525380166567358465\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/m5spw9YYzg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qGefzIUAE9HpA.jpg",
      "id_str" : "525380165032235009",
      "id" : 525380165032235009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qGefzIUAE9HpA.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 920
      } ],
      "display_url" : "pic.twitter.com\/m5spw9YYzg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525395375444987904",
  "text" : "RT @phdcomics: Turing's Test: \"We must never fail to see the humanity in each other\" @sciammind @BrainyActs http:\/\/t.co\/m5spw9YYzg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SciAm Mind",
        "screen_name" : "sciammind",
        "indices" : [ 70, 80 ],
        "id_str" : "29328707",
        "id" : 29328707
      }, {
        "name" : "Dwayne Godwin",
        "screen_name" : "BrainyActs",
        "indices" : [ 81, 92 ],
        "id_str" : "84525427",
        "id" : 84525427
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phdcomics\/status\/525380166567358465\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/m5spw9YYzg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qGefzIUAE9HpA.jpg",
        "id_str" : "525380165032235009",
        "id" : 525380165032235009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qGefzIUAE9HpA.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 920
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 920
        } ],
        "display_url" : "pic.twitter.com\/m5spw9YYzg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525380166567358465",
    "text" : "Turing's Test: \"We must never fail to see the humanity in each other\" @sciammind @BrainyActs http:\/\/t.co\/m5spw9YYzg",
    "id" : 525380166567358465,
    "created_at" : "2014-10-23 20:16:07 +0000",
    "user" : {
      "name" : "PHD Comics",
      "screen_name" : "PHDcomics",
      "protected" : false,
      "id_str" : "15521075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658834232123502592\/cwurv-IT_normal.png",
      "id" : 15521075,
      "verified" : false
    }
  },
  "id" : 525395375444987904,
  "created_at" : "2014-10-23 21:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina Borchert",
      "screen_name" : "lyssaslounge",
      "indices" : [ 3, 16 ],
      "id_str" : "2513671",
      "id" : 2513671
    }, {
      "name" : "TechnicallyRon",
      "screen_name" : "TechnicallyRon",
      "indices" : [ 77, 92 ],
      "id_str" : "108140114",
      "id" : 108140114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525394047125696513",
  "text" : "RT @lyssaslounge: \"Pointing out spelling mistakes + how it gets you laid\" RT @TechnicallyRon: New issue of ANGRY TWITTER MAGAZINE http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechnicallyRon",
        "screen_name" : "TechnicallyRon",
        "indices" : [ 59, 74 ],
        "id_str" : "108140114",
        "id" : 108140114
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechnicallyRon\/status\/524845840209551360\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/vYjweXzpuK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0iggmdCAAALZW_.jpg",
        "id_str" : "524845838527234048",
        "id" : 524845838527234048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0iggmdCAAALZW_.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1447
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 848
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1447
        } ],
        "display_url" : "pic.twitter.com\/vYjweXzpuK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "524845840209551360",
    "geo" : { },
    "id_str" : "525392513251958785",
    "in_reply_to_user_id" : 108140114,
    "text" : "\"Pointing out spelling mistakes + how it gets you laid\" RT @TechnicallyRon: New issue of ANGRY TWITTER MAGAZINE http:\/\/t.co\/vYjweXzpuK\u201D",
    "id" : 525392513251958785,
    "in_reply_to_status_id" : 524845840209551360,
    "created_at" : "2014-10-23 21:05:11 +0000",
    "in_reply_to_screen_name" : "TechnicallyRon",
    "in_reply_to_user_id_str" : "108140114",
    "user" : {
      "name" : "Katharina Borchert",
      "screen_name" : "lyssaslounge",
      "protected" : false,
      "id_str" : "2513671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786372317542649857\/REDKcTgj_normal.jpg",
      "id" : 2513671,
      "verified" : true
    }
  },
  "id" : 525394047125696513,
  "created_at" : "2014-10-23 21:11:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525381863159111682",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150631905, 8.7504882813 ]
  },
  "id_str" : "525382142017417216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer our current setup does not even allow for -X on ssh. ;)",
  "id" : 525382142017417216,
  "in_reply_to_status_id" : 525381863159111682,
  "created_at" : "2014-10-23 20:23:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525379257804271616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151466537, 8.7503547702 ]
  },
  "id_str" : "525379512012660738",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer am already home, so i can\u2019t say for sure. but ssh + htop seems to say yes.",
  "id" : 525379512012660738,
  "in_reply_to_status_id" : 525379257804271616,
  "created_at" : "2014-10-23 20:13:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525366545074384898",
  "geo" : { },
  "id_str" : "525369639967416320",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks nice, congratulations :)",
  "id" : 525369639967416320,
  "in_reply_to_status_id" : 525366545074384898,
  "created_at" : "2014-10-23 19:34:17 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112057248, 8.7537672057 ]
  },
  "id_str" : "525345223132852224",
  "text" : "\u00ABNorbert und die Nacktsamer. Das w\u00E4re auch ein guter Name f\u00FCr eine Holzf\u00E4llerband mit Banjos!\u00BB",
  "id" : 525345223132852224,
  "created_at" : "2014-10-23 17:57:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525334354835542016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1731575421, 8.6280143727 ]
  },
  "id_str" : "525334440504217600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess it will be finished later this evening. :)",
  "id" : 525334440504217600,
  "in_reply_to_status_id" : 525334354835542016,
  "created_at" : "2014-10-23 17:14:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525333962630393856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1734882436, 8.6280003634 ]
  },
  "id_str" : "525334214708056065",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only a single, wanted to use my workstation for other stuff as well. It\u2019s 2x ~40 mbp for me.",
  "id" : 525334214708056065,
  "in_reply_to_status_id" : 525333962630393856,
  "created_at" : "2014-10-23 17:13:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525255107538325504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1734001932, 8.6278270209 ]
  },
  "id_str" : "525333718916149248",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so it seems to work, even if it takes ages. :)",
  "id" : 525333718916149248,
  "in_reply_to_status_id" : 525255107538325504,
  "created_at" : "2014-10-23 17:11:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525287295763873792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724011442, 8.6274604833 ]
  },
  "id_str" : "525292797017223168",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer great!",
  "id" : 525292797017223168,
  "in_reply_to_status_id" : 525287295763873792,
  "created_at" : "2014-10-23 14:28:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525286498309259264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172350139, 8.6275340845 ]
  },
  "id_str" : "525286757060063232",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer as long as we keep solr I will be a regular guest there! :D",
  "id" : 525286757060063232,
  "in_reply_to_status_id" : 525286498309259264,
  "created_at" : "2014-10-23 14:04:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/hytbjoCEjx",
      "expanded_url" : "http:\/\/instagram.com\/p\/ufvHgFhwrL\/",
      "display_url" : "instagram.com\/p\/ufvHgFhwrL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525270245238640640",
  "text" : "Hundstage http:\/\/t.co\/hytbjoCEjx",
  "id" : 525270245238640640,
  "created_at" : "2014-10-23 12:59:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525255107538325504",
  "geo" : { },
  "id_str" : "525255540117868544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx!",
  "id" : 525255540117868544,
  "in_reply_to_status_id" : 525255107538325504,
  "created_at" : "2014-10-23 12:00:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525252899585404928",
  "geo" : { },
  "id_str" : "525254807033229312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, I\u2019m already failing at finding the download :D",
  "id" : 525254807033229312,
  "in_reply_to_status_id" : 525252899585404928,
  "created_at" : "2014-10-23 11:57:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525252364157341696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723743226, 8.6275323325 ]
  },
  "id_str" : "525252642633949184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, we\u2019ll see.",
  "id" : 525252642633949184,
  "in_reply_to_status_id" : 525252364157341696,
  "created_at" : "2014-10-23 11:49:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525252073215262720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723384159, 8.627531629 ]
  },
  "id_str" : "525252210830344192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that on the other hand doesn\u2019t sound like fun. ;)",
  "id" : 525252210830344192,
  "in_reply_to_status_id" : 525252073215262720,
  "created_at" : "2014-10-23 11:47:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525251639738118144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723382297, 8.6275457775 ]
  },
  "id_str" : "525251848950005761",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer symap it is then ;)",
  "id" : 525251848950005761,
  "in_reply_to_status_id" : 525251639738118144,
  "created_at" : "2014-10-23 11:46:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525251276205199360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723382297, 8.6275457775 ]
  },
  "id_str" : "525251497987411968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx, will have a look. Does it work well scaffolds vs scaffolds?",
  "id" : 525251497987411968,
  "in_reply_to_status_id" : 525251276205199360,
  "created_at" : "2014-10-23 11:44:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525249812623790080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1737577458, 8.6249088108 ]
  },
  "id_str" : "525251014426103808",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Visual Inspection in a first step, looking more closely into synteny later on.",
  "id" : 525251014426103808,
  "in_reply_to_status_id" : 525249812623790080,
  "created_at" : "2014-10-23 11:42:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525249547208249345",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer do you have a recommendation for genome against genome mapping?",
  "id" : 525249547208249345,
  "created_at" : "2014-10-23 11:37:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525239305309274114",
  "geo" : { },
  "id_str" : "525242687281446912",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat foto!",
  "id" : 525242687281446912,
  "in_reply_to_status_id" : 525239305309274114,
  "created_at" : "2014-10-23 11:09:49 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/YFinMtHRyf",
      "expanded_url" : "http:\/\/0height.com\/wp-content\/uploads\/2013\/07\/deal-with-it-gif-pony.gif",
      "display_url" : "0height.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "525215390616809472",
  "geo" : { },
  "id_str" : "525215794725412864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/YFinMtHRyf",
  "id" : 525215794725412864,
  "in_reply_to_status_id" : 525215390616809472,
  "created_at" : "2014-10-23 09:22:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525214545271599105",
  "geo" : { },
  "id_str" : "525214722686451713",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @Lobot und Bienenst\u00F6cke zu haben ist uns explizit untersagt. ;)",
  "id" : 525214722686451713,
  "in_reply_to_status_id" : 525214545271599105,
  "created_at" : "2014-10-23 09:18:42 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525214477613301760",
  "geo" : { },
  "id_str" : "525214609322827776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this is not the pony play you are looking for!",
  "id" : 525214609322827776,
  "in_reply_to_status_id" : 525214477613301760,
  "created_at" : "2014-10-23 09:18:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525213824753074176",
  "geo" : { },
  "id_str" : "525214218963144704",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wie cool w\u00E4re das? Ich k\u00F6nnte mir morgens meinen Poncho \u00FCberwerfen und zur Arbeit reiten!",
  "id" : 525214218963144704,
  "in_reply_to_status_id" : 525213824753074176,
  "created_at" : "2014-10-23 09:16:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525207509418909696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723094853, 8.6274676064 ]
  },
  "id_str" : "525212539874197504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot steht dagegen auch was in der Hausordnung?",
  "id" : 525212539874197504,
  "in_reply_to_status_id" : 525207509418909696,
  "created_at" : "2014-10-23 09:10:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525194608322830336",
  "geo" : { },
  "id_str" : "525199300281004032",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u05D0\u05E8\u05D5\u05D7\u05EA \u05D4\u05D1\u05D5\u05E7\u05E8 \u05E9\u05DC\u05D9!",
  "id" : 525199300281004032,
  "in_reply_to_status_id" : 525194608322830336,
  "created_at" : "2014-10-23 08:17:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 15, 21 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/525193597722054657\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/lWYGdJCBqH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ncytJIAAA0Fdb.jpg",
      "id_str" : "525193595234811904",
      "id" : 525193595234811904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ncytJIAAA0Fdb.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lWYGdJCBqH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723397935, 8.6275082828 ]
  },
  "id_str" : "525193597722054657",
  "text" : "Nom-Resupplies @Lobot http:\/\/t.co\/lWYGdJCBqH",
  "id" : 525193597722054657,
  "created_at" : "2014-10-23 07:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525066107666067457",
  "geo" : { },
  "id_str" : "525066200951562240",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot ah, cool.",
  "id" : 525066200951562240,
  "in_reply_to_status_id" : 525066107666067457,
  "created_at" : "2014-10-22 23:28:32 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525065758242779136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106388456, 8.7594718652 ]
  },
  "id_str" : "525065925113184257",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot in the worst case we will fit you into our sleeping bags. What brings you to Amsterdam?",
  "id" : 525065925113184257,
  "in_reply_to_status_id" : 525065758242779136,
  "created_at" : "2014-10-22 23:27:26 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525065307183120385",
  "geo" : { },
  "id_str" : "525065554814849024",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr great, @lobot and I will go camping there on that weekend.",
  "id" : 525065554814849024,
  "in_reply_to_status_id" : 525065307183120385,
  "created_at" : "2014-10-22 23:25:58 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525026235513307137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152801513, 8.7503814697 ]
  },
  "id_str" : "525063112886861824",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr guess who will also be in Amsterdam on 21st of Nov! Wanna go for drinks\/dinner?",
  "id" : 525063112886861824,
  "in_reply_to_status_id" : 525026235513307137,
  "created_at" : "2014-10-22 23:16:15 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Nm7Um5A4FF",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/10\/16\/creating-the-field-of-evidence-based-data-analysis-do-people-know-what-a-p-value-looks-like\/",
      "display_url" : "simplystatistics.org\/2014\/10\/16\/cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524979555233456129",
  "text" : "\u00ABdo people know what a p-value looks like?\u00BB http:\/\/t.co\/Nm7Um5A4FF",
  "id" : 524979555233456129,
  "created_at" : "2014-10-22 17:44:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/KOv3SyhhAq",
      "expanded_url" : "http:\/\/instagram.com\/p\/udZW41hwul\/",
      "display_url" : "instagram.com\/p\/udZW41hwul\/"
    } ]
  },
  "geo" : { },
  "id_str" : "524940920945651712",
  "text" : "We're not slacking off, we are doing biotechnology. http:\/\/t.co\/KOv3SyhhAq",
  "id" : 524940920945651712,
  "created_at" : "2014-10-22 15:10:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524939067436568577",
  "geo" : { },
  "id_str" : "524939385310289921",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I have no stakes in keeping Solr, replacing it is more than fine by me.",
  "id" : 524939385310289921,
  "in_reply_to_status_id" : 524939067436568577,
  "created_at" : "2014-10-22 15:04:37 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524937930847297536",
  "geo" : { },
  "id_str" : "524938451289116674",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch looks impressive nevertheless ;)",
  "id" : 524938451289116674,
  "in_reply_to_status_id" : 524937930847297536,
  "created_at" : "2014-10-22 15:00:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.169336951, 8.6335133706 ]
  },
  "id_str" : "524931862398246912",
  "text" : "\u00ABBut then the applicants would be stuck in Limbo for really long!\u00BB \u2014 \u00ABThey have to dance?!\u00BB",
  "id" : 524931862398246912,
  "created_at" : "2014-10-22 14:34:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524839462321537024",
  "text" : "\u00ABIch hab die Lampen aus der Steckdose gezogen &amp; den Schalter f\u00FCr die Deckenlampe abgeklebt damit mein Sohn mich morgens nicht grell weckt.\u00BB",
  "id" : 524839462321537024,
  "created_at" : "2014-10-22 08:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. \uD83E\uDD14. Ritter",
      "screen_name" : "paniq",
      "indices" : [ 3, 9 ],
      "id_str" : "15840592",
      "id" : 15840592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/0DQp85wEdc",
      "expanded_url" : "http:\/\/gamergates.tumblr.com\/",
      "display_url" : "gamergates.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "524826238628929536",
  "text" : "RT @paniq: All the GamerGates you need. http:\/\/t.co\/0DQp85wEdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/0DQp85wEdc",
        "expanded_url" : "http:\/\/gamergates.tumblr.com\/",
        "display_url" : "gamergates.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "524699060784365569",
    "text" : "All the GamerGates you need. http:\/\/t.co\/0DQp85wEdc",
    "id" : 524699060784365569,
    "created_at" : "2014-10-21 23:09:39 +0000",
    "user" : {
      "name" : "L. \uD83E\uDD14. Ritter",
      "screen_name" : "paniq",
      "protected" : false,
      "id_str" : "15840592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888469564543127553\/lct3T2Zk_normal.jpg",
      "id" : 15840592,
      "verified" : false
    }
  },
  "id" : 524826238628929536,
  "created_at" : "2014-10-22 07:35:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524820281958088704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1667308451, 8.6217632265 ]
  },
  "id_str" : "524823423089135617",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot tja, rat mal wer so faul ist das er nicht mal Paddel zum Kanu gekauft hat!",
  "id" : 524823423089135617,
  "in_reply_to_status_id" : 524820281958088704,
  "created_at" : "2014-10-22 07:23:49 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524714055089815553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1124364525, 8.7539055084 ]
  },
  "id_str" : "524812796782182400",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot Verein zur F\u00F6rderung des \u00F6ffentlichen bewegten Wasserverkehrs.",
  "id" : 524812796782182400,
  "in_reply_to_status_id" : 524714055089815553,
  "created_at" : "2014-10-22 06:41:35 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    }, {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 12, 20 ],
      "id_str" : "15890805",
      "id" : 15890805
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 21, 28 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524693205275901952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096599078, 8.2830072742 ]
  },
  "id_str" : "524694002072055808",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke @ekelias @Bediko sleep tight",
  "id" : 524694002072055808,
  "in_reply_to_status_id" : 524693205275901952,
  "created_at" : "2014-10-21 22:49:33 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    }, {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 9, 20 ],
      "id_str" : "56062177",
      "id" : 56062177
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 21, 28 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524692081709953024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096599078, 8.2830072742 ]
  },
  "id_str" : "524693050288009216",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias @TanteSilke @Bediko jetzt bekomm ich Hunger und will frisch gepressten Saft!",
  "id" : 524693050288009216,
  "in_reply_to_status_id" : 524692081709953024,
  "created_at" : "2014-10-21 22:45:46 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    }, {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 12, 17 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524689985841418240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096607448, 8.2830086862 ]
  },
  "id_str" : "524690173318422528",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke @balu das war auch mein Gedanke, mehr zellul\u00E4re Bestandteile, ist nur die Frage wieviel das ausmacht.",
  "id" : 524690173318422528,
  "in_reply_to_status_id" : 524689985841418240,
  "created_at" : "2014-10-21 22:34:20 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    }, {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 8, 19 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524689500610785280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096612909, 8.2829785939 ]
  },
  "id_str" : "524689963171213312",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko @TanteSilke was man bei Selbstverkostung mit einberechnen sollte.",
  "id" : 524689963171213312,
  "in_reply_to_status_id" : 524689500610785280,
  "created_at" : "2014-10-21 22:33:30 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    }, {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 8, 19 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/N67tbkCdod",
      "expanded_url" : "https:\/\/twitter.com\/balu\/status\/524687906980757506",
      "display_url" : "twitter.com\/balu\/status\/52\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "524689500610785280",
  "geo" : { },
  "id_str" : "524689613966016512",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko @TanteSilke Die Frage wurde \u00FCbrigens beantwortet. ;) https:\/\/t.co\/N67tbkCdod",
  "id" : 524689613966016512,
  "in_reply_to_status_id" : 524689500610785280,
  "created_at" : "2014-10-21 22:32:06 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524687244146515969",
  "geo" : { },
  "id_str" : "524688670440583168",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke Ich vermute f\u00FCr Sperma d\u00FCrfte man zumindest leichter Freiwillige finden.",
  "id" : 524688670440583168,
  "in_reply_to_status_id" : 524687244146515969,
  "created_at" : "2014-10-21 22:28:21 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524687906980757506",
  "geo" : { },
  "id_str" : "524688394044309504",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu danke, da waren meine Suchanfragen wohl um einen search term zu spezifisch ;)",
  "id" : 524688394044309504,
  "in_reply_to_status_id" : 524687906980757506,
  "created_at" : "2014-10-21 22:27:16 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524686849282158593",
  "geo" : { },
  "id_str" : "524687076626022400",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke Das ist doch alles eine Frage der Menge, oder nicht?",
  "id" : 524687076626022400,
  "in_reply_to_status_id" : 524686849282158593,
  "created_at" : "2014-10-21 22:22:01 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524686652636418050",
  "text" : "Wo wir schon bei Ern\u00E4hrung sind: Wieviel kcal hat eigentlich Menstruationsblut?",
  "id" : 524686652636418050,
  "created_at" : "2014-10-21 22:20:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524685543142342656",
  "text" : "\u00ABDu h\u00E4ttest Anne Frank auch f\u00FCr ein St\u00FCck Zucker verraten!\u00BB\u2013\u00ABWas denkst du von mir?\u00BB\u2013\u00ABNa gut, du bist moralisch integer. Zwei St\u00FCck Zucker.\u00BB",
  "id" : 524685543142342656,
  "created_at" : "2014-10-21 22:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111880718, 8.7586112849 ]
  },
  "id_str" : "524628726165028864",
  "text" : "The satisfying feeling of finally getting a glimpse why some algorithm utterly fails.",
  "id" : 524628726165028864,
  "created_at" : "2014-10-21 18:30:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524599072209264641",
  "geo" : { },
  "id_str" : "524610014141767681",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch did you bring the divine comedy as reading material for the wait?",
  "id" : 524610014141767681,
  "in_reply_to_status_id" : 524599072209264641,
  "created_at" : "2014-10-21 17:15:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524604512703905792",
  "geo" : { },
  "id_str" : "524609867362099200",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @PhilippBayer *dramatic drum roll*",
  "id" : 524609867362099200,
  "in_reply_to_status_id" : 524604512703905792,
  "created_at" : "2014-10-21 17:15:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524597281400840192",
  "geo" : { },
  "id_str" : "524597382697467904",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that\u2019s because they don\u2019t have to say \u201Cno\u201D, saying nothing is just as good? ;)",
  "id" : 524597382697467904,
  "in_reply_to_status_id" : 524597281400840192,
  "created_at" : "2014-10-21 16:25:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524595822579974144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723233569, 8.627501593 ]
  },
  "id_str" : "524596797587869696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch best of luck on that. :)",
  "id" : 524596797587869696,
  "in_reply_to_status_id" : 524595822579974144,
  "created_at" : "2014-10-21 16:23:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524595277207195648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722975062, 8.6275973449 ]
  },
  "id_str" : "524595580325363712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch or at least you hope to be there ;)",
  "id" : 524595580325363712,
  "in_reply_to_status_id" : 524595277207195648,
  "created_at" : "2014-10-21 16:18:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524588765290196992",
  "geo" : { },
  "id_str" : "524589816231788545",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yeah, even for me it is a bit like this, Berlin was easier to plan.",
  "id" : 524589816231788545,
  "in_reply_to_status_id" : 524588765290196992,
  "created_at" : "2014-10-21 15:55:33 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524588069014765568",
  "geo" : { },
  "id_str" : "524588155505508352",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer no plans for it so far, what about you?",
  "id" : 524588155505508352,
  "in_reply_to_status_id" : 524588069014765568,
  "created_at" : "2014-10-21 15:48:57 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lolnope",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524584648408858624",
  "geo" : { },
  "id_str" : "524585294226808832",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach die Uni Frankfurt ist ja bekannt daf\u00FCr flexible Arbeitsvertr\u00E4ge anzubieten. #lolnope",
  "id" : 524585294226808832,
  "in_reply_to_status_id" : 524584648408858624,
  "created_at" : "2014-10-21 15:37:35 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524584381793722369",
  "geo" : { },
  "id_str" : "524584567668477952",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach Nur wenn er diese Menge w\u00F6chentlich liefern kann.",
  "id" : 524584567668477952,
  "in_reply_to_status_id" : 524584381793722369,
  "created_at" : "2014-10-21 15:34:41 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524584248062533632",
  "text" : "\u00ABWenn ihr mich einstellt bringe ich 1.5 kg Schokokekse mit.\u00BB",
  "id" : 524584248062533632,
  "created_at" : "2014-10-21 15:33:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 0, 12 ],
      "id_str" : "59806323",
      "id" : 59806323
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524565245562736640",
  "geo" : { },
  "id_str" : "524565717669380096",
  "in_reply_to_user_id" : 59806323,
  "text" : "@sleeksorrow @Lobot da fehlt aber das Stra\u00DFenmusik-Feeling :)",
  "id" : 524565717669380096,
  "in_reply_to_status_id" : 524565245562736640,
  "created_at" : "2014-10-21 14:19:47 +0000",
  "in_reply_to_screen_name" : "sleeksorrow",
  "in_reply_to_user_id_str" : "59806323",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/zNvy7s7SR3",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3518",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524560455541751808",
  "text" : "being special http:\/\/t.co\/zNvy7s7SR3",
  "id" : 524560455541751808,
  "created_at" : "2014-10-21 13:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/8C4H5SCfXF",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/51",
      "display_url" : "existentialcomics.com\/comic\/51"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723229928, 8.6275279671 ]
  },
  "id_str" : "524548544095879169",
  "text" : "Philosophy Tech Support http:\/\/t.co\/8C4H5SCfXF",
  "id" : 524548544095879169,
  "created_at" : "2014-10-21 13:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/PjjFfCtYtA",
      "expanded_url" : "http:\/\/instagram.com\/p\/ualT7ZBwn1\/",
      "display_url" : "instagram.com\/p\/ualT7ZBwn1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "524544995362340864",
  "text" : "Omicsomics NEW! http:\/\/t.co\/PjjFfCtYtA",
  "id" : 524544995362340864,
  "created_at" : "2014-10-21 12:57:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524539135072407552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722964284, 8.6275167091 ]
  },
  "id_str" : "524540522455912449",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot du bist schwerer, du musst paddeln! ;)",
  "id" : 524540522455912449,
  "in_reply_to_status_id" : 524539135072407552,
  "created_at" : "2014-10-21 12:39:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524536719442722816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722989876, 8.627518216 ]
  },
  "id_str" : "524538063423561729",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot HMS Beagle 2.0? ;)",
  "id" : 524538063423561729,
  "in_reply_to_status_id" : 524536719442722816,
  "created_at" : "2014-10-21 12:29:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524491794776862720",
  "geo" : { },
  "id_str" : "524492380360417280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (look at there DL dump links to)",
  "id" : 524492380360417280,
  "in_reply_to_status_id" : 524491794776862720,
  "created_at" : "2014-10-21 09:28:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 23, 32 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/FiB5FFyaaj",
      "expanded_url" : "https:\/\/opensnp.org\/fitbit",
      "display_url" : "opensnp.org\/fitbit"
    } ]
  },
  "in_reply_to_status_id_str" : "524491794776862720",
  "geo" : { },
  "id_str" : "524492364958928896",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. did @eramirez and you figure out the problem? I think it\u2019s the legacy link here: https:\/\/t.co\/FiB5FFyaaj",
  "id" : 524492364958928896,
  "in_reply_to_status_id" : 524491794776862720,
  "created_at" : "2014-10-21 09:28:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524491794776862720",
  "geo" : { },
  "id_str" : "524491908312498176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yep, still nice to have it fixed. :)",
  "id" : 524491908312498176,
  "in_reply_to_status_id" : 524491794776862720,
  "created_at" : "2014-10-21 09:26:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524491486210322433",
  "geo" : { },
  "id_str" : "524491603017469953",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, probably just a c&amp;p error :)",
  "id" : 524491603017469953,
  "in_reply_to_status_id" : 524491486210322433,
  "created_at" : "2014-10-21 09:25:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524491032688611328",
  "geo" : { },
  "id_str" : "524491178696527872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I remember we updated the internal data to 37, but kept the original files untouched.",
  "id" : 524491178696527872,
  "in_reply_to_status_id" : 524491032688611328,
  "created_at" : "2014-10-21 09:23:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524490661689827328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer regarding the latest info@ mail. We are at 38 or 37 atm? ;)",
  "id" : 524490661689827328,
  "created_at" : "2014-10-21 09:21:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Barrantes",
      "screen_name" : "jpablobr",
      "indices" : [ 40, 49 ],
      "id_str" : "20365288",
      "id" : 20365288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Fj2mu1giWf",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8qSg8Gtukkw&index=2&list=RDITH2uopBcOg",
      "display_url" : "youtube.com\/watch?v=8qSg8G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524488661166194688",
  "text" : "Guitar-Porn https:\/\/t.co\/Fj2mu1giWf \/ht @jpablobr",
  "id" : 524488661166194688,
  "created_at" : "2014-10-21 09:13:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524482845503664128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172319449, 8.6274781186 ]
  },
  "id_str" : "524483631201665024",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer that would be fine by me. Reducing the dependencies sounds like a good idea.",
  "id" : 524483631201665024,
  "in_reply_to_status_id" : 524482845503664128,
  "created_at" : "2014-10-21 08:53:36 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524475445874790400",
  "geo" : { },
  "id_str" : "524481711166750720",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer we went with solr because it was easy to implement all the search functions but I guess you\u2019re right.",
  "id" : 524481711166750720,
  "in_reply_to_status_id" : 524475445874790400,
  "created_at" : "2014-10-21 08:45:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "good decision maker",
      "screen_name" : "killerlimpet",
      "indices" : [ 3, 16 ],
      "id_str" : "512599288",
      "id" : 512599288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524317236601683968",
  "text" : "RT @killerlimpet: .fastq -&gt; .sam -&gt; .bam -&gt; .sort.bam -&gt; .bai -&gt; .bcf -&gt; .vcf -&gt; ...\n\nMe, when bioinformatics is happening to me:\nhttp:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 133, 155 ],
        "url" : "http:\/\/t.co\/MJM3wERJt0",
        "expanded_url" : "http:\/\/i.imgur.com\/nJdP4.gif",
        "display_url" : "i.imgur.com\/nJdP4.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "524038020539117568",
    "text" : ".fastq -&gt; .sam -&gt; .bam -&gt; .sort.bam -&gt; .bai -&gt; .bcf -&gt; .vcf -&gt; ...\n\nMe, when bioinformatics is happening to me:\nhttp:\/\/t.co\/MJM3wERJt0",
    "id" : 524038020539117568,
    "created_at" : "2014-10-20 03:22:54 +0000",
    "user" : {
      "name" : "good decision maker",
      "screen_name" : "killerlimpet",
      "protected" : false,
      "id_str" : "512599288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922289116708065280\/JJ9JP5xl_normal.jpg",
      "id" : 512599288,
      "verified" : false
    }
  },
  "id" : 524317236601683968,
  "created_at" : "2014-10-20 21:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U of T Copyright",
      "screen_name" : "UofTSCCO",
      "indices" : [ 3, 12 ],
      "id_str" : "2533185035",
      "id" : 2533185035
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/UofTSCCO\/status\/524261462874005504\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/igg7r2Zozb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aM_wxIUAADgS6.jpg",
      "id_str" : "524261433685856256",
      "id" : 524261433685856256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aM_wxIUAADgS6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/igg7r2Zozb"
    } ],
    "hashtags" : [ {
      "text" : "oaweek",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "uoft",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524291353598242817",
  "text" : "RT @UofTSCCO: \"If I lost access to all online research today, I would...\" #oaweek #uoft http:\/\/t.co\/igg7r2Zozb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/UofTSCCO\/status\/524261462874005504\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/igg7r2Zozb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aM_wxIUAADgS6.jpg",
        "id_str" : "524261433685856256",
        "id" : 524261433685856256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aM_wxIUAADgS6.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/igg7r2Zozb"
      } ],
      "hashtags" : [ {
        "text" : "oaweek",
        "indices" : [ 60, 67 ]
      }, {
        "text" : "uoft",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524261462874005504",
    "text" : "\"If I lost access to all online research today, I would...\" #oaweek #uoft http:\/\/t.co\/igg7r2Zozb",
    "id" : 524261462874005504,
    "created_at" : "2014-10-20 18:10:47 +0000",
    "user" : {
      "name" : "U of T Copyright",
      "screen_name" : "UofTSCCO",
      "protected" : false,
      "id_str" : "2533185035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515157437108609025\/lhVMmx_q_normal.jpeg",
      "id" : 2533185035,
      "verified" : false
    }
  },
  "id" : 524291353598242817,
  "created_at" : "2014-10-20 20:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111833746, 8.7590727006 ]
  },
  "id_str" : "524284339870109696",
  "text" : "Bought a canoe named \u2018#yolo\u2019. Makes you wonder why the seller wanted to get rid of it.",
  "id" : 524284339870109696,
  "created_at" : "2014-10-20 19:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bengoldacre\/status\/524219278074343424\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gv1oduk70Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Zmp67IcAE4wNv.png",
      "id_str" : "524219277013184513",
      "id" : 524219277013184513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Zmp67IcAE4wNv.png",
      "sizes" : [ {
        "h" : 901,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 664
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 880
      } ],
      "display_url" : "pic.twitter.com\/gv1oduk70Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/2TTdUlAxpm",
      "expanded_url" : "http:\/\/goodmenproject.com\/families\/tmb-whats-dad-daughter-wants-dress-han-solo\/",
      "display_url" : "goodmenproject.com\/families\/tmb-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524228491064393728",
  "text" : "RT @bengoldacre: What\u2019s a dad to do when his daughter wants to dress as Han Solo? http:\/\/t.co\/2TTdUlAxpm http:\/\/t.co\/gv1oduk70Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bengoldacre\/status\/524219278074343424\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/gv1oduk70Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Zmp67IcAE4wNv.png",
        "id_str" : "524219277013184513",
        "id" : 524219277013184513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Zmp67IcAE4wNv.png",
        "sizes" : [ {
          "h" : 901,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 664
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/gv1oduk70Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/2TTdUlAxpm",
        "expanded_url" : "http:\/\/goodmenproject.com\/families\/tmb-whats-dad-daughter-wants-dress-han-solo\/",
        "display_url" : "goodmenproject.com\/families\/tmb-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524219278074343424",
    "text" : "What\u2019s a dad to do when his daughter wants to dress as Han Solo? http:\/\/t.co\/2TTdUlAxpm http:\/\/t.co\/gv1oduk70Q",
    "id" : 524219278074343424,
    "created_at" : "2014-10-20 15:23:10 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 524228491064393728,
  "created_at" : "2014-10-20 15:59:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/oIjiGK0kRf",
      "expanded_url" : "https:\/\/medium.com\/@designuxui\/how-bad-ux-killed-jenny-ef915419879e",
      "display_url" : "medium.com\/@designuxui\/ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524183064835264512",
  "text" : "Next: A\/B testing not using conversion rates but using survival rates: \u00ABHow Bad UX Killed Jenny\u00BB https:\/\/t.co\/oIjiGK0kRf",
  "id" : 524183064835264512,
  "created_at" : "2014-10-20 12:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HZVwlqEZT7",
      "expanded_url" : "http:\/\/instagram.com\/p\/uX6WKFhwpQ\/",
      "display_url" : "instagram.com\/p\/uX6WKFhwpQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "524169038554234880",
  "text" : "\u00ABWillst du auch ein kitschiges Bild vor dem Sonnenuntergang haben?\u00BB http:\/\/t.co\/HZVwlqEZT7",
  "id" : 524169038554234880,
  "created_at" : "2014-10-20 12:03:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/VxndNUCm3p",
      "expanded_url" : "http:\/\/ravenshadow.lmd.net\/files\/index\/MySpacePics\/Comic%20-%20Farside%20-%20Chicken%20and%20the%20egg.jpg",
      "display_url" : "ravenshadow.lmd.net\/files\/index\/My\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "524165577028694016",
  "geo" : { },
  "id_str" : "524167033878245376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/VxndNUCm3p",
  "id" : 524167033878245376,
  "in_reply_to_status_id" : 524165577028694016,
  "created_at" : "2014-10-20 11:55:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524164919034671104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1759188741, 8.6166902229 ]
  },
  "id_str" : "524165395998314496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot do want!",
  "id" : 524165395998314496,
  "in_reply_to_status_id" : 524164919034671104,
  "created_at" : "2014-10-20 11:49:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/MJYSZz7Hv1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QplQL5eAxlY&list=UU3XTzVzaHQEd30rQbuvCtTQ",
      "display_url" : "youtube.com\/watch?v=QplQL5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524130939363151874",
  "text" : "\u00ABdon't you dare call this kafkaesk, I don't want my name anywhere near this shit.\u00BB https:\/\/t.co\/MJYSZz7Hv1",
  "id" : 524130939363151874,
  "created_at" : "2014-10-20 09:32:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 54, 60 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/QmwERhDwEl",
      "expanded_url" : "http:\/\/www.piccolo.cc\/",
      "display_url" : "piccolo.cc"
    } ]
  },
  "geo" : { },
  "id_str" : "524125155623452673",
  "text" : "piccolo \u2013 the tiny CNC-bot http:\/\/t.co\/QmwERhDwEl \/cc @Lobot",
  "id" : 524125155623452673,
  "created_at" : "2014-10-20 09:09:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 14, 23 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524118516191227904",
  "geo" : { },
  "id_str" : "524119069252145152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eramirez and fitbit also send me a couple of emails regarding us hitting their API rate limit. ;)",
  "id" : 524119069252145152,
  "in_reply_to_status_id" : 524118516191227904,
  "created_at" : "2014-10-20 08:44:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 14, 23 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524118516191227904",
  "geo" : { },
  "id_str" : "524119012931031040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eramirez at least I did get the files I requested.",
  "id" : 524119012931031040,
  "in_reply_to_status_id" : 524118516191227904,
  "created_at" : "2014-10-20 08:44:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/YOCherfrsZ",
      "expanded_url" : "http:\/\/giphy.com\/gifs\/win-funny-dancing-OwGMuG7bCc5Dq",
      "display_url" : "giphy.com\/gifs\/win-funny\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "523940818290483200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152801514, 8.7503814697 ]
  },
  "id_str" : "523941946788962304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/YOCherfrsZ",
  "id" : 523941946788962304,
  "in_reply_to_status_id" : 523940818290483200,
  "created_at" : "2014-10-19 21:01:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152964404, 8.7503787715 ]
  },
  "id_str" : "523940137236176897",
  "text" : "\u00ABBist du nackt?\u00BB \u2013 \u00ABDas geht sie gar nichts an, junge Frau!\u00BB",
  "id" : 523940137236176897,
  "created_at" : "2014-10-19 20:53:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523921147101212672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152695061, 8.7503793407 ]
  },
  "id_str" : "523925240574144512",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err gl\u00FCckwunsch! :)",
  "id" : 523925240574144512,
  "in_reply_to_status_id" : 523921147101212672,
  "created_at" : "2014-10-19 19:54:46 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523911000169271296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152635164, 8.7503781427 ]
  },
  "id_str" : "523916358795657216",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @PhilippBayer have fun!",
  "id" : 523916358795657216,
  "in_reply_to_status_id" : 523911000169271296,
  "created_at" : "2014-10-19 19:19:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523187852717203456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143949976, 8.7464649135 ]
  },
  "id_str" : "523903312329183232",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @PhilippBayer was so kind to fix that problem. you may receive belated downloadlinks soon ;)",
  "id" : 523903312329183232,
  "in_reply_to_status_id" : 523187852717203456,
  "created_at" : "2014-10-19 18:27:37 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/D9phjuL537",
      "expanded_url" : "http:\/\/www.bostonglobe.com\/ideas\/2014\/10\/18\/when-island-nations-drown-who-owns-their-seas\/hyH9W5b1mCAyTVgwlFh7qO\/story.html",
      "display_url" : "bostonglobe.com\/ideas\/2014\/10\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647, 8.282986 ]
  },
  "id_str" : "523899622218293248",
  "text" : "When Island Nations Drown, Who Owns Their Seas? http:\/\/t.co\/D9phjuL537",
  "id" : 523899622218293248,
  "created_at" : "2014-10-19 18:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Anthony Fejes",
      "screen_name" : "apfejes",
      "indices" : [ 86, 94 ],
      "id_str" : "59855448",
      "id" : 59855448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523822203977334786",
  "text" : "RT @pjacock: Likes because \u201Cit\u2019s the exact opposite of everything I do in my work\u201D RT @apfejes: Ikea furniture and bioinformatics. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Fejes",
        "screen_name" : "apfejes",
        "indices" : [ 73, 81 ],
        "id_str" : "59855448",
        "id" : 59855448
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Q9hvlGoD0r",
        "expanded_url" : "http:\/\/ift.tt\/1wVFZcs",
        "display_url" : "ift.tt\/1wVFZcs"
      } ]
    },
    "geo" : { },
    "id_str" : "523813106955583488",
    "text" : "Likes because \u201Cit\u2019s the exact opposite of everything I do in my work\u201D RT @apfejes: Ikea furniture and bioinformatics. http:\/\/t.co\/Q9hvlGoD0r",
    "id" : 523813106955583488,
    "created_at" : "2014-10-19 12:29:11 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 523822203977334786,
  "created_at" : "2014-10-19 13:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Gauld",
      "screen_name" : "tomgauld",
      "indices" : [ 39, 48 ],
      "id_str" : "46090073",
      "id" : 46090073
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tomgauld\/status\/523770376112078848\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/27HNG87wf7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0TOXsKCIAAHVan.jpg",
      "id_str" : "523770363067375616",
      "id" : 523770363067375616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0TOXsKCIAAHVan.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/27HNG87wf7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964735, 8.28298609 ]
  },
  "id_str" : "523818622649901058",
  "text" : "Give me cartoon dog Sherlock Homes! MT @tomgauld: \u201E221b Baker Street\u201C http:\/\/t.co\/27HNG87wf7",
  "id" : 523818622649901058,
  "created_at" : "2014-10-19 12:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/l40uqdfZUT",
      "expanded_url" : "http:\/\/priceonomics.com\/stepping-off-the-golden-gate-bridge\/",
      "display_url" : "priceonomics.com\/stepping-off-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11069473, 8.75751801 ]
  },
  "id_str" : "523592899582517249",
  "text" : "Stepping off the Golden Gate Bridge http:\/\/t.co\/l40uqdfZUT",
  "id" : 523592899582517249,
  "created_at" : "2014-10-18 21:54:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1142120361, 8.7501678467 ]
  },
  "id_str" : "523444558215270400",
  "text" : "Grippostalingrad",
  "id" : 523444558215270400,
  "created_at" : "2014-10-18 12:04:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Robine",
      "screen_name" : "notSoJunkDNA",
      "indices" : [ 3, 16 ],
      "id_str" : "107174526",
      "id" : 107174526
    }, {
      "name" : "Illumina",
      "screen_name" : "illumina",
      "indices" : [ 49, 58 ],
      "id_str" : "46145761",
      "id" : 46145761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/0r45HAB1Tt",
      "expanded_url" : "http:\/\/bit.ly\/1sWTFVQ",
      "display_url" : "bit.ly\/1sWTFVQ"
    } ]
  },
  "geo" : { },
  "id_str" : "523408732601217024",
  "text" : "RT @notSoJunkDNA: YEAH! 2x250bp! Bring it on! MT @illumina: Announcing new reagent kits: Rapid V2 for 2x250 PE http:\/\/t.co\/0r45HAB1Tt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Illumina",
        "screen_name" : "illumina",
        "indices" : [ 31, 40 ],
        "id_str" : "46145761",
        "id" : 46145761
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/0r45HAB1Tt",
        "expanded_url" : "http:\/\/bit.ly\/1sWTFVQ",
        "display_url" : "bit.ly\/1sWTFVQ"
      } ]
    },
    "in_reply_to_status_id_str" : "523060132230742016",
    "geo" : { },
    "id_str" : "523100219412856832",
    "in_reply_to_user_id" : 46145761,
    "text" : "YEAH! 2x250bp! Bring it on! MT @illumina: Announcing new reagent kits: Rapid V2 for 2x250 PE http:\/\/t.co\/0r45HAB1Tt",
    "id" : 523100219412856832,
    "in_reply_to_status_id" : 523060132230742016,
    "created_at" : "2014-10-17 13:16:25 +0000",
    "in_reply_to_screen_name" : "illumina",
    "in_reply_to_user_id_str" : "46145761",
    "user" : {
      "name" : "Nicolas Robine",
      "screen_name" : "notSoJunkDNA",
      "protected" : false,
      "id_str" : "107174526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925905483302670338\/jMPGgj0v_normal.jpg",
      "id" : 107174526,
      "verified" : false
    }
  },
  "id" : 523408732601217024,
  "created_at" : "2014-10-18 09:42:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/vzc17t6XBJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/uSfVZMBwkU\/",
      "display_url" : "instagram.com\/p\/uSfVZMBwkU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113868442, 8.753692928 ]
  },
  "id_str" : "523405951458873345",
  "text" : "Kaffeepause @ Hafeninsel http:\/\/t.co\/vzc17t6XBJ",
  "id" : 523405951458873345,
  "created_at" : "2014-10-18 09:31:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523187852717203456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009666438, 8.2829103367 ]
  },
  "id_str" : "523209066961977344",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez After sending that email. ;-)",
  "id" : 523209066961977344,
  "in_reply_to_status_id" : 523187852717203456,
  "created_at" : "2014-10-17 20:28:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523187499766542336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096664421, 8.2829103454 ]
  },
  "id_str" : "523187601109712897",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez No problem, will send out an email to the others later, just came back from my dayjob.",
  "id" : 523187601109712897,
  "in_reply_to_status_id" : 523187499766542336,
  "created_at" : "2014-10-17 19:03:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523186764907692032",
  "geo" : { },
  "id_str" : "523187397274918912",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I hope so too. The problem for the other export-function seems to be our limited server capabilities right now.",
  "id" : 523187397274918912,
  "in_reply_to_status_id" : 523186764907692032,
  "created_at" : "2014-10-17 19:02:50 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/szUh58H7Vw",
      "expanded_url" : "https:\/\/opensnp.org\/data\/zip\/opensnp_datadump.current.zip",
      "display_url" : "opensnp.org\/data\/zip\/opens\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "523185944283721728",
  "geo" : { },
  "id_str" : "523186492739694592",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez you, Sir, discovered some legacy code on the Fitbit-overview-page. Try this https:\/\/t.co\/szUh58H7Vw (warning, large download)",
  "id" : 523186492739694592,
  "in_reply_to_status_id" : 523185944283721728,
  "created_at" : "2014-10-17 18:59:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523185852680122368",
  "geo" : { },
  "id_str" : "523186013041356800",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Ah, okay. I will have a look now. :-)",
  "id" : 523186013041356800,
  "in_reply_to_status_id" : 523185852680122368,
  "created_at" : "2014-10-17 18:57:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523181155554557952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096662041, 8.2829098429 ]
  },
  "id_str" : "523185704533504001",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @openSNPorg I will have a look. Did the Fitbit-Export work by now?",
  "id" : 523185704533504001,
  "in_reply_to_status_id" : 523181155554557952,
  "created_at" : "2014-10-17 18:56:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523181155554557952",
  "geo" : { },
  "id_str" : "523185659461509123",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez You\u2019re not being a pest at all. I\u2019m happy for each user that tells us something is wrong. Especially when done that nicely!",
  "id" : 523185659461509123,
  "in_reply_to_status_id" : 523181155554557952,
  "created_at" : "2014-10-17 18:55:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 99, 106 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1741549693, 8.6279558992 ]
  },
  "id_str" : "523179283058274304",
  "text" : "\u00ABAlter, so eine Scheiss. Hier sind ja nur Studenten!\u00BB Ich glaube die Jugend am Riedberg m\u00F6chte mit @lsanoj bekannt gemacht werden.",
  "id" : 523179283058274304,
  "created_at" : "2014-10-17 18:30:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/gPjrEICMmv",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/10\/next-gen-sequencing-dna-forensics.html",
      "display_url" : "massgenomics.org\/2014\/10\/next-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523140070963171328",
  "text" : "Next-Gen sequencing for DNA Forensics http:\/\/t.co\/gPjrEICMmv",
  "id" : 523140070963171328,
  "created_at" : "2014-10-17 15:54:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/6Ui7H3hfUq",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/10\/17\/bayes-rule-in-a-gif\/",
      "display_url" : "simplystatistics.org\/2014\/10\/17\/bay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523127005077073920",
  "text" : "For those struggling with understanding statistics: Bayes Rule in an animated gif http:\/\/t.co\/6Ui7H3hfUq",
  "id" : 523127005077073920,
  "created_at" : "2014-10-17 15:02:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523084765172613120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724332814, 8.6275123113 ]
  },
  "id_str" : "523110427430232064",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot jetzt brauche ich nur noch ein Fahrrad. Und einen Hund.",
  "id" : 523110427430232064,
  "in_reply_to_status_id" : 523084765172613120,
  "created_at" : "2014-10-17 13:56:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 3, 9 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/WcjU6K4qkT",
      "expanded_url" : "http:\/\/ift.tt\/1qCZFhC",
      "display_url" : "ift.tt\/1qCZFhC"
    } ]
  },
  "geo" : { },
  "id_str" : "523065972740354048",
  "text" : "RT @tante: AirBnB is used by few wealthy people to run \"hotels\" without oversight. http:\/\/t.co\/WcjU6K4qkT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/WcjU6K4qkT",
        "expanded_url" : "http:\/\/ift.tt\/1qCZFhC",
        "display_url" : "ift.tt\/1qCZFhC"
      } ]
    },
    "geo" : { },
    "id_str" : "523065236639989761",
    "text" : "AirBnB is used by few wealthy people to run \"hotels\" without oversight. http:\/\/t.co\/WcjU6K4qkT",
    "id" : 523065236639989761,
    "created_at" : "2014-10-17 10:57:25 +0000",
    "user" : {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "protected" : false,
      "id_str" : "14179278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802837466512236544\/UiursIr__normal.jpg",
      "id" : 14179278,
      "verified" : true
    }
  },
  "id" : 523065972740354048,
  "created_at" : "2014-10-17 11:00:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rowan Hooper",
      "screen_name" : "rowhoop",
      "indices" : [ 3, 11 ],
      "id_str" : "16110819",
      "id" : 16110819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/mjw7MoP2Jq",
      "expanded_url" : "http:\/\/ow.ly\/CTXEP",
      "display_url" : "ow.ly\/CTXEP"
    } ]
  },
  "geo" : { },
  "id_str" : "523050226559770624",
  "text" : "RT @rowhoop: Greenpeace has undermined its own scientific credibility and its ability to shoot down Owen Paterson http:\/\/t.co\/mjw7MoP2Jq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/mjw7MoP2Jq",
        "expanded_url" : "http:\/\/ow.ly\/CTXEP",
        "display_url" : "ow.ly\/CTXEP"
      } ]
    },
    "geo" : { },
    "id_str" : "523012011912077312",
    "text" : "Greenpeace has undermined its own scientific credibility and its ability to shoot down Owen Paterson http:\/\/t.co\/mjw7MoP2Jq",
    "id" : 523012011912077312,
    "created_at" : "2014-10-17 07:25:55 +0000",
    "user" : {
      "name" : "Rowan Hooper",
      "screen_name" : "rowhoop",
      "protected" : false,
      "id_str" : "16110819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736427491\/ed8e7deb1a2a366b8d7f66f109802abd_normal.jpeg",
      "id" : 16110819,
      "verified" : true
    }
  },
  "id" : 523050226559770624,
  "created_at" : "2014-10-17 09:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Ybf1fbA7cs",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0109999",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523046720700420096",
  "text" : "Whole Genome Complete Resequencing of Bacillus subtilis Natto by Combining Long Reads with High-Quality Short Reads http:\/\/t.co\/Ybf1fbA7cs",
  "id" : 523046720700420096,
  "created_at" : "2014-10-17 09:43:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/UtmtjcZIZq",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1160",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523046129911738368",
  "text" : "My five year plan http:\/\/t.co\/UtmtjcZIZq",
  "id" : 523046129911738368,
  "created_at" : "2014-10-17 09:41:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523045546555346944",
  "geo" : { },
  "id_str" : "523045734023987200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch they are already used to me, so that will not be a surprise.",
  "id" : 523045734023987200,
  "in_reply_to_status_id" : 523045546555346944,
  "created_at" : "2014-10-17 09:39:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523043908495106048",
  "geo" : { },
  "id_str" : "523044510147035136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that\u2019s why. I guess my co-workers also would like to meet the other crazy openSNP-guys. :p",
  "id" : 523044510147035136,
  "in_reply_to_status_id" : 523043908495106048,
  "created_at" : "2014-10-17 09:35:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523043258965164032",
  "geo" : { },
  "id_str" : "523043842661318657",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I will be offended if you don\u2019t drop by before leaving. ;)",
  "id" : 523043842661318657,
  "in_reply_to_status_id" : 523043258965164032,
  "created_at" : "2014-10-17 09:32:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523042581224370176",
  "geo" : { },
  "id_str" : "523043036180533248",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch By that time you hopefully will be back in Australia. btw: how is the visa stuff progressing?",
  "id" : 523043036180533248,
  "in_reply_to_status_id" : 523042581224370176,
  "created_at" : "2014-10-17 09:29:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/cDJeT6S8J8",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1410.3972",
      "display_url" : "arxiv.org\/abs\/1410.3972"
    } ]
  },
  "geo" : { },
  "id_str" : "523034145203974144",
  "text" : "\u00ABThe 'extremely ancient' chromosome that still isn\u2019t\u00BB http:\/\/t.co\/cDJeT6S8J8",
  "id" : 523034145203974144,
  "created_at" : "2014-10-17 08:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 59, 72 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 73, 85 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/wzqNMRhIta",
      "expanded_url" : "http:\/\/www.sciencemag.org\/content\/346\/6207\/296.full",
      "display_url" : "sciencemag.org\/content\/346\/62\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523031065695629313",
  "text" : "Changes on the horizon for consumer genomics in the EU \/cc @PhilippBayer @helgerausch http:\/\/t.co\/wzqNMRhIta",
  "id" : 523031065695629313,
  "created_at" : "2014-10-17 08:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/523017464893169664\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/fFlu1rR9c5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0IhnGnIAAARUmi.jpg",
      "id_str" : "523017462401728512",
      "id" : 523017462401728512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0IhnGnIAAARUmi.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/fFlu1rR9c5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723047963, 8.6274822241 ]
  },
  "id_str" : "523017464893169664",
  "text" : "Luckily I can just convince myself that I\u2019m rather small. http:\/\/t.co\/fFlu1rR9c5",
  "id" : 523017464893169664,
  "created_at" : "2014-10-17 07:47:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ichbinsoalt",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096611432, 8.2830105733 ]
  },
  "id_str" : "522874869046722561",
  "text" : "#ichbinsoalt, mein Name ist Mensch.",
  "id" : 522874869046722561,
  "created_at" : "2014-10-16 22:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Konnikova",
      "screen_name" : "mkonnikova",
      "indices" : [ 3, 14 ],
      "id_str" : "358566293",
      "id" : 358566293
    }, {
      "name" : "James Hamblin",
      "screen_name" : "jameshamblin",
      "indices" : [ 119, 132 ],
      "id_str" : "332993870",
      "id" : 332993870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522873928713121793",
  "text" : "RT @mkonnikova: \"What if nutrition labels told people exactly what calories meant? A coke, it might say=50-minute jog\" @jameshamblin http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Hamblin",
        "screen_name" : "jameshamblin",
        "indices" : [ 103, 116 ],
        "id_str" : "332993870",
        "id" : 332993870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/dg14mL3zzo",
        "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/10\/forget-calories-ii\/381494\/?single_page=true",
        "display_url" : "theatlantic.com\/health\/archive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522853867583975424",
    "text" : "\"What if nutrition labels told people exactly what calories meant? A coke, it might say=50-minute jog\" @jameshamblin http:\/\/t.co\/dg14mL3zzo",
    "id" : 522853867583975424,
    "created_at" : "2014-10-16 20:57:30 +0000",
    "user" : {
      "name" : "Maria Konnikova",
      "screen_name" : "mkonnikova",
      "protected" : false,
      "id_str" : "358566293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454261373996773379\/5oYFsBnU_normal.jpeg",
      "id" : 358566293,
      "verified" : true
    }
  },
  "id" : 522873928713121793,
  "created_at" : "2014-10-16 22:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 23, 29 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522686474169634816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724760676, 8.6275284458 ]
  },
  "id_str" : "522686728495464448",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 damit kann ich @lobot dann zur Ganzk\u00F6rper-Alu-Mumie machen!",
  "id" : 522686728495464448,
  "in_reply_to_status_id" : 522686474169634816,
  "created_at" : "2014-10-16 09:53:21 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522686228265967616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724384586, 8.6276884843 ]
  },
  "id_str" : "522686590507048960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 \u00ABIch will Constanze werden statt der Constanze!\u00BB",
  "id" : 522686590507048960,
  "in_reply_to_status_id" : 522686228265967616,
  "created_at" : "2014-10-16 09:52:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522685242831036416",
  "geo" : { },
  "id_str" : "522685515339153408",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 Kannst dich ja beim CCC als Sprecherin bewerben mit der Einstellung!",
  "id" : 522685515339153408,
  "in_reply_to_status_id" : 522685242831036416,
  "created_at" : "2014-10-16 09:48:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522684151871582208",
  "text" : "Working on a workstation &amp; a laptop at the same time is great. It means you can crash both machines in parallel\u2026",
  "id" : 522684151871582208,
  "created_at" : "2014-10-16 09:43:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522677193403809792",
  "text" : "\u00ABIch wollte mich eigentlich nur bei ihm einhaken. Und jetzt bin ich ganz nass!\u00BB Morgendliche Kaffeeunf\u00E4lle.",
  "id" : 522677193403809792,
  "created_at" : "2014-10-16 09:15:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723302555, 8.6274675616 ]
  },
  "id_str" : "522653108791681024",
  "text" : "\u00ABJetzt wo du den Lebkuchentaler genommen hast musst du dich auch setzen und dir mein Leid anh\u00F6ren!\u00BB",
  "id" : 522653108791681024,
  "created_at" : "2014-10-16 07:39:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 59, 75 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/kgm1803X45",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2014\/07\/16\/007187",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522460206845140992",
  "text" : "Made my choice: the next journal club will give a plug for @pathogenomenick and http:\/\/t.co\/kgm1803X45",
  "id" : 522460206845140992,
  "created_at" : "2014-10-15 18:53:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522449846327058433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659979, 8.7588850867 ]
  },
  "id_str" : "522454699816275968",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo thanks for the great support and the wonderful work. But I guess for German the drinking sound used is  \u2018gluck\u2019 :)",
  "id" : 522454699816275968,
  "in_reply_to_status_id" : 522449846327058433,
  "created_at" : "2014-10-15 18:31:21 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 40, 52 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Wfv38bVkN6",
      "expanded_url" : "http:\/\/instagram.com\/p\/uLlvbZBwis\/",
      "display_url" : "instagram.com\/p\/uLlvbZBwis\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106777711, 8.758867017 ]
  },
  "id_str" : "522435052920385537",
  "text" : "Our kitchen looks so much nicer! Thanks @chapmangamo! http:\/\/t.co\/Wfv38bVkN6",
  "id" : 522435052920385537,
  "created_at" : "2014-10-15 17:13:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/KC0JCSqsy3",
      "expanded_url" : "http:\/\/www.itv.com\/news\/meridian\/update\/2014-10-15\/fox-trashes-pub-after-falling-down-chimney\/",
      "display_url" : "itv.com\/news\/meridian\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522421239928061952",
  "text" : "Fox trashes pub after falling down chimney http:\/\/t.co\/KC0JCSqsy3",
  "id" : 522421239928061952,
  "created_at" : "2014-10-15 16:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522405274804834305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726715729, 8.6275896713 ]
  },
  "id_str" : "522406508001513472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot can\u2019t I finally get my defender?",
  "id" : 522406508001513472,
  "in_reply_to_status_id" : 522405274804834305,
  "created_at" : "2014-10-15 15:19:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 31, 37 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/eQXSn9VCwa",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/10\/gunther-christine-holtorf-odyssey\/",
      "display_url" : "thisiscolossal.com\/2014\/10\/gunthe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522392514633170944",
  "text" : "Could we do another road trip, @lobot? http:\/\/t.co\/eQXSn9VCwa",
  "id" : 522392514633170944,
  "created_at" : "2014-10-15 14:24:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lynn that middle name or even a few more emo",
      "screen_name" : "Peter_Lynn",
      "indices" : [ 3, 14 ],
      "id_str" : "23652005",
      "id" : 23652005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522384037282054144",
  "text" : "RT @Peter_Lynn: I read Malcolm Gladwell books for 10,000 hours and now I'm an expert at cherry-picked anecdotes, post-hoc sophistry and fal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522373898235428864",
    "text" : "I read Malcolm Gladwell books for 10,000 hours and now I'm an expert at cherry-picked anecdotes, post-hoc sophistry and false dichotomies.",
    "id" : 522373898235428864,
    "created_at" : "2014-10-15 13:10:17 +0000",
    "user" : {
      "name" : "Peter Lynn that middle name or even a few more emo",
      "screen_name" : "Peter_Lynn",
      "protected" : false,
      "id_str" : "23652005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884937412945862656\/9MiHfjAv_normal.jpg",
      "id" : 23652005,
      "verified" : false
    }
  },
  "id" : 522384037282054144,
  "created_at" : "2014-10-15 13:50:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 99, 110 ],
      "id_str" : "44903491",
      "id" : 44903491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/WwxGdx8twf",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/10\/rats-arent-smarter-than-mice-and-that-actually-matters\/381430\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522379224142061569",
  "text" : "RT @edyong209: Rats aren't smarter than mice, and that actually matters. http:\/\/t.co\/WwxGdx8twf HT @roseveleth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rose Eveleth \u25B7\u25B7",
        "screen_name" : "roseveleth",
        "indices" : [ 84, 95 ],
        "id_str" : "44903491",
        "id" : 44903491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/WwxGdx8twf",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/10\/rats-arent-smarter-than-mice-and-that-actually-matters\/381430\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522378660092071936",
    "text" : "Rats aren't smarter than mice, and that actually matters. http:\/\/t.co\/WwxGdx8twf HT @roseveleth",
    "id" : 522378660092071936,
    "created_at" : "2014-10-15 13:29:12 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 522379224142061569,
  "created_at" : "2014-10-15 13:31:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9bdPXeqVcy",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/10\/fantastically-wrong-strange-murderous-sometimes-sexy-history-mermaid\/",
      "display_url" : "wired.com\/2014\/10\/fantas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522378557390323712",
  "text" : "Fantastically Wrong: The Murderous, Sometimes Sexy History of the Mermaid http:\/\/t.co\/9bdPXeqVcy",
  "id" : 522378557390323712,
  "created_at" : "2014-10-15 13:28:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522372290651361280",
  "text" : "\u00ABImmer wenn ich mit Bastian auf der Dachterrasse bin ist bei mir alles ganz offen.\u00BB",
  "id" : 522372290651361280,
  "created_at" : "2014-10-15 13:03:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723461764, 8.6275773876 ]
  },
  "id_str" : "522351884318048256",
  "text" : "\u00ABWor\u00FCber lacht ihr beiden so?\u00BB \u2014 \u00ABWir dachten gestern beide das wir bald vielleicht Eltern werden. Also, unabh\u00E4ngig von einander.\u00BB",
  "id" : 522351884318048256,
  "created_at" : "2014-10-15 11:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723525027, 8.6275269933 ]
  },
  "id_str" : "522335077066612737",
  "text" : "Im Journal Club gelernt: Wie wir unser Cluster \u00FCber Malware auf USB-Sticks vergr\u00F6\u00DFern. N\u00E4chste Exkursion: In die Computerpools der Uni.",
  "id" : 522335077066612737,
  "created_at" : "2014-10-15 10:36:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "indices" : [ 3, 10 ],
      "id_str" : "2849770550",
      "id" : 2849770550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522334309018267648",
  "text" : "RT @bik_f_: Today at 12:30pm we'll be doing back exercises in Wallace. invertebrate ecologists and others without backs are excused",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522327408129871872",
    "text" : "Today at 12:30pm we'll be doing back exercises in Wallace. invertebrate ecologists and others without backs are excused",
    "id" : 522327408129871872,
    "created_at" : "2014-10-15 10:05:33 +0000",
    "user" : {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "protected" : false,
      "id_str" : "2849770550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520456619709452289\/DG1Gz8_e_normal.jpeg",
      "id" : 2849770550,
      "verified" : false
    }
  },
  "id" : 522334309018267648,
  "created_at" : "2014-10-15 10:32:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 91, 96 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/cnCcjrhIKX",
      "expanded_url" : "http:\/\/jayisgames.com\/games\/double-hitler\/",
      "display_url" : "jayisgames.com\/games\/double-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522310931687415809",
  "text" : "\u00ABtheir quest to achieve greatness, accidentally triggering a little mishap called WWII\u00BB MT @klmr: \u201CDouble Hitler\u201D. http:\/\/t.co\/cnCcjrhIKX\u201D",
  "id" : 522310931687415809,
  "created_at" : "2014-10-15 09:00:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522300221184020480",
  "text" : "\u00ABHaving a rational discussion about this? You are a stereotypical German after all!\u00BB\u2013\u00ABOne of the few things where you can\u2019t out-german me!\u00BB",
  "id" : 522300221184020480,
  "created_at" : "2014-10-15 08:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151189295, 8.7503329313 ]
  },
  "id_str" : "522161254639894528",
  "text" : "\u00ABPeople always make Nazi jokes when they hear I'm learning German. It\u2019s strange, to me it\u2019s the language of love and music.\u00BB",
  "id" : 522161254639894528,
  "created_at" : "2014-10-14 23:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151189295, 8.7503329313 ]
  },
  "id_str" : "522160703353143297",
  "text" : "\u00ABIst das dein Penis oder freust du dich mich zu sehen?\u00BB",
  "id" : 522160703353143297,
  "created_at" : "2014-10-14 23:03:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 59, 69 ],
      "id_str" : "8198012",
      "id" : 8198012
    }, {
      "name" : "Benjamen Walker",
      "screen_name" : "benjamenwalker",
      "indices" : [ 76, 91 ],
      "id_str" : "22834949",
      "id" : 22834949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/yJMauvIBPD",
      "expanded_url" : "http:\/\/kck.st\/1w0nW5F",
      "display_url" : "kck.st\/1w0nW5F"
    } ]
  },
  "geo" : { },
  "id_str" : "522135028319662082",
  "text" : "During my next 7 hour drive I once again want to listen to @romanmars &amp; @benjamenwalker non-stop, so give them money: http:\/\/t.co\/yJMauvIBPD",
  "id" : 522135028319662082,
  "created_at" : "2014-10-14 21:21:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brain Pickings",
      "screen_name" : "brainpickings",
      "indices" : [ 3, 17 ],
      "id_str" : "79783264",
      "id" : 79783264
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brainpickings\/status\/521506904397602816\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/h7M2KnRSPX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzzDxCqIUAA16ju.png",
      "id_str" : "521506904162717696",
      "id" : 521506904162717696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzzDxCqIUAA16ju.png",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 464
      } ],
      "display_url" : "pic.twitter.com\/h7M2KnRSPX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/voL6zuQOZP",
      "expanded_url" : "http:\/\/j.mp\/1rpo5KB",
      "display_url" : "j.mp\/1rpo5KB"
    } ]
  },
  "geo" : { },
  "id_str" : "522130320079224832",
  "text" : "RT @brainpickings: Patti Smith's advice on life \u2013 her wonderful Pratt commencement address http:\/\/t.co\/voL6zuQOZP http:\/\/t.co\/h7M2KnRSPX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brainpickings\/status\/521506904397602816\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/h7M2KnRSPX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzzDxCqIUAA16ju.png",
        "id_str" : "521506904162717696",
        "id" : 521506904162717696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzzDxCqIUAA16ju.png",
        "sizes" : [ {
          "h" : 241,
          "resize" : "fit",
          "w" : 464
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 464
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 464
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 464
        } ],
        "display_url" : "pic.twitter.com\/h7M2KnRSPX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/voL6zuQOZP",
        "expanded_url" : "http:\/\/j.mp\/1rpo5KB",
        "display_url" : "j.mp\/1rpo5KB"
      } ]
    },
    "geo" : { },
    "id_str" : "521506904397602816",
    "text" : "Patti Smith's advice on life \u2013 her wonderful Pratt commencement address http:\/\/t.co\/voL6zuQOZP http:\/\/t.co\/h7M2KnRSPX",
    "id" : 521506904397602816,
    "created_at" : "2014-10-13 03:45:09 +0000",
    "user" : {
      "name" : "Brain Pickings",
      "screen_name" : "brainpickings",
      "protected" : false,
      "id_str" : "79783264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1526735513\/222158_10150189612955745_55555550744_7095892_1866590_n_normal.jpg",
      "id" : 79783264,
      "verified" : false
    }
  },
  "id" : 522130320079224832,
  "created_at" : "2014-10-14 21:02:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Ci52h4czpL",
      "expanded_url" : "http:\/\/theappendix.net\/issues\/2014\/10\/photographing-the-guillotine",
      "display_url" : "theappendix.net\/issues\/2014\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522072705617903616",
  "text" : "Photographing the Guillotine http:\/\/t.co\/Ci52h4czpL",
  "id" : 522072705617903616,
  "created_at" : "2014-10-14 17:13:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damian Pattinson",
      "screen_name" : "damianpattinson",
      "indices" : [ 3, 19 ],
      "id_str" : "146213978",
      "id" : 146213978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522064459347820545",
  "text" : "RT @damianpattinson: Nice write-up of a nice story: authors fail to replicate their own study and publish findings in PLOS ONE http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/6yx1znYv41",
        "expanded_url" : "http:\/\/bit.ly\/1xMnt7q",
        "display_url" : "bit.ly\/1xMnt7q"
      } ]
    },
    "geo" : { },
    "id_str" : "522034257984634880",
    "text" : "Nice write-up of a nice story: authors fail to replicate their own study and publish findings in PLOS ONE http:\/\/t.co\/6yx1znYv41",
    "id" : 522034257984634880,
    "created_at" : "2014-10-14 14:40:40 +0000",
    "user" : {
      "name" : "Damian Pattinson",
      "screen_name" : "damianpattinson",
      "protected" : false,
      "id_str" : "146213978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815173641\/Damian_Portrait_normal.png",
      "id" : 146213978,
      "verified" : false
    }
  },
  "id" : 522064459347820545,
  "created_at" : "2014-10-14 16:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MiketheMadBiologist",
      "screen_name" : "mikethemadbiol",
      "indices" : [ 3, 18 ],
      "id_str" : "27234566",
      "id" : 27234566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/FFR5IsQ4J9",
      "expanded_url" : "http:\/\/wp.me\/pZ9Pf-5Xu",
      "display_url" : "wp.me\/pZ9Pf-5Xu"
    } ]
  },
  "geo" : { },
  "id_str" : "522028544353120256",
  "text" : "RT @mikethemadbiol: Maybe This Explains Part of the Reproducibility\u00A0Problem? http:\/\/t.co\/FFR5IsQ4J9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/FFR5IsQ4J9",
        "expanded_url" : "http:\/\/wp.me\/pZ9Pf-5Xu",
        "display_url" : "wp.me\/pZ9Pf-5Xu"
      } ]
    },
    "geo" : { },
    "id_str" : "522024072792653824",
    "text" : "Maybe This Explains Part of the Reproducibility\u00A0Problem? http:\/\/t.co\/FFR5IsQ4J9",
    "id" : 522024072792653824,
    "created_at" : "2014-10-14 14:00:12 +0000",
    "user" : {
      "name" : "MiketheMadBiologist",
      "screen_name" : "mikethemadbiol",
      "protected" : false,
      "id_str" : "27234566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/115647461\/64797071_cadf3e2637_m_normal.jpg",
      "id" : 27234566,
      "verified" : false
    }
  },
  "id" : 522028544353120256,
  "created_at" : "2014-10-14 14:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522025640904499200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1728949492, 8.625706704 ]
  },
  "id_str" : "522026417341886464",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I can do a very convincing American impression if needed.",
  "id" : 522026417341886464,
  "in_reply_to_status_id" : 522025640904499200,
  "created_at" : "2014-10-14 14:09:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522025226767306754",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723329812, 8.6275514065 ]
  },
  "id_str" : "522025374537244672",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez sure, count me in. :)",
  "id" : 522025374537244672,
  "in_reply_to_status_id" : 522025226767306754,
  "created_at" : "2014-10-14 14:05:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522014586396889088",
  "geo" : { },
  "id_str" : "522024694506348544",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez will you fly me in for experiments? :p",
  "id" : 522024694506348544,
  "in_reply_to_status_id" : 522014586396889088,
  "created_at" : "2014-10-14 14:02:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723823624, 8.6275673287 ]
  },
  "id_str" : "521981100797988864",
  "text" : "\u00ABIhr habt doch wohl nur theoretisch nackt auf der Dachterrasse getanzt.\u00BB\u2014\u00ABWir sind die angewandte Bioinformatik, nicht die theoretische.\u00BB",
  "id" : 521981100797988864,
  "created_at" : "2014-10-14 11:09:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adl14",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/QzN85MA1wQ",
      "expanded_url" : "http:\/\/findingada.com\/read-2014s-stories\/",
      "display_url" : "findingada.com\/read-2014s-sto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521962001896312833",
  "text" : "Enjoy Ada Lovelace Day. There are already lots of stories: http:\/\/t.co\/QzN85MA1wQ #adl14",
  "id" : 521962001896312833,
  "created_at" : "2014-10-14 09:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723432257, 8.6275532027 ]
  },
  "id_str" : "521954646295072769",
  "text" : "\u00ABDann ist mein Auto explodiert. Wobei weniger explodiert als das Schaum aus jeder \u00D6ffnung gequollen ist.\u00BB \u2014 \u00ABOh, hatte es auch Tollwut?\u00BB",
  "id" : 521954646295072769,
  "created_at" : "2014-10-14 09:24:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cIHmrl7XP5",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/genetics-emphatically-deny-playing-any-part-in-are,37164\/",
      "display_url" : "theonion.com\/articles\/genet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521939393373020161",
  "text" : "\u00ABthe 46 chromosomes denied that they had played a direct role of any kind in the present state of his physique\u00BB http:\/\/t.co\/cIHmrl7XP5",
  "id" : 521939393373020161,
  "created_at" : "2014-10-14 08:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH Bear",
      "screen_name" : "NIH_Bear",
      "indices" : [ 3, 12 ],
      "id_str" : "2577076094",
      "id" : 2577076094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nih",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521780324230246400",
  "text" : "RT @NIH_Bear: If it weren't for the 10 year slide in #nih funding, fat would now be 6 calories per gram.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nih",
        "indices" : [ 39, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "521729660246573057",
    "text" : "If it weren't for the 10 year slide in #nih funding, fat would now be 6 calories per gram.",
    "id" : 521729660246573057,
    "created_at" : "2014-10-13 18:30:18 +0000",
    "user" : {
      "name" : "NIH Bear",
      "screen_name" : "NIH_Bear",
      "protected" : false,
      "id_str" : "2577076094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547789267888783360\/M8bGKd-t_normal.jpeg",
      "id" : 2577076094,
      "verified" : false
    }
  },
  "id" : 521780324230246400,
  "created_at" : "2014-10-13 21:51:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/521779918833979392\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/dDpJHgUSwK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz28EkdIAAA33eJ.jpg",
      "id_str" : "521779918536179712",
      "id" : 521779918536179712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz28EkdIAAA33eJ.jpg",
      "sizes" : [ {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/dDpJHgUSwK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153327622, 8.7503136956 ]
  },
  "id_str" : "521779918833979392",
  "text" : "Schr\u00F6dingers Kater. Bei Millers Hirnstr\u00F6men kann man nie sicher sein ob er noch lebt oder nicht. http:\/\/t.co\/dDpJHgUSwK",
  "id" : 521779918833979392,
  "created_at" : "2014-10-13 21:50:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521755500560785409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153327622, 8.7503136956 ]
  },
  "id_str" : "521779117029871616",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch me neither, will reply to that tomorrow.",
  "id" : 521779117029871616,
  "in_reply_to_status_id" : 521755500560785409,
  "created_at" : "2014-10-13 21:46:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/G4qvB1Krk0",
      "expanded_url" : "http:\/\/thenewinquiry.com\/essays\/view-from-nowhere\/",
      "display_url" : "thenewinquiry.com\/essays\/view-fr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521729026516606977",
  "text" : "\u00ABWe should pursue a popular approach to large data sets that comes to terms with Big Data\u2019s own smallness\u00BB  http:\/\/t.co\/G4qvB1Krk0",
  "id" : 521729026516606977,
  "created_at" : "2014-10-13 18:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/WaCSCss4B2",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/50",
      "display_url" : "existentialcomics.com\/comic\/50"
    } ]
  },
  "geo" : { },
  "id_str" : "521724599659425792",
  "text" : "Zeno and Zeno  http:\/\/t.co\/WaCSCss4B2",
  "id" : 521724599659425792,
  "created_at" : "2014-10-13 18:10:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wmfra",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1312978493, 8.6261201744 ]
  },
  "id_str" : "521723417457090560",
  "text" : "Industrie 4.0 #wmfra",
  "id" : 521723417457090560,
  "created_at" : "2014-10-13 18:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 8, 19 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521721960829833216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1313309085, 8.6259520715 ]
  },
  "id_str" : "521722208566398976",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @herrurbach und du uns abgef\u00FCllt hast.",
  "id" : 521722208566398976,
  "in_reply_to_status_id" : 521721960829833216,
  "created_at" : "2014-10-13 18:00:42 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wmfra",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1312934735, 8.626095651 ]
  },
  "id_str" : "521722130506194944",
  "text" : "Anonymous Hessen e.V. #wmfra",
  "id" : 521722130506194944,
  "created_at" : "2014-10-13 18:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521721304677113856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1312106957, 8.6263517491 ]
  },
  "id_str" : "521721972922023937",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach sonst w\u00E4re ich nie hier gelandet. :)",
  "id" : 521721972922023937,
  "in_reply_to_status_id" : 521721304677113856,
  "created_at" : "2014-10-13 17:59:46 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521720830989176832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1312937873, 8.626123295 ]
  },
  "id_str" : "521721243234729984",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach lang lang ist\u2019s her!",
  "id" : 521721243234729984,
  "in_reply_to_status_id" : 521720830989176832,
  "created_at" : "2014-10-13 17:56:52 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521704412574916610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1312937873, 8.626123295 ]
  },
  "id_str" : "521720751108677632",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach welcome to nostalgia? ;)",
  "id" : 521720751108677632,
  "in_reply_to_status_id" : 521704412574916610,
  "created_at" : "2014-10-13 17:54:54 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1313323461, 8.6262385549 ]
  },
  "id_str" : "521720045400240129",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer anyone of you near a ssh-capable device? Solr seems to be down again.",
  "id" : 521720045400240129,
  "created_at" : "2014-10-13 17:52:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521708153335869440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1129975283, 8.7526957051 ]
  },
  "id_str" : "521708309179822080",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @openSNPorg okay, it usually should be done rather quickly, like maybe 10-15 minutes depending on the load.",
  "id" : 521708309179822080,
  "in_reply_to_status_id" : 521708153335869440,
  "created_at" : "2014-10-13 17:05:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521692149528539138",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1129975283, 8.7526957051 ]
  },
  "id_str" : "521708068560990208",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @openSNPorg oh, if it hasn\u2019t gone through by now you can re-request it. Will look into why nothing happened so far.",
  "id" : 521708068560990208,
  "in_reply_to_status_id" : 521692149528539138,
  "created_at" : "2014-10-13 17:04:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "indices" : [ 3, 15 ],
      "id_str" : "15859033",
      "id" : 15859033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/OeG81OsWeu",
      "expanded_url" : "http:\/\/wp.me\/pYKlt-60T",
      "display_url" : "wp.me\/pYKlt-60T"
    } ]
  },
  "geo" : { },
  "id_str" : "521686650674753537",
  "text" : "RT @ivanoransky: How meta: Paper on errors retracted for \u201Ctoo many stupid\u00A0mistakes\u201D http:\/\/t.co\/OeG81OsWeu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/OeG81OsWeu",
        "expanded_url" : "http:\/\/wp.me\/pYKlt-60T",
        "display_url" : "wp.me\/pYKlt-60T"
      } ]
    },
    "geo" : { },
    "id_str" : "521685292701347841",
    "text" : "How meta: Paper on errors retracted for \u201Ctoo many stupid\u00A0mistakes\u201D http:\/\/t.co\/OeG81OsWeu",
    "id" : 521685292701347841,
    "created_at" : "2014-10-13 15:34:00 +0000",
    "user" : {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "protected" : false,
      "id_str" : "15859033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1485171512\/bearcubtwitter_normal.jpg",
      "id" : 15859033,
      "verified" : false
    }
  },
  "id" : 521686650674753537,
  "created_at" : "2014-10-13 15:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PU4VpFHE8F",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1002\/1522-7189(199911\/12)7:6%3C321::AID-NT90%3E3.0.CO;2-U\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1002\/15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521685419952726016",
  "text" : "Besides being an astrobiologist I can also claim having some Bear Grylls-like skills. http:\/\/t.co\/PU4VpFHE8F",
  "id" : 521685419952726016,
  "created_at" : "2014-10-13 15:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723117353, 8.6275301736 ]
  },
  "id_str" : "521675932214788096",
  "text" : "\u00ABDanke das ich \u2018Bastian der Beste\u2019 in deinem Adressbuch bin.\u00BB \u2014 \u00ABDas wird beim Empf\u00E4nger angezeigt?! Ich muss mein Adressbuch durchgehen!\u00BB",
  "id" : 521675932214788096,
  "created_at" : "2014-10-13 14:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maoris Off-Katze",
      "screen_name" : "MaoriHH",
      "indices" : [ 3, 11 ],
      "id_str" : "4373299636",
      "id" : 4373299636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MaoriHH\/status\/521660965407191040\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/CRMloQvoIg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz1P3rvCYAAS_Kq.jpg",
      "id_str" : "521660949896257536",
      "id" : 521660949896257536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz1P3rvCYAAS_Kq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/CRMloQvoIg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521665047261876225",
  "text" : "RT @MaoriHH: Projekt \u00BBDeutschland in ein B\u00E4llebad umbauen 2020\u00AB. http:\/\/t.co\/CRMloQvoIg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MaoriHH\/status\/521660965407191040\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/CRMloQvoIg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz1P3rvCYAAS_Kq.jpg",
        "id_str" : "521660949896257536",
        "id" : 521660949896257536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz1P3rvCYAAS_Kq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/CRMloQvoIg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "521660965407191040",
    "text" : "Projekt \u00BBDeutschland in ein B\u00E4llebad umbauen 2020\u00AB. http:\/\/t.co\/CRMloQvoIg",
    "id" : 521660965407191040,
    "created_at" : "2014-10-13 13:57:20 +0000",
    "user" : {
      "name" : "Maori",
      "screen_name" : "Maori",
      "protected" : false,
      "id_str" : "109518412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856800212890906624\/IFwA2-xC_normal.jpg",
      "id" : 109518412,
      "verified" : false
    }
  },
  "id" : 521665047261876225,
  "created_at" : "2014-10-13 14:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/OtPYyf0sje",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S1754504812000098",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521663151558127617",
  "text" : "I always thought I was trolling people when I told them I was doing astrobiology. Turns out it\u2019s even somewhat true! http:\/\/t.co\/OtPYyf0sje",
  "id" : 521663151558127617,
  "created_at" : "2014-10-13 14:06:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722999809, 8.6274612262 ]
  },
  "id_str" : "521653003557011456",
  "text" : "\u00ABFreundliches Kassenpersonal bitte.\u00BB Seltsame Durchsagen hier im Supermarkt.",
  "id" : 521653003557011456,
  "created_at" : "2014-10-13 13:25:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 86, 92 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/4Ynf836AbQ",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/10\/stone-age-tools-language\/",
      "display_url" : "wired.com\/2014\/10\/stone-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521642472687300608",
  "text" : "Learn to Make Stone-Age Tools to Help Study the Origins of Language \/cc @PhilippBayer @Lobot http:\/\/t.co\/4Ynf836AbQ",
  "id" : 521642472687300608,
  "created_at" : "2014-10-13 12:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ZiOaM0iHY1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OGtb1YfJ2vo",
      "display_url" : "youtube.com\/watch?v=OGtb1Y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521599437333069824",
  "text" : "Kansas' Sex Toy Auction https:\/\/t.co\/ZiOaM0iHY1",
  "id" : 521599437333069824,
  "created_at" : "2014-10-13 09:52:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/xBReDYuuID",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/12\/walking-dead-vs-wildlife-the.html",
      "display_url" : "boingboing.net\/2014\/10\/12\/wal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521589313285672961",
  "text" : "Walking Dead vs Wildlife http:\/\/t.co\/xBReDYuuID",
  "id" : 521589313285672961,
  "created_at" : "2014-10-13 09:12:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/EoNwIrcHtg",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0022519311003754",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "521585532313534464",
  "geo" : { },
  "id_str" : "521585801663369216",
  "in_reply_to_user_id" : 14286491,
  "text" : "From \u00ABGroup selection and inclusive fitness are not equivalent; the Price equation vs. models and statistics\u00BB http:\/\/t.co\/EoNwIrcHtg",
  "id" : 521585801663369216,
  "in_reply_to_status_id" : 521585532313534464,
  "created_at" : "2014-10-13 08:58:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521585532313534464",
  "text" : "\u00ABWhat can go wrong when the Price equation is used [\u2026] can best be explained with the words of a famous Dutch football player\u00BB",
  "id" : 521585532313534464,
  "created_at" : "2014-10-13 08:57:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/qPZenHW5ib",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/timothy-e-kaldas\/lies-damned-lies-and-bill-mahers-statistics_b_5956278.html",
      "display_url" : "huffingtonpost.com\/timothy-e-kald\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520935040222773248",
  "text" : "RT @john_s_wilkins: Lies, Damned Lies, and Bill Maher's Statistics\u00A0|\u00A0Timothy E. Kaldas http:\/\/t.co\/qPZenHW5ib",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/qPZenHW5ib",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/timothy-e-kaldas\/lies-damned-lies-and-bill-mahers-statistics_b_5956278.html",
        "display_url" : "huffingtonpost.com\/timothy-e-kald\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520892025642553344",
    "text" : "Lies, Damned Lies, and Bill Maher's Statistics\u00A0|\u00A0Timothy E. Kaldas http:\/\/t.co\/qPZenHW5ib",
    "id" : 520892025642553344,
    "created_at" : "2014-10-11 11:01:51 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 520935040222773248,
  "created_at" : "2014-10-11 13:52:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110721195, 8.7584441737 ]
  },
  "id_str" : "520918854739189760",
  "text" : "\u00ABJedi passt als Religion auch gut zu dir, alleine weil f\u00FCr dich ein brauner Bademantel total praktisch w\u00E4re.\u00BB \u2014 \u00ABNenn mich Lube Skywalker.\u00BB",
  "id" : 520918854739189760,
  "created_at" : "2014-10-11 12:48:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520630416601264130",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112442595, 8.7504164748 ]
  },
  "id_str" : "520644015025586176",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @openSNPorg you will get an download link via email. Or at least you should. Currently our server is having some trouble. :)",
  "id" : 520644015025586176,
  "in_reply_to_status_id" : 520630416601264130,
  "created_at" : "2014-10-10 18:36:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anwen",
      "screen_name" : "eridisk",
      "indices" : [ 3, 11 ],
      "id_str" : "270043459",
      "id" : 270043459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/j5qlCG3MUo",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/an-open-letter-to-my-toddler-regarding-his-use-of-my-iphone",
      "display_url" : "mcsweeneys.net\/articles\/an-op\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520498561918980096",
  "text" : "RT @eridisk: 'To My Toddler, Regarding His Use of My iPhone' and other hilarious open letters\nhttp:\/\/t.co\/j5qlCG3MUo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/j5qlCG3MUo",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/an-open-letter-to-my-toddler-regarding-his-use-of-my-iphone",
        "display_url" : "mcsweeneys.net\/articles\/an-op\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520496270398734337",
    "text" : "'To My Toddler, Regarding His Use of My iPhone' and other hilarious open letters\nhttp:\/\/t.co\/j5qlCG3MUo",
    "id" : 520496270398734337,
    "created_at" : "2014-10-10 08:49:15 +0000",
    "user" : {
      "name" : "anwen",
      "screen_name" : "eridisk",
      "protected" : false,
      "id_str" : "270043459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000104867029\/0333b263a7b440f64c68733b84b4abc1_normal.jpeg",
      "id" : 270043459,
      "verified" : false
    }
  },
  "id" : 520498561918980096,
  "created_at" : "2014-10-10 08:58:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "indices" : [ 3, 10 ],
      "id_str" : "2849770550",
      "id" : 2849770550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520490348691615744",
  "text" : "RT @bik_f_: Hm, who else from BiK-F is on twitter?\n\n(We ask the void)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520458869995470848",
    "text" : "Hm, who else from BiK-F is on twitter?\n\n(We ask the void)",
    "id" : 520458869995470848,
    "created_at" : "2014-10-10 06:20:38 +0000",
    "user" : {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "protected" : false,
      "id_str" : "2849770550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520456619709452289\/DG1Gz8_e_normal.jpeg",
      "id" : 2849770550,
      "verified" : false
    }
  },
  "id" : 520490348691615744,
  "created_at" : "2014-10-10 08:25:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520473483839807488",
  "geo" : { },
  "id_str" : "520481565802233856",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch ordered the reboot, let\u2019s see what happens",
  "id" : 520481565802233856,
  "in_reply_to_status_id" : 520473483839807488,
  "created_at" : "2014-10-10 07:50:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520463210911375360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1111524639, 8.7516791148 ]
  },
  "id_str" : "520473365107056640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch again, will reboot it as soon as I'm in the office.",
  "id" : 520473365107056640,
  "in_reply_to_status_id" : 520463210911375360,
  "created_at" : "2014-10-10 07:18:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520251854740291584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138817706, 8.7532280199 ]
  },
  "id_str" : "520263052865069056",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo thanks for taking that much care. You're doing a great job. :-)",
  "id" : 520263052865069056,
  "in_reply_to_status_id" : 520251854740291584,
  "created_at" : "2014-10-09 17:22:32 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 19, 31 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520249861451837440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1127664934, 8.7517757727 ]
  },
  "id_str" : "520262898959261697",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx  @helgerausch! Will send you the PW later.",
  "id" : 520262898959261697,
  "in_reply_to_status_id" : 520249861451837440,
  "created_at" : "2014-10-09 17:21:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520176920835915776",
  "geo" : { },
  "id_str" : "520177189208481792",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer he rebooted the website!",
  "id" : 520177189208481792,
  "in_reply_to_status_id" : 520176920835915776,
  "created_at" : "2014-10-09 11:41:21 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520170016432738304",
  "geo" : { },
  "id_str" : "520170207734927360",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo grats! :)",
  "id" : 520170207734927360,
  "in_reply_to_status_id" : 520170016432738304,
  "created_at" : "2014-10-09 11:13:36 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 3, 15 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NbYQeVg665",
      "expanded_url" : "http:\/\/etsy.me\/1otUG1O",
      "display_url" : "etsy.me\/1otUG1O"
    } ]
  },
  "geo" : { },
  "id_str" : "520170179360075776",
  "text" : "RT @chapmangamo: My book arrived! HOORAAAY. Thanks if you bought it! I'll start dispatching as soon as possible http:\/\/t.co\/NbYQeVg665 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chapmangamo\/status\/520170016432738304\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/M9iPDvXMsg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzgD33wIUAAMJKb.jpg",
        "id_str" : "520170015354802176",
        "id" : 520170015354802176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzgD33wIUAAMJKb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 972
        } ],
        "display_url" : "pic.twitter.com\/M9iPDvXMsg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/NbYQeVg665",
        "expanded_url" : "http:\/\/etsy.me\/1otUG1O",
        "display_url" : "etsy.me\/1otUG1O"
      } ]
    },
    "geo" : { },
    "id_str" : "520170016432738304",
    "text" : "My book arrived! HOORAAAY. Thanks if you bought it! I'll start dispatching as soon as possible http:\/\/t.co\/NbYQeVg665 http:\/\/t.co\/M9iPDvXMsg",
    "id" : 520170016432738304,
    "created_at" : "2014-10-09 11:12:50 +0000",
    "user" : {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "protected" : false,
      "id_str" : "30633376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793772420616359937\/gpZg3fEE_normal.jpg",
      "id" : 30633376,
      "verified" : false
    }
  },
  "id" : 520170179360075776,
  "created_at" : "2014-10-09 11:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520167516862418944",
  "geo" : { },
  "id_str" : "520167632134475776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yep, looks like it.",
  "id" : 520167632134475776,
  "in_reply_to_status_id" : 520167516862418944,
  "created_at" : "2014-10-09 11:03:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520167038833405952",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer guess which website is down again! ;)",
  "id" : 520167038833405952,
  "created_at" : "2014-10-09 11:01:00 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723381426, 8.6275671257 ]
  },
  "id_str" : "520151956107841536",
  "text" : "Slide 1 f\u00FCr die Einf\u00FChrungsveranstaltung der Erstsemester: 'All hope abandon, ye who enter here'.",
  "id" : 520151956107841536,
  "created_at" : "2014-10-09 10:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1554007703, 8.6188380921 ]
  },
  "id_str" : "520149508463030272",
  "text" : "\u00ABEr rief an und meinte 'Hallo mein Schatz, ich wollte dir nur kurz eine gute Nacht w\u00FCnschen. Oh, moment, hier kotzt wer \u00FCber 3 Etagen!'\u00BB",
  "id" : 520149508463030272,
  "created_at" : "2014-10-09 09:51:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520135975776051200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724902587, 8.6277445592 ]
  },
  "id_str" : "520147318763708416",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yet another ugly theory slain by an ugly fact.",
  "id" : 520147318763708416,
  "in_reply_to_status_id" : 520135975776051200,
  "created_at" : "2014-10-09 09:42:39 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/WSjK65X77U",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3506",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520116966523416576",
  "text" : "you are awesome http:\/\/t.co\/WSjK65X77U",
  "id" : 520116966523416576,
  "created_at" : "2014-10-09 07:42:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/cPwTmrWq95",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/08\/where-wolves-fuck.html",
      "display_url" : "boingboing.net\/2014\/10\/08\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520116218205077504",
  "text" : "where wolves fuck http:\/\/t.co\/cPwTmrWq95",
  "id" : 520116218205077504,
  "created_at" : "2014-10-09 07:39:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Myers",
      "screen_name" : "rachelmyers",
      "indices" : [ 3, 15 ],
      "id_str" : "17204571",
      "id" : 17204571
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rachelmyers\/status\/520022564039827456\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iGEPu05Pkf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzd9wfxIcAEox-q.jpg",
      "id_str" : "520022554099347457",
      "id" : 520022554099347457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzd9wfxIcAEox-q.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 972
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 972
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 972
      } ],
      "display_url" : "pic.twitter.com\/iGEPu05Pkf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520101163413540864",
  "text" : "RT @rachelmyers: I'm so glad someone did this. http:\/\/t.co\/iGEPu05Pkf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rachelmyers\/status\/520022564039827456\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/iGEPu05Pkf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzd9wfxIcAEox-q.jpg",
        "id_str" : "520022554099347457",
        "id" : 520022554099347457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzd9wfxIcAEox-q.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 972
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 972
        } ],
        "display_url" : "pic.twitter.com\/iGEPu05Pkf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520022564039827456",
    "text" : "I'm so glad someone did this. http:\/\/t.co\/iGEPu05Pkf",
    "id" : 520022564039827456,
    "created_at" : "2014-10-09 01:26:55 +0000",
    "user" : {
      "name" : "Rachel Myers",
      "screen_name" : "rachelmyers",
      "protected" : false,
      "id_str" : "17204571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763508597112213504\/LVWnMnPO_normal.jpg",
      "id" : 17204571,
      "verified" : false
    }
  },
  "id" : 520101163413540864,
  "created_at" : "2014-10-09 06:39:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "indices" : [ 3, 14 ],
      "id_str" : "16042794",
      "id" : 16042794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L5ryTuTqaG",
      "expanded_url" : "http:\/\/trib.al\/1cmtQv9",
      "display_url" : "trib.al\/1cmtQv9"
    } ]
  },
  "geo" : { },
  "id_str" : "519973499713388544",
  "text" : "RT @GuardianUS: Jennifer Lawrence's scathing response to her nude photo hack is a \"hell yes\" moment for feminists http:\/\/t.co\/L5ryTuTqaG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/L5ryTuTqaG",
        "expanded_url" : "http:\/\/trib.al\/1cmtQv9",
        "display_url" : "trib.al\/1cmtQv9"
      } ]
    },
    "geo" : { },
    "id_str" : "519933774931705856",
    "text" : "Jennifer Lawrence's scathing response to her nude photo hack is a \"hell yes\" moment for feminists http:\/\/t.co\/L5ryTuTqaG",
    "id" : 519933774931705856,
    "created_at" : "2014-10-08 19:34:06 +0000",
    "user" : {
      "name" : "Guardian US",
      "screen_name" : "GuardianUS",
      "protected" : false,
      "id_str" : "16042794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888149953008156673\/-jwMr5r3_normal.jpg",
      "id" : 16042794,
      "verified" : true
    }
  },
  "id" : 519973499713388544,
  "created_at" : "2014-10-08 22:11:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FindingAda",
      "screen_name" : "FindingAda",
      "indices" : [ 3, 14 ],
      "id_str" : "16736682",
      "id" : 16736682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YcyRoqYYqL",
      "expanded_url" : "http:\/\/ow.ly\/CmuLj",
      "display_url" : "ow.ly\/CmuLj"
    } ]
  },
  "geo" : { },
  "id_str" : "519936482891792385",
  "text" : "RT @FindingAda: Do you know a woman in STEM who inspires you? Add her story to our list and share her achievements! http:\/\/t.co\/YcyRoqYYqL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/YcyRoqYYqL",
        "expanded_url" : "http:\/\/ow.ly\/CmuLj",
        "display_url" : "ow.ly\/CmuLj"
      } ]
    },
    "geo" : { },
    "id_str" : "519890060700024833",
    "text" : "Do you know a woman in STEM who inspires you? Add her story to our list and share her achievements! http:\/\/t.co\/YcyRoqYYqL",
    "id" : 519890060700024833,
    "created_at" : "2014-10-08 16:40:24 +0000",
    "user" : {
      "name" : "FindingAda",
      "screen_name" : "FindingAda",
      "protected" : false,
      "id_str" : "16736682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000684191993\/decf45206a13b74244348ed7fc123585_normal.jpeg",
      "id" : 16736682,
      "verified" : true
    }
  },
  "id" : 519936482891792385,
  "created_at" : "2014-10-08 19:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dedalus Root",
      "screen_name" : "DedalusRoot",
      "indices" : [ 0, 12 ],
      "id_str" : "112733212",
      "id" : 112733212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519891748928385024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135616011, 8.7530257562 ]
  },
  "id_str" : "519912570992742400",
  "in_reply_to_user_id" : 112733212,
  "text" : "@DedalusRoot ich bin damals auf den gleichen Post gesto\u00DFen und hab wegen ihm das Buch gelesen. ;)",
  "id" : 519912570992742400,
  "in_reply_to_status_id" : 519891748928385024,
  "created_at" : "2014-10-08 18:09:51 +0000",
  "in_reply_to_screen_name" : "DedalusRoot",
  "in_reply_to_user_id_str" : "112733212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dedalus Root",
      "screen_name" : "DedalusRoot",
      "indices" : [ 0, 12 ],
      "id_str" : "112733212",
      "id" : 112733212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/UF2vKjYYED",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/633766679",
      "display_url" : "goodreads.com\/review\/show\/63\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519855225973112832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1785464119, 8.6079681221 ]
  },
  "id_str" : "519873397250355201",
  "in_reply_to_user_id" : 112733212,
  "text" : "@DedalusRoot do not read https:\/\/t.co\/UF2vKjYYED",
  "id" : 519873397250355201,
  "in_reply_to_status_id" : 519855225973112832,
  "created_at" : "2014-10-08 15:34:11 +0000",
  "in_reply_to_screen_name" : "DedalusRoot",
  "in_reply_to_user_id_str" : "112733212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519859956171145216",
  "text" : "Spend 4 hours playing around with the facet feature of ggplot2.",
  "id" : 519859956171145216,
  "created_at" : "2014-10-08 14:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519854151618940928",
  "geo" : { },
  "id_str" : "519854681519304705",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I can do that!",
  "id" : 519854681519304705,
  "in_reply_to_status_id" : 519854151618940928,
  "created_at" : "2014-10-08 14:19:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/qYrhABIMlo",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=H4TKHzcyEWU",
      "display_url" : "youtube.com\/watch?v=H4TKHz\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519845403844296705",
  "geo" : { },
  "id_str" : "519848922341453824",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/qYrhABIMlo ?",
  "id" : 519848922341453824,
  "in_reply_to_status_id" : 519845403844296705,
  "created_at" : "2014-10-08 13:56:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1795174081, 8.604879654 ]
  },
  "id_str" : "519826113754054657",
  "text" : "\u00ABLass uns kontextfreie Grammatiken machen!\u00BB \u2014 \u00ABDarunter f\u00E4llt hier doch jedes Gespr\u00E4ch?\u00BB",
  "id" : 519826113754054657,
  "created_at" : "2014-10-08 12:26:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceslam",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172318052, 8.6275497824 ]
  },
  "id_str" : "519812264359366656",
  "text" : "\u00ABIch kann an dem #scienceslam Termin leider nicht. Ich geh lieber mit meiner Freundin ins Bett, da ist der Frauenanteil dann wenigstens 50%\u00BB",
  "id" : 519812264359366656,
  "created_at" : "2014-10-08 11:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 3, 18 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "redpenblackpen",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519762353512906752",
  "text" : "RT @BioDataGanache: OK- prerelease of the new #redpenblackpen comic since my website seems to be down. A Fine Trip Spoiled http:\/\/t.co\/871Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BioDataGanache\/status\/519733579773779968\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/871YJP2oRM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzZ277qCAAAcNVk.jpg",
        "id_str" : "519733579006214144",
        "id" : 519733579006214144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzZ277qCAAAcNVk.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 909
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1551
        }, {
          "h" : 2174,
          "resize" : "fit",
          "w" : 1646
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 515
        } ],
        "display_url" : "pic.twitter.com\/871YJP2oRM"
      } ],
      "hashtags" : [ {
        "text" : "redpenblackpen",
        "indices" : [ 26, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519733579773779968",
    "text" : "OK- prerelease of the new #redpenblackpen comic since my website seems to be down. A Fine Trip Spoiled http:\/\/t.co\/871YJP2oRM",
    "id" : 519733579773779968,
    "created_at" : "2014-10-08 06:18:36 +0000",
    "user" : {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "protected" : false,
      "id_str" : "1040758742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825446808696483840\/nMI6-h4y_normal.jpg",
      "id" : 1040758742,
      "verified" : false
    }
  },
  "id" : 519762353512906752,
  "created_at" : "2014-10-08 08:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/P5U2CdF6sa",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/XlW9cE1EDLmXC\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/XlW9cE1E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519760808952094721",
  "text" : "The moment I figure out my R history is somehow gone\u2026 http:\/\/t.co\/P5U2CdF6sa",
  "id" : 519760808952094721,
  "created_at" : "2014-10-08 08:06:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/TyPaopDvF3",
      "expanded_url" : "http:\/\/toe.prx.org\/2014\/10\/enchanted-by-numbers\/",
      "display_url" : "toe.prx.org\/2014\/10\/enchan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1733707392, 8.6276942966 ]
  },
  "id_str" : "519750170762698752",
  "text" : "Enchanting by Numbers http:\/\/t.co\/TyPaopDvF3",
  "id" : 519750170762698752,
  "created_at" : "2014-10-08 07:24:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1111602793, 8.7515705231 ]
  },
  "id_str" : "519600250466496512",
  "text" : "\u00ABWir sollen die Piraten aus dem WLAN-Passwort nehmen? Wie w\u00E4re es mit 'undimmereinehandbreitcolalightunterdemkiel'?\u00BB",
  "id" : 519600250466496512,
  "created_at" : "2014-10-07 21:28:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "indices" : [ 3, 8 ],
      "id_str" : "516875194",
      "id" : 516875194
    }, {
      "name" : "Feminist Frequency",
      "screen_name" : "femfreq",
      "indices" : [ 19, 27 ],
      "id_str" : "56768257",
      "id" : 56768257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519581882883649536",
  "text" : "RT @xoxo: At XOXO, @femfreq's Anita Sarkeesian laid out the tactics used to discredit her, and many other women, online: http:\/\/t.co\/BaXrYw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Feminist Frequency",
        "screen_name" : "femfreq",
        "indices" : [ 9, 17 ],
        "id_str" : "56768257",
        "id" : 56768257
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/BaXrYwWqOl",
        "expanded_url" : "http:\/\/youtu.be\/ah8mhDW6Shs",
        "display_url" : "youtu.be\/ah8mhDW6Shs"
      } ]
    },
    "geo" : { },
    "id_str" : "519533433949655040",
    "text" : "At XOXO, @femfreq's Anita Sarkeesian laid out the tactics used to discredit her, and many other women, online: http:\/\/t.co\/BaXrYwWqOl",
    "id" : 519533433949655040,
    "created_at" : "2014-10-07 17:03:17 +0000",
    "user" : {
      "name" : "XOXO",
      "screen_name" : "xoxo",
      "protected" : false,
      "id_str" : "516875194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883531581821829121\/xJ16ds3f_normal.jpg",
      "id" : 516875194,
      "verified" : false
    }
  },
  "id" : 519581882883649536,
  "created_at" : "2014-10-07 20:15:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gunter",
      "screen_name" : "girlscientist",
      "indices" : [ 3, 17 ],
      "id_str" : "17047208",
      "id" : 17047208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519544633370877953",
  "text" : "RT @girlscientist: Speaker: \"there's a black box between the data and you; it's called bioinformatics.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519514219335942144",
    "text" : "Speaker: \"there's a black box between the data and you; it's called bioinformatics.\"",
    "id" : 519514219335942144,
    "created_at" : "2014-10-07 15:46:56 +0000",
    "user" : {
      "name" : "Chris Gunter",
      "screen_name" : "girlscientist",
      "protected" : false,
      "id_str" : "17047208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683835610126106624\/OMdS5B2w_normal.jpg",
      "id" : 17047208,
      "verified" : false
    }
  },
  "id" : 519544633370877953,
  "created_at" : "2014-10-07 17:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519472159240888321",
  "text" : "\u00ABMit dem Volumentarif meines Opas hab ich seine Rente verprasst. Jetzt hat er keine Z\u00E4hne mehr, aber das Geld reicht sowieso nur f\u00FCr Ramen.\u00BB",
  "id" : 519472159240888321,
  "created_at" : "2014-10-07 12:59:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/rIYFdpcEI0",
      "expanded_url" : "http:\/\/blog.longreads.com\/2014\/10\/01\/nightshift-excerpts-from-an-instagram-essay\/",
      "display_url" : "blog.longreads.com\/2014\/10\/01\/nig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519463617847373824",
  "text" : "\u00ABa story always unfolding, unraveling, shifting direction. Another word for this is\u00A0journalism\u00BB http:\/\/t.co\/rIYFdpcEI0",
  "id" : 519463617847373824,
  "created_at" : "2014-10-07 12:25:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/66nzY9Tbkq",
      "expanded_url" : "http:\/\/instagram.com\/p\/t2bmiWBwmE\/",
      "display_url" : "instagram.com\/p\/t2bmiWBwmE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173591317, 8.633167204 ]
  },
  "id_str" : "519457094756737024",
  "text" : "the waiting game @ Uni Campus Riedberg, Frankfurt am Main http:\/\/t.co\/66nzY9Tbkq",
  "id" : 519457094756737024,
  "created_at" : "2014-10-07 11:59:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/DrMYIdqcOs",
      "expanded_url" : "http:\/\/emperorx.bandcamp.com\/album\/10000-year-earworm-to-discourage-settlement-near-nuclear-waste-repositories",
      "display_url" : "emperorx.bandcamp.com\/album\/10000-ye\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519447565587451904",
  "geo" : { },
  "id_str" : "519448071550558208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot because that would indicate that we should fear the construction site next to us. http:\/\/t.co\/DrMYIdqcOs",
  "id" : 519448071550558208,
  "in_reply_to_status_id" : 519447565587451904,
  "created_at" : "2014-10-07 11:24:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/GvqlHB9Vro",
      "expanded_url" : "http:\/\/www.marymeetsdolly.com\/blog\/uploads\/transgenickitty.jpg",
      "display_url" : "marymeetsdolly.com\/blog\/uploads\/t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519445798585925632",
  "geo" : { },
  "id_str" : "519446850752249856",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you could go for a live snake, using yet another Nobel-winning technique! http:\/\/t.co\/GvqlHB9Vro",
  "id" : 519446850752249856,
  "in_reply_to_status_id" : 519445798585925632,
  "created_at" : "2014-10-07 11:19:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519441318356189184",
  "geo" : { },
  "id_str" : "519444123829686273",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot stretching your business idea?",
  "id" : 519444123829686273,
  "in_reply_to_status_id" : 519441318356189184,
  "created_at" : "2014-10-07 11:08:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/8cTFQxpB40",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=oSk-C7W0L28",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519430416538009601",
  "text" : "John Oliver Demands to Know How Ayn Rand Is \u2018Still a Thing\u2019 https:\/\/t.co\/8cTFQxpB40",
  "id" : 519430416538009601,
  "created_at" : "2014-10-07 10:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 7, 14 ],
      "id_str" : "26962623",
      "id" : 26962623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519428936317812736",
  "geo" : { },
  "id_str" : "519429565308235776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @der_ak and soon the Nobel peace prize will be yours.",
  "id" : 519429565308235776,
  "in_reply_to_status_id" : 519428936317812736,
  "created_at" : "2014-10-07 10:10:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 19, 25 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 30, 37 ],
      "id_str" : "26962623",
      "id" : 26962623
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 39, 55 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/YO3HrflvyF",
      "expanded_url" : "http:\/\/i.imgur.com\/kgYcUya.png",
      "display_url" : "i.imgur.com\/kgYcUya.png"
    } ]
  },
  "geo" : { },
  "id_str" : "519427654001647616",
  "text" : "Please build this, @Lobot! RT @der_ak: @gedankenstuecke in fact it was. http:\/\/t.co\/YO3HrflvyF",
  "id" : 519427654001647616,
  "created_at" : "2014-10-07 10:02:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519425024680534016",
  "text" : "Just maybe I misread the Nobel announcement and thought it was awarded for inventing a \u2018blue light-emitting dildo\u2019\u2026",
  "id" : 519425024680534016,
  "created_at" : "2014-10-07 09:52:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 3, 13 ],
      "id_str" : "331228486",
      "id" : 331228486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519416920123408384",
  "text" : "RT @DevilleSy: If you speak English with a Swedish accent, it's the best week of the year to place prank phone calls to your colleagues. #N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nobel2014",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519033078086639617",
    "text" : "If you speak English with a Swedish accent, it's the best week of the year to place prank phone calls to your colleagues. #Nobel2014",
    "id" : 519033078086639617,
    "created_at" : "2014-10-06 07:55:03 +0000",
    "user" : {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "protected" : false,
      "id_str" : "331228486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887046588954226688\/p3UlM_8C_normal.jpg",
      "id" : 331228486,
      "verified" : false
    }
  },
  "id" : 519416920123408384,
  "created_at" : "2014-10-07 09:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CNfCrLtPXz",
      "expanded_url" : "http:\/\/petewarden.com\/2014\/10\/05\/why-nerd-culture-must-die\/",
      "display_url" : "petewarden.com\/2014\/10\/05\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519416602681692160",
  "text" : "Calling time on nerd culture: \u00ABOur ingrained sense of victimization has become a perverse justification for bullying\u00BB http:\/\/t.co\/CNfCrLtPXz",
  "id" : 519416602681692160,
  "created_at" : "2014-10-07 09:19:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/PHQYnV8qxB",
      "expanded_url" : "http:\/\/michael-balter.blogspot.co.uk\/2014\/10\/why-i-have-taken-leave-of-absence-from.html",
      "display_url" : "michael-balter.blogspot.co.uk\/2014\/10\/why-i-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519410322244112384",
  "text" : "\u00ABWhy I have taken a leave of absence from Science: to protest the abrupt firing of 4 colleagues\u00BB http:\/\/t.co\/PHQYnV8qxB",
  "id" : 519410322244112384,
  "created_at" : "2014-10-07 08:54:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152005677, 8.7503281491 ]
  },
  "id_str" : "519265107969585152",
  "text" : "\u00ABDu hast einen wundervollen Humor.\u00BB \u2013 \u00ABWie alle Nazis!\u00BB",
  "id" : 519265107969585152,
  "created_at" : "2014-10-06 23:17:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/XLHlbYvacq",
      "expanded_url" : "http:\/\/blog.openhelix.eu\/?p=20018&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+openhelix%2FGhpE+%28The+OpenHelix+Blog%29",
      "display_url" : "blog.openhelix.eu\/?p=20018&utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519257989531062272",
  "text" : "Great work: \u00ABBioinformatics tools extracted from a typical mammalian genome project\u00BB  http:\/\/t.co\/XLHlbYvacq",
  "id" : 519257989531062272,
  "created_at" : "2014-10-06 22:48:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/XLHlbYvacq",
      "expanded_url" : "http:\/\/blog.openhelix.eu\/?p=20018&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+openhelix%2FGhpE+%28The+OpenHelix+Blog%29",
      "display_url" : "blog.openhelix.eu\/?p=20018&utm_s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114126, 8.752301 ]
  },
  "id_str" : "519257232127848448",
  "text" : "\u00ABironically, RepeatMasker was referenced so many times I began to stop marking it up at one point\u00BB http:\/\/t.co\/XLHlbYvacq",
  "id" : 519257232127848448,
  "created_at" : "2014-10-06 22:45:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6h2dfQsEOC",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/49",
      "display_url" : "existentialcomics.com\/comic\/49"
    } ]
  },
  "geo" : { },
  "id_str" : "519255970405703680",
  "text" : "The Philosophy of the Science of Poker http:\/\/t.co\/6h2dfQsEOC",
  "id" : 519255970405703680,
  "created_at" : "2014-10-06 22:40:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/OPdiFjVQw4",
      "expanded_url" : "http:\/\/instagram.com\/p\/t02djIhwi_\/",
      "display_url" : "instagram.com\/p\/t02djIhwi_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519234751782060032",
  "text" : "Now try aligning that http:\/\/t.co\/OPdiFjVQw4",
  "id" : 519234751782060032,
  "created_at" : "2014-10-06 21:16:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 81, 93 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110702349, 8.7585496795 ]
  },
  "id_str" : "519172146036486144",
  "text" : "\u00ABEssen? Ich glaube ich verdaue immer noch das reichhaltige Fr\u00FChst\u00FCck was wir mit @helgerausch hatten!\u00BB",
  "id" : 519172146036486144,
  "created_at" : "2014-10-06 17:07:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1731008221, 8.6276064441 ]
  },
  "id_str" : "519156704974757888",
  "text" : "\u00ABDen ganzen Tag stehst du jetzt? Tut das nicht total weh?\u00BB \u2014 \u00ABUnd wie, vor allem in Vibrams!\u00BB",
  "id" : 519156704974757888,
  "created_at" : "2014-10-06 16:06:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519140746721787904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723093773, 8.627567282 ]
  },
  "id_str" : "519141706567254016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i think we already have some at home.",
  "id" : 519141706567254016,
  "in_reply_to_status_id" : 519140746721787904,
  "created_at" : "2014-10-06 15:06:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/mJNjRtrUUj",
      "expanded_url" : "http:\/\/instagram.com\/p\/t0MEuNhwo6\/",
      "display_url" : "instagram.com\/p\/t0MEuNhwo6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519141473611026432",
  "text" : "Woody http:\/\/t.co\/mJNjRtrUUj",
  "id" : 519141473611026432,
  "created_at" : "2014-10-06 15:05:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519140329728262144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724244608, 8.6276629195 ]
  },
  "id_str" : "519140845145321473",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot maybe stem cells can solve that down the road.",
  "id" : 519140845145321473,
  "in_reply_to_status_id" : 519140329728262144,
  "created_at" : "2014-10-06 15:03:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zeynep tufekci",
      "screen_name" : "zeynep",
      "indices" : [ 3, 10 ],
      "id_str" : "65375759",
      "id" : 65375759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519135768074543104",
  "text" : "RT @zeynep: By SHARING, I don't mean subletting couch or moonlighting as taxi driver. People crave non-market interactions &amp; protests incor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519132382285557761",
    "text" : "By SHARING, I don't mean subletting couch or moonlighting as taxi driver. People crave non-market interactions &amp; protests incorporate them.",
    "id" : 519132382285557761,
    "created_at" : "2014-10-06 14:29:39 +0000",
    "user" : {
      "name" : "zeynep tufekci",
      "screen_name" : "zeynep",
      "protected" : false,
      "id_str" : "65375759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852492056798916608\/bydhBkye_normal.jpg",
      "id" : 65375759,
      "verified" : true
    }
  },
  "id" : 519135768074543104,
  "created_at" : "2014-10-06 14:43:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/aiMwgi0p2P",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/2014\/oct\/05\/laboratory-penises-test-on-men",
      "display_url" : "theguardian.com\/science\/2014\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519131836044574720",
  "text" : "Good news, @lobot! Scientists ready to test lab-grown penises on men http:\/\/t.co\/aiMwgi0p2P",
  "id" : 519131836044574720,
  "created_at" : "2014-10-06 14:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doc Bastard",
      "screen_name" : "DocBastard",
      "indices" : [ 3, 14 ],
      "id_str" : "468669904",
      "id" : 468669904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DocBastard\/status\/518967699003940865\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DVZz8Y5XxS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzO-X0hIcAA4S0W.jpg",
      "id_str" : "518967698521616384",
      "id" : 518967698521616384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzO-X0hIcAA4S0W.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/DVZz8Y5XxS"
    } ],
    "hashtags" : [ {
      "text" : "medicine",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519124573502332928",
  "text" : "RT @DocBastard: Advice from a patient. Every doctor in the world should read this every day. #medicine http:\/\/t.co\/DVZz8Y5XxS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DocBastard\/status\/518967699003940865\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/DVZz8Y5XxS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzO-X0hIcAA4S0W.jpg",
        "id_str" : "518967698521616384",
        "id" : 518967698521616384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzO-X0hIcAA4S0W.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 785,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 785,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 785,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/DVZz8Y5XxS"
      } ],
      "hashtags" : [ {
        "text" : "medicine",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518967699003940865",
    "text" : "Advice from a patient. Every doctor in the world should read this every day. #medicine http:\/\/t.co\/DVZz8Y5XxS",
    "id" : 518967699003940865,
    "created_at" : "2014-10-06 03:35:16 +0000",
    "user" : {
      "name" : "Doc Bastard",
      "screen_name" : "DocBastard",
      "protected" : false,
      "id_str" : "468669904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3364929045\/ed0e9db56d051f41aaea0c77ebfa6e0e_normal.jpeg",
      "id" : 468669904,
      "verified" : false
    }
  },
  "id" : 519124573502332928,
  "created_at" : "2014-10-06 13:58:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/bedLyZjJQm",
      "expanded_url" : "http:\/\/i.lvme.me\/cz1xdkx.jpg",
      "display_url" : "i.lvme.me\/cz1xdkx.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172371226, 8.6275562623 ]
  },
  "id_str" : "519099540235116545",
  "text" : "In my Inbox: \u00ABSanger Sequencing Promotion\u00BB http:\/\/t.co\/bedLyZjJQm",
  "id" : 519099540235116545,
  "created_at" : "2014-10-06 12:19:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519095608200925184",
  "geo" : { },
  "id_str" : "519097998559952896",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @PhilippBayer in that case you can have dinner alone!",
  "id" : 519097998559952896,
  "in_reply_to_status_id" : 519095608200925184,
  "created_at" : "2014-10-06 12:13:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519097767260868608",
  "geo" : { },
  "id_str" : "519097901965131776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot :hipster:",
  "id" : 519097901965131776,
  "in_reply_to_status_id" : 519097767260868608,
  "created_at" : "2014-10-06 12:12:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519090202858758144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172343888, 8.6275864896 ]
  },
  "id_str" : "519094329076629505",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @PhilippBayer you are the consultant. Whatever you say we will do. Though I'm not sure if \uD83D\uDCA9 results are enough to be agricultural.",
  "id" : 519094329076629505,
  "in_reply_to_status_id" : 519090202858758144,
  "created_at" : "2014-10-06 11:58:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519087974441816065",
  "geo" : { },
  "id_str" : "519088642061787136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if @Lobot hurries up we might even do form signing for whatever  openSNP will end up being. :p",
  "id" : 519088642061787136,
  "in_reply_to_status_id" : 519087974441816065,
  "created_at" : "2014-10-06 11:35:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519085858549669888",
  "geo" : { },
  "id_str" : "519086244761194496",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer then you better drop by before you leave ;)",
  "id" : 519086244761194496,
  "in_reply_to_status_id" : 519085858549669888,
  "created_at" : "2014-10-06 11:26:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/miYfa2lNDg",
      "expanded_url" : "http:\/\/instagram.com\/p\/tzkMl7BwjT\/",
      "display_url" : "instagram.com\/p\/tzkMl7BwjT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519053782299054080",
  "text" : "Wuff! http:\/\/t.co\/miYfa2lNDg",
  "id" : 519053782299054080,
  "created_at" : "2014-10-06 09:17:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519038761871880192",
  "geo" : { },
  "id_str" : "519039332280438784",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke \u2018untergekommen\u2019 ;)",
  "id" : 519039332280438784,
  "in_reply_to_status_id" : 519038761871880192,
  "created_at" : "2014-10-06 08:19:54 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/os7MByC1nj",
      "expanded_url" : "http:\/\/instagram.com\/p\/tzdSIvBwuJ\/",
      "display_url" : "instagram.com\/p\/tzdSIvBwuJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "519038579851284480",
  "text" : "\u00ABIch habe da was phallusf\u00F6rmiges f\u00FCr dich!\u00BB http:\/\/t.co\/os7MByC1nj",
  "id" : 519038579851284480,
  "created_at" : "2014-10-06 08:16:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 3, 12 ],
      "id_str" : "19530289",
      "id" : 19530289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/T2KYkfW4HR",
      "expanded_url" : "http:\/\/laurie-penny.com\/on-weev-fascism-and-the-free-internet\/",
      "display_url" : "laurie-penny.com\/on-weev-fascis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519025497926541312",
  "text" : "RT @PennyRed: On Weev, fascism and the free internet. http:\/\/t.co\/T2KYkfW4HR I really wish I hadn't had to write this blog.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/T2KYkfW4HR",
        "expanded_url" : "http:\/\/laurie-penny.com\/on-weev-fascism-and-the-free-internet\/",
        "display_url" : "laurie-penny.com\/on-weev-fascis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518936994677014528",
    "text" : "On Weev, fascism and the free internet. http:\/\/t.co\/T2KYkfW4HR I really wish I hadn't had to write this blog.",
    "id" : 518936994677014528,
    "created_at" : "2014-10-06 01:33:15 +0000",
    "user" : {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "protected" : false,
      "id_str" : "19530289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887966692877504512\/hrvuIg4n_normal.jpg",
      "id" : 19530289,
      "verified" : true
    }
  },
  "id" : 519025497926541312,
  "created_at" : "2014-10-06 07:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dQPXAxfSE8",
      "expanded_url" : "http:\/\/michaelnielsen.org\/blog\/three-myths-about-scientific-peer-review\/",
      "display_url" : "michaelnielsen.org\/blog\/three-myt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518893220328394753",
  "text" : "RT @BioMickWatson: \u201CEditorial peer review, although widely used, is largely untested and its effects are uncertain\u201D http:\/\/t.co\/dQPXAxfSE8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/dQPXAxfSE8",
        "expanded_url" : "http:\/\/michaelnielsen.org\/blog\/three-myths-about-scientific-peer-review\/",
        "display_url" : "michaelnielsen.org\/blog\/three-myt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518853107338735616",
    "text" : "\u201CEditorial peer review, although widely used, is largely untested and its effects are uncertain\u201D http:\/\/t.co\/dQPXAxfSE8",
    "id" : 518853107338735616,
    "created_at" : "2014-10-05 19:59:55 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 518893220328394753,
  "created_at" : "2014-10-05 22:39:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1111535176, 8.7516633992 ]
  },
  "id_str" : "518889517567463424",
  "text" : "The weekend is finally over. Now I could need a day off.",
  "id" : 518889517567463424,
  "created_at" : "2014-10-05 22:24:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceslam",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6856983313, 7.1523329752 ]
  },
  "id_str" : "518841025985806337",
  "text" : "VWLer bei der 'Save The World' bestreitet seinen #scienceslam Beitrag mit einem Dreiklang aus Sexismus, Ableismus und Lookismus. m(",
  "id" : 518841025985806337,
  "created_at" : "2014-10-05 19:11:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518839191967662081",
  "text" : "RT @Lobot: Science Slam in Bonn. Sieben machen mit, darunter eine Frau, sie tritt als einzige nicht allein auf und hat als einzige kein Hea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.7398012058, 7.1322955728 ]
    },
    "id_str" : "518838343879368704",
    "text" : "Science Slam in Bonn. Sieben machen mit, darunter eine Frau, sie tritt als einzige nicht allein auf und hat als einzige kein Headset. Why?!",
    "id" : 518838343879368704,
    "created_at" : "2014-10-05 19:01:15 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 518839191967662081,
  "created_at" : "2014-10-05 19:04:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 3, 10 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Vb4lzMJh8J",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC27565\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518817368395759617",
  "text" : "RT @nplhse: On comparing apples and oranges: http:\/\/t.co\/Vb4lzMJh8J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Vb4lzMJh8J",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC27565\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518817021925265408",
    "text" : "On comparing apples and oranges: http:\/\/t.co\/Vb4lzMJh8J",
    "id" : 518817021925265408,
    "created_at" : "2014-10-05 17:36:31 +0000",
    "user" : {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "protected" : false,
      "id_str" : "111716214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511134543667920896\/dxDalEyT_normal.jpeg",
      "id" : 111716214,
      "verified" : false
    }
  },
  "id" : 518817368395759617,
  "created_at" : "2014-10-05 17:37:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Johnson",
      "screen_name" : "Green_Footballs",
      "indices" : [ 3, 19 ],
      "id_str" : "21785215",
      "id" : 21785215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518802413411921922",
  "text" : "RT @Green_Footballs: I wonder if all the conservatives yelling that Ebola might become airborne realize it means they now believe in evolut\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518196513940336640",
    "text" : "I wonder if all the conservatives yelling that Ebola might become airborne realize it means they now believe in evolution?",
    "id" : 518196513940336640,
    "created_at" : "2014-10-04 00:30:51 +0000",
    "user" : {
      "name" : "Charles Johnson",
      "screen_name" : "Green_Footballs",
      "protected" : false,
      "id_str" : "21785215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649280758675214336\/EskyPGto_normal.jpg",
      "id" : 21785215,
      "verified" : true
    }
  },
  "id" : 518802413411921922,
  "created_at" : "2014-10-05 16:38:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/ARAY8rross",
      "expanded_url" : "http:\/\/instagram.com\/p\/txw_YPhwpz\/",
      "display_url" : "instagram.com\/p\/txw_YPhwpz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "518800440989716480",
  "text" : "Now my name badge fits. http:\/\/t.co\/ARAY8rross",
  "id" : 518800440989716480,
  "created_at" : "2014-10-05 16:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139432099, 8.7530773133 ]
  },
  "id_str" : "518737778524569600",
  "text" : "\u00ABIch stecke dir so gerne Dinge \u00FCberall rein!\u00BB \u2014 \u00ABAusgezeichnet, ich hab Hunger. F\u00FCtter mich!\u00BB",
  "id" : 518737778524569600,
  "created_at" : "2014-10-05 12:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/UnExeMcEjq",
      "expanded_url" : "http:\/\/instagram.com\/p\/tw-ZMMhwlO\/",
      "display_url" : "instagram.com\/p\/tw-ZMMhwlO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "518689176762736640",
  "text" : "\u00ABWenn sie mal wirklich einen Schlaganfall hat werden wir alle nur lachen und niedliche Fotos machen.\u00BB http:\/\/t.co\/UnExeMcEjq",
  "id" : 518689176762736640,
  "created_at" : "2014-10-05 09:08:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/DSxj4TKdIm",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/03\/tangled-fox-cub-rescued-massa.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2014\/10\/03\/tan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672, 8.283027 ]
  },
  "id_str" : "518687618650103808",
  "text" : "Tangled Fox cub rescued, massaged http:\/\/t.co\/DSxj4TKdIm",
  "id" : 518687618650103808,
  "created_at" : "2014-10-05 09:02:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/U6Aydyc4k6",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/-2pginrx4wY\/dogs-of-the-world-illustrated.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518686356282023937",
  "text" : "Dogs of the world, illustrated and grouped by\u00A0geography http:\/\/t.co\/U6Aydyc4k6",
  "id" : 518686356282023937,
  "created_at" : "2014-10-05 08:57:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518535653781303296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1105637674, 8.7542064318 ]
  },
  "id_str" : "518678797177356288",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer too bad for me! :p",
  "id" : 518678797177356288,
  "in_reply_to_status_id" : 518535653781303296,
  "created_at" : "2014-10-05 08:27:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1105637674, 8.7542064318 ]
  },
  "id_str" : "518678691061448704",
  "text" : "\u00ABOh Nein! Ich komme gar nicht an mein Telefon weil so viele Penisse davor liegen!\u00BB",
  "id" : 518678691061448704,
  "created_at" : "2014-10-05 08:26:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/jnT6FHlb3I",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/3IqWKAOFq20\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115341, 8.750351 ]
  },
  "id_str" : "518520110995496960",
  "text" : "\u00ABK\u00F6nnte uns das auch passieren?\u00BB Die Antwort? Bald auf Twitter! http:\/\/t.co\/jnT6FHlb3I",
  "id" : 518520110995496960,
  "created_at" : "2014-10-04 21:56:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518473488437637121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115341186, 8.750350952 ]
  },
  "id_str" : "518518706096586752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u00ABWhen the pins are excited, they bounce all around the shear line\u00BB",
  "id" : 518518706096586752,
  "in_reply_to_status_id" : 518473488437637121,
  "created_at" : "2014-10-04 21:51:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110666634, 8.7519255033 ]
  },
  "id_str" : "518441742530793473",
  "text" : "\u00ABMir ist aufgefallen das Urethral sounding &amp; Lock picking voll \u00E4hnlich sind. Man muss den Spanner nicht ganz reinschieben damit es geil ist\u00BB",
  "id" : 518441742530793473,
  "created_at" : "2014-10-04 16:45:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518340380933111808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6234040473, 8.8953235596 ]
  },
  "id_str" : "518428473409683457",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer when will you arrive? :)",
  "id" : 518428473409683457,
  "in_reply_to_status_id" : 518340380933111808,
  "created_at" : "2014-10-04 15:52:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Proletarische Gefechtsf\u00FChrung",
      "screen_name" : "Piratenlily",
      "indices" : [ 0, 12 ],
      "id_str" : "51749563",
      "id" : 51749563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518351463303901185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.8732748786, 11.7920332326 ]
  },
  "id_str" : "518392572621103106",
  "in_reply_to_user_id" : 51749563,
  "text" : "@Piratenlily du hast dich da vertan: Desintegration eindrucksvoll demonstriert. Bekommen die Piraten aber auch ohne meine Hilfe ganz gut hin",
  "id" : 518392572621103106,
  "in_reply_to_status_id" : 518351463303901185,
  "created_at" : "2014-10-04 13:29:55 +0000",
  "in_reply_to_screen_name" : "Piratenlily",
  "in_reply_to_user_id_str" : "51749563",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 0, 7 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518182999494787073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5556352948, 13.3937547323 ]
  },
  "id_str" : "518192772265050113",
  "in_reply_to_user_id" : 15353398,
  "text" : "@zinken der feine Unterschied zwischen 'Director' &amp; 'PhD Student': Ich schlafe in Zimmern die in Kommunen f\u00FCr eine Nacht frei sind ;)",
  "id" : 518192772265050113,
  "in_reply_to_status_id" : 518182999494787073,
  "created_at" : "2014-10-04 00:15:59 +0000",
  "in_reply_to_screen_name" : "zinken",
  "in_reply_to_user_id_str" : "15353398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5555322691, 13.3937450804 ]
  },
  "id_str" : "518177235912896512",
  "text" : "\u00ABSchon wieder kein Nerdzimmer.\u00BB \u2014 \u00ABKeine Steckdosen am Bett?\u00BB \u2014 \u00ABGenau. Ich glaube wir hatten Steckdosen am Bett bevor wir ein Bett hatten.\u00BB",
  "id" : 518177235912896512,
  "created_at" : "2014-10-03 23:14:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxen",
      "screen_name" : "axuse",
      "indices" : [ 3, 9 ],
      "id_str" : "798602797",
      "id" : 798602797
    }, {
      "name" : "WikimediaDeutschland",
      "screen_name" : "WikimediaDE",
      "indices" : [ 48, 60 ],
      "id_str" : "47948264",
      "id" : 47948264
    }, {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 92, 99 ],
      "id_str" : "1209301",
      "id" : 1209301
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 100, 116 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "mntmn \uA66E",
      "screen_name" : "mntmn",
      "indices" : [ 117, 123 ],
      "id_str" : "19429480",
      "id" : 19429480
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 124, 129 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "anke domscheit-berg",
      "screen_name" : "anked",
      "indices" : [ 132, 138 ],
      "id_str" : "16557497",
      "id" : 16557497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "Datenschutz",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/9JKD1T6pXE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CniyPLh5uhI",
      "display_url" : "youtube.com\/watch?v=CniyPL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518071216415199232",
  "text" : "RT @axuse: Freie Wissen #BigData + #Datenschutz @WikimediaDE (1h42s) http:\/\/t.co\/9JKD1T6pXE @fukami @gedankenstuecke @mntmn @johl+(-@anked)\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WikimediaDeutschland",
        "screen_name" : "WikimediaDE",
        "indices" : [ 37, 49 ],
        "id_str" : "47948264",
        "id" : 47948264
      }, {
        "name" : "fukami",
        "screen_name" : "fukami",
        "indices" : [ 81, 88 ],
        "id_str" : "1209301",
        "id" : 1209301
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 89, 105 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "mntmn \uA66E",
        "screen_name" : "mntmn",
        "indices" : [ 106, 112 ],
        "id_str" : "19429480",
        "id" : 19429480
      }, {
        "name" : "Jens Ohlig",
        "screen_name" : "johl",
        "indices" : [ 113, 118 ],
        "id_str" : "1147751",
        "id" : 1147751
      }, {
        "name" : "anke domscheit-berg",
        "screen_name" : "anked",
        "indices" : [ 121, 127 ],
        "id_str" : "16557497",
        "id" : 16557497
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "Datenschutz",
        "indices" : [ 24, 36 ]
      }, {
        "text" : "wmdesalon",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/9JKD1T6pXE",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CniyPLh5uhI",
        "display_url" : "youtube.com\/watch?v=CniyPL\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518057023066607618",
    "text" : "Freie Wissen #BigData + #Datenschutz @WikimediaDE (1h42s) http:\/\/t.co\/9JKD1T6pXE @fukami @gedankenstuecke @mntmn @johl+(-@anked) #wmdesalon",
    "id" : 518057023066607618,
    "created_at" : "2014-10-03 15:16:34 +0000",
    "user" : {
      "name" : "Chr\u00B0Maxen",
      "screen_name" : "m4x3n",
      "protected" : false,
      "id_str" : "1351792795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908192608534573057\/1RNDzq9B_normal.jpg",
      "id" : 1351792795,
      "verified" : false
    }
  },
  "id" : 518071216415199232,
  "created_at" : "2014-10-03 16:12:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 68, 74 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517990677180088320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.555823865, 13.3926509444 ]
  },
  "id_str" : "517991648807358465",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch perfect. I will drag our business consultant along. ;) @Lobot",
  "id" : 517991648807358465,
  "in_reply_to_status_id" : 517990677180088320,
  "created_at" : "2014-10-03 10:56:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517985557319000065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5554239636, 13.3933184769 ]
  },
  "id_str" : "517986403700183040",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch sounds great, what about 10am?",
  "id" : 517986403700183040,
  "in_reply_to_status_id" : 517985557319000065,
  "created_at" : "2014-10-03 10:35:57 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517963934931091456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5552886929, 13.3932933901 ]
  },
  "id_str" : "517985228103892994",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch nope, we're in Wedding\/Prenzlauer Berg and have to be on our way at noon\/noonish. Any ideas?",
  "id" : 517985228103892994,
  "in_reply_to_status_id" : 517963934931091456,
  "created_at" : "2014-10-03 10:31:16 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517955987181801472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.555258386, 13.3932220581 ]
  },
  "id_str" : "517958068618137600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch but agreed on fixing it first.",
  "id" : 517958068618137600,
  "in_reply_to_status_id" : 517955987181801472,
  "created_at" : "2014-10-03 08:43:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 31, 43 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517955987181801472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5553455781, 13.3932884879 ]
  },
  "id_str" : "517957988129472512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer this is more for @helgerausch, as I'm in Berlin until tomorrow late morning. :)",
  "id" : 517957988129472512,
  "in_reply_to_status_id" : 517955987181801472,
  "created_at" : "2014-10-03 08:43:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517954321762516992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5553066445, 13.393184349 ]
  },
  "id_str" : "517954673995972608",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer btw: what about having breakfast tomorrow?",
  "id" : 517954673995972608,
  "in_reply_to_status_id" : 517954321762516992,
  "created_at" : "2014-10-03 08:29:52 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 46, 57 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 99, 111 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 112, 128 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517922534688579584",
  "text" : "RT @PhilippBayer: Lots of shellshock lines in @openSNPorg server logs, including erratasecs' :3 cc @helgerausch @gedankenstuecke http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 28, 39 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Helge Rausch \uD83E\uDD59",
        "screen_name" : "helgerausch",
        "indices" : [ 81, 93 ],
        "id_str" : "52747896",
        "id" : 52747896
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 94, 110 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/517884622252695552\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/SWotqvd6Jk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By_lUZECQAA4qOT.png",
        "id_str" : "517884620658851840",
        "id" : 517884620658851840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By_lUZECQAA4qOT.png",
        "sizes" : [ {
          "h" : 502,
          "resize" : "fit",
          "w" : 1851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 1851
        } ],
        "display_url" : "pic.twitter.com\/SWotqvd6Jk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517884622252695552",
    "text" : "Lots of shellshock lines in @openSNPorg server logs, including erratasecs' :3 cc @helgerausch @gedankenstuecke http:\/\/t.co\/SWotqvd6Jk",
    "id" : 517884622252695552,
    "created_at" : "2014-10-03 03:51:30 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 517922534688579584,
  "created_at" : "2014-10-03 06:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517790628735123456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5554287374, 13.3935035425 ]
  },
  "id_str" : "517790993316581376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot knock yourself out.",
  "id" : 517790993316581376,
  "in_reply_to_status_id" : 517790628735123456,
  "created_at" : "2014-10-02 21:39:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.5558607048, 13.3936653659 ]
  },
  "id_str" : "517788209812869120",
  "text" : "\u00ABWir haben hier nur 2 einfache Hausregeln: Nicht in die Dusche und nicht in die Waschmaschine kacken.\u00BB",
  "id" : 517788209812869120,
  "created_at" : "2014-10-02 21:28:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 4, 9 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 64, 70 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.55547015, 13.3930259943 ]
  },
  "id_str" : "517787731175686145",
  "text" : "Der @johl ist ja ein Fuchs: moderiert seine Panels extra so das @Lobot absurdes* Zeug \u00FCber mich twittern kann. \n*wahres",
  "id" : 517787731175686145,
  "created_at" : "2014-10-02 21:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517721063518928897",
  "text" : "RT @edyong209: \"Our paper was peer-reviewed, your critique wasn't\" is the most pathetic of responses to scientific debate. http:\/\/t.co\/EId6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/EId6fopqBM",
        "expanded_url" : "http:\/\/io9.com\/geneticists-slam-study-claiming-schizophrenia-is-eight-1641303100\/all",
        "display_url" : "io9.com\/geneticists-sl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517666053825232896",
    "text" : "\"Our paper was peer-reviewed, your critique wasn't\" is the most pathetic of responses to scientific debate. http:\/\/t.co\/EId6fopqBM",
    "id" : 517666053825232896,
    "created_at" : "2014-10-02 13:22:59 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 517721063518928897,
  "created_at" : "2014-10-02 17:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D.Hi",
      "screen_name" : "Dahie",
      "indices" : [ 0, 6 ],
      "id_str" : "50637773",
      "id" : 50637773
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 7, 13 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/EKl5BrO1cJ",
      "expanded_url" : "http:\/\/www.fender.com\/accessories\/tuners\/california-series-clip-on-tuner-lake-placid-blue\/",
      "display_url" : "fender.com\/accessories\/tu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "517659569519329280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.4998103221, 13.3774722694 ]
  },
  "id_str" : "517694209105866752",
  "in_reply_to_user_id" : 50637773,
  "text" : "@Dahie @Lobot http:\/\/t.co\/EKl5BrO1cJ",
  "id" : 517694209105866752,
  "in_reply_to_status_id" : 517659569519329280,
  "created_at" : "2014-10-02 15:14:52 +0000",
  "in_reply_to_screen_name" : "Dahie",
  "in_reply_to_user_id_str" : "50637773",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517585427554131968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.0036819359, 10.2374428996 ]
  },
  "id_str" : "517618740071268352",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon ja, voller Schallplatten.",
  "id" : 517618740071268352,
  "in_reply_to_status_id" : 517585427554131968,
  "created_at" : "2014-10-02 10:14:59 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1067335422, 8.7544810729 ]
  },
  "id_str" : "517584817115103232",
  "text" : "On my way to Berlin.",
  "id" : 517584817115103232,
  "created_at" : "2014-10-02 08:00:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/97HOSlTinC",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/10\/01\/tentacle-sex-game-thats-all.html#more-335027",
      "display_url" : "boingboing.net\/2014\/10\/01\/ten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517571297141071872",
  "text" : "Consentacle: Tentacle sex game that's all about consent http:\/\/t.co\/97HOSlTinC",
  "id" : 517571297141071872,
  "created_at" : "2014-10-02 07:06:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nicolas lartillot",
      "screen_name" : "bayesiancook",
      "indices" : [ 3, 16 ],
      "id_str" : "2275114487",
      "id" : 2275114487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/FttZvVBmp6",
      "expanded_url" : "http:\/\/www.bayesiancook.blogspot.fr",
      "display_url" : "bayesiancook.blogspot.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "517566640293445632",
  "text" : "RT @bayesiancook: Selecting phylogenetic models without computing Bayes factors -- http:\/\/t.co\/FttZvVBmp6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/FttZvVBmp6",
        "expanded_url" : "http:\/\/www.bayesiancook.blogspot.fr",
        "display_url" : "bayesiancook.blogspot.fr"
      } ]
    },
    "geo" : { },
    "id_str" : "517312529161539584",
    "text" : "Selecting phylogenetic models without computing Bayes factors -- http:\/\/t.co\/FttZvVBmp6",
    "id" : 517312529161539584,
    "created_at" : "2014-10-01 13:58:12 +0000",
    "user" : {
      "name" : "nicolas lartillot",
      "screen_name" : "bayesiancook",
      "protected" : false,
      "id_str" : "2275114487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545124461926969344\/Xx_iBrrT_normal.jpeg",
      "id" : 2275114487,
      "verified" : false
    }
  },
  "id" : 517566640293445632,
  "created_at" : "2014-10-02 06:47:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1110798647, 8.7529687715 ]
  },
  "id_str" : "517427003499499520",
  "text" : "\u00ABUnter 'Doktorspiele' gibt es 24\/7 Anal-Stretching-Ringe?! Das hat mir noch kein Doktor angeboten!\u00BB \u2014 \u00ABIch beeil mich ja mit der Promotion\u2026\u00BB",
  "id" : 517427003499499520,
  "created_at" : "2014-10-01 21:33:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 0, 7 ],
      "id_str" : "1209301",
      "id" : 1209301
    }, {
      "name" : "anke domscheit-berg",
      "screen_name" : "anked",
      "indices" : [ 8, 14 ],
      "id_str" : "16557497",
      "id" : 16557497
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 15, 20 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517421497519190019",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.75192532 ]
  },
  "id_str" : "517423875802791937",
  "in_reply_to_user_id" : 1209301,
  "text" : "@fukami @anked @johl immer willst du nur langweilig \u00FCber Themen reden. ;)",
  "id" : 517423875802791937,
  "in_reply_to_status_id" : 517421497519190019,
  "created_at" : "2014-10-01 21:20:39 +0000",
  "in_reply_to_screen_name" : "fukami",
  "in_reply_to_user_id_str" : "1209301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 120, 128 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517409882514149376",
  "text" : "RT @hormiga: \u201CIt was like a religious conversion. And suddenly, I was no longer panicking about statistics.\u201D written by @cbahlai http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christie Bahlai",
        "screen_name" : "cbahlai",
        "indices" : [ 107, 115 ],
        "id_str" : "958649520",
        "id" : 958649520
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/azCsSf97FS",
        "expanded_url" : "http:\/\/wp.me\/p4aNDG-8G",
        "display_url" : "wp.me\/p4aNDG-8G"
      } ]
    },
    "geo" : { },
    "id_str" : "517386932297277441",
    "text" : "\u201CIt was like a religious conversion. And suddenly, I was no longer panicking about statistics.\u201D written by @cbahlai http:\/\/t.co\/azCsSf97FS",
    "id" : 517386932297277441,
    "created_at" : "2014-10-01 18:53:51 +0000",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 517409882514149376,
  "created_at" : "2014-10-01 20:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 20, 27 ],
      "id_str" : "1209301",
      "id" : 1209301
    }, {
      "name" : "anke domscheit-berg",
      "screen_name" : "anked",
      "indices" : [ 32, 38 ],
      "id_str" : "16557497",
      "id" : 16557497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wmdesalon",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108721923, 8.7586167845 ]
  },
  "id_str" : "517407264375054336",
  "text" : "Morgen rede ich mit @fukami und @anked im #wmdesalon \u00FCber \u201CEx-Piraten: Fluch oder Segen?\u201D. Oder \u00FCber Big Data. Mal schauen.",
  "id" : 517407264375054336,
  "created_at" : "2014-10-01 20:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517379019399241728",
  "text" : "parsed html with regex. it\u2019s as if millions of voices on stackoverflow suddenly cried out in terror and were suddenly silenced",
  "id" : 517379019399241728,
  "created_at" : "2014-10-01 18:22:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723573716, 8.6275363378 ]
  },
  "id_str" : "517354616649175041",
  "text" : "Bioinformatics. Where really all formats are incompatible. Today: the alleged A0 poster isn't A0\u2026",
  "id" : 517354616649175041,
  "created_at" : "2014-10-01 16:45:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 35, 46 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723098701, 8.6275784201 ]
  },
  "id_str" : "517340012829216768",
  "text" : "Doing yet another slide deck about @openSNPorg. By now I wish people would invite me to talk about something else.",
  "id" : 517340012829216768,
  "created_at" : "2014-10-01 15:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723426648, 8.6275865453 ]
  },
  "id_str" : "517301819400536064",
  "text" : "\u00ABF\u00FCr jemanden der sie sonst nur mit Mett macht sind diese veganen Cupcakes echt ganz gut geworden.\u00BB",
  "id" : 517301819400536064,
  "created_at" : "2014-10-01 13:15:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/5xMIC1ILJG",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/48",
      "display_url" : "existentialcomics.com\/comic\/48"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172392, 8.627537 ]
  },
  "id_str" : "517240343956553728",
  "text" : "A lesson in Stoicism from Marcus Aurelius http:\/\/t.co\/5xMIC1ILJG",
  "id" : 517240343956553728,
  "created_at" : "2014-10-01 09:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/OhzJE5wHOk",
      "expanded_url" : "http:\/\/instagram.com\/p\/tmoAAGhwgb\/",
      "display_url" : "instagram.com\/p\/tmoAAGhwgb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173591317, 8.633167204 ]
  },
  "id_str" : "517232558581379073",
  "text" : "False Alarm @ Uni Campus Riedberg, Frankfurt am Main http:\/\/t.co\/OhzJE5wHOk",
  "id" : 517232558581379073,
  "created_at" : "2014-10-01 08:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/TfG6IzvoW1",
      "expanded_url" : "http:\/\/instagram.com\/p\/tmj9eyBwtW\/",
      "display_url" : "instagram.com\/p\/tmj9eyBwtW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113868442, 8.753692928 ]
  },
  "id_str" : "517223675989602304",
  "text" : "Hafenromantik @ Hafeninsel http:\/\/t.co\/TfG6IzvoW1",
  "id" : 517223675989602304,
  "created_at" : "2014-10-01 08:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]