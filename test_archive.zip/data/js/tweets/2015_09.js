Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649264735133790208",
  "geo" : { },
  "id_str" : "649266039696551936",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache read a quarter of it before quitting.",
  "id" : 649266039696551936,
  "in_reply_to_status_id" : 649264735133790208,
  "created_at" : "2015-09-30 16:54:21 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649263302250528768",
  "text" : "RT @MozillaScience: LAST DAY to get your Open Research Accelerator application in! Join us to get help on your project at #mozfest\n\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozfest",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/7meWphOlZD",
        "expanded_url" : "http:\/\/mozillascience.org\/coming-to-mozfest-2015-open-research-accelerator",
        "display_url" : "mozillascience.org\/coming-to-mozf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649237308663730177",
    "text" : "LAST DAY to get your Open Research Accelerator application in! Join us to get help on your project at #mozfest\n\nhttp:\/\/t.co\/7meWphOlZD",
    "id" : 649237308663730177,
    "created_at" : "2015-09-30 15:00:11 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 649263302250528768,
  "created_at" : "2015-09-30 16:43:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649257412252315648",
  "text" : "Is it me getting old or is the mobile Google Flights UI hard to grasp?",
  "id" : 649257412252315648,
  "created_at" : "2015-09-30 16:20:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649205899458912257",
  "geo" : { },
  "id_str" : "649205977355522048",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab not exactly, it\u2019s Molecular Ecology Resources. :)",
  "id" : 649205977355522048,
  "in_reply_to_status_id" : 649205899458912257,
  "created_at" : "2015-09-30 12:55:41 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649205539700871169",
  "geo" : { },
  "id_str" : "649205570440962048",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab thanks!",
  "id" : 649205570440962048,
  "in_reply_to_status_id" : 649205539700871169,
  "created_at" : "2015-09-30 12:54:04 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/swAXWc011r",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "649204681726685184",
  "geo" : { },
  "id_str" : "649204968994570240",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I thought so. But wasn\u2019t 100% sure as my second paper on fungal genetics is just out: http:\/\/t.co\/swAXWc011r",
  "id" : 649204968994570240,
  "in_reply_to_status_id" : 649204681726685184,
  "created_at" : "2015-09-30 12:51:40 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 3, 12 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 110, 126 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649203323078320129",
  "text" : "RT @Krisztab: The day when you are looking for a paper for a student and you recognize an author from twitter @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 96, 112 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649202878536658944",
    "text" : "The day when you are looking for a paper for a student and you recognize an author from twitter @gedankenstuecke",
    "id" : 649202878536658944,
    "created_at" : "2015-09-30 12:43:22 +0000",
    "user" : {
      "name" : "Kriszta Kezia V",
      "screen_name" : "kri_keziush",
      "protected" : false,
      "id_str" : "19334473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836703338775343104\/tM-WE4G6_normal.jpg",
      "id" : 19334473,
      "verified" : false
    }
  },
  "id" : 649203323078320129,
  "created_at" : "2015-09-30 12:45:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649202878536658944",
  "geo" : { },
  "id_str" : "649203001316507648",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab oh, which one is it? And can I be of any help? :)",
  "id" : 649203001316507648,
  "in_reply_to_status_id" : 649202878536658944,
  "created_at" : "2015-09-30 12:43:51 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/rRpdzhq4Wz",
      "expanded_url" : "http:\/\/xkcd.com\/1584\/",
      "display_url" : "xkcd.com\/1584\/"
    } ]
  },
  "geo" : { },
  "id_str" : "649155064708395008",
  "text" : "That's funny http:\/\/t.co\/rRpdzhq4Wz",
  "id" : 649155064708395008,
  "created_at" : "2015-09-30 09:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649131191505952768",
  "text" : "\u00ABThis part of my de Bruijn graph looks like a noose. Looking more at the graph I want to put my head into it\u2026\u00BB",
  "id" : 649131191505952768,
  "created_at" : "2015-09-30 07:58:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plaid Bot",
      "screen_name" : "plaidbot",
      "indices" : [ 0, 9 ],
      "id_str" : "2983553937",
      "id" : 2983553937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "profile",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649119386314407936",
  "in_reply_to_user_id" : 2983553937,
  "text" : "@plaidbot #profile",
  "id" : 649119386314407936,
  "created_at" : "2015-09-30 07:11:36 +0000",
  "in_reply_to_screen_name" : "plaidbot",
  "in_reply_to_user_id_str" : "2983553937",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649098561184006144",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 btw: der Adapter ist gut angekommen. Danke \u2764\uFE0F",
  "id" : 649098561184006144,
  "created_at" : "2015-09-30 05:48:51 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/B3yxdkEF9V",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0139405",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648998379230502913",
  "text" : "\u201Cmulti-locus\u201D: A Molecular Phylogeny of the Lichen Genus Lecidella Focusing on Species from Mainland China http:\/\/t.co\/B3yxdkEF9V",
  "id" : 648998379230502913,
  "created_at" : "2015-09-29 23:10:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/KgzTUVxkGZ",
      "expanded_url" : "https:\/\/twitter.com\/arikia\/status\/648257634102022144",
      "display_url" : "twitter.com\/arikia\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648997700743090177",
  "text" : "\u00ABwhether to have it performed in first place should be left to the individual who must live with the consequences\u00BB https:\/\/t.co\/KgzTUVxkGZ",
  "id" : 648997700743090177,
  "created_at" : "2015-09-29 23:08:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/VG4ob3IVnv",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3876",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648992939125927936",
  "text" : "GATTACA would have been a much better movie if this was included http:\/\/t.co\/VG4ob3IVnv",
  "id" : 648992939125927936,
  "created_at" : "2015-09-29 22:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/97QiEPo8bO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=VMFg4x2NAQ8",
      "display_url" : "youtube.com\/watch?v=VMFg4x\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648971201528918016",
  "text" : "anchored in a storm, stubbornness comes naturally https:\/\/t.co\/97QiEPo8bO",
  "id" : 648971201528918016,
  "created_at" : "2015-09-29 21:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648968768455081984",
  "text" : "is there a nice way to add a phylogenetic tree to a set of barplots? (preferentially using ggplot et al.)",
  "id" : 648968768455081984,
  "created_at" : "2015-09-29 21:13:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uYM5LAH2pm",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/mgWP3JJgxJ3eE\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/mgWP3JJg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648942096246796289",
  "geo" : { },
  "id_str" : "648946016037797888",
  "in_reply_to_user_id" : 14286491,
  "text" : "Totally relevant: http:\/\/t.co\/uYM5LAH2pm",
  "id" : 648946016037797888,
  "in_reply_to_status_id" : 648942096246796289,
  "created_at" : "2015-09-29 19:42:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648944563156045824",
  "text" : "RT @existentialcoms: Sometimes I feel stupid, but then I remember that there are people out there who think we can scan people's brains to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648943194332250112",
    "text" : "Sometimes I feel stupid, but then I remember that there are people out there who think we can scan people's brains to figure out morality.",
    "id" : 648943194332250112,
    "created_at" : "2015-09-29 19:31:28 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 648944563156045824,
  "created_at" : "2015-09-29 19:36:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648942096246796289",
  "text" : "Being unable to say \u2018no\u2019 to professional requests is an academic thing right? In other words: welcome 14h workdays, I barely missed you.",
  "id" : 648942096246796289,
  "created_at" : "2015-09-29 19:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 38, 48 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 53, 65 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/DOoQs88KaG",
      "expanded_url" : "http:\/\/ivory.idyll.org\/blog\/2015-authorship-on-software-papers.html#comment-2280252322",
      "display_url" : "ivory.idyll.org\/blog\/2015-auth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648937013681459200",
  "text" : "These things are why I\u2019m a big fan of @biocrusoe and @ctitusbrown http:\/\/t.co\/DOoQs88KaG",
  "id" : 648937013681459200,
  "created_at" : "2015-09-29 19:06:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RjGn8S4Ken",
      "expanded_url" : "https:\/\/twitter.com\/DNADigest\/status\/648918205113716737",
      "display_url" : "twitter.com\/DNADigest\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648919891148414976",
  "text" : "If you wanna write a review on it, you can at the Winnower. Would love some post pub review. https:\/\/t.co\/tQZY3AlP4m https:\/\/t.co\/RjGn8S4Ken",
  "id" : 648919891148414976,
  "created_at" : "2015-09-29 17:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648914043118288896",
  "geo" : { },
  "id_str" : "648918414153678848",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam I think mine could be prevented in last minute :3",
  "id" : 648918414153678848,
  "in_reply_to_status_id" : 648914043118288896,
  "created_at" : "2015-09-29 17:53:00 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648903804377800704",
  "text" : "Awesome, I\u2019ll be at #Mozfest at the beginning of November!",
  "id" : 648903804377800704,
  "created_at" : "2015-09-29 16:54:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/bLJ2oJtCA6",
      "expanded_url" : "http:\/\/i0.kym-cdn.com\/photos\/images\/newsfeed\/000\/503\/585\/17b.jpg",
      "display_url" : "i0.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648878900710375424",
  "text" : "feeling: http:\/\/t.co\/bLJ2oJtCA6",
  "id" : 648878900710375424,
  "created_at" : "2015-09-29 15:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 16, 24 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648869189470564352",
  "geo" : { },
  "id_str" : "648870323916566528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @VetoSeb @ny_borg du willst dich mir auf den Bauch binden?",
  "id" : 648870323916566528,
  "in_reply_to_status_id" : 648869189470564352,
  "created_at" : "2015-09-29 14:41:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Beckers",
      "screen_name" : "mimimibe",
      "indices" : [ 0, 9 ],
      "id_str" : "621603079",
      "id" : 621603079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648857184072265728",
  "geo" : { },
  "id_str" : "648857327651672064",
  "in_reply_to_user_id" : 621603079,
  "text" : "@mimimibe unless it\u2019s Dawkins, then you can have both things at the same time!",
  "id" : 648857327651672064,
  "in_reply_to_status_id" : 648857184072265728,
  "created_at" : "2015-09-29 13:50:16 +0000",
  "in_reply_to_screen_name" : "mimimibe",
  "in_reply_to_user_id_str" : "621603079",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648856551575392256",
  "text" : "academia: where you are fighting over a text of 200 words for a day.",
  "id" : 648856551575392256,
  "created_at" : "2015-09-29 13:47:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "John M Hancock",
      "screen_name" : "JohnMHancock",
      "indices" : [ 12, 25 ],
      "id_str" : "343018077",
      "id" : 343018077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648797809987166208",
  "geo" : { },
  "id_str" : "648798446942584832",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner @JohnMHancock well, apparently they were okay with the weird license at the time, because it\u2019s mentioned in the paper.",
  "id" : 648798446942584832,
  "in_reply_to_status_id" : 648797809987166208,
  "created_at" : "2015-09-29 09:56:18 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 7, 18 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648797032610701312",
  "geo" : { },
  "id_str" : "648797356163469312",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @kathakatze must be an outgrow of the dumb paleo-movement: some paleo \u2018morals\u2019 to go along your paleo diet?",
  "id" : 648797356163469312,
  "in_reply_to_status_id" : 648797032610701312,
  "created_at" : "2015-09-29 09:51:58 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 12, 18 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648795423893782528",
  "geo" : { },
  "id_str" : "648796620277088256",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @tante another special kind of \u201Cevolutionary biologist\u201D\u2026 \uD83D\uDE2D",
  "id" : 648796620277088256,
  "in_reply_to_status_id" : 648795423893782528,
  "created_at" : "2015-09-29 09:49:02 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/cAe8xOdEoz",
      "expanded_url" : "https:\/\/twitter.com\/JohnMHancock\/status\/648757864882937856",
      "display_url" : "twitter.com\/JohnMHancock\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648794440153362432",
  "text" : "\u00ABWhoever [\u2026] welcomes immigrants to Europe and Germany is my enemy.\u00BB You can still be an idiot while doing science\u2026 https:\/\/t.co\/cAe8xOdEoz",
  "id" : 648794440153362432,
  "created_at" : "2015-09-29 09:40:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648760646176079872",
  "geo" : { },
  "id_str" : "648761794870276096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sweet, thanks!",
  "id" : 648761794870276096,
  "in_reply_to_status_id" : 648760646176079872,
  "created_at" : "2015-09-29 07:30:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648759393245261825",
  "geo" : { },
  "id_str" : "648760333373472768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw, having you here: do you know how to get p-values in R given chi2 values + df?",
  "id" : 648760333373472768,
  "in_reply_to_status_id" : 648759393245261825,
  "created_at" : "2015-09-29 07:24:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648759393245261825",
  "geo" : { },
  "id_str" : "648759987074895872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but that\u2019s for pulling data from openSNP into AUS I guess? ;)",
  "id" : 648759987074895872,
  "in_reply_to_status_id" : 648759393245261825,
  "created_at" : "2015-09-29 07:23:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648696111394197505",
  "geo" : { },
  "id_str" : "648758884308516864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer now the big question is: do they have an API to connect to openSNP? :P",
  "id" : 648758884308516864,
  "in_reply_to_status_id" : 648696111394197505,
  "created_at" : "2015-09-29 07:19:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648731869568040960",
  "geo" : { },
  "id_str" : "648736084541747200",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson I really want to, just need to find the time and especially money :)",
  "id" : 648736084541747200,
  "in_reply_to_status_id" : 648731869568040960,
  "created_at" : "2015-09-29 05:48:30 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/mWKvQ5ltLe",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/4040018\/flight-map-o.gif",
      "display_url" : "stream1.gifsoup.com\/view2\/4040018\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648615055995506688",
  "geo" : { },
  "id_str" : "648618972343091200",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson also a good opportunity to follow you to Seattle ;) http:\/\/t.co\/mWKvQ5ltLe",
  "id" : 648618972343091200,
  "in_reply_to_status_id" : 648615055995506688,
  "created_at" : "2015-09-28 22:03:08 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648611522982346752",
  "text" : "Already having a first draft of a slide deck, 1 month(!) before giving the talk. What have I become?!",
  "id" : 648611522982346752,
  "created_at" : "2015-09-28 21:33:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/6hTCb5Z55Z",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=arqaJAAM6pQ",
      "display_url" : "youtube.com\/watch?v=arqaJA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648588435553406976",
  "text" : "we learn to carry on through the grieving https:\/\/t.co\/6hTCb5Z55Z",
  "id" : 648588435553406976,
  "created_at" : "2015-09-28 20:01:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648582646709243906",
  "geo" : { },
  "id_str" : "648583667728707584",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze die Bauaufsicht hat dem Adler das Landen untersagt.",
  "id" : 648583667728707584,
  "in_reply_to_status_id" : 648582646709243906,
  "created_at" : "2015-09-28 19:42:51 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648581850789728256",
  "geo" : { },
  "id_str" : "648582287303540736",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze das tausendj\u00E4hrige Grossbauprojekt. Speer w\u00E4re stolz.",
  "id" : 648582287303540736,
  "in_reply_to_status_id" : 648581850789728256,
  "created_at" : "2015-09-28 19:37:22 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648579885695430656",
  "geo" : { },
  "id_str" : "648581598342942721",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze 2999: BER Millennium Edition wird angek\u00FCndigt.",
  "id" : 648581598342942721,
  "in_reply_to_status_id" : 648579885695430656,
  "created_at" : "2015-09-28 19:34:37 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Hack Day BLN",
      "screen_name" : "SHD_Berlin",
      "indices" : [ 3, 14 ],
      "id_str" : "1531582164",
      "id" : 1531582164
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SHDB14",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "feels",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/6fsmeidWvZ",
      "expanded_url" : "http:\/\/vimeo.com\/140458250",
      "display_url" : "vimeo.com\/140458250"
    } ]
  },
  "geo" : { },
  "id_str" : "648579065075642368",
  "text" : "RT @SHD_Berlin: http:\/\/t.co\/6fsmeidWvZ  #SHDB14 #feels :) \nP.S. Registration for this year's SHDB opens Friday 9th October at 12 noon!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SHDB14",
        "indices" : [ 24, 31 ]
      }, {
        "text" : "feels",
        "indices" : [ 32, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/6fsmeidWvZ",
        "expanded_url" : "http:\/\/vimeo.com\/140458250",
        "display_url" : "vimeo.com\/140458250"
      } ]
    },
    "geo" : { },
    "id_str" : "648571009029812224",
    "text" : "http:\/\/t.co\/6fsmeidWvZ  #SHDB14 #feels :) \nP.S. Registration for this year's SHDB opens Friday 9th October at 12 noon!",
    "id" : 648571009029812224,
    "created_at" : "2015-09-28 18:52:33 +0000",
    "user" : {
      "name" : "Science Hack Day BLN",
      "screen_name" : "SHD_Berlin",
      "protected" : false,
      "id_str" : "1531582164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925791549937668096\/kO0CE8a0_normal.jpg",
      "id" : 1531582164,
      "verified" : false
    }
  },
  "id" : 648579065075642368,
  "created_at" : "2015-09-28 19:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Boyer",
      "screen_name" : "BoyerAlison",
      "indices" : [ 3, 15 ],
      "id_str" : "2203509619",
      "id" : 2203509619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/duQLuGViyT",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2014\/11\/18\/harvard_business_school_study_it_s_not_kids_but_husbands_that_hold_women.html",
      "display_url" : "slate.com\/blogs\/xx_facto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648556300419366912",
  "text" : "RT @BoyerAlison: \"It\u2019s Not Your Kids Holding Your Career Back. It\u2019s Your Husband.\" So heartbreakingly true. http:\/\/t.co\/duQLuGViyT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/duQLuGViyT",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/xx_factor\/2014\/11\/18\/harvard_business_school_study_it_s_not_kids_but_husbands_that_hold_women.html",
        "display_url" : "slate.com\/blogs\/xx_facto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648551492593524736",
    "text" : "\"It\u2019s Not Your Kids Holding Your Career Back. It\u2019s Your Husband.\" So heartbreakingly true. http:\/\/t.co\/duQLuGViyT",
    "id" : 648551492593524736,
    "created_at" : "2015-09-28 17:34:59 +0000",
    "user" : {
      "name" : "Alison Boyer",
      "screen_name" : "BoyerAlison",
      "protected" : false,
      "id_str" : "2203509619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000766821959\/6ccd702c9c06c1a9beadd46fe50dba66_normal.jpeg",
      "id" : 2203509619,
      "verified" : false
    }
  },
  "id" : 648556300419366912,
  "created_at" : "2015-09-28 17:54:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648550616114049024",
  "geo" : { },
  "id_str" : "648551110937083905",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson ich hab noch ein paar einzelne refill cartridges, hab aber keine Ahnung in welche H\u00FCllen sie noch passen.",
  "id" : 648551110937083905,
  "in_reply_to_status_id" : 648550616114049024,
  "created_at" : "2015-09-28 17:33:29 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648547641417166848",
  "geo" : { },
  "id_str" : "648549175848792064",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson Hi-Tec-C Gel mit 0.3mm Tip funktionieren f\u00FCr mich als Lefty bislang am besten.",
  "id" : 648549175848792064,
  "in_reply_to_status_id" : 648547641417166848,
  "created_at" : "2015-09-28 17:25:47 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/648543718836961284\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/qm5rixFOBQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQAXE3KW8AA-5aJ.jpg",
      "id_str" : "648543718635663360",
      "id" : 648543718635663360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQAXE3KW8AA-5aJ.jpg",
      "sizes" : [ {
        "h" : 1175,
        "resize" : "fit",
        "w" : 783
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1175,
        "resize" : "fit",
        "w" : 783
      }, {
        "h" : 1175,
        "resize" : "fit",
        "w" : 783
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/qm5rixFOBQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648543718836961284",
  "text" : "Sorry, not sorry http:\/\/t.co\/qm5rixFOBQ",
  "id" : 648543718836961284,
  "created_at" : "2015-09-28 17:04:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 9, 17 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648542075093426176",
  "geo" : { },
  "id_str" : "648542530884251648",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb @ny_borg ich gebe selbst einen Talk und bebauchbinde mich dann nachtr\u00E4glich ;)",
  "id" : 648542530884251648,
  "in_reply_to_status_id" : 648542075093426176,
  "created_at" : "2015-09-28 16:59:23 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 9, 17 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648541038378942464",
  "geo" : { },
  "id_str" : "648541886274252800",
  "in_reply_to_user_id" : 448328735,
  "text" : "@VetoSeb @ny_borg was? Die waren so gut und hatten so viele Fans! :3",
  "id" : 648541886274252800,
  "in_reply_to_status_id" : 648541038378942464,
  "created_at" : "2015-09-28 16:56:49 +0000",
  "in_reply_to_screen_name" : "SebInAction",
  "in_reply_to_user_id_str" : "448328735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Nivatius)))",
      "screen_name" : "Nivatius",
      "indices" : [ 0, 9 ],
      "id_str" : "18052595",
      "id" : 18052595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648499840092143616",
  "geo" : { },
  "id_str" : "648499914234839040",
  "in_reply_to_user_id" : 18052595,
  "text" : "@Nivatius ah, danke :)",
  "id" : 648499914234839040,
  "in_reply_to_status_id" : 648499840092143616,
  "created_at" : "2015-09-28 14:10:02 +0000",
  "in_reply_to_screen_name" : "Nivatius",
  "in_reply_to_user_id_str" : "18052595",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "ICTscienceEU",
      "indices" : [ 0, 13 ],
      "id_str" : "930380481966886912",
      "id" : 930380481966886912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648432618678157312",
  "geo" : { },
  "id_str" : "648496574990000128",
  "in_reply_to_user_id" : 1533210170,
  "text" : "@ICTscienceEU thanks! :)",
  "id" : 648496574990000128,
  "in_reply_to_status_id" : 648432618678157312,
  "created_at" : "2015-09-28 13:56:46 +0000",
  "in_reply_to_screen_name" : "SciArtTech_eu",
  "in_reply_to_user_id_str" : "1533210170",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/xY0BDSpX0U",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/charliewarzel\/if-they-build-it-will-we-come-meet-the-tech-entrepreneurs-tr#.piXP8mD6g",
      "display_url" : "buzzfeed.com\/charliewarzel\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648496160802537472",
  "text" : "\u00ABThe sexual singularity, [\u2026], feels about as probable as a three-way with your Roomba and Siri.\u00BB http:\/\/t.co\/xY0BDSpX0U",
  "id" : 648496160802537472,
  "created_at" : "2015-09-28 13:55:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/lfgKEeDCeD",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/wonkblog\/wp\/2015\/09\/11\/the-powerful-argument-for-not-learning-too-much-about-your-genes\/",
      "display_url" : "washingtonpost.com\/news\/wonkblog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648489712013979648",
  "text" : "on genetic testing: partially-understood genes where a confusing situation could arise? 99% of the genome. https:\/\/t.co\/lfgKEeDCeD",
  "id" : 648489712013979648,
  "created_at" : "2015-09-28 13:29:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Nivatius)))",
      "screen_name" : "Nivatius",
      "indices" : [ 0, 9 ],
      "id_str" : "18052595",
      "id" : 18052595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648453706934022144",
  "geo" : { },
  "id_str" : "648488848721375232",
  "in_reply_to_user_id" : 18052595,
  "text" : "@Nivatius gibt es eigentlich was neues vom Unicorn? :3",
  "id" : 648488848721375232,
  "in_reply_to_status_id" : 648453706934022144,
  "created_at" : "2015-09-28 13:26:04 +0000",
  "in_reply_to_screen_name" : "Nivatius",
  "in_reply_to_user_id_str" : "18052595",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/dJT5hnBURg",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/blogs\/answer-sheet\/wp\/2015\/09\/25\/what-one-college-discovered-when-it-stopped-accepting-satact-scores\/",
      "display_url" : "washingtonpost.com\/blogs\/answer-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648452959014158337",
  "text" : "Standardised testing doesn\u2019t work, who would have guessed. https:\/\/t.co\/dJT5hnBURg",
  "id" : 648452959014158337,
  "created_at" : "2015-09-28 11:03:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mL4piN6ksp",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/09\/war-genome-editing-just-got-lot-interesting\/",
      "display_url" : "wired.com\/2015\/09\/war-ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648437354017988609",
  "text" : "If you so far missed the muckraking over CRISPR patents: the war over genome editing just got a lot more interesting. http:\/\/t.co\/mL4piN6ksp",
  "id" : 648437354017988609,
  "created_at" : "2015-09-28 10:01:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/cgNZ3eVo2e",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/WQAna7qFrUAne\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/WQAna7qF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648432739033718784",
  "geo" : { },
  "id_str" : "648433521841860608",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson already see me embarking on an adventure in Norway. https:\/\/t.co\/cgNZ3eVo2e",
  "id" : 648433521841860608,
  "in_reply_to_status_id" : 648432739033718784,
  "created_at" : "2015-09-28 09:46:13 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648431245031022592",
  "geo" : { },
  "id_str" : "648431840416657408",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson sounds proper spyish to me!",
  "id" : 648431840416657408,
  "in_reply_to_status_id" : 648431245031022592,
  "created_at" : "2015-09-28 09:39:32 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648430216508010496",
  "geo" : { },
  "id_str" : "648431041510813696",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson and the meeting is after dark under some shady bridge? :3",
  "id" : 648431041510813696,
  "in_reply_to_status_id" : 648430216508010496,
  "created_at" : "2015-09-28 09:36:22 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/q4ISzDSsyG",
      "expanded_url" : "https:\/\/medium.com\/@mach\/the-secret-of-san-francisco-fonts-4b5295d9a745",
      "display_url" : "medium.com\/@mach\/the-secr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648427172227645440",
  "text" : "The not-so-secret details of Apple\u2019s San Francisco font family (whops, gave it away) https:\/\/t.co\/q4ISzDSsyG",
  "id" : 648427172227645440,
  "created_at" : "2015-09-28 09:20:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648412635042594816",
  "text" : "Travel advice on where to stay starting with \u00ABIf you are feeling brave and poor\u2026\u00BB is right up my alley\/budget.",
  "id" : 648412635042594816,
  "created_at" : "2015-09-28 08:23:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 95, 103 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/zdPT6g8cmM",
      "expanded_url" : "http:\/\/sfy.co\/j17oj",
      "display_url" : "sfy.co\/j17oj"
    } ]
  },
  "geo" : { },
  "id_str" : "648410446039502849",
  "text" : "Read all my snark and the useful contributions made by other people during #GET2015, thanks to @glyn_dk http:\/\/t.co\/zdPT6g8cmM",
  "id" : 648410446039502849,
  "created_at" : "2015-09-28 08:14:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648405934268633088",
  "text" : "You\u2019d expect that the whole process of applying for visa would drive people into hating the idea of national states as such.",
  "id" : 648405934268633088,
  "created_at" : "2015-09-28 07:56:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648244092548325376",
  "geo" : { },
  "id_str" : "648256993828990976",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer maybe not, if we transfer to another machine anyway?",
  "id" : 648256993828990976,
  "in_reply_to_status_id" : 648244092548325376,
  "created_at" : "2015-09-27 22:04:46 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648193200625176576",
  "geo" : { },
  "id_str" : "648212348252069888",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer wow, still pretty much of a performance boost :)",
  "id" : 648212348252069888,
  "in_reply_to_status_id" : 648193200625176576,
  "created_at" : "2015-09-27 19:07:21 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648189777393623040",
  "geo" : { },
  "id_str" : "648189858360524800",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer how fast is it now? :)",
  "id" : 648189858360524800,
  "in_reply_to_status_id" : 648189777393623040,
  "created_at" : "2015-09-27 17:37:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648187863796985856",
  "geo" : { },
  "id_str" : "648188158396493824",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer that\u2019s too bad :( w\/ the progress the Patreon campaign is doing we maybe could upgrade next month?",
  "id" : 648188158396493824,
  "in_reply_to_status_id" : 648187863796985856,
  "created_at" : "2015-09-27 17:31:14 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648184789967732736",
  "geo" : { },
  "id_str" : "648184851833733120",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer full steam ahead? :3",
  "id" : 648184851833733120,
  "in_reply_to_status_id" : 648184789967732736,
  "created_at" : "2015-09-27 17:18:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    }, {
      "name" : "Sarah Gray",
      "screen_name" : "SGrayDC",
      "indices" : [ 14, 22 ],
      "id_str" : "19921572",
      "id" : 19921572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648168430768664576",
  "geo" : { },
  "id_str" : "648168849842524161",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist @SGrayDC there have been much more dubious life choices, so I\u2019m happy with how things turned out ;-)",
  "id" : 648168849842524161,
  "in_reply_to_status_id" : 648168430768664576,
  "created_at" : "2015-09-27 16:14:30 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diemen",
      "screen_name" : "Diemen",
      "indices" : [ 0, 7 ],
      "id_str" : "16870959",
      "id" : 16870959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648158301817933824",
  "geo" : { },
  "id_str" : "648167827166380032",
  "in_reply_to_user_id" : 16870959,
  "text" : "@Diemen oh, danke :)",
  "id" : 648167827166380032,
  "in_reply_to_status_id" : 648158301817933824,
  "created_at" : "2015-09-27 16:10:27 +0000",
  "in_reply_to_screen_name" : "Diemen",
  "in_reply_to_user_id_str" : "16870959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/TtRnSyrtJt",
      "expanded_url" : "https:\/\/instagram.com\/p\/8I4_xqhwiB\/",
      "display_url" : "instagram.com\/p\/8I4_xqhwiB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "648155895516557312",
  "text" : "Color-Overload https:\/\/t.co\/TtRnSyrtJt",
  "id" : 648155895516557312,
  "created_at" : "2015-09-27 15:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648153589928587264",
  "geo" : { },
  "id_str" : "648154846298808320",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot der obere Fu\u00DF ist noch \uD83C\uDF44-frei?",
  "id" : 648154846298808320,
  "in_reply_to_status_id" : 648153589928587264,
  "created_at" : "2015-09-27 15:18:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 31, 45 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648151862827323392",
  "text" : "RT @madprime: @gedankenstuecke @beaugunderson the whole genre of \"defensive architecture\" is sad once one starts noticing it... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "beau",
        "screen_name" : "beaugunderson",
        "indices" : [ 17, 31 ],
        "id_str" : "5746882",
        "id" : 5746882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/3RZpPH0X8J",
        "expanded_url" : "http:\/\/www.theguardian.com\/society\/2015\/feb\/18\/defensive-architecture-keeps-poverty-undeen-and-makes-us-more-hostile",
        "display_url" : "theguardian.com\/society\/2015\/f\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "648080810218770432",
    "geo" : { },
    "id_str" : "648125859652632578",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @beaugunderson the whole genre of \"defensive architecture\" is sad once one starts noticing it... http:\/\/t.co\/3RZpPH0X8J",
    "id" : 648125859652632578,
    "in_reply_to_status_id" : 648080810218770432,
    "created_at" : "2015-09-27 13:23:41 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 648151862827323392,
  "created_at" : "2015-09-27 15:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Gray",
      "screen_name" : "SGrayDC",
      "indices" : [ 0, 8 ],
      "id_str" : "19921572",
      "id" : 19921572
    }, {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 47, 60 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648143402991792128",
  "geo" : { },
  "id_str" : "648150156039335936",
  "in_reply_to_user_id" : 19921572,
  "text" : "@SGrayDC it\u2019s a nice read! have fun, as I told @MishaAngrist during #GET2015: this book inspired me to do openSNP :)",
  "id" : 648150156039335936,
  "in_reply_to_status_id" : 648143402991792128,
  "created_at" : "2015-09-27 15:00:13 +0000",
  "in_reply_to_screen_name" : "SGrayDC",
  "in_reply_to_user_id_str" : "19921572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648125859652632578",
  "geo" : { },
  "id_str" : "648134326698307584",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @beaugunderson thanks!",
  "id" : 648134326698307584,
  "in_reply_to_status_id" : 648125859652632578,
  "created_at" : "2015-09-27 13:57:19 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 61, 75 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ShwivBNY9E",
      "expanded_url" : "https:\/\/medium.com\/futures-exchange\/designing-the-perfect-anti-object-49a184a6667a",
      "display_url" : "medium.com\/futures-exchan\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648016869748772864",
  "geo" : { },
  "id_str" : "648080810218770432",
  "in_reply_to_user_id" : 5746882,
  "text" : "\u00ABa symbol of the freedom we\u2019ve lost in our public spaces\u00BB RT @beaugunderson: hate benches are the worst https:\/\/t.co\/ShwivBNY9E",
  "id" : 648080810218770432,
  "in_reply_to_status_id" : 648016869748772864,
  "created_at" : "2015-09-27 10:24:40 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Erickson",
      "screen_name" : "Jessjerickson",
      "indices" : [ 3, 17 ],
      "id_str" : "33528381",
      "id" : 33528381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647909136139702273",
  "text" : "RT @Jessjerickson: \"Opinions are like nipples. Everybody has them, but men get to share theirs in public.\" via Isaac Wolkerstorfer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647655036827385856",
    "text" : "\"Opinions are like nipples. Everybody has them, but men get to share theirs in public.\" via Isaac Wolkerstorfer",
    "id" : 647655036827385856,
    "created_at" : "2015-09-26 06:12:48 +0000",
    "user" : {
      "name" : "Jess Erickson",
      "screen_name" : "Jessjerickson",
      "protected" : false,
      "id_str" : "33528381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787012035586338816\/JmJ02RJQ_normal.jpg",
      "id" : 33528381,
      "verified" : false
    }
  },
  "id" : 647909136139702273,
  "created_at" : "2015-09-26 23:02:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 3, 14 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    }, {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 20, 34 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Meredith Carpenter",
      "screen_name" : "M_L_Carpenter",
      "indices" : [ 40, 54 ],
      "id_str" : "1472866045",
      "id" : 1472866045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/647789792042741766\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/R7JGx482ix",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1pYiDUAAAS5lG.jpg",
      "id_str" : "647789791589695488",
      "id" : 647789791589695488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1pYiDUAAAS5lG.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/R7JGx482ix"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vl9YebO7NR",
      "expanded_url" : "https:\/\/www.usenix.org\/conference\/lisa15\/conference-program\/presentation\/mickens",
      "display_url" : "usenix.org\/conference\/lis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647866768703229952",
  "text" : "RT @lteytelman: Via @genetics_blog. And @M_L_Carpenter calls it \"the best abstract ever.\" https:\/\/t.co\/vl9YebO7NR http:\/\/t.co\/R7JGx482ix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Turner",
        "screen_name" : "genetics_blog",
        "indices" : [ 4, 18 ],
        "id_str" : "923639552874557440",
        "id" : 923639552874557440
      }, {
        "name" : "Meredith Carpenter",
        "screen_name" : "M_L_Carpenter",
        "indices" : [ 24, 38 ],
        "id_str" : "1472866045",
        "id" : 1472866045
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/647789792042741766\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/R7JGx482ix",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1pYiDUAAAS5lG.jpg",
        "id_str" : "647789791589695488",
        "id" : 647789791589695488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1pYiDUAAAS5lG.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/R7JGx482ix"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/vl9YebO7NR",
        "expanded_url" : "https:\/\/www.usenix.org\/conference\/lisa15\/conference-program\/presentation\/mickens",
        "display_url" : "usenix.org\/conference\/lis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647789792042741766",
    "text" : "Via @genetics_blog. And @M_L_Carpenter calls it \"the best abstract ever.\" https:\/\/t.co\/vl9YebO7NR http:\/\/t.co\/R7JGx482ix",
    "id" : 647789792042741766,
    "created_at" : "2015-09-26 15:08:16 +0000",
    "user" : {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "protected" : false,
      "id_str" : "1343132275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819433710831472640\/WxJQTMMz_normal.jpg",
      "id" : 1343132275,
      "verified" : false
    }
  },
  "id" : 647866768703229952,
  "created_at" : "2015-09-26 20:14:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Birdist",
      "screen_name" : "TheBirdist",
      "indices" : [ 3, 14 ],
      "id_str" : "361910269",
      "id" : 361910269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647832124352020480",
  "text" : "RT @TheBirdist: Haven't been tweeting much because I got married yesterday! I kept a checklist for the ceremony, of course http:\/\/t.co\/hoI5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheBirdist\/status\/647765289921155072\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/hoI5nx89mN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1S5LoUcAAw70f.jpg",
        "id_str" : "647765063739142144",
        "id" : 647765063739142144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1S5LoUcAAw70f.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/hoI5nx89mN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647765289921155072",
    "text" : "Haven't been tweeting much because I got married yesterday! I kept a checklist for the ceremony, of course http:\/\/t.co\/hoI5nx89mN",
    "id" : 647765289921155072,
    "created_at" : "2015-09-26 13:30:54 +0000",
    "user" : {
      "name" : "The Birdist",
      "screen_name" : "TheBirdist",
      "protected" : false,
      "id_str" : "361910269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703256558407442432\/_kYSamVg_normal.jpg",
      "id" : 361910269,
      "verified" : false
    }
  },
  "id" : 647832124352020480,
  "created_at" : "2015-09-26 17:56:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/J6mH3WdnF4",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3873",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647799407979663360",
  "text" : "LDR http:\/\/t.co\/J6mH3WdnF4",
  "id" : 647799407979663360,
  "created_at" : "2015-09-26 15:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647719293543653376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407925374586, 8.753277641037688 ]
  },
  "id_str" : "647764396031217665",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze \u2764\uFE0F\uD83C\uDF69\uD83C\uDF66\uD83C\uDF68\uD83C\uDF6A",
  "id" : 647764396031217665,
  "in_reply_to_status_id" : 647719293543653376,
  "created_at" : "2015-09-26 13:27:21 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647691930940346368",
  "geo" : { },
  "id_str" : "647696647028371456",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju do want!",
  "id" : 647696647028371456,
  "in_reply_to_status_id" : 647691930940346368,
  "created_at" : "2015-09-26 08:58:08 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/647696052313788416\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/TI5BB5hns7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP0UILfWoAA6_kR.jpg",
      "id_str" : "647696052167024640",
      "id" : 647696052167024640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP0UILfWoAA6_kR.jpg",
      "sizes" : [ {
        "h" : 1013,
        "resize" : "fit",
        "w" : 1351
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 1351
      } ],
      "display_url" : "pic.twitter.com\/TI5BB5hns7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647696052313788416",
  "text" : "Team Fungus, what's growing in this coffee filter? (We can safely establish I can quit coffee any time!) http:\/\/t.co\/TI5BB5hns7",
  "id" : 647696052313788416,
  "created_at" : "2015-09-26 08:55:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "geo" : { },
  "id_str" : "647688814786424832",
  "text" : "Having a late breakfast and want to do something that arguably raises your karma? Support us in running openSNP. \uD83D\uDE02\uD83C\uDF39 https:\/\/t.co\/OprjH129UP",
  "id" : 647688814786424832,
  "created_at" : "2015-09-26 08:27:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Ryan Hussey",
      "screen_name" : "ryanhussey",
      "indices" : [ 9, 20 ],
      "id_str" : "262476283",
      "id" : 262476283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647678279034499072",
  "geo" : { },
  "id_str" : "647682191456120832",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @ryanhussey calling each other out is like the best thing in the world :3",
  "id" : 647682191456120832,
  "in_reply_to_status_id" : 647678279034499072,
  "created_at" : "2015-09-26 08:00:42 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Ryan Hussey",
      "screen_name" : "ryanhussey",
      "indices" : [ 61, 72 ],
      "id_str" : "262476283",
      "id" : 262476283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/f7KIg2UufO",
      "expanded_url" : "https:\/\/medium.com\/the-coffeelicious\/4-things-i-need-from-you-in-a-relationship-91c7a207c053?source=tw-2bef900f168b-1443253558716",
      "display_url" : "medium.com\/the-coffeelici\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647681747119939584",
  "text" : "RT @glyn_dk: \u201C4 Things I Need From You in a Relationship\u201D by @ryanhussey https:\/\/t.co\/f7KIg2UufO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Hussey",
        "screen_name" : "ryanhussey",
        "indices" : [ 48, 59 ],
        "id_str" : "262476283",
        "id" : 262476283
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/f7KIg2UufO",
        "expanded_url" : "https:\/\/medium.com\/the-coffeelicious\/4-things-i-need-from-you-in-a-relationship-91c7a207c053?source=tw-2bef900f168b-1443253558716",
        "display_url" : "medium.com\/the-coffeelici\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647678279034499072",
    "text" : "\u201C4 Things I Need From You in a Relationship\u201D by @ryanhussey https:\/\/t.co\/f7KIg2UufO",
    "id" : 647678279034499072,
    "created_at" : "2015-09-26 07:45:09 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 647681747119939584,
  "created_at" : "2015-09-26 07:58:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 3, 11 ],
      "id_str" : "300735398",
      "id" : 300735398
    }, {
      "name" : "Matthew \"Rid the world of Nazis\" Francis",
      "screen_name" : "DrMRFrancis",
      "indices" : [ 99, 111 ],
      "id_str" : "186585181",
      "id" : 186585181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tuEiS2Ugdi",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/science\/2015\/09\/richard_dawkins_on_social_media_the_author_of_the_selfish_gene_and_meme.html",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647519102647537665",
  "text" : "RT @aatishb: A Rationalist\u2019s Irrationality:\nWhy is Richard Dawkins such a jerk? Excellent piece by @DrMRFrancis http:\/\/t.co\/tuEiS2Ugdi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew \"Rid the world of Nazis\" Francis",
        "screen_name" : "DrMRFrancis",
        "indices" : [ 86, 98 ],
        "id_str" : "186585181",
        "id" : 186585181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/tuEiS2Ugdi",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/science\/2015\/09\/richard_dawkins_on_social_media_the_author_of_the_selfish_gene_and_meme.html",
        "display_url" : "slate.com\/articles\/healt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647516790122225664",
    "text" : "A Rationalist\u2019s Irrationality:\nWhy is Richard Dawkins such a jerk? Excellent piece by @DrMRFrancis http:\/\/t.co\/tuEiS2Ugdi",
    "id" : 647516790122225664,
    "created_at" : "2015-09-25 21:03:27 +0000",
    "user" : {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "protected" : false,
      "id_str" : "300735398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000817613002\/3814bf3474aff91370d827c2f4cbdb9b_normal.jpeg",
      "id" : 300735398,
      "verified" : true
    }
  },
  "id" : 647519102647537665,
  "created_at" : "2015-09-25 21:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 13, 28 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 29, 43 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 44, 49 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647511991033032704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407451546843, 8.75337439646791 ]
  },
  "id_str" : "647516303931146240",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @torstenseemann @genetics_blog @klmr sweet, missed that! It will remove the one issue I had for a long time with the package :)",
  "id" : 647516303931146240,
  "in_reply_to_status_id" : 647511991033032704,
  "created_at" : "2015-09-25 21:01:31 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/VsTRvZpiQz",
      "expanded_url" : "http:\/\/www.theheartradio.org\/heatwave\/themagicwand",
      "display_url" : "theheartradio.org\/heatwave\/thema\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647465773942837250",
  "text" : "The Heart has a whole episode on \u00ABThe Queen of Vibrators: The Hitachi Magic Wand\u00BB \u263A\uFE0F http:\/\/t.co\/VsTRvZpiQz",
  "id" : 647465773942837250,
  "created_at" : "2015-09-25 17:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean-Louis Couturier",
      "screen_name" : "couturij",
      "indices" : [ 3, 12 ],
      "id_str" : "64289069",
      "id" : 64289069
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruinanovelwithsocialmedia",
      "indices" : [ 39, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647432841844891649",
  "text" : "RT @couturij: A Listicle for Leibowitz\n#ruinanovelwithsocialmedia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruinanovelwithsocialmedia",
        "indices" : [ 25, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647430697766883328",
    "text" : "A Listicle for Leibowitz\n#ruinanovelwithsocialmedia",
    "id" : 647430697766883328,
    "created_at" : "2015-09-25 15:21:21 +0000",
    "user" : {
      "name" : "Jean-Louis Couturier",
      "screen_name" : "couturij",
      "protected" : false,
      "id_str" : "64289069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3220648388\/2695c9f0e5b1494bf94ba29f66bd68ba_normal.jpeg",
      "id" : 64289069,
      "verified" : false
    }
  },
  "id" : 647432841844891649,
  "created_at" : "2015-09-25 15:29:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647422378251718656",
  "geo" : { },
  "id_str" : "647422730422353920",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe that\u2019s awesome. \uD83D\uDC93",
  "id" : 647422730422353920,
  "in_reply_to_status_id" : 647422378251718656,
  "created_at" : "2015-09-25 14:49:42 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Daniel S. Katz",
      "screen_name" : "danielskatz",
      "indices" : [ 16, 28 ],
      "id_str" : "19238958",
      "id" : 19238958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647422646230077440",
  "text" : "RT @biocrusoe: .@danielskatz We gave credit to each person who gets a pull request merged. We respect the name provided by the contributor.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel S. Katz",
        "screen_name" : "danielskatz",
        "indices" : [ 1, 13 ],
        "id_str" : "19238958",
        "id" : 19238958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyNameIsMe",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "647421353050664960",
    "geo" : { },
    "id_str" : "647422378251718656",
    "in_reply_to_user_id" : 19238958,
    "text" : ".@danielskatz We gave credit to each person who gets a pull request merged. We respect the name provided by the contributor. #MyNameIsMe",
    "id" : 647422378251718656,
    "in_reply_to_status_id" : 647421353050664960,
    "created_at" : "2015-09-25 14:48:18 +0000",
    "in_reply_to_screen_name" : "danielskatz",
    "in_reply_to_user_id_str" : "19238958",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 647422646230077440,
  "created_at" : "2015-09-25 14:49:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "indices" : [ 0, 11 ],
      "id_str" : "237650650",
      "id" : 237650650
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 12, 22 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 23, 35 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647420438948257792",
  "geo" : { },
  "id_str" : "647421044953907201",
  "in_reply_to_user_id" : 237650650,
  "text" : "@MMMarksman @biocrusoe @ctitusbrown Congrats!",
  "id" : 647421044953907201,
  "in_reply_to_status_id" : 647420438948257792,
  "created_at" : "2015-09-25 14:43:00 +0000",
  "in_reply_to_screen_name" : "MMMarksman",
  "in_reply_to_user_id_str" : "237650650",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/Yxdm1ovA4h",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/symbiartic\/confirmation-bias\/",
      "display_url" : "blogs.scientificamerican.com\/symbiartic\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647402281097412608",
  "text" : "confirmation bias http:\/\/t.co\/Yxdm1ovA4h",
  "id" : 647402281097412608,
  "created_at" : "2015-09-25 13:28:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/sI1Wtqa8ml",
      "expanded_url" : "https:\/\/twitter.com\/mishaangrist\/status\/647399030239166465",
      "display_url" : "twitter.com\/mishaangrist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647401400616517632",
  "text" : "RT @wilbanks: Study advertisements must not contain pictures of fire. Fire bad. https:\/\/t.co\/sI1Wtqa8ml",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/sI1Wtqa8ml",
        "expanded_url" : "https:\/\/twitter.com\/mishaangrist\/status\/647399030239166465",
        "display_url" : "twitter.com\/mishaangrist\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647400417421336577",
    "text" : "Study advertisements must not contain pictures of fire. Fire bad. https:\/\/t.co\/sI1Wtqa8ml",
    "id" : 647400417421336577,
    "created_at" : "2015-09-25 13:21:02 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 647401400616517632,
  "created_at" : "2015-09-25 13:24:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 12, 28 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647378772551991296",
  "geo" : { },
  "id_str" : "647380186179194880",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack @pathogenomenick happy to help out!",
  "id" : 647380186179194880,
  "in_reply_to_status_id" : 647378772551991296,
  "created_at" : "2015-09-25 12:00:38 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 12, 28 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/UmEEmdAmyv",
      "expanded_url" : "https:\/\/dl.dropboxusercontent.com\/u\/170329\/Science-2015-Servick-1472-7.pdf",
      "display_url" : "dl.dropboxusercontent.com\/u\/170329\/Scien\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "647377705671991296",
  "geo" : { },
  "id_str" : "647378095268339712",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack @pathogenomenick whops, sorry. I found this PDF-link ;-) https:\/\/t.co\/UmEEmdAmyv",
  "id" : 647378095268339712,
  "in_reply_to_status_id" : 647377705671991296,
  "created_at" : "2015-09-25 11:52:20 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christian m\u00FCller",
      "screen_name" : "capwnd",
      "indices" : [ 0, 7 ],
      "id_str" : "19160866",
      "id" : 19160866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647355593569779712",
  "geo" : { },
  "id_str" : "647366322100244480",
  "in_reply_to_user_id" : 19160866,
  "text" : "@capwnd nano m(",
  "id" : 647366322100244480,
  "in_reply_to_status_id" : 647355593569779712,
  "created_at" : "2015-09-25 11:05:33 +0000",
  "in_reply_to_screen_name" : "capwnd",
  "in_reply_to_user_id_str" : "19160866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 100, 116 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lYVVkn5awG",
      "expanded_url" : "http:\/\/www.sciencemag.org\/content\/349\/6255\/1472.full",
      "display_url" : "sciencemag.org\/content\/349\/62\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647343977251893248",
  "text" : "\u2018Can 23andMe have it all?\u2019 Unfortunately their office space is the only thing that\u2019s wide-open. \/HT @pathogenomenick http:\/\/t.co\/lYVVkn5awG",
  "id" : 647343977251893248,
  "created_at" : "2015-09-25 09:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647336905055543296",
  "text" : "\u00ABEven back in your day there was at least one polyamory self-help book, even had a 10-point checklist. One point being \u2018Thou Shalt Not Lie\u2019\u00BB",
  "id" : 647336905055543296,
  "created_at" : "2015-09-25 09:08:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 14, 22 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/1PluOciawT",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1745",
      "display_url" : "michaeleisen.org\/blog\/?p=1745"
    } ]
  },
  "in_reply_to_status_id_str" : "647307883454025732",
  "geo" : { },
  "id_str" : "647328565567033344",
  "in_reply_to_user_id" : 14286491,
  "text" : "Great post by @mbeisen why we should call out Wikipedia for the deal with Elsevier. http:\/\/t.co\/1PluOciawT",
  "id" : 647328565567033344,
  "in_reply_to_status_id" : 647307883454025732,
  "created_at" : "2015-09-25 08:35:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 0, 12 ],
      "id_str" : "53560219",
      "id" : 53560219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647323689344589824",
  "geo" : { },
  "id_str" : "647323877266313216",
  "in_reply_to_user_id" : 53560219,
  "text" : "@openscience \uD83C\uDF7B",
  "id" : 647323877266313216,
  "in_reply_to_status_id" : 647323689344589824,
  "created_at" : "2015-09-25 08:16:53 +0000",
  "in_reply_to_screen_name" : "openscience",
  "in_reply_to_user_id_str" : "53560219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/pHxIFSh0w0",
      "expanded_url" : "https:\/\/instagram.com\/p\/8C9vHDhwhw\/",
      "display_url" : "instagram.com\/p\/8C9vHDhwhw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "647321796342095872",
  "text" : "over not so troubled water https:\/\/t.co\/pHxIFSh0w0",
  "id" : 647321796342095872,
  "created_at" : "2015-09-25 08:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 116, 127 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647317041238667264",
  "text" : "RT @helgerausch: If \"the Facebook of genes\" really creeps you out, but you want to see where this is going, support @openSNPorg! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 99, 110 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/rMRTJ2URth",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "geo" : { },
    "id_str" : "647295682559246336",
    "text" : "If \"the Facebook of genes\" really creeps you out, but you want to see where this is going, support @openSNPorg! https:\/\/t.co\/rMRTJ2URth ;)",
    "id" : 647295682559246336,
    "created_at" : "2015-09-25 06:24:51 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 647317041238667264,
  "created_at" : "2015-09-25 07:49:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ijad Madisch",
      "screen_name" : "IjadMadisch",
      "indices" : [ 0, 12 ],
      "id_str" : "17386540",
      "id" : 17386540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647314042713935872",
  "geo" : { },
  "id_str" : "647315052924674048",
  "in_reply_to_user_id" : 17386540,
  "text" : "@IjadMadisch sorry, but I just deleted my RG account this morning as it wasn\u2019t useful to me. :)",
  "id" : 647315052924674048,
  "in_reply_to_status_id" : 647314042713935872,
  "created_at" : "2015-09-25 07:41:49 +0000",
  "in_reply_to_screen_name" : "IjadMadisch",
  "in_reply_to_user_id_str" : "17386540",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/Njpft3hXfz",
      "expanded_url" : "https:\/\/instagram.com\/p\/8C5qRRBwtb\/",
      "display_url" : "instagram.com\/p\/8C5qRRBwtb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "647312833768759296",
  "text" : "Wandering #latergram https:\/\/t.co\/Njpft3hXfz",
  "id" : 647312833768759296,
  "created_at" : "2015-09-25 07:33:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647308811255087104",
  "geo" : { },
  "id_str" : "647308923658207232",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich haha, as if. charging for colour figures instead.",
  "id" : 647308923658207232,
  "in_reply_to_status_id" : 647308811255087104,
  "created_at" : "2015-09-25 07:17:28 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647307883454025732",
  "text" : "Did 2 articles with non open access journals due to peer-pressure. Can now say that I\u2019d rather blog about my results than doing it again.",
  "id" : 647307883454025732,
  "created_at" : "2015-09-25 07:13:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 17, 28 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647291829562515456",
  "geo" : { },
  "id_str" : "647305321375895552",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @EffyVayena thx!",
  "id" : 647305321375895552,
  "in_reply_to_status_id" : 647291829562515456,
  "created_at" : "2015-09-25 07:03:09 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 17, 28 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Et5SQA0BnU",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "647123984803307520",
  "text" : "RT @heyaudy: The @openSNPorg project needs your help to fund a bigger server for all your SNPs: https:\/\/t.co\/Et5SQA0BnU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 4, 15 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/Et5SQA0BnU",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
        "display_url" : "patreon.com\/openSNP?ty=h"
      } ]
    },
    "geo" : { },
    "id_str" : "647119518003798016",
    "text" : "The @openSNPorg project needs your help to fund a bigger server for all your SNPs: https:\/\/t.co\/Et5SQA0BnU",
    "id" : 647119518003798016,
    "created_at" : "2015-09-24 18:44:50 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 647123984803307520,
  "created_at" : "2015-09-24 19:02:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647119518003798016",
  "geo" : { },
  "id_str" : "647123830599733249",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy thanks for contributing \u263A\uFE0F\uD83C\uDF39",
  "id" : 647123830599733249,
  "in_reply_to_status_id" : 647119518003798016,
  "created_at" : "2015-09-24 19:01:58 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C1sta Helgad\u00F3ttir",
      "screen_name" : "asta_fish",
      "indices" : [ 3, 13 ],
      "id_str" : "605042583",
      "id" : 605042583
    }, {
      "name" : "VICE UK",
      "screen_name" : "VICEUK",
      "indices" : [ 93, 100 ],
      "id_str" : "15995155",
      "id" : 15995155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gqMc0eHQTR",
      "expanded_url" : "http:\/\/www.vice.com\/en_uk\/read\/iceland-the-liberal-paradise-and-other-lies-you-might-believe-887",
      "display_url" : "vice.com\/en_uk\/read\/ice\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647109088560697344",
  "text" : "RT @asta_fish: Why Iceland Doesn't Deserve Its Liberal Reputation http:\/\/t.co\/gqMc0eHQTR via @viceuk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VICE UK",
        "screen_name" : "VICEUK",
        "indices" : [ 78, 85 ],
        "id_str" : "15995155",
        "id" : 15995155
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/gqMc0eHQTR",
        "expanded_url" : "http:\/\/www.vice.com\/en_uk\/read\/iceland-the-liberal-paradise-and-other-lies-you-might-believe-887",
        "display_url" : "vice.com\/en_uk\/read\/ice\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647102560084619264",
    "text" : "Why Iceland Doesn't Deserve Its Liberal Reputation http:\/\/t.co\/gqMc0eHQTR via @viceuk",
    "id" : 647102560084619264,
    "created_at" : "2015-09-24 17:37:27 +0000",
    "user" : {
      "name" : "\u00C1sta Helgad\u00F3ttir",
      "screen_name" : "asta_fish",
      "protected" : false,
      "id_str" : "605042583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784069399019917312\/3p6XLETy_normal.jpg",
      "id" : 605042583,
      "verified" : true
    }
  },
  "id" : 647109088560697344,
  "created_at" : "2015-09-24 18:03:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/hVURHBsbKR",
      "expanded_url" : "https:\/\/instagram.com\/p\/8BV-4Bhwkv\/",
      "display_url" : "instagram.com\/p\/8BV-4Bhwkv\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.109589588, 8.765576562 ]
  },
  "id_str" : "647093639764668416",
  "text" : "Ups and Downs @ Offenbacher Ruderverein 1874 E.V. https:\/\/t.co\/hVURHBsbKR",
  "id" : 647093639764668416,
  "created_at" : "2015-09-24 17:02:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Sigi",
      "screen_name" : "toxoplasmoese",
      "indices" : [ 12, 26 ],
      "id_str" : "381719880",
      "id" : 381719880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647067184791965697",
  "geo" : { },
  "id_str" : "647067565534113792",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @toxoplasmoese ich kenn ihn leider auch noch nicht pers\u00F6nlich. :3",
  "id" : 647067565534113792,
  "in_reply_to_status_id" : 647067184791965697,
  "created_at" : "2015-09-24 15:18:24 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Sigi",
      "screen_name" : "toxoplasmoese",
      "indices" : [ 12, 26 ],
      "id_str" : "381719880",
      "id" : 381719880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/USEkzS4qZ3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FKdu01LqXdI",
      "display_url" : "youtube.com\/watch?v=FKdu01\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "647066605390811136",
  "geo" : { },
  "id_str" : "647067049169043457",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @toxoplasmoese there you go! https:\/\/t.co\/USEkzS4qZ3",
  "id" : 647067049169043457,
  "in_reply_to_status_id" : 647066605390811136,
  "created_at" : "2015-09-24 15:16:21 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "\u3164",
      "screen_name" : "neingeist",
      "indices" : [ 12, 22 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647066732918644736",
  "geo" : { },
  "id_str" : "647066920437596160",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @neingeist your fetish is not my fetish, but your fetish is okay. ;)",
  "id" : 647066920437596160,
  "in_reply_to_status_id" : 647066732918644736,
  "created_at" : "2015-09-24 15:15:50 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "\u3164",
      "screen_name" : "neingeist",
      "indices" : [ 12, 22 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647065210495344640",
  "geo" : { },
  "id_str" : "647066366286106624",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @neingeist \uD83C\uDF32\uD83C\uDF84",
  "id" : 647066366286106624,
  "in_reply_to_status_id" : 647065210495344640,
  "created_at" : "2015-09-24 15:13:38 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647064015324213248",
  "geo" : { },
  "id_str" : "647064532221865984",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze super Produktname, would buy.",
  "id" : 647064532221865984,
  "in_reply_to_status_id" : 647064015324213248,
  "created_at" : "2015-09-24 15:06:21 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/tWWUoNFRmK",
      "expanded_url" : "http:\/\/a.dilcdn.com\/bl\/wp-content\/uploads\/sites\/8\/2013\/12\/candy-canes-sugar-cookies-chritmas-recipe-photo-420-1196-FF11202.jpg",
      "display_url" : "a.dilcdn.com\/bl\/wp-content\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "647063549810987008",
  "geo" : { },
  "id_str" : "647063936899108864",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze die candy canes bieten sich auch an http:\/\/t.co\/tWWUoNFRmK",
  "id" : 647063936899108864,
  "in_reply_to_status_id" : 647063549810987008,
  "created_at" : "2015-09-24 15:03:59 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647063018229075968",
  "geo" : { },
  "id_str" : "647063287964766208",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze Und zum Konsumfest am Ende des Jahres ergibt sich \u201CFriedliche Weihnachten\u201D als Slogan gleich ganz von selbst.",
  "id" : 647063287964766208,
  "in_reply_to_status_id" : 647063018229075968,
  "created_at" : "2015-09-24 15:01:24 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 17, 28 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647053585830780929",
  "geo" : { },
  "id_str" : "647053682136252417",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @EffyVayena do you have a link?",
  "id" : 647053682136252417,
  "in_reply_to_status_id" : 647053585830780929,
  "created_at" : "2015-09-24 14:23:14 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FGWVLgzmeY",
      "expanded_url" : "http:\/\/www.theguardian.com\/women-in-leadership\/2015\/sep\/24\/67-of-europeans-dont-believe-women-have-the-skills-to-be-scientists?CMP=twt_a-science_b-gdnscience",
      "display_url" : "theguardian.com\/women-in-leade\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647050087210815489",
  "text" : "A number that should be 1915 instead of 2015: 67% of Europeans don't believe women have the skills to be scientists \uD83D\uDE2D http:\/\/t.co\/FGWVLgzmeY",
  "id" : 647050087210815489,
  "created_at" : "2015-09-24 14:08:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/YcPj3iOGt4",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/sep\/23\/powerpoint-thought-students-bullet-points-information?CMP=fb_gu",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647027292779233281",
  "text" : "On slide presentations: \u00ABThe presentation is not a movie &amp; the presenter is rarely Brad Pitt. No wonder we are bored\u00BB http:\/\/t.co\/YcPj3iOGt4",
  "id" : 647027292779233281,
  "created_at" : "2015-09-24 12:38:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2oNuuOnNuo",
      "expanded_url" : "http:\/\/thelongandshort.org\/life-death\/dna-testing-and-you",
      "display_url" : "thelongandshort.org\/life-death\/dna\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647008472110886912",
  "text" : "\u00ABDespite the hype, DNA testing may not reveal as much about yourself as you would hope.\u00BB Hope or fear. http:\/\/t.co\/2oNuuOnNuo",
  "id" : 647008472110886912,
  "created_at" : "2015-09-24 11:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646984781461368832",
  "geo" : { },
  "id_str" : "646985668162387968",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ziemlich bequem und gut zum laufen, allerdings haben sich die Zehenzwischenr\u00E4ume ziemlich schnell aufgel\u00F6st.",
  "id" : 646985668162387968,
  "in_reply_to_status_id" : 646984781461368832,
  "created_at" : "2015-09-24 09:52:58 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Croucher",
      "screen_name" : "walkingrandomly",
      "indices" : [ 3, 19 ],
      "id_str" : "92746008",
      "id" : 92746008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/QiOG8qQx02",
      "expanded_url" : "http:\/\/mikecroucher.github.io\/MLPM_talk\/",
      "display_url" : "mikecroucher.github.io\/MLPM_talk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "646981280983289856",
  "text" : "RT @walkingrandomly: Slides for the talk I'm about to give http:\/\/t.co\/QiOG8qQx02 Is your research software correct?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/QiOG8qQx02",
        "expanded_url" : "http:\/\/mikecroucher.github.io\/MLPM_talk\/",
        "display_url" : "mikecroucher.github.io\/MLPM_talk\/"
      } ]
    },
    "geo" : { },
    "id_str" : "646969688451346432",
    "text" : "Slides for the talk I'm about to give http:\/\/t.co\/QiOG8qQx02 Is your research software correct?",
    "id" : 646969688451346432,
    "created_at" : "2015-09-24 08:49:28 +0000",
    "user" : {
      "name" : "Mike Croucher",
      "screen_name" : "walkingrandomly",
      "protected" : false,
      "id_str" : "92746008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928007729473564673\/tIyEHpge_normal.jpg",
      "id" : 92746008,
      "verified" : false
    }
  },
  "id" : 646981280983289856,
  "created_at" : "2015-09-24 09:35:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646978488541556736",
  "text" : "A beachfront hotel in TLV it is. I guess academia requires sacrifices from all of us.",
  "id" : 646978488541556736,
  "created_at" : "2015-09-24 09:24:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646972924113649665",
  "geo" : { },
  "id_str" : "646973631885635584",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Das sind\/waren die Lontra.",
  "id" : 646973631885635584,
  "in_reply_to_status_id" : 646972924113649665,
  "created_at" : "2015-09-24 09:05:08 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646921228008091648",
  "geo" : { },
  "id_str" : "646967244619141120",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup thanks for including us in that list :)",
  "id" : 646967244619141120,
  "in_reply_to_status_id" : 646921228008091648,
  "created_at" : "2015-09-24 08:39:45 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/83FFDn6GVj",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/23\/dog-steals-ice-cream-from-fell.html",
      "display_url" : "boingboing.net\/2015\/09\/23\/dog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646965044387938304",
  "text" : "This video of dogs eating ice cream is geo-blocked on youtube on copyright grounds. \uD83D\uDE2D http:\/\/t.co\/83FFDn6GVj",
  "id" : 646965044387938304,
  "created_at" : "2015-09-24 08:31:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 104, 117 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/VQ3Tyn3qgS",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0139047",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646964637502734336",
  "text" : "Pyvolve: A Flexible Python Module for Simulating Sequences along Phylogenies http:\/\/t.co\/VQ3Tyn3qgS \/cc @PhilippBayer",
  "id" : 646964637502734336,
  "created_at" : "2015-09-24 08:29:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 0, 9 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 10, 25 ],
      "id_str" : "20198007",
      "id" : 20198007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646952819962998784",
  "geo" : { },
  "id_str" : "646953236121845760",
  "in_reply_to_user_id" : 20126211,
  "text" : "@hdashnow @bobbledavidson asked a couple of lawyers for advice when we started and they had no clue what to advise due to lack of precedent.",
  "id" : 646953236121845760,
  "in_reply_to_status_id" : 646952819962998784,
  "created_at" : "2015-09-24 07:44:05 +0000",
  "in_reply_to_screen_name" : "hdashnow",
  "in_reply_to_user_id_str" : "20126211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 0, 9 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 10, 25 ],
      "id_str" : "20198007",
      "id" : 20198007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646952819962998784",
  "geo" : { },
  "id_str" : "646952977585020928",
  "in_reply_to_user_id" : 20126211,
  "text" : "@hdashnow @bobbledavidson we don\u2019t have any, we\u2019re just a couple of people running a website in our spare time.",
  "id" : 646952977585020928,
  "in_reply_to_status_id" : 646952819962998784,
  "created_at" : "2015-09-24 07:43:04 +0000",
  "in_reply_to_screen_name" : "hdashnow",
  "in_reply_to_user_id_str" : "20126211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 0, 9 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 10, 25 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 26, 37 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646951642441478145",
  "geo" : { },
  "id_str" : "646952519806119936",
  "in_reply_to_user_id" : 20126211,
  "text" : "@hdashnow @bobbledavidson @openSNPorg Thanks, we tried hard to get a \u201Chuman-readable\u201D (as opposed to \u201Clawyer-readable\u201D) disclaimer. :)",
  "id" : 646952519806119936,
  "in_reply_to_status_id" : 646951642441478145,
  "created_at" : "2015-09-24 07:41:15 +0000",
  "in_reply_to_screen_name" : "hdashnow",
  "in_reply_to_user_id_str" : "20126211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646948499318157314",
  "geo" : { },
  "id_str" : "646949270147436544",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow also published my data on GitHub before openSNP. I think it\u2019s less enabling sharing per se, but making it useful.",
  "id" : 646949270147436544,
  "in_reply_to_status_id" : 646948499318157314,
  "created_at" : "2015-09-24 07:28:20 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646947418550857728",
  "geo" : { },
  "id_str" : "646948108346236928",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow would love IRB-approval to facilitate data usage. At same time I feel genomes would be posted to FB if not openSNP",
  "id" : 646948108346236928,
  "in_reply_to_status_id" : 646947418550857728,
  "created_at" : "2015-09-24 07:23:43 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "GA4GH",
      "screen_name" : "GA4GH",
      "indices" : [ 26, 32 ],
      "id_str" : "2375288959",
      "id" : 2375288959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646947418550857728",
  "geo" : { },
  "id_str" : "646947650227576832",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow @GA4GH We tried getting IRB approval. But boards in Germany felt we\u2019re not doing science, just collecting data.",
  "id" : 646947650227576832,
  "in_reply_to_status_id" : 646947418550857728,
  "created_at" : "2015-09-24 07:21:54 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "GA4GH",
      "screen_name" : "GA4GH",
      "indices" : [ 26, 32 ],
      "id_str" : "2375288959",
      "id" : 2375288959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646946921567784961",
  "geo" : { },
  "id_str" : "646947136475631616",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow @GA4GH I think getting informed consent IRB-approved cross-country is the problem.",
  "id" : 646947136475631616,
  "in_reply_to_status_id" : 646946921567784961,
  "created_at" : "2015-09-24 07:19:51 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "646946862033989632",
  "text" : "openSNP made it halfway to our first goal on Patreon. Hopefully we can upgrade the technical infrastructure soon. https:\/\/t.co\/ZOxhf6oQTY",
  "id" : 646946862033989632,
  "created_at" : "2015-09-24 07:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "GA4GH",
      "screen_name" : "GA4GH",
      "indices" : [ 26, 32 ],
      "id_str" : "2375288959",
      "id" : 2375288959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646946079397666816",
  "geo" : { },
  "id_str" : "646946391894437888",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow @GA4GH Yes, of course! :) And I agree on PGP(-UK &amp; others). But their consent-forms force country-limitations. :(",
  "id" : 646946391894437888,
  "in_reply_to_status_id" : 646946079397666816,
  "created_at" : "2015-09-24 07:16:54 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Davidson",
      "screen_name" : "bobbledavidson",
      "indices" : [ 0, 15 ],
      "id_str" : "20198007",
      "id" : 20198007
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 16, 25 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "GA4GH",
      "screen_name" : "GA4GH",
      "indices" : [ 83, 89 ],
      "id_str" : "2375288959",
      "id" : 2375288959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646944075304714240",
  "geo" : { },
  "id_str" : "646945434150268928",
  "in_reply_to_user_id" : 20198007,
  "text" : "@bobbledavidson @hdashnow thanks, we\u2019re also running a couple of APIs, including a @GA4GH beacon. :)",
  "id" : 646945434150268928,
  "in_reply_to_status_id" : 646944075304714240,
  "created_at" : "2015-09-24 07:13:05 +0000",
  "in_reply_to_screen_name" : "bobbledavidson",
  "in_reply_to_user_id_str" : "20198007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/j07AGoRFhc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4zUh7EARJhQ",
      "display_url" : "youtube.com\/watch?v=4zUh7E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646943387409645568",
  "text" : "my inbox: \u201DPeter Maffay: secretly totally into graph theory\" https:\/\/t.co\/j07AGoRFhc",
  "id" : 646943387409645568,
  "created_at" : "2015-09-24 07:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/vSR0gShiu3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_Jxh7eyIGu8",
      "display_url" : "youtube.com\/watch?v=_Jxh7e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "646824670679986176",
  "geo" : { },
  "id_str" : "646825419459661824",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze https:\/\/t.co\/vSR0gShiu3",
  "id" : 646825419459661824,
  "in_reply_to_status_id" : 646824670679986176,
  "created_at" : "2015-09-23 23:16:12 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646772796819816453",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407307741482, 8.753394348874918 ]
  },
  "id_str" : "646774853647777795",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ @PhilippBayer no problem, sorry that it takes so long.",
  "id" : 646774853647777795,
  "in_reply_to_status_id" : 646772796819816453,
  "created_at" : "2015-09-23 19:55:16 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "indices" : [ 3, 17 ],
      "id_str" : "44438256",
      "id" : 44438256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8qK7h1C6lM",
      "expanded_url" : "http:\/\/onforb.es\/1iMno2b",
      "display_url" : "onforb.es\/1iMno2b"
    } ]
  },
  "geo" : { },
  "id_str" : "646768910788874240",
  "text" : "RT @matthewherper: Even After Price Cut, Martin Shkreli Wins http:\/\/t.co\/8qK7h1C6lM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/8qK7h1C6lM",
        "expanded_url" : "http:\/\/onforb.es\/1iMno2b",
        "display_url" : "onforb.es\/1iMno2b"
      } ]
    },
    "geo" : { },
    "id_str" : "646754836394983424",
    "text" : "Even After Price Cut, Martin Shkreli Wins http:\/\/t.co\/8qK7h1C6lM",
    "id" : 646754836394983424,
    "created_at" : "2015-09-23 18:35:43 +0000",
    "user" : {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "protected" : false,
      "id_str" : "44438256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804670477939724288\/qMG4aBwA_normal.jpg",
      "id" : 44438256,
      "verified" : true
    }
  },
  "id" : 646768910788874240,
  "created_at" : "2015-09-23 19:31:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "in_reply_to_status_id_str" : "646749895584555009",
  "geo" : { },
  "id_str" : "646768357312757760",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ @PhilippBayer yes, it should already be more stable.But working on moving everything to larger machine(s) https:\/\/t.co\/OprjH129UP",
  "id" : 646768357312757760,
  "in_reply_to_status_id" : 646749895584555009,
  "created_at" : "2015-09-23 19:29:27 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "indices" : [ 3, 19 ],
      "id_str" : "2277140276",
      "id" : 2277140276
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HistoryInPix\/status\/646634404908040192\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7i0H2phn6A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPlOkK7WUAAUhpP.jpg",
      "id_str" : "646634404819914752",
      "id" : 646634404819914752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPlOkK7WUAAUhpP.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/7i0H2phn6A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646747825502580737",
  "text" : "RT @AhistoricalPics: Neil Armstrong relaxes between takes on Moon Landing Soundstage No. 3, 1969ish http:\/\/t.co\/7i0H2phn6A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HistoryInPix\/status\/646634404908040192\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/7i0H2phn6A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPlOkK7WUAAUhpP.jpg",
        "id_str" : "646634404819914752",
        "id" : 646634404819914752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPlOkK7WUAAUhpP.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/7i0H2phn6A"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646746859390828545",
    "text" : "Neil Armstrong relaxes between takes on Moon Landing Soundstage No. 3, 1969ish http:\/\/t.co\/7i0H2phn6A",
    "id" : 646746859390828545,
    "created_at" : "2015-09-23 18:04:01 +0000",
    "user" : {
      "name" : "A. History",
      "screen_name" : "AhistoricalPics",
      "protected" : false,
      "id_str" : "2277140276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419701923944480769\/AzrkOS2P_normal.jpeg",
      "id" : 2277140276,
      "verified" : false
    }
  },
  "id" : 646747825502580737,
  "created_at" : "2015-09-23 18:07:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/koE9ervuB3",
      "expanded_url" : "https:\/\/instagram.com\/p\/7-4Wtthwki\/",
      "display_url" : "instagram.com\/p\/7-4Wtthwki\/"
    } ]
  },
  "geo" : { },
  "id_str" : "646747013464358913",
  "text" : "I guess after 14 months of walking and running it's time to retire them. https:\/\/t.co\/koE9ervuB3",
  "id" : 646747013464358913,
  "created_at" : "2015-09-23 18:04:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 86, 96 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646743038698618880",
  "text" : "\u00ABMeet the Mark Zuckerberg of Open Source Genetics\u00BB Reading the headline of the latest @DNADigest newsletter confused me a bit at first.",
  "id" : 646743038698618880,
  "created_at" : "2015-09-23 17:48:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646740020150300672",
  "geo" : { },
  "id_str" : "646741290491736065",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks!",
  "id" : 646741290491736065,
  "in_reply_to_status_id" : 646740020150300672,
  "created_at" : "2015-09-23 17:41:54 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia",
      "screen_name" : "larkinia",
      "indices" : [ 0, 9 ],
      "id_str" : "68164476",
      "id" : 68164476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646725673915154432",
  "geo" : { },
  "id_str" : "646727857343959040",
  "in_reply_to_user_id" : 68164476,
  "text" : "@larkinia die reflektierende Warnweste nicht vergessen.",
  "id" : 646727857343959040,
  "in_reply_to_status_id" : 646725673915154432,
  "created_at" : "2015-09-23 16:48:31 +0000",
  "in_reply_to_screen_name" : "larkinia",
  "in_reply_to_user_id_str" : "68164476",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/JSekBgmwLz",
      "expanded_url" : "http:\/\/i.imgur.com\/fQP43aB.gifv",
      "display_url" : "i.imgur.com\/fQP43aB.gifv"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/q7qVwSo2RN",
      "expanded_url" : "https:\/\/twitter.com\/j_zimms\/status\/646699143767965696",
      "display_url" : "twitter.com\/j_zimms\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723328905422, 8.627520985835677 ]
  },
  "id_str" : "646700191786135552",
  "text" : "This is how I feel about this story: http:\/\/t.co\/JSekBgmwLz https:\/\/t.co\/q7qVwSo2RN",
  "id" : 646700191786135552,
  "created_at" : "2015-09-23 14:58:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Zimmerman",
      "screen_name" : "j_zimms",
      "indices" : [ 3, 11 ],
      "id_str" : "14714760",
      "id" : 14714760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646699947333677056",
  "text" : "RT @j_zimms: Boyfriend: \u201CI'd like to be the kind of person who drives animals around in a makeshift train when I'm older\u201D https:\/\/t.co\/Kg3T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/Kg3TOpUeJ6",
        "expanded_url" : "https:\/\/www.thedodo.com\/man-builds-dog-train-for-rescued-pups-1362467342.html",
        "display_url" : "thedodo.com\/man-builds-dog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646699143767965696",
    "text" : "Boyfriend: \u201CI'd like to be the kind of person who drives animals around in a makeshift train when I'm older\u201D https:\/\/t.co\/Kg3TOpUeJ6",
    "id" : 646699143767965696,
    "created_at" : "2015-09-23 14:54:25 +0000",
    "user" : {
      "name" : "Jess Zimmerman",
      "screen_name" : "j_zimms",
      "protected" : false,
      "id_str" : "14714760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869618972999680000\/fC9mWoiv_normal.jpg",
      "id" : 14714760,
      "verified" : true
    }
  },
  "id" : 646699947333677056,
  "created_at" : "2015-09-23 14:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/tbDvnddV5q",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3870",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646689761911025664",
  "text" : "been there. http:\/\/t.co\/tbDvnddV5q",
  "id" : 646689761911025664,
  "created_at" : "2015-09-23 14:17:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/646679243955511296\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0lasBYaYzC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPl3WIFWoAAsuKk.jpg",
      "id_str" : "646679243515142144",
      "id" : 646679243515142144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPl3WIFWoAAsuKk.jpg",
      "sizes" : [ {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0lasBYaYzC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646678829315006464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233178796893, 8.62752150672797 ]
  },
  "id_str" : "646679243955511296",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick not sure if I\u2019d call it \u201Csolve\u201D per se, but this is one approach taken here. http:\/\/t.co\/0lasBYaYzC",
  "id" : 646679243955511296,
  "in_reply_to_status_id" : 646678829315006464,
  "created_at" : "2015-09-23 13:35:21 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/iyMhiJqnrd",
      "expanded_url" : "http:\/\/flowingdata.com\/2015\/09\/23\/years-you-have-left-to-live-probably\/",
      "display_url" : "flowingdata.com\/2015\/09\/23\/yea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646668421757829121",
  "text" : "A nice visualization of \u201Cyears left to live\u201D: You better don\u2019t drop the ball early. http:\/\/t.co\/iyMhiJqnrd",
  "id" : 646668421757829121,
  "created_at" : "2015-09-23 12:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VvZhezU9WN",
      "expanded_url" : "https:\/\/github.com\/minimaxir\/big-list-of-naughty-strings",
      "display_url" : "github.com\/minimaxir\/big-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646623974806396928",
  "text" : "If you ever feel the need to see whether your code can deal with user input: Big List of Naughty Strings https:\/\/t.co\/VvZhezU9WN",
  "id" : 646623974806396928,
  "created_at" : "2015-09-23 09:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646590623596826624",
  "text" : "Sum of lines in all data files on openSNP (\u00B1 # of genetic variants stored): 1,458,372,087.",
  "id" : 646590623596826624,
  "created_at" : "2015-09-23 07:43:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Poncelet",
      "screen_name" : "PonWinnie",
      "indices" : [ 3, 13 ],
      "id_str" : "2811694452",
      "id" : 2811694452
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 43, 59 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 85, 93 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/5PbMsEkcoA",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=2",
      "display_url" : "patreon.com\/openSNP?ty=2"
    } ]
  },
  "geo" : { },
  "id_str" : "646586653436444673",
  "text" : "RT @PonWinnie: This is important - Support @gedankenstuecke openSNP creating Science @Patreon https:\/\/t.co\/5PbMsEkcoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 28, 44 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Patreon",
        "screen_name" : "Patreon",
        "indices" : [ 70, 78 ],
        "id_str" : "1228325660",
        "id" : 1228325660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/5PbMsEkcoA",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=2",
        "display_url" : "patreon.com\/openSNP?ty=2"
      } ]
    },
    "geo" : { },
    "id_str" : "646559394549862400",
    "text" : "This is important - Support @gedankenstuecke openSNP creating Science @Patreon https:\/\/t.co\/5PbMsEkcoA",
    "id" : 646559394549862400,
    "created_at" : "2015-09-23 05:39:06 +0000",
    "user" : {
      "name" : "Winnie Poncelet",
      "screen_name" : "PonWinnie",
      "protected" : false,
      "id_str" : "2811694452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922465736001576961\/zUMFBQWn_normal.jpg",
      "id" : 2811694452,
      "verified" : false
    }
  },
  "id" : 646586653436444673,
  "created_at" : "2015-09-23 07:27:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Poncelet",
      "screen_name" : "PonWinnie",
      "indices" : [ 0, 10 ],
      "id_str" : "2811694452",
      "id" : 2811694452
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 11, 19 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646559394549862400",
  "geo" : { },
  "id_str" : "646580243889786880",
  "in_reply_to_user_id" : 2811694452,
  "text" : "@PonWinnie @Patreon thanks!",
  "id" : 646580243889786880,
  "in_reply_to_status_id" : 646559394549862400,
  "created_at" : "2015-09-23 07:01:57 +0000",
  "in_reply_to_screen_name" : "PonWinnie",
  "in_reply_to_user_id_str" : "2811694452",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/XtWXHrNUg2",
      "expanded_url" : "https:\/\/instagram.com\/p\/78oM7oBwmS\/",
      "display_url" : "instagram.com\/p\/78oM7oBwmS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "646430026829824000",
  "text" : "PAL\u00C6ONTOLOGIE #latergram https:\/\/t.co\/XtWXHrNUg2",
  "id" : 646430026829824000,
  "created_at" : "2015-09-22 21:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 0, 15 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646339355166949376",
  "geo" : { },
  "id_str" : "646424560020144128",
  "in_reply_to_user_id" : 1428575976,
  "text" : "@MozillaScience thanks for tweeting. Wish I could have made it myself :-)",
  "id" : 646424560020144128,
  "in_reply_to_status_id" : 646339355166949376,
  "created_at" : "2015-09-22 20:43:19 +0000",
  "in_reply_to_screen_name" : "MozillaScience",
  "in_reply_to_user_id_str" : "1428575976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 48, 54 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646400710939136000",
  "geo" : { },
  "id_str" : "646419507821547521",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen apropos \u201CW\u00FCrde verlieren\u201D. Ich habe @Lobot heute den Baum gezeigt unter dem du &amp; ich uns kennengelernt haben \uD83D\uDE02",
  "id" : 646419507821547521,
  "in_reply_to_status_id" : 646400710939136000,
  "created_at" : "2015-09-22 20:23:15 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antideppren\u00F6r",
      "screen_name" : "piratefeminist",
      "indices" : [ 0, 15 ],
      "id_str" : "1152407016",
      "id" : 1152407016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646396529478115329",
  "geo" : { },
  "id_str" : "646396767936860161",
  "in_reply_to_user_id" : 1152407016,
  "text" : "@piratefeminist I can imagine, must have been early teen when started playing RA :D",
  "id" : 646396767936860161,
  "in_reply_to_status_id" : 646396529478115329,
  "created_at" : "2015-09-22 18:52:53 +0000",
  "in_reply_to_screen_name" : "piratefeminist",
  "in_reply_to_user_id_str" : "1152407016",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antideppren\u00F6r",
      "screen_name" : "piratefeminist",
      "indices" : [ 0, 15 ],
      "id_str" : "1152407016",
      "id" : 1152407016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646395243835879424",
  "geo" : { },
  "id_str" : "646396029470961664",
  "in_reply_to_user_id" : 1152407016,
  "text" : "@piratefeminist omg, the only RTS I ever enjoyed :D",
  "id" : 646396029470961664,
  "in_reply_to_status_id" : 646395243835879424,
  "created_at" : "2015-09-22 18:49:57 +0000",
  "in_reply_to_screen_name" : "piratefeminist",
  "in_reply_to_user_id_str" : "1152407016",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646366435690827776",
  "geo" : { },
  "id_str" : "646366938755678208",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg oh yeah, wie cool!",
  "id" : 646366938755678208,
  "in_reply_to_status_id" : 646366435690827776,
  "created_at" : "2015-09-22 16:54:21 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646292753538752513",
  "geo" : { },
  "id_str" : "646296578353930240",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon thanks! &lt;3",
  "id" : 646296578353930240,
  "in_reply_to_status_id" : 646292753538752513,
  "created_at" : "2015-09-22 12:14:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 23, 31 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 95, 106 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/eZpfVzXviH",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "646296535563698176",
  "text" : "RT @Senficon: Who said @Patreon was just for the arts? Support awesome citizen science project @openSNPorg now! https:\/\/t.co\/eZpfVzXviH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patreon",
        "screen_name" : "Patreon",
        "indices" : [ 9, 17 ],
        "id_str" : "1228325660",
        "id" : 1228325660
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 81, 92 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/eZpfVzXviH",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
        "display_url" : "patreon.com\/openSNP?ty=h"
      } ]
    },
    "geo" : { },
    "id_str" : "646292753538752513",
    "text" : "Who said @Patreon was just for the arts? Support awesome citizen science project @openSNPorg now! https:\/\/t.co\/eZpfVzXviH",
    "id" : 646292753538752513,
    "created_at" : "2015-09-22 11:59:34 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 646296535563698176,
  "created_at" : "2015-09-22 12:14:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 3, 17 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 61, 69 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "science",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "genetics",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dUNPZAwNs6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/646102667287220224",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646230181305315328",
  "text" : "RT @onetruecathal: I'm supporting #openscience \/ #science on @Patreon, why don't you commit even $1\/month? #genetics https:\/\/t.co\/dUNPZAwNs6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=org.mariotaku.twidere\" rel=\"nofollow\"\u003ETwidere for Android #4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patreon",
        "screen_name" : "Patreon",
        "indices" : [ 42, 50 ],
        "id_str" : "1228325660",
        "id" : 1228325660
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 15, 27 ]
      }, {
        "text" : "science",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "genetics",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/dUNPZAwNs6",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/646102667287220224",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646217844796051456",
    "text" : "I'm supporting #openscience \/ #science on @Patreon, why don't you commit even $1\/month? #genetics https:\/\/t.co\/dUNPZAwNs6",
    "id" : 646217844796051456,
    "created_at" : "2015-09-22 07:01:55 +0000",
    "user" : {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "protected" : false,
      "id_str" : "16066596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673955584920563713\/KsGsM0A5_normal.jpg",
      "id" : 16066596,
      "verified" : false
    }
  },
  "id" : 646230181305315328,
  "created_at" : "2015-09-22 07:50:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : { },
  "id_str" : "646102667287220224",
  "text" : "You can now help keeping openSNP running smoothly by supporting us on Patreon. Every dollar is a huge help to us: https:\/\/t.co\/ZOxhf6oQTY",
  "id" : 646102667287220224,
  "created_at" : "2015-09-21 23:24:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646039426108264448",
  "geo" : { },
  "id_str" : "646045387074220032",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson don\u2019t get killed!",
  "id" : 646045387074220032,
  "in_reply_to_status_id" : 646039426108264448,
  "created_at" : "2015-09-21 19:36:37 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Dilworth PhD",
      "screen_name" : "PolycrystalhD",
      "indices" : [ 3, 17 ],
      "id_str" : "963401670",
      "id" : 963401670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646030833870987264",
  "text" : "RT @PolycrystalhD: 4. If your life is only science, when your experiment fails your life will fail. Try to also live outside the lab. #Advi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AdviceForNewGradStudents",
        "indices" : [ 115, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645988118215036929",
    "text" : "4. If your life is only science, when your experiment fails your life will fail. Try to also live outside the lab. #AdviceForNewGradStudents",
    "id" : 645988118215036929,
    "created_at" : "2015-09-21 15:49:03 +0000",
    "user" : {
      "name" : "Crystal Dilworth PhD",
      "screen_name" : "PolycrystalhD",
      "protected" : false,
      "id_str" : "963401670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906412680558161920\/gPhEAFW7_normal.jpg",
      "id" : 963401670,
      "verified" : true
    }
  },
  "id" : 646030833870987264,
  "created_at" : "2015-09-21 18:38:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645977656937156608",
  "geo" : { },
  "id_str" : "646028410825895936",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan just as you\u2019d expect of Brits. \uD83D\uDE09",
  "id" : 646028410825895936,
  "in_reply_to_status_id" : 645977656937156608,
  "created_at" : "2015-09-21 18:29:10 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645968334660497409",
  "geo" : { },
  "id_str" : "645986599990358016",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks for the shoutout and the pledge \u2764\uFE0F",
  "id" : 645986599990358016,
  "in_reply_to_status_id" : 645968334660497409,
  "created_at" : "2015-09-21 15:43:01 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645986500010754049",
  "text" : "RT @wilbanks: Do you like open genomes, personal data control, open source science? Please support OpenSNP w\/ a monthly donation. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/gVfHc0jw1W",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "geo" : { },
    "id_str" : "645968334660497409",
    "text" : "Do you like open genomes, personal data control, open source science? Please support OpenSNP w\/ a monthly donation. https:\/\/t.co\/gVfHc0jw1W",
    "id" : 645968334660497409,
    "created_at" : "2015-09-21 14:30:27 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 645986500010754049,
  "created_at" : "2015-09-21 15:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645900886624071680",
  "geo" : { },
  "id_str" : "645901143168675841",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yes, because it was very intense. what you can\u2019t see in the picture: the whole platform with the desk &amp; chairs is rotating.",
  "id" : 645901143168675841,
  "in_reply_to_status_id" : 645900886624071680,
  "created_at" : "2015-09-21 10:03:27 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/645899830661877761\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/kaBacTknlX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPayeUgXAAAVCYc.jpg",
      "id_str" : "645899830544498688",
      "id" : 645899830544498688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPayeUgXAAAVCYc.jpg",
      "sizes" : [ {
        "h" : 845,
        "resize" : "fit",
        "w" : 1127
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 1127
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 1127
      } ],
      "display_url" : "pic.twitter.com\/kaBacTknlX"
    } ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645899830661877761",
  "text" : "Brainstorming in the brain room. This must be my favorite photo of #GET2015. http:\/\/t.co\/kaBacTknlX",
  "id" : 645899830661877761,
  "created_at" : "2015-09-21 09:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/hQQrzsdTPw",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/645893426462851074",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645894767365234688",
  "text" : "Really looking forward to participating in this track at #ICG. https:\/\/t.co\/hQQrzsdTPw",
  "id" : 645894767365234688,
  "created_at" : "2015-09-21 09:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/TtOCjZrZ4W",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "geo" : { },
  "id_str" : "645880757777526784",
  "text" : "RT @PhilippBayer: You can become an @openSNPorg patreon now: https:\/\/t.co\/TtOCjZrZ4W We use that money for server costs (eventually, a bigg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 18, 29 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/TtOCjZrZ4W",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "geo" : { },
    "id_str" : "645880057123082240",
    "text" : "You can become an @openSNPorg patreon now: https:\/\/t.co\/TtOCjZrZ4W We use that money for server costs (eventually, a bigger server)",
    "id" : 645880057123082240,
    "created_at" : "2015-09-21 08:39:40 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 645880757777526784,
  "created_at" : "2015-09-21 08:42:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/645877924504150016\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/O4x6kpfww1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPaejKoWoAAYgI2.jpg",
      "id_str" : "645877923560464384",
      "id" : 645877923560464384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPaejKoWoAAYgI2.jpg",
      "sizes" : [ {
        "h" : 1108,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 831
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/O4x6kpfww1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645877924504150016",
  "text" : "Putting advertising on a church is already kinda funny. Even more so if it says 'blah blah blah' http:\/\/t.co\/O4x6kpfww1",
  "id" : 645877924504150016,
  "created_at" : "2015-09-21 08:31:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DonDahlmann",
      "screen_name" : "DonDahlmann",
      "indices" : [ 0, 12 ],
      "id_str" : "1151281",
      "id" : 1151281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7qBV4wAzLz",
      "expanded_url" : "https:\/\/instagram.com\/p\/70oHq4PBLK\/",
      "display_url" : "instagram.com\/p\/70oHq4PBLK\/"
    } ]
  },
  "in_reply_to_status_id_str" : "645875395154284544",
  "geo" : { },
  "id_str" : "645876102376894464",
  "in_reply_to_user_id" : 1151281,
  "text" : "@DonDahlmann Es gibt noch Hoffnung: Unser dummer Kater ist nach \u00FCber 2 Wochen Suche von selbst wieder aufgetaucht. https:\/\/t.co\/7qBV4wAzLz",
  "id" : 645876102376894464,
  "in_reply_to_status_id" : 645875395154284544,
  "created_at" : "2015-09-21 08:23:57 +0000",
  "in_reply_to_screen_name" : "DonDahlmann",
  "in_reply_to_user_id_str" : "1151281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645874240466604033",
  "text" : "By now many evolutionary biologists would be more than happy to lay down one Dawkins for 1\/8th of a Haldane.",
  "id" : 645874240466604033,
  "created_at" : "2015-09-21 08:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/j3QbH5RNTA",
      "expanded_url" : "https:\/\/instagram.com\/p\/74om19hwsL\/",
      "display_url" : "instagram.com\/p\/74om19hwsL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "645867966928658432",
  "text" : "super inviting https:\/\/t.co\/j3QbH5RNTA",
  "id" : 645867966928658432,
  "created_at" : "2015-09-21 07:51:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UTS ePRESS",
      "screen_name" : "UTSePRESS",
      "indices" : [ 3, 13 ],
      "id_str" : "1724389009",
      "id" : 1724389009
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/oypWzjw5Le",
      "expanded_url" : "https:\/\/goo.gl\/2zhY2n",
      "display_url" : "goo.gl\/2zhY2n"
    } ]
  },
  "geo" : { },
  "id_str" : "645867308481675265",
  "text" : "RT @UTSePRESS: @gedankenstuecke How I Got to be Called the Mark Zuckerberg of Open Source Genetics https:\/\/t.co\/oypWzjw5Le Nice!\n#opendata \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "openscience",
        "indices" : [ 124, 136 ]
      }, {
        "text" : "oa",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/oypWzjw5Le",
        "expanded_url" : "https:\/\/goo.gl\/2zhY2n",
        "display_url" : "goo.gl\/2zhY2n"
      } ]
    },
    "geo" : { },
    "id_str" : "645748768436936704",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke How I Got to be Called the Mark Zuckerberg of Open Source Genetics https:\/\/t.co\/oypWzjw5Le Nice!\n#opendata #openscience #oa",
    "id" : 645748768436936704,
    "created_at" : "2015-09-20 23:57:58 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "UTS ePRESS",
      "screen_name" : "UTSePRESS",
      "protected" : false,
      "id_str" : "1724389009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000403738429\/3f03c898c9e020840a873f12147ec098_normal.jpeg",
      "id" : 1724389009,
      "verified" : false
    }
  },
  "id" : 645867308481675265,
  "created_at" : "2015-09-21 07:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645854115118088192",
  "text" : "TIL: On this day 155 years ago Schopenhauer died in Frankfurt.",
  "id" : 645854115118088192,
  "created_at" : "2015-09-21 06:56:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Thompson",
      "screen_name" : "kiwinat",
      "indices" : [ 3, 11 ],
      "id_str" : "19125281",
      "id" : 19125281
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 93, 109 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 110, 122 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645750485765496832",
  "text" : "RT @kiwinat: Mark Zuckerberg of open source genetics? A neat personal open access piece from @gedankenstuecke @theWinnower http:\/\/t.co\/9WBH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 80, 96 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "the Winnower",
        "screen_name" : "theWinnower",
        "indices" : [ 97, 109 ],
        "id_str" : "748018813",
        "id" : 748018813
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/9WBHt1SXKr",
        "expanded_url" : "http:\/\/tinyurl.com\/pqbsz8l",
        "display_url" : "tinyurl.com\/pqbsz8l"
      } ]
    },
    "geo" : { },
    "id_str" : "645748151123468288",
    "text" : "Mark Zuckerberg of open source genetics? A neat personal open access piece from @gedankenstuecke @theWinnower http:\/\/t.co\/9WBHt1SXKr",
    "id" : 645748151123468288,
    "created_at" : "2015-09-20 23:55:31 +0000",
    "user" : {
      "name" : "Natalie Thompson",
      "screen_name" : "kiwinat",
      "protected" : false,
      "id_str" : "19125281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791845665357778945\/17J7pAYy_normal.jpg",
      "id" : 19125281,
      "verified" : false
    }
  },
  "id" : 645750485765496832,
  "created_at" : "2015-09-21 00:04:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Daschek",
      "screen_name" : "noniq",
      "indices" : [ 0, 6 ],
      "id_str" : "17576232",
      "id" : 17576232
    }, {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 7, 17 ],
      "id_str" : "16958590",
      "id" : 16958590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645742136231596032",
  "geo" : { },
  "id_str" : "645743822153064448",
  "in_reply_to_user_id" : 17576232,
  "text" : "@noniq @coraxaroc ja, w\u00FCrde nur funktionieren wenn immer die zuerst gew\u00E4hlte Antwort und die Richtige stehen bleiben w\u00FCrden. :)",
  "id" : 645743822153064448,
  "in_reply_to_status_id" : 645742136231596032,
  "created_at" : "2015-09-20 23:38:19 +0000",
  "in_reply_to_screen_name" : "noniq",
  "in_reply_to_user_id_str" : "17576232",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Daschek",
      "screen_name" : "noniq",
      "indices" : [ 0, 6 ],
      "id_str" : "17576232",
      "id" : 17576232
    }, {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 7, 17 ],
      "id_str" : "16958590",
      "id" : 16958590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645742043596222465",
  "geo" : { },
  "id_str" : "645742502943846400",
  "in_reply_to_user_id" : 17576232,
  "text" : "@noniq @coraxaroc genau das ist der Unterschied zur Ziege und sorgt daf\u00FCr das es hier 50:50 bleibt :)",
  "id" : 645742502943846400,
  "in_reply_to_status_id" : 645742043596222465,
  "created_at" : "2015-09-20 23:33:04 +0000",
  "in_reply_to_screen_name" : "noniq",
  "in_reply_to_user_id_str" : "17576232",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 0, 10 ],
      "id_str" : "16958590",
      "id" : 16958590
    }, {
      "name" : "Stefan Daschek",
      "screen_name" : "noniq",
      "indices" : [ 17, 23 ],
      "id_str" : "17576232",
      "id" : 17576232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645741351447986177",
  "geo" : { },
  "id_str" : "645741626225201152",
  "in_reply_to_user_id" : 16958590,
  "text" : "@coraxaroc denke @noniq hat recht. Anders als bei den Ziegen bleibt die zuerst gew\u00E4hlte Antwort ja nicht immer im rennen.",
  "id" : 645741626225201152,
  "in_reply_to_status_id" : 645741351447986177,
  "created_at" : "2015-09-20 23:29:35 +0000",
  "in_reply_to_screen_name" : "coraxaroc",
  "in_reply_to_user_id_str" : "16958590",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 0, 10 ],
      "id_str" : "16958590",
      "id" : 16958590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645737520131637248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407462730443, 8.753379214277624 ]
  },
  "id_str" : "645737883530326016",
  "in_reply_to_user_id" : 16958590,
  "text" : "@coraxaroc danke! :)",
  "id" : 645737883530326016,
  "in_reply_to_status_id" : 645737520131637248,
  "created_at" : "2015-09-20 23:14:43 +0000",
  "in_reply_to_screen_name" : "coraxaroc",
  "in_reply_to_user_id_str" : "16958590",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Jj5TU7CEo8",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2015\/09\/20\/fashion\/modern-love-quirkyalone-is-still-alone.html?_r=0",
      "display_url" : "mobile.nytimes.com\/2015\/09\/20\/fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645733324279910401",
  "text" : "\u00ABListen, I love you, but it\u2019s only Stage 1 \u2014 still very treatable.\u00BB http:\/\/t.co\/Jj5TU7CEo8",
  "id" : 645733324279910401,
  "created_at" : "2015-09-20 22:56:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/yuN4e6jPsq",
      "expanded_url" : "http:\/\/vignette3.wikia.nocookie.net\/uncyclopedia\/images\/3\/3e\/Red_Communist_Party.jpg\/revision\/latest?cb=20120229172022",
      "display_url" : "vignette3.wikia.nocookie.net\/uncyclopedia\/i\u2026"
    }, {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/jMMMymv48j",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/09\/17\/fashion\/death-of-the-party.html",
      "display_url" : "nytimes.com\/2015\/09\/17\/fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645659374774546432",
  "text" : "the death of the party http:\/\/t.co\/yuN4e6jPsq http:\/\/t.co\/jMMMymv48j",
  "id" : 645659374774546432,
  "created_at" : "2015-09-20 18:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen McCarthy",
      "screen_name" : "HistorianHelen",
      "indices" : [ 3, 18 ],
      "id_str" : "552682584",
      "id" : 552682584
    }, {
      "name" : "Amia Srinivasan",
      "screen_name" : "amiasrinivasan",
      "indices" : [ 37, 52 ],
      "id_str" : "14651591",
      "id" : 14651591
    }, {
      "name" : "London Review (LRB)",
      "screen_name" : "LRB",
      "indices" : [ 93, 97 ],
      "id_str" : "23975060",
      "id" : 23975060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UOewLvlu7d",
      "expanded_url" : "http:\/\/www.lrb.co.uk\/v37\/n18\/amia-srinivasan\/stop-the-robot-apocalypse",
      "display_url" : "lrb.co.uk\/v37\/n18\/amia-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645655674219831296",
  "text" : "RT @HistorianHelen: This critique by @amiasrinivasan of the Effective Altruism 'movement' in @LRB is bloody brilliant http:\/\/t.co\/UOewLvlu7d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amia Srinivasan",
        "screen_name" : "amiasrinivasan",
        "indices" : [ 17, 32 ],
        "id_str" : "14651591",
        "id" : 14651591
      }, {
        "name" : "London Review (LRB)",
        "screen_name" : "LRB",
        "indices" : [ 73, 77 ],
        "id_str" : "23975060",
        "id" : 23975060
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/UOewLvlu7d",
        "expanded_url" : "http:\/\/www.lrb.co.uk\/v37\/n18\/amia-srinivasan\/stop-the-robot-apocalypse",
        "display_url" : "lrb.co.uk\/v37\/n18\/amia-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645306480116297728",
    "text" : "This critique by @amiasrinivasan of the Effective Altruism 'movement' in @LRB is bloody brilliant http:\/\/t.co\/UOewLvlu7d",
    "id" : 645306480116297728,
    "created_at" : "2015-09-19 18:40:28 +0000",
    "user" : {
      "name" : "Helen McCarthy",
      "screen_name" : "HistorianHelen",
      "protected" : false,
      "id_str" : "552682584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461825693379088384\/jF5S_x--_normal.jpeg",
      "id" : 552682584,
      "verified" : false
    }
  },
  "id" : 645655674219831296,
  "created_at" : "2015-09-20 17:48:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645654831034703872",
  "geo" : { },
  "id_str" : "645655166490951680",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU and \u201Cguilty by association\u201D really is a problem as well, because it\u2019s easy to get binned with the capital-A atheists. ;)",
  "id" : 645655166490951680,
  "in_reply_to_status_id" : 645654831034703872,
  "created_at" : "2015-09-20 17:46:02 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645645431851085824",
  "geo" : { },
  "id_str" : "645647489438220288",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU \u2026for me the term is too much loaded for the strong \u201Ci know there is no god\u201D-camp. Would ID myself more as an agnostic.",
  "id" : 645647489438220288,
  "in_reply_to_status_id" : 645645431851085824,
  "created_at" : "2015-09-20 17:15:31 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645645431851085824",
  "geo" : { },
  "id_str" : "645647099044995072",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU not stupid at all I\u2019d say. I know there are prob as many definitions for atheists as self-id\u2019d atheists, but\u2026",
  "id" : 645647099044995072,
  "in_reply_to_status_id" : 645645431851085824,
  "created_at" : "2015-09-20 17:13:58 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645637907357806592",
  "geo" : { },
  "id_str" : "645638567985868800",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU and my opinion towards any god hasn\u2019t changed either, but I\u2019d never call myself atheist or (god-forbid!) skeptic :D",
  "id" : 645638567985868800,
  "in_reply_to_status_id" : 645637907357806592,
  "created_at" : "2015-09-20 16:40:04 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645637907357806592",
  "geo" : { },
  "id_str" : "645638385902731264",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU as i\u2019m not too much into tattoo removal (and can\u2019t drop the degree) i\u2019m somewhat bound to stay an evolutionary biologist ;)",
  "id" : 645638385902731264,
  "in_reply_to_status_id" : 645637907357806592,
  "created_at" : "2015-09-20 16:39:21 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645633266255560704",
  "text" : "When I was a teen Dawkins &amp; Maher fueled my interest into atheism &amp; evolution. Now they\u2019re the reason I\u2019d love to drop\/dropped those labels\u2026",
  "id" : 645633266255560704,
  "created_at" : "2015-09-20 16:19:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 9, 17 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Steve Laurie",
      "screen_name" : "SteveLaurie42",
      "indices" : [ 18, 32 ],
      "id_str" : "409576747",
      "id" : 409576747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645613861823909888",
  "geo" : { },
  "id_str" : "645619705106026497",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup @glyn_dk @SteveLaurie42 the thing I would love to see are the plushies. I love the cuddly bases :D",
  "id" : 645619705106026497,
  "in_reply_to_status_id" : 645613861823909888,
  "created_at" : "2015-09-20 15:25:07 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Steve Laurie",
      "screen_name" : "SteveLaurie42",
      "indices" : [ 9, 23 ],
      "id_str" : "409576747",
      "id" : 409576747
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 61, 69 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645556458692734976",
  "geo" : { },
  "id_str" : "645557514705223680",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @SteveLaurie42 i don\u2019t think so, i basically begged @junaxup to make more and it didn\u2019t help :)",
  "id" : 645557514705223680,
  "in_reply_to_status_id" : 645556458692734976,
  "created_at" : "2015-09-20 11:18:00 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11831174308345, 16.56828441332408 ]
  },
  "id_str" : "645519629075546112",
  "text" : "Goodbye Vienna &amp; #GET2015: VIE \u2708\uFE0F FRA on LH 1235.",
  "id" : 645519629075546112,
  "created_at" : "2015-09-20 08:47:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645506730386980864",
  "text" : "The list of items in carry-on that security suspects to be bombs is growing with virtually every single flight. Probably next: my toothbrush",
  "id" : 645506730386980864,
  "created_at" : "2015-09-20 07:56:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/0OMze0hAUj",
      "expanded_url" : "http:\/\/ollydbg.de\/Paperbak\/#1",
      "display_url" : "ollydbg.de\/Paperbak\/#1"
    } ]
  },
  "geo" : { },
  "id_str" : "645505300229976064",
  "text" : "Revolutionary: PaperBack \u2013 How to store data on a single A4\/Letter sheet http:\/\/t.co\/0OMze0hAUj",
  "id" : 645505300229976064,
  "created_at" : "2015-09-20 07:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren",
      "screen_name" : "lhockenson",
      "indices" : [ 3, 14 ],
      "id_str" : "165834612",
      "id" : 165834612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jvZoTw7IyL",
      "expanded_url" : "https:\/\/twitter.com\/TheNextWeb\/status\/644999378747400192",
      "display_url" : "twitter.com\/TheNextWeb\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645502509012942848",
  "text" : "RT @lhockenson: This is the most stomach-churning farce of a Women in Tech Panel I\u2019ve ever seen. It will shock you. https:\/\/t.co\/jvZoTw7IyL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/jvZoTw7IyL",
        "expanded_url" : "https:\/\/twitter.com\/TheNextWeb\/status\/644999378747400192",
        "display_url" : "twitter.com\/TheNextWeb\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644999533005434880",
    "text" : "This is the most stomach-churning farce of a Women in Tech Panel I\u2019ve ever seen. It will shock you. https:\/\/t.co\/jvZoTw7IyL",
    "id" : 644999533005434880,
    "created_at" : "2015-09-18 22:20:46 +0000",
    "user" : {
      "name" : "Lauren",
      "screen_name" : "lhockenson",
      "protected" : false,
      "id_str" : "165834612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856585515348262912\/L_rfNH0w_normal.jpg",
      "id" : 165834612,
      "verified" : true
    }
  },
  "id" : 645502509012942848,
  "created_at" : "2015-09-20 07:39:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ambarrio",
      "screen_name" : "ambarrio",
      "indices" : [ 0, 9 ],
      "id_str" : "406442515",
      "id" : 406442515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645398646578618368",
  "geo" : { },
  "id_str" : "645500664110546944",
  "in_reply_to_user_id" : 406442515,
  "text" : "@ambarrio thanks! Glad you liked Metalab. Happy to show you around Frankfurt if you ever leave the airport there :D",
  "id" : 645500664110546944,
  "in_reply_to_status_id" : 645398646578618368,
  "created_at" : "2015-09-20 07:32:05 +0000",
  "in_reply_to_screen_name" : "ambarrio",
  "in_reply_to_user_id_str" : "406442515",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ambarrio",
      "screen_name" : "ambarrio",
      "indices" : [ 0, 9 ],
      "id_str" : "406442515",
      "id" : 406442515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645254402815717376",
  "geo" : { },
  "id_str" : "645365064447492096",
  "in_reply_to_user_id" : 406442515,
  "text" : "@ambarrio that was fun :D",
  "id" : 645365064447492096,
  "in_reply_to_status_id" : 645254402815717376,
  "created_at" : "2015-09-19 22:33:16 +0000",
  "in_reply_to_screen_name" : "ambarrio",
  "in_reply_to_user_id_str" : "406442515",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 9, 20 ],
      "id_str" : "18372260",
      "id" : 18372260
    }, {
      "name" : "Matthew Herper",
      "screen_name" : "matthewherper",
      "indices" : [ 21, 35 ],
      "id_str" : "44438256",
      "id" : 44438256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645361370339393536",
  "geo" : { },
  "id_str" : "645361906484703232",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @grapealope @matthewherper wonder how this translates to sleep trackers ;)",
  "id" : 645361906484703232,
  "in_reply_to_status_id" : 645361370339393536,
  "created_at" : "2015-09-19 22:20:43 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/7x0lJyPcdI",
      "expanded_url" : "https:\/\/instagram.com\/p\/71BktvBwkw\/",
      "display_url" : "instagram.com\/p\/71BktvBwkw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "645359921161220097",
  "text" : "Lovely rooftop view from CeMM during #GET2015 lunches. https:\/\/t.co\/7x0lJyPcdI",
  "id" : 645359921161220097,
  "created_at" : "2015-09-19 22:12:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 9, 19 ],
      "id_str" : "334912047",
      "id" : 334912047
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 45, 53 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645355214577487872",
  "geo" : { },
  "id_str" : "645355917773512704",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @DNADigest thanks should also go to @junaxup who made them :-)",
  "id" : 645355917773512704,
  "in_reply_to_status_id" : 645355214577487872,
  "created_at" : "2015-09-19 21:56:55 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/JDfCTSyGP3",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/645354489512378368",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645354903305617408",
  "text" : "The best way to end #GET2015 \u263A\uFE0F https:\/\/t.co\/JDfCTSyGP3",
  "id" : 645354903305617408,
  "created_at" : "2015-09-19 21:52:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645303952620285952",
  "geo" : { },
  "id_str" : "645306599767179264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC93",
  "id" : 645306599767179264,
  "in_reply_to_status_id" : 645303952620285952,
  "created_at" : "2015-09-19 18:40:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645292284108500992",
  "text" : "\u00ABPlease tell me you have stickers here. My directions from home are pretty clear: I\u2019m not allowed to leave Vienna without Metalab-stickers.\u00BB",
  "id" : 645292284108500992,
  "created_at" : "2015-09-19 17:44:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/HxgmcsoRgU",
      "expanded_url" : "https:\/\/instagram.com\/p\/70AF3jBwtg\/",
      "display_url" : "instagram.com\/p\/70AF3jBwtg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "645215923595542528",
  "text" : "View from the rooftop of the Natural History Museum #latergram https:\/\/t.co\/HxgmcsoRgU",
  "id" : 645215923595542528,
  "created_at" : "2015-09-19 12:40:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 10, 21 ],
      "id_str" : "18372260",
      "id" : 18372260
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 22, 36 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645168606926491648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962974513191, 16.34936132167295 ]
  },
  "id_str" : "645168848635863040",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @grapealope @beaugunderson i hope there\u2019s no scheduling-conflict next year ;)",
  "id" : 645168848635863040,
  "in_reply_to_status_id" : 645168606926491648,
  "created_at" : "2015-09-19 09:33:34 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 0, 11 ],
      "id_str" : "18372260",
      "id" : 18372260
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 12, 26 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 32, 41 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645168480795426816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21959059071527, 16.34938089076435 ]
  },
  "id_str" : "645168733263167488",
  "in_reply_to_user_id" : 18372260,
  "text" : "@grapealope @beaugunderson hear @eramirez, you really need to step up your wearable-game! \uD83D\uDE0D\uD83D\uDE0A",
  "id" : 645168733263167488,
  "in_reply_to_status_id" : 645168480795426816,
  "created_at" : "2015-09-19 09:33:07 +0000",
  "in_reply_to_screen_name" : "grapealope",
  "in_reply_to_user_id_str" : "18372260",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 0, 11 ],
      "id_str" : "18372260",
      "id" : 18372260
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 12, 26 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 77, 86 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645167167701413888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21961717811214, 16.34940724265266 ]
  },
  "id_str" : "645167331002478592",
  "in_reply_to_user_id" : 18372260,
  "text" : "@grapealope @beaugunderson reading the stream is a bad substitute for giving @eramirez a hug!",
  "id" : 645167331002478592,
  "in_reply_to_status_id" : 645167167701413888,
  "created_at" : "2015-09-19 09:27:32 +0000",
  "in_reply_to_screen_name" : "grapealope",
  "in_reply_to_user_id_str" : "18372260",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QSEU15",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645166281247825920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962494126422, 16.34934951519733 ]
  },
  "id_str" : "645166489360842752",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @beaugunderson yeah, so does #QSEU15. Sucks having had to decide on one \uD83D\uDE2D",
  "id" : 645166489360842752,
  "in_reply_to_status_id" : 645166281247825920,
  "created_at" : "2015-09-19 09:24:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 25, 34 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "get2015",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645166053396512768",
  "text" : "RT @BPrainsack: #get2015 @madprime when access to raw data is offered then participation becomes more meaningful",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Madeleine Price Ball",
        "screen_name" : "madprime",
        "indices" : [ 9, 18 ],
        "id_str" : "71557700",
        "id" : 71557700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "get2015",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645165969678143488",
    "text" : "#get2015 @madprime when access to raw data is offered then participation becomes more meaningful",
    "id" : 645165969678143488,
    "created_at" : "2015-09-19 09:22:08 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 645166053396512768,
  "created_at" : "2015-09-19 09:22:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 5, 14 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962331447803, 16.34933864803273 ]
  },
  "id_str" : "645164136297570304",
  "text" : "Now: @madprime on personal data, public sharing &amp; connecting participants to research. #GET2015",
  "id" : 645164136297570304,
  "created_at" : "2015-09-19 09:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "get2015",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645162912395431936",
  "text" : "RT @BPrainsack: #get2015 B Knoppers: Right to Science= 1. Right 2benefit from science 2. right 2recognition of scientific production http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "get2015",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/N0WrB0jMmD",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC4053599\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645162791410794496",
    "text" : "#get2015 B Knoppers: Right to Science= 1. Right 2benefit from science 2. right 2recognition of scientific production http:\/\/t.co\/N0WrB0jMmD",
    "id" : 645162791410794496,
    "created_at" : "2015-09-19 09:09:30 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 645162912395431936,
  "created_at" : "2015-09-19 09:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21960737720993, 16.34938497608374 ]
  },
  "id_str" : "645161670189445120",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack thanks for the great talk!",
  "id" : 645161670189445120,
  "created_at" : "2015-09-19 09:05:03 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 55, 66 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21960737720993, 16.34938497608374 ]
  },
  "id_str" : "645161178952527872",
  "text" : "\u00ABnot only science, but also healthcare should be open\u00BB @BPrainsack #GET2015",
  "id" : 645161178952527872,
  "created_at" : "2015-09-19 09:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 40, 51 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21960630808827, 16.34932074725318 ]
  },
  "id_str" : "645160545868480512",
  "text" : "\u00ABReciprocity is the core of openness\u00BB \u2013 @BPrainsack #GET2015",
  "id" : 645160545868480512,
  "created_at" : "2015-09-19 09:00:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 10, 21 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645149964713201665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21961117626616, 16.34939658653465 ]
  },
  "id_str" : "645150189431488514",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @EffyVayena I know, ever since hearing about it I\u2019m telling everyone who will listen that I\u2019m a human rights activist!",
  "id" : 645150189431488514,
  "in_reply_to_status_id" : 645149964713201665,
  "created_at" : "2015-09-19 08:19:26 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645148044762198016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962780584694, 16.34940526461867 ]
  },
  "id_str" : "645148613975363584",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson my guess is that they will be excluded because today being a scientist still means being backed by an institution.",
  "id" : 645148613975363584,
  "in_reply_to_status_id" : 645148044762198016,
  "created_at" : "2015-09-19 08:13:10 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645147867284377600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962780584694, 16.34940526461867 ]
  },
  "id_str" : "645148166803881984",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson from what I\u2019ve seen\/heard you seem to be the exception rather than the rule. :)",
  "id" : 645148166803881984,
  "in_reply_to_status_id" : 645147867284377600,
  "created_at" : "2015-09-19 08:11:23 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962520590687, 16.34941045096094 ]
  },
  "id_str" : "645145859810807808",
  "text" : "wearables: no one is getting VC for building hardware, it\u2019s the data streams that are valuable. #GET2015",
  "id" : 645145859810807808,
  "created_at" : "2015-09-19 08:02:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21962520590687, 16.34941045096094 ]
  },
  "id_str" : "645144847083548672",
  "text" : "the biggest technical challenge for wearables: battery life, our batteries suck. #GET2015",
  "id" : 645144847083548672,
  "created_at" : "2015-09-19 07:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 23, 34 ],
      "id_str" : "18372260",
      "id" : 18372260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "get2015",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645144151458213888",
  "text" : "RT @madprime: #get2015 @grapealope shares exciting \u2013 and funny \u2013 wearables &amp; integrated tech. A vest that \"hugs\" for a facebook \"like\"!  (\u3065\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel Kalmar",
        "screen_name" : "grapealope",
        "indices" : [ 9, 20 ],
        "id_str" : "18372260",
        "id" : 18372260
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "get2015",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "645144108776996864",
    "text" : "#get2015 @grapealope shares exciting \u2013 and funny \u2013 wearables &amp; integrated tech. A vest that \"hugs\" for a facebook \"like\"!  (\u3065\uFFE3 \u00B3\uFFE3)\u3065",
    "id" : 645144108776996864,
    "created_at" : "2015-09-19 07:55:16 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 645144151458213888,
  "created_at" : "2015-09-19 07:55:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21963028288602, 16.34935656814606 ]
  },
  "id_str" : "645143851309641729",
  "text" : "\u00ABIn the not too distant future everything will be connected.\u00BB How many US participants can use google maps on their phones here? #GET2015",
  "id" : 645143851309641729,
  "created_at" : "2015-09-19 07:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Synthetic Future(s)",
      "screen_name" : "SynFutures",
      "indices" : [ 3, 14 ],
      "id_str" : "1119861073",
      "id" : 1119861073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645142778721210368",
  "text" : "RT @SynFutures: Our governments now treat us like cattle \u2013 governed by fear, we have surrendered too many of our hard-won freedoms...\nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/994jufiE7u",
        "expanded_url" : "http:\/\/gu.com\/p\/4cdgy\/stw",
        "display_url" : "gu.com\/p\/4cdgy\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "645140962554052608",
    "text" : "Our governments now treat us like cattle \u2013 governed by fear, we have surrendered too many of our hard-won freedoms...\nhttp:\/\/t.co\/994jufiE7u",
    "id" : 645140962554052608,
    "created_at" : "2015-09-19 07:42:46 +0000",
    "user" : {
      "name" : "Synthetic Future(s)",
      "screen_name" : "SynFutures",
      "protected" : false,
      "id_str" : "1119861073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000280417804\/626413b63fd1c8df5045e700438e55fe_normal.png",
      "id" : 1119861073,
      "verified" : false
    }
  },
  "id" : 645142778721210368,
  "created_at" : "2015-09-19 07:49:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21963258464719, 16.34936245452308 ]
  },
  "id_str" : "645139525606481920",
  "text" : "the term 'legitimate scientist\u2019 always makes me uneasy. what happens if i lose my membership card to the secret club? #GET2015",
  "id" : 645139525606481920,
  "created_at" : "2015-09-19 07:37:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 17, 27 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645138716382633984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21963258464719, 16.34936245452308 ]
  },
  "id_str" : "645139016174714880",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @SCEdmunds '\u2026can neither confirm nor deny\u2026\u2019",
  "id" : 645139016174714880,
  "in_reply_to_status_id" : 645138716382633984,
  "created_at" : "2015-09-19 07:35:02 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FlsZboDKog",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/18\/how-a-world-war-ii-german-sub.html",
      "display_url" : "boingboing.net\/2015\/09\/18\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645134931593662464",
  "text" : "How a World War II German sub captain used the toilet wrong and sunk his vessel http:\/\/t.co\/FlsZboDKog",
  "id" : 645134931593662464,
  "created_at" : "2015-09-19 07:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/645127251709796353\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/cdnxO4koZJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPPz0TtWcAETCse.jpg",
      "id_str" : "645127251613347841",
      "id" : 645127251613347841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPPz0TtWcAETCse.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/cdnxO4koZJ"
    } ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645127251709796353",
  "text" : "Found on a random building while walking to dinner yesterday: Free Science, Free Data #GET2015 http:\/\/t.co\/cdnxO4koZJ",
  "id" : 645127251709796353,
  "created_at" : "2015-09-19 06:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645104306383884288",
  "geo" : { },
  "id_str" : "645107224445104128",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia we should compare travel plans, by chance we could end up some place at the same time.",
  "id" : 645107224445104128,
  "in_reply_to_status_id" : 645104306383884288,
  "created_at" : "2015-09-19 05:28:42 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645004433609347073",
  "geo" : { },
  "id_str" : "645004529302376449",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj overusing the magic operator on psychedelic drugs",
  "id" : 645004529302376449,
  "in_reply_to_status_id" : 645004433609347073,
  "created_at" : "2015-09-18 22:40:38 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645003564054614017",
  "geo" : { },
  "id_str" : "645004129094516736",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj in the genetic code there\u2019s somewhere a comment \u201C# ugly workaround, but somehow works for now, dunno why!\u201D",
  "id" : 645004129094516736,
  "in_reply_to_status_id" : 645003564054614017,
  "created_at" : "2015-09-18 22:39:02 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644992343305793536",
  "geo" : { },
  "id_str" : "645003443409670144",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia now i really wanna travel with you some time.",
  "id" : 645003443409670144,
  "in_reply_to_status_id" : 644992343305793536,
  "created_at" : "2015-09-18 22:36:19 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/80VB9468cU",
      "expanded_url" : "https:\/\/twitter.com\/BioDataGanache\/status\/644912511893012480",
      "display_url" : "twitter.com\/BioDataGanache\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645002176734081025",
  "text" : "Obviously never corrected for multiple testing. I mean: just look at the platypus! https:\/\/t.co\/80VB9468cU",
  "id" : 645002176734081025,
  "created_at" : "2015-09-18 22:31:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 3, 18 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Reviewer3",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645001916548841476",
  "text" : "RT @BioDataGanache: God: Here's my proposal for evolution\nRev1: Great. Love the platypus.\nRev2: Cool. More unicorns?\n#Reviewer3: MASSIVE FI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Reviewer3",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644912511893012480",
    "text" : "God: Here's my proposal for evolution\nRev1: Great. Love the platypus.\nRev2: Cool. More unicorns?\n#Reviewer3: MASSIVE FISHING EXPEDITION",
    "id" : 644912511893012480,
    "created_at" : "2015-09-18 16:34:59 +0000",
    "user" : {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "protected" : false,
      "id_str" : "1040758742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825446808696483840\/nMI6-h4y_normal.jpg",
      "id" : 1040758742,
      "verified" : false
    }
  },
  "id" : 645001916548841476,
  "created_at" : "2015-09-18 22:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644997453561896960",
  "geo" : { },
  "id_str" : "644998878119501825",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk yes, looks like we\u2019re really lucky with the conference venues this year :D",
  "id" : 644998878119501825,
  "in_reply_to_status_id" : 644997453561896960,
  "created_at" : "2015-09-18 22:18:10 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/eoq80fJwmm",
      "expanded_url" : "https:\/\/instagram.com\/p\/7yc0_whwju\/",
      "display_url" : "instagram.com\/p\/7yc0_whwju\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.205152782, 16.360251302 ]
  },
  "id_str" : "644997639373778944",
  "text" : "Carrying 'The Descent of Man' \uD83D\uDC12\uD83D\uDC9D @ NhM Naturhistorisches Museum Wien https:\/\/t.co\/eoq80fJwmm",
  "id" : 644997639373778944,
  "created_at" : "2015-09-18 22:13:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/o9GFBau6JT",
      "expanded_url" : "https:\/\/instagram.com\/p\/7yaht2hwve\/",
      "display_url" : "instagram.com\/p\/7yaht2hwve\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644992579885473792",
  "text" : "\u00ABI'm sure they just call it 'skull hallway' for historical reasons\u2026or maybe not\u2026\u00BB #GET2015 https:\/\/t.co\/o9GFBau6JT",
  "id" : 644992579885473792,
  "created_at" : "2015-09-18 21:53:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644988889959112704",
  "geo" : { },
  "id_str" : "644991887825371136",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv no, I\u2019m in Vienna until Sunday. But did meet someone Berlin-based here and she\u2019s interested in genome sonification.",
  "id" : 644991887825371136,
  "in_reply_to_status_id" : 644988889959112704,
  "created_at" : "2015-09-18 21:50:24 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644988775463014400",
  "text" : "\u00ABWhat did bring you to Vienna?\u00BB\u2014\u00ABFor my studies it was either Bielefeld or Vienna, so\u2026\u00BB\u2014\u00ABNo need to go on!\u00BB",
  "id" : 644988775463014400,
  "created_at" : "2015-09-18 21:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644927118812540928",
  "geo" : { },
  "id_str" : "644987469058998274",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk better clone some Neanderthals quickly to defend him \uD83D\uDE02\uD83D\uDE07",
  "id" : 644987469058998274,
  "in_reply_to_status_id" : 644927118812540928,
  "created_at" : "2015-09-18 21:32:50 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644962032157106176",
  "geo" : { },
  "id_str" : "644982349181100032",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv btw met someone from Berlin I have to introduce you to tomorrow :3",
  "id" : 644982349181100032,
  "in_reply_to_status_id" : 644962032157106176,
  "created_at" : "2015-09-18 21:12:29 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/pkzrFqmRtO",
      "expanded_url" : "https:\/\/instagram.com\/p\/7yNvGWBwn1\/",
      "display_url" : "instagram.com\/p\/7yNvGWBwn1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644964454329917440",
  "text" : "View at the conference dinner #GET2015 https:\/\/t.co\/pkzrFqmRtO",
  "id" : 644964454329917440,
  "created_at" : "2015-09-18 20:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "indices" : [ 0, 12 ],
      "id_str" : "215420646",
      "id" : 215420646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644939314388930564",
  "geo" : { },
  "id_str" : "644959850116554752",
  "in_reply_to_user_id" : 215420646,
  "text" : "@jessiet1023 haha, I wouldn\u2019t say better. Very different kind of history to experience here :)",
  "id" : 644959850116554752,
  "in_reply_to_status_id" : 644939314388930564,
  "created_at" : "2015-09-18 19:43:05 +0000",
  "in_reply_to_screen_name" : "jessiet1023",
  "in_reply_to_user_id_str" : "215420646",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/3zj3ugrYBE",
      "expanded_url" : "https:\/\/instagram.com\/p\/7x-t9_hwtD\/",
      "display_url" : "instagram.com\/p\/7x-t9_hwtD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644931421010833408",
  "text" : "Nice haircut! https:\/\/t.co\/3zj3ugrYBE",
  "id" : 644931421010833408,
  "created_at" : "2015-09-18 17:50:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/M2SKVidcN7",
      "expanded_url" : "https:\/\/instagram.com\/p\/7x-MtiBwr-\/",
      "display_url" : "instagram.com\/p\/7x-MtiBwr-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644930803995123712",
  "text" : "Ok Vienna, this is a great location for a cocktail party. I\u2019m in love! #GET2015 https:\/\/t.co\/M2SKVidcN7",
  "id" : 644930803995123712,
  "created_at" : "2015-09-18 17:47:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644899650571513856",
  "geo" : { },
  "id_str" : "644900436655362048",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime \u201CDas Pers\u00F6nliche Genom Projekt!\u201D, works best if you shout it with a caricaturesk Nazi-Germany voice.",
  "id" : 644900436655362048,
  "in_reply_to_status_id" : 644899650571513856,
  "created_at" : "2015-09-18 15:47:00 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644899771015163904",
  "text" : "RT @madprime: In PGP UK Stephan Beck describes the conversion of traditional consent to open consent, converting data to be open access #ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "get2015",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644898517266399232",
    "text" : "In PGP UK Stephan Beck describes the conversion of traditional consent to open consent, converting data to be open access #get2015",
    "id" : 644898517266399232,
    "created_at" : "2015-09-18 15:39:22 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 644899771015163904,
  "created_at" : "2015-09-18 15:44:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ZOxhf6oQTY",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP?ty=h",
      "display_url" : "patreon.com\/openSNP?ty=h"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.219659, 16.349333 ]
  },
  "id_str" : "644894109421961216",
  "text" : "Thanks to @beaugunderson for being our first 'external' openSNP-patron. \uD83D\uDC93 #GET2015  https:\/\/t.co\/ZOxhf6oQTY",
  "id" : 644894109421961216,
  "created_at" : "2015-09-18 15:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 45, 56 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/f5jXJ1Lj6b",
      "expanded_url" : "https:\/\/opensnp.org\/signup",
      "display_url" : "opensnp.org\/signup"
    } ]
  },
  "geo" : { },
  "id_str" : "644893476321140737",
  "text" : "RT @BPrainsack: #GET2015 Bastian admits that @openSNPorg's ToS are not written to attract users really. https:\/\/t.co\/f5jXJ1Lj6b No not real\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 29, 40 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GET2015",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/f5jXJ1Lj6b",
        "expanded_url" : "https:\/\/opensnp.org\/signup",
        "display_url" : "opensnp.org\/signup"
      } ]
    },
    "geo" : { },
    "id_str" : "644891206703558656",
    "text" : "#GET2015 Bastian admits that @openSNPorg's ToS are not written to attract users really. https:\/\/t.co\/f5jXJ1Lj6b No not really.",
    "id" : 644891206703558656,
    "created_at" : "2015-09-18 15:10:19 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 644893476321140737,
  "created_at" : "2015-09-18 15:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644892440776806400",
  "geo" : { },
  "id_str" : "644893171739172864",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack thanks for the recommendation. We will :-)",
  "id" : 644893171739172864,
  "in_reply_to_status_id" : 644892440776806400,
  "created_at" : "2015-09-18 15:18:08 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GenomeTerry",
      "screen_name" : "terryvrijenhoek",
      "indices" : [ 0, 16 ],
      "id_str" : "50276212",
      "id" : 50276212
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 82, 88 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644891501781209089",
  "geo" : { },
  "id_str" : "644893078659145728",
  "in_reply_to_user_id" : 50276212,
  "text" : "@terryvrijenhoek more than happy to. On soundcloud there\u2019s the complete song. And @dvzrv can probably provide 6-channel mix. :)",
  "id" : 644893078659145728,
  "in_reply_to_status_id" : 644891501781209089,
  "created_at" : "2015-09-18 15:17:46 +0000",
  "in_reply_to_screen_name" : "terryvrijenhoek",
  "in_reply_to_user_id_str" : "50276212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 28, 44 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644892910241075200",
  "text" : "RT @madprime: openSNP &amp; @gedankenstuecke: publicly sharing genotype if you have it, and collects phenotypes, surveys, fitbit, &gt;2k contribut\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 14, 30 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "get2015",
        "indices" : [ 135, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644890857108213760",
    "text" : "openSNP &amp; @gedankenstuecke: publicly sharing genotype if you have it, and collects phenotypes, surveys, fitbit, &gt;2k contributed #get2015",
    "id" : 644890857108213760,
    "created_at" : "2015-09-18 15:08:56 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 644892910241075200,
  "created_at" : "2015-09-18 15:17:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 134, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644885628950323200",
  "text" : "Finding and accessing data frustrates everyone &amp; it will get worse every time someone shows the Moore\u2019s law\/sequencing cost graph #GET2015",
  "id" : 644885628950323200,
  "created_at" : "2015-09-18 14:48:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 5, 13 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644884443027668992",
  "text" : "Now: @glyn_dk talking about repositive.io and the frustrations of data discovery. #GET2015",
  "id" : 644884443027668992,
  "created_at" : "2015-09-18 14:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644875293493198848",
  "text" : "Now: The importance of genomic phase. Including mention of Seymour Benzer. #GET2015",
  "id" : 644875293493198848,
  "created_at" : "2015-09-18 14:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644872482781065216",
  "text" : "Identifiability: 13 STRs are unique enough to be used for genetic fingerprinting in the US. #GET2015",
  "id" : 644872482781065216,
  "created_at" : "2015-09-18 13:55:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/wtgRCsECMd",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/644861936383995904",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644868779957186560",
  "text" : "Hear me talk openSNP at 5:15pm. Including an audio sample of my genome. #GET2015 https:\/\/t.co\/wtgRCsECMd",
  "id" : 644868779957186560,
  "created_at" : "2015-09-18 13:41:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/0XgJ95raPD",
      "expanded_url" : "https:\/\/twitter.com\/glyn_dk\/status\/644861102585679872",
      "display_url" : "twitter.com\/glyn_dk\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644868350938624001",
  "text" : "Found myself! #GET2015 https:\/\/t.co\/0XgJ95raPD",
  "id" : 644868350938624001,
  "created_at" : "2015-09-18 13:39:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644857114985406464",
  "geo" : { },
  "id_str" : "644857624375205889",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack maybe I\u2019m a cynic, but I expect less rigor from the vows than from science \uD83D\uDE09",
  "id" : 644857624375205889,
  "in_reply_to_status_id" : 644857114985406464,
  "created_at" : "2015-09-18 12:56:53 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644855433845452800",
  "text" : "\u00ABX influences your microbiota\u00BB is the new \u00ABX changes your brain\u00BB #GET2015",
  "id" : 644855433845452800,
  "created_at" : "2015-09-18 12:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hyperbolome",
      "indices" : [ 117, 129 ]
    }, {
      "text" : "GET2015",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644854501128687616",
  "text" : "It\u2019s always somewhat too early to have definite evidence, but somehow it\u2019s never too early to make grandiose claims. #hyperbolome #GET2015",
  "id" : 644854501128687616,
  "created_at" : "2015-09-18 12:44:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/644854114363535360\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/dCxaZWffDH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPL7Zn0XAAAH4Ll.jpg",
      "id_str" : "644854114271297536",
      "id" : 644854114271297536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPL7Zn0XAAAH4Ll.jpg",
      "sizes" : [ {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1499
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1499
      } ],
      "display_url" : "pic.twitter.com\/dCxaZWffDH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644854114363535360",
  "text" : "Paint \uD83D\uDE97\uD83D\uDE97 like \uD83D\uDC04\uD83D\uDC04! http:\/\/t.co\/dCxaZWffDH",
  "id" : 644854114363535360,
  "created_at" : "2015-09-18 12:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644852663344058371",
  "text" : "Now the really hard questions: What kind of sample would you like to receive via mail? DNA? Blood? Urine? Poo? #GET2015",
  "id" : 644852663344058371,
  "created_at" : "2015-09-18 12:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644812536165044224",
  "text" : "JC: Why is consent to removing half of patients brain done more easily than consent to sharing genetic data? #GET2015",
  "id" : 644812536165044224,
  "created_at" : "2015-09-18 09:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644811608443736064",
  "text" : "RT @edyong209: That chap who got bees to sting him on the eyes\/nose\/penis just won an Ignobel. Here's my piece about his study http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/ssZug3fcfD",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/04\/03\/the-worst-places-to-get-stung-by-a-bee-nostril-lip-penis\/",
        "display_url" : "phenomena.nationalgeographic.com\/2014\/04\/03\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644811561727561728",
    "text" : "That chap who got bees to sting him on the eyes\/nose\/penis just won an Ignobel. Here's my piece about his study http:\/\/t.co\/ssZug3fcfD",
    "id" : 644811561727561728,
    "created_at" : "2015-09-18 09:53:50 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 644811608443736064,
  "created_at" : "2015-09-18 09:54:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/644810886973104128\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yN8jEiwBI2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPLUFdAWgAIks9y.jpg",
      "id_str" : "644810886817939458",
      "id" : 644810886817939458,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPLUFdAWgAIks9y.jpg",
      "sizes" : [ {
        "h" : 1178,
        "resize" : "fit",
        "w" : 1571
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1178,
        "resize" : "fit",
        "w" : 1571
      } ],
      "display_url" : "pic.twitter.com\/yN8jEiwBI2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644810886973104128",
  "text" : "Overly specific statement: \u00ABNever use people who love you.\u00BB (screw all others) \u2014 Paula, 9 years old http:\/\/t.co\/yN8jEiwBI2",
  "id" : 644810886973104128,
  "created_at" : "2015-09-18 09:51:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/h8pqnDtNmJ",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view5\/2818549\/cantina-band-o.gif",
      "display_url" : "stream1.gifsoup.com\/view5\/2818549\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "644808981945389056",
  "geo" : { },
  "id_str" : "644810305063755776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/h8pqnDtNmJ",
  "id" : 644810305063755776,
  "in_reply_to_status_id" : 644808981945389056,
  "created_at" : "2015-09-18 09:48:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 54, 67 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644809396619448320",
  "text" : "\u00ABWhen people hoard data it prevents to find an N=2\u00BB \u2014 @MishaAngrist  #GET2015",
  "id" : 644809396619448320,
  "created_at" : "2015-09-18 09:45:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644804349726720000",
  "geo" : { },
  "id_str" : "644808234755313664",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke oh, danke! :)",
  "id" : 644808234755313664,
  "in_reply_to_status_id" : 644804349726720000,
  "created_at" : "2015-09-18 09:40:37 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644802003546316800",
  "text" : "The problem of nebulous phenotypes. My bet is we will hear about ontologies pretty soon. #GET2015",
  "id" : 644802003546316800,
  "created_at" : "2015-09-18 09:15:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/644799996194365440\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/TlVCYouMWu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPLKLhnXAAEXScE.jpg",
      "id_str" : "644799996018229249",
      "id" : 644799996018229249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPLKLhnXAAEXScE.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1083,
        "resize" : "fit",
        "w" : 1444
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1083,
        "resize" : "fit",
        "w" : 1444
      } ],
      "display_url" : "pic.twitter.com\/TlVCYouMWu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21964, 16.349324 ]
  },
  "id_str" : "644799996194365440",
  "text" : "Progressive Vienna: \u00ABFollow the rules!\u00BB - Yannick, 11 years old. http:\/\/t.co\/TlVCYouMWu",
  "id" : 644799996194365440,
  "created_at" : "2015-09-18 09:07:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21965487316784, 16.34936130671154 ]
  },
  "id_str" : "644787813679013888",
  "text" : "There's no cloud, just other people\u2019s genomes. #GET2015",
  "id" : 644787813679013888,
  "created_at" : "2015-09-18 08:19:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 3, 14 ],
      "id_str" : "18372260",
      "id" : 18372260
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 123, 132 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644785310040260608",
  "text" : "RT @grapealope: \"...taking a piece of information off the internet is like getting food colouring out of a swimming pool.\" @doctorow http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 107, 116 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/sZV3ozKNLx",
        "expanded_url" : "http:\/\/www.theguardian.com\/technology\/2007\/sep\/18\/informationeconomy",
        "display_url" : "theguardian.com\/technology\/200\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.2199118, 16.3482444 ]
    },
    "id_str" : "644784982012116992",
    "text" : "\"...taking a piece of information off the internet is like getting food colouring out of a swimming pool.\" @doctorow http:\/\/t.co\/sZV3ozKNLx",
    "id" : 644784982012116992,
    "created_at" : "2015-09-18 08:08:13 +0000",
    "user" : {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "protected" : false,
      "id_str" : "18372260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780881616\/rachelPortraitSq-sm_normal.jpg",
      "id" : 18372260,
      "verified" : false
    }
  },
  "id" : 644785310040260608,
  "created_at" : "2015-09-18 08:09:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.219654873038, 16.34936131967343 ]
  },
  "id_str" : "644783509874311168",
  "text" : "~2% of people sequenced through Geisinger will have incidental findings returned which are on a list of 76 conditions. #GET2015",
  "id" : 644783509874311168,
  "created_at" : "2015-09-18 08:02:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644776044311019521",
  "text" : "JC on 100kGenomes: In British parlance, telling a prime minister that something is a brave idea is telling him it\u2019s a stupid idea. #GET2015",
  "id" : 644776044311019521,
  "created_at" : "2015-09-18 07:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 0, 11 ],
      "id_str" : "18372260",
      "id" : 18372260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Xk4jSes2HH",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/24990702",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/24990702"
    } ]
  },
  "in_reply_to_status_id_str" : "644772924734459904",
  "geo" : { },
  "id_str" : "644773286291853312",
  "in_reply_to_user_id" : 18372260,
  "text" : "@grapealope one of my favorite ones: http:\/\/t.co\/Xk4jSes2HH",
  "id" : 644773286291853312,
  "in_reply_to_status_id" : 644772924734459904,
  "created_at" : "2015-09-18 07:21:45 +0000",
  "in_reply_to_screen_name" : "grapealope",
  "in_reply_to_user_id_str" : "18372260",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644771335382634496",
  "text" : "\u00ABThere\u2019s more papers on Star Wars than on those SLCs on PubMed.\u00BB #GET2015",
  "id" : 644771335382634496,
  "created_at" : "2015-09-18 07:14:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edur\u2764am loves you",
      "screen_name" : "eduroamLovesYou",
      "indices" : [ 4, 20 ],
      "id_str" : "2612213109",
      "id" : 2612213109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21965166723979, 16.34932379612643 ]
  },
  "id_str" : "644764794017419264",
  "text" : "\uD83D\uDC36 \uD83D\uDC93 @eduroamLovesYou",
  "id" : 644764794017419264,
  "created_at" : "2015-09-18 06:48:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/gJW5gmXC7c",
      "expanded_url" : "https:\/\/twitter.com\/gvwilson\/status\/644755283911311361",
      "display_url" : "twitter.com\/gvwilson\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2171303100146, 16.35112156515738 ]
  },
  "id_str" : "644757419013357568",
  "text" : "Bioinformatics\u2019 answer to this: put yet another Docker around the insanity. https:\/\/t.co\/gJW5gmXC7c",
  "id" : 644757419013357568,
  "created_at" : "2015-09-18 06:18:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/7nZjOCSTZQ",
      "expanded_url" : "https:\/\/instagram.com\/p\/7wucqPhwuN\/",
      "display_url" : "instagram.com\/p\/7wucqPhwuN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644754911859769344",
  "text" : "Morning workout https:\/\/t.co\/7nZjOCSTZQ",
  "id" : 644754911859769344,
  "created_at" : "2015-09-18 06:08:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oa",
      "indices" : [ 49, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/gJUaTMEY0Z",
      "expanded_url" : "http:\/\/bjoern.brembs.net\/2015\/09\/many-symptoms-one-disease\/",
      "display_url" : "bjoern.brembs.net\/2015\/09\/many-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644753851401269248",
  "text" : "RT @brembs: Why can so many be enthused to treat #oa symptoms, but so few dare tackle the disease? http:\/\/t.co\/gJUaTMEY0Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oa",
        "indices" : [ 37, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/gJUaTMEY0Z",
        "expanded_url" : "http:\/\/bjoern.brembs.net\/2015\/09\/many-symptoms-one-disease\/",
        "display_url" : "bjoern.brembs.net\/2015\/09\/many-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644737826815393792",
    "text" : "Why can so many be enthused to treat #oa symptoms, but so few dare tackle the disease? http:\/\/t.co\/gJUaTMEY0Z",
    "id" : 644737826815393792,
    "created_at" : "2015-09-18 05:00:51 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 644753851401269248,
  "created_at" : "2015-09-18 06:04:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    }, {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 30, 40 ],
      "id_str" : "8198012",
      "id" : 8198012
    }, {
      "name" : "Avery Trufelman",
      "screen_name" : "trufelman",
      "indices" : [ 47, 57 ],
      "id_str" : "1528307430",
      "id" : 1528307430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644633139457970176",
  "geo" : { },
  "id_str" : "644633287697244160",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare now I really want @romanmars &amp; @trufelman to do this on a TED stage!",
  "id" : 644633287697244160,
  "in_reply_to_status_id" : 644633139457970176,
  "created_at" : "2015-09-17 22:05:27 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/0g04LrWz78",
      "expanded_url" : "https:\/\/instagram.com\/p\/7vxpG6Bwh-\/",
      "display_url" : "instagram.com\/p\/7vxpG6Bwh-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644621196861001728",
  "text" : "Disappointed that the artist didn't call this sculpture 'balls of steel', would've finally been an\u2026 https:\/\/t.co\/0g04LrWz78",
  "id" : 644621196861001728,
  "created_at" : "2015-09-17 21:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/644617653554966528\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/f1u9CHfLHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPIkVylWIAEtXJz.jpg",
      "id_str" : "644617653441667073",
      "id" : 644617653441667073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPIkVylWIAEtXJz.jpg",
      "sizes" : [ {
        "h" : 982,
        "resize" : "fit",
        "w" : 1270
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 982,
        "resize" : "fit",
        "w" : 1270
      } ],
      "display_url" : "pic.twitter.com\/f1u9CHfLHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.22315, 16.348892 ]
  },
  "id_str" : "644617653554966528",
  "text" : "Must be wrong, they are not advertising 99% Invisible. http:\/\/t.co\/f1u9CHfLHh",
  "id" : 644617653554966528,
  "created_at" : "2015-09-17 21:03:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "indices" : [ 0, 8 ],
      "id_str" : "1529905135",
      "id" : 1529905135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644616584821010432",
  "geo" : { },
  "id_str" : "644616892347514881",
  "in_reply_to_user_id" : 1529905135,
  "text" : "@ARCScon glad to help out. Standard procedure seems to be \u201C. @username $restoftweet\u201D :)",
  "id" : 644616892347514881,
  "in_reply_to_status_id" : 644616584821010432,
  "created_at" : "2015-09-17 21:00:18 +0000",
  "in_reply_to_screen_name" : "ARCScon",
  "in_reply_to_user_id_str" : "1529905135",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "indices" : [ 0, 8 ],
      "id_str" : "1529905135",
      "id" : 1529905135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644614469998415872",
  "geo" : { },
  "id_str" : "644614730204717057",
  "in_reply_to_user_id" : 1529905135,
  "text" : "@ARCScon just a small hint: tweets starting with a username are only seen by people who follow both sender and the one mentioned :)",
  "id" : 644614730204717057,
  "in_reply_to_status_id" : 644614469998415872,
  "created_at" : "2015-09-17 20:51:42 +0000",
  "in_reply_to_screen_name" : "ARCScon",
  "in_reply_to_user_id_str" : "1529905135",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "indices" : [ 3, 11 ],
      "id_str" : "1529905135",
      "id" : 1529905135
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 114, 125 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644614576466710528",
  "text" : "RT @ARCScon: @gedankenstuecke AKA the \"Mark Zuckerberg of Open Source Genetics\" on the intersections of openness, @openSNPorg &amp; his career!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 101, 112 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensience",
        "indices" : [ 133, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644614469998415872",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke AKA the \"Mark Zuckerberg of Open Source Genetics\" on the intersections of openness, @openSNPorg &amp; his career!   #opensience",
    "id" : 644614469998415872,
    "created_at" : "2015-09-17 20:50:40 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "ARCScon",
      "screen_name" : "ARCScon",
      "protected" : false,
      "id_str" : "1529905135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000692010967\/06b022449e1a9e1081eaaa1ad8226c5c_normal.png",
      "id" : 1529905135,
      "verified" : false
    }
  },
  "id" : 644614576466710528,
  "created_at" : "2015-09-17 20:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644582932699578368",
  "geo" : { },
  "id_str" : "644585864060882945",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy i\u2019ll try! :D",
  "id" : 644585864060882945,
  "in_reply_to_status_id" : 644582932699578368,
  "created_at" : "2015-09-17 18:57:00 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644580741578403841",
  "geo" : { },
  "id_str" : "644585782271983616",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 yes\uD83D\uDC49\uD83C\uDF69\uD83D\uDC48",
  "id" : 644585782271983616,
  "in_reply_to_status_id" : 644580741578403841,
  "created_at" : "2015-09-17 18:56:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644578437676572673",
  "geo" : { },
  "id_str" : "644579960951341056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 und hei\u00DFt die Kombi aus Panzer &amp; Stream-Seb eigentlich Panzertape-Seb? :D",
  "id" : 644579960951341056,
  "in_reply_to_status_id" : 644578437676572673,
  "created_at" : "2015-09-17 18:33:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 24, 31 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644578437676572673",
  "geo" : { },
  "id_str" : "644579766922838016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot siehe dem Stream-@Seb666 seinen Tweet ;)",
  "id" : 644579766922838016,
  "in_reply_to_status_id" : 644578437676572673,
  "created_at" : "2015-09-17 18:32:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644579479545880576",
  "text" : "\u00ABIt\u2019s still the disease we treat, not a collection of genes.\u00BB #GET2015",
  "id" : 644579479545880576,
  "created_at" : "2015-09-17 18:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644579161827344385",
  "text" : "RT @bella_velo: 'Scarcity in the digital commons is artificially created - by us - the digital commons in its nature is infinitely abundant\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Stacey",
        "screen_name" : "pgstacey",
        "indices" : [ 125, 134 ],
        "id_str" : "48018738",
        "id" : 48018738
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644579101781561344",
    "text" : "'Scarcity in the digital commons is artificially created - by us - the digital commons in its nature is infinitely abundant' @pgstacey",
    "id" : 644579101781561344,
    "created_at" : "2015-09-17 18:30:08 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 644579161827344385,
  "created_at" : "2015-09-17 18:30:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644577760703344640",
  "geo" : { },
  "id_str" : "644578594983931904",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 \uD83C\uDF46\uD83C\uDF46 for the \uD83C\uDF69 goddess!",
  "id" : 644578594983931904,
  "in_reply_to_status_id" : 644577760703344640,
  "created_at" : "2015-09-17 18:28:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644578123468685312",
  "geo" : { },
  "id_str" : "644578280486621184",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 danke!",
  "id" : 644578280486621184,
  "in_reply_to_status_id" : 644578123468685312,
  "created_at" : "2015-09-17 18:26:52 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644577972461150208",
  "geo" : { },
  "id_str" : "644578245535494144",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das w\u00E4re lieb \uD83D\uDC93",
  "id" : 644578245535494144,
  "in_reply_to_status_id" : 644577972461150208,
  "created_at" : "2015-09-17 18:26:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644577718445678592",
  "geo" : { },
  "id_str" : "644577845835137024",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot danke, gibt es da einen Plan zur Familienzusammenf\u00FChrung oder muss ich einfach nen neuen besorgen?",
  "id" : 644577845835137024,
  "in_reply_to_status_id" : 644577718445678592,
  "created_at" : "2015-09-17 18:25:08 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644577156450910208",
  "geo" : { },
  "id_str" : "644577388450480128",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 macht ihr wieder \uD83C\uDF4C\uD83C\uDF3D\uD83C\uDF46-Vergleich?",
  "id" : 644577388450480128,
  "in_reply_to_status_id" : 644577156450910208,
  "created_at" : "2015-09-17 18:23:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644575336504688645",
  "geo" : { },
  "id_str" : "644575782766026752",
  "in_reply_to_user_id" : 14286491,
  "text" : "Maybe it\u2019s just me, but that feels like an either or thing. Can\u2019t have your genomic privacy cake and eat the medical relevance too. #GET2015",
  "id" : 644575782766026752,
  "in_reply_to_status_id" : 644575336504688645,
  "created_at" : "2015-09-17 18:16:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644575336504688645",
  "text" : "People arguing at same time that genomics is a) not privacy issue because non-deterministic b) useful because of medical relevance. #GET2015",
  "id" : 644575336504688645,
  "created_at" : "2015-09-17 18:15:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644573147098955776",
  "text" : "Comment from the audience: sharing is not a personal decision, it gives away details of relatives. #GET2015",
  "id" : 644573147098955776,
  "created_at" : "2015-09-17 18:06:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644572638468276225",
  "text" : "Members of the audience so far: all sharing genetic data for altruistic reasons, not for immediate personal gain. #GET2015",
  "id" : 644572638468276225,
  "created_at" : "2015-09-17 18:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 68, 75 ],
      "id_str" : "15921173",
      "id" : 15921173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644572378144616449",
  "text" : "\u00ABSharing is not a duty, but it\u2019s a gift and a personal decision.\u00BB \u2014 @edyson #GET2015",
  "id" : 644572378144616449,
  "created_at" : "2015-09-17 18:03:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644571445700489216",
  "text" : "On Austria\u2019s attitude to GMO: \u00ABIn supermarkets you will see the stickers \u2018free of genes\u2019 which of course doesn\u2019t mean what it says\u00BB #GET2015",
  "id" : 644571445700489216,
  "created_at" : "2015-09-17 17:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644568948265099265",
  "text" : "\u00ABIs it okay to change populations?\u00BB I feel this is the straw man always put up. No one opposes all changes in allele frequencies #GET2015",
  "id" : 644568948265099265,
  "created_at" : "2015-09-17 17:49:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644567151660154880",
  "geo" : { },
  "id_str" : "644567474869018624",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk yes. :)",
  "id" : 644567474869018624,
  "in_reply_to_status_id" : 644567151660154880,
  "created_at" : "2015-09-17 17:43:56 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644566436057378816",
  "text" : "GC on sharing: NIST + FDA are using PGP data for \u2018genome in a bottle\u2019 #GET2015",
  "id" : 644566436057378816,
  "created_at" : "2015-09-17 17:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644566040098246656",
  "text" : "The most common disease is death I guess. #GET2015",
  "id" : 644566040098246656,
  "created_at" : "2015-09-17 17:38:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644564509521244160",
  "text" : "George Church: Europe loves (certain) GMO: the ones creating pharmaceuticals, eg Insulin. #GET2015",
  "id" : 644564509521244160,
  "created_at" : "2015-09-17 17:32:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 9, 20 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "george church",
      "screen_name" : "geochurch",
      "indices" : [ 21, 31 ],
      "id_str" : "137836269",
      "id" : 137836269
    }, {
      "name" : "PersonalGenomes.org",
      "screen_name" : "PGorg",
      "indices" : [ 32, 38 ],
      "id_str" : "48160604",
      "id" : 48160604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644561881282277376",
  "geo" : { },
  "id_str" : "644563618516836352",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @BPrainsack @geochurch @PGorg check #GET2015. There\u2019s at least one \u2018official\u2019 tweet. :)",
  "id" : 644563618516836352,
  "in_reply_to_status_id" : 644561881282277376,
  "created_at" : "2015-09-17 17:28:36 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644559709865943040",
  "text" : "GenomAustria rightfully showing off, being 1st of its kind on the European continent (\u2018and certainly in German speaking countries\u2019) #GET2015",
  "id" : 644559709865943040,
  "created_at" : "2015-09-17 17:13:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/B9uHcy1ETe",
      "expanded_url" : "https:\/\/instagram.com\/p\/7vUgrlBwkJ\/",
      "display_url" : "instagram.com\/p\/7vUgrlBwkJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20872, 16.37739 ]
  },
  "id_str" : "644557127948877824",
  "text" : "Vienna's showing off: Yet another lecture hall that makes me wanna leave Frankfurt. @ Austrian\u2026 https:\/\/t.co\/B9uHcy1ETe",
  "id" : 644557127948877824,
  "created_at" : "2015-09-17 17:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644536340718219265",
  "text" : "\u00ABFor whom would you like to do PR once your studies are finished?\u00BB \u2014 \u00ABNot for the evil ones!\u00BB my host has it all planned out.",
  "id" : 644536340718219265,
  "created_at" : "2015-09-17 15:40:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 3, 16 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 118, 134 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644520781251260417",
  "text" : "RT @emckiernan13: \"Publishing open access, doing open source and facilitating open data can mean a huge career boost\" @gedankenstuecke http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 100, 116 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0Q967Z3PDb",
        "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
        "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644520521485299713",
    "text" : "\"Publishing open access, doing open source and facilitating open data can mean a huge career boost\" @gedankenstuecke https:\/\/t.co\/0Q967Z3PDb",
    "id" : 644520521485299713,
    "created_at" : "2015-09-17 14:37:21 +0000",
    "user" : {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "protected" : false,
      "id_str" : "404442001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696004367640449024\/9-eZl3Dr_normal.jpg",
      "id" : 404442001,
      "verified" : false
    }
  },
  "id" : 644520781251260417,
  "created_at" : "2015-09-17 14:38:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icg10",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644511814261342208",
  "text" : "Flights FRA \u2708\uFE0F HKG \u2708\uFE0F FRA for ICG-10 #icg10 \u2714\uFE0E",
  "id" : 644511814261342208,
  "created_at" : "2015-09-17 14:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644494350655856640",
  "geo" : { },
  "id_str" : "644494461788160000",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot just tell me where I have to sign with my XXX.",
  "id" : 644494461788160000,
  "in_reply_to_status_id" : 644494350655856640,
  "created_at" : "2015-09-17 12:53:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644493200397324289",
  "geo" : { },
  "id_str" : "644494249615036417",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot see, call it engineering and it will work?",
  "id" : 644494249615036417,
  "in_reply_to_status_id" : 644493200397324289,
  "created_at" : "2015-09-17 12:52:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644492751573229568",
  "geo" : { },
  "id_str" : "644492946495143936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I can write an invoice for wood-based data science? :3",
  "id" : 644492946495143936,
  "in_reply_to_status_id" : 644492751573229568,
  "created_at" : "2015-09-17 12:47:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644489036904689664",
  "geo" : { },
  "id_str" : "644491418136903680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot can we be reimbursed for the time spent building stuff? :3",
  "id" : 644491418136903680,
  "in_reply_to_status_id" : 644489036904689664,
  "created_at" : "2015-09-17 12:41:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644470259479613440",
  "text" : "32\u00B0C. okay.jpg \u2600\uFE0F",
  "id" : 644470259479613440,
  "created_at" : "2015-09-17 11:17:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/80qtQ6VlRV",
      "expanded_url" : "https:\/\/instagram.com\/p\/7ulmHrBwkY\/",
      "display_url" : "instagram.com\/p\/7ulmHrBwkY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "644453960208773120",
  "text" : "waiting in line https:\/\/t.co\/80qtQ6VlRV",
  "id" : 644453960208773120,
  "created_at" : "2015-09-17 10:12:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04485205261133, 8.563911715501533 ]
  },
  "id_str" : "644447352074465280",
  "text" : "Looks like I will be speaking at #GET2015 after all. \uD83D\uDE31",
  "id" : 644447352074465280,
  "created_at" : "2015-09-17 09:46:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644444333257715712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04495127918645, 8.563018675564857 ]
  },
  "id_str" : "644445170897944576",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor \uD83D\uDE02",
  "id" : 644445170897944576,
  "in_reply_to_status_id" : 644444333257715712,
  "created_at" : "2015-09-17 09:37:56 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/b8H2SuL6pS",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/644427668985880576",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "644442091507068928",
  "geo" : { },
  "id_str" : "644442509305860096",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor https:\/\/t.co\/b8H2SuL6pS :)",
  "id" : 644442509305860096,
  "in_reply_to_status_id" : 644442091507068928,
  "created_at" : "2015-09-17 09:27:22 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GET Conference",
      "screen_name" : "attendGET",
      "indices" : [ 37, 47 ],
      "id_str" : "3349342414",
      "id" : 3349342414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644438364322725888",
  "text" : "Now: LH 1238 FRA \u2708\uFE0F VIE for #GET2015\/@attendGET.",
  "id" : 644438364322725888,
  "created_at" : "2015-09-17 09:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644433641800663040",
  "text" : "Inner-European travel feels like being back to: better bring your passport\u2026",
  "id" : 644433641800663040,
  "created_at" : "2015-09-17 08:52:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Raford",
      "screen_name" : "nraford",
      "indices" : [ 0, 8 ],
      "id_str" : "89227119",
      "id" : 89227119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644410837600370689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06911242881448, 8.629611175354771 ]
  },
  "id_str" : "644427668985880576",
  "in_reply_to_user_id" : 89227119,
  "text" : "@nraford yeah, also: things you can buy cheaply are better to forget.",
  "id" : 644427668985880576,
  "in_reply_to_status_id" : 644410837600370689,
  "created_at" : "2015-09-17 08:28:23 +0000",
  "in_reply_to_screen_name" : "nraford",
  "in_reply_to_user_id_str" : "89227119",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644420606121897984",
  "text" : "Today: How Maker2 nearly made me miss my flight.",
  "id" : 644420606121897984,
  "created_at" : "2015-09-17 08:00:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644410447723134976",
  "text" : "Nearly forgetting toothpaste but having already packed 3 different chargers.",
  "id" : 644410447723134976,
  "created_at" : "2015-09-17 07:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GonzoHacker",
      "screen_name" : "GonzoHacker",
      "indices" : [ 3, 15 ],
      "id_str" : "773009000",
      "id" : 773009000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644155694741110784",
  "text" : "RT @GonzoHacker: If clocks are illegal then only criminals will be on time",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644147612526841856",
    "text" : "If clocks are illegal then only criminals will be on time",
    "id" : 644147612526841856,
    "created_at" : "2015-09-16 13:55:33 +0000",
    "user" : {
      "name" : "GonzoHacker",
      "screen_name" : "GonzoHacker",
      "protected" : false,
      "id_str" : "773009000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920078035533090816\/qM6ROxQX_normal.jpg",
      "id" : 773009000,
      "verified" : false
    }
  },
  "id" : 644155694741110784,
  "created_at" : "2015-09-16 14:27:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/MbUiTDFlvU",
      "expanded_url" : "https:\/\/medium.com\/@tpoi\/do-the-rest-of-the-fucking-analysis-8fcef22fd991",
      "display_url" : "medium.com\/@tpoi\/do-the-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644150407703470080",
  "text" : "Step 2\u200A\u2014\u200Ado the rest of the fucking analysis https:\/\/t.co\/MbUiTDFlvU",
  "id" : 644150407703470080,
  "created_at" : "2015-09-16 14:06:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644130120878395392",
  "geo" : { },
  "id_str" : "644130340152430592",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj cryptornography?",
  "id" : 644130340152430592,
  "in_reply_to_status_id" : 644130120878395392,
  "created_at" : "2015-09-16 12:46:55 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Thomas Stadler",
      "screen_name" : "RAStadler",
      "indices" : [ 10, 20 ],
      "id_str" : "17782233",
      "id" : 17782233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644126317433200641",
  "geo" : { },
  "id_str" : "644126480952348672",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @RAStadler Kafka hat angerufen und m\u00F6chte seine Buch-Idee zur\u00FCck.",
  "id" : 644126480952348672,
  "in_reply_to_status_id" : 644126317433200641,
  "created_at" : "2015-09-16 12:31:35 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift Conference",
      "screen_name" : "LIFTconference",
      "indices" : [ 3, 18 ],
      "id_str" : "12881092",
      "id" : 12881092
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 86, 102 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liftbasel",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644111170874556416",
  "text" : "RT @LIFTconference: Opening up a million genomes (for starters: meet Bastian Greshake @gedankenstuecke at #liftbasel on Oct 29-30 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 66, 82 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "liftbasel",
        "indices" : [ 86, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/0tluij1FQs",
        "expanded_url" : "http:\/\/liftconference.com\/lift-basel-15\/speakers\/4428",
        "display_url" : "liftconference.com\/lift-basel-15\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644111043673767937",
    "text" : "Opening up a million genomes (for starters: meet Bastian Greshake @gedankenstuecke at #liftbasel on Oct 29-30 http:\/\/t.co\/0tluij1FQs",
    "id" : 644111043673767937,
    "created_at" : "2015-09-16 11:30:14 +0000",
    "user" : {
      "name" : "Lift Conference",
      "screen_name" : "LIFTconference",
      "protected" : false,
      "id_str" : "12881092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829680221787930624\/8PbZy-uQ_normal.jpg",
      "id" : 12881092,
      "verified" : false
    }
  },
  "id" : 644111170874556416,
  "created_at" : "2015-09-16 11:30:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644075124304429056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234348594895, 8.627518567539624 ]
  },
  "id_str" : "644075302503731200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay!",
  "id" : 644075302503731200,
  "in_reply_to_status_id" : 644075124304429056,
  "created_at" : "2015-09-16 09:08:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644051639540674561",
  "geo" : { },
  "id_str" : "644069914769260544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let\u2019s see. Just 1\/2 a day later it looks like I\u2019ve installed just enough packages to get maker up &amp; running according to docs\u2026",
  "id" : 644069914769260544,
  "in_reply_to_status_id" : 644051639540674561,
  "created_at" : "2015-09-16 08:46:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/QXKg2RMQAo",
      "expanded_url" : "https:\/\/media1.giphy.com\/media\/XAiT1V4jEc7vy\/200.gif",
      "display_url" : "media1.giphy.com\/media\/XAiT1V4j\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "644050809278361600",
  "geo" : { },
  "id_str" : "644067146419564544",
  "in_reply_to_user_id" : 14286491,
  "text" : "Software that tries to redefine \u2018getline\u2019\u2026 https:\/\/t.co\/QXKg2RMQAo",
  "id" : 644067146419564544,
  "in_reply_to_status_id" : 644050809278361600,
  "created_at" : "2015-09-16 08:35:48 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644051992126484480",
  "geo" : { },
  "id_str" : "644052497754161152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer let\u2019s see. Getting ready for maker iteration 1. :)",
  "id" : 644052497754161152,
  "in_reply_to_status_id" : 644051992126484480,
  "created_at" : "2015-09-16 07:37:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644051639540674561",
  "geo" : { },
  "id_str" : "644051783267041280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ES, for the workflow\/pipeline you tweeted a while back. Merging with maker.",
  "id" : 644051783267041280,
  "in_reply_to_status_id" : 644051639540674561,
  "created_at" : "2015-09-16 07:34:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644050984377802752",
  "geo" : { },
  "id_str" : "644051202334949376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer spot on, that\u2019s exactly what I was just installing.",
  "id" : 644051202334949376,
  "in_reply_to_status_id" : 644050984377802752,
  "created_at" : "2015-09-16 07:32:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/5ebaJ559XN",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/Vp9rYcsH1cIVO\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Vp9rYcsH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644050809278361600",
  "text" : "Academic software with weird licenses that requires you to \u2018apply\u2019 to get a license key\u2026 http:\/\/t.co\/5ebaJ559XN",
  "id" : 644050809278361600,
  "created_at" : "2015-09-16 07:30:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644044092519923712",
  "text" : "@malech yet another career that finished before it really started.",
  "id" : 644044092519923712,
  "created_at" : "2015-09-16 07:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644041388653473792",
  "geo" : { },
  "id_str" : "644041794028761089",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \uD83D\uDC49\uD83C\uDF69\uD83D\uDC48",
  "id" : 644041794028761089,
  "in_reply_to_status_id" : 644041388653473792,
  "created_at" : "2015-09-16 06:55:04 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644040980858044416",
  "text" : "Kinky sexting only using cute emoji totally is a skill that\u2019s marketable on your CV, right?",
  "id" : 644040980858044416,
  "created_at" : "2015-09-16 06:51:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annalisa Merelli",
      "screen_name" : "missanabeem",
      "indices" : [ 3, 15 ],
      "id_str" : "15099007",
      "id" : 15099007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644020846068125696",
  "text" : "RT @missanabeem: Kid builds a clock, because he is really smart. His teachers think it's a bomb, because he is Muslim. Heartbreaking: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tD0NpQDocQ",
        "expanded_url" : "http:\/\/www.dallasnews.com\/news\/community-news\/northwest-dallas-county\/headlines\/20150915-irving-ninth-grader-arrested-after-taking-homemade-clock-to-school.ece",
        "display_url" : "dallasnews.com\/news\/community\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643970678773940224",
    "text" : "Kid builds a clock, because he is really smart. His teachers think it's a bomb, because he is Muslim. Heartbreaking: http:\/\/t.co\/tD0NpQDocQ",
    "id" : 643970678773940224,
    "created_at" : "2015-09-16 02:12:28 +0000",
    "user" : {
      "name" : "Annalisa Merelli",
      "screen_name" : "missanabeem",
      "protected" : false,
      "id_str" : "15099007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655106727633784832\/mj_Ebfpx_normal.jpg",
      "id" : 15099007,
      "verified" : true
    }
  },
  "id" : 644020846068125696,
  "created_at" : "2015-09-16 05:31:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 7, 18 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Lucie \uD83C\uDF42",
      "screen_name" : "Autofocus",
      "indices" : [ 19, 29 ],
      "id_str" : "18939309",
      "id" : 18939309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qoDwlzPQZN",
      "expanded_url" : "https:\/\/de.wikipedia.org\/wiki\/Anstoss",
      "display_url" : "de.wikipedia.org\/wiki\/Anstoss"
    } ]
  },
  "in_reply_to_status_id_str" : "643805837778132992",
  "geo" : { },
  "id_str" : "643806448871428096",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @herrurbach @Autofocus yeah, a totally weird and foreign culture. https:\/\/t.co\/qoDwlzPQZN ;)",
  "id" : 643806448871428096,
  "in_reply_to_status_id" : 643805837778132992,
  "created_at" : "2015-09-15 15:19:53 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zA5MYZ09kh",
      "expanded_url" : "http:\/\/alexjs.com\/",
      "display_url" : "alexjs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "643801872881553409",
  "text" : "RT @kaythaney: Ooo, alexjs - a way to catch language that\u2019s insensitive w.r.t gender, race, religion, unequal. http:\/\/t.co\/zA5MYZ09kh (HT @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Riordan\uD83D\uDD96",
        "screen_name" : "riordan",
        "indices" : [ 123, 131 ],
        "id_str" : "1281581",
        "id" : 1281581
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/zA5MYZ09kh",
        "expanded_url" : "http:\/\/alexjs.com\/",
        "display_url" : "alexjs.com"
      } ]
    },
    "geo" : { },
    "id_str" : "643798507745316864",
    "text" : "Ooo, alexjs - a way to catch language that\u2019s insensitive w.r.t gender, race, religion, unequal. http:\/\/t.co\/zA5MYZ09kh (HT @riordan)",
    "id" : 643798507745316864,
    "created_at" : "2015-09-15 14:48:20 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 643801872881553409,
  "created_at" : "2015-09-15 15:01:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643773797464674309",
  "geo" : { },
  "id_str" : "643774763001843712",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce nope, University of Frankfurt.",
  "id" : 643774763001843712,
  "in_reply_to_status_id" : 643773797464674309,
  "created_at" : "2015-09-15 13:13:58 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/XpDOmpmpMB",
      "expanded_url" : "https:\/\/instagram.com\/p\/7paQbTBwvW\/",
      "display_url" : "instagram.com\/p\/7paQbTBwvW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "643725339194208256",
  "text" : "\u2614\uFE0F\u26A1\uFE0F\uD83D\uDD25\uD83D\uDEBF\uD83D\uDE92\uD83D\uDEA8\uD83D\uDE92\uD83D\uDE92\uD83D\uDE91\uD83D\uDE92\uD83D\uDEA8 https:\/\/t.co\/XpDOmpmpMB",
  "id" : 643725339194208256,
  "created_at" : "2015-09-15 09:57:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643723099016425476",
  "geo" : { },
  "id_str" : "643724027329167360",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot don\u2019t act all surprised :p",
  "id" : 643724027329167360,
  "in_reply_to_status_id" : 643723099016425476,
  "created_at" : "2015-09-15 09:52:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/4laMfIhcSp",
      "expanded_url" : "https:\/\/instagram.com\/p\/7pRMuZzFUW\/",
      "display_url" : "instagram.com\/p\/7pRMuZzFUW\/"
    } ]
  },
  "in_reply_to_status_id_str" : "643720885237587968",
  "geo" : { },
  "id_str" : "643721640505942016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot from my actual recommendations: https:\/\/t.co\/4laMfIhcSp",
  "id" : 643721640505942016,
  "in_reply_to_status_id" : 643720885237587968,
  "created_at" : "2015-09-15 09:42:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643719893007900672",
  "geo" : { },
  "id_str" : "643720155973992448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot are you stalking my Instagram recommendations? :3",
  "id" : 643720155973992448,
  "in_reply_to_status_id" : 643719893007900672,
  "created_at" : "2015-09-15 09:36:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/8Boo7ojUDp",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/tBPLFrohARGi4",
      "display_url" : "giphy.com\/gifs\/tBPLFrohA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "643718537538895872",
  "geo" : { },
  "id_str" : "643719091119910912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this seems to be a theme: https:\/\/t.co\/8Boo7ojUDp",
  "id" : 643719091119910912,
  "in_reply_to_status_id" : 643718537538895872,
  "created_at" : "2015-09-15 09:32:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/atJ2Rp7xpH",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/UOu29KX19K6ha\/200.gif",
      "display_url" : "media4.giphy.com\/media\/UOu29KX1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "643717129582309376",
  "geo" : { },
  "id_str" : "643717933244526592",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot no worries! https:\/\/t.co\/atJ2Rp7xpH",
  "id" : 643717933244526592,
  "in_reply_to_status_id" : 643717129582309376,
  "created_at" : "2015-09-15 09:28:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Nivatius)))",
      "screen_name" : "Nivatius",
      "indices" : [ 0, 9 ],
      "id_str" : "18052595",
      "id" : 18052595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643714512714092544",
  "geo" : { },
  "id_str" : "643714695162122244",
  "in_reply_to_user_id" : 18052595,
  "text" : "@Nivatius danke \uD83D\uDC34",
  "id" : 643714695162122244,
  "in_reply_to_status_id" : 643714512714092544,
  "created_at" : "2015-09-15 09:15:17 +0000",
  "in_reply_to_screen_name" : "Nivatius",
  "in_reply_to_user_id_str" : "18052595",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/wyzdsGKjVa",
      "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v33\/n9\/full\/nbt.3340.html",
      "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643713959527383040",
  "text" : "TIL: ownership of medical data in the US is even worse than I thought. http:\/\/t.co\/wyzdsGKjVa",
  "id" : 643713959527383040,
  "created_at" : "2015-09-15 09:12:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643713086663335936",
  "text" : "RT @kbradnam: I'm seeking a position relating to science communication\/outreach\/training in London (or surrounding area). My CV: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/65MuX27kOB",
        "expanded_url" : "http:\/\/www.keithbradnam.com\/curriculum-vitae",
        "display_url" : "keithbradnam.com\/curriculum-vit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643109394163482624",
    "text" : "I'm seeking a position relating to science communication\/outreach\/training in London (or surrounding area). My CV: http:\/\/t.co\/65MuX27kOB",
    "id" : 643109394163482624,
    "created_at" : "2015-09-13 17:10:02 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 643713086663335936,
  "created_at" : "2015-09-15 09:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Nivatius)))",
      "screen_name" : "Nivatius",
      "indices" : [ 0, 9 ],
      "id_str" : "18052595",
      "id" : 18052595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634021592905981952",
  "geo" : { },
  "id_str" : "643712471501533184",
  "in_reply_to_user_id" : 18052595,
  "text" : "@Nivatius da f\u00E4llt mir ein: Du hast mir ein Einhorn versprochen :D",
  "id" : 643712471501533184,
  "in_reply_to_status_id" : 634021592905981952,
  "created_at" : "2015-09-15 09:06:27 +0000",
  "in_reply_to_screen_name" : "Nivatius",
  "in_reply_to_user_id_str" : "18052595",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Murphy",
      "screen_name" : "timothypmurphy",
      "indices" : [ 3, 18 ],
      "id_str" : "17291452",
      "id" : 17291452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/pIV0UKfIi7",
      "expanded_url" : "http:\/\/www.motherjones.com\/mojo\/2015\/09\/does-donald-trump-send-his-own-tweets",
      "display_url" : "motherjones.com\/mojo\/2015\/09\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643555230777536512",
  "text" : "RT @timothypmurphy: This is like finding out that Horse eBooks was sentient http:\/\/t.co\/pIV0UKfIi7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/pIV0UKfIi7",
        "expanded_url" : "http:\/\/www.motherjones.com\/mojo\/2015\/09\/does-donald-trump-send-his-own-tweets",
        "display_url" : "motherjones.com\/mojo\/2015\/09\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643503156438110208",
    "text" : "This is like finding out that Horse eBooks was sentient http:\/\/t.co\/pIV0UKfIi7",
    "id" : 643503156438110208,
    "created_at" : "2015-09-14 19:14:42 +0000",
    "user" : {
      "name" : "Tim Murphy",
      "screen_name" : "timothypmurphy",
      "protected" : false,
      "id_str" : "17291452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413077614224359424\/9n8fncT5_normal.jpeg",
      "id" : 17291452,
      "verified" : true
    }
  },
  "id" : 643555230777536512,
  "created_at" : "2015-09-14 22:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 3, 19 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/w12Gfboh88",
      "expanded_url" : "http:\/\/www.sbs.com.au\/comedy\/article\/2015\/02\/04\/julia-gillard-rushed-hospital-after-overdosing-schadenfreude",
      "display_url" : "sbs.com.au\/comedy\/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643456250219495425",
  "text" : "RT @kevinschawinski: ICYMI: Julia Gillard Rushed To Hospital After Overdosing On Schadenfreude. http:\/\/t.co\/w12Gfboh88",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/w12Gfboh88",
        "expanded_url" : "http:\/\/www.sbs.com.au\/comedy\/article\/2015\/02\/04\/julia-gillard-rushed-hospital-after-overdosing-schadenfreude",
        "display_url" : "sbs.com.au\/comedy\/article\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643455446888652800",
    "text" : "ICYMI: Julia Gillard Rushed To Hospital After Overdosing On Schadenfreude. http:\/\/t.co\/w12Gfboh88",
    "id" : 643455446888652800,
    "created_at" : "2015-09-14 16:05:08 +0000",
    "user" : {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "protected" : false,
      "id_str" : "242844365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765909514549886976\/CSbHdSCr_normal.jpg",
      "id" : 242844365,
      "verified" : true
    }
  },
  "id" : 643456250219495425,
  "created_at" : "2015-09-14 16:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yocDyBRtBz",
      "expanded_url" : "https:\/\/goo.gl\/PY5OeK",
      "display_url" : "goo.gl\/PY5OeK"
    } ]
  },
  "geo" : { },
  "id_str" : "643402703675240449",
  "text" : "RT @PhdGeek: Registration for the #LGBTSTEMinar is now live. To be held on 15th January, University of Sheffield. https:\/\/t.co\/yocDyBRtBz #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar",
        "indices" : [ 21, 34 ]
      }, {
        "text" : "LGBTSTEM",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/yocDyBRtBz",
        "expanded_url" : "https:\/\/goo.gl\/PY5OeK",
        "display_url" : "goo.gl\/PY5OeK"
      } ]
    },
    "geo" : { },
    "id_str" : "643402071337775104",
    "text" : "Registration for the #LGBTSTEMinar is now live. To be held on 15th January, University of Sheffield. https:\/\/t.co\/yocDyBRtBz #LGBTSTEM",
    "id" : 643402071337775104,
    "created_at" : "2015-09-14 12:33:02 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 643402703675240449,
  "created_at" : "2015-09-14 12:35:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643348326524436480",
  "geo" : { },
  "id_str" : "643348438436982784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that\u2019s why I wonder whether going for a hybrid SSD\/HDD machine now would be worth it.",
  "id" : 643348438436982784,
  "in_reply_to_status_id" : 643348326524436480,
  "created_at" : "2015-09-14 08:59:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643346773134577664",
  "geo" : { },
  "id_str" : "643347101196394496",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch 10% did take ~1 week? You expect it to speed up that much?",
  "id" : 643347101196394496,
  "in_reply_to_status_id" : 643346773134577664,
  "created_at" : "2015-09-14 08:54:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643345618866298880",
  "geo" : { },
  "id_str" : "643346001382764544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch maybe we should go for a new machine now? :P",
  "id" : 643346001382764544,
  "in_reply_to_status_id" : 643345618866298880,
  "created_at" : "2015-09-14 08:50:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/V7i6mUfM6s",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view1\/2195085\/voodoo-priestess-o.gif",
      "display_url" : "stream1.gifsoup.com\/view1\/2195085\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643332943268737024",
  "text" : "submitting to the SRA http:\/\/t.co\/V7i6mUfM6s",
  "id" : 643332943268737024,
  "created_at" : "2015-09-14 07:58:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643332399082766336",
  "geo" : { },
  "id_str" : "643332920363642880",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski thanks!",
  "id" : 643332920363642880,
  "in_reply_to_status_id" : 643332399082766336,
  "created_at" : "2015-09-14 07:58:15 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 15, 26 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643324067987238912",
  "geo" : { },
  "id_str" : "643326127486967808",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HansZauner thanks :)",
  "id" : 643326127486967808,
  "in_reply_to_status_id" : 643324067987238912,
  "created_at" : "2015-09-14 07:31:15 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643324144268918784",
  "geo" : { },
  "id_str" : "643324379363954688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so it\u2019s praying the uni admin will work quickly? :D",
  "id" : 643324379363954688,
  "in_reply_to_status_id" : 643324144268918784,
  "created_at" : "2015-09-14 07:24:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643323762184601600",
  "geo" : { },
  "id_str" : "643323906720403456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, how is your thesis resubmission coming along?",
  "id" : 643323906720403456,
  "in_reply_to_status_id" : 643323762184601600,
  "created_at" : "2015-09-14 07:22:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/chSePrcRPl",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643323599479283714",
  "text" : "One publication closer to getting a PhD: Finally accepted by Molecular Ecology Resources! http:\/\/t.co\/chSePrcRPl",
  "id" : 643323599479283714,
  "created_at" : "2015-09-14 07:21:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643176423184842752",
  "geo" : { },
  "id_str" : "643177050614956032",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 F\u00FCr Spa\u00DF von Utah bis Sword!",
  "id" : 643177050614956032,
  "in_reply_to_status_id" : 643176423184842752,
  "created_at" : "2015-09-13 21:38:53 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643173661759901696",
  "geo" : { },
  "id_str" : "643175473028169728",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 das qualifiziert f\u00FCr ein T-Shirt und P\u00F6bel-Privilegien ;)",
  "id" : 643175473028169728,
  "in_reply_to_status_id" : 643173661759901696,
  "created_at" : "2015-09-13 21:32:37 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Price",
      "screen_name" : "mister_burns",
      "indices" : [ 0, 13 ],
      "id_str" : "54701196",
      "id" : 54701196
    }, {
      "name" : "rock'n'rollheit",
      "screen_name" : "rottensnowwhite",
      "indices" : [ 14, 30 ],
      "id_str" : "23417007",
      "id" : 23417007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643057186566967296",
  "geo" : { },
  "id_str" : "643162201235320833",
  "in_reply_to_user_id" : 54701196,
  "text" : "@mister_burns @rottensnowwhite remote viewers are decreasing as well. linear might be overly optimistic, maybe exp. decay is more appropr.",
  "id" : 643162201235320833,
  "in_reply_to_status_id" : 643057186566967296,
  "created_at" : "2015-09-13 20:39:52 +0000",
  "in_reply_to_screen_name" : "mister_burns",
  "in_reply_to_user_id_str" : "54701196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643090754882154496",
  "geo" : { },
  "id_str" : "643102205139156992",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 jetzt hier ;)",
  "id" : 643102205139156992,
  "in_reply_to_status_id" : 643090754882154496,
  "created_at" : "2015-09-13 16:41:28 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643071049136013312",
  "geo" : { },
  "id_str" : "643071903960301568",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ah, die Homogenit\u00E4t bei den oms meinte ich.",
  "id" : 643071903960301568,
  "in_reply_to_status_id" : 643071049136013312,
  "created_at" : "2015-09-13 14:41:04 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643059611793235972",
  "geo" : { },
  "id_str" : "643070227270471680",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye ist in den letzten Jahren mehr so geworden finde ich.",
  "id" : 643070227270471680,
  "in_reply_to_status_id" : 643059611793235972,
  "created_at" : "2015-09-13 14:34:24 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rock'n'rollheit",
      "screen_name" : "rottensnowwhite",
      "indices" : [ 0, 16 ],
      "id_str" : "23417007",
      "id" : 23417007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643052716021948416",
  "geo" : { },
  "id_str" : "643053826459758593",
  "in_reply_to_user_id" : 23417007,
  "text" : "@rottensnowwhite indeed.",
  "id" : 643053826459758593,
  "in_reply_to_status_id" : 643052716021948416,
  "created_at" : "2015-09-13 13:29:14 +0000",
  "in_reply_to_screen_name" : "rottensnowwhite",
  "in_reply_to_user_id_str" : "23417007",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643052585923051520",
  "text" : "Linear regression says: in 2016 the conference will be visited by 30 people, 100% of whom will be organizing the conference. #om15",
  "id" : 643052585923051520,
  "created_at" : "2015-09-13 13:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "-christian \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "stbc",
      "indices" : [ 19, 24 ],
      "id_str" : "16849921",
      "id" : 16849921
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 25, 37 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643051440005586944",
  "geo" : { },
  "id_str" : "643051653508263936",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze @Lobot @stbc @alibi_ranch aber ich will lieber die Katze sein :3",
  "id" : 643051653508263936,
  "in_reply_to_status_id" : 643051440005586944,
  "created_at" : "2015-09-13 13:20:36 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "-christian \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "stbc",
      "indices" : [ 7, 12 ],
      "id_str" : "16849921",
      "id" : 16849921
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 13, 25 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 26, 37 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643049267175755777",
  "geo" : { },
  "id_str" : "643049663520641024",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @stbc @alibi_ranch @kathakatze \u2018are you ok with pets sleeping in your bed?\u2019, required answer: yes!",
  "id" : 643049663520641024,
  "in_reply_to_status_id" : 643049267175755777,
  "created_at" : "2015-09-13 13:12:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "-christian \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "stbc",
      "indices" : [ 7, 12 ],
      "id_str" : "16849921",
      "id" : 16849921
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 13, 25 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 26, 37 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/bsE7BOFACi",
      "expanded_url" : "https:\/\/instagram.com\/p\/wixlsoBwkI\/",
      "display_url" : "instagram.com\/p\/wixlsoBwkI\/"
    } ]
  },
  "in_reply_to_status_id_str" : "643048241978851328",
  "geo" : { },
  "id_str" : "643048880368668672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @stbc @alibi_ranch @kathakatze bei OkC bis heute mein Avatar: https:\/\/t.co\/bsE7BOFACi \uD83D\uDC31",
  "id" : 643048880368668672,
  "in_reply_to_status_id" : 643048241978851328,
  "created_at" : "2015-09-13 13:09:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 22, 33 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/6GMcHh0kEQ",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/en\/e\/e9\/Gandalf600ppx.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/en\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "643020502139858945",
  "geo" : { },
  "id_str" : "643025275857600512",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot  dann bestehen @herrurbach und ich auf Wei\u00DFe-Eminenz-Shirts. https:\/\/t.co\/6GMcHh0kEQ",
  "id" : 643025275857600512,
  "in_reply_to_status_id" : 643020502139858945,
  "created_at" : "2015-09-13 11:35:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/643005890552012800\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/YY4XnI1Qwo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COxqc1nWcAA73DQ.jpg",
      "id_str" : "643005890468147200",
      "id" : 643005890468147200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COxqc1nWcAA73DQ.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 953
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 953
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 953
      } ],
      "display_url" : "pic.twitter.com\/YY4XnI1Qwo"
    } ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643005890552012800",
  "text" : "Eine Au\u00DFenstelle des Raum-Zeit-Labors! #om15 http:\/\/t.co\/YY4XnI1Qwo",
  "id" : 643005890552012800,
  "created_at" : "2015-09-13 10:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642997869826453504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31946497056703, 9.474899464637508 ]
  },
  "id_str" : "642998835195826177",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Mrozford &amp; Sons.",
  "id" : 642998835195826177,
  "in_reply_to_status_id" : 642997869826453504,
  "created_at" : "2015-09-13 09:50:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642995984432242688",
  "geo" : { },
  "id_str" : "642997474240630784",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das endet dann doch in \u2018Band ohne Namen\u2019, die j\u00FCngeren erinnern sich.",
  "id" : 642997474240630784,
  "in_reply_to_status_id" : 642995984432242688,
  "created_at" : "2015-09-13 09:45:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642996999474806785",
  "geo" : { },
  "id_str" : "642997298935517184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich aka Sex &amp; Candy?",
  "id" : 642997298935517184,
  "in_reply_to_status_id" : 642996999474806785,
  "created_at" : "2015-09-13 09:44:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/JYNBZ3hzV7",
      "expanded_url" : "https:\/\/instagram.com\/p\/7kNnK4Bwjz\/",
      "display_url" : "instagram.com\/p\/7kNnK4Bwjz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3194199, 9.4755201 ]
  },
  "id_str" : "642993846553571328",
  "text" : "\u00ABYet another plan b, in case academia doesn't work out: homeless rockstar.\u00BB #om15 @ Jugendherberge\u2026 https:\/\/t.co\/JYNBZ3hzV7",
  "id" : 642993846553571328,
  "created_at" : "2015-09-13 09:30:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/uZvrYVFh6s",
      "expanded_url" : "https:\/\/instagram.com\/p\/7kJAuUhwrr\/",
      "display_url" : "instagram.com\/p\/7kJAuUhwrr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3194199, 9.4755201 ]
  },
  "id_str" : "642983732039798784",
  "text" : "The Age of Wireless #om15 @ Jugendherberge Kassel https:\/\/t.co\/uZvrYVFh6s",
  "id" : 642983732039798784,
  "created_at" : "2015-09-13 08:50:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642979731416199168",
  "geo" : { },
  "id_str" : "642980035775832064",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 \uD83C\uDF4C\uD83C\uDF7C",
  "id" : 642980035775832064,
  "in_reply_to_status_id" : 642979731416199168,
  "created_at" : "2015-09-13 08:36:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642867433053663232",
  "geo" : { },
  "id_str" : "642955586531889152",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine #\uD83D\uDC26",
  "id" : 642955586531889152,
  "in_reply_to_status_id" : 642867433053663232,
  "created_at" : "2015-09-13 06:58:52 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642819060963651584",
  "geo" : { },
  "id_str" : "642824882112360449",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine @Lobot f\u00FCr so tolles Publikum gerne \uD83D\uDC96",
  "id" : 642824882112360449,
  "in_reply_to_status_id" : 642819060963651584,
  "created_at" : "2015-09-12 22:19:29 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642805763220590592",
  "geo" : { },
  "id_str" : "642814252324102146",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine @Lobot danke, damit versuche ich auch gerne noch ein 3. Mal vor Publikum zu spielen :3",
  "id" : 642814252324102146,
  "in_reply_to_status_id" : 642805763220590592,
  "created_at" : "2015-09-12 21:37:15 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642748495405936640",
  "text" : "RT @lpachter: Strikingly, researchers reject null model that students taking Stanford course don't learn anything (p = 3.5\u00D710^\u22126). http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fsLPiJq4Yq",
        "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0068853",
        "display_url" : "journals.plos.org\/plosone\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642745367373611009",
    "text" : "Strikingly, researchers reject null model that students taking Stanford course don't learn anything (p = 3.5\u00D710^\u22126). http:\/\/t.co\/fsLPiJq4Yq",
    "id" : 642745367373611009,
    "created_at" : "2015-09-12 17:03:31 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 642748495405936640,
  "created_at" : "2015-09-12 17:15:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642725948069167104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31953887118377, 9.470581236729846 ]
  },
  "id_str" : "642726540837584897",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @NazeefaFatima always happy to help with German etymology. :)",
  "id" : 642726540837584897,
  "in_reply_to_status_id" : 642725948069167104,
  "created_at" : "2015-09-12 15:48:43 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 9, 21 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 22, 28 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.32528867730498, 9.470580677254674 ]
  },
  "id_str" : "642724500967178240",
  "text" : "@levudev @alibi_ranch @Lobot nicht \u00FCberbacken, d\u00FCnsten!",
  "id" : 642724500967178240,
  "created_at" : "2015-09-12 15:40:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642722411310379008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.32358845671578, 9.475934466692273 ]
  },
  "id_str" : "642723463820640260",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @NazeefaFatima \u2018Fett\u2019 is used in the same ways as \u2018fat\u2019 in English.",
  "id" : 642723463820640260,
  "in_reply_to_status_id" : 642722411310379008,
  "created_at" : "2015-09-12 15:36:29 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642722411310379008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.32363055131702, 9.476031810276112 ]
  },
  "id_str" : "642723180054974464",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @NazeefaFatima German \u2018dick\u2019 is related to English \u2018thick\u2019, used for describing large diameter besides weight-shaming.",
  "id" : 642723180054974464,
  "in_reply_to_status_id" : 642722411310379008,
  "created_at" : "2015-09-12 15:35:22 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/642714295835488256\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/P0E9m0rsPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COthPp6WgAAq8BP.jpg",
      "id_str" : "642714293406957568",
      "id" : 642714293406957568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COthPp6WgAAq8BP.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/P0E9m0rsPB"
    } ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642714295835488256",
  "text" : "Wait, what?! #om15 http:\/\/t.co\/P0E9m0rsPB",
  "id" : 642714295835488256,
  "created_at" : "2015-09-12 15:00:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31405784493517, 9.480363637934149 ]
  },
  "id_str" : "642702096723247104",
  "text" : "inter-faith designer #om15",
  "id" : 642702096723247104,
  "created_at" : "2015-09-12 14:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 95, 102 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642697282920554496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31970060062717, 9.476587604740146 ]
  },
  "id_str" : "642698548765675520",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 F\u00FCr Raum2 sollte das gehen wenn es vom Steckplatz passt. ;) F\u00FCr Raum1 kann dir das der @Seb666 sagen. :)",
  "id" : 642698548765675520,
  "in_reply_to_status_id" : 642697282920554496,
  "created_at" : "2015-09-12 13:57:29 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/BIrhNk1Xoj",
      "expanded_url" : "https:\/\/twitter.com\/ShiriEisner\/status\/642670622632476674",
      "display_url" : "twitter.com\/ShiriEisner\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642692873763323904",
  "text" : "RT @vortacist: Yes. This. Maybe I should start wearing more togas? https:\/\/t.co\/BIrhNk1Xoj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/BIrhNk1Xoj",
        "expanded_url" : "https:\/\/twitter.com\/ShiriEisner\/status\/642670622632476674",
        "display_url" : "twitter.com\/ShiriEisner\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642675240728940544",
    "text" : "Yes. This. Maybe I should start wearing more togas? https:\/\/t.co\/BIrhNk1Xoj",
    "id" : 642675240728940544,
    "created_at" : "2015-09-12 12:24:52 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 642692873763323904,
  "created_at" : "2015-09-12 13:34:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/amjrbMF3cU",
      "expanded_url" : "https:\/\/instagram.com\/p\/7huEwVBwhN\/",
      "display_url" : "instagram.com\/p\/7huEwVBwhN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3194199, 9.4755201 ]
  },
  "id_str" : "642643019326484480",
  "text" : "Post-Stream-Installation #om15 @ Jugendherberge Kassel https:\/\/t.co\/amjrbMF3cU",
  "id" : 642643019326484480,
  "created_at" : "2015-09-12 10:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31443839591565, 9.47965962365714 ]
  },
  "id_str" : "642641221358387200",
  "text" : "Q&amp;A, aka thinly veiled 5-minute statements\u2026",
  "id" : 642641221358387200,
  "created_at" : "2015-09-12 10:09:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642638826192637952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31927664396476, 9.475689316177252 ]
  },
  "id_str" : "642639670376046592",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule \u2764\uFE0F firebugs",
  "id" : 642639670376046592,
  "in_reply_to_status_id" : 642638826192637952,
  "created_at" : "2015-09-12 10:03:31 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642638782760624128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31928728898178, 9.475270723932866 ]
  },
  "id_str" : "642639102458896384",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 i feel you, just doing regular flat sharing shows how that can fail :D",
  "id" : 642639102458896384,
  "in_reply_to_status_id" : 642638782760624128,
  "created_at" : "2015-09-12 10:01:16 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642637747770015744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31154705406269, 9.485012332715666 ]
  },
  "id_str" : "642638510386757632",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 what parts of your world?",
  "id" : 642638510386757632,
  "in_reply_to_status_id" : 642637747770015744,
  "created_at" : "2015-09-12 09:58:55 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 79, 88 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/XfCG1ABwCl",
      "expanded_url" : "http:\/\/www.theallusionist.org\/allusionist\/fix-ii",
      "display_url" : "theallusionist.org\/allusionist\/fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642638177711337472",
  "text" : "the europification of english: about the strange dialect of EU technocrats \/cc @Senficon  http:\/\/t.co\/XfCG1ABwCl",
  "id" : 642638177711337472,
  "created_at" : "2015-09-12 09:57:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31884959775685, 9.475645346664098 ]
  },
  "id_str" : "642635983058505728",
  "text" : "if everyone\u2019s responsible, no one is responsible. #om15",
  "id" : 642635983058505728,
  "created_at" : "2015-09-12 09:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/bBXQMVtApl",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/11\/coyotegolden-retriever-mix-do.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/09\/11\/coy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642620027280224256",
  "text" : "Coyote\/Golden Retriever mix dog adopts 10 baby chicks \uD83D\uDC36\u2764\uFE0F\uD83D\uDC23 http:\/\/t.co\/bBXQMVtApl",
  "id" : 642620027280224256,
  "created_at" : "2015-09-12 08:45:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/kEemd7IrkR",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/128875398990",
      "display_url" : "chapmangamo.tumblr.com\/post\/128875398\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642617913048997888",
  "text" : "how to splat http:\/\/t.co\/kEemd7IrkR",
  "id" : 642617913048997888,
  "created_at" : "2015-09-12 08:37:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 17, 22 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642603024431624193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31931698490047, 9.475281916416783 ]
  },
  "id_str" : "642608245568356352",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @NASA do want!",
  "id" : 642608245568356352,
  "in_reply_to_status_id" : 642603024431624193,
  "created_at" : "2015-09-12 07:58:39 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642603936399101952",
  "geo" : { },
  "id_str" : "642606255178055680",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor oh, dann alles Gute daf\u00FCr nat\u00FCrlich! :)",
  "id" : 642606255178055680,
  "in_reply_to_status_id" : 642603936399101952,
  "created_at" : "2015-09-12 07:50:44 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642601905416466432",
  "geo" : { },
  "id_str" : "642602824661123072",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski thanks. Do you have stickers? :3",
  "id" : 642602824661123072,
  "in_reply_to_status_id" : 642601905416466432,
  "created_at" : "2015-09-12 07:37:07 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    }, {
      "name" : "Connichi",
      "screen_name" : "Connichi",
      "indices" : [ 42, 51 ],
      "id_str" : "29685056",
      "id" : 29685056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642601200647602176",
  "geo" : { },
  "id_str" : "642602670629392384",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor danke, euch dann auch zur @connichi :)",
  "id" : 642602670629392384,
  "in_reply_to_status_id" : 642601200647602176,
  "created_at" : "2015-09-12 07:36:30 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/KQLqEt26a3",
      "expanded_url" : "https:\/\/instagram.com\/p\/7hbVKZhwkr\/",
      "display_url" : "instagram.com\/p\/7hbVKZhwkr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "642601800743432192",
  "text" : "Setup presenter notebook \u2714\uFE0F #om15 https:\/\/t.co\/KQLqEt26a3",
  "id" : 642601800743432192,
  "created_at" : "2015-09-12 07:33:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "HP LatinoVoices",
      "screen_name" : "LatinoVoices",
      "indices" : [ 85, 98 ],
      "id_str" : "351065668",
      "id" : 351065668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/97oeKk53Ka",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/prisca-dorcas-mojica-rodriguez\/growing-up-as-a-brown-girl-aesthetics_b_8120358.html",
      "display_url" : "huffingtonpost.com\/prisca-dorcas-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642600769972273153",
  "text" : "RT @NazeefaFatima: Growing up as a Brown Girl: Aesthetics http:\/\/t.co\/97oeKk53Ka via @LatinoVoices",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HP LatinoVoices",
        "screen_name" : "LatinoVoices",
        "indices" : [ 66, 79 ],
        "id_str" : "351065668",
        "id" : 351065668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/97oeKk53Ka",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/prisca-dorcas-mojica-rodriguez\/growing-up-as-a-brown-girl-aesthetics_b_8120358.html",
        "display_url" : "huffingtonpost.com\/prisca-dorcas-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642597033132560384",
    "text" : "Growing up as a Brown Girl: Aesthetics http:\/\/t.co\/97oeKk53Ka via @LatinoVoices",
    "id" : 642597033132560384,
    "created_at" : "2015-09-12 07:14:06 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 642600769972273153,
  "created_at" : "2015-09-12 07:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642599678769516545",
  "geo" : { },
  "id_str" : "642600653852905472",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor nur bis Sonntag. N\u00E4chste Woche bin ich in Wien. :)",
  "id" : 642600653852905472,
  "in_reply_to_status_id" : 642599678769516545,
  "created_at" : "2015-09-12 07:28:29 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 23, 28 ]
    }, {
      "text" : "omnomnom15",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/SXAfcGbkwZ",
      "expanded_url" : "https:\/\/instagram.com\/p\/7hUsxBhwsf\/",
      "display_url" : "instagram.com\/p\/7hUsxBhwsf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3194199, 9.4755201 ]
  },
  "id_str" : "642587221669859329",
  "text" : "Youth Hostel Breakfast #om15 #omnomnom15 @ Jugendherberge Kassel https:\/\/t.co\/SXAfcGbkwZ",
  "id" : 642587221669859329,
  "created_at" : "2015-09-12 06:35:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/nC6EMjVgzp",
      "expanded_url" : "https:\/\/instagram.com\/p\/7gsJxJBwu3\/",
      "display_url" : "instagram.com\/p\/7gsJxJBwu3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "642498057418985473",
  "text" : "getting the video infrastructure up, like every year: just in time. #om15 https:\/\/t.co\/nC6EMjVgzp",
  "id" : 642498057418985473,
  "created_at" : "2015-09-12 00:40:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 15, 25 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642488197432389632",
  "geo" : { },
  "id_str" : "642492526331600896",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @eltonjohn you are both right. :)",
  "id" : 642492526331600896,
  "in_reply_to_status_id" : 642488197432389632,
  "created_at" : "2015-09-12 00:18:49 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 0, 7 ],
      "id_str" : "26962623",
      "id" : 26962623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642412757489426432",
  "geo" : { },
  "id_str" : "642433226791886848",
  "in_reply_to_user_id" : 26962623,
  "text" : "@der_ak der Witz ist: ich war bei 300+, dann ist die Platte abgeraucht und ich war zur\u00FCck bei 0. ;)",
  "id" : 642433226791886848,
  "in_reply_to_status_id" : 642412757489426432,
  "created_at" : "2015-09-11 20:23:11 +0000",
  "in_reply_to_screen_name" : "der_ak",
  "in_reply_to_user_id_str" : "26962623",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Bokor",
      "screen_name" : "d1etpunk",
      "indices" : [ 0, 9 ],
      "id_str" : "49618309",
      "id" : 49618309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642404740802940928",
  "geo" : { },
  "id_str" : "642407506954846208",
  "in_reply_to_user_id" : 49618309,
  "text" : "@d1etpunk Carlos Danger!",
  "id" : 642407506954846208,
  "in_reply_to_status_id" : 642404740802940928,
  "created_at" : "2015-09-11 18:40:59 +0000",
  "in_reply_to_screen_name" : "d1etpunk",
  "in_reply_to_user_id_str" : "49618309",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/642402431901528065\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/o6rkomzhjk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COpFm60WgAUCpBX.jpg",
      "id_str" : "642402431779897349",
      "id" : 642402431779897349,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COpFm60WgAUCpBX.jpg",
      "sizes" : [ {
        "h" : 748,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 997
      } ],
      "display_url" : "pic.twitter.com\/o6rkomzhjk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642402431901528065",
  "text" : "Be Safe http:\/\/t.co\/o6rkomzhjk",
  "id" : 642402431901528065,
  "created_at" : "2015-09-11 18:20:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 32, 45 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 46, 58 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642341724048748544",
  "geo" : { },
  "id_str" : "642342259934031872",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ thanks, we\u2019re on it. @PhilippBayer @helgerausch",
  "id" : 642342259934031872,
  "in_reply_to_status_id" : 642341724048748544,
  "created_at" : "2015-09-11 14:21:43 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642315859684380672",
  "text" : "Off to #om15, where this year\u2019s motto apparently should have been \u2018All Things Will Die\u2019.",
  "id" : 642315859684380672,
  "created_at" : "2015-09-11 12:36:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Banti, Khyberman",
      "screen_name" : "Khyberman",
      "indices" : [ 3, 13 ],
      "id_str" : "21514100",
      "id" : 21514100
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Khyberman\/status\/641684156808863744\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RBu4Vp7cJS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COe4VfoW8AECnh1.jpg",
      "id_str" : "641684151331123201",
      "id" : 641684151331123201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COe4VfoW8AECnh1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/RBu4Vp7cJS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642274555604639744",
  "text" : "RT @Khyberman: Bloody imiagrunts! Coming over here, stealing our dictionaries. http:\/\/t.co\/RBu4Vp7cJS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Khyberman\/status\/641684156808863744\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/RBu4Vp7cJS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COe4VfoW8AECnh1.jpg",
        "id_str" : "641684151331123201",
        "id" : 641684151331123201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COe4VfoW8AECnh1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/RBu4Vp7cJS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641684156808863744",
    "text" : "Bloody imiagrunts! Coming over here, stealing our dictionaries. http:\/\/t.co\/RBu4Vp7cJS",
    "id" : 641684156808863744,
    "created_at" : "2015-09-09 18:46:39 +0000",
    "user" : {
      "name" : "Banti, Khyberman",
      "screen_name" : "Khyberman",
      "protected" : false,
      "id_str" : "21514100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914783368331612160\/e6Oek8jZ_normal.jpg",
      "id" : 21514100,
      "verified" : false
    }
  },
  "id" : 642274555604639744,
  "created_at" : "2015-09-11 09:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642274497408696320",
  "text" : "RT @pathogenomenick: \"If the introducing panel is not an expert but saw an interesting talk in the domain a few weeks ago, you\u2019re saved.\" h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/w1DERmVZI7",
        "expanded_url" : "https:\/\/nlenov.wordpress.com\/2015\/09\/09\/selection-panels-follow-the-rule-of-thirds\/",
        "display_url" : "nlenov.wordpress.com\/2015\/09\/09\/sel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642263772799889408",
    "text" : "\"If the introducing panel is not an expert but saw an interesting talk in the domain a few weeks ago, you\u2019re saved.\" https:\/\/t.co\/w1DERmVZI7",
    "id" : 642263772799889408,
    "created_at" : "2015-09-11 09:09:50 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 642274497408696320,
  "created_at" : "2015-09-11 09:52:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642244143851421697",
  "geo" : { },
  "id_str" : "642245325739175936",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson I always wonder how large the overlap between those populations is.",
  "id" : 642245325739175936,
  "in_reply_to_status_id" : 642244143851421697,
  "created_at" : "2015-09-11 07:56:32 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Hemsoth",
      "screen_name" : "NicoleHemsoth",
      "indices" : [ 3, 17 ],
      "id_str" : "1176330954",
      "id" : 1176330954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fwvckat1OR",
      "expanded_url" : "https:\/\/www.expeditedssl.com\/aws-in-plain-english",
      "display_url" : "expeditedssl.com\/aws-in-plain-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642234820488249344",
  "text" : "RT @NicoleHemsoth: Brilliant. All AWS services named by what they probably should have been named in the first place https:\/\/t.co\/fwvckat1OR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/fwvckat1OR",
        "expanded_url" : "https:\/\/www.expeditedssl.com\/aws-in-plain-english",
        "display_url" : "expeditedssl.com\/aws-in-plain-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642170003811344384",
    "text" : "Brilliant. All AWS services named by what they probably should have been named in the first place https:\/\/t.co\/fwvckat1OR",
    "id" : 642170003811344384,
    "created_at" : "2015-09-11 02:57:14 +0000",
    "user" : {
      "name" : "Nicole Hemsoth",
      "screen_name" : "NicoleHemsoth",
      "protected" : false,
      "id_str" : "1176330954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852362607579234304\/aO7ikiii_normal.jpg",
      "id" : 1176330954,
      "verified" : false
    }
  },
  "id" : 642234820488249344,
  "created_at" : "2015-09-11 07:14:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/3D0jHs9aRZ",
      "expanded_url" : "https:\/\/instagram.com\/p\/7e0PfmBwsF\/",
      "display_url" : "instagram.com\/p\/7e0PfmBwsF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "642234368451330048",
  "text" : "doesn't feel that cold. https:\/\/t.co\/3D0jHs9aRZ",
  "id" : 642234368451330048,
  "created_at" : "2015-09-11 07:13:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/lSrhtlLKkZ",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3857",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642104446319771650",
  "text" : "any proper utilitarian system should favor deep-seated loathing of other people\u2019s tastes http:\/\/t.co\/lSrhtlLKkZ",
  "id" : 642104446319771650,
  "created_at" : "2015-09-10 22:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Press",
      "screen_name" : "AllenPress",
      "indices" : [ 3, 14 ],
      "id_str" : "29191374",
      "id" : 29191374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5gt9nKvCfH",
      "expanded_url" : "http:\/\/blog.alpsp.org\/2015\/09\/anurag-acharya-co-creator-of-google.html",
      "display_url" : "blog.alpsp.org\/2015\/09\/anurag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642099165066067968",
  "text" : "RT @AllenPress: Co-founder of Google Scholar discussed how research methods have evolved since content went online http:\/\/t.co\/5gt9nKvCfH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/5gt9nKvCfH",
        "expanded_url" : "http:\/\/blog.alpsp.org\/2015\/09\/anurag-acharya-co-creator-of-google.html",
        "display_url" : "blog.alpsp.org\/2015\/09\/anurag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642088099565056001",
    "text" : "Co-founder of Google Scholar discussed how research methods have evolved since content went online http:\/\/t.co\/5gt9nKvCfH",
    "id" : 642088099565056001,
    "created_at" : "2015-09-10 21:31:47 +0000",
    "user" : {
      "name" : "Allen Press",
      "screen_name" : "AllenPress",
      "protected" : false,
      "id_str" : "29191374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743847316088512512\/Ttz_6G-q_normal.jpg",
      "id" : 29191374,
      "verified" : false
    }
  },
  "id" : 642099165066067968,
  "created_at" : "2015-09-10 22:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 0, 12 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642064055470039040",
  "geo" : { },
  "id_str" : "642065056189038593",
  "in_reply_to_user_id" : 748018813,
  "text" : "@theWinnower thanks a lot, you\u2019re nearly overdoing the flattery! ;-)",
  "id" : 642065056189038593,
  "in_reply_to_status_id" : 642064055470039040,
  "created_at" : "2015-09-10 20:00:13 +0000",
  "in_reply_to_screen_name" : "theWinnower",
  "in_reply_to_user_id_str" : "748018813",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 27, 39 ],
      "id_str" : "748018813",
      "id" : 748018813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642062026781626372",
  "text" : "Praise also needs to go to @theWinnower. My short text on the success of open already has lots of views. https:\/\/t.co\/tQZY3AlP4m",
  "id" : 642062026781626372,
  "created_at" : "2015-09-10 19:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642049708572213248",
  "geo" : { },
  "id_str" : "642059845907161088",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson \u201CKatzen\u201D, close! :)",
  "id" : 642059845907161088,
  "in_reply_to_status_id" : 642049708572213248,
  "created_at" : "2015-09-10 19:39:30 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642059493761777664",
  "text" : "\u00ABNo way I could deal with the frustration that is academia. I\u2019d rather do political work on copyright reform.\u00BB",
  "id" : 642059493761777664,
  "created_at" : "2015-09-10 19:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 26, 33 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642057348127834112",
  "text" : "Really have to praise the @PacBio software developers\/community, the support on GitHub et al. is great.",
  "id" : 642057348127834112,
  "created_at" : "2015-09-10 19:29:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/j0QgxPjc3M",
      "expanded_url" : "https:\/\/juliareda.eu\/2015\/09\/academics-for-copyright-reform\/",
      "display_url" : "juliareda.eu\/2015\/09\/academ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642021085697961984",
  "text" : "\u00ABWhy academics need to lobby for copyright reform\u00BB Unfortunately so far, we collectively suck at lobbying. https:\/\/t.co\/j0QgxPjc3M",
  "id" : 642021085697961984,
  "created_at" : "2015-09-10 17:05:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642001893192024064",
  "geo" : { },
  "id_str" : "642010365199564803",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander for most of my writing etherpads are good enough. Also: Google docs. But I\u2019m a vim user when working alone ;)",
  "id" : 642010365199564803,
  "in_reply_to_status_id" : 642001893192024064,
  "created_at" : "2015-09-10 16:22:53 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angel Pizarro",
      "screen_name" : "delagoya",
      "indices" : [ 0, 9 ],
      "id_str" : "6977272",
      "id" : 6977272
    }, {
      "name" : "Katharina Hayer",
      "screen_name" : "kat_hayer",
      "indices" : [ 10, 20 ],
      "id_str" : "1061814210",
      "id" : 1061814210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642000000172589056",
  "geo" : { },
  "id_str" : "642000243450605568",
  "in_reply_to_user_id" : 6977272,
  "text" : "@delagoya @kat_hayer congrats!",
  "id" : 642000243450605568,
  "in_reply_to_status_id" : 642000000172589056,
  "created_at" : "2015-09-10 15:42:40 +0000",
  "in_reply_to_screen_name" : "delagoya",
  "in_reply_to_user_id_str" : "6977272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641995901997813760",
  "text" : "RT @kaythaney: Some great discussion happening RIGHT NOW on #openscience and innovations in publishing. Not too late to join! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/gLBNEYS49j",
        "expanded_url" : "https:\/\/etherpad.mozilla.org\/sciencelab-calls-sep10-2015",
        "display_url" : "etherpad.mozilla.org\/sciencelab-cal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641995724943675392",
    "text" : "Some great discussion happening RIGHT NOW on #openscience and innovations in publishing. Not too late to join! https:\/\/t.co\/gLBNEYS49j",
    "id" : 641995724943675392,
    "created_at" : "2015-09-10 15:24:43 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 641995901997813760,
  "created_at" : "2015-09-10 15:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Montague-Hellen",
      "screen_name" : "KateMontagueH",
      "indices" : [ 0, 14 ],
      "id_str" : "1208125945",
      "id" : 1208125945
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 15, 23 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/641984482950705153\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/yC7bOmZA28",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COjJfCSWoAArNNt.png",
      "id_str" : "641984481927274496",
      "id" : 641984481927274496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COjJfCSWoAArNNt.png",
      "sizes" : [ {
        "h" : 144,
        "resize" : "crop",
        "w" : 144
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 239
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 239
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 239
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 239
      } ],
      "display_url" : "pic.twitter.com\/yC7bOmZA28"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641984149490937856",
  "geo" : { },
  "id_str" : "641984482950705153",
  "in_reply_to_user_id" : 1208125945,
  "text" : "@KateMontagueH @PhdGeek the two of you are pretty consistent in your replies ;) http:\/\/t.co\/yC7bOmZA28",
  "id" : 641984482950705153,
  "in_reply_to_status_id" : 641984149490937856,
  "created_at" : "2015-09-10 14:40:02 +0000",
  "in_reply_to_screen_name" : "KateMontagueH",
  "in_reply_to_user_id_str" : "1208125945",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Kate Montague-Hellen",
      "screen_name" : "KateMontagueH",
      "indices" : [ 9, 23 ],
      "id_str" : "1208125945",
      "id" : 1208125945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641978718165041156",
  "geo" : { },
  "id_str" : "641979776215973888",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @KateMontagueH \uD83C\uDFCA don\u2019t drown. ;)",
  "id" : 641979776215973888,
  "in_reply_to_status_id" : 641978718165041156,
  "created_at" : "2015-09-10 14:21:20 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Kate Montague-Hellen",
      "screen_name" : "KateMontagueH",
      "indices" : [ 9, 23 ],
      "id_str" : "1208125945",
      "id" : 1208125945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641976352023945216",
  "geo" : { },
  "id_str" : "641978379097518080",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @KateMontagueH more than happy to! :-)",
  "id" : 641978379097518080,
  "in_reply_to_status_id" : 641976352023945216,
  "created_at" : "2015-09-10 14:15:47 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Kate Montague-Hellen",
      "screen_name" : "KateMontagueH",
      "indices" : [ 21, 35 ],
      "id_str" : "1208125945",
      "id" : 1208125945
    }, {
      "name" : "Aspire",
      "screen_name" : "AspireCharity",
      "indices" : [ 56, 70 ],
      "id_str" : "60919603",
      "id" : 60919603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fundraising",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641977319494680580",
  "text" : "RT @PhdGeek: My wife @KateMontagueH is #fundraising for @AspireCharity for spinal injuries (she used to be a SI nurse). Donate?  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Montague-Hellen",
        "screen_name" : "KateMontagueH",
        "indices" : [ 8, 22 ],
        "id_str" : "1208125945",
        "id" : 1208125945
      }, {
        "name" : "Aspire",
        "screen_name" : "AspireCharity",
        "indices" : [ 43, 57 ],
        "id_str" : "60919603",
        "id" : 60919603
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fundraising",
        "indices" : [ 26, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ekaPJkZRqM",
        "expanded_url" : "http:\/\/www.justgiving.com\/KateMHChannelSwim\/?utm_source=Twitter&utm_medium=fundraisingpage&utm_content=KateMHChannelSwim&utm_campaign=pfp-tweet",
        "display_url" : "justgiving.com\/KateMHChannelS\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641976352023945216",
    "text" : "My wife @KateMontagueH is #fundraising for @AspireCharity for spinal injuries (she used to be a SI nurse). Donate?  http:\/\/t.co\/ekaPJkZRqM",
    "id" : 641976352023945216,
    "created_at" : "2015-09-10 14:07:44 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 641977319494680580,
  "created_at" : "2015-09-10 14:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641975869976772609",
  "text" : "yay for real-time collaborative writing &amp; editing \uD83D\uDC4D",
  "id" : 641975869976772609,
  "created_at" : "2015-09-10 14:05:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/8AofYHRsZA",
      "expanded_url" : "https:\/\/instagram.com\/p\/7cpJmZBwl6\/",
      "display_url" : "instagram.com\/p\/7cpJmZBwl6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "641928501789085696",
  "text" : "long time no see https:\/\/t.co\/8AofYHRsZA",
  "id" : 641928501789085696,
  "created_at" : "2015-09-10 10:57:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 3, 19 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    }, {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 116, 123 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/FLjY8RxBSd",
      "expanded_url" : "http:\/\/on.recode.net\/1Fk4XWK",
      "display_url" : "on.recode.net\/1Fk4XWK"
    } ]
  },
  "geo" : { },
  "id_str" : "641920926523723776",
  "text" : "RT @raspberryperson: Twitter Bias: We Listen When Men Talk Tech and Women Talk Diversity http:\/\/t.co\/FLjY8RxBSd via @recode",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Recode",
        "screen_name" : "Recode",
        "indices" : [ 95, 102 ],
        "id_str" : "2244340904",
        "id" : 2244340904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/FLjY8RxBSd",
        "expanded_url" : "http:\/\/on.recode.net\/1Fk4XWK",
        "display_url" : "on.recode.net\/1Fk4XWK"
      } ]
    },
    "geo" : { },
    "id_str" : "641707295286632448",
    "text" : "Twitter Bias: We Listen When Men Talk Tech and Women Talk Diversity http:\/\/t.co\/FLjY8RxBSd via @recode",
    "id" : 641707295286632448,
    "created_at" : "2015-09-09 20:18:36 +0000",
    "user" : {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "protected" : true,
      "id_str" : "2841131495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636978308186554368\/j_6M1_vq_normal.png",
      "id" : 2841131495,
      "verified" : false
    }
  },
  "id" : 641920926523723776,
  "created_at" : "2015-09-10 10:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641903985734090752",
  "text" : "is it just me or is ncbi (taxonomy) right now very laggy &amp; crashes all the time?",
  "id" : 641903985734090752,
  "created_at" : "2015-09-10 09:20:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641866903212982273",
  "geo" : { },
  "id_str" : "641878577806462976",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju apparently microsoft now really has to copy all \u2018features\u2019 of mac os\u2026",
  "id" : 641878577806462976,
  "in_reply_to_status_id" : 641866903212982273,
  "created_at" : "2015-09-10 07:39:13 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Minot",
      "screen_name" : "sminot",
      "indices" : [ 3, 10 ],
      "id_str" : "27120158",
      "id" : 27120158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/OoHtctfX1M",
      "expanded_url" : "https:\/\/twitter.com\/bioinformatics\/status\/641725671379566592",
      "display_url" : "twitter.com\/bioinformatics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641877470065655808",
  "text" : "RT @sminot: What an interesting collection of bizarre errors! A great resource for writing tests for file parsers  https:\/\/t.co\/OoHtctfX1M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/OoHtctfX1M",
        "expanded_url" : "https:\/\/twitter.com\/bioinformatics\/status\/641725671379566592",
        "display_url" : "twitter.com\/bioinformatics\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641728398595756032",
    "text" : "What an interesting collection of bizarre errors! A great resource for writing tests for file parsers  https:\/\/t.co\/OoHtctfX1M",
    "id" : 641728398595756032,
    "created_at" : "2015-09-09 21:42:27 +0000",
    "user" : {
      "name" : "Sam Minot",
      "screen_name" : "sminot",
      "protected" : false,
      "id_str" : "27120158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871740031198568450\/r8OTaMxT_normal.jpg",
      "id" : 27120158,
      "verified" : false
    }
  },
  "id" : 641877470065655808,
  "created_at" : "2015-09-10 07:34:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "46213956",
      "id" : 46213956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JamilSmith\/status\/641796344621965312\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/X725xph8uF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COgeX5mWsAAkruH.jpg",
      "id_str" : "641796342847811584",
      "id" : 641796342847811584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COgeX5mWsAAkruH.jpg",
      "sizes" : [ {
        "h" : 249,
        "resize" : "fit",
        "w" : 479
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 479
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 479
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 479
      } ],
      "display_url" : "pic.twitter.com\/X725xph8uF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641877230738612224",
  "text" : "RT @JamilSmith: Just saying, Kim Davis. http:\/\/t.co\/X725xph8uF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JamilSmith\/status\/641796344621965312\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/X725xph8uF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COgeX5mWsAAkruH.jpg",
        "id_str" : "641796342847811584",
        "id" : 641796342847811584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COgeX5mWsAAkruH.jpg",
        "sizes" : [ {
          "h" : 249,
          "resize" : "fit",
          "w" : 479
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 479
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 479
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 479
        } ],
        "display_url" : "pic.twitter.com\/X725xph8uF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641796344621965312",
    "text" : "Just saying, Kim Davis. http:\/\/t.co\/X725xph8uF",
    "id" : 641796344621965312,
    "created_at" : "2015-09-10 02:12:27 +0000",
    "user" : {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "protected" : false,
      "id_str" : "46213956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875585850456723456\/GCwUC18n_normal.jpg",
      "id" : 46213956,
      "verified" : true
    }
  },
  "id" : 641877230738612224,
  "created_at" : "2015-09-10 07:33:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641873042050781184",
  "text" : "\u00ABHow much time do we have for writing the exam?\u00BB \u2013 \u00ABUntil my laptop battery dies and I\u2019m getting bored, deal?\u00BB",
  "id" : 641873042050781184,
  "created_at" : "2015-09-10 07:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 46, 59 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641628827572174849",
  "geo" : { },
  "id_str" : "641629207957753856",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch nope, have to largely agree with @PhilippBayer\u2019s initial rival that it\u2019s advertising. Performance examples super biased.",
  "id" : 641629207957753856,
  "in_reply_to_status_id" : 641628827572174849,
  "created_at" : "2015-09-09 15:08:18 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 3, 12 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641624552569704448",
  "text" : "RT @erlichya: How I used #science to fight back and win my insurance company. \nA blog post dedicated for new PhD students.\nhttps:\/\/t.co\/dSB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/dSBUrBlVpd",
        "expanded_url" : "https:\/\/medium.com\/@erlichya\/how-i-fought-and-won-against-my-insurance-company-using-grad-school-skills-548ef4347ec9",
        "display_url" : "medium.com\/@erlichya\/how-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641322044622274560",
    "text" : "How I used #science to fight back and win my insurance company. \nA blog post dedicated for new PhD students.\nhttps:\/\/t.co\/dSBUrBlVpd \u2026 \u2026",
    "id" : 641322044622274560,
    "created_at" : "2015-09-08 18:47:45 +0000",
    "user" : {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "protected" : false,
      "id_str" : "495517322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906175801770606592\/4xxuTloM_normal.jpg",
      "id" : 495517322,
      "verified" : false
    }
  },
  "id" : 641624552569704448,
  "created_at" : "2015-09-09 14:49:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641620802836779009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232977781494, 8.6275283744368 ]
  },
  "id_str" : "641621069850394624",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy congrats!",
  "id" : 641621069850394624,
  "in_reply_to_status_id" : 641620802836779009,
  "created_at" : "2015-09-09 14:35:58 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3VN8qb8Vb9",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/128706094161\/coping-with-grad-school",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/128706094\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641608001728704516",
  "text" : "that\u2019s in the afternoon. in the morning we \u2018sip\u2019 coffee in the same fashion. http:\/\/t.co\/3VN8qb8Vb9",
  "id" : 641608001728704516,
  "created_at" : "2015-09-09 13:44:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641606447005085696",
  "geo" : { },
  "id_str" : "641606573119414272",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, i\u2019m pretty optimistic that this will speed lots of things up, e.g. getting genotype\/allele frequencies.",
  "id" : 641606573119414272,
  "in_reply_to_status_id" : 641606447005085696,
  "created_at" : "2015-09-09 13:38:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641605503056015360",
  "geo" : { },
  "id_str" : "641606201382436864",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer i don\u2019t know how large the DB will be after the migration\/reparsing.",
  "id" : 641606201382436864,
  "in_reply_to_status_id" : 641605503056015360,
  "created_at" : "2015-09-09 13:36:53 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/6StoEcpMi7",
      "expanded_url" : "https:\/\/www.hetzner.de\/de\/hosting\/produkte_rootserver\/ex40-hybrid",
      "display_url" : "hetzner.de\/de\/hosting\/pro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "641604667676475392",
  "geo" : { },
  "id_str" : "641604904184844288",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer i see, was originally thinking about https:\/\/t.co\/6StoEcpMi7 or the 40-SSD.",
  "id" : 641604904184844288,
  "in_reply_to_status_id" : 641604667676475392,
  "created_at" : "2015-09-09 13:31:44 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641602956803092480",
  "text" : "spreading the ggplot-gospel, one student at a time.",
  "id" : 641602956803092480,
  "created_at" : "2015-09-09 13:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641581498995503104",
  "geo" : { },
  "id_str" : "641601995170840576",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer or is there lots of trash we could get rid off?",
  "id" : 641601995170840576,
  "in_reply_to_status_id" : 641581498995503104,
  "created_at" : "2015-09-09 13:20:10 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641581498995503104",
  "geo" : { },
  "id_str" : "641601932914753536",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer i guess that means going for a SSD for the parsing won\u2019t work?",
  "id" : 641601932914753536,
  "in_reply_to_status_id" : 641581498995503104,
  "created_at" : "2015-09-09 13:19:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 3, 19 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/raspberryperson\/status\/641575590517166081\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/HRX5FOMm1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COdVmW1XAAA4pGQ.png",
      "id_str" : "641575589376360448",
      "id" : 641575589376360448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COdVmW1XAAA4pGQ.png",
      "sizes" : [ {
        "h" : 87,
        "resize" : "crop",
        "w" : 87
      }, {
        "h" : 87,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 87,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 87,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 87,
        "resize" : "fit",
        "w" : 466
      } ],
      "display_url" : "pic.twitter.com\/HRX5FOMm1t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/9KwyLQ9QtE",
      "expanded_url" : "http:\/\/learnpythonthehardway.org\/book\/ex3.html",
      "display_url" : "learnpythonthehardway.org\/book\/ex3.html"
    } ]
  },
  "geo" : { },
  "id_str" : "641578340705521665",
  "text" : "RT @raspberryperson: \u203ALearn Python The Hard Way\u2039 nailed it. http:\/\/t.co\/9KwyLQ9QtE http:\/\/t.co\/HRX5FOMm1t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/raspberryperson\/status\/641575590517166081\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/HRX5FOMm1t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COdVmW1XAAA4pGQ.png",
        "id_str" : "641575589376360448",
        "id" : 641575589376360448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COdVmW1XAAA4pGQ.png",
        "sizes" : [ {
          "h" : 87,
          "resize" : "crop",
          "w" : 87
        }, {
          "h" : 87,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 87,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 87,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 87,
          "resize" : "fit",
          "w" : 466
        } ],
        "display_url" : "pic.twitter.com\/HRX5FOMm1t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/9KwyLQ9QtE",
        "expanded_url" : "http:\/\/learnpythonthehardway.org\/book\/ex3.html",
        "display_url" : "learnpythonthehardway.org\/book\/ex3.html"
      } ]
    },
    "geo" : { },
    "id_str" : "641575590517166081",
    "text" : "\u203ALearn Python The Hard Way\u2039 nailed it. http:\/\/t.co\/9KwyLQ9QtE http:\/\/t.co\/HRX5FOMm1t",
    "id" : 641575590517166081,
    "created_at" : "2015-09-09 11:35:15 +0000",
    "user" : {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "protected" : true,
      "id_str" : "2841131495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636978308186554368\/j_6M1_vq_normal.png",
      "id" : 2841131495,
      "verified" : false
    }
  },
  "id" : 641578340705521665,
  "created_at" : "2015-09-09 11:46:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641571943997681665",
  "geo" : { },
  "id_str" : "641575755076489216",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer also: how much space do we need right now?",
  "id" : 641575755076489216,
  "in_reply_to_status_id" : 641571943997681665,
  "created_at" : "2015-09-09 11:35:54 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641571943997681665",
  "geo" : { },
  "id_str" : "641575553233997825",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I guess we can\u2019t do the move right now? ;)",
  "id" : 641575553233997825,
  "in_reply_to_status_id" : 641571943997681665,
  "created_at" : "2015-09-09 11:35:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641570186844311552",
  "geo" : { },
  "id_str" : "641573977580793856",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer sounds reasonable to me.",
  "id" : 641573977580793856,
  "in_reply_to_status_id" : 641570186844311552,
  "created_at" : "2015-09-09 11:28:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641563134935732224",
  "geo" : { },
  "id_str" : "641565182603476992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch it\u2019s even super slow from inside the DFN, but that was already the case yesterday :D",
  "id" : 641565182603476992,
  "in_reply_to_status_id" : 641563134935732224,
  "created_at" : "2015-09-09 10:53:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 3, 9 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/uWYM6uEzR6",
      "expanded_url" : "http:\/\/ift.tt\/1OclJys",
      "display_url" : "ift.tt\/1OclJys"
    } ]
  },
  "geo" : { },
  "id_str" : "641557829896306690",
  "text" : "RT @tante: The strange art on 1990s-2010s graphics card boxes http:\/\/t.co\/uWYM6uEzR6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/uWYM6uEzR6",
        "expanded_url" : "http:\/\/ift.tt\/1OclJys",
        "display_url" : "ift.tt\/1OclJys"
      } ]
    },
    "geo" : { },
    "id_str" : "641556295779287040",
    "text" : "The strange art on 1990s-2010s graphics card boxes http:\/\/t.co\/uWYM6uEzR6",
    "id" : 641556295779287040,
    "created_at" : "2015-09-09 10:18:35 +0000",
    "user" : {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "protected" : false,
      "id_str" : "14179278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802837466512236544\/UiursIr__normal.jpg",
      "id" : 14179278,
      "verified" : true
    }
  },
  "id" : 641557829896306690,
  "created_at" : "2015-09-09 10:24:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/VzHBVbBaq9",
      "expanded_url" : "http:\/\/www.streetartnews.net\/2015\/09\/the-times-they-are-changing-new-mural.html",
      "display_url" : "streetartnews.net\/2015\/09\/the-ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641532107978883073",
  "text" : "indeed, the times they are a-changin\u2019 http:\/\/t.co\/VzHBVbBaq9",
  "id" : 641532107978883073,
  "created_at" : "2015-09-09 08:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devi Sridhar",
      "screen_name" : "devisridhar",
      "indices" : [ 3, 15 ],
      "id_str" : "174151902",
      "id" : 174151902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/GealrTDVe4",
      "expanded_url" : "http:\/\/gu.com\/p\/4c6qz\/stw",
      "display_url" : "gu.com\/p\/4c6qz\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "641528233876430848",
  "text" : "RT @devisridhar: Four steps to killing off sexism in science http:\/\/t.co\/GealrTDVe4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/GealrTDVe4",
        "expanded_url" : "http:\/\/gu.com\/p\/4c6qz\/stw",
        "display_url" : "gu.com\/p\/4c6qz\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "641527779306156032",
    "text" : "Four steps to killing off sexism in science http:\/\/t.co\/GealrTDVe4",
    "id" : 641527779306156032,
    "created_at" : "2015-09-09 08:25:16 +0000",
    "user" : {
      "name" : "Devi Sridhar",
      "screen_name" : "devisridhar",
      "protected" : false,
      "id_str" : "174151902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927788109315608576\/yYBS709P_normal.jpg",
      "id" : 174151902,
      "verified" : true
    }
  },
  "id" : 641528233876430848,
  "created_at" : "2015-09-09 08:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/K1vo9fSoSq",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/HhTXt43pk1I1W\/200.gif",
      "display_url" : "media3.giphy.com\/media\/HhTXt43p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "641525062512709632",
  "geo" : { },
  "id_str" : "641525250186977280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch https:\/\/t.co\/K1vo9fSoSq",
  "id" : 641525250186977280,
  "in_reply_to_status_id" : 641525062512709632,
  "created_at" : "2015-09-09 08:15:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 83, 96 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641515235552198656",
  "geo" : { },
  "id_str" : "641518039746387968",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch sorry, still didn\u2019t find the time. A rather busy week here at work :( @PhilippBayer",
  "id" : 641518039746387968,
  "in_reply_to_status_id" : 641515235552198656,
  "created_at" : "2015-09-09 07:46:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/3w8fk7rDhQ",
      "expanded_url" : "https:\/\/twitter.com\/bchesky\/status\/641357556573605888",
      "display_url" : "twitter.com\/bchesky\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641386259819155456",
  "text" : "How many stayed in the streets? https:\/\/t.co\/3w8fk7rDhQ",
  "id" : 641386259819155456,
  "created_at" : "2015-09-08 23:02:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641373421285285888",
  "geo" : { },
  "id_str" : "641373866745548800",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime not sure I can successfully sell the wish to have kids so I can contribute to open source software during paternity leave.",
  "id" : 641373866745548800,
  "in_reply_to_status_id" : 641373421285285888,
  "created_at" : "2015-09-08 22:13:40 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641367778360971264",
  "geo" : { },
  "id_str" : "641371668229816320",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime i totally would, if it wasn\u2019t for that pesky day job ;)",
  "id" : 641371668229816320,
  "in_reply_to_status_id" : 641367778360971264,
  "created_at" : "2015-09-08 22:04:56 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641366005235642368",
  "geo" : { },
  "id_str" : "641366699757826048",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime oh, very nice! Now I feel slightly pressured into stepping up our game ;)",
  "id" : 641366699757826048,
  "in_reply_to_status_id" : 641366005235642368,
  "created_at" : "2015-09-08 21:45:11 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641350582276456448",
  "geo" : { },
  "id_str" : "641363737702608896",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime best thing about managing an open data resource: hand waive that running it keeps you so busy, can\u2019t analyze it simultaneously ;)",
  "id" : 641363737702608896,
  "in_reply_to_status_id" : 641350582276456448,
  "created_at" : "2015-09-08 21:33:25 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/QD3WtkfMek",
      "expanded_url" : "http:\/\/loveandradio.org\/2015\/08\/bride-of-the-sea\/",
      "display_url" : "loveandradio.org\/2015\/08\/bride-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641335089373270020",
  "text" : "Bride of the Sea is a really impressive episode of Love + Radio. http:\/\/t.co\/QD3WtkfMek",
  "id" : 641335089373270020,
  "created_at" : "2015-09-08 19:39:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 0, 13 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 14, 28 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 29, 43 ],
      "id_str" : "388503174",
      "id" : 388503174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641279879430803456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403730297055, 8.753325886722875 ]
  },
  "id_str" : "641329952600813574",
  "in_reply_to_user_id" : 404442001,
  "text" : "@emckiernan13 @Protohedgehog @juancommander thanks a lot! :-)",
  "id" : 641329952600813574,
  "in_reply_to_status_id" : 641279879430803456,
  "created_at" : "2015-09-08 19:19:10 +0000",
  "in_reply_to_screen_name" : "emckiernan13",
  "in_reply_to_user_id_str" : "404442001",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641313007864311808",
  "geo" : { },
  "id_str" : "641314696465907713",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze brielliant!",
  "id" : 641314696465907713,
  "in_reply_to_status_id" : 641313007864311808,
  "created_at" : "2015-09-08 18:18:33 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/RFZAK8GQqR",
      "expanded_url" : "https:\/\/twitter.com\/io9\/status\/641272984158736385",
      "display_url" : "twitter.com\/io9\/status\/641\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641308907080679424",
  "text" : "RT @vortacist: This was crafted by a woman for a woman amputee cosplayer: WITNESS. https:\/\/t.co\/RFZAK8GQqR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/RFZAK8GQqR",
        "expanded_url" : "https:\/\/twitter.com\/io9\/status\/641272984158736385",
        "display_url" : "twitter.com\/io9\/status\/641\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641307099910275072",
    "text" : "This was crafted by a woman for a woman amputee cosplayer: WITNESS. https:\/\/t.co\/RFZAK8GQqR",
    "id" : 641307099910275072,
    "created_at" : "2015-09-08 17:48:22 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 641308907080679424,
  "created_at" : "2015-09-08 17:55:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dataviz",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Av5ERA3SK3",
      "expanded_url" : "http:\/\/thetruesize.com\/#?borders=1~!MTUwMTgxNzk.NDY3MTc3NQ*MzM3OTI5Mzk(ODQ4MDQzOQ~!CONTIGUOUS_US*MTAwMjQwNzU.MjUwMjM1MTc(MTc1)MA~!IN*NTI2NDA1MQ.Nzg2MzQyMQ)MQ~!CN*OTkyMTY5Nw.NzMxNDcwNQ(MjI1)Mg",
      "display_url" : "thetruesize.com\/#?borders=1~!M\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641254732229701632",
  "text" : "RT @randal_olson: Nice! Now we can make our own \"true size of [country]\" maps with this tool. #dataviz\n\nhttp:\/\/t.co\/Av5ERA3SK3 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/641253891221377024\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/DOmpB7JKoz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COYxBB4WsAAOz5J.png",
        "id_str" : "641253890701307904",
        "id" : 641253890701307904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COYxBB4WsAAOz5J.png",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 557
        }, {
          "h" : 1262,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1262,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 983
        } ],
        "display_url" : "pic.twitter.com\/DOmpB7JKoz"
      } ],
      "hashtags" : [ {
        "text" : "dataviz",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Av5ERA3SK3",
        "expanded_url" : "http:\/\/thetruesize.com\/#?borders=1~!MTUwMTgxNzk.NDY3MTc3NQ*MzM3OTI5Mzk(ODQ4MDQzOQ~!CONTIGUOUS_US*MTAwMjQwNzU.MjUwMjM1MTc(MTc1)MA~!IN*NTI2NDA1MQ.Nzg2MzQyMQ)MQ~!CN*OTkyMTY5Nw.NzMxNDcwNQ(MjI1)Mg",
        "display_url" : "thetruesize.com\/#?borders=1~!M\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641253891221377024",
    "text" : "Nice! Now we can make our own \"true size of [country]\" maps with this tool. #dataviz\n\nhttp:\/\/t.co\/Av5ERA3SK3 http:\/\/t.co\/DOmpB7JKoz",
    "id" : 641253891221377024,
    "created_at" : "2015-09-08 14:16:56 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 641254732229701632,
  "created_at" : "2015-09-08 14:20:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/7F5RNmYRLu",
      "expanded_url" : "http:\/\/sexualitics.org\/",
      "display_url" : "sexualitics.org"
    } ]
  },
  "in_reply_to_status_id_str" : "641250899034247168",
  "geo" : { },
  "id_str" : "641251134628347905",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn someone on the mailing list of http:\/\/t.co\/7F5RNmYRLu",
  "id" : 641251134628347905,
  "in_reply_to_status_id" : 641250899034247168,
  "created_at" : "2015-09-08 14:05:59 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 3, 19 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641233256353005569",
  "text" : "RT @raspberryperson: \u00BBSimply telling women to \u201Clean in\u201D demands nothing of us as men. It frees us from listening and reflecting [...]\u00AB http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/57YNpzuJgL",
        "expanded_url" : "https:\/\/twitter.com\/EvrydayFeminism\/status\/639196104580534272",
        "display_url" : "twitter.com\/EvrydayFeminis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641231198132551680",
    "text" : "\u00BBSimply telling women to \u201Clean in\u201D demands nothing of us as men. It frees us from listening and reflecting [...]\u00AB https:\/\/t.co\/57YNpzuJgL",
    "id" : 641231198132551680,
    "created_at" : "2015-09-08 12:46:45 +0000",
    "user" : {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "protected" : true,
      "id_str" : "2841131495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636978308186554368\/j_6M1_vq_normal.png",
      "id" : 2841131495,
      "verified" : false
    }
  },
  "id" : 641233256353005569,
  "created_at" : "2015-09-08 12:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 17, 31 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 32, 44 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Zamin Iqbal",
      "screen_name" : "ZaminIqbal",
      "indices" : [ 45, 56 ],
      "id_str" : "2191109263",
      "id" : 2191109263
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 57, 66 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nuoWnV5fWU",
      "expanded_url" : "http:\/\/figshare.com\/articles\/Genome_Skimming_of_Symbiotic_Communities_an_in_silico_Evaluation_of_Assembly_Approaches\/1337845",
      "display_url" : "figshare.com\/articles\/Genom\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "641187450556162048",
  "geo" : { },
  "id_str" : "641190814991929344",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @BioMickWatson @froggleston @ZaminIqbal @hollybik thus missing lots of stuff that\u2019s in the data, see http:\/\/t.co\/nuoWnV5fWU",
  "id" : 641190814991929344,
  "in_reply_to_status_id" : 641187450556162048,
  "created_at" : "2015-09-08 10:06:17 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 17, 31 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 32, 44 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Zamin Iqbal",
      "screen_name" : "ZaminIqbal",
      "indices" : [ 45, 56 ],
      "id_str" : "2191109263",
      "id" : 2191109263
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 57, 66 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641187450556162048",
  "geo" : { },
  "id_str" : "641190750449991680",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @BioMickWatson @froggleston @ZaminIqbal @hollybik seen this too, n50 maximized by excluding formation of short contigs.",
  "id" : 641190750449991680,
  "in_reply_to_status_id" : 641187450556162048,
  "created_at" : "2015-09-08 10:06:02 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/xmAlahNYyr",
      "expanded_url" : "https:\/\/twitter.com\/hollybik\/status\/641185541292167168",
      "display_url" : "twitter.com\/hollybik\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641188265933078528",
  "text" : "Amen! https:\/\/t.co\/xmAlahNYyr",
  "id" : 641188265933078528,
  "created_at" : "2015-09-08 09:56:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641186912892493824",
  "geo" : { },
  "id_str" : "641188193031864320",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot maybe better: \n\u00A0|\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\u00A0\u00A0\uD83D\uDC26\n\u00A0|\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\n\u00A0| \u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\n\u00A0|_____________\n\uD83D\uDCA9\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDCA9\uD83D\uDCA9\uD83D\uDCA9",
  "id" : 641188193031864320,
  "in_reply_to_status_id" : 641186912892493824,
  "created_at" : "2015-09-08 09:55:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641184246116302848",
  "geo" : { },
  "id_str" : "641186307880919040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \n\u00A0|\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDCA9\n\u00A0|\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDCA9\n\u00A0| \u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDCA9 \n\u00A0|___________________\n\uD83D\uDC26\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\uD83D\uDC26\uD83D\uDC26\uD83D\uDC26",
  "id" : 641186307880919040,
  "in_reply_to_status_id" : 641184246116302848,
  "created_at" : "2015-09-08 09:48:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/OsyuIpOP23",
      "expanded_url" : "https:\/\/medium.com\/@chazhutton\/life-explained-via-7-post-it-note-graphs-2d713f79e815",
      "display_url" : "medium.com\/@chazhutton\/li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641181118306324480",
  "text" : "life \u2013 in 7 post-its https:\/\/t.co\/OsyuIpOP23",
  "id" : 641181118306324480,
  "created_at" : "2015-09-08 09:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/dMB0pdUrqt",
      "expanded_url" : "http:\/\/blog.rogach.org\/2015\/09\/diy-control-pedal-on-linux.html",
      "display_url" : "blog.rogach.org\/2015\/09\/diy-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641177439784321024",
  "text" : "that\u2019s a genius idea: how can you call yourself a rockstar programmer if you don\u2019t have any stompboxes! http:\/\/t.co\/dMB0pdUrqt",
  "id" : 641177439784321024,
  "created_at" : "2015-09-08 09:13:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ZyarTW9v4e",
      "expanded_url" : "https:\/\/twitter.com\/LouWoodley\/status\/641173135463706624",
      "display_url" : "twitter.com\/LouWoodley\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641174819317415936",
  "text" : "Most interesting: there are still people who still use their smartphones to place calls. https:\/\/t.co\/ZyarTW9v4e",
  "id" : 641174819317415936,
  "created_at" : "2015-09-08 09:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641167124107501568",
  "geo" : { },
  "id_str" : "641167183448571904",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer that would be cool!",
  "id" : 641167183448571904,
  "in_reply_to_status_id" : 641167124107501568,
  "created_at" : "2015-09-08 08:32:23 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641166107831848960",
  "geo" : { },
  "id_str" : "641166187557220352",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer i\u2019ll take that for a \u201Cyes, that\u2019s a good idea\u201D ;)",
  "id" : 641166187557220352,
  "in_reply_to_status_id" : 641166107831848960,
  "created_at" : "2015-09-08 08:28:26 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641164578483773440",
  "geo" : { },
  "id_str" : "641164849754578944",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer that\u2019s rather fast. maybe should announce this via twitter\/facebook? :D",
  "id" : 641164849754578944,
  "in_reply_to_status_id" : 641164578483773440,
  "created_at" : "2015-09-08 08:23:07 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641164402104864768",
  "geo" : { },
  "id_str" : "641164699795517440",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ok, I\u2019ll try to find some time in the afternoon. Or maybe @PhilippBayer finds time pre-bedtime :D",
  "id" : 641164699795517440,
  "in_reply_to_status_id" : 641164402104864768,
  "created_at" : "2015-09-08 08:22:31 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641163794459312128",
  "geo" : { },
  "id_str" : "641163997723631616",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer (it\u2019s how i noticed, because of their API warnings)",
  "id" : 641163997723631616,
  "in_reply_to_status_id" : 641163794459312128,
  "created_at" : "2015-09-08 08:19:43 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641163738381426688",
  "geo" : { },
  "id_str" : "641163946850918400",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ok, maybe we just run the fitbit-worker? because that one gets external data pushed regularly.",
  "id" : 641163946850918400,
  "in_reply_to_status_id" : 641163738381426688,
  "created_at" : "2015-09-08 08:19:31 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641162571026984960",
  "geo" : { },
  "id_str" : "641162766900940800",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Ah, i see. Couldn\u2019t we run the non-parsing workers, e.g. fitbit despite that?",
  "id" : 641162766900940800,
  "in_reply_to_status_id" : 641162571026984960,
  "created_at" : "2015-09-08 08:14:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641158074921787392",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer btw. are all workers disabled by design? :-)",
  "id" : 641158074921787392,
  "created_at" : "2015-09-08 07:56:11 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641144665580929024",
  "text" : "RT @vortacist: Hey gamers: Friend has a 12yo gamer son &amp; wants to explain feminism, GG!=ethics in journalism, rape jokes bad, etc. Got reso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641054059592581120",
    "text" : "Hey gamers: Friend has a 12yo gamer son &amp; wants to explain feminism, GG!=ethics in journalism, rape jokes bad, etc. Got resources for us?",
    "id" : 641054059592581120,
    "created_at" : "2015-09-08 01:02:52 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 641144665580929024,
  "created_at" : "2015-09-08 07:02:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641143899789070336",
  "text" : "\u00ABThat\u2019s a sweet Circos plot!\u00BB \u2013 \u00ABUh, that\u2019s a phylogenetic tree, but close\u2026\u00BB",
  "id" : 641143899789070336,
  "created_at" : "2015-09-08 06:59:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Perry",
      "screen_name" : "TheSpencerPerry",
      "indices" : [ 3, 19 ],
      "id_str" : "40732344",
      "id" : 40732344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheSpencerPerry\/status\/640983987448492032\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/mUU791E5iO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COU7ih2VEAE8OiR.png",
      "id_str" : "640983986357997569",
      "id" : 640983986357997569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COU7ih2VEAE8OiR.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 853
      } ],
      "display_url" : "pic.twitter.com\/mUU791E5iO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641026785258393604",
  "text" : "RT @TheSpencerPerry: The internet in a nutshell. http:\/\/t.co\/mUU791E5iO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheSpencerPerry\/status\/640983987448492032\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/mUU791E5iO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COU7ih2VEAE8OiR.png",
        "id_str" : "640983986357997569",
        "id" : 640983986357997569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COU7ih2VEAE8OiR.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 853
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 853
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 853
        } ],
        "display_url" : "pic.twitter.com\/mUU791E5iO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640983987448492032",
    "text" : "The internet in a nutshell. http:\/\/t.co\/mUU791E5iO",
    "id" : 640983987448492032,
    "created_at" : "2015-09-07 20:24:26 +0000",
    "user" : {
      "name" : "Spencer Perry",
      "screen_name" : "TheSpencerPerry",
      "protected" : false,
      "id_str" : "40732344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925723586081579013\/fRFhhb48_normal.jpg",
      "id" : 40732344,
      "verified" : false
    }
  },
  "id" : 641026785258393604,
  "created_at" : "2015-09-07 23:14:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CB8\u0CAE\u0CB0\u0CCD\u0CA5 \u0C86\u0CB0\u0CCD\u0CAF",
      "screen_name" : "SamarthArya",
      "indices" : [ 0, 12 ],
      "id_str" : "83054101",
      "id" : 83054101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641025816558764036",
  "geo" : { },
  "id_str" : "641025923337310208",
  "in_reply_to_user_id" : 83054101,
  "text" : "@SamarthArya thanks, nice to see you here as well! :)",
  "id" : 641025923337310208,
  "in_reply_to_status_id" : 641025816558764036,
  "created_at" : "2015-09-07 23:11:04 +0000",
  "in_reply_to_screen_name" : "SamarthArya",
  "in_reply_to_user_id_str" : "83054101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau P aus G",
      "screen_name" : "ursa_minor_",
      "indices" : [ 0, 12 ],
      "id_str" : "156578973",
      "id" : 156578973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640961109919444992",
  "geo" : { },
  "id_str" : "640979471940616192",
  "in_reply_to_user_id" : 156578973,
  "text" : "@ursa_minor_ a lovely idea :)",
  "id" : 640979471940616192,
  "in_reply_to_status_id" : 640961109919444992,
  "created_at" : "2015-09-07 20:06:29 +0000",
  "in_reply_to_screen_name" : "ursa_minor_",
  "in_reply_to_user_id_str" : "156578973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Seay",
      "screen_name" : "texasinafrica",
      "indices" : [ 3, 17 ],
      "id_str" : "33400961",
      "id" : 33400961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/texasinafrica\/status\/640643031503233024\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/G6FE4WyR0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COQFcAqUwAAtkJ2.jpg",
      "id_str" : "640643025765449728",
      "id" : 640643025765449728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COQFcAqUwAAtkJ2.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 749
      } ],
      "display_url" : "pic.twitter.com\/G6FE4WyR0F"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ioojZAvQZB",
      "expanded_url" : "https:\/\/www.insidehighered.com\/news\/2015\/09\/05\/political-science-association-criticized-agreeing-keep-babies-out-exhibit-hall",
      "display_url" : "insidehighered.com\/news\/2015\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640956603697655808",
  "text" : "RT @texasinafrica: Lest you think our profession is past this crap.  https:\/\/t.co\/ioojZAvQZB http:\/\/t.co\/G6FE4WyR0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/texasinafrica\/status\/640643031503233024\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/G6FE4WyR0F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COQFcAqUwAAtkJ2.jpg",
        "id_str" : "640643025765449728",
        "id" : 640643025765449728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COQFcAqUwAAtkJ2.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/G6FE4WyR0F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/ioojZAvQZB",
        "expanded_url" : "https:\/\/www.insidehighered.com\/news\/2015\/09\/05\/political-science-association-criticized-agreeing-keep-babies-out-exhibit-hall",
        "display_url" : "insidehighered.com\/news\/2015\/09\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640643031503233024",
    "text" : "Lest you think our profession is past this crap.  https:\/\/t.co\/ioojZAvQZB http:\/\/t.co\/G6FE4WyR0F",
    "id" : 640643031503233024,
    "created_at" : "2015-09-06 21:49:35 +0000",
    "user" : {
      "name" : "Laura Seay",
      "screen_name" : "texasinafrica",
      "protected" : false,
      "id_str" : "33400961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690643712\/texasinafrica_normal.jpg",
      "id" : 33400961,
      "verified" : true
    }
  },
  "id" : 640956603697655808,
  "created_at" : "2015-09-07 18:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/8rz5yU9Cjy",
      "expanded_url" : "https:\/\/instagram.com\/p\/5-KC5Mhwgo\/?taken-by=gedankenstuecke",
      "display_url" : "instagram.com\/p\/5-KC5Mhwgo\/?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "640946672294621184",
  "geo" : { },
  "id_str" : "640947348588371968",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg mehr https:\/\/t.co\/8rz5yU9Cjy vom Niederschlag her ;)",
  "id" : 640947348588371968,
  "in_reply_to_status_id" : 640946672294621184,
  "created_at" : "2015-09-07 17:58:50 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/MADDJTTjd1",
      "expanded_url" : "https:\/\/instagram.com\/p\/7Vqf-khwkV\/",
      "display_url" : "instagram.com\/p\/7Vqf-khwkV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "640946307780214784",
  "text" : "Home, just in time https:\/\/t.co\/MADDJTTjd1",
  "id" : 640946307780214784,
  "created_at" : "2015-09-07 17:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/640944499775143936\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/eOixQ1EX8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COUXoGTWsAAiQkh.jpg",
      "id_str" : "640944499624161280",
      "id" : 640944499624161280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COUXoGTWsAAiQkh.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 1554,
        "resize" : "fit",
        "w" : 1553
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1554,
        "resize" : "fit",
        "w" : 1553
      } ],
      "display_url" : "pic.twitter.com\/eOixQ1EX8I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640944499775143936",
  "text" : "Time and again I'm puzzled why people around here are so deeply in love with the sun grid engine. http:\/\/t.co\/eOixQ1EX8I",
  "id" : 640944499775143936,
  "created_at" : "2015-09-07 17:47:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Arieff",
      "screen_name" : "aarieff",
      "indices" : [ 3, 11 ],
      "id_str" : "24007000",
      "id" : 24007000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640941097070542848",
  "text" : "RT @aarieff: Walking in San Francisco: The city may only cover 49 square miles but the pedestrian possibilities are endless.  http:\/\/t.co\/y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/yheCRdHxhM",
        "expanded_url" : "http:\/\/www.spur.org\/publications\/article\/2015-09-06\/walking-san-francisco",
        "display_url" : "spur.org\/publications\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640936466147733505",
    "text" : "Walking in San Francisco: The city may only cover 49 square miles but the pedestrian possibilities are endless.  http:\/\/t.co\/yheCRdHxhM",
    "id" : 640936466147733505,
    "created_at" : "2015-09-07 17:15:36 +0000",
    "user" : {
      "name" : "Allison Arieff",
      "screen_name" : "aarieff",
      "protected" : false,
      "id_str" : "24007000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1508685168\/AllisonbyTylerKohlhoffCROP_normal.jpg",
      "id" : 24007000,
      "verified" : true
    }
  },
  "id" : 640941097070542848,
  "created_at" : "2015-09-07 17:34:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 89, 98 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/KNLWFwgdZg",
      "expanded_url" : "https:\/\/twitter.com\/TylerJArbour\/status\/640929090141196288",
      "display_url" : "twitter.com\/TylerJArbour\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640934601226121216",
  "text" : "RT @PhdGeek: The 'straightness of science', or the perception that it is, is exactly why @LGBTSTEM was started. https:\/\/t.co\/KNLWFwgdZg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LGBTQ+ STEM",
        "screen_name" : "LGBTSTEM",
        "indices" : [ 76, 85 ],
        "id_str" : "2442015493",
        "id" : 2442015493
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/KNLWFwgdZg",
        "expanded_url" : "https:\/\/twitter.com\/TylerJArbour\/status\/640929090141196288",
        "display_url" : "twitter.com\/TylerJArbour\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640933901603631104",
    "text" : "The 'straightness of science', or the perception that it is, is exactly why @LGBTSTEM was started. https:\/\/t.co\/KNLWFwgdZg",
    "id" : 640933901603631104,
    "created_at" : "2015-09-07 17:05:24 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 640934601226121216,
  "created_at" : "2015-09-07 17:08:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 0, 14 ],
      "id_str" : "388503174",
      "id" : 388503174
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 43, 57 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640926277797437441",
  "geo" : { },
  "id_str" : "640931394458357760",
  "in_reply_to_user_id" : 388503174,
  "text" : "@juancommander thanks, I enjoyed yours and @Protohedgehog\u2019s as well! :-)",
  "id" : 640931394458357760,
  "in_reply_to_status_id" : 640926277797437441,
  "created_at" : "2015-09-07 16:55:27 +0000",
  "in_reply_to_screen_name" : "juancommander",
  "in_reply_to_user_id_str" : "388503174",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640917464872812545",
  "text" : "for the US crowd: check out my text about the success of being open. https:\/\/t.co\/tQZY3AlP4m",
  "id" : 640917464872812545,
  "created_at" : "2015-09-07 16:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daan Speth",
      "screen_name" : "daanspeth",
      "indices" : [ 0, 10 ],
      "id_str" : "1536778088",
      "id" : 1536778088
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 100, 107 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/tVKohX85nC",
      "expanded_url" : "http:\/\/allanino.me\/blog\/everything-else\/do-you-know-sci-hub\/",
      "display_url" : "allanino.me\/blog\/everythin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "640913580796284928",
  "geo" : { },
  "id_str" : "640914045449699329",
  "in_reply_to_user_id" : 1536778088,
  "text" : "@daanspeth in that case: welcome to the club! You might also want to look at http:\/\/t.co\/tVKohX85nC @McDawg recommended it to me. :)",
  "id" : 640914045449699329,
  "in_reply_to_status_id" : 640913580796284928,
  "created_at" : "2015-09-07 15:46:30 +0000",
  "in_reply_to_screen_name" : "daanspeth",
  "in_reply_to_user_id_str" : "1536778088",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daan Speth",
      "screen_name" : "daanspeth",
      "indices" : [ 0, 10 ],
      "id_str" : "1536778088",
      "id" : 1536778088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icanhazpdf",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640913060446793728",
  "geo" : { },
  "id_str" : "640913373434105857",
  "in_reply_to_user_id" : 1536778088,
  "text" : "@daanspeth standard #icanhazpdf workflow is to just delete the tweets afaik. :-)",
  "id" : 640913373434105857,
  "in_reply_to_status_id" : 640913060446793728,
  "created_at" : "2015-09-07 15:43:50 +0000",
  "in_reply_to_screen_name" : "daanspeth",
  "in_reply_to_user_id_str" : "1536778088",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaia \uD83C\uDF42\uD83C\uDF41",
      "screen_name" : "knsievert",
      "indices" : [ 3, 13 ],
      "id_str" : "61310080",
      "id" : 61310080
    }, {
      "name" : "Amer. Library Assn.",
      "screen_name" : "ALALibrary",
      "indices" : [ 16, 27 ],
      "id_str" : "21799699",
      "id" : 21799699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640900611710545921",
  "text" : "RT @knsievert: .@ALALibrary facebook page hacked, but dedicated librarian Steve Kemple adding call numbers to each post. http:\/\/t.co\/H7Q0AX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amer. Library Assn.",
        "screen_name" : "ALALibrary",
        "indices" : [ 1, 12 ],
        "id_str" : "21799699",
        "id" : 21799699
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/knsievert\/status\/640573547186925568\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/H7Q0AXK23B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COPGPyDUwAAnvZK.png",
        "id_str" : "640573546452795392",
        "id" : 640573546452795392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COPGPyDUwAAnvZK.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1130,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 469
        }, {
          "h" : 1130,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 1130,
          "resize" : "fit",
          "w" : 780
        } ],
        "display_url" : "pic.twitter.com\/H7Q0AXK23B"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640573547186925568",
    "text" : ".@ALALibrary facebook page hacked, but dedicated librarian Steve Kemple adding call numbers to each post. http:\/\/t.co\/H7Q0AXK23B",
    "id" : 640573547186925568,
    "created_at" : "2015-09-06 17:13:29 +0000",
    "user" : {
      "name" : "Kaia \uD83C\uDF42\uD83C\uDF41",
      "screen_name" : "knsievert",
      "protected" : false,
      "id_str" : "61310080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720765822952538114\/1hZM1REm_normal.jpg",
      "id" : 61310080,
      "verified" : false
    }
  },
  "id" : 640900611710545921,
  "created_at" : "2015-09-07 14:53:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/mlf4ioLLre",
      "expanded_url" : "http:\/\/img1.wikia.nocookie.net\/__cb20120416002311\/thehungergames\/images\/2\/2b\/Spinning_daschund.gif",
      "display_url" : "img1.wikia.nocookie.net\/__cb2012041600\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640888046813102080",
  "text" : "work status: http:\/\/t.co\/mlf4ioLLre",
  "id" : 640888046813102080,
  "created_at" : "2015-09-07 14:03:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640877980370268160",
  "text" : "@malech \uD83C\uDF89",
  "id" : 640877980370268160,
  "created_at" : "2015-09-07 13:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Bremges",
      "screen_name" : "abremges",
      "indices" : [ 0, 9 ],
      "id_str" : "407725357",
      "id" : 407725357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640857009437474816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231357282564, 8.627541889541883 ]
  },
  "id_str" : "640857229592293376",
  "in_reply_to_user_id" : 407725357,
  "text" : "@abremges thanks!",
  "id" : 640857229592293376,
  "in_reply_to_status_id" : 640857009437474816,
  "created_at" : "2015-09-07 12:00:44 +0000",
  "in_reply_to_screen_name" : "abremges",
  "in_reply_to_user_id_str" : "407725357",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640849251711483904",
  "text" : "Recommendations for a good review\/best practice piece on doing shotgun metagenomics?",
  "id" : 640849251711483904,
  "created_at" : "2015-09-07 11:29:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640846070847827968",
  "geo" : { },
  "id_str" : "640847305122443264",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch danke, wenn man dem Vergleich schon nicht mehr entgehen kann, dann kann man ihn zumindest claimen ;)",
  "id" : 640847305122443264,
  "in_reply_to_status_id" : 640846070847827968,
  "created_at" : "2015-09-07 11:21:18 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640831786956816384",
  "geo" : { },
  "id_str" : "640834308316483584",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander thanks ;)",
  "id" : 640834308316483584,
  "in_reply_to_status_id" : 640831786956816384,
  "created_at" : "2015-09-07 10:29:39 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/HdMYtwiq59",
      "expanded_url" : "http:\/\/i.imgur.com\/2DIRrKe.gif",
      "display_url" : "i.imgur.com\/2DIRrKe.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "640826115616047104",
  "text" : "Over-caffeinated http:\/\/t.co\/HdMYtwiq59",
  "id" : 640826115616047104,
  "created_at" : "2015-09-07 09:57:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640815528244826112",
  "geo" : { },
  "id_str" : "640816837920428033",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks \uD83D\uDE4F",
  "id" : 640816837920428033,
  "in_reply_to_status_id" : 640815528244826112,
  "created_at" : "2015-09-07 09:20:14 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/tQZY3AlP4m",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/2368-you-don-t-get-to-2000-open-data-sets-without-making-a-few-friends-or-how-i-got-to-be-called-the-mark-zuckerberg-of-open-source-genetics",
      "display_url" : "thewinnower.com\/papers\/2368-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640813543235960832",
  "text" : "a not-so-humble brag about the success of open https:\/\/t.co\/tQZY3AlP4m",
  "id" : 640813543235960832,
  "created_at" : "2015-09-07 09:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 122, 132 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/F61wCXVL2H",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/pOrNtology",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640782427284205568",
  "text" : "Funny, after being dormant for ~3 years, there\u2019s now some interest in the pOrNtology stuff again. https:\/\/t.co\/F61wCXVL2H @eltonjohn",
  "id" : 640782427284205568,
  "created_at" : "2015-09-07 07:03:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/SmaqcAviTE",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/pdf\/10.1080\/00224499.2015.1015714",
      "display_url" : "tandfonline.com\/doi\/pdf\/10.108\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640644564483723264",
  "text" : "Surprise, there\u2019s no gaydar! And perpetuating the myth is hurtful: http:\/\/t.co\/SmaqcAviTE",
  "id" : 640644564483723264,
  "created_at" : "2015-09-06 21:55:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640641265542017024",
  "geo" : { },
  "id_str" : "640641450586320896",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj du bist schon zu lange in Mainz\u2026",
  "id" : 640641450586320896,
  "in_reply_to_status_id" : 640641265542017024,
  "created_at" : "2015-09-06 21:43:19 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/LNxCsLJpN2",
      "expanded_url" : "https:\/\/instagram.com\/p\/7Sxno1Bwrl\/",
      "display_url" : "instagram.com\/p\/7Sxno1Bwrl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "640539753121718272",
  "text" : "\u00ABWhat's the hashtag for our food?\u00BB https:\/\/t.co\/LNxCsLJpN2",
  "id" : 640539753121718272,
  "created_at" : "2015-09-06 14:59:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640531953456955392",
  "text" : "\u00ABWe are getting along great\u2026as long as we are asleep.\u00BB",
  "id" : 640531953456955392,
  "created_at" : "2015-09-06 14:28:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640282553056890880",
  "geo" : { },
  "id_str" : "640298683096006657",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat das n\u00E4chste Mal zur Begr\u00FC\u00DFung dann Gut wieder hier zu sein!",
  "id" : 640298683096006657,
  "in_reply_to_status_id" : 640282553056890880,
  "created_at" : "2015-09-05 23:01:16 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    }, {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 8, 17 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ydG97B3TDc",
      "expanded_url" : "https:\/\/github.com\/ubiome-opensource\/microbiome-data\/issues\/2",
      "display_url" : "github.com\/ubiome-opensou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "640248844068917249",
  "geo" : { },
  "id_str" : "640249377810968577",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome @infoecho reminds me, did you guys see https:\/\/t.co\/ydG97B3TDc ?",
  "id" : 640249377810968577,
  "in_reply_to_status_id" : 640248844068917249,
  "created_at" : "2015-09-05 19:45:21 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640239466288779264",
  "geo" : { },
  "id_str" : "640248755959267328",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho that sounds like fun too!",
  "id" : 640248755959267328,
  "in_reply_to_status_id" : 640239466288779264,
  "created_at" : "2015-09-05 19:42:53 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuven Lazarus",
      "screen_name" : "rlazarus",
      "indices" : [ 3, 12 ],
      "id_str" : "33474253",
      "id" : 33474253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640248305432305664",
  "text" : "RT @rlazarus: Would you like to learn more about Bloom filters?\n[ ] no\n[ ] probably",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640191284469178368",
    "text" : "Would you like to learn more about Bloom filters?\n[ ] no\n[ ] probably",
    "id" : 640191284469178368,
    "created_at" : "2015-09-05 15:54:31 +0000",
    "user" : {
      "name" : "Reuven Lazarus",
      "screen_name" : "rlazarus",
      "protected" : false,
      "id_str" : "33474253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/147980457\/n5728777_40383187_6081_normal.jpg",
      "id" : 33474253,
      "verified" : false
    }
  },
  "id" : 640248305432305664,
  "created_at" : "2015-09-05 19:41:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim van Biezen",
      "screen_name" : "KBiezen",
      "indices" : [ 0, 8 ],
      "id_str" : "1327081562",
      "id" : 1327081562
    }, {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 9, 16 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640245240629231616",
  "geo" : { },
  "id_str" : "640247363672666112",
  "in_reply_to_user_id" : 1327081562,
  "text" : "@KBiezen @uBiome another 21st century benefit: virtual high fives with other people air mailing poo! \uD83D\uDE4F",
  "id" : 640247363672666112,
  "in_reply_to_status_id" : 640245240629231616,
  "created_at" : "2015-09-05 19:37:21 +0000",
  "in_reply_to_screen_name" : "KBiezen",
  "in_reply_to_user_id_str" : "1327081562",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 102, 109 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640238625712664576",
  "text" : "Sending my poop across the Atlantic, all the way to San Francisco. I love living in the 21st century! @uBiome \u2708\uFE0F\uD83D\uDCA9\uD83D\uDD2C",
  "id" : 640238625712664576,
  "created_at" : "2015-09-05 19:02:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "indices" : [ 3, 9 ],
      "id_str" : "13889622",
      "id" : 13889622
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Carnage4Life\/status\/639924003138748416\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/5DUo8FtoFA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COF3fXCUYAArTam.png",
      "id_str" : "639924002706710528",
      "id" : 639924002706710528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COF3fXCUYAArTam.png",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/5DUo8FtoFA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640226736744099840",
  "text" : "RT @lukew: Rosetta Stone: http:\/\/t.co\/5DUo8FtoFA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Carnage4Life\/status\/639924003138748416\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/5DUo8FtoFA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COF3fXCUYAArTam.png",
        "id_str" : "639924002706710528",
        "id" : 639924002706710528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COF3fXCUYAArTam.png",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 543
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/5DUo8FtoFA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640020040989806592",
    "text" : "Rosetta Stone: http:\/\/t.co\/5DUo8FtoFA",
    "id" : 640020040989806592,
    "created_at" : "2015-09-05 04:34:03 +0000",
    "user" : {
      "name" : "Luke Wroblewski",
      "screen_name" : "lukew",
      "protected" : false,
      "id_str" : "13889622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477610446917103616\/_cjU3_ga_normal.png",
      "id" : 13889622,
      "verified" : false
    }
  },
  "id" : 640226736744099840,
  "created_at" : "2015-09-05 18:15:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640223971577827329",
  "text" : "@malech @Whitey_chan @dridde \uD83C\uDF6E\uD83C\uDF76",
  "id" : 640223971577827329,
  "created_at" : "2015-09-05 18:04:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640221573593608193",
  "text" : "@malech @Whitey_chan @dridde notfalls wird alles mit Skyr aufgef\u00FCllt :3",
  "id" : 640221573593608193,
  "created_at" : "2015-09-05 17:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640221312158404608",
  "text" : "@malech @Whitey_chan @dridde klappt :D",
  "id" : 640221312158404608,
  "created_at" : "2015-09-05 17:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640220642244198401",
  "text" : "@malech @Whitey_chan @dridde etwas mehr Sahne oder \u00E4quivalent w\u00E4re eventuell cool, hast du was da? :)",
  "id" : 640220642244198401,
  "created_at" : "2015-09-05 17:51:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640220550078537729",
  "text" : "@malech @Whitey_chan @dridde ok. Wird bei mir vielleicht eher 1430\/1500. ich hab jede Menge Sojaschnitzel, Tomaten und auch Platten.",
  "id" : 640220550078537729,
  "created_at" : "2015-09-05 17:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 8, 20 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 21, 28 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640216513727832064",
  "text" : "@malech @Whitey_chan @dridde ich bin da ganz offen, wann passt es dir? Und muss ich noch mal mehr Zutaten besorgen weil wir 4 Leute werden?\uD83D\uDE09",
  "id" : 640216513727832064,
  "created_at" : "2015-09-05 17:34:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 13, 20 ],
      "id_str" : "52021289",
      "id" : 52021289
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 21, 28 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640212042641764352",
  "geo" : { },
  "id_str" : "640213516788592640",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan @dridde @malech das kommt darauf an wie sehr ich mich am Sabich \u00FCberfuttere was es jetzt gibt. \uD83C\uDF46\uD83C\uDF45",
  "id" : 640213516788592640,
  "in_reply_to_status_id" : 640212042641764352,
  "created_at" : "2015-09-05 17:22:51 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 0, 7 ],
      "id_str" : "52021289",
      "id" : 52021289
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 8, 15 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640207117027250176",
  "geo" : { },
  "id_str" : "640207392635002880",
  "in_reply_to_user_id" : 52021289,
  "text" : "@dridde @malech vegetarische Lasagne. \uD83C\uDF5D",
  "id" : 640207392635002880,
  "in_reply_to_status_id" : 640207117027250176,
  "created_at" : "2015-09-05 16:58:31 +0000",
  "in_reply_to_screen_name" : "dridde",
  "in_reply_to_user_id_str" : "52021289",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640202163722035201",
  "text" : "@malech also mir w\u00FCrde ein halbes reichen ;)",
  "id" : 640202163722035201,
  "created_at" : "2015-09-05 16:37:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/45YomfmfEM",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/04\/developers-mourn-a-canceled-pr.html",
      "display_url" : "boingboing.net\/2015\/09\/04\/dev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640136408074747905",
  "text" : "Developers mourn a canceled project in this short 'cave painting' about grief http:\/\/t.co\/45YomfmfEM",
  "id" : 640136408074747905,
  "created_at" : "2015-09-05 12:16:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9BkOLDLNML",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/04\/adorable-husky-puppy-cant-ho.html",
      "display_url" : "boingboing.net\/2015\/09\/04\/ado\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640133798265495552",
  "text" : "you need to practise everything. http:\/\/t.co\/9BkOLDLNML",
  "id" : 640133798265495552,
  "created_at" : "2015-09-05 12:06:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/ehbTYz5xwY",
      "expanded_url" : "https:\/\/instagram.com\/p\/7P3hREBwvr\/",
      "display_url" : "instagram.com\/p\/7P3hREBwvr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "640130519687151616",
  "text" : "Ups and Downs https:\/\/t.co\/ehbTYz5xwY",
  "id" : 640130519687151616,
  "created_at" : "2015-09-05 11:53:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/HRNLlk7njS",
      "expanded_url" : "https:\/\/github.com\/getcahoots\/correspondence\/pull\/1",
      "display_url" : "github.com\/getcahoots\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640126316143116288",
  "text" : "how to get started contributing to open source projects for total beginners: https:\/\/t.co\/HRNLlk7njS",
  "id" : 640126316143116288,
  "created_at" : "2015-09-05 11:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 90, 106 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 107, 117 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "writing",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "competition",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640083354319237120",
  "text" : "RT @glyn_dk: How did Open Science help you advance your career? #writing #competition \ncc @gedankenstuecke @bmpvieira \n\nhttps:\/\/t.co\/V3WW2R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 77, 93 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Bruno Vieira",
        "screen_name" : "bmpvieira",
        "indices" : [ 94, 104 ],
        "id_str" : "55388565",
        "id" : 55388565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "writing",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "competition",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/V3WW2R9Ehl",
        "expanded_url" : "https:\/\/thewinnower.com\/posts\/contest-and-showcase-the-rewards-of-being-open",
        "display_url" : "thewinnower.com\/posts\/contest-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640069003164168192",
    "text" : "How did Open Science help you advance your career? #writing #competition \ncc @gedankenstuecke @bmpvieira \n\nhttps:\/\/t.co\/V3WW2R9Ehl",
    "id" : 640069003164168192,
    "created_at" : "2015-09-05 07:48:36 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 640083354319237120,
  "created_at" : "2015-09-05 08:45:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 9, 19 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640069003164168192",
  "geo" : { },
  "id_str" : "640072929628323840",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @bmpvieira thanks, looks like we will enter in a friendly competition? ;)",
  "id" : 640072929628323840,
  "in_reply_to_status_id" : 640069003164168192,
  "created_at" : "2015-09-05 08:04:13 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Hw23BQewoF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pWS8Mg-JWSg",
      "display_url" : "youtube.com\/watch?v=pWS8Mg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "639908049239547904",
  "geo" : { },
  "id_str" : "639908714485575680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich ich dachte das geht so? https:\/\/t.co\/Hw23BQewoF",
  "id" : 639908714485575680,
  "in_reply_to_status_id" : 639908049239547904,
  "created_at" : "2015-09-04 21:11:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639897837472481280",
  "geo" : { },
  "id_str" : "639907819966349313",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot komisch wie du meinen Nachnamen schreibst.",
  "id" : 639907819966349313,
  "in_reply_to_status_id" : 639897837472481280,
  "created_at" : "2015-09-04 21:08:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Hq57tsSQPr",
      "expanded_url" : "https:\/\/twitter.com\/ctitusbrown\/status\/639874101188792320",
      "display_url" : "twitter.com\/ctitusbrown\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639897760116903936",
  "text" : "How bioinformaticians keep themselves busy and thrilled. https:\/\/t.co\/Hq57tsSQPr",
  "id" : 639897760116903936,
  "created_at" : "2015-09-04 20:28:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ciyer",
      "screen_name" : "ciyer",
      "indices" : [ 0, 6 ],
      "id_str" : "14533425",
      "id" : 14533425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639885283723489280",
  "geo" : { },
  "id_str" : "639896556573958144",
  "in_reply_to_user_id" : 14533425,
  "text" : "@ciyer cool viz!",
  "id" : 639896556573958144,
  "in_reply_to_status_id" : 639885283723489280,
  "created_at" : "2015-09-04 20:23:22 +0000",
  "in_reply_to_screen_name" : "ciyer",
  "in_reply_to_user_id_str" : "14533425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/uiAUrZKy9v",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/09\/03\/what-does-english-sound-like-t.html",
      "display_url" : "boingboing.net\/2015\/09\/03\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639894871822757888",
  "text" : "a lesson in how to sound like you speak english w\/o knowing a single word. http:\/\/t.co\/uiAUrZKy9v",
  "id" : 639894871822757888,
  "created_at" : "2015-09-04 20:16:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl on the Net",
      "screen_name" : "girlonthenet",
      "indices" : [ 3, 16 ],
      "id_str" : "137466551",
      "id" : 137466551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639892576942878720",
  "text" : "RT @girlonthenet: Weirdly, there's a strong correlation between people who tell me the UK is 'full' and people who tell me I should have ha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639710330147471360",
    "text" : "Weirdly, there's a strong correlation between people who tell me the UK is 'full' and people who tell me I should have had kids.",
    "id" : 639710330147471360,
    "created_at" : "2015-09-04 08:03:22 +0000",
    "user" : {
      "name" : "Girl on the Net",
      "screen_name" : "girlonthenet",
      "protected" : false,
      "id_str" : "137466551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745636327367020545\/DlrDZnd5_normal.jpg",
      "id" : 137466551,
      "verified" : false
    }
  },
  "id" : 639892576942878720,
  "created_at" : "2015-09-04 20:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639853537338376192",
  "geo" : { },
  "id_str" : "639892315834830848",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe yes, puzzled why closed &amp; commercial \u2018alternatives\u2019 are seen as such. Especially by people who don\u2019t accept it for code etc.",
  "id" : 639892315834830848,
  "in_reply_to_status_id" : 639853537338376192,
  "created_at" : "2015-09-04 20:06:31 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "ORCID Organization",
      "screen_name" : "ORCID_Org",
      "indices" : [ 51, 61 ],
      "id_str" : "148815591",
      "id" : 148815591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639891756578942979",
  "text" : "RT @biocrusoe: It is disappointing to see the anti-@ORCID_Org rants. Global community open source projects are exactly the ones that need o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ORCID Organization",
        "screen_name" : "ORCID_Org",
        "indices" : [ 36, 46 ],
        "id_str" : "148815591",
        "id" : 148815591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639853537338376192",
    "text" : "It is disappointing to see the anti-@ORCID_Org rants. Global community open source projects are exactly the ones that need our support.",
    "id" : 639853537338376192,
    "created_at" : "2015-09-04 17:32:25 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 639891756578942979,
  "created_at" : "2015-09-04 20:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639843237121798144",
  "geo" : { },
  "id_str" : "639890284583723009",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer all the best!",
  "id" : 639890284583723009,
  "in_reply_to_status_id" : 639843237121798144,
  "created_at" : "2015-09-04 19:58:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639871832049500160",
  "text" : "Listening to a MD who talks about \u2018Western Medicine\u2019 and how great shamans are. Feels like I\u2019m back at the esotericism fair\u2026",
  "id" : 639871832049500160,
  "created_at" : "2015-09-04 18:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1Julia Evans\u26A1",
      "screen_name" : "b0rk",
      "indices" : [ 3, 8 ],
      "id_str" : "6603532",
      "id" : 6603532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639828325154820096",
  "text" : "RT @b0rk: how many badass OSS developer women\/minorities do I know? I want to convince you to apply to be paid to work on OSS. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/J7FzwGx2TN",
        "expanded_url" : "https:\/\/stripe.com\/blog\/open-source-retreat-2016",
        "display_url" : "stripe.com\/blog\/open-sour\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639764759458545665",
    "text" : "how many badass OSS developer women\/minorities do I know? I want to convince you to apply to be paid to work on OSS. https:\/\/t.co\/J7FzwGx2TN",
    "id" : 639764759458545665,
    "created_at" : "2015-09-04 11:39:39 +0000",
    "user" : {
      "name" : "\u26A1Julia Evans\u26A1",
      "screen_name" : "b0rk",
      "protected" : false,
      "id_str" : "6603532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846106819391115264\/iZAxk4qr_normal.jpg",
      "id" : 6603532,
      "verified" : false
    }
  },
  "id" : 639828325154820096,
  "created_at" : "2015-09-04 15:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerald Carter",
      "screen_name" : "gerrygcarter",
      "indices" : [ 3, 16 ],
      "id_str" : "2455687826",
      "id" : 2455687826
    }, {
      "name" : "PLOS ONE",
      "screen_name" : "PLOSONE",
      "indices" : [ 103, 111 ],
      "id_str" : "27596259",
      "id" : 27596259
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 112, 117 ],
      "id_str" : "12819112",
      "id" : 12819112
    }, {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 118, 131 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/knV1xe7owC",
      "expanded_url" : "http:\/\/wp.me\/p2lvIg-ri",
      "display_url" : "wp.me\/p2lvIg-ri"
    } ]
  },
  "geo" : { },
  "id_str" : "639827482707951616",
  "text" : "RT @gerrygcarter: PLOS One and the goals of science vs. the goals of scientists http:\/\/t.co\/knV1xe7owC @PLOSONE @PLOS @SamHarrisOrg #openac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS ONE",
        "screen_name" : "PLOSONE",
        "indices" : [ 85, 93 ],
        "id_str" : "27596259",
        "id" : 27596259
      }, {
        "name" : "PLOS",
        "screen_name" : "PLOS",
        "indices" : [ 94, 99 ],
        "id_str" : "12819112",
        "id" : 12819112
      }, {
        "name" : "Sam Harris",
        "screen_name" : "SamHarrisOrg",
        "indices" : [ 100, 113 ],
        "id_str" : "116994659",
        "id" : 116994659
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 114, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/knV1xe7owC",
        "expanded_url" : "http:\/\/wp.me\/p2lvIg-ri",
        "display_url" : "wp.me\/p2lvIg-ri"
      } ]
    },
    "geo" : { },
    "id_str" : "631589077905608705",
    "text" : "PLOS One and the goals of science vs. the goals of scientists http:\/\/t.co\/knV1xe7owC @PLOSONE @PLOS @SamHarrisOrg #openaccess",
    "id" : 631589077905608705,
    "created_at" : "2015-08-12 22:12:25 +0000",
    "user" : {
      "name" : "Gerald Carter",
      "screen_name" : "gerrygcarter",
      "protected" : false,
      "id_str" : "2455687826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713503670835359745\/fsKfteqp_normal.jpg",
      "id" : 2455687826,
      "verified" : false
    }
  },
  "id" : 639827482707951616,
  "created_at" : "2015-09-04 15:48:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin R. Gollery",
      "screen_name" : "mgollery",
      "indices" : [ 0, 9 ],
      "id_str" : "214146874",
      "id" : 214146874
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 10, 24 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 25, 34 ],
      "id_str" : "29575969",
      "id" : 29575969
    }, {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 35, 49 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639817641708818432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11287485720877, 8.750312766413185 ]
  },
  "id_str" : "639823022841556992",
  "in_reply_to_user_id" : 214146874,
  "text" : "@mgollery @BioMickWatson @infoecho @lexnederbragt but somehow the performance suffers for genomes with high\/low G\/C content i guess ;)",
  "id" : 639823022841556992,
  "in_reply_to_status_id" : 639817641708818432,
  "created_at" : "2015-09-04 15:31:10 +0000",
  "in_reply_to_screen_name" : "mgollery",
  "in_reply_to_user_id_str" : "214146874",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639807545754816512",
  "geo" : { },
  "id_str" : "639808879489122309",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho we could rename after the merger: quaNNNNNNNNNNNNNNNNNNNtum-Pore.",
  "id" : 639808879489122309,
  "in_reply_to_status_id" : 639807545754816512,
  "created_at" : "2015-09-04 14:34:58 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    }, {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 10, 24 ],
      "id_str" : "48966898",
      "id" : 48966898
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 25, 39 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639806741278912512",
  "geo" : { },
  "id_str" : "639806921185337344",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho @lexnederbragt @BioMickWatson care to offer me some venture capital or interested in buying my just-founded company? :P",
  "id" : 639806921185337344,
  "in_reply_to_status_id" : 639806741278912512,
  "created_at" : "2015-09-04 14:27:11 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    }, {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 10, 24 ],
      "id_str" : "48966898",
      "id" : 48966898
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 25, 39 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639800381476765696",
  "geo" : { },
  "id_str" : "639806174502776832",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho @lexnederbragt @BioMickWatson let\u2019s put out 0.5mb reads, consisting of only Ns to account for yet undiscovered modifications. ;)",
  "id" : 639806174502776832,
  "in_reply_to_status_id" : 639800381476765696,
  "created_at" : "2015-09-04 14:24:13 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639792662891991040",
  "geo" : { },
  "id_str" : "639793954741993472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer bound to happen when bashing your head on the keyboard 54k words in.",
  "id" : 639793954741993472,
  "in_reply_to_status_id" : 639792662891991040,
  "created_at" : "2015-09-04 13:35:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639789099730141184",
  "geo" : { },
  "id_str" : "639790785777520640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer please tell me #20 was a typo in your name :D",
  "id" : 639790785777520640,
  "in_reply_to_status_id" : 639789099730141184,
  "created_at" : "2015-09-04 13:23:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/7s0yAtpbOp",
      "expanded_url" : "http:\/\/www.theatlantic.com\/international\/archive\/2015\/09\/syria-boy-refugee-photo-turkey\/403606\/",
      "display_url" : "theatlantic.com\/international\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639735074171297792",
  "text" : "RT @edyong209: \"My first reaction was despair. My second was: My son sleeps just like that.\" http:\/\/t.co\/7s0yAtpbOp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/7s0yAtpbOp",
        "expanded_url" : "http:\/\/www.theatlantic.com\/international\/archive\/2015\/09\/syria-boy-refugee-photo-turkey\/403606\/",
        "display_url" : "theatlantic.com\/international\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639734682083586048",
    "text" : "\"My first reaction was despair. My second was: My son sleeps just like that.\" http:\/\/t.co\/7s0yAtpbOp",
    "id" : 639734682083586048,
    "created_at" : "2015-09-04 09:40:08 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 639735074171297792,
  "created_at" : "2015-09-04 09:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 8, 17 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639731768329957376",
  "geo" : { },
  "id_str" : "639734099377291264",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Phaidr0s als h\u00E4tte es nicht schon gereicht das wir uns f\u00FCr Dawkins immer wieder sch\u00E4men m\u00FCssen :(",
  "id" : 639734099377291264,
  "in_reply_to_status_id" : 639731768329957376,
  "created_at" : "2015-09-04 09:37:49 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 3, 16 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Gq1rTNIazv",
      "expanded_url" : "https:\/\/medium.com\/@scientistpilot\/why-we-support-open-source-science-but-don-t-participate-in-it-60e42e3d8a88?source=tw-10de2a453240-1441357556299",
      "display_url" : "medium.com\/@scientistpilo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639726848381964288",
  "text" : "RT @MaliciaRogue: \u201CWhy We Support Open Source\/Science But Don\u2019t Participate In It\u201D https:\/\/t.co\/Gq1rTNIazv :O WTF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/Gq1rTNIazv",
        "expanded_url" : "https:\/\/medium.com\/@scientistpilot\/why-we-support-open-source-science-but-don-t-participate-in-it-60e42e3d8a88?source=tw-10de2a453240-1441357556299",
        "display_url" : "medium.com\/@scientistpilo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639726151930388480",
    "text" : "\u201CWhy We Support Open Source\/Science But Don\u2019t Participate In It\u201D https:\/\/t.co\/Gq1rTNIazv :O WTF",
    "id" : 639726151930388480,
    "created_at" : "2015-09-04 09:06:14 +0000",
    "user" : {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "protected" : false,
      "id_str" : "189118361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837584473843712000\/2Av32bxZ_normal.jpg",
      "id" : 189118361,
      "verified" : true
    }
  },
  "id" : 639726848381964288,
  "created_at" : "2015-09-04 09:09:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Gray",
      "screen_name" : "_AmyGray_",
      "indices" : [ 3, 13 ],
      "id_str" : "11741632",
      "id" : 11741632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639723526367350784",
  "text" : "RT @_AmyGray_: Just saw CEO refuse a meeting: \"I'm not going to give up reading to my kids just because they moved a meeting\". Dads, this i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639215204614574080",
    "text" : "Just saw CEO refuse a meeting: \"I'm not going to give up reading to my kids just because they moved a meeting\". Dads, this is how you do it.",
    "id" : 639215204614574080,
    "created_at" : "2015-09-02 23:15:55 +0000",
    "user" : {
      "name" : "Amy Gray",
      "screen_name" : "_AmyGray_",
      "protected" : false,
      "id_str" : "11741632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778044616482234368\/D5fFpNFj_normal.jpg",
      "id" : 11741632,
      "verified" : true
    }
  },
  "id" : 639723526367350784,
  "created_at" : "2015-09-04 08:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639723035046621184",
  "geo" : { },
  "id_str" : "639723437641101312",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s So in etwa, Gro\u00DFteil der Publikationen sind pop. sci. \u00FCber Creationism\/Evolution. \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 639723437641101312,
  "in_reply_to_status_id" : 639723035046621184,
  "created_at" : "2015-09-04 08:55:27 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639721880988073984",
  "geo" : { },
  "id_str" : "639722798076821504",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Wenn ich mir die Publikationsliste so anschaue ist er in den letzten Jahren nicht mehr durch seine wiss. Arbeit aufgefallen\u2026",
  "id" : 639722798076821504,
  "in_reply_to_status_id" : 639721880988073984,
  "created_at" : "2015-09-04 08:52:55 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639720818617004032",
  "geo" : { },
  "id_str" : "639721323854491648",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s was halt so passiert wenn man sich f\u00FCr den deutschen Dawkins h\u00E4lt\u2026 m(",
  "id" : 639721323854491648,
  "in_reply_to_status_id" : 639720818617004032,
  "created_at" : "2015-09-04 08:47:03 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6mKG3PnJ2E",
      "expanded_url" : "http:\/\/i3.kym-cdn.com\/photos\/images\/newsfeed\/000\/108\/655\/135k.jpg",
      "display_url" : "i3.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "639708111419363328",
  "geo" : { },
  "id_str" : "639715533684928512",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Ich wusste der Gesichtsausdruck kam mir bekannt vor. http:\/\/t.co\/6mKG3PnJ2E",
  "id" : 639715533684928512,
  "in_reply_to_status_id" : 639708111419363328,
  "created_at" : "2015-09-04 08:24:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 3, 18 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/fDLIIFodNV",
      "expanded_url" : "http:\/\/bit.ly\/1QaAiBM",
      "display_url" : "bit.ly\/1QaAiBM"
    } ]
  },
  "geo" : { },
  "id_str" : "639712772834635778",
  "text" : "RT @ConversationUK: While 38% of people think they have a food allergy, the real figure is closer to around 1% http:\/\/t.co\/fDLIIFodNV http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ConversationUK\/status\/639461607035113473\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/16wCQ3Md2w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN-cJEuWsAArNf-.png",
        "id_str" : "639401351810822144",
        "id" : 639401351810822144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN-cJEuWsAArNf-.png",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 821
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 821
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 821
        } ],
        "display_url" : "pic.twitter.com\/16wCQ3Md2w"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/fDLIIFodNV",
        "expanded_url" : "http:\/\/bit.ly\/1QaAiBM",
        "display_url" : "bit.ly\/1QaAiBM"
      } ]
    },
    "geo" : { },
    "id_str" : "639461607035113473",
    "text" : "While 38% of people think they have a food allergy, the real figure is closer to around 1% http:\/\/t.co\/fDLIIFodNV http:\/\/t.co\/16wCQ3Md2w",
    "id" : 639461607035113473,
    "created_at" : "2015-09-03 15:35:02 +0000",
    "user" : {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "protected" : false,
      "id_str" : "1241258612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875640793590976512\/IH4VD6Vm_normal.jpg",
      "id" : 1241258612,
      "verified" : true
    }
  },
  "id" : 639712772834635778,
  "created_at" : "2015-09-04 08:13:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/qi5iGY5mtb",
      "expanded_url" : "https:\/\/medium.com\/navigating-the-sea-of-singledom\/on-hanging-out-cool-girls-and-being-clingy-f81e519c717a",
      "display_url" : "medium.com\/navigating-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639701198526935040",
  "text" : "On Hanging Out, Cool Girls, and Being Clingy https:\/\/t.co\/qi5iGY5mtb",
  "id" : 639701198526935040,
  "created_at" : "2015-09-04 07:27:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639700205907128320",
  "text" : "\u00ABWhat do you think, how many polyamorous people are there in Iceland?\u00BB \u2013 \u00ABI guess\u2026maybe two?\u00BB",
  "id" : 639700205907128320,
  "created_at" : "2015-09-04 07:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/pGTIFzgcMg",
      "expanded_url" : "http:\/\/www.rosincerate.com\/2015\/09\/fuels-and-fungi-love-story.html",
      "display_url" : "rosincerate.com\/2015\/09\/fuels-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639547598148345856",
  "text" : "Fuels and fungi: A love story http:\/\/t.co\/pGTIFzgcMg",
  "id" : 639547598148345856,
  "created_at" : "2015-09-03 21:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 87, 100 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/kzROWV7pvG",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/09\/02\/025999?rss=1",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639547099755974657",
  "text" : "Privacy-Preserving Microbiome Analysis Using Secure Computation http:\/\/t.co\/kzROWV7pvG @PhilippBayer",
  "id" : 639547099755974657,
  "created_at" : "2015-09-03 21:14:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 15, 20 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639533053426008064",
  "geo" : { },
  "id_str" : "639543375608332288",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @li5a awesome, thanks. :-) I think you should talk DIYBio if you get the chance!",
  "id" : 639543375608332288,
  "in_reply_to_status_id" : 639533053426008064,
  "created_at" : "2015-09-03 20:59:57 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639521324587687936",
  "geo" : { },
  "id_str" : "639542051139395584",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick \u201Clooks and smells like ~80% functional to me!\u201D",
  "id" : 639542051139395584,
  "in_reply_to_status_id" : 639521324587687936,
  "created_at" : "2015-09-03 20:54:41 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639495975837548544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11095116551618, 8.757733717307696 ]
  },
  "id_str" : "639503502478286848",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima all of it.",
  "id" : 639503502478286848,
  "in_reply_to_status_id" : 639495975837548544,
  "created_at" : "2015-09-03 18:21:31 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "indices" : [ 3, 16 ],
      "id_str" : "9550352",
      "id" : 9550352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rachelnabors\/status\/639105595178622978\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/1CATpIb8M0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6PJxBXAAA1_0z.jpg",
      "id_str" : "639105595073822720",
      "id" : 639105595073822720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6PJxBXAAA1_0z.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/1CATpIb8M0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/pviZZg9XhH",
      "expanded_url" : "http:\/\/buff.ly\/1KqFnH8",
      "display_url" : "buff.ly\/1KqFnH8"
    } ]
  },
  "geo" : { },
  "id_str" : "639487972254072832",
  "text" : "RT @rachelnabors: ICYMI: I said no to a conference without a Code of Conduct. Here's why: http:\/\/t.co\/pviZZg9XhH http:\/\/t.co\/1CATpIb8M0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rachelnabors\/status\/639105595178622978\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/1CATpIb8M0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN6PJxBXAAA1_0z.jpg",
        "id_str" : "639105595073822720",
        "id" : 639105595073822720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN6PJxBXAAA1_0z.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/1CATpIb8M0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/pviZZg9XhH",
        "expanded_url" : "http:\/\/buff.ly\/1KqFnH8",
        "display_url" : "buff.ly\/1KqFnH8"
      } ]
    },
    "geo" : { },
    "id_str" : "639105595178622978",
    "text" : "ICYMI: I said no to a conference without a Code of Conduct. Here's why: http:\/\/t.co\/pviZZg9XhH http:\/\/t.co\/1CATpIb8M0",
    "id" : 639105595178622978,
    "created_at" : "2015-09-02 16:00:22 +0000",
    "user" : {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "protected" : false,
      "id_str" : "9550352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/899039208693669888\/ibha3cYB_normal.jpg",
      "id" : 9550352,
      "verified" : false
    }
  },
  "id" : 639487972254072832,
  "created_at" : "2015-09-03 17:19:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639443480843055104",
  "geo" : { },
  "id_str" : "639446362090815488",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThe process of \u2018re-lichenization\u2019 has been studied, and what might be viewed as quite scandalous interactions have come to light.\u00BB",
  "id" : 639446362090815488,
  "in_reply_to_status_id" : 639443480843055104,
  "created_at" : "2015-09-03 14:34:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/t8CW0zT8XE",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0269915X05002016",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639443480843055104",
  "text" : "Sure you can give your paper the title \u2018Sex in the extremes\u2019, but googling for it might become a bit of a pain. http:\/\/t.co\/t8CW0zT8XE",
  "id" : 639443480843055104,
  "created_at" : "2015-09-03 14:23:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 12, 26 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639441150345089024",
  "geo" : { },
  "id_str" : "639442517109403650",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a maybe @beaugunderson can help out with recommendations. :)",
  "id" : 639442517109403650,
  "in_reply_to_status_id" : 639441150345089024,
  "created_at" : "2015-09-03 14:19:11 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/PobUZ91pQ0",
      "expanded_url" : "https:\/\/youtu.be\/NQ-8IuUkJJc?t=1m2s",
      "display_url" : "youtu.be\/NQ-8IuUkJJc?t=\u2026"
    }, {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/muTrQfTjQ8",
      "expanded_url" : "https:\/\/twitter.com\/whereisdaz\/status\/639300554120757249",
      "display_url" : "twitter.com\/whereisdaz\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639425667210330112",
  "text" : "\u2026 and for kids who can\u2019t survive good\u2026 https:\/\/t.co\/PobUZ91pQ0 https:\/\/t.co\/muTrQfTjQ8",
  "id" : 639425667210330112,
  "created_at" : "2015-09-03 13:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 9, 19 ],
      "id_str" : "12192142",
      "id" : 12192142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639419143725404160",
  "geo" : { },
  "id_str" : "639419433874771968",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @hdsjulian lifehacker!",
  "id" : 639419433874771968,
  "in_reply_to_status_id" : 639419143725404160,
  "created_at" : "2015-09-03 12:47:27 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639418898266386434",
  "geo" : { },
  "id_str" : "639419137115181056",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy also i think it drastically underestimates cd in my case, as for many cases I\u2019m using z instead.",
  "id" : 639419137115181056,
  "in_reply_to_status_id" : 639418898266386434,
  "created_at" : "2015-09-03 12:46:16 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639418434602835968",
  "geo" : { },
  "id_str" : "639418621341642752",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy i frequently check from different machines\/offices\/etc.",
  "id" : 639418621341642752,
  "in_reply_to_status_id" : 639418434602835968,
  "created_at" : "2015-09-03 12:44:13 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 85, 101 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/639412156073684992\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/pbIo5Ipyv3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN-l96MWsAAzoFR.png",
      "id_str" : "639412155121577984",
      "id" : 639412155121577984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN-l96MWsAAzoFR.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/pbIo5Ipyv3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639409075831336960",
  "geo" : { },
  "id_str" : "639412156073684992",
  "in_reply_to_user_id" : 14286491,
  "text" : "Apparently my own bash\/zsh history doesn\u2019t follow Zipf as nicely. Here\u2019s the top 15. @raspberryperson http:\/\/t.co\/pbIo5Ipyv3",
  "id" : 639412156073684992,
  "in_reply_to_status_id" : 639409075831336960,
  "created_at" : "2015-09-03 12:18:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639410444797612032",
  "geo" : { },
  "id_str" : "639410609356980228",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson das habe ich auch gemacht, nur das base command, ohne Argumente oder angeh\u00E4ngte pipes.",
  "id" : 639410609356980228,
  "in_reply_to_status_id" : 639410444797612032,
  "created_at" : "2015-09-03 12:12:23 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639409890763612160",
  "geo" : { },
  "id_str" : "639410175997292545",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson in meinem Fall awk|sort|uniq, aber whatever converts your strings. :-)",
  "id" : 639410175997292545,
  "in_reply_to_status_id" : 639409890763612160,
  "created_at" : "2015-09-03 12:10:40 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639409532695904256",
  "geo" : { },
  "id_str" : "639409759989420033",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson bin gerade dabei :D",
  "id" : 639409759989420033,
  "in_reply_to_status_id" : 639409532695904256,
  "created_at" : "2015-09-03 12:09:01 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/639409075831336960\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/AKTgnkwGtL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN-jKnBWoAAKcWQ.png",
      "id_str" : "639409074778578944",
      "id" : 639409074778578944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN-jKnBWoAAKcWQ.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/AKTgnkwGtL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/KgF0JSECih",
      "expanded_url" : "http:\/\/www.webminal.org\/fulc\/",
      "display_url" : "webminal.org\/fulc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "639409075831336960",
  "text" : "the most frequently used bash commands (according to http:\/\/t.co\/KgF0JSECih) follow Zipf pretty closely. http:\/\/t.co\/AKTgnkwGtL",
  "id" : 639409075831336960,
  "created_at" : "2015-09-03 12:06:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Business Insider",
      "screen_name" : "businessinsider",
      "indices" : [ 3, 19 ],
      "id_str" : "20562637",
      "id" : 20562637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/u6b4ldoExk",
      "expanded_url" : "http:\/\/read.bi\/1KsO1Fk",
      "display_url" : "read.bi\/1KsO1Fk"
    } ]
  },
  "geo" : { },
  "id_str" : "639404327317176320",
  "text" : "RT @businessinsider: There is now a 'Trip Advisor' for migrants so they can avoid falling into slavery http:\/\/t.co\/u6b4ldoExk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.businessinsider.com\" rel=\"nofollow\"\u003EBusiness Insider\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/u6b4ldoExk",
        "expanded_url" : "http:\/\/read.bi\/1KsO1Fk",
        "display_url" : "read.bi\/1KsO1Fk"
      } ]
    },
    "geo" : { },
    "id_str" : "639280657076719616",
    "text" : "There is now a 'Trip Advisor' for migrants so they can avoid falling into slavery http:\/\/t.co\/u6b4ldoExk",
    "id" : 639280657076719616,
    "created_at" : "2015-09-03 03:36:00 +0000",
    "user" : {
      "name" : "Business Insider",
      "screen_name" : "businessinsider",
      "protected" : false,
      "id_str" : "20562637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887662979902304257\/azSzxYkB_normal.jpg",
      "id" : 20562637,
      "verified" : true
    }
  },
  "id" : 639404327317176320,
  "created_at" : "2015-09-03 11:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 102, 111 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aJ30IwyohQ",
      "expanded_url" : "http:\/\/sciencebusiness.net\/news\/77178\/%E2%80%9CI%E2%80%99m-confident-of-a-mandatory-text-and-data-mining-deal-for-researchers%E2%80%9D",
      "display_url" : "sciencebusiness.net\/news\/77178\/%E2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639388059029643264",
  "text" : "why science is in a desperate need for liberal regulations of text &amp; data mining, as explained by @Senficon http:\/\/t.co\/aJ30IwyohQ",
  "id" : 639388059029643264,
  "created_at" : "2015-09-03 10:42:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639379527966294017",
  "geo" : { },
  "id_str" : "639379930128719872",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so viele Wasserf\u00E4lle und Gletscherspalten ;)",
  "id" : 639379930128719872,
  "in_reply_to_status_id" : 639379527966294017,
  "created_at" : "2015-09-03 10:10:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 129, 138 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/O2rU1t0ibL",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0133505",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639371785096556544",
  "text" : "You Are What You Tweet: Connecting the Geographic Variation in America\u2019s Obesity Rate to Twitter Content http:\/\/t.co\/O2rU1t0ibL \/@eramirez",
  "id" : 639371785096556544,
  "created_at" : "2015-09-03 09:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/639350243134414848\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/C0MXR8G5XZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN9tp-4W8AALg9k.jpg",
      "id_str" : "639350240131346432",
      "id" : 639350240131346432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN9tp-4W8AALg9k.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/C0MXR8G5XZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639349714765389824",
  "geo" : { },
  "id_str" : "639350243134414848",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin fully agree. http:\/\/t.co\/C0MXR8G5XZ",
  "id" : 639350243134414848,
  "in_reply_to_status_id" : 639349714765389824,
  "created_at" : "2015-09-03 08:12:31 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639350241716760576",
  "text" : "RT @kaiblin: @gedankenstuecke not using version control for code is like not using a lab book for bench work. latter is illegal, former sho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639349120961019904",
    "geo" : { },
    "id_str" : "639349714765389824",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke not using version control for code is like not using a lab book for bench work. latter is illegal, former should be.",
    "id" : 639349714765389824,
    "in_reply_to_status_id" : 639349120961019904,
    "created_at" : "2015-09-03 08:10:25 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 639350241716760576,
  "created_at" : "2015-09-03 08:12:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639348930321514496",
  "geo" : { },
  "id_str" : "639349120961019904",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin i\u2019m actually thinking of going the non-collaboration route from now on.",
  "id" : 639349120961019904,
  "in_reply_to_status_id" : 639348930321514496,
  "created_at" : "2015-09-03 08:08:03 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639347703282028544",
  "geo" : { },
  "id_str" : "639347965350539264",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin i\u2019ve done that as well, it really is a pain. You end up merging mycoolscript_v3_name_final.py into your VCS\u2026",
  "id" : 639347965350539264,
  "in_reply_to_status_id" : 639347703282028544,
  "created_at" : "2015-09-03 08:03:28 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fBKZCyMQrK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ITwD2bCdDhw",
      "display_url" : "youtube.com\/watch?v=ITwD2b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639345944992051200",
  "text" : "\u00ABI want whiskey when I'm sick and a man when I'm well. But it's nice to have them both sometimes\u2026\u00BB https:\/\/t.co\/fBKZCyMQrK",
  "id" : 639345944992051200,
  "created_at" : "2015-09-03 07:55:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Lucianovic \uD83C\uDF27\uFE0F\uD83C\uDF42\uD83C\uDF27\uFE0F\uD83C\uDF41\uD83C\uDF27\uFE0F",
      "screen_name" : "grubreport",
      "indices" : [ 3, 14 ],
      "id_str" : "15678388",
      "id" : 15678388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5piaECfgxI",
      "expanded_url" : "https:\/\/twitter.com\/JenLucPiquant\/status\/639271333138837508",
      "display_url" : "twitter.com\/JenLucPiquant\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639344069194448896",
  "text" : "RT @grubreport: You don't just walk into Mordor without 1,780,214.59 calories. https:\/\/t.co\/5piaECfgxI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/5piaECfgxI",
        "expanded_url" : "https:\/\/twitter.com\/JenLucPiquant\/status\/639271333138837508",
        "display_url" : "twitter.com\/JenLucPiquant\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639271946069262336",
    "text" : "You don't just walk into Mordor without 1,780,214.59 calories. https:\/\/t.co\/5piaECfgxI",
    "id" : 639271946069262336,
    "created_at" : "2015-09-03 03:01:23 +0000",
    "user" : {
      "name" : "Stephanie Lucianovic \uD83C\uDF27\uFE0F\uD83C\uDF42\uD83C\uDF27\uFE0F\uD83C\uDF41\uD83C\uDF27\uFE0F",
      "screen_name" : "grubreport",
      "protected" : false,
      "id_str" : "15678388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887045216632397828\/EhjrjqC6_normal.jpg",
      "id" : 15678388,
      "verified" : false
    }
  },
  "id" : 639344069194448896,
  "created_at" : "2015-09-03 07:47:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639166194608664576",
  "geo" : { },
  "id_str" : "639339603846131713",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Congrats!",
  "id" : 639339603846131713,
  "in_reply_to_status_id" : 639166194608664576,
  "created_at" : "2015-09-03 07:30:14 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "indices" : [ 0, 13 ],
      "id_str" : "128275616",
      "id" : 128275616
    }, {
      "name" : "Bruno Grande",
      "screen_name" : "grandebruno",
      "indices" : [ 14, 26 ],
      "id_str" : "203557358",
      "id" : 203557358
    }, {
      "name" : "A.D. Letaw",
      "screen_name" : "adletaw",
      "indices" : [ 38, 46 ],
      "id_str" : "2750155988",
      "id" : 2750155988
    }, {
      "name" : "Jenny Bryan",
      "screen_name" : "JennyBryan",
      "indices" : [ 47, 58 ],
      "id_str" : "2167059661",
      "id" : 2167059661
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 59, 67 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639210787664478208",
  "geo" : { },
  "id_str" : "639335949114191872",
  "in_reply_to_user_id" : 128275616,
  "text" : "@polesasunder @grandebruno @lmguzmanu @adletaw @JennyBryan @kaiblin thanks for all your recommendations. :)",
  "id" : 639335949114191872,
  "in_reply_to_status_id" : 639210787664478208,
  "created_at" : "2015-09-03 07:15:43 +0000",
  "in_reply_to_screen_name" : "polesasunder",
  "in_reply_to_user_id_str" : "128275616",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "indices" : [ 3, 16 ],
      "id_str" : "128275616",
      "id" : 128275616
    }, {
      "name" : "Bruno Grande",
      "screen_name" : "grandebruno",
      "indices" : [ 18, 30 ],
      "id_str" : "203557358",
      "id" : 203557358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639335797079035904",
  "text" : "RT @polesasunder: @grandebruno you just wait till the horse is thirsty then drink lotsa cold water right in front of her.  or s\/t @JennyBry\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruno Grande",
        "screen_name" : "grandebruno",
        "indices" : [ 0, 12 ],
        "id_str" : "203557358",
        "id" : 203557358
      }, {
        "name" : "Jenny Bryan",
        "screen_name" : "JennyBryan",
        "indices" : [ 112, 123 ],
        "id_str" : "2167059661",
        "id" : 2167059661
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 124, 140 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639196969773109248",
    "geo" : { },
    "id_str" : "639211499571974145",
    "in_reply_to_user_id" : 203557358,
    "text" : "@grandebruno you just wait till the horse is thirsty then drink lotsa cold water right in front of her.  or s\/t @JennyBryan @gedankenstuecke",
    "id" : 639211499571974145,
    "in_reply_to_status_id" : 639196969773109248,
    "created_at" : "2015-09-02 23:01:12 +0000",
    "in_reply_to_screen_name" : "grandebruno",
    "in_reply_to_user_id_str" : "203557358",
    "user" : {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "protected" : false,
      "id_str" : "128275616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776147537308819456\/d-qJ5lJQ_normal.jpg",
      "id" : 128275616,
      "verified" : false
    }
  },
  "id" : 639335797079035904,
  "created_at" : "2015-09-03 07:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "indices" : [ 3, 16 ],
      "id_str" : "128275616",
      "id" : 128275616
    }, {
      "name" : "Bruno Grande",
      "screen_name" : "grandebruno",
      "indices" : [ 18, 30 ],
      "id_str" : "203557358",
      "id" : 203557358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639335781631422464",
  "text" : "RT @polesasunder: @grandebruno Also there were three of us: @lmguzmanu  and @adletaw and I convinced our PI; the rest followed. @gedankenst\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruno Grande",
        "screen_name" : "grandebruno",
        "indices" : [ 0, 12 ],
        "id_str" : "203557358",
        "id" : 203557358
      }, {
        "name" : "A.D. Letaw",
        "screen_name" : "adletaw",
        "indices" : [ 58, 66 ],
        "id_str" : "2750155988",
        "id" : 2750155988
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 110, 126 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639210534164934656",
    "geo" : { },
    "id_str" : "639210787664478208",
    "in_reply_to_user_id" : 128275616,
    "text" : "@grandebruno Also there were three of us: @lmguzmanu  and @adletaw and I convinced our PI; the rest followed. @gedankenstuecke",
    "id" : 639210787664478208,
    "in_reply_to_status_id" : 639210534164934656,
    "created_at" : "2015-09-02 22:58:22 +0000",
    "in_reply_to_screen_name" : "polesasunder",
    "in_reply_to_user_id_str" : "128275616",
    "user" : {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "protected" : false,
      "id_str" : "128275616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776147537308819456\/d-qJ5lJQ_normal.jpg",
      "id" : 128275616,
      "verified" : false
    }
  },
  "id" : 639335781631422464,
  "created_at" : "2015-09-03 07:15:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "indices" : [ 3, 16 ],
      "id_str" : "128275616",
      "id" : 128275616
    }, {
      "name" : "Bruno Grande",
      "screen_name" : "grandebruno",
      "indices" : [ 18, 30 ],
      "id_str" : "203557358",
      "id" : 203557358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639335760131424256",
  "text" : "RT @polesasunder: @grandebruno Then there was a project large enough that none of us could do it alone. Suddenly everyone is branching 2\/2 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruno Grande",
        "screen_name" : "grandebruno",
        "indices" : [ 0, 12 ],
        "id_str" : "203557358",
        "id" : 203557358
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 121, 137 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639210282204708864",
    "geo" : { },
    "id_str" : "639210534164934656",
    "in_reply_to_user_id" : 128275616,
    "text" : "@grandebruno Then there was a project large enough that none of us could do it alone. Suddenly everyone is branching 2\/2 @gedankenstuecke",
    "id" : 639210534164934656,
    "in_reply_to_status_id" : 639210282204708864,
    "created_at" : "2015-09-02 22:57:21 +0000",
    "in_reply_to_screen_name" : "polesasunder",
    "in_reply_to_user_id_str" : "128275616",
    "user" : {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "protected" : false,
      "id_str" : "128275616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776147537308819456\/d-qJ5lJQ_normal.jpg",
      "id" : 128275616,
      "verified" : false
    }
  },
  "id" : 639335760131424256,
  "created_at" : "2015-09-03 07:14:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "indices" : [ 3, 16 ],
      "id_str" : "128275616",
      "id" : 128275616
    }, {
      "name" : "Bruno Grande",
      "screen_name" : "grandebruno",
      "indices" : [ 18, 30 ],
      "id_str" : "203557358",
      "id" : 203557358
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 119, 135 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639335745363296256",
  "text" : "RT @polesasunder: @grandebruno I found that all the enthusiasm, papers and slideshows I threw at them did nothing. 1\/2 @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruno Grande",
        "screen_name" : "grandebruno",
        "indices" : [ 0, 12 ],
        "id_str" : "203557358",
        "id" : 203557358
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 101, 117 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "639196969773109248",
    "geo" : { },
    "id_str" : "639210282204708864",
    "in_reply_to_user_id" : 203557358,
    "text" : "@grandebruno I found that all the enthusiasm, papers and slideshows I threw at them did nothing. 1\/2 @gedankenstuecke",
    "id" : 639210282204708864,
    "in_reply_to_status_id" : 639196969773109248,
    "created_at" : "2015-09-02 22:56:21 +0000",
    "in_reply_to_screen_name" : "grandebruno",
    "in_reply_to_user_id_str" : "203557358",
    "user" : {
      "name" : "Andrew MacDonald",
      "screen_name" : "polesasunder",
      "protected" : false,
      "id_str" : "128275616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776147537308819456\/d-qJ5lJQ_normal.jpg",
      "id" : 128275616,
      "verified" : false
    }
  },
  "id" : 639335745363296256,
  "created_at" : "2015-09-03 07:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Bryan",
      "screen_name" : "JennyBryan",
      "indices" : [ 0, 11 ],
      "id_str" : "2167059661",
      "id" : 2167059661
    }, {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 12, 26 ],
      "id_str" : "48966898",
      "id" : 48966898
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 27, 37 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639173734276829184",
  "geo" : { },
  "id_str" : "639184516200972288",
  "in_reply_to_user_id" : 2167059661,
  "text" : "@JennyBryan @lexnederbragt @eltonjohn training them is hard. If people don\u2019t want to learn it\u2019s tough.",
  "id" : 639184516200972288,
  "in_reply_to_status_id" : 639173734276829184,
  "created_at" : "2015-09-02 21:13:58 +0000",
  "in_reply_to_screen_name" : "JennyBryan",
  "in_reply_to_user_id_str" : "2167059661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639154790895894529",
  "geo" : { },
  "id_str" : "639155202294194176",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks, hugs are always a good help. And dealing with the fluctuations gets a bit easier with time.",
  "id" : 639155202294194176,
  "in_reply_to_status_id" : 639154790895894529,
  "created_at" : "2015-09-02 19:17:29 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639154287734599681",
  "geo" : { },
  "id_str" : "639154696100446208",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima I\u2019ve no idea who made this. I found it via Twitter ages ago but it was a already a repost.",
  "id" : 639154696100446208,
  "in_reply_to_status_id" : 639154287734599681,
  "created_at" : "2015-09-02 19:15:29 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639153012154462208",
  "geo" : { },
  "id_str" : "639153882006949888",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima and if it\u2019s any consolation: it generally stays this up\/down game. \uD83D\uDE14",
  "id" : 639153882006949888,
  "in_reply_to_status_id" : 639153012154462208,
  "created_at" : "2015-09-02 19:12:15 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/639151748465209344\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/WCDsYTj2Zl",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CN65HkTWEAEBEdH.png",
      "id_str" : "639151736788226049",
      "id" : 639151736788226049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CN65HkTWEAEBEdH.png",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/WCDsYTj2Zl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639141238470483972",
  "geo" : { },
  "id_str" : "639151748465209344",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima there are those days \uD83D\uDE1F On other days it\u2019s like this: http:\/\/t.co\/WCDsYTj2Zl",
  "id" : 639151748465209344,
  "in_reply_to_status_id" : 639141238470483972,
  "created_at" : "2015-09-02 19:03:46 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Kqf439Kya0",
      "expanded_url" : "http:\/\/www.nature.com\/news\/what-could-derail-the-wearables-revolution-1.18263?WT.mc_id=TWT_NatureNews",
      "display_url" : "nature.com\/news\/what-coul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639149348316557312",
  "text" : "RT @EffyVayena: What could derail the wearables revolution? : Nature News &amp; Comment http:\/\/t.co\/Kqf439Kya0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/Kqf439Kya0",
        "expanded_url" : "http:\/\/www.nature.com\/news\/what-could-derail-the-wearables-revolution-1.18263?WT.mc_id=TWT_NatureNews",
        "display_url" : "nature.com\/news\/what-coul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639108713203277824",
    "text" : "What could derail the wearables revolution? : Nature News &amp; Comment http:\/\/t.co\/Kqf439Kya0",
    "id" : 639108713203277824,
    "created_at" : "2015-09-02 16:12:45 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 639149348316557312,
  "created_at" : "2015-09-02 18:54:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Zielinski",
      "screen_name" : "SarahZielinski",
      "indices" : [ 3, 18 ],
      "id_str" : "37547775",
      "id" : 37547775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639080034146361344",
  "text" : "RT @SarahZielinski: Dear scientist, when the spiders can kill you, they don't have an \"image problem.\" They really are terrifying. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/wASOMSYNwC",
        "expanded_url" : "http:\/\/news.nationalgeographic.com\/2015\/09\/150902-spiders-animals-australia-science-world\/",
        "display_url" : "news.nationalgeographic.com\/2015\/09\/150902\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639079147277549568",
    "text" : "Dear scientist, when the spiders can kill you, they don't have an \"image problem.\" They really are terrifying. http:\/\/t.co\/wASOMSYNwC",
    "id" : 639079147277549568,
    "created_at" : "2015-09-02 14:15:16 +0000",
    "user" : {
      "name" : "Sarah Zielinski",
      "screen_name" : "SarahZielinski",
      "protected" : false,
      "id_str" : "37547775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879790044608962560\/LK7XWnpZ_normal.jpg",
      "id" : 37547775,
      "verified" : true
    }
  },
  "id" : 639080034146361344,
  "created_at" : "2015-09-02 14:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639071169698766850",
  "geo" : { },
  "id_str" : "639071838262456320",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko I will, it\u2019s so tiring and exhausting\u2026",
  "id" : 639071838262456320,
  "in_reply_to_status_id" : 639071169698766850,
  "created_at" : "2015-09-02 13:46:14 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639067566326067201",
  "geo" : { },
  "id_str" : "639067828461654016",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick all of the above.",
  "id" : 639067828461654016,
  "in_reply_to_status_id" : 639067566326067201,
  "created_at" : "2015-09-02 13:30:18 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639066496019361792",
  "geo" : { },
  "id_str" : "639066774126915584",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju frustration levels are definitely growing to a point where \u2018beating into submission\u2019 begins to sound appealing\u2026",
  "id" : 639066774126915584,
  "in_reply_to_status_id" : 639066496019361792,
  "created_at" : "2015-09-02 13:26:06 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639066374669750272",
  "text" : "Dear Twitter, how do you get \u2018academic\u2019 \u2018programmers\u2019 to use version control? \uD83D\uDE2D",
  "id" : 639066374669750272,
  "created_at" : "2015-09-02 13:24:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/W0Pt30aQmL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=4uKBwB_SQPQ",
      "display_url" : "youtube.com\/watch?v=4uKBwB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639061672552996864",
  "text" : "One of us is right. The other seems to have lost their mind. https:\/\/t.co\/W0Pt30aQmL",
  "id" : 639061672552996864,
  "created_at" : "2015-09-02 13:05:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/HFn7sOdDSX",
      "expanded_url" : "https:\/\/xkcd.com\/882\/",
      "display_url" : "xkcd.com\/882\/"
    } ]
  },
  "in_reply_to_status_id_str" : "639025237644984320",
  "geo" : { },
  "id_str" : "639029466338074624",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr that will be a fun data set to show how https:\/\/t.co\/HFn7sOdDSX works!",
  "id" : 639029466338074624,
  "in_reply_to_status_id" : 639025237644984320,
  "created_at" : "2015-09-02 10:57:52 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "k\u00FCchenphilosophie",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639027936918642688",
  "text" : "\u00ABWenn der Schafsmilch-Gouda in China umf\u00E4llt und niemand ist da es zu h\u00F6ren: Macht er dann ein Ger\u00E4usch?\u00BB #k\u00FCchenphilosophie",
  "id" : 639027936918642688,
  "created_at" : "2015-09-02 10:51:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639000373475299329",
  "geo" : { },
  "id_str" : "639008570386870272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot aye, sudden death while doing something you love seems pretty perfect to me.",
  "id" : 639008570386870272,
  "in_reply_to_status_id" : 639000373475299329,
  "created_at" : "2015-09-02 09:34:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638998966823190528",
  "geo" : { },
  "id_str" : "638999272826998784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, I  enjoy being rocked to sleep while driving.",
  "id" : 638999272826998784,
  "in_reply_to_status_id" : 638998966823190528,
  "created_at" : "2015-09-02 08:57:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/pxzF1bgXSI",
      "expanded_url" : "http:\/\/i.kinja-img.com\/gawker-media\/image\/upload\/s--pBVMBx0G--\/c_fit,fl_progressive,q_80,w_320\/17m7vp3um0ne9jpg.jpg",
      "display_url" : "i.kinja-img.com\/gawker-media\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638998311328944128",
  "geo" : { },
  "id_str" : "638998854143246336",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl better get used to the gang signs: http:\/\/t.co\/pxzF1bgXSI",
  "id" : 638998854143246336,
  "in_reply_to_status_id" : 638998311328944128,
  "created_at" : "2015-09-02 08:56:13 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 10, 22 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/8WrN3ibbBh",
      "expanded_url" : "https:\/\/dynamicecology.wordpress.com\/2014\/02\/04\/you-do-not-need-to-work-80-hours-a-week-to-succeed-in-academia\/",
      "display_url" : "dynamicecology.wordpress.com\/2014\/02\/04\/you\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638982174608359424",
  "geo" : { },
  "id_str" : "638983444769468416",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @alibi_ranch verbunden mit one-up(wo)manship: https:\/\/t.co\/8WrN3ibbBh",
  "id" : 638983444769468416,
  "in_reply_to_status_id" : 638982174608359424,
  "created_at" : "2015-09-02 07:54:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 99, 105 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/KitqOCvdWK",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/classes\/2015\/09\/take_a_wittgenstein_class_he_explains_the_problems_of_translating_language.single.html",
      "display_url" : "slate.com\/articles\/life\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638976317413806080",
  "text" : "\u00ABWittgenstein\u2019s philosophy also accounts for the disastrous state of Internet discourse today\u00BB \/cc @Lobot  http:\/\/t.co\/KitqOCvdWK",
  "id" : 638976317413806080,
  "created_at" : "2015-09-02 07:26:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 3, 13 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/d4y4KLutkD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?t=12&v=agcRwGDKulw",
      "display_url" : "youtube.com\/watch?t=12&v=a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638963474840817664",
  "text" : "RT @romanmars: The architect of the original Death Star responds to design criticism.\nhttps:\/\/t.co\/d4y4KLutkD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/d4y4KLutkD",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?t=12&v=agcRwGDKulw",
        "display_url" : "youtube.com\/watch?t=12&v=a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638909045319991297",
    "text" : "The architect of the original Death Star responds to design criticism.\nhttps:\/\/t.co\/d4y4KLutkD",
    "id" : 638909045319991297,
    "created_at" : "2015-09-02 02:59:21 +0000",
    "user" : {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "protected" : false,
      "id_str" : "8198012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875790518440951809\/Uy995Ysj_normal.jpg",
      "id" : 8198012,
      "verified" : true
    }
  },
  "id" : 638963474840817664,
  "created_at" : "2015-09-02 06:35:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638821012193193985",
  "geo" : { },
  "id_str" : "638821273527709696",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Ich w\u00FCrde es nur knapp hinter \u2018The Descent of Man, and Selection in Relation to Sex\u2019 einsortieren.",
  "id" : 638821273527709696,
  "in_reply_to_status_id" : 638821012193193985,
  "created_at" : "2015-09-01 21:10:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/DoaY80lMzd",
      "expanded_url" : "http:\/\/static.fjcdn.com\/pictures\/Pterodactyl_b14f05_147867.jpg",
      "display_url" : "static.fjcdn.com\/pictures\/Ptero\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638820397455048706",
  "geo" : { },
  "id_str" : "638820624337498112",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich what about http:\/\/t.co\/DoaY80lMzd ?",
  "id" : 638820624337498112,
  "in_reply_to_status_id" : 638820397455048706,
  "created_at" : "2015-09-01 21:08:00 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/m2OSIScdOi",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/1733558\/terror-birds-o.gif",
      "display_url" : "stream1.gifsoup.com\/view2\/1733558\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638819471726002176",
  "geo" : { },
  "id_str" : "638819863062929413",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich sieht ein bisschen so aus als h\u00E4tte es schon jemand verfilmt: http:\/\/t.co\/m2OSIScdOi",
  "id" : 638819863062929413,
  "in_reply_to_status_id" : 638819471726002176,
  "created_at" : "2015-09-01 21:04:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/D8dLyMxFc0",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Phorusrhacidae",
      "display_url" : "en.wikipedia.org\/wiki\/Phorusrha\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638818555132166144",
  "geo" : { },
  "id_str" : "638818812578557952",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Ich k\u00F6nnte problemlos 90 Minuten mit einem Script \u00FCber Phorusrhacidae f\u00FCllen. https:\/\/t.co\/D8dLyMxFc0",
  "id" : 638818812578557952,
  "in_reply_to_status_id" : 638818555132166144,
  "created_at" : "2015-09-01 21:00:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638815807309541376",
  "text" : "@malech Oof!",
  "id" : 638815807309541376,
  "created_at" : "2015-09-01 20:48:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638814991647408128",
  "text" : "@malech ich hab erst irgendwann Mitte des Jahres \u00FCberhaupt mitbekommen das es die gibt!",
  "id" : 638814991647408128,
  "created_at" : "2015-09-01 20:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638811547339489280",
  "geo" : { },
  "id_str" : "638812708016652288",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare daf\u00FCr kann man mit compound nouns manchmal ein paar Zeichen sparen? ;)",
  "id" : 638812708016652288,
  "in_reply_to_status_id" : 638811547339489280,
  "created_at" : "2015-09-01 20:36:32 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638803131720146944",
  "geo" : { },
  "id_str" : "638804852995420160",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare Gl\u00FCckwunsch! :)",
  "id" : 638804852995420160,
  "in_reply_to_status_id" : 638803131720146944,
  "created_at" : "2015-09-01 20:05:20 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638771518449819649",
  "geo" : { },
  "id_str" : "638802602755530752",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \uD83D\uDC13\uD83D\uDC14\uD83D\uDC24\uD83D\uDC23\uD83D\uDC25\uD83D\uDC26\uD83D\uDC27 there you go!",
  "id" : 638802602755530752,
  "in_reply_to_status_id" : 638771518449819649,
  "created_at" : "2015-09-01 19:56:23 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 78, 84 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638800621634777088",
  "text" : "Sweet, my tiny \uD83D\uDE97 finally sounds like a \uD83D\uDE97 again, and not like a \uD83D\uDE82 X \uD83D\uDE9C.  Thanks @Lobot for getting it \uD83D\uDD29\uD83D\uDD28\uD83D\uDD27.",
  "id" : 638800621634777088,
  "created_at" : "2015-09-01 19:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638787139703033857",
  "geo" : { },
  "id_str" : "638789353205014529",
  "in_reply_to_user_id" : 14286491,
  "text" : "Network theorists: is this just a side effect of the network layout constraint or is it me slowly realizing I\u2019m a hub?",
  "id" : 638789353205014529,
  "in_reply_to_status_id" : 638787139703033857,
  "created_at" : "2015-09-01 19:03:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638787139703033857",
  "text" : "Thought six degrees of separation meant that you need 6 edges to connect A to B. Lately feels like it\u2019s 6 independent paths connecting them.",
  "id" : 638787139703033857,
  "created_at" : "2015-09-01 18:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "indices" : [ 3, 18 ],
      "id_str" : "116867280",
      "id" : 116867280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/fxDJ77viQP",
      "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/09\/ions-s5.html",
      "display_url" : "omicsomics.blogspot.com\/2015\/09\/ions-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638708087013163008",
  "text" : "RT @OmicsOmicsBlog: Ion's S5 http:\/\/t.co\/fxDJ77viQP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/fxDJ77viQP",
        "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2015\/09\/ions-s5.html",
        "display_url" : "omicsomics.blogspot.com\/2015\/09\/ions-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638683307467800576",
    "text" : "Ion's S5 http:\/\/t.co\/fxDJ77viQP",
    "id" : 638683307467800576,
    "created_at" : "2015-09-01 12:02:21 +0000",
    "user" : {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "protected" : false,
      "id_str" : "116867280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859776960058339329\/c0IznW_h_normal.jpg",
      "id" : 116867280,
      "verified" : false
    }
  },
  "id" : 638708087013163008,
  "created_at" : "2015-09-01 13:40:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 0, 14 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638704326547009536",
  "geo" : { },
  "id_str" : "638706217586700292",
  "in_reply_to_user_id" : 48966898,
  "text" : "@lexnederbragt so, \u2019S\u2019 is for \u2018screw sample purity\u2019?",
  "id" : 638706217586700292,
  "in_reply_to_status_id" : 638704326547009536,
  "created_at" : "2015-09-01 13:33:23 +0000",
  "in_reply_to_screen_name" : "lexnederbragt",
  "in_reply_to_user_id_str" : "48966898",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zjKYSLgPBO",
      "expanded_url" : "http:\/\/mbio.asm.org\/content\/6\/4\/e00936-15.full",
      "display_url" : "mbio.asm.org\/content\/6\/4\/e0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638705828283949056",
  "text" : "Finally worked through \u201CSMRT sequencing + optical mapping yields complete fungal genome\u201D Lots of cool stuff in there: http:\/\/t.co\/zjKYSLgPBO",
  "id" : 638705828283949056,
  "created_at" : "2015-09-01 13:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638691125348429824",
  "text" : "Mac OS + ssh + Linux + locales = the never ending story of weird bugs that are hard to reproduce\u2026",
  "id" : 638691125348429824,
  "created_at" : "2015-09-01 12:33:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "academicspamfromhell",
      "indices" : [ 55, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638685235404767232",
  "text" : "wait, now the omics group gives me honorable diabetes? #academicspamfromhell",
  "id" : 638685235404767232,
  "created_at" : "2015-09-01 12:10:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638636992067039232",
  "geo" : { },
  "id_str" : "638637393034280960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer maybe, I also missed it this time.",
  "id" : 638637393034280960,
  "in_reply_to_status_id" : 638636992067039232,
  "created_at" : "2015-09-01 08:59:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ngs2015",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638618290244349952",
  "geo" : { },
  "id_str" : "638618799462350849",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer also read up the #ngs2015 tweets, there\u2019s lots of useful things in there. :)",
  "id" : 638618799462350849,
  "in_reply_to_status_id" : 638618290244349952,
  "created_at" : "2015-09-01 07:46:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 59, 72 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Pu8M8nTUDr",
      "expanded_url" : "https:\/\/flxlexblog.wordpress.com\/2015\/08\/31\/active-learning-strategies-for-bioinformatics-teaching-2\/",
      "display_url" : "flxlexblog.wordpress.com\/2015\/08\/31\/act\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638607690932088832",
  "text" : "Active learning strategies for bioinformatics\u00A0teaching \/cc @PhilippBayer https:\/\/t.co\/Pu8M8nTUDr",
  "id" : 638607690932088832,
  "created_at" : "2015-09-01 07:01:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/eLmJDMSjDh",
      "expanded_url" : "http:\/\/cdn.makeagif.com\/media\/8-31-2015\/61snk3.gif",
      "display_url" : "cdn.makeagif.com\/media\/8-31-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638493225284669440",
  "text" : "if you\u2019re in a hole\u2026 http:\/\/t.co\/eLmJDMSjDh",
  "id" : 638493225284669440,
  "created_at" : "2015-08-31 23:27:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/fVENw13xk7",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3846",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638487108215287808",
  "text" : "parsimony is for wimps http:\/\/t.co\/fVENw13xk7",
  "id" : 638487108215287808,
  "created_at" : "2015-08-31 23:02:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]