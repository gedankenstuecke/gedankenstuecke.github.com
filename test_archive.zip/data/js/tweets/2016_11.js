Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnathan Nightingale",
      "screen_name" : "johnath",
      "indices" : [ 0, 8 ],
      "id_str" : "6140482",
      "id" : 6140482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803991885572349952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.76191637017649, 8.136197235442825 ]
  },
  "id_str" : "803995470376894464",
  "in_reply_to_user_id" : 6140482,
  "text" : "@johnath thanks for writing it. Reminded me a lot of myself!",
  "id" : 803995470376894464,
  "in_reply_to_status_id" : 803991885572349952,
  "created_at" : "2016-11-30 16:13:52 +0000",
  "in_reply_to_screen_name" : "johnath",
  "in_reply_to_user_id_str" : "6140482",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Stewart",
      "screen_name" : "BioStew",
      "indices" : [ 0, 8 ],
      "id_str" : "221032511",
      "id" : 221032511
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 9, 18 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803902839919706112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236991441153, 8.627522223308695 ]
  },
  "id_str" : "803938869003583488",
  "in_reply_to_user_id" : 221032511,
  "text" : "@BioStew @msandstr Perfect \uD83D\uDC96",
  "id" : 803938869003583488,
  "in_reply_to_status_id" : 803902839919706112,
  "created_at" : "2016-11-30 12:28:57 +0000",
  "in_reply_to_screen_name" : "BioStew",
  "in_reply_to_user_id_str" : "221032511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803901426007207937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239886358645, 8.6275219155132 ]
  },
  "id_str" : "803901779209519105",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr it\u2019s Berlin next Year, right?",
  "id" : 803901779209519105,
  "in_reply_to_status_id" : 803901426007207937,
  "created_at" : "2016-11-30 10:01:34 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803901063229276160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239886358645, 8.6275219155132 ]
  },
  "id_str" : "803901215969079296",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr we should organize one!",
  "id" : 803901215969079296,
  "in_reply_to_status_id" : 803901063229276160,
  "created_at" : "2016-11-30 09:59:20 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/p8MEF3vUzO",
      "expanded_url" : "https:\/\/medium.com\/@mwichary\/party-where-we-read-things-c503c3ec624c?source=userActivityShare-aaeb714c1b80-1480463240",
      "display_url" : "medium.com\/@mwichary\/part\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803895362431946752",
  "text" : "That\u2019s my kind of party: Sitting around and reading to each other. https:\/\/t.co\/p8MEF3vUzO",
  "id" : 803895362431946752,
  "created_at" : "2016-11-30 09:36:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/BdUWy4Kng9",
      "expanded_url" : "https:\/\/medium.com\/decoding-living-systems\/conservation-genomics-saving-genomes-not-individuals-4a1173fd0929?source=twitterShare-aaeb714c1b80-1480463099",
      "display_url" : "medium.com\/decoding-livin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803746678058733570",
  "text" : "A nice primer on Conservation Genomics https:\/\/t.co\/BdUWy4Kng9",
  "id" : 803746678058733570,
  "created_at" : "2016-11-29 23:45:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/6KLjsTeUhT",
      "expanded_url" : "https:\/\/thinkprogress.org\/mapping-hate-in-trumps-america-9b166b2c52c2?source=twitterShare-aaeb714c1b80-1480462950",
      "display_url" : "thinkprogress.org\/mapping-hate-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803746084791128064",
  "text" : "Tracking the explosion of hate since the election https:\/\/t.co\/6KLjsTeUhT",
  "id" : 803746084791128064,
  "created_at" : "2016-11-29 23:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/kjVDQpJsu4",
      "expanded_url" : "https:\/\/www.theguardian.com\/society\/2016\/nov\/29\/alexandre-mars-states-dont-have-money-to-do-good-business-does?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/society\/2016\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803745230931558400",
  "text" : "\u2018States don\u2019t have the money to do good. Business does.\u2019 Largely because businesses aren't paying taxes, but well\u2026 https:\/\/t.co\/kjVDQpJsu4",
  "id" : 803745230931558400,
  "created_at" : "2016-11-29 23:39:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/sB2CYd7iRO",
      "expanded_url" : "https:\/\/mfbt.ca\/some-garbage-i-used-to-believe-about-equality-e7c771784f26#.1g3ct1r78",
      "display_url" : "mfbt.ca\/some-garbage-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803625466921947136",
  "text" : "Some Garbage I Used to Believe About\u00A0Equality https:\/\/t.co\/sB2CYd7iRO",
  "id" : 803625466921947136,
  "created_at" : "2016-11-29 15:43:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/IcL23mtGX1",
      "expanded_url" : "https:\/\/medium.com\/embrace-race\/life-at-the-intersection-of-hate-2016-806e233113fe#.c18kg98a5",
      "display_url" : "medium.com\/embrace-race\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803622258493321217",
  "text" : "Life at the Intersection of Hate:\u00A02016-??? https:\/\/t.co\/IcL23mtGX1",
  "id" : 803622258493321217,
  "created_at" : "2016-11-29 15:30:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 27, 39 ],
      "id_str" : "29891068",
      "id" : 29891068
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 44, 53 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/L01CpIYyxY",
      "expanded_url" : "http:\/\/blogs.plos.org\/plospodcasts\/2016\/11\/23\/open-source-science-communities-an-interview-with-abigail-cabunoc-mayes\/",
      "display_url" : "blogs.plos.org\/plospodcasts\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803543772160282624",
  "text" : "Finally found time to hear @tweetotaler and @abbycabs discuss Open Source Science Communities. Thx for the shoutout! https:\/\/t.co\/L01CpIYyxY",
  "id" : 803543772160282624,
  "created_at" : "2016-11-29 10:18:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "ISCB News",
      "screen_name" : "iscb",
      "indices" : [ 18, 23 ],
      "id_str" : "96111619",
      "id" : 96111619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diversity",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803539558730231809",
  "text" : "RT @OBF_BOSC: The @iscb are calling on their members to nominate new fellows - please help to build on 2016\u2019s improved #diversity https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ISCB News",
        "screen_name" : "iscb",
        "indices" : [ 4, 9 ],
        "id_str" : "96111619",
        "id" : 96111619
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "diversity",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/omG8Oo5dU2",
        "expanded_url" : "https:\/\/www.iscb.org\/iscb-fellows-program",
        "display_url" : "iscb.org\/iscb-fellows-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "803539288864473088",
    "text" : "The @iscb are calling on their members to nominate new fellows - please help to build on 2016\u2019s improved #diversity https:\/\/t.co\/omG8Oo5dU2",
    "id" : 803539288864473088,
    "created_at" : "2016-11-29 10:01:10 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 803539558730231809,
  "created_at" : "2016-11-29 10:02:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/swg8l27MPG",
      "expanded_url" : "https:\/\/www.theguardian.com\/society\/2016\/nov\/29\/act-up-aids-new-york-spencer-cox",
      "display_url" : "theguardian.com\/society\/2016\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803532357760389120",
  "text" : "The reinvention of radical protest: life on the frontline of the Aids epidemic https:\/\/t.co\/swg8l27MPG",
  "id" : 803532357760389120,
  "created_at" : "2016-11-29 09:33:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ursula K. Le Guin",
      "screen_name" : "ursulaleguin",
      "indices" : [ 3, 16 ],
      "id_str" : "243428457",
      "id" : 243428457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/nUcPXmTwHr",
      "expanded_url" : "http:\/\/ow.ly\/p5xc306zd5O",
      "display_url" : "ow.ly\/p5xc306zd5O"
    } ]
  },
  "geo" : { },
  "id_str" : "803527028486139904",
  "text" : "RT @ursulaleguin: My blog entry on the election result: https:\/\/t.co\/nUcPXmTwHr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/nUcPXmTwHr",
        "expanded_url" : "http:\/\/ow.ly\/p5xc306zd5O",
        "display_url" : "ow.ly\/p5xc306zd5O"
      } ]
    },
    "geo" : { },
    "id_str" : "803374230117158913",
    "text" : "My blog entry on the election result: https:\/\/t.co\/nUcPXmTwHr",
    "id" : 803374230117158913,
    "created_at" : "2016-11-28 23:05:17 +0000",
    "user" : {
      "name" : "Ursula K. Le Guin",
      "screen_name" : "ursulaleguin",
      "protected" : false,
      "id_str" : "243428457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1226807203\/UKLbyMWK-280x347_normal.jpg",
      "id" : 243428457,
      "verified" : true
    }
  },
  "id" : 803527028486139904,
  "created_at" : "2016-11-29 09:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/UUTdBcUn1s",
      "expanded_url" : "https:\/\/twitter.com\/GholsonLyon\/status\/802617766695948288",
      "display_url" : "twitter.com\/GholsonLyon\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087856583401, 8.818668906146588 ]
  },
  "id_str" : "803319316804407297",
  "text" : "Hell yes they are. And the more you study them, the more you see it that way. \uD83C\uDFB1\uD83D\uDD2E https:\/\/t.co\/UUTdBcUn1s",
  "id" : 803319316804407297,
  "created_at" : "2016-11-28 19:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06112054596996, 8.818662250100497 ]
  },
  "id_str" : "803316469002043392",
  "text" : "My mom\u2019s not picking favorites amongst my partners at all. Except it\u2019s the one who plays her card games and gives her free concerts. \uD83D\uDE02",
  "id" : 803316469002043392,
  "created_at" : "2016-11-28 19:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803260699115982848",
  "geo" : { },
  "id_str" : "803260801150685184",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim k, will pass the word on!",
  "id" : 803260801150685184,
  "in_reply_to_status_id" : 803260699115982848,
  "created_at" : "2016-11-28 15:34:33 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803260115289862144",
  "geo" : { },
  "id_str" : "803260278242615296",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim what\u2019ll happen in general? :D",
  "id" : 803260278242615296,
  "in_reply_to_status_id" : 803260115289862144,
  "created_at" : "2016-11-28 15:32:28 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803258031962226688",
  "geo" : { },
  "id_str" : "803259505710694401",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim need to sign up to see all the info? :(",
  "id" : 803259505710694401,
  "in_reply_to_status_id" : 803258031962226688,
  "created_at" : "2016-11-28 15:29:24 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/VqwtA1RyXv",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/153656703804\/bean-just-sleeping-and-being-cute-p",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/153656703\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803246643634180098",
  "text" : "jetlag status: https:\/\/t.co\/VqwtA1RyXv \uD83D\uDC36\u2708\uFE0F",
  "id" : 803246643634180098,
  "created_at" : "2016-11-28 14:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0MjRaaPC4p",
      "expanded_url" : "https:\/\/twitter.com\/Science_Open\/status\/803225958731907072",
      "display_url" : "twitter.com\/Science_Open\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803228315712626688",
  "text" : "I also said: \u00ABIf we want to foster openness we need to be more forgiving and accept that no one of is without fault\u00BB https:\/\/t.co\/0MjRaaPC4p",
  "id" : 803228315712626688,
  "created_at" : "2016-11-28 13:25:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/sB1ou3YkuB",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/25814351-the-bad-ass-librarians-of-timbuktu",
      "display_url" : "goodreads.com\/book\/show\/2581\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803222387516907521",
  "text" : "Random book buy that was totally worth it: The Bad-Ass Librarians of Timbuktu. \uD83D\uDCDA\uD83D\uDE0D https:\/\/t.co\/sB1ou3YkuB",
  "id" : 803222387516907521,
  "created_at" : "2016-11-28 13:01:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803179906322472960",
  "geo" : { },
  "id_str" : "803181630965895168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon I already see the millions rolling in!",
  "id" : 803181630965895168,
  "in_reply_to_status_id" : 803179906322472960,
  "created_at" : "2016-11-28 10:19:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/AZYp3eAYCQ",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/11\/11\/087254",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803181501676285953",
  "text" : "Our preprint on the annotated draft genome for Radix auricularia is on bioRxiv https:\/\/t.co\/AZYp3eAYCQ",
  "id" : 803181501676285953,
  "created_at" : "2016-11-28 10:19:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/AiBBwlCYKR",
      "expanded_url" : "https:\/\/twitter.com\/likeuberbut\/status\/803124739317207040",
      "display_url" : "twitter.com\/likeuberbut\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "803178247764766720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon there you go! https:\/\/t.co\/AiBBwlCYKR",
  "id" : 803178247764766720,
  "created_at" : "2016-11-28 10:06:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "803164963363639296",
  "geo" : { },
  "id_str" : "803167616063913984",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I wish!",
  "id" : 803167616063913984,
  "in_reply_to_status_id" : 803164963363639296,
  "created_at" : "2016-11-28 09:24:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/803161501036986368\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/ytdeKUVTdm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CyVnHU_XEAAAbQT.jpg",
      "id_str" : "803161484146708480",
      "id" : 803161484146708480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CyVnHU_XEAAAbQT.jpg",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ytdeKUVTdm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803161501036986368",
  "text" : "Coming into the office this morning. https:\/\/t.co\/ytdeKUVTdm",
  "id" : 803161501036986368,
  "created_at" : "2016-11-28 08:59:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802994232222879744",
  "geo" : { },
  "id_str" : "802995736552083457",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 hope you\u2019re dealing fine with that!",
  "id" : 802995736552083457,
  "in_reply_to_status_id" : 802994232222879744,
  "created_at" : "2016-11-27 22:01:17 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802993730127069185",
  "geo" : { },
  "id_str" : "802994159430860800",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 I envy you!",
  "id" : 802994159430860800,
  "in_reply_to_status_id" : 802993730127069185,
  "created_at" : "2016-11-27 21:55:01 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/YX12BN9FmJ",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/802907876012490752",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "802991738860240896",
  "text" : "15\/10 Would pet! https:\/\/t.co\/YX12BN9FmJ",
  "id" : 802991738860240896,
  "created_at" : "2016-11-27 21:45:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802979077091168256",
  "text" : "Inbox Zero \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89",
  "id" : 802979077091168256,
  "created_at" : "2016-11-27 20:55:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 58, 74 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/802969056622084097\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/XJJLkp0hlo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyS4FsbWQAA524x.jpg",
      "id_str" : "802969041543512064",
      "id" : 802969041543512064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyS4FsbWQAA524x.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/XJJLkp0hlo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802974253717012481",
  "text" : "RT @Lobot: It\u2019s kind of a super secret handshake. (Thanks @gedankenstuecke!) &lt;3 https:\/\/t.co\/XJJLkp0hlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 47, 63 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/802969056622084097\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/XJJLkp0hlo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CyS4FsbWQAA524x.jpg",
        "id_str" : "802969041543512064",
        "id" : 802969041543512064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyS4FsbWQAA524x.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/XJJLkp0hlo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "802969056622084097",
    "text" : "It\u2019s kind of a super secret handshake. (Thanks @gedankenstuecke!) &lt;3 https:\/\/t.co\/XJJLkp0hlo",
    "id" : 802969056622084097,
    "created_at" : "2016-11-27 20:15:16 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 802974253717012481,
  "created_at" : "2016-11-27 20:35:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802969056622084097",
  "geo" : { },
  "id_str" : "802974010388660224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u270A\uD83D\uDC96\uD83C\uDF89",
  "id" : 802974010388660224,
  "in_reply_to_status_id" : 802969056622084097,
  "created_at" : "2016-11-27 20:34:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yashar Ali \uD83D\uDC18",
      "screen_name" : "yashar",
      "indices" : [ 0, 7 ],
      "id_str" : "11744152",
      "id" : 11744152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802727332284919812",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05943317523958, 8.807199884011693 ]
  },
  "id_str" : "802951693088489472",
  "in_reply_to_user_id" : 11744152,
  "text" : "@yashar wtf did I just see?",
  "id" : 802951693088489472,
  "in_reply_to_status_id" : 802727332284919812,
  "created_at" : "2016-11-27 19:06:16 +0000",
  "in_reply_to_screen_name" : "yashar",
  "in_reply_to_user_id_str" : "11744152",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802950083394371584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05944153943011, 8.807177627661162 ]
  },
  "id_str" : "802950972859449345",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe keep rocking it! \uD83D\uDC96",
  "id" : 802950972859449345,
  "in_reply_to_status_id" : 802950083394371584,
  "created_at" : "2016-11-27 19:03:24 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802855875211853824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05943487339614, 8.807253292104514 ]
  },
  "id_str" : "802948814860480512",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe wtf? How does that even relate to one another?",
  "id" : 802948814860480512,
  "in_reply_to_status_id" : 802855875211853824,
  "created_at" : "2016-11-27 18:54:50 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802925220126302208",
  "text" : "RT @LGBTSTEM: You can still register to attend #LGBTSTEMinar17 up to 16 Dec. &gt;100 LGBTQ+ scientists &amp; allies have already! https:\/\/t.co\/SyI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar17",
        "indices" : [ 33, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/SyIg5H2MAw",
        "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/lgbt-steminar-2017\/",
        "display_url" : "lgbtstem.wordpress.com\/lgbt-steminar-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "802848134107795456",
    "text" : "You can still register to attend #LGBTSTEMinar17 up to 16 Dec. &gt;100 LGBTQ+ scientists &amp; allies have already! https:\/\/t.co\/SyIg5H2MAw",
    "id" : 802848134107795456,
    "created_at" : "2016-11-27 12:14:46 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 802925220126302208,
  "created_at" : "2016-11-27 17:21:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/sHhJAa2Ush",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNTyEiFDVvV\/",
      "display_url" : "instagram.com\/p\/BNTyEiFDVvV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "802811070230446080",
  "text" : "Still a fun sight each and every time https:\/\/t.co\/sHhJAa2Ush",
  "id" : 802811070230446080,
  "created_at" : "2016-11-27 09:47:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 69, 82 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 83, 95 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tQT66NQ81F",
      "expanded_url" : "http:\/\/www.frontlinegenomics.com\/opinion\/8051\/further-bias-personal-genomics\/",
      "display_url" : "frontlinegenomics.com\/opinion\/8051\/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99560722964657, -22.62391452839476 ]
  },
  "id_str" : "802740008385966080",
  "text" : "\u00ABFurther bias in personal genomics?\u00BB, based largely on openSNP data. @PhilippBayer @helgerausch https:\/\/t.co\/tQT66NQ81F",
  "id" : 802740008385966080,
  "created_at" : "2016-11-27 05:05:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/802728818851004417\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/2HMCOqhc3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyPdmOoXcAAvn6z.jpg",
      "id_str" : "802728807434252288",
      "id" : 802728807434252288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyPdmOoXcAAvn6z.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2HMCOqhc3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802719221402587136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99564138161379, -22.62376270085787 ]
  },
  "id_str" : "802728818851004417",
  "in_reply_to_user_id" : 14286491,
  "text" : "Mission accomplished! https:\/\/t.co\/2HMCOqhc3J",
  "id" : 802728818851004417,
  "in_reply_to_status_id" : 802719221402587136,
  "created_at" : "2016-11-27 04:20:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99231685831187, -22.62473716149018 ]
  },
  "id_str" : "802719221402587136",
  "text" : "There we go again KEF. I have promised to buy Liquorice this time!",
  "id" : 802719221402587136,
  "created_at" : "2016-11-27 03:42:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802637473490866176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99208941037207, -22.62469405310473 ]
  },
  "id_str" : "802719014212472832",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Protohedgehog thanks for your support!",
  "id" : 802719014212472832,
  "in_reply_to_status_id" : 802637473490866176,
  "created_at" : "2016-11-27 03:41:41 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/pKuR6LYJx5",
      "expanded_url" : "https:\/\/twitter.com\/theWinnower\/status\/802575062905847808",
      "display_url" : "twitter.com\/theWinnower\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61047579429309, -122.3893943737288 ]
  },
  "id_str" : "802595117626294273",
  "text" : "\u05DE\u05D6\u05DC \u05D8\u05D5\u05D1! https:\/\/t.co\/pKuR6LYJx5",
  "id" : 802595117626294273,
  "created_at" : "2016-11-26 19:29:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/oVGfuakKzh",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/opv3C3h2B2Kas\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/opv3C3h2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61423372720098, -122.3875356294645 ]
  },
  "id_str" : "802589445190926337",
  "text" : "Dramatic Airport Goodbyes, Expert Level. Now: SFO \u2708\uFE0F KEF. https:\/\/t.co\/oVGfuakKzh",
  "id" : 802589445190926337,
  "created_at" : "2016-11-26 19:06:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/802309519296430080\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ITQbrGuhWS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyJgQTfUcAAcEJn.jpg",
      "id_str" : "802309516851179520",
      "id" : 802309516851179520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyJgQTfUcAAcEJn.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ITQbrGuhWS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802309519296430080",
  "text" : "\u00ABI'm surprised. You really went for the huge ice cream!\u00BB \u2014 \u00ABYou really don't know anything about me!\u00BB https:\/\/t.co\/ITQbrGuhWS",
  "id" : 802309519296430080,
  "created_at" : "2016-11-26 00:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/kJVwXpS8PK",
      "expanded_url" : "http:\/\/impossiblefoods.com\/",
      "display_url" : "impossiblefoods.com"
    } ]
  },
  "in_reply_to_status_id_str" : "802261610412638208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77863864223674, -122.3972346688871 ]
  },
  "id_str" : "802264616109645824",
  "in_reply_to_user_id" : 14286491,
  "text" : "Definitely good enough to fool me. https:\/\/t.co\/kJVwXpS8PK \uD83D\uDE0D",
  "id" : 802264616109645824,
  "in_reply_to_status_id" : 802261610412638208,
  "created_at" : "2016-11-25 21:36:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 39, 47 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/802261610412638208\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/C7KYOdiOX6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyI0qgwUkAA3R6u.jpg",
      "id_str" : "802261588577128448",
      "id" : 802261588577128448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyI0qgwUkAA3R6u.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/C7KYOdiOX6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802261610412638208",
  "text" : "Maximum cognitive dissonance in 3\u20262\u20261\u2026 @mbeisen https:\/\/t.co\/C7KYOdiOX6",
  "id" : 802261610412638208,
  "created_at" : "2016-11-25 21:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 7, 21 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802248246949253122",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7801926154828, -122.3943507845889 ]
  },
  "id_str" : "802250631830347776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Protohedgehog yay!",
  "id" : 802250631830347776,
  "in_reply_to_status_id" : 802248246949253122,
  "created_at" : "2016-11-25 20:40:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802236465535033344",
  "text" : "RT @existentialcoms: Get the hottest deals this Black Friday by seizing the means of production and eliminating the vampiric capitalist cla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "802228267734290432",
    "text" : "Get the hottest deals this Black Friday by seizing the means of production and eliminating the vampiric capitalist class!",
    "id" : 802228267734290432,
    "created_at" : "2016-11-25 19:11:38 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 802236465535033344,
  "created_at" : "2016-11-25 19:44:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/BlzTOsuB41",
      "expanded_url" : "https:\/\/twitter.com\/biolojical\/status\/801798315033575424",
      "display_url" : "twitter.com\/biolojical\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79081827010175, -122.4041000711363 ]
  },
  "id_str" : "802235886402355200",
  "text" : "The Mullis one made me spit my coffee all over my postcards because of too much (non-LSD fueled) laughter. https:\/\/t.co\/BlzTOsuB41",
  "id" : 802235886402355200,
  "created_at" : "2016-11-25 19:41:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/4yrQr1VqB4",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNPqMyejF9w\/",
      "display_url" : "instagram.com\/p\/BNPqMyejF9w\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7964227, -122.4053498 ]
  },
  "id_str" : "802230812213026816",
  "text" : "a room with a view @ Hotel North Beach https:\/\/t.co\/4yrQr1VqB4",
  "id" : 802230812213026816,
  "created_at" : "2016-11-25 19:21:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802202838944202752",
  "text" : "\u00ABThe weirdest part about this hotel is that the two of us are the least weird people here.\u00BB",
  "id" : 802202838944202752,
  "created_at" : "2016-11-25 17:30:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802071946032717824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7967229206467, -122.4054357783146 ]
  },
  "id_str" : "802174944587042817",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thank you! \uD83D\uDC96\uD83D\uDE0D\uD83C\uDF89",
  "id" : 802174944587042817,
  "in_reply_to_status_id" : 802071946032717824,
  "created_at" : "2016-11-25 15:39:45 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moves",
      "screen_name" : "movesapp",
      "indices" : [ 0, 9 ],
      "id_str" : "888379981",
      "id" : 888379981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/802034943610097664\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/jEqRkqwevR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyFmhRtUkAAPQqN.jpg",
      "id_str" : "802034930523869184",
      "id" : 802034930523869184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyFmhRtUkAAPQqN.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/jEqRkqwevR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79653875238894, -122.4051978119092 ]
  },
  "id_str" : "802034943610097664",
  "in_reply_to_user_id" : 888379981,
  "text" : "@movesapp what\u2019s the issue with the 0,0 coordinates I see more often these days? https:\/\/t.co\/jEqRkqwevR",
  "id" : 802034943610097664,
  "created_at" : "2016-11-25 06:23:26 +0000",
  "in_reply_to_screen_name" : "movesapp",
  "in_reply_to_user_id_str" : "888379981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79667807746473, -122.4055800308682 ]
  },
  "id_str" : "802034079847706624",
  "text" : "\u00ABI still have 20 minutes to become a functioning human being!\u00BB \u2014 \u00ABIf the last 31 years didn\u2019t help I\u2019m not sure whether that\u2019ll work.\u00BB",
  "id" : 802034079847706624,
  "created_at" : "2016-11-25 06:20:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/vdAED9f3iy",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNNmVBODPht\/",
      "display_url" : "instagram.com\/p\/BNNmVBODPht\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77038, -122.4603 ]
  },
  "id_str" : "801940823357198336",
  "text" : "Endless Names @ National AIDS Memorial Grove https:\/\/t.co\/vdAED9f3iy",
  "id" : 801940823357198336,
  "created_at" : "2016-11-25 00:09:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juh",
      "screen_name" : "__juh__",
      "indices" : [ 0, 8 ],
      "id_str" : "20516838",
      "id" : 20516838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801857159860539392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79687000206604, -122.4054586734762 ]
  },
  "id_str" : "801861351517753344",
  "in_reply_to_user_id" : 20516838,
  "text" : "@__juh__ yay, gut zu h\u00F6ren das sie angekommen ist!",
  "id" : 801861351517753344,
  "in_reply_to_status_id" : 801857159860539392,
  "created_at" : "2016-11-24 18:53:38 +0000",
  "in_reply_to_screen_name" : "__juh__",
  "in_reply_to_user_id_str" : "20516838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/S6UyERfocD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNM_UbXjOHc\/",
      "display_url" : "instagram.com\/p\/BNM_UbXjOHc\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8555232706, -122.565631047 ]
  },
  "id_str" : "801855041741197312",
  "text" : "Uphill #latergram @ Pirates Cove https:\/\/t.co\/S6UyERfocD",
  "id" : 801855041741197312,
  "created_at" : "2016-11-24 18:28:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801844063007866880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79680905293476, -122.4054410652018 ]
  },
  "id_str" : "801846075883520000",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 no complains at all, best way to spend an early morning.",
  "id" : 801846075883520000,
  "in_reply_to_status_id" : 801844063007866880,
  "created_at" : "2016-11-24 17:52:56 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79689793812837, -122.4055265241838 ]
  },
  "id_str" : "801845976231079936",
  "text" : "If you\u2019re in San Francisco today and don\u2019t want to spend this day alone for one reason or another: give a shout out, I\u2019m game.",
  "id" : 801845976231079936,
  "created_at" : "2016-11-24 17:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bkleZYQ6tE",
      "expanded_url" : "https:\/\/instagram.com\/p\/BNFsF2LDFv3\/",
      "display_url" : "instagram.com\/p\/BNFsF2LDFv3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79670720457825, -122.405637614543 ]
  },
  "id_str" : "801811367392985088",
  "text" : "\u00ABHow many cute dog videos do you get send every morning?\u00BB 30 minutes later, we\u2019re still wading through the backlog. https:\/\/t.co\/bkleZYQ6tE",
  "id" : 801811367392985088,
  "created_at" : "2016-11-24 15:35:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 0, 12 ],
      "id_str" : "19355816",
      "id" : 19355816
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 29, 40 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 41, 50 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800996195514679296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79685149990305, -122.4055389686567 ]
  },
  "id_str" : "801684218543648768",
  "in_reply_to_user_id" : 19355816,
  "text" : "@davidweisss yes, of course! @openSNPorg @crowd_ai",
  "id" : 801684218543648768,
  "in_reply_to_status_id" : 800996195514679296,
  "created_at" : "2016-11-24 07:09:46 +0000",
  "in_reply_to_screen_name" : "davidweisss",
  "in_reply_to_user_id_str" : "19355816",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78669062272814, -122.4136721462415 ]
  },
  "id_str" : "801655410734178304",
  "text" : "\u00ABThis is Mr. S Leather, right? Do you happen to have any vegan collars?\u00BB \uD83D\uDE02",
  "id" : 801655410734178304,
  "created_at" : "2016-11-24 05:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/BAb4TFE8eH",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNLMi_LjZxI\/",
      "display_url" : "instagram.com\/p\/BNLMi_LjZxI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7794018516, -122.423421637 ]
  },
  "id_str" : "801602654233313281",
  "text" : "After a 20 minute descend to the pirate's nest @ Pirates Cove https:\/\/t.co\/BAb4TFE8eH",
  "id" : 801602654233313281,
  "created_at" : "2016-11-24 01:45:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/KeGrEOFNyk",
      "expanded_url" : "https:\/\/twitter.com\/godtributes\/status\/801600039139295232",
      "display_url" : "twitter.com\/godtributes\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77515229007416, -122.4102020939165 ]
  },
  "id_str" : "801600125919297536",
  "text" : "That\u2019s the spirit. https:\/\/t.co\/KeGrEOFNyk",
  "id" : 801600125919297536,
  "created_at" : "2016-11-24 01:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/801600032629628928\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/jJIQMqkGuv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cx_a-yjUkAECzn_.jpg",
      "id_str" : "801600030951903233",
      "id" : 801600030951903233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cx_a-yjUkAECzn_.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jJIQMqkGuv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801600032629628928",
  "text" : "Explored the antique vibrator museum. \uD83D\uDE0D https:\/\/t.co\/jJIQMqkGuv",
  "id" : 801600032629628928,
  "created_at" : "2016-11-24 01:35:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ZypkDn0O9F",
      "expanded_url" : "https:\/\/twitter.com\/GwilymLockwood\/status\/801502622113038336",
      "display_url" : "twitter.com\/GwilymLockwood\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7752897236848, -122.4101401214697 ]
  },
  "id_str" : "801595636051099648",
  "text" : "We searched hard for these. \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/ZypkDn0O9F",
  "id" : 801595636051099648,
  "created_at" : "2016-11-24 01:17:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/PdCzW9w6m0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNKLhpSj8iE\/",
      "display_url" : "instagram.com\/p\/BNKLhpSj8iE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.518036, -121.95054 ]
  },
  "id_str" : "801459671416639488",
  "text" : "And a last one from Route 1. #latergram @ Point Lobos State Reserve https:\/\/t.co\/PdCzW9w6m0",
  "id" : 801459671416639488,
  "created_at" : "2016-11-23 16:17:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/GEp6C8Afer",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNJINAqDemO\/",
      "display_url" : "instagram.com\/p\/BNJINAqDemO\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78, -122.513611111 ]
  },
  "id_str" : "801311627765227520",
  "text" : "Urban Exploration \uD83D\uDC96 #latergram @ Sutro Baths https:\/\/t.co\/GEp6C8Afer",
  "id" : 801311627765227520,
  "created_at" : "2016-11-23 06:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mF9cPNZsYw",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNJH1muDbSh\/",
      "display_url" : "instagram.com\/p\/BNJH1muDbSh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.5171, -121.943 ]
  },
  "id_str" : "801310826313478144",
  "text" : "Trentepohlia as far as the eyes reach #latergram @ Point Lobos https:\/\/t.co\/mF9cPNZsYw",
  "id" : 801310826313478144,
  "created_at" : "2016-11-23 06:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 47, 55 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/801278922352566272\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/oV1Ge3mOyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cx627RwVQAAwCvz.jpg",
      "id_str" : "801278913213186048",
      "id" : 801278913213186048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cx627RwVQAAwCvz.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oV1Ge3mOyc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79682186901364, -122.4054773525544 ]
  },
  "id_str" : "801278922352566272",
  "text" : "The things that come out of having dinner with @mbeisen! https:\/\/t.co\/oV1Ge3mOyc",
  "id" : 801278922352566272,
  "created_at" : "2016-11-23 04:19:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801172033388220416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79680362002048, -122.4054914197933 ]
  },
  "id_str" : "801209195634667520",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen usually hear algae used only for Chlorophyta. Otherwise prefixed with red etc.",
  "id" : 801209195634667520,
  "in_reply_to_status_id" : 801172033388220416,
  "created_at" : "2016-11-22 23:42:12 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ujRhkA08px",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNIZUmiDqp2\/",
      "display_url" : "instagram.com\/p\/BNIZUmiDqp2\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.518036, -121.95054 ]
  },
  "id_str" : "801208537309388800",
  "text" : "Definitely my favorite ocean to wet my feet in. #latergram @ Point Lobos State Reserve https:\/\/t.co\/ujRhkA08px",
  "id" : 801208537309388800,
  "created_at" : "2016-11-22 23:39:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Glen Wright",
      "screen_name" : "MarinePolicy",
      "indices" : [ 15, 28 ],
      "id_str" : "301842084",
      "id" : 301842084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801165442727309312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78663140259477, -122.4955051114061 ]
  },
  "id_str" : "801180994053160960",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @MarinePolicy I thought I might shoot for the Nobel in Literature!",
  "id" : 801180994053160960,
  "in_reply_to_status_id" : 801165442727309312,
  "created_at" : "2016-11-22 21:50:08 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 50, 66 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/801168917020307456\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jQk4nRACcz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cx5S4jZUQAAvyIy.jpg",
      "id_str" : "801168915246104576",
      "id" : 801168915246104576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cx5S4jZUQAAvyIy.jpg",
      "sizes" : [ {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/jQk4nRACcz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jkFyYzmIn0",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/cx97b6ouL9v",
      "display_url" : "swarmapp.com\/c\/cx97b6ouL9v"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78042984007032, -122.51285084626193 ]
  },
  "id_str" : "801168917020307456",
  "text" : "And the next 99PI inspired stop. (@ Sutro Baths - @natlparkservice in San Francisco, CA) https:\/\/t.co\/jkFyYzmIn0 https:\/\/t.co\/jQk4nRACcz",
  "id" : 801168917020307456,
  "created_at" : "2016-11-22 21:02:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800870801993961472",
  "geo" : { },
  "id_str" : "800881037102354432",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto will try! :)",
  "id" : 800881037102354432,
  "in_reply_to_status_id" : 800870801993961472,
  "created_at" : "2016-11-22 01:58:13 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863395117285377",
  "text" : "RT @EmilyGorcenski: And we fought so goddamn hard. And we lost so badly just when we were on the verge of victory.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800860665925746688",
    "geo" : { },
    "id_str" : "800860917755834369",
    "in_reply_to_user_id" : 1483064670,
    "text" : "And we fought so goddamn hard. And we lost so badly just when we were on the verge of victory.",
    "id" : 800860917755834369,
    "in_reply_to_status_id" : 800860665925746688,
    "created_at" : "2016-11-22 00:38:16 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863395117285377,
  "created_at" : "2016-11-22 00:48:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863384384114688",
  "text" : "RT @EmilyGorcenski: Tech put these assholes in the White House. Tech did that. This is our community, this is who we walk amongst.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800860452397797377",
    "geo" : { },
    "id_str" : "800860665925746688",
    "in_reply_to_user_id" : 1483064670,
    "text" : "Tech put these assholes in the White House. Tech did that. This is our community, this is who we walk amongst.",
    "id" : 800860665925746688,
    "in_reply_to_status_id" : 800860452397797377,
    "created_at" : "2016-11-22 00:37:16 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863384384114688,
  "created_at" : "2016-11-22 00:48:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863372476444672",
  "text" : "RT @EmilyGorcenski: This is the dark, dirty work many of us have been doing for years. And you wonder why we're so tired.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800860322290692096",
    "geo" : { },
    "id_str" : "800860452397797377",
    "in_reply_to_user_id" : 1483064670,
    "text" : "This is the dark, dirty work many of us have been doing for years. And you wonder why we're so tired.",
    "id" : 800860452397797377,
    "in_reply_to_status_id" : 800860322290692096,
    "created_at" : "2016-11-22 00:36:25 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863372476444672,
  "created_at" : "2016-11-22 00:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863363622268928",
  "text" : "RT @EmilyGorcenski: Handling the death threats, building trusting relationships with people who can put you up in a storm and not mention i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800860165994151936",
    "geo" : { },
    "id_str" : "800860322290692096",
    "in_reply_to_user_id" : 1483064670,
    "text" : "Handling the death threats, building trusting relationships with people who can put you up in a storm and not mention it.",
    "id" : 800860322290692096,
    "in_reply_to_status_id" : 800860165994151936,
    "created_at" : "2016-11-22 00:35:54 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863363622268928,
  "created_at" : "2016-11-22 00:47:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863311952646144",
  "text" : "RT @EmilyGorcenski: But we rarely talk about the third shift... protecting yourself against the endless waves of harassment, the stalkers,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800860014353084419",
    "geo" : { },
    "id_str" : "800860165994151936",
    "in_reply_to_user_id" : 1483064670,
    "text" : "But we rarely talk about the third shift... protecting yourself against the endless waves of harassment, the stalkers, the nazis, the doxers",
    "id" : 800860165994151936,
    "in_reply_to_status_id" : 800860014353084419,
    "created_at" : "2016-11-22 00:35:17 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863311952646144,
  "created_at" : "2016-11-22 00:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863150434185217",
  "text" : "RT @EmilyGorcenski: And you've probably heard of second-shift work: the emotional labor that it takes to run meetups and women-in-tech grou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "800859849563181056",
    "geo" : { },
    "id_str" : "800860014353084419",
    "in_reply_to_user_id" : 1483064670,
    "text" : "And you've probably heard of second-shift work: the emotional labor that it takes to run meetups and women-in-tech groups and speaking, etc.",
    "id" : 800860014353084419,
    "in_reply_to_status_id" : 800859849563181056,
    "created_at" : "2016-11-22 00:34:41 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863150434185217,
  "created_at" : "2016-11-22 00:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800863139566784512",
  "text" : "RT @EmilyGorcenski: There are three shifts of work in the technology industry, when you're in it like I am. The first shift is your day-to-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "800859849563181056",
    "text" : "There are three shifts of work in the technology industry, when you're in it like I am. The first shift is your day-to-day work.",
    "id" : 800859849563181056,
    "created_at" : "2016-11-22 00:34:02 +0000",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 800863139566784512,
  "created_at" : "2016-11-22 00:47:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/PG7E138Dh5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNF7rX2DmAb\/",
      "display_url" : "instagram.com\/p\/BNF7rX2DmAb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6630291515, -121.257436904 ]
  },
  "id_str" : "800861872769605632",
  "text" : "And the guy who wanted to steal my coffee this morning. @ Elephant Seal Vista Point https:\/\/t.co\/PG7E138Dh5",
  "id" : 800861872769605632,
  "created_at" : "2016-11-22 00:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/7Q4SGyPBI6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNF5e9VDeXE\/",
      "display_url" : "instagram.com\/p\/BNF5e9VDeXE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.5206530789, -121.94076734 ]
  },
  "id_str" : "800857047747219456",
  "text" : "The guy who wanted to steal my breakfast. @ Whaler's Cove, Point Lobos Reserve https:\/\/t.co\/7Q4SGyPBI6",
  "id" : 800857047747219456,
  "created_at" : "2016-11-22 00:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/LKh6fo1qDN",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNF1gmUj3iD\/",
      "display_url" : "instagram.com\/p\/BNF1gmUj3iD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6630291515, -121.257436904 ]
  },
  "id_str" : "800848309602623488",
  "text" : "Cuddle Puddle @ Elephant Seal Vista Point https:\/\/t.co\/LKh6fo1qDN",
  "id" : 800848309602623488,
  "created_at" : "2016-11-21 23:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 3, 12 ],
      "id_str" : "176841064",
      "id" : 176841064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/yJrbCUcyyX",
      "expanded_url" : "https:\/\/www.theguardian.com\/higher-education-network\/2016\/nov\/08\/tef-dump-the-pointless-metrics-and-take-a-hard-look-at-casualisation?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/higher-educati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "800739417379872768",
  "text" : "RT @BeckPitt: \"Tef: dump the pointless metrics and take a hard look at casualisation\" https:\/\/t.co\/yJrbCUcyyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/yJrbCUcyyX",
        "expanded_url" : "https:\/\/www.theguardian.com\/higher-education-network\/2016\/nov\/08\/tef-dump-the-pointless-metrics-and-take-a-hard-look-at-casualisation?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/higher-educati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "800729557687013377",
    "text" : "\"Tef: dump the pointless metrics and take a hard look at casualisation\" https:\/\/t.co\/yJrbCUcyyX",
    "id" : 800729557687013377,
    "created_at" : "2016-11-21 15:56:18 +0000",
    "user" : {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "protected" : false,
      "id_str" : "176841064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871655655462940672\/LOaN4jAw_normal.jpg",
      "id" : 176841064,
      "verified" : false
    }
  },
  "id" : 800739417379872768,
  "created_at" : "2016-11-21 16:35:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800621494808154112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.61172138236618, -121.14072390559 ]
  },
  "id_str" : "800739191353024512",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das sieht nach tief fliegendem \uD83E\uDDC0 aus! \uD83D\uDE02",
  "id" : 800739191353024512,
  "in_reply_to_status_id" : 800621494808154112,
  "created_at" : "2016-11-21 16:34:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.61168925839999, -121.1407671869929 ]
  },
  "id_str" : "800575723643617280",
  "text" : "Since Wednesday I have been getting 8h of sleep every night, like a responsible adult. Don\u2019t know how many years ago that happened last.",
  "id" : 800575723643617280,
  "created_at" : "2016-11-21 05:45:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/y1bF6X1wE4",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNDlX27jk-h\/",
      "display_url" : "instagram.com\/p\/BNDlX27jk-h\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.4081685034, -119.878645487 ]
  },
  "id_str" : "800531349031354368",
  "text" : "Split seconds before my hiking boots were filled with water. @ Sands Beach https:\/\/t.co\/y1bF6X1wE4",
  "id" : 800531349031354368,
  "created_at" : "2016-11-21 02:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antje Krause",
      "screen_name" : "akkrause",
      "indices" : [ 0, 9 ],
      "id_str" : "154828510",
      "id" : 154828510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800223540997799936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.3661923669608, -120.8531234880172 ]
  },
  "id_str" : "800511370122797056",
  "in_reply_to_user_id" : 154828510,
  "text" : "@akkrause cool, wie lief es? :)",
  "id" : 800511370122797056,
  "in_reply_to_status_id" : 800223540997799936,
  "created_at" : "2016-11-21 01:29:18 +0000",
  "in_reply_to_screen_name" : "akkrause",
  "in_reply_to_user_id_str" : "154828510",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/vlAF9PbDvN",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNDcCooDwtx\/",
      "display_url" : "instagram.com\/p\/BNDcCooDwtx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "800510827564584960",
  "text" : "Sit &amp; Wait https:\/\/t.co\/vlAF9PbDvN",
  "id" : 800510827564584960,
  "created_at" : "2016-11-21 01:27:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/800502347747196929\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/INS174982E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cxv0pBPXgAAL8V7.jpg",
      "id_str" : "800502344333099008",
      "id" : 800502344333099008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cxv0pBPXgAAL8V7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/INS174982E"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/nV9zioxJ0o",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/3tUbMl9rVbC",
      "display_url" : "swarmapp.com\/c\/3tUbMl9rVbC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.3661562289674, -120.85312721647597 ]
  },
  "id_str" : "800502347747196929",
  "text" : "Tasty \uD83D\uDC36 treats! (@ Sun-N-Buns in Morro Bay, CA) https:\/\/t.co\/nV9zioxJ0o https:\/\/t.co\/INS174982E",
  "id" : 800502347747196929,
  "created_at" : "2016-11-21 00:53:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.27767910997782, -119.2695650552579 ]
  },
  "id_str" : "800412953392521216",
  "text" : "Hey San Francisco friends. I\u2019ll be in town starting Tuesday. Anyone up for meeting?",
  "id" : 800412953392521216,
  "created_at" : "2016-11-20 18:58:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Io8N7Bccep",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNBJ9GajxdM\/",
      "display_url" : "instagram.com\/p\/BNBJ9GajxdM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6715805556, -118.427236111 ]
  },
  "id_str" : "800189580506845185",
  "text" : "Leaving the smoke filled mountains. @ Lake Isabella https:\/\/t.co\/Io8N7Bccep",
  "id" : 800189580506845185,
  "created_at" : "2016-11-20 04:10:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaciteFood",
      "screen_name" : "TaciteFood",
      "indices" : [ 0, 11 ],
      "id_str" : "919511072683577344",
      "id" : 919511072683577344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799635385164898304",
  "geo" : { },
  "id_str" : "800180250147581952",
  "in_reply_to_user_id" : 3063744659,
  "text" : "@TaciteFood yes, you can register using whatever username comes to your mind, including random numbers. :)",
  "id" : 800180250147581952,
  "in_reply_to_status_id" : 799635385164898304,
  "created_at" : "2016-11-20 03:33:32 +0000",
  "in_reply_to_screen_name" : "TaciteData",
  "in_reply_to_user_id_str" : "3063744659",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/vClWJVjY5f",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNAgYvYjbfl\/",
      "display_url" : "instagram.com\/p\/BNAgYvYjbfl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "800098171183595520",
  "text" : "Roadtripping further. After Sequoia was cancelled due to wild fires. https:\/\/t.co\/vClWJVjY5f",
  "id" : 800098171183595520,
  "created_at" : "2016-11-19 22:07:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/MBqDbIfRT5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BNAdP4wDzoW\/",
      "display_url" : "instagram.com\/p\/BNAdP4wDzoW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.1342756367, -116.315510246 ]
  },
  "id_str" : "800091269875847172",
  "text" : "Blooming #latergram @ Joshua Tree National Park https:\/\/t.co\/MBqDbIfRT5",
  "id" : 800091269875847172,
  "created_at" : "2016-11-19 21:39:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "800085642705154048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.64594333063405, -118.4655905050397 ]
  },
  "id_str" : "800087658395406336",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy nope, probably not :(",
  "id" : 800087658395406336,
  "in_reply_to_status_id" : 800085642705154048,
  "created_at" : "2016-11-19 21:25:37 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/TBUClMlZAR",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM_0lxLDx0h\/",
      "display_url" : "instagram.com\/p\/BM_0lxLDx0h\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.7339063, -115.7991589 ]
  },
  "id_str" : "800001861629706240",
  "text" : "Pointy @ Mastodon Peak https:\/\/t.co\/TBUClMlZAR",
  "id" : 800001861629706240,
  "created_at" : "2016-11-19 15:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.61481761584979, -117.6707104578065 ]
  },
  "id_str" : "800000118690705408",
  "text" : "Last nights adventure: Following an unmarked dirt road next to the train tracks to get around a huge traffic jam.",
  "id" : 800000118690705408,
  "created_at" : "2016-11-19 15:37:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799846321050054656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.61420464757288, -117.6706545750225 ]
  },
  "id_str" : "799970934392164353",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 I thought I had spotted him, but it was just some garbage caught in a bush. :p",
  "id" : 799970934392164353,
  "in_reply_to_status_id" : 799846321050054656,
  "created_at" : "2016-11-19 13:41:48 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/3i6GQsIpY1",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM-ruvzDbyj\/",
      "display_url" : "instagram.com\/p\/BM-ruvzDbyj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.1342756367, -116.315510246 ]
  },
  "id_str" : "799841642593271809",
  "text" : "In search of the woman of the year @ Joshua Tree National Park https:\/\/t.co\/3i6GQsIpY1",
  "id" : 799841642593271809,
  "created_at" : "2016-11-19 05:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799692455603892224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.23175734470993, -116.4400426671993 ]
  },
  "id_str" : "799780560906387457",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes that\u2019s what I always suspected!",
  "id" : 799780560906387457,
  "in_reply_to_status_id" : 799692455603892224,
  "created_at" : "2016-11-19 01:05:19 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    }, {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 17, 26 ],
      "id_str" : "621133833",
      "id" : 621133833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799641831671635968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72809849996685, -116.2313130584706 ]
  },
  "id_str" : "799641957332959234",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan @april_cs \uD83D\uDE0A\uD83D\uDC96",
  "id" : 799641957332959234,
  "in_reply_to_status_id" : 799641831671635968,
  "created_at" : "2016-11-18 15:54:33 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72809242946082, -116.2312621796617 ]
  },
  "id_str" : "799640442526535681",
  "text" : "Americans, I always wondered, with a fixed-wall \uD83D\uDEBF: 1. how do you wash your hair if you\u2019re &gt;160cm 2. how do you wash your genitals?",
  "id" : 799640442526535681,
  "created_at" : "2016-11-18 15:48:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 0, 9 ],
      "id_str" : "621133833",
      "id" : 621133833
    }, {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 10, 26 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799630586067308545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72814752377182, -116.2314695990733 ]
  },
  "id_str" : "799639435432239104",
  "in_reply_to_user_id" : 621133833,
  "text" : "@april_cs @RadicevSlobodan I think mostly skeptical of the photographer :p",
  "id" : 799639435432239104,
  "in_reply_to_status_id" : 799630586067308545,
  "created_at" : "2016-11-18 15:44:32 +0000",
  "in_reply_to_screen_name" : "april_cs",
  "in_reply_to_user_id_str" : "621133833",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/rbNDxjjP90",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM7zTG1D41k\/",
      "display_url" : "instagram.com\/p\/BM7zTG1D41k\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.3256328571, -115.917067143 ]
  },
  "id_str" : "799436073776644096",
  "text" : "Landlocked @ Salton Sea, CA https:\/\/t.co\/rbNDxjjP90",
  "id" : 799436073776644096,
  "created_at" : "2016-11-18 02:16:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/d84hfW7gFz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM7ygxxD4Rz\/",
      "display_url" : "instagram.com\/p\/BM7ygxxD4Rz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.333, -115.834 ]
  },
  "id_str" : "799434342002999296",
  "text" : "Dead things like to wash up here it seems. @ Salton Sea https:\/\/t.co\/d84hfW7gFz",
  "id" : 799434342002999296,
  "created_at" : "2016-11-18 02:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799318405727813632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72783892493312, -116.2317039186703 ]
  },
  "id_str" : "799431236124971008",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette I\u2019ll sleep badly tonight!",
  "id" : 799431236124971008,
  "in_reply_to_status_id" : 799318405727813632,
  "created_at" : "2016-11-18 01:57:14 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 12, 21 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 22, 35 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799325717733380096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72800433545721, -116.2315736712108 ]
  },
  "id_str" : "799431169896914944",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @MsPhelps @jeroenbosman will do. So far seems it\u2019s more CA than OR. :)",
  "id" : 799431169896914944,
  "in_reply_to_status_id" : 799325717733380096,
  "created_at" : "2016-11-18 01:56:58 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 40, 50 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/799431086358921216\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bkqcwJZ6xi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxgmVCCUkAEj_cK.jpg",
      "id_str" : "799431076623978497",
      "id" : 799431076623978497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxgmVCCUkAEj_cK.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bkqcwJZ6xi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.72803702487958, -116.2315507047961 ]
  },
  "id_str" : "799431086358921216",
  "text" : "Spent the day at the Salton Sea. Thanks @romanmars! \uD83C\uDF0A https:\/\/t.co\/bkqcwJZ6xi",
  "id" : 799431086358921216,
  "created_at" : "2016-11-18 01:56:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/JuJtO1uARA",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798144393823842304",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "799265257143209986",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.75004206439549, -117.1595905769234 ]
  },
  "id_str" : "799317175387308032",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette let\u2019s say virtually no one then. And it just started as a joke! https:\/\/t.co\/JuJtO1uARA",
  "id" : 799317175387308032,
  "in_reply_to_status_id" : 799265257143209986,
  "created_at" : "2016-11-17 18:23:59 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799238854729285634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.75012981149624, -117.159463511889 ]
  },
  "id_str" : "799263215746060288",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics thanks! \uD83D\uDE0D",
  "id" : 799263215746060288,
  "in_reply_to_status_id" : 799238854729285634,
  "created_at" : "2016-11-17 14:49:34 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799123384164564992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.75008071172816, -117.1594810704146 ]
  },
  "id_str" : "799133860755738624",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps thanks, will do! :)",
  "id" : 799133860755738624,
  "in_reply_to_status_id" : 799123384164564992,
  "created_at" : "2016-11-17 06:15:34 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/799060381473783808\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/rbwcf9YrXL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxbVLoRVEAAmKPT.jpg",
      "id_str" : "799060379670220800",
      "id" : 799060379670220800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxbVLoRVEAAmKPT.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 270
      } ],
      "display_url" : "pic.twitter.com\/rbwcf9YrXL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wgcRWGfYlR",
      "expanded_url" : "http:\/\/amzn.to\/2fyqDM1",
      "display_url" : "amzn.to\/2fyqDM1"
    } ]
  },
  "geo" : { },
  "id_str" : "799060381473783808",
  "text" : "\u00ABThe rise of feminist underpants is a weird twist on Marx\u2019s theory of commodity fetishism\u2026\u00BB https:\/\/t.co\/wgcRWGfYlR https:\/\/t.co\/rbwcf9YrXL",
  "id" : 799060381473783808,
  "created_at" : "2016-11-17 01:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hend Amry",
      "screen_name" : "LibyaLiberty",
      "indices" : [ 3, 16 ],
      "id_str" : "254873869",
      "id" : 254873869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799052334936375296",
  "text" : "RT @LibyaLiberty: I say if a Nazi-inspired religious registry happens, no one registers in a concerted, loud, nation-wide movement of civil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/tFk6SCEYw5",
        "expanded_url" : "https:\/\/twitter.com\/kejames\/status\/799018434029875205",
        "display_url" : "twitter.com\/kejames\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "799036159863259136",
    "text" : "I say if a Nazi-inspired religious registry happens, no one registers in a concerted, loud, nation-wide movement of civil disobedience. https:\/\/t.co\/tFk6SCEYw5",
    "id" : 799036159863259136,
    "created_at" : "2016-11-16 23:47:20 +0000",
    "user" : {
      "name" : "Hend Amry",
      "screen_name" : "LibyaLiberty",
      "protected" : false,
      "id_str" : "254873869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928314233103695873\/wOsazuD5_normal.jpg",
      "id" : 254873869,
      "verified" : true
    }
  },
  "id" : 799052334936375296,
  "created_at" : "2016-11-17 00:51:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 12, 21 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 22, 35 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799046905019789312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.33926390393948, -117.5076867454848 ]
  },
  "id_str" : "799047954082336769",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @MsPhelps @jeroenbosman yes, renting a \uD83D\uDE97 tomorrow and heading north. Going out from SFO, but might even go to PDX.",
  "id" : 799047954082336769,
  "in_reply_to_status_id" : 799046905019789312,
  "created_at" : "2016-11-17 00:34:12 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 32, 41 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 42, 55 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/t1q93zlLtR",
      "expanded_url" : "https:\/\/instagram.com\/p\/BM5CE3aDGQF\/",
      "display_url" : "instagram.com\/p\/BM5CE3aDGQF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.38255303914973, -117.5837685262017 ]
  },
  "id_str" : "799046672915386368",
  "text" : "Hey Pacific, there we go again. @MsPhelps @jeroenbosman you were totally right. \uD83D\uDE88\uD83D\uDC96 https:\/\/t.co\/t1q93zlLtR",
  "id" : 799046672915386368,
  "created_at" : "2016-11-17 00:29:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 12, 21 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 22, 35 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799038690416701440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.65723173602824, -117.7332123276943 ]
  },
  "id_str" : "799038817311170560",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @MsPhelps @jeroenbosman no, left for LAX first thing this morning. :)",
  "id" : 799038817311170560,
  "in_reply_to_status_id" : 799038690416701440,
  "created_at" : "2016-11-16 23:57:54 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Wollgarten",
      "screen_name" : "Zwiespaeltig",
      "indices" : [ 0, 13 ],
      "id_str" : "60676898",
      "id" : 60676898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799030864994848768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.86854567568178, -117.9225216341372 ]
  },
  "id_str" : "799031522313408512",
  "in_reply_to_user_id" : 60676898,
  "text" : "@Zwiespaeltig Ja, also letzte Woche von FRA \u2708\uFE0F KEF \u2708\uFE0F BWI, bis heute in DC gewesen und jetzt hier :)",
  "id" : 799031522313408512,
  "in_reply_to_status_id" : 799030864994848768,
  "created_at" : "2016-11-16 23:28:54 +0000",
  "in_reply_to_screen_name" : "Zwiespaeltig",
  "in_reply_to_user_id_str" : "60676898",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Wollgarten",
      "screen_name" : "Zwiespaeltig",
      "indices" : [ 0, 13 ],
      "id_str" : "60676898",
      "id" : 60676898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799029728048979968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.87261441911932, -117.9701764417048 ]
  },
  "id_str" : "799030283408273408",
  "in_reply_to_user_id" : 60676898,
  "text" : "@Zwiespaeltig bis morgen vermutlich. Dann mit \uD83D\uDE97 irgendwo entlang Richtung Norden. Am 26. geht es dann von SFO \u2708\uFE0F KEF \u2708\uFE0F FRA.",
  "id" : 799030283408273408,
  "in_reply_to_status_id" : 799029728048979968,
  "created_at" : "2016-11-16 23:23:59 +0000",
  "in_reply_to_screen_name" : "Zwiespaeltig",
  "in_reply_to_user_id_str" : "60676898",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Wollgarten",
      "screen_name" : "Zwiespaeltig",
      "indices" : [ 0, 13 ],
      "id_str" : "60676898",
      "id" : 60676898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799027050858369025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.98758659608102, -118.1342055090872 ]
  },
  "id_str" : "799027098316771328",
  "in_reply_to_user_id" : 60676898,
  "text" : "@Zwiespaeltig yep!",
  "id" : 799027098316771328,
  "in_reply_to_status_id" : 799027050858369025,
  "created_at" : "2016-11-16 23:11:20 +0000",
  "in_reply_to_screen_name" : "Zwiespaeltig",
  "in_reply_to_user_id_str" : "60676898",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 68, 77 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 82, 95 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.05866324904753, -118.2333690394817 ]
  },
  "id_str" : "799024632930017284",
  "text" : "On the train to San Diego. Super excited, after all the praise that @MsPhelps and @jeroenbosman had for this route!",
  "id" : 799024632930017284,
  "created_at" : "2016-11-16 23:01:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Reinhardt",
      "screen_name" : "Enigma424",
      "indices" : [ 0, 10 ],
      "id_str" : "24397949",
      "id" : 24397949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799014253629816832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.05627585955278, -118.2361101153286 ]
  },
  "id_str" : "799014346441441280",
  "in_reply_to_user_id" : 24397949,
  "text" : "@Enigma424 oof, wie doof. \uD83D\uDE1E",
  "id" : 799014346441441280,
  "in_reply_to_status_id" : 799014253629816832,
  "created_at" : "2016-11-16 22:20:39 +0000",
  "in_reply_to_screen_name" : "Enigma424",
  "in_reply_to_user_id_str" : "24397949",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily F",
      "screen_name" : "femilyr",
      "indices" : [ 3, 11 ],
      "id_str" : "732243",
      "id" : 732243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "progress",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "799011282259046400",
  "text" : "RT @femilyr: Swedish Union sets up a hotline for workers to report mansplaining. Only needed this once during #opencon #progress https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "progress",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/M5DFJyCegb",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/11\/17\/world\/europe\/mansplaining-hotline-swedish-union.html",
        "display_url" : "nytimes.com\/2016\/11\/17\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798982657132498944",
    "text" : "Swedish Union sets up a hotline for workers to report mansplaining. Only needed this once during #opencon #progress https:\/\/t.co\/M5DFJyCegb",
    "id" : 798982657132498944,
    "created_at" : "2016-11-16 20:14:44 +0000",
    "user" : {
      "name" : "Emily F",
      "screen_name" : "femilyr",
      "protected" : false,
      "id_str" : "732243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466754453643608065\/SsJicjYf_normal.jpeg",
      "id" : 732243,
      "verified" : false
    }
  },
  "id" : 799011282259046400,
  "created_at" : "2016-11-16 22:08:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabio Reinhardt",
      "screen_name" : "Enigma424",
      "indices" : [ 0, 10 ],
      "id_str" : "24397949",
      "id" : 24397949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798957337826312192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0561749412562, -118.236468784519 ]
  },
  "id_str" : "799008973965799424",
  "in_reply_to_user_id" : 24397949,
  "text" : "@Enigma424 Anschluss verpasst? :(",
  "id" : 799008973965799424,
  "in_reply_to_status_id" : 798957337826312192,
  "created_at" : "2016-11-16 21:59:18 +0000",
  "in_reply_to_screen_name" : "Enigma424",
  "in_reply_to_user_id_str" : "24397949",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798962985565765632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.05629067446593, -118.2363980946984 ]
  },
  "id_str" : "799008301820166144",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr that sucks. So far everything else has worked out on this trip. Will be in SAN at 6pm-ish.",
  "id" : 799008301820166144,
  "in_reply_to_status_id" : 798962985565765632,
  "created_at" : "2016-11-16 21:56:38 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/bg9n1eyCpS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM4wGN9DgV0\/",
      "display_url" : "instagram.com\/p\/BM4wGN9DgV0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.0561385913, -118.235164157 ]
  },
  "id_str" : "799006819561721860",
  "text" : "Getting my ticket to the off-world colonies. @ Union Station Dowtown LA https:\/\/t.co\/bg9n1eyCpS",
  "id" : 799006819561721860,
  "created_at" : "2016-11-16 21:50:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/yzYefoVguu",
      "expanded_url" : "https:\/\/twitter.com\/blueyedgenes\/status\/794282309184679936",
      "display_url" : "twitter.com\/blueyedgenes\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799005911272427520",
  "text" : "Mentions our work with openSNP \uD83C\uDF89\uD83D\uDE0D https:\/\/t.co\/yzYefoVguu",
  "id" : 799005911272427520,
  "created_at" : "2016-11-16 21:47:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/AK5rggXtQr",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798997963401891841",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "798997963401891841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.05068686235142, -118.2475446817635 ]
  },
  "id_str" : "798998278306050048",
  "in_reply_to_user_id" : 14286491,
  "text" : "@JP_Stich \uD83D\uDE0D\uD83D\uDC22\uD83C\uDF35\uD83C\uDFDC https:\/\/t.co\/AK5rggXtQr",
  "id" : 798998278306050048,
  "in_reply_to_status_id" : 798997963401891841,
  "created_at" : "2016-11-16 21:16:48 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Pq5leZ4xVc",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM4sEeyj19t\/",
      "display_url" : "instagram.com\/p\/BM4sEeyj19t\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 34.050526, -118.247834 ]
  },
  "id_str" : "798997963401891841",
  "text" : "And another thing is off the bucket list. @ Bradbury Building https:\/\/t.co\/Pq5leZ4xVc",
  "id" : 798997963401891841,
  "created_at" : "2016-11-16 21:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/e3Kq7XKYAF",
      "expanded_url" : "https:\/\/twitter.com\/helgerausch\/status\/798928213351301120",
      "display_url" : "twitter.com\/helgerausch\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.94539849758399, -118.3995216486548 ]
  },
  "id_str" : "798959771474759680",
  "text" : "Look who\u2019s there, @Protohedgehog! https:\/\/t.co\/e3Kq7XKYAF",
  "id" : 798959771474759680,
  "created_at" : "2016-11-16 18:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/UQBFnxLJai",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798947342757920768",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "798947342757920768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.93632478857415, -118.4208609140518 ]
  },
  "id_str" : "798957185854124032",
  "in_reply_to_user_id" : 14286491,
  "text" : "Which is completely useless if you then have to wait for 1+ hour on the tarmac as there\u2019s no free gate. \uD83D\uDE1E https:\/\/t.co\/UQBFnxLJai",
  "id" : 798957185854124032,
  "in_reply_to_status_id" : 798947342757920768,
  "created_at" : "2016-11-16 18:33:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.93725326753588, -118.4243371245623 ]
  },
  "id_str" : "798947342757920768",
  "text" : "Hey LAX. That was a quick ride, 45 minutes early!",
  "id" : 798947342757920768,
  "created_at" : "2016-11-16 17:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "it's not me it's you",
      "screen_name" : "DiaKayyali",
      "indices" : [ 3, 14 ],
      "id_str" : "846270619",
      "id" : 846270619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/EcBwqK34HQ",
      "expanded_url" : "https:\/\/twitter.com\/transrelief\/status\/797903394908188672",
      "display_url" : "twitter.com\/transrelief\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798862478679666688",
  "text" : "RT @DiaKayyali: Little bit of love for those of us who CAN'T get our gender on our passports https:\/\/t.co\/EcBwqK34HQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/EcBwqK34HQ",
        "expanded_url" : "https:\/\/twitter.com\/transrelief\/status\/797903394908188672",
        "display_url" : "twitter.com\/transrelief\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798793612112760832",
    "text" : "Little bit of love for those of us who CAN'T get our gender on our passports https:\/\/t.co\/EcBwqK34HQ",
    "id" : 798793612112760832,
    "created_at" : "2016-11-16 07:43:32 +0000",
    "user" : {
      "name" : "it's not me it's you",
      "screen_name" : "DiaKayyali",
      "protected" : false,
      "id_str" : "846270619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436420989182681088\/WKEj-tUh_normal.jpeg",
      "id" : 846270619,
      "verified" : false
    }
  },
  "id" : 798862478679666688,
  "created_at" : "2016-11-16 12:17:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/jOF3UM1frk",
      "expanded_url" : "https:\/\/twitter.com\/SDawsonBerlin\/status\/798804560106004482",
      "display_url" : "twitter.com\/SDawsonBerlin\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.17821969238967, -76.6674119868695 ]
  },
  "id_str" : "798861248960020480",
  "text" : "Read about me going all hippie on open*. https:\/\/t.co\/jOF3UM1frk",
  "id" : 798861248960020480,
  "created_at" : "2016-11-16 12:12:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9143159753074, -77.01734544716497 ]
  },
  "id_str" : "798827538491416576",
  "text" : "Who thought it was a good idea to get a 07:25am flight from BWI?! Oh, that\u2019d be me. \uD83D\uDE34\uD83D\uDCA4",
  "id" : 798827538491416576,
  "created_at" : "2016-11-16 09:58:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "highlando",
      "screen_name" : "jnhlnd",
      "indices" : [ 0, 7 ],
      "id_str" : "914320717",
      "id" : 914320717
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798784511097999360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9166459669796, -77.02290763834317 ]
  },
  "id_str" : "798825261424742400",
  "in_reply_to_user_id" : 914320717,
  "text" : "@jnhlnd @Protohedgehog too late, they are already posted :)",
  "id" : 798825261424742400,
  "in_reply_to_status_id" : 798784511097999360,
  "created_at" : "2016-11-16 09:49:18 +0000",
  "in_reply_to_screen_name" : "jnhlnd",
  "in_reply_to_user_id_str" : "914320717",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798721224411152384\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/bR95R1tKRW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxWguFfXgAAO-Ti.jpg",
      "id_str" : "798721222536298496",
      "id" : 798721222536298496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxWguFfXgAAO-Ti.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 88
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 133
      }, {
        "h" : 133,
        "resize" : "crop",
        "w" : 133
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 133
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 133
      } ],
      "display_url" : "pic.twitter.com\/bR95R1tKRW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798721224411152384",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog I think we did okay. https:\/\/t.co\/bR95R1tKRW",
  "id" : 798721224411152384,
  "created_at" : "2016-11-16 02:55:54 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/pABRJTPbJ6",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/7Jkv02RLFYj6M\/200.gif",
      "display_url" : "media4.giphy.com\/media\/7Jkv02RL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "798690271735279617",
  "geo" : { },
  "id_str" : "798692556515250176",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha safe travels! https:\/\/t.co\/pABRJTPbJ6",
  "id" : 798692556515250176,
  "in_reply_to_status_id" : 798690271735279617,
  "created_at" : "2016-11-16 01:01:59 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 63, 77 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798665547294633984\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NdSvF3IE9M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxVuE82WIAAvgg1.jpg",
      "id_str" : "798665540260732928",
      "id" : 798665540260732928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxVuE82WIAAvgg1.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/NdSvF3IE9M"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91662060310004, -77.02362583250012 ]
  },
  "id_str" : "798665547294633984",
  "text" : "Let\u2019s do crowdfunding they said. It will be fun they said. Now @Protohedgehog\u2019s and my wrists hurt so much! #opencon https:\/\/t.co\/NdSvF3IE9M",
  "id" : 798665547294633984,
  "created_at" : "2016-11-15 23:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 0, 10 ],
      "id_str" : "248717660",
      "id" : 248717660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798656702413348864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91669071883584, -77.0236081342335 ]
  },
  "id_str" : "798662073743998976",
  "in_reply_to_user_id" : 248717660,
  "text" : "@operkovic when I tried to explain the flag to that person they totally drew a blank.",
  "id" : 798662073743998976,
  "in_reply_to_status_id" : 798656702413348864,
  "created_at" : "2016-11-15 23:00:51 +0000",
  "in_reply_to_screen_name" : "operkovic",
  "in_reply_to_user_id_str" : "248717660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798653950714986496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91665572608316, -77.02363034502633 ]
  },
  "id_str" : "798656155987779584",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb very much so.",
  "id" : 798656155987779584,
  "in_reply_to_status_id" : 798653950714986496,
  "created_at" : "2016-11-15 22:37:20 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 0, 10 ],
      "id_str" : "248717660",
      "id" : 248717660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798651196164767744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91665270714971, -77.02366538922709 ]
  },
  "id_str" : "798653987067084801",
  "in_reply_to_user_id" : 248717660,
  "text" : "@operkovic yes \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
  "id" : 798653987067084801,
  "in_reply_to_status_id" : 798651196164767744,
  "created_at" : "2016-11-15 22:28:43 +0000",
  "in_reply_to_screen_name" : "operkovic",
  "in_reply_to_user_id_str" : "248717660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798647751999262720\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/DFEZzjKyJr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxVd5cDUAAANAzW.jpg",
      "id_str" : "798647750292144128",
      "id" : 798647750292144128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxVd5cDUAAANAzW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/DFEZzjKyJr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798647751999262720",
  "text" : "My reaction when the postcard seller said \u00ABYou're from Germany, aren't you? I recognized the flag on your chest.\u00BB https:\/\/t.co\/DFEZzjKyJr",
  "id" : 798647751999262720,
  "created_at" : "2016-11-15 22:03:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/6qaXvgWdut",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798613909183885312",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "798613909183885312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89600408790635, -77.04238668580176 ]
  },
  "id_str" : "798632699951009793",
  "in_reply_to_user_id" : 14286491,
  "text" : "So moving to see the next generation take the streets. It wasn\u2019t only me who became all weepy. Many bystanders who saw the march as well. https:\/\/t.co\/6qaXvgWdut",
  "id" : 798632699951009793,
  "in_reply_to_status_id" : 798613909183885312,
  "created_at" : "2016-11-15 21:04:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Stewart",
      "screen_name" : "BioStew",
      "indices" : [ 0, 8 ],
      "id_str" : "221032511",
      "id" : 221032511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798625988183736321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89599988240646, -77.04236073426627 ]
  },
  "id_str" : "798627365991710721",
  "in_reply_to_user_id" : 221032511,
  "text" : "@BioStew unfortunately not really, for the chord diagram I just googled \u201Cchord diagram R\u201D, for the network I read the Gephi-how-tos.",
  "id" : 798627365991710721,
  "in_reply_to_status_id" : 798625988183736321,
  "created_at" : "2016-11-15 20:42:56 +0000",
  "in_reply_to_screen_name" : "BioStew",
  "in_reply_to_user_id_str" : "221032511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798622076051619840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89871972616659, -77.03743544414364 ]
  },
  "id_str" : "798622558023192576",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner @Protohedgehog we\u2019ve already been taken for teachers. :D",
  "id" : 798622558023192576,
  "in_reply_to_status_id" : 798622076051619840,
  "created_at" : "2016-11-15 20:23:50 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 4, 18 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/90cPR1NkxN",
      "expanded_url" : "https:\/\/twitter.com\/CameraCrazyFox5\/status\/798585867724066816",
      "display_url" : "twitter.com\/CameraCrazyFox\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8954357384135, -77.03987298540495 ]
  },
  "id_str" : "798620589225222144",
  "text" : "See @Protohedgehog and me fulfill our #opencon crowdfunding perks. \uD83D\uDE02 https:\/\/t.co\/90cPR1NkxN",
  "id" : 798620589225222144,
  "created_at" : "2016-11-15 20:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 59, 73 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89518796935575, -77.04578390352152 ]
  },
  "id_str" : "798618852271734784",
  "text" : "\u00ABNice how you scaled that barricade, German Ninja.\u00BB I feel @Protohedgehog is not taking me serious.",
  "id" : 798618852271734784,
  "created_at" : "2016-11-15 20:09:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/aX4542mzbO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM19bCKj3oq\/",
      "display_url" : "instagram.com\/p\/BM19bCKj3oq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.889444, -77.050278 ]
  },
  "id_str" : "798613909183885312",
  "text" : "Highschool Students from all Public schools sit-in against Trump. @ Lincoln Memorial https:\/\/t.co\/aX4542mzbO",
  "id" : 798613909183885312,
  "created_at" : "2016-11-15 19:49:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 0, 10 ],
      "id_str" : "248717660",
      "id" : 248717660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798607875945955329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.88967477254466, -77.03558505519948 ]
  },
  "id_str" : "798608656287809536",
  "in_reply_to_user_id" : 248717660,
  "text" : "@operkovic thanks, will do!",
  "id" : 798608656287809536,
  "in_reply_to_status_id" : 798607875945955329,
  "created_at" : "2016-11-15 19:28:35 +0000",
  "in_reply_to_screen_name" : "operkovic",
  "in_reply_to_user_id_str" : "248717660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/OCrCvJc2WJ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM15m1FjyxL\/",
      "display_url" : "instagram.com\/p\/BM15m1FjyxL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89, -77.0236111111 ]
  },
  "id_str" : "798605518008774656",
  "text" : "Phallocracy @ The Mall (Washington DC) https:\/\/t.co\/OCrCvJc2WJ",
  "id" : 798605518008774656,
  "created_at" : "2016-11-15 19:16:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Nx6y8qFuWe",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM12XKqjTg5\/",
      "display_url" : "instagram.com\/p\/BM12XKqjTg5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8887862759, -77.0058374956 ]
  },
  "id_str" : "798598383854292992",
  "text" : "The #opencon librarians should love it. @ The Library of Congress https:\/\/t.co\/Nx6y8qFuWe",
  "id" : 798598383854292992,
  "created_at" : "2016-11-15 18:47:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/2Unh35Zn8Z",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM11BMFj-zP\/",
      "display_url" : "instagram.com\/p\/BM11BMFj-zP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8905555556, -77.0044444444 ]
  },
  "id_str" : "798595429378068480",
  "text" : "Standing together @ Supreme Court of the United States https:\/\/t.co\/2Unh35Zn8Z",
  "id" : 798595429378068480,
  "created_at" : "2016-11-15 18:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/eBSzKrZdq0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BM1zkmljUbr\/",
      "display_url" : "instagram.com\/p\/BM1zkmljUbr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.8921651589, -77.0175919107 ]
  },
  "id_str" : "798592248677945345",
  "text" : "That sightseeing turned political rather quickly. @ The Capital Building, Washington DC https:\/\/t.co\/eBSzKrZdq0",
  "id" : 798592248677945345,
  "created_at" : "2016-11-15 18:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798585891274956801\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/JoR6DdidjD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxUlooiUsAA3gru.jpg",
      "id_str" : "798585888934506496",
      "id" : 798585888934506496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxUlooiUsAA3gru.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JoR6DdidjD"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798585891274956801",
  "text" : "I guess we found out where we'll shoot our video. #opencon https:\/\/t.co\/JoR6DdidjD",
  "id" : 798585891274956801,
  "created_at" : "2016-11-15 17:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798575663397699584\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pXaFQTJNR2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CxUcUsxWEAABZan.jpg",
      "id_str" : "798575650869219328",
      "id" : 798575650869219328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CxUcUsxWEAABZan.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 418
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 418
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 418
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 418
      } ],
      "display_url" : "pic.twitter.com\/pXaFQTJNR2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798575663397699584",
  "text" : "\u00ABSorry for sending the cute dog picture twice.\u00BB \u2014 \u00ABYou can send that as often as you like. Infinite puppy loop!\u00BB https:\/\/t.co\/pXaFQTJNR2",
  "id" : 798575663397699584,
  "created_at" : "2016-11-15 17:17:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/ngfy518NxQ",
      "expanded_url" : "https:\/\/twitter.com\/froggleston\/status\/798530591385911296",
      "display_url" : "twitter.com\/froggleston\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89726638797568, -77.02380822978637 ]
  },
  "id_str" : "798574862868606976",
  "text" : "Awesome, that\u2019s how I\u2019d feel. https:\/\/t.co\/ngfy518NxQ",
  "id" : 798574862868606976,
  "created_at" : "2016-11-15 17:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Stewart",
      "screen_name" : "BioStew",
      "indices" : [ 0, 8 ],
      "id_str" : "221032511",
      "id" : 221032511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798531185077080065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89725109636621, -77.02380362246673 ]
  },
  "id_str" : "798570224501092353",
  "in_reply_to_user_id" : 221032511,
  "text" : "@BioStew glad you like them!",
  "id" : 798570224501092353,
  "in_reply_to_status_id" : 798531185077080065,
  "created_at" : "2016-11-15 16:55:52 +0000",
  "in_reply_to_screen_name" : "BioStew",
  "in_reply_to_user_id_str" : "221032511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798346096162603012",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.89738632147745, -77.020294040881 ]
  },
  "id_str" : "798567155348410368",
  "in_reply_to_user_id" : 14286491,
  "text" : "Are there any people left in DC who\u2019d like to be our crowdfunding-reward video directors? #opencon",
  "id" : 798567155348410368,
  "in_reply_to_status_id" : 798346096162603012,
  "created_at" : "2016-11-15 16:43:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 7, 16 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 79, 92 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/798526074548273152\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/nM0tY3Swbr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxTvOycXAAAWXOi.jpg",
      "id_str" : "798526071289348096",
      "id" : 798526071289348096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxTvOycXAAAWXOi.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nM0tY3Swbr"
    } ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 56, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798526074548273152",
  "text" : "Thanks @MsPhelps for doing further visualisation of the #scienceisglobal data! @royalsociety https:\/\/t.co\/2B3nwjPmxa https:\/\/t.co\/nM0tY3Swbr",
  "id" : 798526074548273152,
  "created_at" : "2016-11-15 14:00:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798498248809910272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91664737665852, -77.02367426512252 ]
  },
  "id_str" : "798514042709180416",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen see you in SF!",
  "id" : 798514042709180416,
  "in_reply_to_status_id" : 798498248809910272,
  "created_at" : "2016-11-15 13:12:38 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798444639355338752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91670610772091, -77.02365304834282 ]
  },
  "id_str" : "798444858759380992",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \uD83D\uDC96\uD83D\uDC96\uD83D\uDC96\uD83D\uDC96",
  "id" : 798444858759380992,
  "in_reply_to_status_id" : 798444639355338752,
  "created_at" : "2016-11-15 08:37:43 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798443788372942848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91670610772091, -77.02365304834282 ]
  },
  "id_str" : "798443940584235009",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen gif? ;)",
  "id" : 798443940584235009,
  "in_reply_to_status_id" : 798443788372942848,
  "created_at" : "2016-11-15 08:34:04 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 15, 22 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798438882257862656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91666426154339, -77.02366601646447 ]
  },
  "id_str" : "798439049090531328",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @Koalha thanks, good night from this side for now!",
  "id" : 798439049090531328,
  "in_reply_to_status_id" : 798438882257862656,
  "created_at" : "2016-11-15 08:14:38 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 15, 22 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798435779815108608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91665925567513, -77.02367327054424 ]
  },
  "id_str" : "798438397643735040",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @Koalha happy to do so. And thanks for the link! \uD83D\uDC96 we should also \uD83D\uDCDE when I\u2019m back in the EU! \uD83D\uDE0A",
  "id" : 798438397643735040,
  "in_reply_to_status_id" : 798435779815108608,
  "created_at" : "2016-11-15 08:12:02 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uA9C1Terence Eden\uA9C2 \u23FB",
      "screen_name" : "edent",
      "indices" : [ 3, 9 ],
      "id_str" : "14054507",
      "id" : 14054507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798432734511321088",
  "text" : "RT @edent: \u25FEDoes your hackathon need a Code of Conduct? (YES!)\n\u25FDWant an easy to use, easy to read CoC?\n\uD83D\uDD38Want to contribute?\n\n\uD83D\uDD39 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fKi1U5JIkN",
        "expanded_url" : "https:\/\/hackcodeofconduct.org\/",
        "display_url" : "hackcodeofconduct.org"
      } ]
    },
    "geo" : { },
    "id_str" : "798430231673585669",
    "text" : "\u25FEDoes your hackathon need a Code of Conduct? (YES!)\n\u25FDWant an easy to use, easy to read CoC?\n\uD83D\uDD38Want to contribute?\n\n\uD83D\uDD39 https:\/\/t.co\/fKi1U5JIkN",
    "id" : 798430231673585669,
    "created_at" : "2016-11-15 07:39:36 +0000",
    "user" : {
      "name" : "\uA9C1Terence Eden\uA9C2 \u23FB",
      "screen_name" : "edent",
      "protected" : false,
      "id_str" : "14054507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785312424031293440\/ilDkJR5W_normal.jpg",
      "id" : 14054507,
      "verified" : true
    }
  },
  "id" : 798432734511321088,
  "created_at" : "2016-11-15 07:49:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Agh\u24D0z\u24D0ri\u24D0n",
      "screen_name" : "mutteringtreats",
      "indices" : [ 0, 16 ],
      "id_str" : "27126740",
      "id" : 27126740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798352317850546182",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.90489509945776, -77.0363236591016 ]
  },
  "id_str" : "798356665456279552",
  "in_reply_to_user_id" : 27126740,
  "text" : "@mutteringtreats thanks! And thanks so much for following up. Let\u2019s keep in touch!",
  "id" : 798356665456279552,
  "in_reply_to_status_id" : 798352317850546182,
  "created_at" : "2016-11-15 02:47:16 +0000",
  "in_reply_to_screen_name" : "mutteringtreats",
  "in_reply_to_user_id_str" : "27126740",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798316599124131840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.90683350950265, -77.03627027032324 ]
  },
  "id_str" : "798346096162603012",
  "in_reply_to_user_id" : 14286491,
  "text" : "I met a second person not wearing a suit. \uD83D\uDC96 #opencon",
  "id" : 798346096162603012,
  "in_reply_to_status_id" : 798316599124131840,
  "created_at" : "2016-11-15 02:05:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798309469843292160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.90476961818654, -77.0363465403025 ]
  },
  "id_str" : "798316658125393921",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot give it 4 years.",
  "id" : 798316658125393921,
  "in_reply_to_status_id" : 798309469843292160,
  "created_at" : "2016-11-15 00:08:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798303365478412288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.90476961818654, -77.0363465403025 ]
  },
  "id_str" : "798316599124131840",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThis suit is limiting my academic freedom to drink wine!\u00BB #opencon",
  "id" : 798316599124131840,
  "in_reply_to_status_id" : 798303365478412288,
  "created_at" : "2016-11-15 00:08:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 15, 22 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798296147898970112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9047485811798, -77.03637863792125 ]
  },
  "id_str" : "798303365478412288",
  "in_reply_to_user_id" : 14286491,
  "text" : "@annakrystalli @Koalha you two should be in touch. Open Ecologists unite. #opencon",
  "id" : 798303365478412288,
  "in_reply_to_status_id" : 798296147898970112,
  "created_at" : "2016-11-14 23:15:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798186586538184705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.90473926447665, -77.03645872294535 ]
  },
  "id_str" : "798296147898970112",
  "in_reply_to_user_id" : 14286491,
  "text" : "Finally had time to stroll through DC. I\u2019m not ashamed to say that i could find most of my way without a map thanks to Fallout 3. #opencon",
  "id" : 798296147898970112,
  "in_reply_to_status_id" : 798186586538184705,
  "created_at" : "2016-11-14 22:46:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Bartsch",
      "screen_name" : "perepyolotshka",
      "indices" : [ 0, 15 ],
      "id_str" : "115919455",
      "id" : 115919455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798235770817486848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.99918999526556, -77.09796770482984 ]
  },
  "id_str" : "798239103250640896",
  "in_reply_to_user_id" : 115919455,
  "text" : "@perepyolotshka yay, glad that worked!",
  "id" : 798239103250640896,
  "in_reply_to_status_id" : 798235770817486848,
  "created_at" : "2016-11-14 19:00:07 +0000",
  "in_reply_to_screen_name" : "perepyolotshka",
  "in_reply_to_user_id_str" : "115919455",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/9ggJv5y8wg",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/159",
      "display_url" : "existentialcomics.com\/comic\/159"
    } ]
  },
  "geo" : { },
  "id_str" : "798210684374974466",
  "text" : "If you don't find equality, peace, prosperity, and justice fun\u2026 https:\/\/t.co\/9ggJv5y8wg",
  "id" : 798210684374974466,
  "created_at" : "2016-11-14 17:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 3, 10 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798186910002872320",
  "text" : "RT @pennyb: Compensate people for their work - don't exploit free or cheap labour. One reason FOSS is so male is who can afford to voluntee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798186470792134657",
    "text" : "Compensate people for their work - don't exploit free or cheap labour. One reason FOSS is so male is who can afford to volunteer. #OpenCon",
    "id" : 798186470792134657,
    "created_at" : "2016-11-14 15:30:58 +0000",
    "user" : {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "protected" : false,
      "id_str" : "6069772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921360107505704960\/-c9C3uCY_normal.jpg",
      "id" : 6069772,
      "verified" : false
    }
  },
  "id" : 798186910002872320,
  "created_at" : "2016-11-14 15:32:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/CqWF2oaJ4k",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/153171663968\/thinking-about-the-future-of-science-in-america",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/153171663\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "798178079650684928",
  "geo" : { },
  "id_str" : "798186586538184705",
  "in_reply_to_user_id" : 14286491,
  "text" : "Captures some of the mood here at #opencon https:\/\/t.co\/CqWF2oaJ4k",
  "id" : 798186586538184705,
  "in_reply_to_status_id" : 798178079650684928,
  "created_at" : "2016-11-14 15:31:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 17, 27 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798182243780861952",
  "geo" : { },
  "id_str" : "798182807235391489",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @blahah404 ID'ng those people and inviting them, reassuring them, is super important.",
  "id" : 798182807235391489,
  "in_reply_to_status_id" : 798182243780861952,
  "created_at" : "2016-11-14 15:16:25 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 11, 27 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798181446435356672",
  "geo" : { },
  "id_str" : "798181812333936640",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @daniellecrobins cater to people who are not feeling welcomed so far?",
  "id" : 798181812333936640,
  "in_reply_to_status_id" : 798181446435356672,
  "created_at" : "2016-11-14 15:12:28 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edur\u2764am loves you",
      "screen_name" : "eduroamLovesYou",
      "indices" : [ 20, 36 ],
      "id_str" : "2612213109",
      "id" : 2612213109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798013611616518144",
  "geo" : { },
  "id_str" : "798178079650684928",
  "in_reply_to_user_id" : 14286491,
  "text" : "We love eduroam and @eduroamLovesYou at #opencon",
  "id" : 798178079650684928,
  "in_reply_to_status_id" : 798013611616518144,
  "created_at" : "2016-11-14 14:57:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Bartsch",
      "screen_name" : "perepyolotshka",
      "indices" : [ 0, 15 ],
      "id_str" : "115919455",
      "id" : 115919455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798173424195538944",
  "geo" : { },
  "id_str" : "798173846771634176",
  "in_reply_to_user_id" : 115919455,
  "text" : "@perepyolotshka depends on where you are right now? ;)",
  "id" : 798173846771634176,
  "in_reply_to_status_id" : 798173424195538944,
  "created_at" : "2016-11-14 14:40:49 +0000",
  "in_reply_to_screen_name" : "perepyolotshka",
  "in_reply_to_user_id_str" : "115919455",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 3, 17 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 118, 129 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798173633671622657",
  "text" : "RT @natalianorori: Hey #opencon ,There's an Open Global Health channel for us on Slack! If you wanna join, just tweet @Neurosarda your emai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniela Saderi",
        "screen_name" : "Neurosarda",
        "indices" : [ 99, 110 ],
        "id_str" : "4657994587",
        "id" : 4657994587
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798160934648811520",
    "text" : "Hey #opencon ,There's an Open Global Health channel for us on Slack! If you wanna join, just tweet @Neurosarda your email address!",
    "id" : 798160934648811520,
    "created_at" : "2016-11-14 13:49:30 +0000",
    "user" : {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "protected" : false,
      "id_str" : "258025439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929957275950878721\/H0Ho5XhS_normal.jpg",
      "id" : 258025439,
      "verified" : false
    }
  },
  "id" : 798173633671622657,
  "created_at" : "2016-11-14 14:39:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798157462939598849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91664841491349, -77.02305435067018 ]
  },
  "id_str" : "798159386258579456",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 i\u2019m glad I could be of service!",
  "id" : 798159386258579456,
  "in_reply_to_status_id" : 798157462939598849,
  "created_at" : "2016-11-14 13:43:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798149926299439106",
  "geo" : { },
  "id_str" : "798150798245040128",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor yeah, without using the one I was carrying with me.",
  "id" : 798150798245040128,
  "in_reply_to_status_id" : 798149926299439106,
  "created_at" : "2016-11-14 13:09:13 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/YjBfror6Y7",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "798150727789137920",
  "text" : "If you need some cheering up these days: have a look at dogs with their tongue out a little bit. \uD83D\uDC36\uD83D\uDC45 https:\/\/t.co\/YjBfror6Y7",
  "id" : 798150727789137920,
  "created_at" : "2016-11-14 13:08:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798149324618219520",
  "geo" : { },
  "id_str" : "798149494198194176",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor it does, but where would be the fun in that? (also: this was just across the street from the apartment \uD83D\uDE09)",
  "id" : 798149494198194176,
  "in_reply_to_status_id" : 798149324618219520,
  "created_at" : "2016-11-14 13:04:02 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/KLdZ7NaTqy",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/798143782512447488",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798144393823842304",
  "text" : "When you put a line in your interview just to tease your partner who\u2019s in neuroscience &amp; it ends up as the headline\u2026 https:\/\/t.co\/KLdZ7NaTqy",
  "id" : 798144393823842304,
  "created_at" : "2016-11-14 12:43:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798045164942069760",
  "text" : "Misread the Google Maps description for the Capitol as \u00ABIconic, doomed classical building housing the US Senate &amp; House of Representatives\u00BB\uD83E\uDD14",
  "id" : 798045164942069760,
  "created_at" : "2016-11-14 06:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 0, 8 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Thinklab",
      "screen_name" : "Thinklab",
      "indices" : [ 9, 18 ],
      "id_str" : "2521036693",
      "id" : 2521036693
    }, {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 19, 35 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798030657352073217",
  "geo" : { },
  "id_str" : "798039809826680832",
  "in_reply_to_user_id" : 289107682,
  "text" : "@dhimmel @thinklab @biorxivpreprint awesome! \uD83D\uDC96\uD83C\uDF89",
  "id" : 798039809826680832,
  "in_reply_to_status_id" : 798030657352073217,
  "created_at" : "2016-11-14 05:48:12 +0000",
  "in_reply_to_screen_name" : "dhimmel",
  "in_reply_to_user_id_str" : "289107682",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 41, 49 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/cddoEgycS2",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/798030579526561792",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798031685711527936",
  "text" : "I guess we\u2019re not allowed to make fun of @dhimmel any longer. #opencon https:\/\/t.co\/cddoEgycS2",
  "id" : 798031685711527936,
  "created_at" : "2016-11-14 05:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798010766041481216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.92179605322131, -77.04248091487766 ]
  },
  "id_str" : "798013611616518144",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00AB\u2018I gotta go, I have to submit a preprint\u2019 should be the official goodbye for the #opencon crowd.\u00BB \u2014 \u00ABIn short: CC-Bye.\u00BB",
  "id" : 798013611616518144,
  "in_reply_to_status_id" : 798010766041481216,
  "created_at" : "2016-11-14 04:04:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 7, 20 ],
      "id_str" : "252204344",
      "id" : 252204344
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 25, 33 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797982357760438276",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.92159833332065, -77.04242136099812 ]
  },
  "id_str" : "798010766041481216",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks @jessicapolka, as @dhimmel bailed on us to submit a preprint there\u2019s more beer left for us. #opencon \uD83C\uDF7B",
  "id" : 798010766041481216,
  "in_reply_to_status_id" : 797982357760438276,
  "created_at" : "2016-11-14 03:52:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "798005977354104832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.92170900128372, -77.04245368490938 ]
  },
  "id_str" : "798006947815428098",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski will happily host.",
  "id" : 798006947815428098,
  "in_reply_to_status_id" : 798005977354104832,
  "created_at" : "2016-11-14 03:37:37 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/0UcebPCfFn",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/797982182488739840",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797852195018461185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.92152404822256, -77.04222081560908 ]
  },
  "id_str" : "797982357760438276",
  "in_reply_to_user_id" : 14286491,
  "text" : "The open supper #opencon https:\/\/t.co\/0UcebPCfFn",
  "id" : 797982357760438276,
  "in_reply_to_status_id" : 797852195018461185,
  "created_at" : "2016-11-14 01:59:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797937607464218624",
  "geo" : { },
  "id_str" : "797937669514887169",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog I'll never carry you home again!",
  "id" : 797937669514887169,
  "in_reply_to_status_id" : 797937607464218624,
  "created_at" : "2016-11-13 23:02:20 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797933805311037440",
  "geo" : { },
  "id_str" : "797937037781254144",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog add me to the slack pls!",
  "id" : 797937037781254144,
  "in_reply_to_status_id" : 797933805311037440,
  "created_at" : "2016-11-13 22:59:49 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayra S. Artiles",
      "screen_name" : "mayrasharlenne",
      "indices" : [ 3, 18 ],
      "id_str" : "65430204",
      "id" : 65430204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797852379731427328",
  "text" : "RT @mayrasharlenne: It's tiring to not speak in your first language, it's tiring to deal with racism, it's tiring to deal with ableism ...\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
        "screen_name" : "pennyb",
        "indices" : [ 128, 135 ],
        "id_str" : "6069772",
        "id" : 6069772
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797851184921014273",
    "text" : "It's tiring to not speak in your first language, it's tiring to deal with racism, it's tiring to deal with ableism ... #opencon @pennyb",
    "id" : 797851184921014273,
    "created_at" : "2016-11-13 17:18:40 +0000",
    "user" : {
      "name" : "Mayra S. Artiles",
      "screen_name" : "mayrasharlenne",
      "protected" : false,
      "id_str" : "65430204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778022207490560000\/WYr51o3-_normal.jpg",
      "id" : 65430204,
      "verified" : false
    }
  },
  "id" : 797852379731427328,
  "created_at" : "2016-11-13 17:23:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 3, 13 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797852298647060481",
  "text" : "RT @kirstie_j: What is \"just a joke\" to you or something you \"didn't mean\" is exhausting for people from under-represented groups #OpenCon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
        "screen_name" : "pennyb",
        "indices" : [ 124, 131 ],
        "id_str" : "6069772",
        "id" : 6069772
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797850805068042241",
    "text" : "What is \"just a joke\" to you or something you \"didn't mean\" is exhausting for people from under-represented groups #OpenCon @pennyb",
    "id" : 797850805068042241,
    "created_at" : "2016-11-13 17:17:09 +0000",
    "user" : {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "protected" : false,
      "id_str" : "37989702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599173943405223937\/oNvZRB25_normal.jpg",
      "id" : 37989702,
      "verified" : false
    }
  },
  "id" : 797852298647060481,
  "created_at" : "2016-11-13 17:23:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 8, 16 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 17, 31 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797848946970415109",
  "geo" : { },
  "id_str" : "797852195018461185",
  "in_reply_to_user_id" : 14286491,
  "text" : "@pennyb @iaravps @AprilHathcock thanks so much. \uD83D\uDC96 #opencon",
  "id" : 797852195018461185,
  "in_reply_to_status_id" : 797848946970415109,
  "created_at" : "2016-11-13 17:22:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 101, 115 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797848601972142081",
  "geo" : { },
  "id_str" : "797848946970415109",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABGuess what: particle physics is not only happening in Switzerland, it's also happening in Nigeria.\u00BB @AprilHathcock #opencon",
  "id" : 797848946970415109,
  "in_reply_to_status_id" : 797848601972142081,
  "created_at" : "2016-11-13 17:09:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797847932821241856",
  "geo" : { },
  "id_str" : "797848601972142081",
  "in_reply_to_user_id" : 14286491,
  "text" : "Calling out the colonialism that's taking place in open. Need space for reflection and critique. #opencon",
  "id" : 797848601972142081,
  "in_reply_to_status_id" : 797847932821241856,
  "created_at" : "2016-11-13 17:08:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 93, 107 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797847447603183617",
  "geo" : { },
  "id_str" : "797847932821241856",
  "in_reply_to_user_id" : 14286491,
  "text" : "To foster diversity we have to put our money where our mouth is: Fund people to participate. @AprilHathcock #opencon",
  "id" : 797847932821241856,
  "in_reply_to_status_id" : 797847447603183617,
  "created_at" : "2016-11-13 17:05:45 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 5, 19 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797844743942238208",
  "geo" : { },
  "id_str" : "797847447603183617",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now: @AprilHathcock is rocking it about the issue of how the dominance of English excludes in the space of open. #opencon",
  "id" : 797847447603183617,
  "in_reply_to_status_id" : 797844743942238208,
  "created_at" : "2016-11-13 17:03:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 3, 11 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 22, 30 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tonyR_H\/status\/797845179071942656\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ogmNcPKYZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxKD9GfXgAgMdy_.jpg",
      "id_str" : "797845169735434248",
      "id" : 797845169735434248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxKD9GfXgAgMdy_.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/ogmNcPKYZ3"
    } ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797845704664354816",
  "text" : "RT @tonyR_H: Awesome. @iaravps about to kick off the panel on equity at #OpenCon https:\/\/t.co\/ogmNcPKYZ3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Iara VPS",
        "screen_name" : "iaravps",
        "indices" : [ 9, 17 ],
        "id_str" : "173881525",
        "id" : 173881525
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tonyR_H\/status\/797845179071942656\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/ogmNcPKYZ3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxKD9GfXgAgMdy_.jpg",
        "id_str" : "797845169735434248",
        "id" : 797845169735434248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxKD9GfXgAgMdy_.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/ogmNcPKYZ3"
      } ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 59, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797845179071942656",
    "text" : "Awesome. @iaravps about to kick off the panel on equity at #OpenCon https:\/\/t.co\/ogmNcPKYZ3",
    "id" : 797845179071942656,
    "created_at" : "2016-11-13 16:54:48 +0000",
    "user" : {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "protected" : false,
      "id_str" : "44890780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908588506917883904\/pJgVpC15_normal.jpg",
      "id" : 44890780,
      "verified" : false
    }
  },
  "id" : 797845704664354816,
  "created_at" : "2016-11-13 16:56:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797835236969160704",
  "geo" : { },
  "id_str" : "797844743942238208",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now:  The Equity and Open session. \uD83C\uDF89\uD83D\uDC96 #opencon",
  "id" : 797844743942238208,
  "in_reply_to_status_id" : 797835236969160704,
  "created_at" : "2016-11-13 16:53:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797842385183051780\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ysTOf8TV46",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CxKBZkEWEAAjoyg.jpg",
      "id_str" : "797842360176611328",
      "id" : 797842360176611328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CxKBZkEWEAAjoyg.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ysTOf8TV46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797840225884078080",
  "geo" : { },
  "id_str" : "797842385183051780",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel that's totally how I work it! https:\/\/t.co\/ysTOf8TV46",
  "id" : 797842385183051780,
  "in_reply_to_status_id" : 797840225884078080,
  "created_at" : "2016-11-13 16:43:42 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/msQcf7lxlP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMwcyswDIxj\/",
      "display_url" : "instagram.com\/p\/BMwcyswDIxj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "797838467711594496",
  "text" : "Found it without one! https:\/\/t.co\/msQcf7lxlP",
  "id" : 797838467711594496,
  "created_at" : "2016-11-13 16:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 61, 69 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797833930716102656",
  "geo" : { },
  "id_str" : "797835236969160704",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABNick asked me to say something inspiring. I won't do that.\u00BB @mbeisen \uD83D\uDE02 #opencon",
  "id" : 797835236969160704,
  "in_reply_to_status_id" : 797833930716102656,
  "created_at" : "2016-11-13 16:15:18 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Casey Driscoll",
      "screen_name" : "caseydriscoll",
      "indices" : [ 15, 29 ],
      "id_str" : "218733347",
      "id" : 218733347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797834308828463106",
  "geo" : { },
  "id_str" : "797834622914756608",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @caseydriscoll it's in the Q I linked too, plus some stats from Germany etc. \uD83D\uDE42",
  "id" : 797834622914756608,
  "in_reply_to_status_id" : 797834308828463106,
  "created_at" : "2016-11-13 16:12:51 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/LHTiAOPSpT",
      "expanded_url" : "http:\/\/academia.stackexchange.com\/questions\/17431\/what-ratio-of-phd-graduates-in-stem-fields-ultimately-end-up-as-tenured-profes",
      "display_url" : "academia.stackexchange.com\/questions\/1743\u2026"
    }, {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ALTxjtkFER",
      "expanded_url" : "https:\/\/twitter.com\/caseydriscoll\/status\/797829639943127041",
      "display_url" : "twitter.com\/caseydriscoll\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797814436715171840",
  "geo" : { },
  "id_str" : "797833930716102656",
  "in_reply_to_user_id" : 14286491,
  "text" : "Find some numbers on that here https:\/\/t.co\/LHTiAOPSpT #opencon https:\/\/t.co\/ALTxjtkFER",
  "id" : 797833930716102656,
  "in_reply_to_status_id" : 797814436715171840,
  "created_at" : "2016-11-13 16:10:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/xpkeKxJyYR",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/1990s-doomsday-planners-worried-about-feminists-breaching-nuclear-waste-sites",
      "display_url" : "atlasobscura.com\/articles\/1990s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "797831300572909568",
  "text" : "\u00AB1990s Doomsday Planners Worried About Feminists Breaching Nuclear Waste Sites\u00BB Uhm\u2026 https:\/\/t.co\/xpkeKxJyYR",
  "id" : 797831300572909568,
  "created_at" : "2016-11-13 15:59:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 3, 17 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797827347919597568",
  "text" : "RT @AprilHathcock: Exactly. Let's not get involved in tone policing marginalized ppl tired of constant mainstream screw ups. #OpenCon https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/5dBVvP5QrH",
        "expanded_url" : "https:\/\/aprilhathcock.wordpress.com\/2016\/04\/13\/youre-gonna-screw-up\/",
        "display_url" : "aprilhathcock.wordpress.com\/2016\/04\/13\/you\u2026"
      }, {
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/aX0ZaMFM6m",
        "expanded_url" : "https:\/\/twitter.com\/pennyb\/status\/797824737506455552",
        "display_url" : "twitter.com\/pennyb\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "797827002564755456",
    "text" : "Exactly. Let's not get involved in tone policing marginalized ppl tired of constant mainstream screw ups. #OpenCon https:\/\/t.co\/5dBVvP5QrH https:\/\/t.co\/aX0ZaMFM6m",
    "id" : 797827002564755456,
    "created_at" : "2016-11-13 15:42:34 +0000",
    "user" : {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "protected" : false,
      "id_str" : "3209949862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925100168277618693\/8UJUY3i2_normal.jpg",
      "id" : 3209949862,
      "verified" : false
    }
  },
  "id" : 797827347919597568,
  "created_at" : "2016-11-13 15:43:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 3, 17 ],
      "id_str" : "388503174",
      "id" : 388503174
    }, {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 54, 68 ],
      "id_str" : "39835900",
      "id" : 39835900
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/juancommander\/status\/797819829759705088\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/cT2cx018FV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxJs48VVEAAN3Em.jpg",
      "id_str" : "797819809522061312",
      "id" : 797819809522061312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxJs48VVEAAN3Em.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cT2cx018FV"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797821937674321920",
  "text" : "RT @juancommander: Deails on the pencil metaphor that @thatpsychprof talked about #opencon https:\/\/t.co\/cT2cx018FV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rajiv Jhangiani",
        "screen_name" : "thatpsychprof",
        "indices" : [ 35, 49 ],
        "id_str" : "39835900",
        "id" : 39835900
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juancommander\/status\/797819829759705088\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/cT2cx018FV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxJs48VVEAAN3Em.jpg",
        "id_str" : "797819809522061312",
        "id" : 797819809522061312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxJs48VVEAAN3Em.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cT2cx018FV"
      } ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797819829759705088",
    "text" : "Deails on the pencil metaphor that @thatpsychprof talked about #opencon https:\/\/t.co\/cT2cx018FV",
    "id" : 797819829759705088,
    "created_at" : "2016-11-13 15:14:04 +0000",
    "user" : {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "protected" : false,
      "id_str" : "388503174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926355239640317952\/aHrFSvOh_normal.jpg",
      "id" : 388503174,
      "verified" : false
    }
  },
  "id" : 797821937674321920,
  "created_at" : "2016-11-13 15:22:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elizabeth berman",
      "screen_name" : "elizabethberman",
      "indices" : [ 3, 19 ],
      "id_str" : "169897631",
      "id" : 169897631
    }, {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 22, 36 ],
      "id_str" : "39835900",
      "id" : 39835900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797818891502317568",
  "text" : "RT @elizabethberman: .@thatpsychprof necessarily emphasizes that our current academic structure reinforces social\/economic inequalities #OE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rajiv Jhangiani",
        "screen_name" : "thatpsychprof",
        "indices" : [ 1, 15 ],
        "id_str" : "39835900",
        "id" : 39835900
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OER",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "OpenCon",
        "indices" : [ 120, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797818488027041792",
    "text" : ".@thatpsychprof necessarily emphasizes that our current academic structure reinforces social\/economic inequalities #OER #OpenCon",
    "id" : 797818488027041792,
    "created_at" : "2016-11-13 15:08:44 +0000",
    "user" : {
      "name" : "elizabeth berman",
      "screen_name" : "elizabethberman",
      "protected" : false,
      "id_str" : "169897631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426903028801613824\/rjyIAkO-_normal.jpeg",
      "id" : 169897631,
      "verified" : false
    }
  },
  "id" : 797818891502317568,
  "created_at" : "2016-11-13 15:10:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary McDowell",
      "screen_name" : "BiophysicalFrog",
      "indices" : [ 3, 19 ],
      "id_str" : "308407719",
      "id" : 308407719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797814934793048064",
  "text" : "RT @BiophysicalFrog: Focusing on US\/Canada so far because you can only do so much to begin. But more data is a good prob to have so others\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/C66CRBXTIU",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797814436715171840",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "797814672510554113",
    "text" : "Focusing on US\/Canada so far because you can only do so much to begin. But more data is a good prob to have so others welcome #OpenCon https:\/\/t.co\/C66CRBXTIU",
    "id" : 797814672510554113,
    "created_at" : "2016-11-13 14:53:35 +0000",
    "user" : {
      "name" : "Gary McDowell",
      "screen_name" : "BiophysicalFrog",
      "protected" : false,
      "id_str" : "308407719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862338034402021377\/GKpVKee__normal.jpg",
      "id" : 308407719,
      "verified" : false
    }
  },
  "id" : 797814934793048064,
  "created_at" : "2016-11-13 14:54:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Michele Busby",
      "screen_name" : "michelebusby",
      "indices" : [ 16, 29 ],
      "id_str" : "155651779",
      "id" : 155651779
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797814863347253248\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/FgCUhtMhKH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CxJoYYZWEAA9Zuw.jpg",
      "id_str" : "797814852072902656",
      "id" : 797814852072902656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CxJoYYZWEAA9Zuw.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/FgCUhtMhKH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797814146641395717",
  "geo" : { },
  "id_str" : "797814863347253248",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @michelebusby https:\/\/t.co\/FgCUhtMhKH",
  "id" : 797814863347253248,
  "in_reply_to_status_id" : 797814146641395717,
  "created_at" : "2016-11-13 14:54:20 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/7NUJr3DdUW",
      "expanded_url" : "https:\/\/twitter.com\/RaoOfPhysics\/status\/797813850372509696",
      "display_url" : "twitter.com\/RaoOfPhysics\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797585912561537025",
  "geo" : { },
  "id_str" : "797814436715171840",
  "in_reply_to_user_id" : 14286491,
  "text" : "But only if you're in \uD83C\uDDE8\uD83C\uDDE6\/\uD83C\uDDFA\uD83C\uDDF8. #opencon https:\/\/t.co\/7NUJr3DdUW",
  "id" : 797814436715171840,
  "in_reply_to_status_id" : 797585912561537025,
  "created_at" : "2016-11-13 14:52:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Michele Busby",
      "screen_name" : "michelebusby",
      "indices" : [ 16, 29 ],
      "id_str" : "155651779",
      "id" : 155651779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797813585254686720",
  "geo" : { },
  "id_str" : "797813928311066624",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @michelebusby there were like 4-5 of them, so that would need to be a huge dungeon (where can I find that?).",
  "id" : 797813928311066624,
  "in_reply_to_status_id" : 797813585254686720,
  "created_at" : "2016-11-13 14:50:37 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Busby",
      "screen_name" : "michelebusby",
      "indices" : [ 3, 16 ],
      "id_str" : "155651779",
      "id" : 155651779
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797813417734238209",
  "text" : "RT @michelebusby: @gedankenstuecke I looks like an evil villian was redecorating his torture room and left the old stuff out on the sidewal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "797811463058575362",
    "geo" : { },
    "id_str" : "797813251115515904",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I looks like an evil villian was redecorating his torture room and left the old stuff out on the sidewalk.",
    "id" : 797813251115515904,
    "in_reply_to_status_id" : 797811463058575362,
    "created_at" : "2016-11-13 14:47:56 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Michele Busby",
      "screen_name" : "michelebusby",
      "protected" : false,
      "id_str" : "155651779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2388625153\/0eszy4nvoawurhpg2ye6_normal.jpeg",
      "id" : 155651779,
      "verified" : false
    }
  },
  "id" : 797813417734238209,
  "created_at" : "2016-11-13 14:48:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 71, 81 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797811463058575362\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/y3aVXZRJOg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxJlS_-W8AIE5pN.jpg",
      "id_str" : "797811461083033602",
      "id" : 797811461083033602,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxJlS_-W8AIE5pN.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y3aVXZRJOg"
    } ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797811463058575362",
  "text" : "Hostile Architecture spotted in DC this morning on the way to #OpenCon @romanmars https:\/\/t.co\/y3aVXZRJOg",
  "id" : 797811463058575362,
  "created_at" : "2016-11-13 14:40:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cobi Smith",
      "screen_name" : "cobismith",
      "indices" : [ 3, 13 ],
      "id_str" : "26703939",
      "id" : 26703939
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 68, 76 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 78, 91 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797687981540855808",
  "text" : "RT @cobismith: thanks for sharing #opencon hijinks in your hometown @mbeisen, @RaoOfPhysics was enthralled by that vintage jukebox: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Eisen",
        "screen_name" : "mbeisen",
        "indices" : [ 53, 61 ],
        "id_str" : "19843630",
        "id" : 19843630
      }, {
        "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
        "screen_name" : "RaoOfPhysics",
        "indices" : [ 63, 76 ],
        "id_str" : "67529128",
        "id" : 67529128
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cobismith\/status\/797656755245301761\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TdgCIHIvdx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxHYlX-WEAItNIC.jpg",
        "id_str" : "797656745623556098",
        "id" : 797656745623556098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxHYlX-WEAItNIC.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TdgCIHIvdx"
      } ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797656755245301761",
    "text" : "thanks for sharing #opencon hijinks in your hometown @mbeisen, @RaoOfPhysics was enthralled by that vintage jukebox: https:\/\/t.co\/TdgCIHIvdx",
    "id" : 797656755245301761,
    "created_at" : "2016-11-13 04:26:04 +0000",
    "user" : {
      "name" : "Cobi Smith",
      "screen_name" : "cobismith",
      "protected" : false,
      "id_str" : "26703939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790170148560736256\/0ldZu4X5_normal.jpg",
      "id" : 26703939,
      "verified" : false
    }
  },
  "id" : 797687981540855808,
  "created_at" : "2016-11-13 06:30:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797651792674885632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.98822874075172, -77.09573457389847 ]
  },
  "id_str" : "797651911948255233",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @Protohedgehog we\u2019re on our way back.",
  "id" : 797651911948255233,
  "in_reply_to_status_id" : 797651792674885632,
  "created_at" : "2016-11-13 04:06:50 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797646706473074689\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/v8U0Jm2blu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxHPcxVW8AA6pXA.jpg",
      "id_str" : "797646702207496192",
      "id" : 797646702207496192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxHPcxVW8AA6pXA.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/v8U0Jm2blu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/mKenWVx1pR",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/1BrZ9HXHLUM",
      "display_url" : "swarmapp.com\/c\/1BrZ9HXHLUM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.98819137, -77.0958478 ]
  },
  "id_str" : "797646706473074689",
  "text" : "Listening to The Devil Went Down in Georgia from the Jukebox. (@ Tastee Diner) https:\/\/t.co\/mKenWVx1pR https:\/\/t.co\/v8U0Jm2blu",
  "id" : 797646706473074689,
  "created_at" : "2016-11-13 03:46:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 0, 10 ],
      "id_str" : "331228486",
      "id" : 331228486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797466132521357312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94588978941466, -77.08083017575666 ]
  },
  "id_str" : "797597509334028288",
  "in_reply_to_user_id" : 331228486,
  "text" : "@DevilleSy yes, at least the USA have been kicked off the list. Still undecided about the U.K.",
  "id" : 797597509334028288,
  "in_reply_to_status_id" : 797466132521357312,
  "created_at" : "2016-11-13 00:30:39 +0000",
  "in_reply_to_screen_name" : "DevilleSy",
  "in_reply_to_user_id_str" : "331228486",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797528615084851201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94582264171027, -77.080745671185 ]
  },
  "id_str" : "797585912561537025",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThis is crazy. Such an awesome group of people here, all these brilliant minds. And then there\u2019s the two of us.\u00BB #opencon",
  "id" : 797585912561537025,
  "in_reply_to_status_id" : 797528615084851201,
  "created_at" : "2016-11-12 23:44:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Bolick",
      "screen_name" : "JoshBolick",
      "indices" : [ 3, 14 ],
      "id_str" : "1152255560",
      "id" : 1152255560
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797574593619828740",
  "text" : "RT @JoshBolick: #opencon Institutional Repositories: Less Annoying than ResearchGate. It's not a *bad* slogan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797573313803522049",
    "text" : "#opencon Institutional Repositories: Less Annoying than ResearchGate. It's not a *bad* slogan.",
    "id" : 797573313803522049,
    "created_at" : "2016-11-12 22:54:30 +0000",
    "user" : {
      "name" : "Josh Bolick",
      "screen_name" : "JoshBolick",
      "protected" : false,
      "id_str" : "1152255560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872915272134402048\/luk5qZhk_normal.jpg",
      "id" : 1152255560,
      "verified" : false
    }
  },
  "id" : 797574593619828740,
  "created_at" : "2016-11-12 22:59:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.93194257285347, -77.077642008734 ]
  },
  "id_str" : "797565054967316481",
  "text" : "Just wondered why all of my credit cards don\u2019t work. Turns out the banks\u2019 servers are all down. \uD83D\uDE02",
  "id" : 797565054967316481,
  "created_at" : "2016-11-12 22:21:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 98, 111 ],
      "id_str" : "252204344",
      "id" : 252204344
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797528615084851201\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/Rbo9136QFS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxFkCkwWgAA0acn.jpg",
      "id_str" : "797528604410281984",
      "id" : 797528604410281984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxFkCkwWgAA0acn.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Rbo9136QFS"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797524744190955520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94597558206816, -77.0808002336674 ]
  },
  "id_str" : "797528615084851201",
  "in_reply_to_user_id" : 14286491,
  "text" : "Preprints are taking off in life sciences? Looks like it, but that\u2019s only 1% of all publications. @jessicapolka at #opencon https:\/\/t.co\/Rbo9136QFS",
  "id" : 797528615084851201,
  "in_reply_to_status_id" : 797524744190955520,
  "created_at" : "2016-11-12 19:56:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 71, 84 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797470865076195328",
  "geo" : { },
  "id_str" : "797524744190955520",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABImposter syndrome is probably not something you are unfamiliar with.\u00BB @RaoOfPhysics  at #opencon",
  "id" : 797524744190955520,
  "in_reply_to_status_id" : 797470865076195328,
  "created_at" : "2016-11-12 19:41:30 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaimie Murdock",
      "screen_name" : "JaimieMurdock",
      "indices" : [ 0, 14 ],
      "id_str" : "24012732",
      "id" : 24012732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797519768421068800",
  "geo" : { },
  "id_str" : "797521149026504704",
  "in_reply_to_user_id" : 24012732,
  "text" : "@JaimieMurdock count me in, can't enter myself from mobile phone though. :)",
  "id" : 797521149026504704,
  "in_reply_to_status_id" : 797519768421068800,
  "created_at" : "2016-11-12 19:27:13 +0000",
  "in_reply_to_screen_name" : "JaimieMurdock",
  "in_reply_to_user_id_str" : "24012732",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Sara Kassabian",
      "screen_name" : "sarakassabian",
      "indices" : [ 12, 26 ],
      "id_str" : "116984422",
      "id" : 116984422
    }, {
      "name" : "Felipe G. Nievinski",
      "screen_name" : "fgnievinski",
      "indices" : [ 27, 39 ],
      "id_str" : "18403981",
      "id" : 18403981
    }, {
      "name" : "Casey Driscoll",
      "screen_name" : "caseydriscoll",
      "indices" : [ 40, 54 ],
      "id_str" : "218733347",
      "id" : 218733347
    }, {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 55, 65 ],
      "id_str" : "248717660",
      "id" : 248717660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797510096922247169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94602415337821, -77.08086216505478 ]
  },
  "id_str" : "797519319718567936",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @sarakassabian @fgnievinski @caseydriscoll @operkovic thanks to all of you, this was the best!",
  "id" : 797519319718567936,
  "in_reply_to_status_id" : 797510096922247169,
  "created_at" : "2016-11-12 19:19:57 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/eWnKi6CXha",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797459816558039041",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797459816558039041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94511603288254, -77.07985600463773 ]
  },
  "id_str" : "797501529100058624",
  "in_reply_to_user_id" : 14286491,
  "text" : "Wow, this circle has been one of the most emotional, awesome and intense experiences I\u2019ve had in a while. Thanks for sharing! #opencon https:\/\/t.co\/eWnKi6CXha",
  "id" : 797501529100058624,
  "in_reply_to_status_id" : 797459816558039041,
  "created_at" : "2016-11-12 18:09:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797471281637625856",
  "geo" : { },
  "id_str" : "797472633067634688",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @dm_waugh In my experience lack of resources &amp; guidelines are often given as excuses. Ego surfaces after these are gone.",
  "id" : 797472633067634688,
  "in_reply_to_status_id" : 797471281637625856,
  "created_at" : "2016-11-12 16:14:26 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Hg6AIVKx08",
      "expanded_url" : "https:\/\/twitter.com\/jessicapolka\/status\/797470448158212097",
      "display_url" : "twitter.com\/jessicapolka\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797464652691210240",
  "geo" : { },
  "id_str" : "797470865076195328",
  "in_reply_to_user_id" : 14286491,
  "text" : "And it's the last one that is often the biggest issue.  #opencon https:\/\/t.co\/Hg6AIVKx08",
  "id" : 797470865076195328,
  "in_reply_to_status_id" : 797464652691210240,
  "created_at" : "2016-11-12 16:07:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 3, 14 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Brewster Kahle",
      "screen_name" : "brewster_kahle",
      "indices" : [ 16, 31 ],
      "id_str" : "315490964",
      "id" : 315490964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "OpenData",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797464899022626817",
  "text" : "RT @Neurosarda: @brewster_kahle YES, thank you - \"Scientific papers with its software and data that is Decentralized\" #OpenCon #OpenData",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brewster Kahle",
        "screen_name" : "brewster_kahle",
        "indices" : [ 0, 15 ],
        "id_str" : "315490964",
        "id" : 315490964
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "OpenData",
        "indices" : [ 111, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797464817682567168",
    "in_reply_to_user_id" : 315490964,
    "text" : "@brewster_kahle YES, thank you - \"Scientific papers with its software and data that is Decentralized\" #OpenCon #OpenData",
    "id" : 797464817682567168,
    "created_at" : "2016-11-12 15:43:23 +0000",
    "in_reply_to_screen_name" : "brewster_kahle",
    "in_reply_to_user_id_str" : "315490964",
    "user" : {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "protected" : false,
      "id_str" : "4657994587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924703180017098753\/U6AAw1fu_normal.jpg",
      "id" : 4657994587,
      "verified" : false
    }
  },
  "id" : 797464899022626817,
  "created_at" : "2016-11-12 15:43:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brewster Kahle",
      "screen_name" : "brewster_kahle",
      "indices" : [ 9, 24 ],
      "id_str" : "315490964",
      "id" : 315490964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797459816558039041",
  "geo" : { },
  "id_str" : "797464652691210240",
  "in_reply_to_user_id" : 14286491,
  "text" : "tl;dr of @brewster_kahle's talk on the decentralized web: What about \u00ABIt's like X, but decentralized\u00BB. #opencon",
  "id" : 797464652691210240,
  "in_reply_to_status_id" : 797459816558039041,
  "created_at" : "2016-11-12 15:42:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Oac4szUaGi",
      "expanded_url" : "https:\/\/twitter.com\/daniellecrobins\/status\/797459302684459009",
      "display_url" : "twitter.com\/daniellecrobin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797457458235080704",
  "geo" : { },
  "id_str" : "797459816558039041",
  "in_reply_to_user_id" : 14286491,
  "text" : "Same here, looking forward to hear from many of you! #opencon https:\/\/t.co\/Oac4szUaGi",
  "id" : 797459816558039041,
  "in_reply_to_status_id" : 797457458235080704,
  "created_at" : "2016-11-12 15:23:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/Q1i1fov9Wm",
      "expanded_url" : "https:\/\/twitter.com\/AprilHathcock\/status\/797456897448275968",
      "display_url" : "twitter.com\/AprilHathcock\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "797455879910096897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9458868491597, -77.08076034071254 ]
  },
  "id_str" : "797457458235080704",
  "in_reply_to_user_id" : 14286491,
  "text" : "And one of them wants us to go to war\u2026 #opencon https:\/\/t.co\/Q1i1fov9Wm",
  "id" : 797457458235080704,
  "in_reply_to_status_id" : 797455879910096897,
  "created_at" : "2016-11-12 15:14:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797455426673659904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94603970303205, -77.08071646784822 ]
  },
  "id_str" : "797455879910096897",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABBe aggressive in your thinking.\u00BB Yeah, because the US is living proof of how well that works out\u2026 #opencon",
  "id" : 797455879910096897,
  "in_reply_to_status_id" : 797455426673659904,
  "created_at" : "2016-11-12 15:07:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797455426673659904",
  "text" : "All this talk of an army of openness and needing ammunition makes me wince. I don't think the language of war is the way to go\u2026 #opencon",
  "id" : 797455426673659904,
  "created_at" : "2016-11-12 15:06:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797449416441495553\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/f2BDWaQPGO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxEb-d2XcAI56eV.jpg",
      "id_str" : "797449368999784450",
      "id" : 797449368999784450,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxEb-d2XcAI56eV.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/f2BDWaQPGO"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94589304927889, -77.08073708268887 ]
  },
  "id_str" : "797449416441495553",
  "text" : "Ready to start. #opencon https:\/\/t.co\/f2BDWaQPGO",
  "id" : 797449416441495553,
  "created_at" : "2016-11-12 14:42:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 0, 7 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797317950902517760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91661366583511, -77.02375684322824 ]
  },
  "id_str" : "797318518110846976",
  "in_reply_to_user_id" : 246624621,
  "text" : "@minaal Must have travelled the globe twice with your gear this year. And it has been tremendous fun!",
  "id" : 797318518110846976,
  "in_reply_to_status_id" : 797317950902517760,
  "created_at" : "2016-11-12 06:02:02 +0000",
  "in_reply_to_screen_name" : "minaal",
  "in_reply_to_user_id_str" : "246624621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797300762690908160\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/GKzgo84shG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxCUzgRW8AAXxf5.jpg",
      "id_str" : "797300746601558016",
      "id" : 797300746601558016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxCUzgRW8AAXxf5.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/GKzgo84shG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797280397101006848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91090978968898, -77.03192494565707 ]
  },
  "id_str" : "797300762690908160",
  "in_reply_to_user_id" : 14286491,
  "text" : "Less than 2 hours later: \u201CAnd you\u2019re the Trump of \u2018Connect Four\u2019!\u201D https:\/\/t.co\/GKzgo84shG",
  "id" : 797300762690908160,
  "in_reply_to_status_id" : 797280397101006848,
  "created_at" : "2016-11-12 04:51:29 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797281327376695296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91093842508764, -77.0318637654536 ]
  },
  "id_str" : "797281826490433537",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins people here are struggling big time with this as well.",
  "id" : 797281826490433537,
  "in_reply_to_status_id" : 797281327376695296,
  "created_at" : "2016-11-12 03:36:14 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91090372705767, -77.03194337727498 ]
  },
  "id_str" : "797280397101006848",
  "text" : "\u00ABThere are two rules for tonight: don\u2019t mention Trump and don\u2019t mention Elsevier.\u00BB",
  "id" : 797280397101006848,
  "created_at" : "2016-11-12 03:30:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 40, 54 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797252146651627520\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/fMf31fWq9a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxBomNzW8AAY9q7.jpg",
      "id_str" : "797252139793969152",
      "id" : 797252139793969152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxBomNzW8AAY9q7.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/fMf31fWq9a"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.91085856754201, -77.03194159859817 ]
  },
  "id_str" : "797252146651627520",
  "text" : "Thanks to all our backers for reuniting @Protohedgehog and me! #opencon https:\/\/t.co\/fMf31fWq9a",
  "id" : 797252146651627520,
  "created_at" : "2016-11-12 01:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/4uaeAzBjwI",
      "expanded_url" : "https:\/\/www.minaal.com\/",
      "display_url" : "minaal.com"
    } ]
  },
  "in_reply_to_status_id_str" : "797209906164146176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.18223021097906, -76.66826646947207 ]
  },
  "id_str" : "797210093335015425",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute oh no! I like my https:\/\/t.co\/4uaeAzBjwI",
  "id" : 797210093335015425,
  "in_reply_to_status_id" : 797209906164146176,
  "created_at" : "2016-11-11 22:51:12 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Comeau",
      "screen_name" : "joeycomeau",
      "indices" : [ 0, 11 ],
      "id_str" : "8858632",
      "id" : 8858632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796815426772549632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.1824076864927, -76.66791911008089 ]
  },
  "id_str" : "797204820721541124",
  "in_reply_to_user_id" : 8858632,
  "text" : "@joeycomeau yes \uD83D\uDC96",
  "id" : 797204820721541124,
  "in_reply_to_status_id" : 796815426772549632,
  "created_at" : "2016-11-11 22:30:15 +0000",
  "in_reply_to_screen_name" : "joeycomeau",
  "in_reply_to_user_id_str" : "8858632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Poffenroth \uD83C\uDF1F",
      "screen_name" : "MaryPoffenroth",
      "indices" : [ 0, 15 ],
      "id_str" : "921764894",
      "id" : 921764894
    }, {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "indices" : [ 16, 29 ],
      "id_str" : "10798802",
      "id" : 10798802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797203449842663424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.18238880693421, -76.66793885780136 ]
  },
  "id_str" : "797204484283912193",
  "in_reply_to_user_id" : 921764894,
  "text" : "@MaryPoffenroth @amandapalmer I think I missed the TED talk, but will have to check that one out!",
  "id" : 797204484283912193,
  "in_reply_to_status_id" : 797203449842663424,
  "created_at" : "2016-11-11 22:28:55 +0000",
  "in_reply_to_screen_name" : "MaryPoffenroth",
  "in_reply_to_user_id_str" : "921764894",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Palmer",
      "screen_name" : "amandapalmer",
      "indices" : [ 24, 37 ],
      "id_str" : "10798802",
      "id" : 10798802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.18076031362842, -76.66546951573956 ]
  },
  "id_str" : "797200604208726017",
  "text" : "Read (&amp; cried over) @amandapalmer\u2019s \u00ABThe Art of Asking\u00BB on my flight to #opencon. Fitting, I wouldn\u2019t be here w\/o your crowdfunding support.",
  "id" : 797200604208726017,
  "created_at" : "2016-11-11 22:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797105703588610048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99178782949596, -22.60331106374283 ]
  },
  "id_str" : "797106332096720897",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon \uD83D\uDC4D",
  "id" : 797106332096720897,
  "in_reply_to_status_id" : 797105703588610048,
  "created_at" : "2016-11-11 15:58:53 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99426011050437, -22.62463548810332 ]
  },
  "id_str" : "797096066172731392",
  "text" : "After doing same fancy synchronous dance moves with another random TSA-PICK victim: KEF \u2708\uFE0F BWI.",
  "id" : 797096066172731392,
  "created_at" : "2016-11-11 15:18:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797089395572621313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99479286751151, -22.62489119546732 ]
  },
  "id_str" : "797094825027833857",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot there must be hot wiring instructions on YouTube.",
  "id" : 797094825027833857,
  "in_reply_to_status_id" : 797089395572621313,
  "created_at" : "2016-11-11 15:13:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797084652246810624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99479619832788, -22.62416571294635 ]
  },
  "id_str" : "797094727581650944",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko worked out fine. :)",
  "id" : 797094727581650944,
  "in_reply_to_status_id" : 797084652246810624,
  "created_at" : "2016-11-11 15:12:47 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/797088117123678209\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Ia98aXwiZO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_TZzeWIAA5Ehi.jpg",
      "id_str" : "797088099335544832",
      "id" : 797088099335544832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_TZzeWIAA5Ehi.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Ia98aXwiZO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99497176412482, -22.62338257988602 ]
  },
  "id_str" : "797088117123678209",
  "text" : "I drive my car hard, but I don\u2019t think that\u2019ll work out. https:\/\/t.co\/Ia98aXwiZO",
  "id" : 797088117123678209,
  "created_at" : "2016-11-11 14:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797084652246810624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99040600002291, -22.55579511990297 ]
  },
  "id_str" : "797085027741868032",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko thanks!",
  "id" : 797085027741868032,
  "in_reply_to_status_id" : 797084652246810624,
  "created_at" : "2016-11-11 14:34:14 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99040606843499, -22.55579483032134 ]
  },
  "id_str" : "797083645500653569",
  "text" : "Hey KEF. Now let\u2019s see that I\u2019ll get that connection.",
  "id" : 797083645500653569,
  "created_at" : "2016-11-11 14:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "re:publica",
      "screen_name" : "republica",
      "indices" : [ 9, 19 ],
      "id_str" : "9824472",
      "id" : 9824472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797028430567051264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04894829389173, 8.588559758314144 ]
  },
  "id_str" : "797029325295984640",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @republica I presented there some years back. It's huge but much more businessy than eg mozfest.",
  "id" : 797029325295984640,
  "in_reply_to_status_id" : 797028430567051264,
  "created_at" : "2016-11-11 10:52:53 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 0, 7 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797022124825317376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04983564572368, 8.591326370897498 ]
  },
  "id_str" : "797023169571913728",
  "in_reply_to_user_id" : 15132914,
  "text" : "@EvoMRI great, looking forward to it!",
  "id" : 797023169571913728,
  "in_reply_to_status_id" : 797022124825317376,
  "created_at" : "2016-11-11 10:28:26 +0000",
  "in_reply_to_screen_name" : "EvoMRI",
  "in_reply_to_user_id_str" : "15132914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 0, 7 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797020288798048256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05146647333701, 8.589980565467656 ]
  },
  "id_str" : "797021136945106944",
  "in_reply_to_user_id" : 15132914,
  "text" : "@EvoMRI nah, I think I got an earlier one. Arrival at BWI at 0430pm local time.",
  "id" : 797021136945106944,
  "in_reply_to_status_id" : 797020288798048256,
  "created_at" : "2016-11-11 10:20:21 +0000",
  "in_reply_to_screen_name" : "EvoMRI",
  "in_reply_to_user_id_str" : "15132914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Sean O'Kane",
      "screen_name" : "sokane1",
      "indices" : [ 42, 50 ],
      "id_str" : "13209362",
      "id" : 13209362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/797014863231025152\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/x403DH5iX2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw-QyxDWQAEko-N.jpg",
      "id_str" : "797014860903104513",
      "id" : 797014860903104513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw-QyxDWQAEko-N.jpg",
      "sizes" : [ {
        "h" : 521,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/x403DH5iX2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/CC1MiuznAo",
      "expanded_url" : "https:\/\/medium.com\/@seanokane\/day-1-in-trumps-america-9e4d58381001#---98-302.chlib7trp",
      "display_url" : "medium.com\/@seanokane\/day\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "797017383756070912",
  "text" : "RT @o_guest: \u201CDay 1 in Trump\u2019s America\u201D\u200A\u2014\u200A@sokane1 https:\/\/t.co\/CC1MiuznAo https:\/\/t.co\/x403DH5iX2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean O'Kane",
        "screen_name" : "sokane1",
        "indices" : [ 29, 37 ],
        "id_str" : "13209362",
        "id" : 13209362
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/797014863231025152\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/x403DH5iX2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw-QyxDWQAEko-N.jpg",
        "id_str" : "797014860903104513",
        "id" : 797014860903104513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw-QyxDWQAEko-N.jpg",
        "sizes" : [ {
          "h" : 521,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/x403DH5iX2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/CC1MiuznAo",
        "expanded_url" : "https:\/\/medium.com\/@seanokane\/day-1-in-trumps-america-9e4d58381001#---98-302.chlib7trp",
        "display_url" : "medium.com\/@seanokane\/day\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "797014863231025152",
    "text" : "\u201CDay 1 in Trump\u2019s America\u201D\u200A\u2014\u200A@sokane1 https:\/\/t.co\/CC1MiuznAo https:\/\/t.co\/x403DH5iX2",
    "id" : 797014863231025152,
    "created_at" : "2016-11-11 09:55:25 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 797017383756070912,
  "created_at" : "2016-11-11 10:05:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05161165554446, 8.589744129795902 ]
  },
  "id_str" : "797015196174811137",
  "text" : "Best way to spend your time when waiting for boarding: playing around with R. Now: FRA \u2708\uFE0F KEF for #opencon.",
  "id" : 797015196174811137,
  "created_at" : "2016-11-11 09:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sj\u00F3n",
      "screen_name" : "Sjonorama",
      "indices" : [ 3, 13 ],
      "id_str" : "824079175",
      "id" : 824079175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797000895288528896",
  "text" : "RT @Sjonorama: Leonard Cohen's poem about Adolf Eichmann is a timeless reminder of how fascism hides in plain sight. The poet has died, his\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sjonorama\/status\/796921226430152704\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/rNsFRHFwo2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw85l4sWEAAX3-I.jpg",
        "id_str" : "796918982104190976",
        "id" : 796918982104190976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw85l4sWEAAX3-I.jpg",
        "sizes" : [ {
          "h" : 549,
          "resize" : "fit",
          "w" : 391
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 391
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 391
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 391
        } ],
        "display_url" : "pic.twitter.com\/rNsFRHFwo2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "796921226430152704",
    "text" : "Leonard Cohen's poem about Adolf Eichmann is a timeless reminder of how fascism hides in plain sight. The poet has died, his songs live. https:\/\/t.co\/rNsFRHFwo2",
    "id" : 796921226430152704,
    "created_at" : "2016-11-11 03:43:21 +0000",
    "user" : {
      "name" : "Sj\u00F3n",
      "screen_name" : "Sjonorama",
      "protected" : false,
      "id_str" : "824079175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3492003420\/c088031a2b8f51ef6b39dade136a2ff0_normal.jpeg",
      "id" : 824079175,
      "verified" : true
    }
  },
  "id" : 797000895288528896,
  "created_at" : "2016-11-11 08:59:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05221219825891, 8.58646251165446 ]
  },
  "id_str" : "796991035608014848",
  "text" : "My mom sends an email, wishing me \u2018exciting hours\u2019 with my partner &amp; that she\u2019ll mentally be with us all the time. Speak of mixed messages.",
  "id" : 796991035608014848,
  "created_at" : "2016-11-11 08:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 32, 44 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/OEzI62sZbF",
      "expanded_url" : "https:\/\/www.brainpickings.org\/2015\/06\/16\/neil-gaiman-how-stories-last\/",
      "display_url" : "brainpickings.org\/2015\/06\/16\/nei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796863081028653056",
  "text" : "Finally found time to listen to @neilhimself talk about how stories last! \uD83D\uDC96 https:\/\/t.co\/OEzI62sZbF",
  "id" : 796863081028653056,
  "created_at" : "2016-11-10 23:52:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/Y2rLkUKUfd",
      "expanded_url" : "https:\/\/medium.com\/@emmalindsay\/why-sex-robots-dont-work-for-women-dfe167671804",
      "display_url" : "medium.com\/@emmalindsay\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796829628505722880",
  "text" : "Why Sex Robots Don\u2019t Work for Women https:\/\/t.co\/Y2rLkUKUfd",
  "id" : 796829628505722880,
  "created_at" : "2016-11-10 21:39:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian M Bot",
      "screen_name" : "BrianMBot",
      "indices" : [ 0, 10 ],
      "id_str" : "504127665",
      "id" : 504127665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796754873773531136",
  "geo" : { },
  "id_str" : "796761592822190080",
  "in_reply_to_user_id" : 504127665,
  "text" : "@BrianMBot thanks! We\u2019ll happily keep you all in the loop (and maybe ask for help ;)).",
  "id" : 796761592822190080,
  "in_reply_to_status_id" : 796754873773531136,
  "created_at" : "2016-11-10 17:09:01 +0000",
  "in_reply_to_screen_name" : "BrianMBot",
  "in_reply_to_user_id_str" : "504127665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796748356554985476",
  "text" : "Is it just me or is Wiley having serious connection issues all day? For me Sci-Hub now delivers OA papers quicker than their servers do\u2026",
  "id" : 796748356554985476,
  "created_at" : "2016-11-10 16:16:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geogoeroe",
      "screen_name" : "geogoeroe",
      "indices" : [ 0, 10 ],
      "id_str" : "63252096",
      "id" : 63252096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796741889231884288",
  "geo" : { },
  "id_str" : "796744317134077952",
  "in_reply_to_user_id" : 63252096,
  "text" : "@geogoeroe yay, thanks for the feedback! \uD83C\uDF89\uD83D\uDC4D",
  "id" : 796744317134077952,
  "in_reply_to_status_id" : 796741889231884288,
  "created_at" : "2016-11-10 16:00:22 +0000",
  "in_reply_to_screen_name" : "geogoeroe",
  "in_reply_to_user_id_str" : "63252096",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geogoeroe",
      "screen_name" : "geogoeroe",
      "indices" : [ 0, 10 ],
      "id_str" : "63252096",
      "id" : 63252096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796741017156354048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242399641335, 8.627461726613253 ]
  },
  "id_str" : "796741394970841089",
  "in_reply_to_user_id" : 63252096,
  "text" : "@geogoeroe whops, should be fixed!",
  "id" : 796741394970841089,
  "in_reply_to_status_id" : 796741017156354048,
  "created_at" : "2016-11-10 15:48:45 +0000",
  "in_reply_to_screen_name" : "geogoeroe",
  "in_reply_to_user_id_str" : "63252096",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geogoeroe",
      "screen_name" : "geogoeroe",
      "indices" : [ 0, 10 ],
      "id_str" : "63252096",
      "id" : 63252096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796739211063885825",
  "in_reply_to_user_id" : 63252096,
  "text" : "@geogoeroe Thanks again for showing up at the Nerdcator MozFest session. Sign in if you want to be updated via email https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796739211063885825,
  "created_at" : "2016-11-10 15:40:05 +0000",
  "in_reply_to_screen_name" : "geogoeroe",
  "in_reply_to_user_id_str" : "63252096",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mammal Web",
      "screen_name" : "MammalWeb",
      "indices" : [ 0, 10 ],
      "id_str" : "3362133777",
      "id" : 3362133777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796739195754741760",
  "in_reply_to_user_id" : 3362133777,
  "text" : "@MammalWeb Thanks again for showing up at the Nerdcator MozFest session. Sign in if you want to be updated via email https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796739195754741760,
  "created_at" : "2016-11-10 15:40:01 +0000",
  "in_reply_to_screen_name" : "MammalWeb",
  "in_reply_to_user_id_str" : "3362133777",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bowden",
      "screen_name" : "tmtm",
      "indices" : [ 0, 5 ],
      "id_str" : "869641",
      "id" : 869641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796738646267330564",
  "in_reply_to_user_id" : 869641,
  "text" : "@tmtm Thanks again for showing up at the Nerdcator MozFest session. Sign in if you want to be updated via email \uD83C\uDF0D\uD83C\uDF89 https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796738646267330564,
  "created_at" : "2016-11-10 15:37:50 +0000",
  "in_reply_to_screen_name" : "tmtm",
  "in_reply_to_user_id_str" : "869641",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shruti Mathur Desai",
      "screen_name" : "inothernews",
      "indices" : [ 0, 12 ],
      "id_str" : "7589162",
      "id" : 7589162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796737373207953409",
  "in_reply_to_user_id" : 7589162,
  "text" : "@inothernews Thanks again for showing up at the Nerdcator MozFest session.Sign in if you want 2 be updated via email https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796737373207953409,
  "created_at" : "2016-11-10 15:32:47 +0000",
  "in_reply_to_screen_name" : "inothernews",
  "in_reply_to_user_id_str" : "7589162",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lina Tran",
      "screen_name" : "Lmntran",
      "indices" : [ 0, 8 ],
      "id_str" : "3169923786",
      "id" : 3169923786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796736764547309569",
  "in_reply_to_user_id" : 3169923786,
  "text" : "@Lmntran Thanks again for showing up at the Nerdcator MozFest session.Sign in if you want to be updated via email \uD83C\uDF0D\uD83C\uDF89 https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796736764547309569,
  "created_at" : "2016-11-10 15:30:21 +0000",
  "in_reply_to_screen_name" : "Lmntran",
  "in_reply_to_user_id_str" : "3169923786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine",
      "screen_name" : "mbonsma",
      "indices" : [ 0, 8 ],
      "id_str" : "422839831",
      "id" : 422839831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796736610096312320",
  "in_reply_to_user_id" : 422839831,
  "text" : "@mbonsma Thanks again for showing up at the Nerdcator MozFest session! Sign in if you want to be updated via email\uD83C\uDF0D\uD83C\uDF89 https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796736610096312320,
  "created_at" : "2016-11-10 15:29:45 +0000",
  "in_reply_to_screen_name" : "mbonsma",
  "in_reply_to_user_id_str" : "422839831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian M Bot",
      "screen_name" : "BrianMBot",
      "indices" : [ 0, 10 ],
      "id_str" : "504127665",
      "id" : 504127665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796736333045764096",
  "in_reply_to_user_id" : 504127665,
  "text" : "@BrianMBot Thanks again for showing up at the Nerdcator MozFest session. Sign in if you want to be updated via email https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796736333045764096,
  "created_at" : "2016-11-10 15:28:39 +0000",
  "in_reply_to_screen_name" : "BrianMBot",
  "in_reply_to_user_id_str" : "504127665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi Desai",
      "screen_name" : "raviadesai",
      "indices" : [ 0, 11 ],
      "id_str" : "17257120",
      "id" : 17257120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PlXhpYMYZl",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfHdGR2GDRthJGI2sfnQ3QyulC17mS28Mz5w56U9dv3ah0pUQ\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796736155593097216",
  "in_reply_to_user_id" : 17257120,
  "text" : "@raviadesai Thanks again for showing up at the Nerdcator MozFest session.Sign in if you want to be updated via email https:\/\/t.co\/PlXhpYMYZl",
  "id" : 796736155593097216,
  "created_at" : "2016-11-10 15:27:56 +0000",
  "in_reply_to_screen_name" : "raviadesai",
  "in_reply_to_user_id_str" : "17257120",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796661387774791680",
  "geo" : { },
  "id_str" : "796662591720484866",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan i think i booked through skiplagged this time.",
  "id" : 796662591720484866,
  "in_reply_to_status_id" : 796661387774791680,
  "created_at" : "2016-11-10 10:35:37 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796658470749696000",
  "geo" : { },
  "id_str" : "796658936548048897",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan I think total roundtrip with the KEF &amp; BWI would have been ~300. But I\u2019m heading from BWI-&gt;LAX and later on SFO-&gt;KEF-&gt;FRA",
  "id" : 796658936548048897,
  "in_reply_to_status_id" : 796658470749696000,
  "created_at" : "2016-11-10 10:21:06 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796656290554609664",
  "geo" : { },
  "id_str" : "796657384303316992",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan nah, as we did the crowdfunding I had to take the cheapest flights possible. And will also get into BWI instead of IAD :D",
  "id" : 796657384303316992,
  "in_reply_to_status_id" : 796656290554609664,
  "created_at" : "2016-11-10 10:14:56 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/bs0uImqp3m",
      "expanded_url" : "http:\/\/www.vanityfair.com\/hollywood\/2016\/11\/aaron-sorkin-donald-trump-president-letter-daughter",
      "display_url" : "vanityfair.com\/hollywood\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796655750043017216",
  "text" : "\u00ABHere\u2019s what we\u2019ll do\u2026we\u2019ll fucking fight. (Roxy, there\u2019s a time for this kind of language and it\u2019s now.)\u00BB https:\/\/t.co\/bs0uImqp3m",
  "id" : 796655750043017216,
  "created_at" : "2016-11-10 10:08:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slobodan Radicev",
      "screen_name" : "RadicevSlobodan",
      "indices" : [ 0, 16 ],
      "id_str" : "1718512256",
      "id" : 1718512256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796654009805340672",
  "geo" : { },
  "id_str" : "796655684821585920",
  "in_reply_to_user_id" : 1718512256,
  "text" : "@RadicevSlobodan flying tomorrow morning, with a layover in KEF. :-)",
  "id" : 796655684821585920,
  "in_reply_to_status_id" : 796654009805340672,
  "created_at" : "2016-11-10 10:08:11 +0000",
  "in_reply_to_screen_name" : "RadicevSlobodan",
  "in_reply_to_user_id_str" : "1718512256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796630998985404416",
  "text" : "\u00ABWill you be on vacation-vacation or can I email you?\u00BB The drawback of people knowing you\u2019re only using annual leave to go to conferences. \uD83D\uDE12",
  "id" : 796630998985404416,
  "created_at" : "2016-11-10 08:30:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796499360880197632",
  "geo" : { },
  "id_str" : "796503812303454212",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice I\u2019ll keep you in my mind while being on my teaching duties tomorrow \uD83D\uDE0A",
  "id" : 796503812303454212,
  "in_reply_to_status_id" : 796499360880197632,
  "created_at" : "2016-11-10 00:04:41 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796463111544983552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086491413089, 8.818660146234798 ]
  },
  "id_str" : "796476536597741568",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice you\u2019ll rock it. \uD83D\uDC96\uD83D\uDE18",
  "id" : 796476536597741568,
  "in_reply_to_status_id" : 796463111544983552,
  "created_at" : "2016-11-09 22:16:18 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/796422514117316608\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/e0AceVxau6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw1190oXcAIxD9i.jpg",
      "id_str" : "796422414074867714",
      "id" : 796422414074867714,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw1190oXcAIxD9i.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/e0AceVxau6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085010326448, 8.818680822919795 ]
  },
  "id_str" : "796422514117316608",
  "text" : "Pretty much what I come to expect when neuroscience and human genetics pair up: deep reading of tea leafs. \uD83C\uDFB1\uD83D\uDD2E https:\/\/t.co\/e0AceVxau6",
  "id" : 796422514117316608,
  "created_at" : "2016-11-09 18:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796282256671277056",
  "text" : "\u00ABI guess we can exclude a good many places for a future home.\u00BB So all of the US is now on the same \u201Edo-not-move there\u201C-list with Pyongyang\u2026",
  "id" : 796282256671277056,
  "created_at" : "2016-11-09 09:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796270104136794112",
  "geo" : { },
  "id_str" : "796270760625106944",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr awesome, that\u2019ll do the trick ;)",
  "id" : 796270760625106944,
  "in_reply_to_status_id" : 796270104136794112,
  "created_at" : "2016-11-09 08:38:37 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796264398570618881",
  "geo" : { },
  "id_str" : "796264689294606336",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr nah, i mean: my partner &amp; co-conspirator on the idea will be there :D",
  "id" : 796264689294606336,
  "in_reply_to_status_id" : 796264398570618881,
  "created_at" : "2016-11-09 08:14:30 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796263291345637377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723992926805, 8.627503276646266 ]
  },
  "id_str" : "796263473919434753",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr ah, too bad! But there might be someone at sfn who could be interested in talking about that twin thing we discussed a while back!",
  "id" : 796263473919434753,
  "in_reply_to_status_id" : 796263291345637377,
  "created_at" : "2016-11-09 08:09:40 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796255113795006465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239735265922, 8.62750685971676 ]
  },
  "id_str" : "796262201199837185",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr when are you heading back? I\u2019ll arrive in SAN on the 16th!",
  "id" : 796262201199837185,
  "in_reply_to_status_id" : 796255113795006465,
  "created_at" : "2016-11-09 08:04:37 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796235845015584768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087512345992, 8.818583847226357 ]
  },
  "id_str" : "796237538860142592",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski and all I can offer are free hugs if wanted. \uD83D\uDE14",
  "id" : 796237538860142592,
  "in_reply_to_status_id" : 796235845015584768,
  "created_at" : "2016-11-09 06:26:37 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/796235514915463168\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/aPlF7Ichwd",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CwzL0zoXEAAHD7y.jpg",
      "id_str" : "796235342210863104",
      "id" : 796235342210863104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CwzL0zoXEAAHD7y.jpg",
      "sizes" : [ {
        "h" : 206,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/aPlF7Ichwd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090399348182, 8.818565458067523 ]
  },
  "id_str" : "796235514915463168",
  "text" : "Europe waking up this morning\u2026 https:\/\/t.co\/aPlF7Ichwd",
  "id" : 796235514915463168,
  "created_at" : "2016-11-09 06:18:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796230405426991104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090794992303, 8.818678253569505 ]
  },
  "id_str" : "796231570138992640",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick welcome back, see what happens when you stop tweeting?",
  "id" : 796231570138992640,
  "in_reply_to_status_id" : 796230405426991104,
  "created_at" : "2016-11-09 06:02:54 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082185083074, 8.818629663445817 ]
  },
  "id_str" : "796148740595847168",
  "text" : "\u00ABWest Virginia: Trump wins narrowly with NaN% of the vote.\u00BB two very similar NaNs I assume.",
  "id" : 796148740595847168,
  "created_at" : "2016-11-09 00:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796126134962417664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085817051537, 8.818841005170903 ]
  },
  "id_str" : "796126633879109633",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps good to reintroduce it then into higher ed as well!",
  "id" : 796126633879109633,
  "in_reply_to_status_id" : 796126134962417664,
  "created_at" : "2016-11-08 23:05:55 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796119814519525377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085817051537, 8.818841005170903 ]
  },
  "id_str" : "796126457588318208",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @NazeefaFatima more like long treats\u2019",
  "id" : 796126457588318208,
  "in_reply_to_status_id" : 796119814519525377,
  "created_at" : "2016-11-08 23:05:13 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796114372582109190",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086022769429, 8.81867773862943 ]
  },
  "id_str" : "796116859527499776",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima this is why we eat them before doing our tree reconstructions!",
  "id" : 796116859527499776,
  "in_reply_to_status_id" : 796114372582109190,
  "created_at" : "2016-11-08 22:27:05 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796114235713536005",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090494073575, 8.818618839870167 ]
  },
  "id_str" : "796114542241714176",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg let\u2019s see, on my way from SFO back to FRA I have another stop there :3",
  "id" : 796114542241714176,
  "in_reply_to_status_id" : 796114235713536005,
  "created_at" : "2016-11-08 22:17:52 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/soMGTbiYgq",
      "expanded_url" : "https:\/\/www.theguardian.com\/business\/2016\/nov\/08\/toblerone-gets-more-gappy-but-its-fans-are-not-happy",
      "display_url" : "theguardian.com\/business\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "796103420444889088",
  "text" : "The upside: Bioinformatics education will soon be able to visualize gappy alignments in another fun (and tasty) way. https:\/\/t.co\/soMGTbiYgq",
  "id" : 796103420444889088,
  "created_at" : "2016-11-08 21:33:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 12, 18 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 19, 33 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796023500486144001",
  "geo" : { },
  "id_str" : "796025791318491136",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley @heluc @Protohedgehog after the travel something local would be ++! Might also drop dead after the last few weeks :D",
  "id" : 796025791318491136,
  "in_reply_to_status_id" : 796023500486144001,
  "created_at" : "2016-11-08 16:25:12 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 7, 18 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 19, 33 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796023065582927873",
  "geo" : { },
  "id_str" : "796023145484455936",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @LouWoodley @Protohedgehog great! Looking forward to meet again!",
  "id" : 796023145484455936,
  "in_reply_to_status_id" : 796023065582927873,
  "created_at" : "2016-11-08 16:14:41 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 20, 31 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 59, 73 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796022341117550592",
  "geo" : { },
  "id_str" : "796022481798762497",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc staying with @LouWoodley who was kind enough to let @Protohedgehog and me crash!",
  "id" : 796022481798762497,
  "in_reply_to_status_id" : 796022341117550592,
  "created_at" : "2016-11-08 16:12:03 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796021166007787522",
  "geo" : { },
  "id_str" : "796021875218464768",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc I\u2019ll only come in on Friday afternoon. But enjoy today\u2019s apocalypse! \uD83D\uDE0A",
  "id" : 796021875218464768,
  "in_reply_to_status_id" : 796021166007787522,
  "created_at" : "2016-11-08 16:09:39 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796021166007787522",
  "geo" : { },
  "id_str" : "796021722415763456",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc a country where sex. assault is an attitude professional enough to run for president can\u2019t make claims for attire \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 796021722415763456,
  "in_reply_to_status_id" : 796021166007787522,
  "created_at" : "2016-11-08 16:09:02 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796020332138266624",
  "geo" : { },
  "id_str" : "796020561365319680",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc I\u2019ve never owned and\/or worn a suite\/tie and I will not start with it now. \u263A\uFE0F",
  "id" : 796020561365319680,
  "in_reply_to_status_id" : 796020332138266624,
  "created_at" : "2016-11-08 16:04:25 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "796004791105286145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724144869371, 8.627487337373962 ]
  },
  "id_str" : "796006636246749184",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I consider myself a somewhat experienced traveler, but I didn\u2019t manage to get into Whovian realms so far.",
  "id" : 796006636246749184,
  "in_reply_to_status_id" : 796004791105286145,
  "created_at" : "2016-11-08 15:09:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795982750037721088",
  "geo" : { },
  "id_str" : "795987068451192832",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr i\u2019m more and more confident that I\u2019ll catch my connection :D",
  "id" : 795987068451192832,
  "in_reply_to_status_id" : 795982750037721088,
  "created_at" : "2016-11-08 13:51:20 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795974096605642752",
  "geo" : { },
  "id_str" : "795979818609340419",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr partially, let\u2019s see how it turns out :D",
  "id" : 795979818609340419,
  "in_reply_to_status_id" : 795974096605642752,
  "created_at" : "2016-11-08 13:22:32 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795970331013947392",
  "geo" : { },
  "id_str" : "795973397566078976",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon i know, but just making the connection will fill the 1.5 hours :D",
  "id" : 795973397566078976,
  "in_reply_to_status_id" : 795970331013947392,
  "created_at" : "2016-11-08 12:57:01 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795970661084778496",
  "geo" : { },
  "id_str" : "795973333389049856",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr yeah, went to Iceland for vacation some time ago :)",
  "id" : 795973333389049856,
  "in_reply_to_status_id" : 795970661084778496,
  "created_at" : "2016-11-08 12:56:45 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724091181128, 8.627575226565831 ]
  },
  "id_str" : "795969262712143872",
  "text" : "I have a 1.5 h layover in Iceland on my way to #opencon and the airline is suggesting me things to visit while I\u2019m there. \uD83D\uDE02",
  "id" : 795969262712143872,
  "created_at" : "2016-11-08 12:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795910829451411456",
  "geo" : { },
  "id_str" : "795918493245984768",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon will just tell my boss that \u201EGoogle made me do it!\u201C (wonder whether that one has been court-tested already).",
  "id" : 795918493245984768,
  "in_reply_to_status_id" : 795910829451411456,
  "created_at" : "2016-11-08 09:18:50 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 0, 10 ],
      "id_str" : "14324284",
      "id" : 14324284
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 11, 19 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795870540334436353",
  "geo" : { },
  "id_str" : "795912803479482368",
  "in_reply_to_user_id" : 14324284,
  "text" : "@hyphaltip @heyaudy who needs \u201Egenome announcements\u201C anyway, if you can have \u201Egenomic shotgun reads announcements\u201C!",
  "id" : 795912803479482368,
  "in_reply_to_status_id" : 795870540334436353,
  "created_at" : "2016-11-08 08:56:14 +0000",
  "in_reply_to_screen_name" : "hyphaltip",
  "in_reply_to_user_id_str" : "14324284",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795909448241909760",
  "text" : "Google sends me an update on how long it would take me to get home right now. At 9am. Pointing to the wrong address. Well done, AI.",
  "id" : 795909448241909760,
  "created_at" : "2016-11-08 08:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795758811181150212",
  "geo" : { },
  "id_str" : "795759220331319296",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \uD83C\uDF89\uD83D\uDC4D",
  "id" : 795759220331319296,
  "in_reply_to_status_id" : 795758811181150212,
  "created_at" : "2016-11-07 22:45:57 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/V5gpHw5SJT",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-1915-map-that-helped-all-women-get-the-right-to-vote",
      "display_url" : "atlasobscura.com\/articles\/the-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795756908128903168",
  "text" : "\u00ABWomen using\u00A0cartography for their own purposes: equality and social justice\u00BB https:\/\/t.co\/V5gpHw5SJT",
  "id" : 795756908128903168,
  "created_at" : "2016-11-07 22:36:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/W6FEdGijn6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/795750042812514310",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "795750042812514310",
  "geo" : { },
  "id_str" : "795750569159880707",
  "in_reply_to_user_id" : 14286491,
  "text" : "Folks, we need to step up our game: gender segregation in genomics, with women being clearly underrepresented. https:\/\/t.co\/W6FEdGijn6",
  "id" : 795750569159880707,
  "in_reply_to_status_id" : 795750042812514310,
  "created_at" : "2016-11-07 22:11:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/xrvIIqWsUB",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002573",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795750042812514310",
  "text" : "\u00ABDifferences in Collaboration Patterns across Discipline, Career Stage, and Gender\u00BB https:\/\/t.co\/xrvIIqWsUB",
  "id" : 795750042812514310,
  "created_at" : "2016-11-07 22:09:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 3, 17 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 37, 48 ]
    }, {
      "text" : "openscience",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795713488941420544",
  "text" : "RT @annakrystalli: We're looking for #openaccess papers that have also published code and data. Propose your #openscience paper here: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "openscience",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Wh9ZPK1xas",
        "expanded_url" : "https:\/\/twitter.com\/annakrystalli\/status\/795642821944471552",
        "display_url" : "twitter.com\/annakrystalli\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "795643151545470976",
    "text" : "We're looking for #openaccess papers that have also published code and data. Propose your #openscience paper here: https:\/\/t.co\/Wh9ZPK1xas",
    "id" : 795643151545470976,
    "created_at" : "2016-11-07 15:04:44 +0000",
    "user" : {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "protected" : false,
      "id_str" : "15090415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871473821446025216\/VfW1yVvV_normal.jpg",
      "id" : 15090415,
      "verified" : false
    }
  },
  "id" : 795713488941420544,
  "created_at" : "2016-11-07 19:44:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristi Vlad",
      "screen_name" : "CristiVlad25",
      "indices" : [ 0, 13 ],
      "id_str" : "2188880010",
      "id" : 2188880010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795595455900094464",
  "geo" : { },
  "id_str" : "795645492692652032",
  "in_reply_to_user_id" : 2188880010,
  "text" : "@CristiVlad25 also: DM me your address if you want some openSNP stickers &amp; magnets! :-)",
  "id" : 795645492692652032,
  "in_reply_to_status_id" : 795595455900094464,
  "created_at" : "2016-11-07 15:14:02 +0000",
  "in_reply_to_screen_name" : "CristiVlad25",
  "in_reply_to_user_id_str" : "2188880010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristi Vlad",
      "screen_name" : "CristiVlad25",
      "indices" : [ 0, 13 ],
      "id_str" : "2188880010",
      "id" : 2188880010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795595455900094464",
  "geo" : { },
  "id_str" : "795645388678172672",
  "in_reply_to_user_id" : 2188880010,
  "text" : "@CristiVlad25 that\u2019s awesome, will use that as another example of how the openSNP data is used in future presentations! :-)",
  "id" : 795645388678172672,
  "in_reply_to_status_id" : 795595455900094464,
  "created_at" : "2016-11-07 15:13:37 +0000",
  "in_reply_to_screen_name" : "CristiVlad25",
  "in_reply_to_user_id_str" : "2188880010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795611215242338304",
  "geo" : { },
  "id_str" : "795644183931457540",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman I envy you a bit. Wish I could play with those too! :D",
  "id" : 795644183931457540,
  "in_reply_to_status_id" : 795611215242338304,
  "created_at" : "2016-11-07 15:08:50 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/aQyx2wfMYQ",
      "expanded_url" : "https:\/\/mygermandiction.wordpress.com\/2012\/02\/13\/%E2%80%9Egeborgenheit-or-what-we-really-need\/",
      "display_url" : "mygermandiction.wordpress.com\/2012\/02\/13\/%E2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795536080216924160",
  "text" : "TIL: Apparently it\u2019s not only me struggling to find an english equivalent to \u2018Geborgenheit\u2019, instead there isn\u2019t one https:\/\/t.co\/aQyx2wfMYQ",
  "id" : 795536080216924160,
  "created_at" : "2016-11-07 07:59:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795442186347085824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404065418259, 8.7533831281934 ]
  },
  "id_str" : "795510430143746048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \uD83D\uDC4D",
  "id" : 795510430143746048,
  "in_reply_to_status_id" : 795442186347085824,
  "created_at" : "2016-11-07 06:17:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795402104898813952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404010314264, 8.753383309233763 ]
  },
  "id_str" : "795405953378160640",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman sure, happy to help out! And let me think about the clustering (already have some chord ideas too)",
  "id" : 795405953378160640,
  "in_reply_to_status_id" : 795402104898813952,
  "created_at" : "2016-11-06 23:22:11 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795194463370940416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925128520692, 8.587602726212912 ]
  },
  "id_str" : "795223662488092672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw did you check Gitter? :)",
  "id" : 795223662488092672,
  "in_reply_to_status_id" : 795194463370940416,
  "created_at" : "2016-11-06 11:17:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 14, 24 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "795194463370940416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925128520692, 8.587602726212912 ]
  },
  "id_str" : "795223611888062464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @alanmrice thanks! \uD83D\uDC96",
  "id" : 795223611888062464,
  "in_reply_to_status_id" : 795194463370940416,
  "created_at" : "2016-11-06 11:17:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/KVZgGk0oou",
      "expanded_url" : "https:\/\/twitter.com\/_katsel\/status\/795016212422021121",
      "display_url" : "twitter.com\/_katsel\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926605498267, 8.58761377268295 ]
  },
  "id_str" : "795180861549330432",
  "text" : "The answer was \u00ABBayesian, but of course I\u2019d be accepting if they wanted to convert to another religion.\u00BB https:\/\/t.co\/KVZgGk0oou",
  "id" : 795180861549330432,
  "created_at" : "2016-11-06 08:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/795018603930198016\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/zU13jh4d6V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwh5NLiWEAAyZcB.jpg",
      "id_str" : "795018601572995072",
      "id" : 795018601572995072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwh5NLiWEAAyZcB.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zU13jh4d6V"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795018603930198016",
  "text" : "Reliving the #mozfest spirit. https:\/\/t.co\/zU13jh4d6V",
  "id" : 795018603930198016,
  "created_at" : "2016-11-05 21:43:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592808430525, 8.58761993939662 ]
  },
  "id_str" : "795015530994429952",
  "text" : "\u00ABIf you\u2019d raise a child: would you tell them about Santa?\u00BB \u2014 \u00ABNo way, more importantly: would you teach them Bayesian or Fisherian stats?\u00BB",
  "id" : 795015530994429952,
  "created_at" : "2016-11-05 21:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794943209944285184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921921461524, 8.587633106669815 ]
  },
  "id_str" : "794993042415644672",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice whops, @PhilippBayer to the rescue. Traveling without real Internet right now.",
  "id" : 794993042415644672,
  "in_reply_to_status_id" : 794943209944285184,
  "created_at" : "2016-11-05 20:01:26 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/794941657980473344\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/kltVZ567Em",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwgzKzHXgAAC4bW.jpg",
      "id_str" : "794941594843709440",
      "id" : 794941594843709440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwgzKzHXgAAC4bW.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/kltVZ567Em"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794941061974081536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927039857905, 8.587619470153918 ]
  },
  "id_str" : "794941657980473344",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice can recommend, would do again. https:\/\/t.co\/kltVZ567Em",
  "id" : 794941657980473344,
  "in_reply_to_status_id" : 794941061974081536,
  "created_at" : "2016-11-05 16:37:15 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ap8PSPM4xi",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMb3W3ADgQa\/",
      "display_url" : "instagram.com\/p\/BMb3W3ADgQa\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3667, 8.55 ]
  },
  "id_str" : "794941396390215686",
  "text" : "Rainbowish @ Z\u00FCrich, Switzerland https:\/\/t.co\/ap8PSPM4xi",
  "id" : 794941396390215686,
  "created_at" : "2016-11-05 16:36:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794938176641101824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35929620525328, 8.587636366079122 ]
  },
  "id_str" : "794940104129253376",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice yes! Have been thinking about that one for a while.",
  "id" : 794940104129253376,
  "in_reply_to_status_id" : 794938176641101824,
  "created_at" : "2016-11-05 16:31:04 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926086505854, 8.587609789079595 ]
  },
  "id_str" : "794937421402095616",
  "text" : "Do I happen to know any tattoo artist who thinks they could get me a good tattoo of Rosalind Franklin\u2019s Photograph 51?",
  "id" : 794937421402095616,
  "created_at" : "2016-11-05 16:20:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926852203195, 8.587615803452858 ]
  },
  "id_str" : "794886909982031874",
  "text" : "\u00ABMaybe Duolingo, after \u201CFlirting in German\u201D, offers a hidden \u201CFighting in German\u201D-lesson?\u00BB",
  "id" : 794886909982031874,
  "created_at" : "2016-11-05 12:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/7uOWjHMwjx",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/space-trash-space-treasure\/",
      "display_url" : "99percentinvisible.org\/episode\/space-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794572977862045697",
  "text" : "Wanna see my space junk? How zero-G sex, space tourism and extra-terrestrial archeology relate. https:\/\/t.co\/7uOWjHMwjx",
  "id" : 794572977862045697,
  "created_at" : "2016-11-04 16:12:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/YniWAzVe9g",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/794558576094285824",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.1585512133773, 8.56665833853983 ]
  },
  "id_str" : "794560865315995648",
  "text" : "Read about all the fun I had last weekend at #MozFest \uD83C\uDF89 https:\/\/t.co\/YniWAzVe9g",
  "id" : 794560865315995648,
  "created_at" : "2016-11-04 15:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristi Vlad",
      "screen_name" : "CristiVlad25",
      "indices" : [ 0, 13 ],
      "id_str" : "2188880010",
      "id" : 2188880010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794535720945852416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246200617828, 8.627517498349512 ]
  },
  "id_str" : "794536834856603648",
  "in_reply_to_user_id" : 2188880010,
  "text" : "@CristiVlad25 awesome, looking forward to it!",
  "id" : 794536834856603648,
  "in_reply_to_status_id" : 794535720945852416,
  "created_at" : "2016-11-04 13:48:37 +0000",
  "in_reply_to_screen_name" : "CristiVlad25",
  "in_reply_to_user_id_str" : "2188880010",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/RH6SchHUFJ",
      "expanded_url" : "https:\/\/twitter.com\/sacca\/status\/794363928008531968",
      "display_url" : "twitter.com\/sacca\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794505691801276418",
  "text" : "Misread this as \u201Eyoung feral employees\u201C and automatically switched to an Attenborough-voice in my mind. https:\/\/t.co\/RH6SchHUFJ",
  "id" : 794505691801276418,
  "created_at" : "2016-11-04 11:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/fVxBfHloy5",
      "expanded_url" : "https:\/\/twitter.com\/iff_or\/status\/794200642222886912",
      "display_url" : "twitter.com\/iff_or\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794205419510132737",
  "text" : "Which would be a shame, the \u201Ethank you\u201Cs make the bus travel awesome! https:\/\/t.co\/fVxBfHloy5",
  "id" : 794205419510132737,
  "created_at" : "2016-11-03 15:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Pool",
      "screen_name" : "thepooluk",
      "indices" : [ 3, 13 ],
      "id_str" : "2977849811",
      "id" : 2977849811
    }, {
      "name" : "Caroline O'Donoghue",
      "screen_name" : "Czaroline",
      "indices" : [ 63, 73 ],
      "id_str" : "36801079",
      "id" : 36801079
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thepooluk\/status\/793787031830818816\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/QRSi1bhwDk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwQZEdMWYAENU2h.jpg",
      "id_str" : "793786998670647297",
      "id" : 793786998670647297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwQZEdMWYAENU2h.jpg",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/QRSi1bhwDk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ypJJY40GUR",
      "expanded_url" : "https:\/\/www.the-pool.com\/news-views\/opinion\/2016\/44\/the-price-of-an-irish-abortion",
      "display_url" : "the-pool.com\/news-views\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794136119432585216",
  "text" : "RT @thepooluk: How much does an Irish abortion literally cost? @Czaroline does the maths: https:\/\/t.co\/ypJJY40GUR https:\/\/t.co\/QRSi1bhwDk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caroline O'Donoghue",
        "screen_name" : "Czaroline",
        "indices" : [ 48, 58 ],
        "id_str" : "36801079",
        "id" : 36801079
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thepooluk\/status\/793787031830818816\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/QRSi1bhwDk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwQZEdMWYAENU2h.jpg",
        "id_str" : "793786998670647297",
        "id" : 793786998670647297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwQZEdMWYAENU2h.jpg",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 772,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 772,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/QRSi1bhwDk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/ypJJY40GUR",
        "expanded_url" : "https:\/\/www.the-pool.com\/news-views\/opinion\/2016\/44\/the-price-of-an-irish-abortion",
        "display_url" : "the-pool.com\/news-views\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793787031830818816",
    "text" : "How much does an Irish abortion literally cost? @Czaroline does the maths: https:\/\/t.co\/ypJJY40GUR https:\/\/t.co\/QRSi1bhwDk",
    "id" : 793787031830818816,
    "created_at" : "2016-11-02 12:09:10 +0000",
    "user" : {
      "name" : "The Pool",
      "screen_name" : "thepooluk",
      "protected" : false,
      "id_str" : "2977849811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816660960341557249\/OWCdjJPI_normal.jpg",
      "id" : 2977849811,
      "verified" : true
    }
  },
  "id" : 794136119432585216,
  "created_at" : "2016-11-03 11:16:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/oGkDFZO7Lu",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/152553748659\/waiting-for-my-pi-to-read-a-draft",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/152553748\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794093993617453056",
  "text" : "pretty much https:\/\/t.co\/oGkDFZO7Lu",
  "id" : 794093993617453056,
  "created_at" : "2016-11-03 08:28:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/aw6ZlAQcGR",
      "expanded_url" : "https:\/\/twitter.com\/dbarthjones\/status\/793926989237383168",
      "display_url" : "twitter.com\/dbarthjones\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00404966952458, 8.269031200983965 ]
  },
  "id_str" : "793933088271331328",
  "text" : "I can predict the likelihood of Venter\u2019s statement being true without even having looked at his genome. \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/aw6ZlAQcGR",
  "id" : 793933088271331328,
  "created_at" : "2016-11-02 21:49:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 21, 31 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793867761294323713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082315002573, 8.818629579626785 ]
  },
  "id_str" : "793877698024247296",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson I bet @SCEdmunds has ideas!",
  "id" : 793877698024247296,
  "in_reply_to_status_id" : 793867761294323713,
  "created_at" : "2016-11-02 18:09:27 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minn Soe",
      "screen_name" : "minn_so",
      "indices" : [ 0, 8 ],
      "id_str" : "86845693",
      "id" : 86845693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793865822678679552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17154557635092, 8.627488072969603 ]
  },
  "id_str" : "793866625795620864",
  "in_reply_to_user_id" : 86845693,
  "text" : "@minn_so hope we as a group can decide on a way forward. For now I just try to learn some more Javascript \uD83D\uDE02",
  "id" : 793866625795620864,
  "in_reply_to_status_id" : 793865822678679552,
  "created_at" : "2016-11-02 17:25:27 +0000",
  "in_reply_to_screen_name" : "minn_so",
  "in_reply_to_user_id_str" : "86845693",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minn Soe",
      "screen_name" : "minn_so",
      "indices" : [ 0, 8 ],
      "id_str" : "86845693",
      "id" : 86845693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793865822678679552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17158803069049, 8.628232469790268 ]
  },
  "id_str" : "793866196609277952",
  "in_reply_to_user_id" : 86845693,
  "text" : "@minn_so yes, that\u2019s by design for now. There\u2019s a pad to leave your email, want to send email to all participants later this week.",
  "id" : 793866196609277952,
  "in_reply_to_status_id" : 793865822678679552,
  "created_at" : "2016-11-02 17:23:45 +0000",
  "in_reply_to_screen_name" : "minn_so",
  "in_reply_to_user_id_str" : "86845693",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minn Soe",
      "screen_name" : "minn_so",
      "indices" : [ 0, 8 ],
      "id_str" : "86845693",
      "id" : 86845693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793863940870643712",
  "geo" : { },
  "id_str" : "793864232588701700",
  "in_reply_to_user_id" : 86845693,
  "text" : "@minn_so I started to work on it a bit already :D",
  "id" : 793864232588701700,
  "in_reply_to_status_id" : 793863940870643712,
  "created_at" : "2016-11-02 17:15:56 +0000",
  "in_reply_to_screen_name" : "minn_so",
  "in_reply_to_user_id_str" : "86845693",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793847918914592768",
  "geo" : { },
  "id_str" : "793848008823767040",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe awesome, please be in touch!",
  "id" : 793848008823767040,
  "in_reply_to_status_id" : 793847918914592768,
  "created_at" : "2016-11-02 16:11:28 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 0, 9 ],
      "id_str" : "16728620",
      "id" : 16728620
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 10, 19 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793821109288337408",
  "geo" : { },
  "id_str" : "793822857725898753",
  "in_reply_to_user_id" : 16728620,
  "text" : "@nshockey @open_con there goes my plan to travel carry-on only!",
  "id" : 793822857725898753,
  "in_reply_to_status_id" : 793821109288337408,
  "created_at" : "2016-11-02 14:31:32 +0000",
  "in_reply_to_screen_name" : "nshockey",
  "in_reply_to_user_id_str" : "16728620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 0, 14 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 15, 24 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793821881010884608",
  "geo" : { },
  "id_str" : "793822775068753921",
  "in_reply_to_user_id" : 3209949862,
  "text" : "@AprilHathcock @open_con yes, I am, see you there! \uD83C\uDF89\uD83C\uDF89",
  "id" : 793822775068753921,
  "in_reply_to_status_id" : 793821881010884608,
  "created_at" : "2016-11-02 14:31:12 +0000",
  "in_reply_to_screen_name" : "AprilHathcock",
  "in_reply_to_user_id_str" : "3209949862",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 20, 29 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/599ySwLbo6",
      "expanded_url" : "http:\/\/www.opencon2016.org\/logistics?utm_campaign=logistics_oct31&utm_medium=email&utm_source=righttoresearch",
      "display_url" : "opencon2016.org\/logistics?utm_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793820160524218368",
  "text" : "Extreme packing for @open_con: \u00ABIf you can, please do bring a laptop or table and any peripherals needed.\u00BB \uD83D\uDE02 https:\/\/t.co\/599ySwLbo6",
  "id" : 793820160524218368,
  "created_at" : "2016-11-02 14:20:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793791309060378626",
  "geo" : { },
  "id_str" : "793794774952271872",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe any way one can help?",
  "id" : 793794774952271872,
  "in_reply_to_status_id" : 793791309060378626,
  "created_at" : "2016-11-02 12:39:56 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Hohner",
      "screen_name" : "janhohner",
      "indices" : [ 0, 10 ],
      "id_str" : "114832665",
      "id" : 114832665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793745289463103488",
  "geo" : { },
  "id_str" : "793754451437903872",
  "in_reply_to_user_id" : 114832665,
  "text" : "@janhohner hugs if wanted!",
  "id" : 793754451437903872,
  "in_reply_to_status_id" : 793745289463103488,
  "created_at" : "2016-11-02 09:59:43 +0000",
  "in_reply_to_screen_name" : "janhohner",
  "in_reply_to_user_id_str" : "114832665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 5, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232403484574, 8.627562647538337 ]
  },
  "id_str" : "793743627663118337",
  "text" : "Post-#MozFest-partum depression is a thing, right?",
  "id" : 793743627663118337,
  "created_at" : "2016-11-02 09:16:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/fq6HpBxxv5",
      "expanded_url" : "http:\/\/www.wnyc.org\/story\/ellen-burstyn-gloria-steinem-death-sex-money",
      "display_url" : "wnyc.org\/story\/ellen-bu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05932432414403, 8.782212991226467 ]
  },
  "id_str" : "793713865112621056",
  "text" : "\u00ABIt\u2019s important for somebody who could play the game and win, to say the game isn\u2019t worth shit.\u00BB https:\/\/t.co\/fq6HpBxxv5",
  "id" : 793713865112621056,
  "created_at" : "2016-11-02 07:18:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793409235308666880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17276881606668, 8.627577746352205 ]
  },
  "id_str" : "793409935551959040",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna I was running around in t-shirts for the last few days!",
  "id" : 793409935551959040,
  "in_reply_to_status_id" : 793409235308666880,
  "created_at" : "2016-11-01 11:10:44 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793407889507508224",
  "geo" : { },
  "id_str" : "793408675406876673",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna yep, post-Mozfest einen Tag mit Freund*innen durch London. \uD83C\uDF89",
  "id" : 793408675406876673,
  "in_reply_to_status_id" : 793407889507508224,
  "created_at" : "2016-11-01 11:05:43 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/fLvKBkwbQI",
      "expanded_url" : "https:\/\/twitter.com\/keyboardpipette\/status\/793406530972442624",
      "display_url" : "twitter.com\/keyboardpipett\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793407452310040576",
  "text" : "\u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/fLvKBkwbQI",
  "id" : 793407452310040576,
  "created_at" : "2016-11-01 11:00:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793407178958929920",
  "geo" : { },
  "id_str" : "793407323364585472",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna und ich dachte du h\u00E4ttest gestern auch einfach einen Tag off gehabt so wie ich. Mir war es erst gar nicht aufgefallen :D",
  "id" : 793407323364585472,
  "in_reply_to_status_id" : 793407178958929920,
  "created_at" : "2016-11-01 11:00:21 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793406784547524608",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna awww&lt;3 \uD83D\uDC96\uD83D\uDC96\uD83D\uDC96\uD83D\uDC36 (heute ist Dienstag \uD83D\uDE09)",
  "id" : 793406784547524608,
  "created_at" : "2016-11-01 10:58:12 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ainsley Newson",
      "screen_name" : "biomedethics",
      "indices" : [ 3, 16 ],
      "id_str" : "277143687",
      "id" : 277143687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhD",
      "indices" : [ 36, 40 ]
    }, {
      "text" : "scholarship",
      "indices" : [ 41, 53 ]
    }, {
      "text" : "genomic",
      "indices" : [ 86, 94 ]
    }, {
      "text" : "data",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rUZ2kmxSbV",
      "expanded_url" : "http:\/\/agile2.ucc.usyd.edu.au\/ro\/opportunities\/scholarships\/1814",
      "display_url" : "agile2.ucc.usyd.edu.au\/ro\/opportuniti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793399795243159553",
  "text" : "RT @biomedethics: I'm advertising a #PhD #scholarship in ethical and legal aspects of #genomic #data sharing: https:\/\/t.co\/rUZ2kmxSbV. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhD",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "scholarship",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "genomic",
        "indices" : [ 68, 76 ]
      }, {
        "text" : "data",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/rUZ2kmxSbV",
        "expanded_url" : "http:\/\/agile2.ucc.usyd.edu.au\/ro\/opportunities\/scholarships\/1814",
        "display_url" : "agile2.ucc.usyd.edu.au\/ro\/opportuniti\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rbbuPgriid",
        "expanded_url" : "https:\/\/twitter.com\/PublicEthics\/status\/793341984819720192",
        "display_url" : "twitter.com\/PublicEthics\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793346798693654528",
    "text" : "I'm advertising a #PhD #scholarship in ethical and legal aspects of #genomic #data sharing: https:\/\/t.co\/rUZ2kmxSbV. https:\/\/t.co\/rbbuPgriid",
    "id" : 793346798693654528,
    "created_at" : "2016-11-01 06:59:51 +0000",
    "user" : {
      "name" : "Ainsley Newson",
      "screen_name" : "biomedethics",
      "protected" : false,
      "id_str" : "277143687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645395738235539456\/Iq5yJ9SZ_normal.jpg",
      "id" : 277143687,
      "verified" : false
    }
  },
  "id" : 793399795243159553,
  "created_at" : "2016-11-01 10:30:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793393624457310208",
  "geo" : { },
  "id_str" : "793393785019457536",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 you need to see my hand-drawn figures!",
  "id" : 793393785019457536,
  "in_reply_to_status_id" : 793393624457310208,
  "created_at" : "2016-11-01 10:06:33 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/lOIDBSDPV6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMQ2e1Qj_XH\/",
      "display_url" : "instagram.com\/p\/BMQ2e1Qj_XH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "793391358396489728",
  "text" : "Writing with a view https:\/\/t.co\/lOIDBSDPV6",
  "id" : 793391358396489728,
  "created_at" : "2016-11-01 09:56:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/rmYp43BxZD",
      "expanded_url" : "https:\/\/twitter.com\/trans_code_ch\/status\/793221540427001856",
      "display_url" : "twitter.com\/trans_code_ch\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11154863558716, 8.688912532069843 ]
  },
  "id_str" : "793359380238524418",
  "text" : "omg, just had a discussion about doing something like this as a #mozfest session two days ago! \uD83D\uDE0D https:\/\/t.co\/rmYp43BxZD",
  "id" : 793359380238524418,
  "created_at" : "2016-11-01 07:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05888420383079, 8.802511939659844 ]
  },
  "id_str" : "793349504997220353",
  "text" : "Unexpected: Wanting to go back to London, as the weather\u2019s so much nicer over there.",
  "id" : 793349504997220353,
  "created_at" : "2016-11-01 07:10:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]