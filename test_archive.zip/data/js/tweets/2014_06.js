Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 3, 18 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    }, {
      "name" : "Sumit Middha",
      "screen_name" : "bioinfosm",
      "indices" : [ 47, 57 ],
      "id_str" : "118266357",
      "id" : 118266357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FTW",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "UNIX",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481532573433470976",
  "text" : "RT @BioDataGanache: Simple approaches #FTW! MT @bioinfosm: #UNIX Grep Command Not FusionMap\/FusionFinder\/ChimeraScan Captures Fusion Gene h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sumit Middha",
        "screen_name" : "bioinfosm",
        "indices" : [ 27, 37 ],
        "id_str" : "118266357",
        "id" : 118266357
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FTW",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "UNIX",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/RvE9Wgh30L",
        "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pone.0099439",
        "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481532073854128129",
    "text" : "Simple approaches #FTW! MT @bioinfosm: #UNIX Grep Command Not FusionMap\/FusionFinder\/ChimeraScan Captures Fusion Gene http:\/\/t.co\/RvE9Wgh30L",
    "id" : 481532073854128129,
    "created_at" : "2014-06-24 20:19:27 +0000",
    "user" : {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "protected" : false,
      "id_str" : "1040758742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825446808696483840\/nMI6-h4y_normal.jpg",
      "id" : 1040758742,
      "verified" : false
    }
  },
  "id" : 481532573433470976,
  "created_at" : "2014-06-24 20:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/07i4gPEgYE",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1722",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723092667, 8.6275949667 ]
  },
  "id_str" : "481509414319718400",
  "text" : "insignificant http:\/\/t.co\/07i4gPEgYE",
  "id" : 481509414319718400,
  "created_at" : "2014-06-24 18:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/mXE94YJdBb",
      "expanded_url" : "http:\/\/j.mp\/1jLafiX",
      "display_url" : "j.mp\/1jLafiX"
    } ]
  },
  "geo" : { },
  "id_str" : "481455391197638656",
  "text" : "RT @brainpicker: For regular rereading: How to make your own luck in life http:\/\/t.co\/mXE94YJdBb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/mXE94YJdBb",
        "expanded_url" : "http:\/\/j.mp\/1jLafiX",
        "display_url" : "j.mp\/1jLafiX"
      } ]
    },
    "geo" : { },
    "id_str" : "481452193166266368",
    "text" : "For regular rereading: How to make your own luck in life http:\/\/t.co\/mXE94YJdBb",
    "id" : 481452193166266368,
    "created_at" : "2014-06-24 15:02:02 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 481455391197638656,
  "created_at" : "2014-06-24 15:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Metagenomics",
      "indices" : [ 65, 78 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 102, 117 ]
    }, {
      "text" : "\u017A",
      "indices" : [ 118, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/lxQocLT8kp",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2014\/06\/19\/bioinformatics.btu395.abstract",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481449017751400448",
  "text" : "RT @genetics_blog: Omega: an Overlap-graph de novo Assembler for #Metagenomics http:\/\/t.co\/lxQocLT8kp #bioinformatics #\u017A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Metagenomics",
        "indices" : [ 46, 59 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 83, 98 ]
      }, {
        "text" : "\u017A",
        "indices" : [ 99, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/lxQocLT8kp",
        "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2014\/06\/19\/bioinformatics.btu395.abstract",
        "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481436670001418240",
    "text" : "Omega: an Overlap-graph de novo Assembler for #Metagenomics http:\/\/t.co\/lxQocLT8kp #bioinformatics #\u017A",
    "id" : 481436670001418240,
    "created_at" : "2014-06-24 14:00:21 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 481449017751400448,
  "created_at" : "2014-06-24 14:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/vr53JZreVt",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/24\/thomas-pikettys-capital-in-t.html",
      "display_url" : "boingboing.net\/2014\/06\/24\/tho\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723092667, 8.6275949667 ]
  },
  "id_str" : "481427543514693632",
  "text" : "\u00ABthere is a spectre haunting Capital in the 21st Century and it is Kapital\u00BB http:\/\/t.co\/vr53JZreVt",
  "id" : 481427543514693632,
  "created_at" : "2014-06-24 13:24:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/aCM7K3wHGg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9sObr3dwdeE",
      "display_url" : "youtube.com\/watch?v=9sObr3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723092667, 8.6275949667 ]
  },
  "id_str" : "481413062290075648",
  "text" : "\u00ABIt\u2019s essentially that a slap \u2013 mitigated by permission \u2013 is a hug.\u00BB https:\/\/t.co\/aCM7K3wHGg",
  "id" : 481413062290075648,
  "created_at" : "2014-06-24 12:26:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2600\uFE0Femoticon\u2600\uFE0Fof\u2600\uFE0Fthe\u2600\uFE0Fmoon\u2600\uFE0F",
      "screen_name" : "Uptomyknees",
      "indices" : [ 3, 15 ],
      "id_str" : "83112392",
      "id" : 83112392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/rteaDprspq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ninOz5ValUM&list=UU9e70u7DXmwFhuWbibgSWeg",
      "display_url" : "youtube.com\/watch?v=ninOz5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481411655520501760",
  "text" : "RT @Uptomyknees: i asked 40 people to hit each other in the face for the first time\nhttps:\/\/t.co\/rteaDprspq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/rteaDprspq",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ninOz5ValUM&list=UU9e70u7DXmwFhuWbibgSWeg",
        "display_url" : "youtube.com\/watch?v=ninOz5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481155969570054144",
    "text" : "i asked 40 people to hit each other in the face for the first time\nhttps:\/\/t.co\/rteaDprspq",
    "id" : 481155969570054144,
    "created_at" : "2014-06-23 19:24:57 +0000",
    "user" : {
      "name" : "\u2600\uFE0Femoticon\u2600\uFE0Fof\u2600\uFE0Fthe\u2600\uFE0Fmoon\u2600\uFE0F",
      "screen_name" : "Uptomyknees",
      "protected" : false,
      "id_str" : "83112392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915020483149447168\/fiwWalAZ_normal.jpg",
      "id" : 83112392,
      "verified" : true
    }
  },
  "id" : 481411655520501760,
  "created_at" : "2014-06-24 12:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481371500642312192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097311838, 8.2832207771 ]
  },
  "id_str" : "481371783258714112",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a including increased libido in the list of maladies is also telling for the time.",
  "id" : 481371783258714112,
  "in_reply_to_status_id" : 481371500642312192,
  "created_at" : "2014-06-24 09:42:31 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 137, 142 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/1IiDEbV4Em",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Bicycle_face",
      "display_url" : "en.wikipedia.org\/wiki\/Bicycle_f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00956598, 8.2828940122 ]
  },
  "id_str" : "481369652778766336",
  "text" : "\u00ABIn addition, physicians warned of maladies caused by cycling including tuberculosis &amp; increased libido\u00BB https:\/\/t.co\/1IiDEbV4Em \/HT @li5a",
  "id" : 481369652778766336,
  "created_at" : "2014-06-24 09:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/kJHpaFAlZr",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=1088",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00956598, 8.2828940122 ]
  },
  "id_str" : "481362272976396288",
  "text" : "don\u2019t love someone to save yourself http:\/\/t.co\/kJHpaFAlZr",
  "id" : 481362272976396288,
  "created_at" : "2014-06-24 09:04:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 90, 103 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pacbio",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7IDRQ8TIN9",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2014\/06\/18\/006395",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481169965467594752",
  "text" : "Error correction and assembly complexity of single molecule sequencing reads. #pacbio \/cc @PhilippBayer http:\/\/t.co\/7IDRQ8TIN9",
  "id" : 481169965467594752,
  "created_at" : "2014-06-23 20:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/DpovKQKfVt",
      "expanded_url" : "http:\/\/instagram.com\/p\/pmVH2Phwsb\/",
      "display_url" : "instagram.com\/p\/pmVH2Phwsb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173591317, 8.633167204 ]
  },
  "id_str" : "481162250053357568",
  "text" : "Biologicum @ Uni Campus Riedberg, Frankfurt am Main http:\/\/t.co\/DpovKQKfVt",
  "id" : 481162250053357568,
  "created_at" : "2014-06-23 19:49:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481159847644495872",
  "text" : "social jetlag status: my breakfast is interrupted by people drinking their after-work-cider.",
  "id" : 481159847644495872,
  "created_at" : "2014-06-23 19:40:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/s9Oc8WtBnE",
      "expanded_url" : "http:\/\/www.theallium.com\/biology\/green-alga-sure-getting-lichen-relationship\/",
      "display_url" : "theallium.com\/biology\/green-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481131189622013952",
  "text" : "I feel you Ms Alga: Green Alga not sure what she is getting out of lichen relationship http:\/\/t.co\/s9Oc8WtBnE",
  "id" : 481131189622013952,
  "created_at" : "2014-06-23 17:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/Em5FU5p2mO",
      "expanded_url" : "http:\/\/opinionator.blogs.nytimes.com\/2014\/06\/13\/no-clocking-out\/?smid=tw-share",
      "display_url" : "opinionator.blogs.nytimes.com\/2014\/06\/13\/no-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481115751982845952",
  "text" : "No Money, No Time http:\/\/t.co\/Em5FU5p2mO",
  "id" : 481115751982845952,
  "created_at" : "2014-06-23 16:45:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/O10G4dwj3x",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=1101",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481093873599807488",
  "text" : "be more kind of weird http:\/\/t.co\/O10G4dwj3x",
  "id" : 481093873599807488,
  "created_at" : "2014-06-23 15:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/KD6Yw1DfU6",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/23\/humans-barking-at-dogs.html",
      "display_url" : "boingboing.net\/2014\/06\/23\/hum\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481088318411927552",
  "text" : "humans barking at dogs http:\/\/t.co\/KD6Yw1DfU6",
  "id" : 481088318411927552,
  "created_at" : "2014-06-23 14:56:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 82, 91 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/xcQv1GzDSC",
      "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2014\/06\/30\/140630fa_fact_sedaris?currentPage=all",
      "display_url" : "newyorker.com\/reporting\/2014\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230416, 8.627585816 ]
  },
  "id_str" : "481057262510043138",
  "text" : "Stepping Out \u2013 David Sedaris on living the Fitbit life http:\/\/t.co\/xcQv1GzDSC \/cc @eramirez",
  "id" : 481057262510043138,
  "created_at" : "2014-06-23 12:52:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mohamed Noor",
      "screen_name" : "mafnoor",
      "indices" : [ 3, 11 ],
      "id_str" : "24001758",
      "id" : 24001758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Evol2014",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/4erHNCs8m6",
      "expanded_url" : "https:\/\/sites.google.com\/site\/noorlabduke\/seminardrinkinggame",
      "display_url" : "sites.google.com\/site\/noorlabdu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481027637381713920",
  "text" : "RT @mafnoor: Science talk drinking game: https:\/\/t.co\/4erHNCs8m6 #Evol2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Evol2014",
        "indices" : [ 52, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/4erHNCs8m6",
        "expanded_url" : "https:\/\/sites.google.com\/site\/noorlabduke\/seminardrinkinggame",
        "display_url" : "sites.google.com\/site\/noorlabdu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480843192787804161",
    "text" : "Science talk drinking game: https:\/\/t.co\/4erHNCs8m6 #Evol2014",
    "id" : 480843192787804161,
    "created_at" : "2014-06-22 22:42:05 +0000",
    "user" : {
      "name" : "Mohamed Noor",
      "screen_name" : "mafnoor",
      "protected" : false,
      "id_str" : "24001758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/189406342\/noor_normal.jpg",
      "id" : 24001758,
      "verified" : false
    }
  },
  "id" : 481027637381713920,
  "created_at" : "2014-06-23 10:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/pW1IT3Yw1L",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3397",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096576267, 8.2829851322 ]
  },
  "id_str" : "480805552201543680",
  "text" : "the defecation-moderated awkwardness test http:\/\/t.co\/pW1IT3Yw1L",
  "id" : 480805552201543680,
  "created_at" : "2014-06-22 20:12:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095735192, 8.2829643071 ]
  },
  "id_str" : "480771877544415232",
  "text" : "\u00ABEs ist ja auch nicht alles schlecht und er hat auch seine guten Seiten. Er ist zum Beispiel nicht Hitler.\u00BB",
  "id" : 480771877544415232,
  "created_at" : "2014-06-22 17:58:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096505064, 8.2829799862 ]
  },
  "id_str" : "480713473064968192",
  "text" : "\u00ABDu wirkst nachdenklich, woran denkst du?\u00BB \u2014 \u00ABTeen Pregnancies.\u00BB \u2014 \u00ABSorry to break the news, aber daf\u00FCr bist du ca. 20 Jahre zu sp\u00E4t dran.\u00BB",
  "id" : 480713473064968192,
  "created_at" : "2014-06-22 14:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/CbgxbQSs5D",
      "expanded_url" : "http:\/\/instagram.com\/p\/pi-r6ABwr8\/",
      "display_url" : "instagram.com\/p\/pi-r6ABwr8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.005940563, 8.286528378 ]
  },
  "id_str" : "480690699667378176",
  "text" : "\u00ABWarte, ich mach es gleich im Bett. Dann kannst du dich in deiner Alpacalypse r\u00E4keln.\u00BB @ Elfenbeinturm http:\/\/t.co\/CbgxbQSs5D",
  "id" : 480690699667378176,
  "created_at" : "2014-06-22 12:36:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480687797062615040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096617733, 8.2828378771 ]
  },
  "id_str" : "480688436731707392",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode das passiert in der Mittagspause und bei L\u00E4nderspielen.",
  "id" : 480688436731707392,
  "in_reply_to_status_id" : 480687797062615040,
  "created_at" : "2014-06-22 12:27:08 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009594393, 8.2829424457 ]
  },
  "id_str" : "480687323714420736",
  "text" : "\u00ABDas w\u00E4re doch ein Job f\u00FCr dich: Lama-Wanderf\u00FChrerin by day, Sextoy-Makerin by night.\u00BB",
  "id" : 480687323714420736,
  "created_at" : "2014-06-22 12:22:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 3, 16 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/arielwaldman\/status\/480567338400354305\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/cg9m4S012I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqtRb-WCMAAjes-.jpg",
      "id_str" : "480567326278823936",
      "id" : 480567326278823936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqtRb-WCMAAjes-.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/cg9m4S012I"
    } ],
    "hashtags" : [ {
      "text" : "foocamp",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "okgo",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480684676047069184",
  "text" : "RT @arielwaldman: My ultimate message. #foocamp #okgo http:\/\/t.co\/cg9m4S012I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arielwaldman\/status\/480567338400354305\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/cg9m4S012I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqtRb-WCMAAjes-.jpg",
        "id_str" : "480567326278823936",
        "id" : 480567326278823936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqtRb-WCMAAjes-.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/cg9m4S012I"
      } ],
      "hashtags" : [ {
        "text" : "foocamp",
        "indices" : [ 21, 29 ]
      }, {
        "text" : "okgo",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480567338400354305",
    "text" : "My ultimate message. #foocamp #okgo http:\/\/t.co\/cg9m4S012I",
    "id" : 480567338400354305,
    "created_at" : "2014-06-22 04:25:56 +0000",
    "user" : {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "protected" : false,
      "id_str" : "814304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2530407461\/xujyyx9bdf3wi65o5a60_normal.jpeg",
      "id" : 814304,
      "verified" : true
    }
  },
  "id" : 480684676047069184,
  "created_at" : "2014-06-22 12:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 33, 39 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480680952952537088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096037822, 8.2829493816 ]
  },
  "id_str" : "480681454931021824",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon das kommt darauf an ob @Lobot sich entscheidet mit einzuziehen oder nicht.",
  "id" : 480681454931021824,
  "in_reply_to_status_id" : 480680952952537088,
  "created_at" : "2014-06-22 11:59:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480656421642838017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096658883, 8.2830127921 ]
  },
  "id_str" : "480677953706418176",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot und isst so niedlich wie die Mutter &lt;3",
  "id" : 480677953706418176,
  "in_reply_to_status_id" : 480656421642838017,
  "created_at" : "2014-06-22 11:45:29 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480654318492983297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7588918927, 9.3999478407 ]
  },
  "id_str" : "480655739061829632",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ah, the list is sorted by # of entered phenotypes by default.",
  "id" : 480655739061829632,
  "in_reply_to_status_id" : 480654318492983297,
  "created_at" : "2014-06-22 10:17:13 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/oGiFBBEw4i",
      "expanded_url" : "http:\/\/instagram.com\/p\/pium88BwpS\/",
      "display_url" : "instagram.com\/p\/pium88BwpS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7601520206, 9.400808381 ]
  },
  "id_str" : "480655560933928960",
  "text" : "Good News: @Lobot und ich haben Nachwuchs. http:\/\/t.co\/oGiFBBEw4i",
  "id" : 480655560933928960,
  "created_at" : "2014-06-22 10:16:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480650961040338945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7597984784, 9.4015313857 ]
  },
  "id_str" : "480653329031516160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yep, think so as well.",
  "id" : 480653329031516160,
  "in_reply_to_status_id" : 480650961040338945,
  "created_at" : "2014-06-22 10:07:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/nU58berYaT",
      "expanded_url" : "http:\/\/songexploder.net\/",
      "display_url" : "songexploder.net"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096518949, 8.2831328146 ]
  },
  "id_str" : "480439833161367552",
  "text" : "Song Exploder: \u00ABIt's like 99 Percent Invisible, but for songs.\u00BB the standard Silicon Valley pitch, but in cool. http:\/\/t.co\/nU58berYaT",
  "id" : 480439833161367552,
  "created_at" : "2014-06-21 19:59:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/kiTlaSiN3Q",
      "expanded_url" : "http:\/\/thememorypalace.us\/2014\/06\/the-glowing-orbs\/",
      "display_url" : "thememorypalace.us\/2014\/06\/the-gl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095518671, 8.2829447643 ]
  },
  "id_str" : "480360046044643328",
  "text" : "glowing orbs: the beauty of pee http:\/\/t.co\/kiTlaSiN3Q",
  "id" : 480360046044643328,
  "created_at" : "2014-06-21 14:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ZoFcWzr4Zq",
      "expanded_url" : "http:\/\/instagram.com\/p\/pgeYEOBwqi\/",
      "display_url" : "instagram.com\/p\/pgeYEOBwqi\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.993674728, 8.293981702 ]
  },
  "id_str" : "480338173776510977",
  "text" : "gone fishing @ Mainspitze http:\/\/t.co\/ZoFcWzr4Zq",
  "id" : 480338173776510977,
  "created_at" : "2014-06-21 13:15:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480030895865217026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1133775595, 8.6964044572 ]
  },
  "id_str" : "480082701417193473",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil @PhilippBayer this is the cutest thing I've read in quite some while!",
  "id" : 480082701417193473,
  "in_reply_to_status_id" : 480030895865217026,
  "created_at" : "2014-06-20 20:20:10 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/uTy1nzD3Qh",
      "expanded_url" : "http:\/\/instagram.com\/p\/peqF9AhwhO\/",
      "display_url" : "instagram.com\/p\/peqF9AhwhO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "480082464077922304",
  "text" : "Nomnomnom http:\/\/t.co\/uTy1nzD3Qh",
  "id" : 480082464077922304,
  "created_at" : "2014-06-20 20:19:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480024151927705600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1826722513, 8.4636844375 ]
  },
  "id_str" : "480026252062244864",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache same for me.",
  "id" : 480026252062244864,
  "in_reply_to_status_id" : 480024151927705600,
  "created_at" : "2014-06-20 16:35:51 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1830266479, 8.4634591763 ]
  },
  "id_str" : "480023339759837185",
  "text" : "\u00ABI was really scared of the bioinformatics work, but then I started fieldwork and learned what I really should be afraid of.\u00BB",
  "id" : 480023339759837185,
  "created_at" : "2014-06-20 16:24:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 18, 26 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479902353152565248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0091578682, 8.2840831048 ]
  },
  "id_str" : "479905728044752896",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng @branleb er hat es an das entsprechende Service-Center weitergetragen, wusste als Supportler aber auch nicht mehr.",
  "id" : 479905728044752896,
  "in_reply_to_status_id" : 479902353152565248,
  "created_at" : "2014-06-20 08:36:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 18, 26 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479901993805557760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479902149489745920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng @branleb haben sie nicht, hab aber noch eine mail geschrieben \u201Cdiese wohnung wollen wir: $link\u201D",
  "id" : 479902149489745920,
  "in_reply_to_status_id" : 479901993805557760,
  "created_at" : "2014-06-20 08:22:43 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 18, 26 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097017508, 8.2830784134 ]
  },
  "id_str" : "479897932620378112",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng @branleb unsere Anmeldung wurde endlich bearbeitet.",
  "id" : 479897932620378112,
  "created_at" : "2014-06-20 08:05:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479786527354920960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096579986, 8.283050892 ]
  },
  "id_str" : "479786757777817600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, saw that you got it from the 2nd hand book pile iirc. I will get myself a copy then :)",
  "id" : 479786757777817600,
  "in_reply_to_status_id" : 479786527354920960,
  "created_at" : "2014-06-20 00:44:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479779345464963073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479781822860382208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not sure if ssh killed the Erd\u0151s lifestyle or facilitates it.",
  "id" : 479781822860382208,
  "in_reply_to_status_id" : 479779345464963073,
  "created_at" : "2014-06-20 00:24:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uR7Ez6XPwx",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/duncanwatts\/should-you-go-to-grad-school",
      "display_url" : "buzzfeed.com\/duncanwatts\/sh\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479775940948815872",
  "text" : "\u00ABGrad students are by nature competitive, analytical types who are already predisposed to overthinking everything\u00BB http:\/\/t.co\/uR7Ez6XPwx",
  "id" : 479775940948815872,
  "created_at" : "2014-06-20 00:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/XXzAyypfWQ",
      "expanded_url" : "http:\/\/theoatmeal.com\/comics\/red_velvet_mite",
      "display_url" : "theoatmeal.com\/comics\/red_vel\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479757643062738944",
  "text" : "\u00AB I left that bit out because cannibalism does not mesh well with metaphors about love.\u00BB http:\/\/t.co\/XXzAyypfWQ",
  "id" : 479757643062738944,
  "created_at" : "2014-06-19 22:48:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479743926170312706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479744146916540416",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel \u2026taxonomic assignment with the sequences. ;)",
  "id" : 479744146916540416,
  "in_reply_to_status_id" : 479743926170312706,
  "created_at" : "2014-06-19 21:54:52 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479743926170312706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479744102985392129",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel from what I\u2019ve seen neither the data you can download, nor what they sent me contains it. But you should be able to do your own\u2026",
  "id" : 479744102985392129,
  "in_reply_to_status_id" : 479743926170312706,
  "created_at" : "2014-06-19 21:54:42 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479743404373708801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479743657239912448",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel best of luck, try to avoid saying \u201Craw data\u201D, that briefly confused the support and I got the counts again instead of sequences :)",
  "id" : 479743657239912448,
  "in_reply_to_status_id" : 479743404373708801,
  "created_at" : "2014-06-19 21:52:55 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479737592691175424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479737822963056640",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \u2026pretty filtered, no idea how many GB that would make per user.",
  "id" : 479737822963056640,
  "in_reply_to_status_id" : 479737592691175424,
  "created_at" : "2014-06-19 21:29:44 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479737592691175424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479737761453604864",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez the variant calls are even &lt; then the 23andMe files are. But I\u2019d like to host the raw sequences, as variant calls are already\u2026",
  "id" : 479737761453604864,
  "in_reply_to_status_id" : 479737592691175424,
  "created_at" : "2014-06-19 21:29:30 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479737335173496833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479737485015400448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez the actual problem are more storage\/server capacities to host the full data sets.",
  "id" : 479737485015400448,
  "in_reply_to_status_id" : 479737335173496833,
  "created_at" : "2014-06-19 21:28:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/fpfe70zdzo",
      "expanded_url" : "http:\/\/opensnp.org\/users\/1",
      "display_url" : "opensnp.org\/users\/1"
    } ]
  },
  "in_reply_to_status_id_str" : "479736910165069824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479737099101675520",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I hope it will be on http:\/\/t.co\/fpfe70zdzo one day",
  "id" : 479737099101675520,
  "in_reply_to_status_id" : 479736910165069824,
  "created_at" : "2014-06-19 21:26:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479736526624944128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479736729298276352",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez which reminds me that I still have to publish my exome sequencing data!",
  "id" : 479736729298276352,
  "in_reply_to_status_id" : 479736526624944128,
  "created_at" : "2014-06-19 21:25:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479728507837509633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479728637831548928",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel yes, I emailed their support and asked for the Illumina reads. :)",
  "id" : 479728637831548928,
  "in_reply_to_status_id" : 479728507837509633,
  "created_at" : "2014-06-19 20:53:14 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "indices" : [ 3, 13 ],
      "id_str" : "18911432",
      "id" : 18911432
    }, {
      "name" : "Nik Papageorgiou",
      "screen_name" : "upmicblog",
      "indices" : [ 47, 57 ],
      "id_str" : "19063117",
      "id" : 19063117
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paulcoxon\/status\/479669515924824064\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/dpkQsM47pa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqgg4O9CIAAZcl0.png",
      "id_str" : "479669510773809152",
      "id" : 479669510773809152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqgg4O9CIAAZcl0.png",
      "sizes" : [ {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1128
      }, {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1128
      }, {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1128
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/dpkQsM47pa"
    } ],
    "hashtags" : [ {
      "text" : "ecrchat",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/FU390LNzML",
      "expanded_url" : "http:\/\/theupturnedmicroscope.com\/comic\/honest-postdoc-ad\/",
      "display_url" : "theupturnedmicroscope.com\/comic\/honest-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479728351100555264",
  "text" : "RT @paulcoxon: Honest job ad for a postdoc, by @upmicblog :D #ecrchat http:\/\/t.co\/FU390LNzML http:\/\/t.co\/dpkQsM47pa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nik Papageorgiou",
        "screen_name" : "upmicblog",
        "indices" : [ 32, 42 ],
        "id_str" : "19063117",
        "id" : 19063117
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paulcoxon\/status\/479669515924824064\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/dpkQsM47pa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqgg4O9CIAAZcl0.png",
        "id_str" : "479669510773809152",
        "id" : 479669510773809152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqgg4O9CIAAZcl0.png",
        "sizes" : [ {
          "h" : 1075,
          "resize" : "fit",
          "w" : 1128
        }, {
          "h" : 1075,
          "resize" : "fit",
          "w" : 1128
        }, {
          "h" : 1075,
          "resize" : "fit",
          "w" : 1128
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/dpkQsM47pa"
      } ],
      "hashtags" : [ {
        "text" : "ecrchat",
        "indices" : [ 46, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/FU390LNzML",
        "expanded_url" : "http:\/\/theupturnedmicroscope.com\/comic\/honest-postdoc-ad\/",
        "display_url" : "theupturnedmicroscope.com\/comic\/honest-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479669515924824064",
    "text" : "Honest job ad for a postdoc, by @upmicblog :D #ecrchat http:\/\/t.co\/FU390LNzML http:\/\/t.co\/dpkQsM47pa",
    "id" : 479669515924824064,
    "created_at" : "2014-06-19 16:58:19 +0000",
    "user" : {
      "name" : "Dr Paul Coxon",
      "screen_name" : "paulcoxon",
      "protected" : false,
      "id_str" : "18911432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636660043312693248\/K6eLUfum_normal.jpg",
      "id" : 18911432,
      "verified" : true
    }
  },
  "id" : 479728351100555264,
  "created_at" : "2014-06-19 20:52:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 4, 11 ],
      "id_str" : "852039852",
      "id" : 852039852
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 108, 115 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/aWmjAkzYPT",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/microbiome",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479723367256580096",
  "text" : "The @uBiome support is really nice: 16S rRNA sequencing reads of my gut\/mouth\/genital microbiome are now on @github. https:\/\/t.co\/aWmjAkzYPT",
  "id" : 479723367256580096,
  "created_at" : "2014-06-19 20:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GRO3JAfa5L",
      "expanded_url" : "http:\/\/arxiv.org\/pdf\/1201.2590v1.pdf",
      "display_url" : "arxiv.org\/pdf\/1201.2590v\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479697633989373952",
  "text" : "Quote from \u00ABIt is Time to Stop Teaching Frequentism to\nNon-statisticians\u00BB http:\/\/t.co\/GRO3JAfa5L",
  "id" : 479697633989373952,
  "created_at" : "2014-06-19 18:50:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479697575562739713",
  "text" : "\u00ABWhen a small p-value appears, it is if the result has been blessed.\nPublication, and all that it happily entails, looms.\u00BB",
  "id" : 479697575562739713,
  "created_at" : "2014-06-19 18:49:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/sZQysUmvpJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SW6FrrAS62E",
      "display_url" : "youtube.com\/watch?v=SW6Frr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679264, 8.283075652 ]
  },
  "id_str" : "479690747453906944",
  "text" : "Who's Fucking http:\/\/t.co\/sZQysUmvpJ",
  "id" : 479690747453906944,
  "created_at" : "2014-06-19 18:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0020124484, 8.2662011404 ]
  },
  "id_str" : "479627270639071232",
  "text" : "\u00ABIch wollte nur kurz \u00FCber die Liebe nachdenken. Und dann bin ich eingeschlafen.\u00BB",
  "id" : 479627270639071232,
  "created_at" : "2014-06-19 14:10:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096649165, 8.2830298226 ]
  },
  "id_str" : "479550542042398721",
  "text" : "\u00ABWieso musst du mir in meinem Alter noch was \u00FCber STD-Verh\u00FCtung erz\u00E4hlen?\u00BB\u2014\u00ABWeil du so alt bist das deine Sturm &amp; Drang-Phase vor HIV war.\u00BB",
  "id" : 479550542042398721,
  "created_at" : "2014-06-19 09:05:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479414696785612800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096512482, 8.2829467449 ]
  },
  "id_str" : "479415621785223168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, I'll keep my eyes open for further xcom-stuff. ;)",
  "id" : 479415621785223168,
  "in_reply_to_status_id" : 479414696785612800,
  "created_at" : "2014-06-19 00:09:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479412142240571392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096842048, 8.2830359698 ]
  },
  "id_str" : "479412735315562496",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope, didn't have a closer look but thought you as fanboy should know ;)",
  "id" : 479412735315562496,
  "in_reply_to_status_id" : 479412142240571392,
  "created_at" : "2014-06-18 23:57:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "indices" : [ 3, 16 ],
      "id_str" : "199360809",
      "id" : 199360809
    }, {
      "name" : "J.B.S. Haldane",
      "screen_name" : "JBS_Haldane",
      "indices" : [ 88, 100 ],
      "id_str" : "1326144174",
      "id" : 1326144174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479282449860792320",
  "text" : "RT @molecologist: \u201CI would be too intimidated to dine with R. A. Fisher, \u2026 I would pick @JBS_Haldane and H. J. Muller \u2026\" http:\/\/t.co\/2ISCzc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "J.B.S. Haldane",
        "screen_name" : "JBS_Haldane",
        "indices" : [ 70, 82 ],
        "id_str" : "1326144174",
        "id" : 1326144174
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/2ISCzcXTNR",
        "expanded_url" : "http:\/\/www.molecularecologist.com\/2014\/06\/people-behind-the-science-dr-montgomery-slatkin\/",
        "display_url" : "molecularecologist.com\/2014\/06\/people\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479279835215179777",
    "text" : "\u201CI would be too intimidated to dine with R. A. Fisher, \u2026 I would pick @JBS_Haldane and H. J. Muller \u2026\" http:\/\/t.co\/2ISCzcXTNR",
    "id" : 479279835215179777,
    "created_at" : "2014-06-18 15:09:51 +0000",
    "user" : {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "protected" : false,
      "id_str" : "199360809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701480248899022849\/-EEVkZX8_normal.png",
      "id" : 199360809,
      "verified" : false
    }
  },
  "id" : 479282449860792320,
  "created_at" : "2014-06-18 15:20:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 118, 128 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/XILiUiKHFh",
      "expanded_url" : "http:\/\/pamelaclark.tumblr.com\/post\/87113711124\/35-practical-tools-for-men-to-further-feminist",
      "display_url" : "pamelaclark.tumblr.com\/post\/871137111\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479264480829128704",
  "text" : "35 Practical Tools for Men to Further Feminist Revolution (also linked: 20 academic tools) http:\/\/t.co\/XILiUiKHFh \/HT @recology_",
  "id" : 479264480829128704,
  "created_at" : "2014-06-18 14:08:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479231187249283072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479244827339792384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot those that are used to tesselate?",
  "id" : 479244827339792384,
  "in_reply_to_status_id" : 479231187249283072,
  "created_at" : "2014-06-18 12:50:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/j765C3fvjg",
      "expanded_url" : "http:\/\/www.beton-strohmaier.de\/sites\/default\/files\/pdf\/Design%2010_20_8.jpg",
      "display_url" : "beton-strohmaier.de\/sites\/default\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479228767144271872",
  "text" : "Was immer vor meinem geistigen Auge erscheint wenn Menschen von \u2018Politik zum Anfassen\u2019 sprechen. http:\/\/t.co\/j765C3fvjg",
  "id" : 479228767144271872,
  "created_at" : "2014-06-18 11:46:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/vy7aujrYYj",
      "expanded_url" : "https:\/\/31.media.tumblr.com\/eebe82ab3d0d73d59f21c9bd36c5cd48\/tumblr_n653zgjRo71s02vreo1_400.gif",
      "display_url" : "31.media.tumblr.com\/eebe82ab3d0d73\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479225253538037760",
  "text" : "torture https:\/\/t.co\/vy7aujrYYj",
  "id" : 479225253538037760,
  "created_at" : "2014-06-18 11:32:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francesc @ \uD83C\uDDE7\uD83C\uDDF7",
      "screen_name" : "francesc",
      "indices" : [ 3, 12 ],
      "id_str" : "122053508",
      "id" : 122053508
    }, {
      "name" : "St\u00E9phanie Laporte",
      "screen_name" : "steashaz",
      "indices" : [ 47, 56 ],
      "id_str" : "46127393",
      "id" : 46127393
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/francesc\/status\/479018387163471872\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/1BFhrFg0pO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqXQr0qCUAAy0Mb.jpg",
      "id_str" : "479018386672734208",
      "id" : 479018386672734208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqXQr0qCUAAy0Mb.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 584
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/1BFhrFg0pO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479184779389452288",
  "text" : "RT @francesc: Why did unicorns disappear?\n\/via:@steashaz http:\/\/t.co\/1BFhrFg0pO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "St\u00E9phanie Laporte",
        "screen_name" : "steashaz",
        "indices" : [ 33, 42 ],
        "id_str" : "46127393",
        "id" : 46127393
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/francesc\/status\/479018387163471872\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/1BFhrFg0pO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqXQr0qCUAAy0Mb.jpg",
        "id_str" : "479018386672734208",
        "id" : 479018386672734208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqXQr0qCUAAy0Mb.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 584
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/1BFhrFg0pO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479018387163471872",
    "text" : "Why did unicorns disappear?\n\/via:@steashaz http:\/\/t.co\/1BFhrFg0pO",
    "id" : 479018387163471872,
    "created_at" : "2014-06-17 21:50:57 +0000",
    "user" : {
      "name" : "Francesc @ \uD83C\uDDE7\uD83C\uDDF7",
      "screen_name" : "francesc",
      "protected" : false,
      "id_str" : "122053508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845684652794789888\/cO3pJOu6_normal.jpg",
      "id" : 122053508,
      "verified" : false
    }
  },
  "id" : 479184779389452288,
  "created_at" : "2014-06-18 08:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/9eqjRJD5DH",
      "expanded_url" : "http:\/\/instagram.com\/p\/pYQt2SBwmW\/",
      "display_url" : "instagram.com\/p\/pYQt2SBwmW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "479182235472764928",
  "text" : "Losing the last remnants of Puerto Rico on my desk. @ Goethe-Universit\u00E4t Frankfurt, Campus Riedberg http:\/\/t.co\/9eqjRJD5DH",
  "id" : 479182235472764928,
  "created_at" : "2014-06-18 08:42:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/1PCGvGPrPV",
      "expanded_url" : "http:\/\/openxcom.org\/2014\/06\/openxcom-1-0\/",
      "display_url" : "openxcom.org\/2014\/06\/openxc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479175223129149440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you already see http:\/\/t.co\/1PCGvGPrPV ?",
  "id" : 479175223129149440,
  "created_at" : "2014-06-18 08:14:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/0yT9exF9e5",
      "expanded_url" : "http:\/\/theappendix.net\/issues\/2014\/4\/the-history-of-mana-how-an-austronesian-concept-became-a-video-game-mechanic",
      "display_url" : "theappendix.net\/issues\/2014\/4\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479173446988214272",
  "text" : "The History of Mana: How an Austronesian Concept Became a Video Game Mechanic http:\/\/t.co\/0yT9exF9e5",
  "id" : 479173446988214272,
  "created_at" : "2014-06-18 08:07:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/exzmsl3cAN",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/06\/16\/wolf-puppy-has-the-hiccups.html",
      "display_url" : "boingboing.net\/2014\/06\/16\/wol\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479170239759147010",
  "text" : "Wolf puppy has the\u00A0hiccups http:\/\/t.co\/exzmsl3cAN",
  "id" : 479170239759147010,
  "created_at" : "2014-06-18 07:54:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lLnn8GaFvR",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0099868",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "479167333936934913",
  "text" : "\u00ABAdult musicians compared to non-musicians showed enhanced performance on measures of cognitive flexibility\u00BB (fMRI) http:\/\/t.co\/lLnn8GaFvR",
  "id" : 479167333936934913,
  "created_at" : "2014-06-18 07:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/3qP2HYCjDe",
      "expanded_url" : "http:\/\/instagram.com\/p\/pXNBIQBwrI\/",
      "display_url" : "instagram.com\/p\/pXNBIQBwrI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.005940563, 8.286528378 ]
  },
  "id_str" : "479033364356550656",
  "text" : "\u00ABThat isn't even a lie, is it?\u00BB @ Elfenbeinturm http:\/\/t.co\/3qP2HYCjDe",
  "id" : 479033364356550656,
  "created_at" : "2014-06-17 22:50:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/shb732628O",
      "expanded_url" : "http:\/\/instagram.com\/p\/pW1eqSBwic\/",
      "display_url" : "instagram.com\/p\/pW1eqSBwic\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478981603167715328",
  "text" : "Lorenzo Homar 1913-2004 http:\/\/t.co\/shb732628O",
  "id" : 478981603167715328,
  "created_at" : "2014-06-17 19:24:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lJIf25oFaI",
      "expanded_url" : "http:\/\/instagram.com\/p\/pWstRkBwit\/",
      "display_url" : "instagram.com\/p\/pWstRkBwit\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478962314201165824",
  "text" : "Old San Juan http:\/\/t.co\/lJIf25oFaI",
  "id" : 478962314201165824,
  "created_at" : "2014-06-17 18:08:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poly in the News",
      "screen_name" : "PolyintheNews",
      "indices" : [ 3, 17 ],
      "id_str" : "151246844",
      "id" : 151246844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/LZ63MkwoPt",
      "expanded_url" : "http:\/\/dlvr.it\/61m6nW",
      "display_url" : "dlvr.it\/61m6nW"
    } ]
  },
  "geo" : { },
  "id_str" : "478962047011782656",
  "text" : "RT @PolyintheNews: Poly in the News:  Dan Savage has Diana Adams exhort for coming out poly http:\/\/t.co\/LZ63MkwoPt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/LZ63MkwoPt",
        "expanded_url" : "http:\/\/dlvr.it\/61m6nW",
        "display_url" : "dlvr.it\/61m6nW"
      } ]
    },
    "geo" : { },
    "id_str" : "478930769780289536",
    "text" : "Poly in the News:  Dan Savage has Diana Adams exhort for coming out poly http:\/\/t.co\/LZ63MkwoPt",
    "id" : 478930769780289536,
    "created_at" : "2014-06-17 16:02:48 +0000",
    "user" : {
      "name" : "Poly in the News",
      "screen_name" : "PolyintheNews",
      "protected" : false,
      "id_str" : "151246844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3306124073\/096a917d69021585a9861ee657f6e214_normal.jpeg",
      "id" : 151246844,
      "verified" : false
    }
  },
  "id" : 478962047011782656,
  "created_at" : "2014-06-17 18:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097196027, 8.2831356628 ]
  },
  "id_str" : "478839753824305152",
  "text" : "\u00ABDu hast so einen niedlichen Fleischpenis.\u00BB \u2014 \u00ABAber ich bin doch Vegetarier!\u00BB",
  "id" : 478839753824305152,
  "created_at" : "2014-06-17 10:01:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stream-Caf\u00E9",
      "screen_name" : "l1vestream",
      "indices" : [ 0, 11 ],
      "id_str" : "3398451658",
      "id" : 3398451658
    }, {
      "name" : "Katzandra",
      "screen_name" : "StrassenKatze",
      "indices" : [ 12, 26 ],
      "id_str" : "21585225",
      "id" : 21585225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478832207084404736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096784533, 8.2831778471 ]
  },
  "id_str" : "478835456571101184",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@l1vestream @StrassenKatze du meinst wie ich meinen Zucker ganz leicht mit Espresso anfeuchte?",
  "id" : 478835456571101184,
  "in_reply_to_status_id" : 478832207084404736,
  "created_at" : "2014-06-17 09:44:03 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478674340452765696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096924008, 8.2832450395 ]
  },
  "id_str" : "478835238194667520",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome got the mail. Will look into it later.",
  "id" : 478835238194667520,
  "in_reply_to_status_id" : 478674340452765696,
  "created_at" : "2014-06-17 09:43:11 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096684175, 8.2830686214 ]
  },
  "id_str" : "478618315162931200",
  "text" : "\u00ABIch dachte immer ich h\u00E4tte ein gutes heteronormatives Passing.\u00BB\u2014\u00ABWieso das!?\u00BB\u2014\u00ABIch seh mindestens so straight aus wie die Village People!\u00BB",
  "id" : 478618315162931200,
  "created_at" : "2014-06-16 19:21:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jana Seelig",
      "screen_name" : "isayshotgun",
      "indices" : [ 0, 12 ],
      "id_str" : "16168195",
      "id" : 16168195
    }, {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 13, 21 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478599656025624576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096030898, 8.2829676324 ]
  },
  "id_str" : "478618150461009922",
  "in_reply_to_user_id" : 16168195,
  "text" : "@isayshotgun @moeffju Pro-Tipp: schon w\u00E4hrend des Spiels f\u00E4llt das Geschrei nicht auf.",
  "id" : 478618150461009922,
  "in_reply_to_status_id" : 478599656025624576,
  "created_at" : "2014-06-16 19:20:34 +0000",
  "in_reply_to_screen_name" : "isayshotgun",
  "in_reply_to_user_id_str" : "16168195",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096369932, 8.2830316124 ]
  },
  "id_str" : "478521663311843329",
  "text" : "\u00ABWoran denkst du?\u00BB \u2014 \u00ABAn deinen Penis und wieso er wohl voller Mund-Bakterien ist.\u00BB",
  "id" : 478521663311843329,
  "created_at" : "2014-06-16 12:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/kyzpG6ukmS",
      "expanded_url" : "http:\/\/instagram.com\/p\/pTMEj3hwjB\/",
      "display_url" : "instagram.com\/p\/pTMEj3hwjB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478468333134958592",
  "text" : "Siesta http:\/\/t.co\/kyzpG6ukmS",
  "id" : 478468333134958592,
  "created_at" : "2014-06-16 09:25:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/YZ4E0UQIjD",
      "expanded_url" : "http:\/\/i.imgur.com\/isGXwi2.gif",
      "display_url" : "i.imgur.com\/isGXwi2.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231882, 8.6275612586 ]
  },
  "id_str" : "478460926124113920",
  "text" : "ohai http:\/\/t.co\/YZ4E0UQIjD",
  "id" : 478460926124113920,
  "created_at" : "2014-06-16 08:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/1bl6Tlht5T",
      "expanded_url" : "http:\/\/instagram.com\/p\/pTCmuohwsZ\/",
      "display_url" : "instagram.com\/p\/pTCmuohwsZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478447516758056960",
  "text" : "Ride On http:\/\/t.co\/1bl6Tlht5T",
  "id" : 478447516758056960,
  "created_at" : "2014-06-16 08:02:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1346283609, 8.6716627655 ]
  },
  "id_str" : "478414716520644608",
  "text" : "\u00ABYou're in the postcard stage. This I interpret to mean either that you're travelling or that you spend a great deal of your time in bed.\u00BB",
  "id" : 478414716520644608,
  "created_at" : "2014-06-16 05:52:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476864054645231616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097256658, 8.2829146538 ]
  },
  "id_str" : "478339015289352193",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome any news on this? :)",
  "id" : 478339015289352193,
  "in_reply_to_status_id" : 476864054645231616,
  "created_at" : "2014-06-16 00:51:23 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478328457588244480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096383039, 8.2829954568 ]
  },
  "id_str" : "478328535200055296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx :)",
  "id" : 478328535200055296,
  "in_reply_to_status_id" : 478328457588244480,
  "created_at" : "2014-06-16 00:09:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478326728603860992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096485217, 8.2829868516 ]
  },
  "id_str" : "478328140486680577",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sounds nice, upload pretty please? :)",
  "id" : 478328140486680577,
  "in_reply_to_status_id" : 478326728603860992,
  "created_at" : "2014-06-16 00:08:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Pearson",
      "screen_name" : "GenomeNathan",
      "indices" : [ 130, 143 ],
      "id_str" : "543876839",
      "id" : 543876839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/kumxX7eHTv",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2014\/05\/19\/solyent-neoliberalism-and-the-politics-of-life-hacking\/#.U54ZzQtazM8.twitter",
      "display_url" : "counterpunch.org\/2014\/05\/19\/sol\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478304195003817986",
  "text" : "Soylent, Neoliberalism &amp; Politics of Life Hacking \u00ABwe can feel most human by eroding our humanity\u00BB http:\/\/t.co\/kumxX7eHTv \/ht @GenomeNathan",
  "id" : 478304195003817986,
  "created_at" : "2014-06-15 22:33:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ozMERJLxjB",
      "expanded_url" : "http:\/\/clickbaitphd.tumblr.com\/",
      "display_url" : "clickbaitphd.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478295270598656001",
  "text" : "Clickbait Dissertations: \u00ABThink your rocket is stable? Take our new quiz! Hopefully you *won\u2019t* be blown away.\u00BB http:\/\/t.co\/ozMERJLxjB",
  "id" : 478295270598656001,
  "created_at" : "2014-06-15 21:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478288076033507329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478288674304831488",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a it\u2019s funny to relate that to Feynman\u2019s \u201Ccargo cult science\u201D. Would argue that w\/o philosophy of science everything is cargo cultish.",
  "id" : 478288674304831488,
  "in_reply_to_status_id" : 478288076033507329,
  "created_at" : "2014-06-15 21:31:20 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478284581440081920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478284900207198209",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a probably some adolescent conviction that philosophy in general is useless, especially for hard sciences. How wrong I was.",
  "id" : 478284900207198209,
  "in_reply_to_status_id" : 478284581440081920,
  "created_at" : "2014-06-15 21:16:21 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478284082997383168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478284363000709120",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a to be fair: 10 years ago I probably would have liked it myself. Today I\u2019m just baffled by it.",
  "id" : 478284363000709120,
  "in_reply_to_status_id" : 478284082997383168,
  "created_at" : "2014-06-15 21:14:12 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478283060329193472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478283785122095104",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a the stupid ornithology one?",
  "id" : 478283785122095104,
  "in_reply_to_status_id" : 478283060329193472,
  "created_at" : "2014-06-15 21:11:55 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/jIH14za52O",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/06\/happily-ever-after\/372573\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478279356050309122",
  "text" : "RT @AndreaKuszewski: Science says lasting relationships come down to\u2014you guessed it\u2014kindness and generosity. http:\/\/t.co\/jIH14za52O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/jIH14za52O",
        "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/06\/happily-ever-after\/372573\/",
        "display_url" : "theatlantic.com\/health\/archive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478276293209751552",
    "text" : "Science says lasting relationships come down to\u2014you guessed it\u2014kindness and generosity. http:\/\/t.co\/jIH14za52O",
    "id" : 478276293209751552,
    "created_at" : "2014-06-15 20:42:08 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 478279356050309122,
  "created_at" : "2014-06-15 20:54:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096581056, 8.2830137156 ]
  },
  "id_str" : "478277667700342784",
  "text" : "\u00ABWillst du Pfandbons haben? Sind auch 5\u20AC!\u00BB\u2013\u00ABWir haben auch USD 60 in der Schublade liegen, pack die Bons zu der restlichen foreign currency\u00BB",
  "id" : 478277667700342784,
  "created_at" : "2014-06-15 20:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096126733, 8.2830015585 ]
  },
  "id_str" : "478275034537263104",
  "text" : "Fun: so far my naive strategy of randomly drawing results from all past World Cup games puts me on rank 7 (of 12) for our prediction game.",
  "id" : 478275034537263104,
  "created_at" : "2014-06-15 20:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/bxFUK7YU4R",
      "expanded_url" : "http:\/\/instagram.com\/p\/pRmep7BwqB\/",
      "display_url" : "instagram.com\/p\/pRmep7BwqB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478244930788159489",
  "text" : "El Yunque V http:\/\/t.co\/bxFUK7YU4R",
  "id" : 478244930788159489,
  "created_at" : "2014-06-15 18:37:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/ZsSWR82aLB",
      "expanded_url" : "http:\/\/instagram.com\/p\/pRW7afhwmR\/",
      "display_url" : "instagram.com\/p\/pRW7afhwmR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478210734258520064",
  "text" : "El Yunque IV http:\/\/t.co\/ZsSWR82aLB",
  "id" : 478210734258520064,
  "created_at" : "2014-06-15 16:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/mBcpYUkIms",
      "expanded_url" : "http:\/\/instagram.com\/p\/pRGv59hwh6\/",
      "display_url" : "instagram.com\/p\/pRGv59hwh6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478175154380361728",
  "text" : "Watched http:\/\/t.co\/mBcpYUkIms",
  "id" : 478175154380361728,
  "created_at" : "2014-06-15 14:00:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/bQlhDNjpDq",
      "expanded_url" : "http:\/\/instagram.com\/p\/pQ-hidBwi7\/",
      "display_url" : "instagram.com\/p\/pQ-hidBwi7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478157070009516033",
  "text" : "El Yunque III http:\/\/t.co\/bQlhDNjpDq",
  "id" : 478157070009516033,
  "created_at" : "2014-06-15 12:48:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0057987862, 8.2594193094 ]
  },
  "id_str" : "478155804429021184",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wir scheinen unterschiedliche Definitionen von 'keine Schlange' zu haben. ;)",
  "id" : 478155804429021184,
  "created_at" : "2014-06-15 12:43:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/tG5xJLGFyR",
      "expanded_url" : "http:\/\/instagram.com\/p\/pQrlv3hwpY\/",
      "display_url" : "instagram.com\/p\/pQrlv3hwpY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478115432813961216",
  "text" : "El Yunque II http:\/\/t.co\/tG5xJLGFyR",
  "id" : 478115432813961216,
  "created_at" : "2014-06-15 10:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.442242464, -66.0150417137 ]
  },
  "id_str" : "477919466043752448",
  "text" : "\u00ABSo, what are you doing when you're not the anarchistic enemy of 23andMe, do science, raise kids or spend time with your girlfriends?\u00BB",
  "id" : 477919466043752448,
  "created_at" : "2014-06-14 21:04:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628041557, -66.0853166352 ]
  },
  "id_str" : "477896261526630401",
  "text" : "\u00ABI've walked a mile in so many people's shoes that I forgot which ones were mine. So now I rather go barefoot.\u00BB",
  "id" : 477896261526630401,
  "created_at" : "2014-06-14 19:32:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/qF5pVQq3HB",
      "expanded_url" : "http:\/\/instagram.com\/p\/pOnouLBwrz\/",
      "display_url" : "instagram.com\/p\/pOnouLBwrz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477825263414554625",
  "text" : "El Yunque http:\/\/t.co\/qF5pVQq3HB",
  "id" : 477825263414554625,
  "created_at" : "2014-06-14 14:49:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630233292, -66.0851062914 ]
  },
  "id_str" : "477798875726884864",
  "text" : "\u00ABThe most awful thing about getting old is that although you can sound very furious and very hurt, one is neither. So I shall be pragmatic.\u00BB",
  "id" : 477798875726884864,
  "created_at" : "2014-06-14 13:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/s4ERLzGe25",
      "expanded_url" : "http:\/\/instagram.com\/p\/pOR2skBwpv\/",
      "display_url" : "instagram.com\/p\/pOR2skBwpv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477777363443658753",
  "text" : "pre-breakfast http:\/\/t.co\/s4ERLzGe25",
  "id" : 477777363443658753,
  "created_at" : "2014-06-14 11:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463074514, -66.0852907018 ]
  },
  "id_str" : "477759857781919744",
  "text" : "\u00ABDu findest auch immer was zu meckern: Es ist zu unordentlich, die V\u00F6gel sind nicht bunt genug und dann regnet es auch noch \u2013 Im Regenwald\u00BB",
  "id" : 477759857781919744,
  "created_at" : "2014-06-14 10:30:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477482580275904512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4386415853, -66.0055429767 ]
  },
  "id_str" : "477485077224779776",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch thx! @PhilippBayer",
  "id" : 477485077224779776,
  "in_reply_to_status_id" : 477482580275904512,
  "created_at" : "2014-06-13 16:18:08 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4410395427, -66.0154730827 ]
  },
  "id_str" : "477475177497128961",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch could one of you restart solr? Seems crashed again.",
  "id" : 477475177497128961,
  "created_at" : "2014-06-13 15:38:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477426954048909312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "477427591972782080",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen oh, mein Beileid!",
  "id" : 477427591972782080,
  "in_reply_to_status_id" : 477426954048909312,
  "created_at" : "2014-06-13 12:29:42 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477361150620102657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "477426823454670848",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ein harter Job, aber irgendjemand muss ihn machen. Samstag geht\u2019s zur\u00FCck ;)",
  "id" : 477426823454670848,
  "in_reply_to_status_id" : 477361150620102657,
  "created_at" : "2014-06-13 12:26:39 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477353261805342720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629008636, -66.085356232 ]
  },
  "id_str" : "477353645911330816",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen science! Die society for molecular biology &amp; evolution hat hier bis heute ihr meeting gehabt.",
  "id" : 477353645911330816,
  "in_reply_to_status_id" : 477353261805342720,
  "created_at" : "2014-06-13 07:35:52 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629582295, -66.0853725682 ]
  },
  "id_str" : "477352889904824321",
  "text" : "\u00ABA penny for your thoughts. But I think I've just given my last change to the street musician. So you might have to wait for the payment.\u00BB",
  "id" : 477352889904824321,
  "created_at" : "2014-06-13 07:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632350806, -66.0851781634 ]
  },
  "id_str" : "477186709549875201",
  "text" : "Cultural transmission of reproductive success leads to decrease in genetic diversity. #smbe14",
  "id" : 477186709549875201,
  "created_at" : "2014-06-12 20:32:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477186304543690752",
  "text" : "On Y chromosome: More tree imbalance in patrilineal populations than in cognatic ones. Identical for mitochondrial loci #smbe14",
  "id" : 477186304543690752,
  "created_at" : "2014-06-12 20:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632350806, -66.0851781634 ]
  },
  "id_str" : "477185626731597824",
  "text" : "More fertility transmission in hunter-gatherer populations than in farmer populations. #smbe14",
  "id" : 477185626731597824,
  "created_at" : "2014-06-12 20:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632350806, -66.0851781634 ]
  },
  "id_str" : "477185236615192576",
  "text" : "Gene genealogies are affected by fertility transmission, leads to unbalanced trees. #smbe14",
  "id" : 477185236615192576,
  "created_at" : "2014-06-12 20:26:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632350806, -66.0851781634 ]
  },
  "id_str" : "477184718803193858",
  "text" : "Number of effective children (i.e. ones that have offspring themselves) is vertically transmitted in many human populations. #smbe14",
  "id" : 477184718803193858,
  "created_at" : "2014-06-12 20:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632350806, -66.0851781634 ]
  },
  "id_str" : "477184286101999617",
  "text" : "Now: cultural transmission of reproductive success. #smbe14",
  "id" : 477184286101999617,
  "created_at" : "2014-06-12 20:22:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "indices" : [ 3, 12 ],
      "id_str" : "1565839604",
      "id" : 1565839604
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ATJCagan\/status\/477174161123463169\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/gKPX3Ni0dI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9DXweCEAAxGks.jpg",
      "id_str" : "477174160951480320",
      "id" : 477174160951480320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9DXweCEAAxGks.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gKPX3Ni0dI"
    } ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477179787920695296",
  "text" : "RT @ATJCagan: Verdi on linguistic and genetic diversity in Cape Verde #SMBE14 http:\/\/t.co\/gKPX3Ni0dI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ATJCagan\/status\/477174161123463169\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/gKPX3Ni0dI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9DXweCEAAxGks.jpg",
        "id_str" : "477174160951480320",
        "id" : 477174160951480320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9DXweCEAAxGks.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gKPX3Ni0dI"
      } ],
      "hashtags" : [ {
        "text" : "SMBE14",
        "indices" : [ 56, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477174161123463169",
    "text" : "Verdi on linguistic and genetic diversity in Cape Verde #SMBE14 http:\/\/t.co\/gKPX3Ni0dI",
    "id" : 477174161123463169,
    "created_at" : "2014-06-12 19:42:40 +0000",
    "user" : {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "protected" : false,
      "id_str" : "1565839604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929784470735065088\/gnM_5OgB_normal.jpg",
      "id" : 1565839604,
      "verified" : false
    }
  },
  "id" : 477179787920695296,
  "created_at" : "2014-06-12 20:05:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477154353720332288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632866224, -66.085662637 ]
  },
  "id_str" : "477175557407653888",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I read it on my flight to Puerto Rico, just now find the time to get through all the quotes I marked. :)",
  "id" : 477175557407653888,
  "in_reply_to_status_id" : 477154353720332288,
  "created_at" : "2014-06-12 19:48:13 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629954989, -66.0851379568 ]
  },
  "id_str" : "477140771385405440",
  "text" : "\u00ABAm also pleased with your hectic love life, because I hope that this will keep you off revolutionary activities.\u00BB \u2014 Lakatos to Feyerabend",
  "id" : 477140771385405440,
  "created_at" : "2014-06-12 17:29:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4627881988, -66.0849531731 ]
  },
  "id_str" : "477138165825011712",
  "text" : "Lots of people running to the Los Gran Rosales Complex. Probably to listen to the couch potato talk. #smbe14",
  "id" : 477138165825011712,
  "created_at" : "2014-06-12 17:19:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "477126550648016896",
  "text" : "\u2018sporadic access to my email\u2019 aka \u2018I lack a waterproof device to read email on the beach\u2019",
  "id" : 477126550648016896,
  "created_at" : "2014-06-12 16:33:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/kD5eUlvi1x",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/100\/",
      "display_url" : "what-if.xkcd.com\/100\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477083966852567041",
  "text" : "WWII Films http:\/\/t.co\/kD5eUlvi1x",
  "id" : 477083966852567041,
  "created_at" : "2014-06-12 13:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "477054091701391361",
  "text" : "Not completely awake yet, misread the label of the hair conditioner as \u2018G\/C rich\u2019.",
  "id" : 477054091701391361,
  "created_at" : "2014-06-12 11:45:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HQT4VVqU0T",
      "expanded_url" : "http:\/\/www.rookiemag.com\/2014\/06\/the-boys-guide-to-not-being-a-jerk\/",
      "display_url" : "rookiemag.com\/2014\/06\/the-bo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "477049570170372097",
  "text" : "\u00ABnot allowing a guy to be predatory with a girl is a pretty damn good starting point. Especially if that guy is you.\u00BB http:\/\/t.co\/HQT4VVqU0T",
  "id" : 477049570170372097,
  "created_at" : "2014-06-12 11:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4627941895, -66.0853417293 ]
  },
  "id_str" : "477032155949060096",
  "text" : "\u00ABSo, you're telling me the beach is closed after 9pm? Why's that, do you need to change the water?\u00BB",
  "id" : 477032155949060096,
  "created_at" : "2014-06-12 10:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476897652005953536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630595986, -66.0851759837 ]
  },
  "id_str" : "476898013638844416",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek I wouldn't want to argue that it's for everyone, but that it's a valid choice!",
  "id" : 476898013638844416,
  "in_reply_to_status_id" : 476897652005953536,
  "created_at" : "2014-06-12 01:25:21 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476893228214403073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629691528, -66.0851625948 ]
  },
  "id_str" : "476897264258932736",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek awesome. Otherwise I'll never get the chance to make my pro-polyamory case!",
  "id" : 476897264258932736,
  "in_reply_to_status_id" : 476893228214403073,
  "created_at" : "2014-06-12 01:22:22 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476892410019348481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463190094, -66.0852705059 ]
  },
  "id_str" : "476892992243249152",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek let's make that post-gala. I'll probably go to old San Juan anyway.",
  "id" : 476892992243249152,
  "in_reply_to_status_id" : 476892410019348481,
  "created_at" : "2014-06-12 01:05:24 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631457582, -66.0852011152 ]
  },
  "id_str" : "476890358622597120",
  "text" : "The first half of the poster session taught me: there really are lichen fans here. #smbe14",
  "id" : 476890358622597120,
  "created_at" : "2014-06-12 00:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476886566179459072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631614664, -66.0851838379 ]
  },
  "id_str" : "476890035073982464",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek I'm not. Sure you don't want to join this evening?",
  "id" : 476890035073982464,
  "in_reply_to_status_id" : 476886566179459072,
  "created_at" : "2014-06-12 00:53:39 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476882902073245696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631556619, -66.0852870953 ]
  },
  "id_str" : "476885894847561728",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek you're at the gala, aren't you?",
  "id" : 476885894847561728,
  "in_reply_to_status_id" : 476882902073245696,
  "created_at" : "2014-06-12 00:37:12 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476864054645231616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632808799, -66.0852298524 ]
  },
  "id_str" : "476866981497286656",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome great, thanks a lot!",
  "id" : 476866981497286656,
  "in_reply_to_status_id" : 476864054645231616,
  "created_at" : "2014-06-11 23:22:02 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476861827482402818",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631163022, -66.084916899 ]
  },
  "id_str" : "476862109012467712",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek would love to discuss LGBT in STEM a bit more over drinks. :)",
  "id" : 476862109012467712,
  "in_reply_to_status_id" : 476861827482402818,
  "created_at" : "2014-06-11 23:02:41 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476861827482402818",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631163022, -66.084916899 ]
  },
  "id_str" : "476861872709566464",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek okay, great :)",
  "id" : 476861872709566464,
  "in_reply_to_status_id" : 476861827482402818,
  "created_at" : "2014-06-11 23:01:44 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476861440155205632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631163022, -66.084916899 ]
  },
  "id_str" : "476861774105702400",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome will have a closer look tomorrow\/after #smbe14, thanks for the support so far!",
  "id" : 476861774105702400,
  "in_reply_to_status_id" : 476861440155205632,
  "created_at" : "2014-06-11 23:01:21 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476861341924589568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631163022, -66.084916899 ]
  },
  "id_str" : "476861595789041664",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome but that only gives JSON of abundance data (at least on iPad &amp; in the overview I posted)?",
  "id" : 476861595789041664,
  "in_reply_to_status_id" : 476861341924589568,
  "created_at" : "2014-06-11 23:00:38 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476861265223368704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630924137, -66.0848766659 ]
  },
  "id_str" : "476861425017569282",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek yeah, we will grab dinner somewhere on the way to the drinks.",
  "id" : 476861425017569282,
  "in_reply_to_status_id" : 476861265223368704,
  "created_at" : "2014-06-11 22:59:58 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476852488126365696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629497393, -66.0851098082 ]
  },
  "id_str" : "476861136575672321",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende unauff\u00E4llig,je nach Tagesform Bristol 3-5.",
  "id" : 476861136575672321,
  "in_reply_to_status_id" : 476852488126365696,
  "created_at" : "2014-06-11 22:58:49 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476845543969538048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628368386, -66.0853715355 ]
  },
  "id_str" : "476858572077555712",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome can I access the sequences itself?",
  "id" : 476858572077555712,
  "in_reply_to_status_id" : 476845543969538048,
  "created_at" : "2014-06-11 22:48:37 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 7, 14 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/476823314430566400\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/KMeDs5s1Sl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp4ERyLCUAErahh.jpg",
      "id_str" : "476823314120200193",
      "id" : 476823314120200193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp4ERyLCUAErahh.jpg",
      "sizes" : [ {
        "h" : 713,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 1570
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 1570
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/KMeDs5s1Sl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629588212, -66.0863310377 ]
  },
  "id_str" : "476823314430566400",
  "text" : "Oh, my @uBiome data is there! http:\/\/t.co\/KMeDs5s1Sl",
  "id" : 476823314430566400,
  "created_at" : "2014-06-11 20:28:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629197689, -66.0862872577 ]
  },
  "id_str" : "476809492344995842",
  "text" : "\u00ABRound table discussion (without the table)\u00BB, so ein sch\u00F6ner Euphemismus f\u00FCr Stuhlkreis.",
  "id" : 476809492344995842,
  "created_at" : "2014-06-11 19:33:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 11, 20 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476794062750494720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4626634757, -66.0848280202 ]
  },
  "id_str" : "476794839867351040",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau @eramirez many users use fake\/throwaway-email accounts &amp; gen pseudonyms, making re-ID based on phenotype\/genotype not that easy.",
  "id" : 476794839867351040,
  "in_reply_to_status_id" : 476794062750494720,
  "created_at" : "2014-06-11 18:35:22 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 10, 20 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476780685818998784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4626634757, -66.0848280202 ]
  },
  "id_str" : "476794148314284033",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @bogdanrau or to put it a better way: they can decide how expensive re-identification of them is.",
  "id" : 476794148314284033,
  "in_reply_to_status_id" : 476780685818998784,
  "created_at" : "2014-06-11 18:32:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 10, 20 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476780685818998784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4626634757, -66.0848280202 ]
  },
  "id_str" : "476793897759150080",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @bogdanrau i think openSNP works because individuals can decide how much anonymity they want to throw away.",
  "id" : 476793897759150080,
  "in_reply_to_status_id" : 476780685818998784,
  "created_at" : "2014-06-11 18:31:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476763505207422976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630243137, -66.0850527926 ]
  },
  "id_str" : "476763888055103489",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau yes, I would like to make all my data open for other people to use.",
  "id" : 476763888055103489,
  "in_reply_to_status_id" : 476763505207422976,
  "created_at" : "2014-06-11 16:32:23 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476763133227175936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630243137, -66.0850527926 ]
  },
  "id_str" : "476763346864467968",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau we\u2019d love to see that (and incorporate that into openSNP)!",
  "id" : 476763346864467968,
  "in_reply_to_status_id" : 476763133227175936,
  "created_at" : "2014-06-11 16:30:14 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/qyvBBAQHeQ",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/XXiLMKRd1O4\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463115, -66.085098 ]
  },
  "id_str" : "476757686969970688",
  "text" : "AT-AT made from Sk8decks http:\/\/t.co\/qyvBBAQHeQ",
  "id" : 476757686969970688,
  "created_at" : "2014-06-11 16:07:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463164872, -66.0852400806 ]
  },
  "id_str" : "476738895879880704",
  "text" : "Laurence Loewe on DAPS: \u00ABA cool tool that can tell us new things or just a waste of time? I don\u2019t know, time will tell!\u00BB #SMBE14",
  "id" : 476738895879880704,
  "created_at" : "2014-06-11 14:53:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "indices" : [ 3, 12 ],
      "id_str" : "1565839604",
      "id" : 1565839604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476726156700286978",
  "text" : "RT @ATJCagan: Foll on detecting selection and combining populations to increase power. Hierarchical Bayesian modelling #SMBE14 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ATJCagan\/status\/476725024184082432\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/IzhwJcFGM0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp2q4jNIYAAojMH.jpg",
        "id_str" : "476725024070852608",
        "id" : 476725024070852608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp2q4jNIYAAojMH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/IzhwJcFGM0"
      } ],
      "hashtags" : [ {
        "text" : "SMBE14",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476725024184082432",
    "text" : "Foll on detecting selection and combining populations to increase power. Hierarchical Bayesian modelling #SMBE14 http:\/\/t.co\/IzhwJcFGM0",
    "id" : 476725024184082432,
    "created_at" : "2014-06-11 13:57:57 +0000",
    "user" : {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "protected" : false,
      "id_str" : "1565839604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929784470735065088\/gnM_5OgB_normal.jpg",
      "id" : 1565839604,
      "verified" : false
    }
  },
  "id" : 476726156700286978,
  "created_at" : "2014-06-11 14:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/nIFYARHoi1",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/Oh-Axt64hfI\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476717480874737664",
  "text" : "Why'd you make me lose?  http:\/\/t.co\/nIFYARHoi1",
  "id" : 476717480874737664,
  "created_at" : "2014-06-11 13:27:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/s8AOzRllTH",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/32",
      "display_url" : "existentialcomics.com\/comic\/32"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.459092, -66.083005 ]
  },
  "id_str" : "476717204076253185",
  "text" : "Dungeons &amp; Dragons &amp; Philosophers III: Ladies' Night at the Dragon's Den http:\/\/t.co\/s8AOzRllTH",
  "id" : 476717204076253185,
  "created_at" : "2014-06-11 13:26:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/5Y6Fw4FTcq",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/88310005419",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/883100054\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.46201, -66.084508 ]
  },
  "id_str" : "476716636058419202",
  "text" : "the red queen theory - a true story http:\/\/t.co\/5Y6Fw4FTcq",
  "id" : 476716636058419202,
  "created_at" : "2014-06-11 13:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/SmsJfxgTZM",
      "expanded_url" : "http:\/\/www.dhushara.com\/book\/unraveltree\/tishkoff09.jpg",
      "display_url" : "dhushara.com\/book\/unraveltr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632414578, -66.0851422029 ]
  },
  "id_str" : "476708923471183872",
  "text" : "ST: Nicholas Wade uses their data to justify the presence of 3-5 races. Asks whether you can spot in the tree http:\/\/t.co\/SmsJfxgTZM #smbe14",
  "id" : 476708923471183872,
  "created_at" : "2014-06-11 12:53:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632141614, -66.0851621564 ]
  },
  "id_str" : "476705500961067008",
  "text" : "Sarah Tishkoff: genetic variation larger within populations (85%) relative to variation between populations (15%) #smbe14",
  "id" : 476705500961067008,
  "created_at" : "2014-06-11 12:40:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476700849222078464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629264194, -66.0854347487 ]
  },
  "id_str" : "476702354885324802",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek I will drop by anyway. Maybe in one of the coffee breaks?",
  "id" : 476702354885324802,
  "in_reply_to_status_id" : 476700849222078464,
  "created_at" : "2014-06-11 12:27:52 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/JQGLAJGg73",
      "expanded_url" : "http:\/\/m.figshare.com\/articles\/Poster_SMBE_2014\/1046678",
      "display_url" : "m.figshare.com\/articles\/Poste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631286087, -66.0851757576 ]
  },
  "id_str" : "476700398515150848",
  "text" : "Catch me in the hallways if you have any questions on http:\/\/t.co\/JQGLAJGg73 I'm the one not wearing pants. #smbe14",
  "id" : 476700398515150848,
  "created_at" : "2014-06-11 12:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 132, 140 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/K2U8KsK6yt",
      "expanded_url" : "http:\/\/m.figshare.com\/articles\/Poster_SMBE_2014\/1046678",
      "display_url" : "m.figshare.com\/articles\/Poste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629149494, -66.0852475138 ]
  },
  "id_str" : "476699519069863936",
  "text" : "My poster on sequencing of lichen Lasallia pustulata is now up, number 087. Too lazy to show up? See http:\/\/t.co\/K2U8KsK6yt #smbe14 @PhdGeek",
  "id" : 476699519069863936,
  "created_at" : "2014-06-11 12:16:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476684218970697728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.462836938, -66.084784593 ]
  },
  "id_str" : "476686459077156864",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ i\u2019ll go full Robinson Crusoe!",
  "id" : 476686459077156864,
  "in_reply_to_status_id" : 476684218970697728,
  "created_at" : "2014-06-11 11:24:42 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476677695003443200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628596959, -66.0853981655 ]
  },
  "id_str" : "476681093211750400",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ actually, I wouldn't mind a brief detour to Costa Rica. ;)",
  "id" : 476681093211750400,
  "in_reply_to_status_id" : 476677695003443200,
  "created_at" : "2014-06-11 11:03:23 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628627864, -66.085389717 ]
  },
  "id_str" : "476675157965406208",
  "text" : "Day 5: People are still mixing up Puerto Rico &amp; Costa Rica. This might lead to interesting return flights.",
  "id" : 476675157965406208,
  "created_at" : "2014-06-11 10:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/TRHbBaZxPV",
      "expanded_url" : "http:\/\/www.thefacultylounge.org\/2014\/04\/whose-business-is-it-if-you-want-to-induce-a-bee-to-sting-your-penis.html",
      "display_url" : "thefacultylounge.org\/2014\/04\/whose-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476674266642272256",
  "text" : "RT @EffyVayena: How did I miss this blog? Whose Business Is It If You Induce a Bee To Sting Your Penis? http:\/\/t.co\/TRHbBaZxPV \u2026  @Michelle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michelle N. Meyer",
        "screen_name" : "MichelleNMeyer",
        "indices" : [ 114, 129 ],
        "id_str" : "59518694",
        "id" : 59518694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLRethics",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/TRHbBaZxPV",
        "expanded_url" : "http:\/\/www.thefacultylounge.org\/2014\/04\/whose-business-is-it-if-you-want-to-induce-a-bee-to-sting-your-penis.html",
        "display_url" : "thefacultylounge.org\/2014\/04\/whose-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476644419069026304",
    "text" : "How did I miss this blog? Whose Business Is It If You Induce a Bee To Sting Your Penis? http:\/\/t.co\/TRHbBaZxPV \u2026  @MichelleNMeyer #PLRethics",
    "id" : 476644419069026304,
    "created_at" : "2014-06-11 08:37:39 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 476674266642272256,
  "created_at" : "2014-06-11 10:36:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476671807492456448",
  "text" : "RT @JBYoder: \u201CI\u2019ll show him, Barn. My jaw is evolved specifically to absorb punches!\u201D\n\n*Takes direct hit to the face.*\n\n\u201COw!\"\n#Adaptationis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AdaptationistFlintstones",
        "indices" : [ 113, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476583427789963265",
    "text" : "\u201CI\u2019ll show him, Barn. My jaw is evolved specifically to absorb punches!\u201D\n\n*Takes direct hit to the face.*\n\n\u201COw!\"\n#AdaptationistFlintstones",
    "id" : 476583427789963265,
    "created_at" : "2014-06-11 04:35:18 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 476671807492456448,
  "created_at" : "2014-06-11 10:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/yCMlCgSV0u",
      "expanded_url" : "http:\/\/thequietus.com\/articles\/15466-harry-crews-author-retrospective",
      "display_url" : "thequietus.com\/articles\/15466\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476671740303900672",
  "text" : "RT @PhilippBayer: 'nothing good in the world has ever been done by well-rounded people' http:\/\/t.co\/yCMlCgSV0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/yCMlCgSV0u",
        "expanded_url" : "http:\/\/thequietus.com\/articles\/15466-harry-crews-author-retrospective",
        "display_url" : "thequietus.com\/articles\/15466\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476578749538775040",
    "text" : "'nothing good in the world has ever been done by well-rounded people' http:\/\/t.co\/yCMlCgSV0u",
    "id" : 476578749538775040,
    "created_at" : "2014-06-11 04:16:42 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 476671740303900672,
  "created_at" : "2014-06-11 10:26:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/goZs9YaNWL",
      "expanded_url" : "http:\/\/instagram.com\/p\/pFxEr8hwoV\/",
      "display_url" : "instagram.com\/p\/pFxEr8hwoV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.46778653, -66.114416069 ]
  },
  "id_str" : "476579380068503552",
  "text" : "The Streets of Old San Juan @ El Callej\u00F3n De La Tanca http:\/\/t.co\/goZs9YaNWL",
  "id" : 476579380068503552,
  "created_at" : "2014-06-11 04:19:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "476572173096996864",
  "text" : "\u00ABI was pretty close with my directions!\u00BB \u2013 \u00ABYou said east while it is actually west, that\u2019s 180\u00B0 off, as wrong as it gets!\u00BB",
  "id" : 476572173096996864,
  "created_at" : "2014-06-11 03:50:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Novak",
      "screen_name" : "paleofuture",
      "indices" : [ 3, 15 ],
      "id_str" : "16877374",
      "id" : 16877374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/WJetpH60Si",
      "expanded_url" : "http:\/\/gawker.com\/its-really-hard-to-be-a-good-guy-with-a-gun-1588660306\/+aweinstein",
      "display_url" : "gawker.com\/its-really-har\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476492157969498112",
  "text" : "RT @paleofuture: It's Really Hard to Be a Good Guy With a Gun http:\/\/t.co\/WJetpH60Si",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/WJetpH60Si",
        "expanded_url" : "http:\/\/gawker.com\/its-really-hard-to-be-a-good-guy-with-a-gun-1588660306\/+aweinstein",
        "display_url" : "gawker.com\/its-really-har\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476490070585659392",
    "text" : "It's Really Hard to Be a Good Guy With a Gun http:\/\/t.co\/WJetpH60Si",
    "id" : 476490070585659392,
    "created_at" : "2014-06-10 22:24:20 +0000",
    "user" : {
      "name" : "Matt Novak",
      "screen_name" : "paleofuture",
      "protected" : false,
      "id_str" : "16877374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848913715722412034\/Pr2Q51o2_normal.jpg",
      "id" : 16877374,
      "verified" : false
    }
  },
  "id" : 476492157969498112,
  "created_at" : "2014-06-10 22:32:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629704426, -66.086334316 ]
  },
  "id_str" : "476486435051413505",
  "text" : "JH: comp-1 sperm can migrate towards the spermatheca, but show defects in residing there. #smbe14",
  "id" : 476486435051413505,
  "created_at" : "2014-06-10 22:09:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629704426, -66.086334316 ]
  },
  "id_str" : "476486039780220929",
  "text" : "Jody Hansen: comp-1 not only involved in male precedence in male\/hermaphrodite sperm competition, but also male-male sperm comp. #smbe14",
  "id" : 476486039780220929,
  "created_at" : "2014-06-10 22:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/UAZDa0z6cZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/pFAh1Ohwpc\/",
      "display_url" : "instagram.com\/p\/pFAh1Ohwpc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "476472627494531072",
  "text" : "Trying out yet another assembler. http:\/\/t.co\/UAZDa0z6cZ",
  "id" : 476472627494531072,
  "created_at" : "2014-06-10 21:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476420327182835712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631319344, -66.084978506 ]
  },
  "id_str" : "476420750824714240",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp you don't need one. Just play some instrument and you can start criticizing. ;)",
  "id" : 476420750824714240,
  "in_reply_to_status_id" : 476420327182835712,
  "created_at" : "2014-06-10 17:48:53 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476403528756248576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630306391, -66.0850033165 ]
  },
  "id_str" : "476418649394139137",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp that's just like at music festivals.",
  "id" : 476418649394139137,
  "in_reply_to_status_id" : 476403528756248576,
  "created_at" : "2014-06-10 17:40:32 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629077983, -66.0863166304 ]
  },
  "id_str" : "476402516939534336",
  "text" : "\u00ABUh, sorry. I just noticed that this is not my slide deck. But I'll try to run with it anyway.\u00BB #smbe14",
  "id" : 476402516939534336,
  "created_at" : "2014-06-10 16:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ExuaoH8EVD",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/Iyw_RLROABM\/info%3Adoi%2F10.1371%2Fjournal.pone.0094602",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463195, -66.085313 ]
  },
  "id_str" : "476400637106593792",
  "text" : "Driving: A Road to Unhealthy Lifestyles and Poor Health Outcomes http:\/\/t.co\/ExuaoH8EVD",
  "id" : 476400637106593792,
  "created_at" : "2014-06-10 16:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632008243, -66.0853527684 ]
  },
  "id_str" : "476400155638259712",
  "text" : "\u00ABThe worse we made our data, the better our results got.\u00BB #smbe14",
  "id" : 476400155638259712,
  "created_at" : "2014-06-10 16:27:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631430194, -66.0853165828 ]
  },
  "id_str" : "476364742492028928",
  "text" : "\u00ABIf the laws of physics don\u2019t explicitly forbid it, you can be pretty sure biology will do it.\u00BB #SMBE14",
  "id" : 476364742492028928,
  "created_at" : "2014-06-10 14:06:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmit Malik",
      "screen_name" : "HarmitMalik",
      "indices" : [ 3, 15 ],
      "id_str" : "2467226497",
      "id" : 2467226497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476359151543525377",
  "text" : "RT @HarmitMalik: Nick Grishin: physics is about rules, biology is about exceptions #SMBE14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SMBE14",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476357110159400961",
    "text" : "Nick Grishin: physics is about rules, biology is about exceptions #SMBE14",
    "id" : 476357110159400961,
    "created_at" : "2014-06-10 13:36:00 +0000",
    "user" : {
      "name" : "Harmit Malik",
      "screen_name" : "HarmitMalik",
      "protected" : false,
      "id_str" : "2467226497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890668257627078657\/5b-xSHmd_normal.jpg",
      "id" : 2467226497,
      "verified" : false
    }
  },
  "id" : 476359151543525377,
  "created_at" : "2014-06-10 13:44:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/eFzGiV5VNq",
      "expanded_url" : "http:\/\/instagram.com\/p\/pDJTE9hwrE\/",
      "display_url" : "instagram.com\/p\/pDJTE9hwrE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.465664124, -66.095068122 ]
  },
  "id_str" : "476210437545943040",
  "text" : "bird watching the bioinformatician's way @ El Hamberguito http:\/\/t.co\/eFzGiV5VNq",
  "id" : 476210437545943040,
  "created_at" : "2014-06-10 03:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Illumina",
      "screen_name" : "illumina",
      "indices" : [ 104, 113 ],
      "id_str" : "46145761",
      "id" : 46145761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629183305, -66.0862938169 ]
  },
  "id_str" : "476116151429103617",
  "text" : "Why do conference venues always have to show off that their air conditioning goes to 11 (\u00B0C)? Using the @illumina towel as poncho. #smbe14",
  "id" : 476116151429103617,
  "created_at" : "2014-06-09 21:38:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4610017141, -66.0837735459 ]
  },
  "id_str" : "476111324984786945",
  "text" : "\u00ABWe\u2019re working on yeast, to make better beer &amp; it gets funding from the brewery industry.\u00BB You don\u2019t always have to cure cancer for grants.",
  "id" : 476111324984786945,
  "created_at" : "2014-06-09 21:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629679261, -66.0863382564 ]
  },
  "id_str" : "476107335094390785",
  "text" : "\u00ABSo, promiscuity is a good thing. Probably yet another reason why the Catholic Church doesn't like evolution.\u00BB #smbe14",
  "id" : 476107335094390785,
  "created_at" : "2014-06-09 21:03:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476068125926899712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4631852301, -66.0852413112 ]
  },
  "id_str" : "476082095153221632",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek nice to meet you as well! Let's have drinks after the talks and continue.",
  "id" : 476082095153221632,
  "in_reply_to_status_id" : 476068125926899712,
  "created_at" : "2014-06-09 19:23:11 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 34, 50 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE14",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476081939959783424",
  "text" : "RT @PhdGeek: Nice to meet up with @gedankenstuecke at lunch to talk about Fungi phylogenies. This is why twitter is great. #SMBE14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 21, 37 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SMBE14",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476068125926899712",
    "text" : "Nice to meet up with @gedankenstuecke at lunch to talk about Fungi phylogenies. This is why twitter is great. #SMBE14",
    "id" : 476068125926899712,
    "created_at" : "2014-06-09 18:27:40 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 476081939959783424,
  "created_at" : "2014-06-09 19:22:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/uSsZ4fnLMO",
      "expanded_url" : "http:\/\/instagram.com\/p\/pCKL1lhwul\/",
      "display_url" : "instagram.com\/p\/pCKL1lhwul\/"
    } ]
  },
  "geo" : { },
  "id_str" : "476071648932921344",
  "text" : "lunch break #smbe14 http:\/\/t.co\/uSsZ4fnLMO",
  "id" : 476071648932921344,
  "created_at" : "2014-06-09 18:41:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476048490586718208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4633400334, -66.0852580229 ]
  },
  "id_str" : "476049212304789504",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek did you already grab food?",
  "id" : 476049212304789504,
  "in_reply_to_status_id" : 476048490586718208,
  "created_at" : "2014-06-09 17:12:31 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Decker",
      "screen_name" : "pop_gen_JED",
      "indices" : [ 3, 15 ],
      "id_str" : "229711796",
      "id" : 229711796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476043278820069376",
  "text" : "RT @pop_gen_JED: Peischl: Deleterious mutations accumulate at wave front, called expansion load. Expansion load can slow rate of range expa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SMBE14",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476043084258877441",
    "text" : "Peischl: Deleterious mutations accumulate at wave front, called expansion load. Expansion load can slow rate of range expansion #SMBE14",
    "id" : 476043084258877441,
    "created_at" : "2014-06-09 16:48:10 +0000",
    "user" : {
      "name" : "Jared Decker",
      "screen_name" : "pop_gen_JED",
      "protected" : false,
      "id_str" : "229711796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725516876504125440\/FDt-recG_normal.jpg",
      "id" : 229711796,
      "verified" : false
    }
  },
  "id" : 476043278820069376,
  "created_at" : "2014-06-09 16:48:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KZd3WVFckX",
      "expanded_url" : "http:\/\/instagram.com\/p\/pB9HllBwo9\/",
      "display_url" : "instagram.com\/p\/pB9HllBwo9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.463303295, -66.084989531 ]
  },
  "id_str" : "476042916461174785",
  "text" : "If you're missing out on the waves just outside you can at least hear about gene surfing #smbe14 @\u2026 http:\/\/t.co\/KZd3WVFckX",
  "id" : 476042916461174785,
  "created_at" : "2014-06-09 16:47:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476025719618023424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630950422, -66.0850103026 ]
  },
  "id_str" : "476026014250717185",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek great, my ppl spotting skills aren\u2019t great either but we\u2019ll manage somehow (I\u2019m without the cat today, so don\u2019t look for that ;))",
  "id" : 476026014250717185,
  "in_reply_to_status_id" : 476025719618023424,
  "created_at" : "2014-06-09 15:40:20 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476000369529880577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4630950422, -66.0850103026 ]
  },
  "id_str" : "476025536272404480",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek i worked with ~120 lately, wanna talk during the lunch break?",
  "id" : 476025536272404480,
  "in_reply_to_status_id" : 476000369529880577,
  "created_at" : "2014-06-09 15:38:26 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 136, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4632941194, -66.0850902278 ]
  },
  "id_str" : "475999373860814848",
  "text" : "\u00ABApparently we\u2019re able to sequence a human genome within a day but it still takes lots of time to get a presentation up &amp; running.\u00BB #smbe14",
  "id" : 475999373860814848,
  "created_at" : "2014-06-09 13:54:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475747421130354688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.462808257, -66.0854584001 ]
  },
  "id_str" : "475747705726447616",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot cry me a river. Wait, don't, that doesn't help either.",
  "id" : 475747705726447616,
  "in_reply_to_status_id" : 475747421130354688,
  "created_at" : "2014-06-08 21:14:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475746047822934016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628567848, -66.0853304795 ]
  },
  "id_str" : "475746316099022849",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it's used by someone whose learning and personal growth skills are dubious at best.",
  "id" : 475746316099022849,
  "in_reply_to_status_id" : 475746047822934016,
  "created_at" : "2014-06-08 21:08:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475745013708894209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628567848, -66.0853304795 ]
  },
  "id_str" : "475745571098361857",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nope, why should it?",
  "id" : 475745571098361857,
  "in_reply_to_status_id" : 475745013708894209,
  "created_at" : "2014-06-08 21:05:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4629163664, -66.0854368205 ]
  },
  "id_str" : "475743259772588032",
  "text" : "Someone just failed at entering Castillo de San Crist\u00F3bal from seaside not due to lack of climbing skills but as he lent out his pick set\u2026",
  "id" : 475743259772588032,
  "created_at" : "2014-06-08 20:56:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christian m\u00FCller",
      "screen_name" : "capwnd",
      "indices" : [ 0, 7 ],
      "id_str" : "19160866",
      "id" : 19160866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475656668223901698",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "475656843314753536",
  "in_reply_to_user_id" : 19160866,
  "text" : "@capwnd right, if you\u2019re talking about compiling a list of reasons on why we shouldn\u2019t return. :p",
  "id" : 475656843314753536,
  "in_reply_to_status_id" : 475656668223901698,
  "created_at" : "2014-06-08 15:13:23 +0000",
  "in_reply_to_screen_name" : "capwnd",
  "in_reply_to_user_id_str" : "19160866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Td6ihBz8yg",
      "expanded_url" : "http:\/\/instagram.com\/p\/o_LwlDhwjx\/",
      "display_url" : "instagram.com\/p\/o_LwlDhwjx\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.457300302, -66.072108178 ]
  },
  "id_str" : "475652898165362688",
  "text" : "we're not slacking off\u2026 @ Atlantic Beach http:\/\/t.co\/Td6ihBz8yg",
  "id" : 475652898165362688,
  "created_at" : "2014-06-08 14:57:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    }, {
      "name" : "iTunes",
      "screen_name" : "iTunes",
      "indices" : [ 61, 68 ],
      "id_str" : "66515223",
      "id" : 66515223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "music",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "dataviz",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "datascience",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Ebg3657pbH",
      "expanded_url" : "http:\/\/theconnman.github.io\/iTunesAnalysis\/",
      "display_url" : "theconnman.github.io\/iTunesAnalysis\/"
    } ]
  },
  "geo" : { },
  "id_str" : "475652172039061504",
  "text" : "RT @randal_olson: Analyze your own library! --&gt; Excellent @iTunes #music library tool: http:\/\/t.co\/Ebg3657pbH #dataviz #datascience http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iTunes",
        "screen_name" : "iTunes",
        "indices" : [ 43, 50 ],
        "id_str" : "66515223",
        "id" : 66515223
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/475625299221028864\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/XBuGQhq5oV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpnCsFCCcAAhLOA.png",
        "id_str" : "475625298185056256",
        "id" : 475625298185056256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpnCsFCCcAAhLOA.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 1416
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 1416
        } ],
        "display_url" : "pic.twitter.com\/XBuGQhq5oV"
      } ],
      "hashtags" : [ {
        "text" : "music",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "dataviz",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "datascience",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/Ebg3657pbH",
        "expanded_url" : "http:\/\/theconnman.github.io\/iTunesAnalysis\/",
        "display_url" : "theconnman.github.io\/iTunesAnalysis\/"
      } ]
    },
    "geo" : { },
    "id_str" : "475625299221028864",
    "text" : "Analyze your own library! --&gt; Excellent @iTunes #music library tool: http:\/\/t.co\/Ebg3657pbH #dataviz #datascience http:\/\/t.co\/XBuGQhq5oV",
    "id" : 475625299221028864,
    "created_at" : "2014-06-08 13:08:02 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 475652172039061504,
  "created_at" : "2014-06-08 14:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628671823, -66.0853829485 ]
  },
  "id_str" : "475650383881068545",
  "text" : "\u00ABMan denkt der Job bringt ganz viele Freiheiten &amp; dann muss man sich nur mit Verwaltung rumschlagen\u2026\u00BB \u2013 \u00ABKlingt nach meinem Liebesleben\u2026\u00BB",
  "id" : 475650383881068545,
  "created_at" : "2014-06-08 14:47:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628612209, -66.0853914106 ]
  },
  "id_str" : "475594307496583168",
  "text" : "The biggest benefit of constantly being sleep deprived in your local time zone: there's no jet lag.",
  "id" : 475594307496583168,
  "created_at" : "2014-06-08 11:04:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/qtuSciJnR0",
      "expanded_url" : "http:\/\/instagram.com\/p\/o9Z_rshwkE\/",
      "display_url" : "instagram.com\/p\/o9Z_rshwkE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "475402728219234305",
  "text" : "#latergram http:\/\/t.co\/qtuSciJnR0",
  "id" : 475402728219234305,
  "created_at" : "2014-06-07 22:23:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4628719074, -66.0853910851 ]
  },
  "id_str" : "475400076060524545",
  "text" : "\u00ABWenn sie w\u00FCssten was in ihrem Keyboard w\u00E4chst dann w\u00FCrden sie sich \u00FCber meinen desinfizierenden Speichel durchs Bordkarte ablecken freuen!\u00BB",
  "id" : 475400076060524545,
  "created_at" : "2014-06-07 22:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475376708389187584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 18.4525721249, -66.0574454942 ]
  },
  "id_str" : "475390768933507073",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn On my way to #smbe14, had a lay over in the dominican republic",
  "id" : 475390768933507073,
  "in_reply_to_status_id" : 475376708389187584,
  "created_at" : "2014-06-07 21:36:06 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/guorMPaJfl",
      "expanded_url" : "http:\/\/instagram.com\/p\/o9Nj_lBws2\/",
      "display_url" : "instagram.com\/p\/o9Nj_lBws2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "475375388500033537",
  "text" : "in transit http:\/\/t.co\/guorMPaJfl",
  "id" : 475375388500033537,
  "created_at" : "2014-06-07 20:34:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/j2ZOpQUYf8",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0098518",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05025528, 8.57514183 ]
  },
  "id_str" : "475179940317786112",
  "text" : "Epidemic Process over the Commute Network in a Metropolitan Area http:\/\/t.co\/j2ZOpQUYf8",
  "id" : 475179940317786112,
  "created_at" : "2014-06-07 07:38:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 91, 104 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/06eCKhF019",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0097524",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05025528, 8.57514183 ]
  },
  "id_str" : "475178867892957184",
  "text" : "GWAS in a Box: Statistical and Visual Analytics of Structured Associations via GenAMap \/cc @PhilippBayer http:\/\/t.co\/06eCKhF019",
  "id" : 475178867892957184,
  "created_at" : "2014-06-07 07:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/aJZdUwT3Jz",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/88011351095\/fun-fact-if-you-watch-this-gif-long-enough-one",
      "display_url" : "chapmangamo.tumblr.com\/post\/880113510\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05025528, 8.57514183 ]
  },
  "id_str" : "475178251456090112",
  "text" : "Metal on Metal http:\/\/t.co\/aJZdUwT3Jz",
  "id" : 475178251456090112,
  "created_at" : "2014-06-07 07:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0502873492, 8.5752999131 ]
  },
  "id_str" : "475171661160128512",
  "text" : "These 'random' extra security-checks are an insult to my intellectual capabilities. If I was a terrorist I certainly wouldn't look like one\u2026",
  "id" : 475171661160128512,
  "created_at" : "2014-06-07 07:05:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096827042, 8.2829942167 ]
  },
  "id_str" : "475061086065262593",
  "text" : "\u00ABDu hast da eine riesige Hummel auf der Nase sitzen.\u00BB \u2014 \u00ABIch wei\u00DF, ich bin Biologe.\u00BB",
  "id" : 475061086065262593,
  "created_at" : "2014-06-06 23:46:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephan baumgaertner",
      "screen_name" : "baumgast",
      "indices" : [ 0, 9 ],
      "id_str" : "572223195",
      "id" : 572223195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475016248607379457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0055180118, 8.2812808547 ]
  },
  "id_str" : "475016514689859586",
  "in_reply_to_user_id" : 572223195,
  "text" : "@baumgast yes, I will lobby for adding this to my group as well. ;)",
  "id" : 475016514689859586,
  "in_reply_to_status_id" : 475016248607379457,
  "created_at" : "2014-06-06 20:48:57 +0000",
  "in_reply_to_screen_name" : "baumgast",
  "in_reply_to_user_id_str" : "572223195",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephan baumgaertner",
      "screen_name" : "baumgast",
      "indices" : [ 0, 9 ],
      "id_str" : "572223195",
      "id" : 572223195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475011959369498624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0067695557, 8.2719802111 ]
  },
  "id_str" : "475012240194940929",
  "in_reply_to_user_id" : 572223195,
  "text" : "@baumgast hatte den Client gerade offen.",
  "id" : 475012240194940929,
  "in_reply_to_status_id" : 475011959369498624,
  "created_at" : "2014-06-06 20:31:58 +0000",
  "in_reply_to_screen_name" : "baumgast",
  "in_reply_to_user_id_str" : "572223195",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephan baumgaertner",
      "screen_name" : "baumgast",
      "indices" : [ 0, 9 ],
      "id_str" : "572223195",
      "id" : 572223195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475011713012858880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0077167945, 8.2708986104 ]
  },
  "id_str" : "475011954223104000",
  "in_reply_to_user_id" : 572223195,
  "text" : "@baumgast war mir eine Freude. :)",
  "id" : 475011954223104000,
  "in_reply_to_status_id" : 475011713012858880,
  "created_at" : "2014-06-06 20:30:49 +0000",
  "in_reply_to_screen_name" : "baumgast",
  "in_reply_to_user_id_str" : "572223195",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094593503, 8.2687789947 ]
  },
  "id_str" : "475011431898038274",
  "text" : "\u00ABI tagged along because of the promise of free beer and food. I stayed for the the ice cream truck and the bouncy castle.\u00BB",
  "id" : 475011431898038274,
  "created_at" : "2014-06-06 20:28:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474871152394125312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474878247231324160",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH danke, werd ich mal testen :)",
  "id" : 474878247231324160,
  "in_reply_to_status_id" : 474871152394125312,
  "created_at" : "2014-06-06 11:39:31 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474868699086991360",
  "text" : "And as X11-Inkscape on a Mac nearly drove me mad: is there any way to tell it to use cmd instead of ctrl as modifier key?",
  "id" : 474868699086991360,
  "created_at" : "2014-06-06 11:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 110, 119 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe14",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/ifQTTcUf7n",
      "expanded_url" : "http:\/\/figshare.com\/articles\/Poster_SMBE_2014\/1046678",
      "display_url" : "figshare.com\/articles\/Poste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474868411282247680",
  "text" : "My poster \u00ABSequencing &amp; Characterizing the Genome of the Lichen Lasallia pustulata\u00BB for #smbe14 is now on @figshare http:\/\/t.co\/ifQTTcUf7n",
  "id" : 474868411282247680,
  "created_at" : "2014-06-06 11:00:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069326775, 8.2830940894 ]
  },
  "id_str" : "474789669046353920",
  "text" : "Somehow my phone ended up in a puddle of lube over night, resulting in slapstick chase moments while trying to turn off the alarms\u2026",
  "id" : 474789669046353920,
  "created_at" : "2014-06-06 05:47:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 3, 17 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/XNiWcps8CI",
      "expanded_url" : "http:\/\/bit.ly\/Ug68WJ",
      "display_url" : "bit.ly\/Ug68WJ"
    } ]
  },
  "geo" : { },
  "id_str" : "474688114750140416",
  "text" : "RT @bradleyvoytek: Yep. \"Everyone is totally just winging it, all the time.\" http:\/\/t.co\/XNiWcps8CI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/XNiWcps8CI",
        "expanded_url" : "http:\/\/bit.ly\/Ug68WJ",
        "display_url" : "bit.ly\/Ug68WJ"
      } ]
    },
    "geo" : { },
    "id_str" : "474687558618992640",
    "text" : "Yep. \"Everyone is totally just winging it, all the time.\" http:\/\/t.co\/XNiWcps8CI",
    "id" : 474687558618992640,
    "created_at" : "2014-06-05 23:01:47 +0000",
    "user" : {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "protected" : false,
      "id_str" : "162535413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408740651909124\/mz2GSnS0_normal.jpg",
      "id" : 162535413,
      "verified" : true
    }
  },
  "id" : 474688114750140416,
  "created_at" : "2014-06-05 23:04:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/8giiPK6YDJ",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/jun\/04\/new-york-times-columnists-harsh-our-mellow",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096708044, 8.2830221289 ]
  },
  "id_str" : "474685597974814721",
  "text" : "\u00ABIn a way, you could say that rollerblades are the precursor to the Internet. I need to lie down, I think.\u00BB http:\/\/t.co\/8giiPK6YDJ",
  "id" : 474685597974814721,
  "created_at" : "2014-06-05 22:54:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474655740339421184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096708044, 8.2830221289 ]
  },
  "id_str" : "474660821889732608",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC please don\u2019t run into type I errors with that ;)",
  "id" : 474660821889732608,
  "in_reply_to_status_id" : 474655740339421184,
  "created_at" : "2014-06-05 21:15:33 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/250fZESpBV",
      "expanded_url" : "http:\/\/media3.giphy.com\/media\/UlQI7xt5R2iuk\/200.gif",
      "display_url" : "media3.giphy.com\/media\/UlQI7xt5\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1022352777, 8.571892867 ]
  },
  "id_str" : "474639858385043458",
  "text" : "This week so far: a total of 50+ hours of work with ~ 5h sleep per night. Status: http:\/\/t.co\/250fZESpBV",
  "id" : 474639858385043458,
  "created_at" : "2014-06-05 19:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    }, {
      "name" : "ENCODE Project",
      "screen_name" : "ENCODE_NIH",
      "indices" : [ 14, 25 ],
      "id_str" : "543700209",
      "id" : 543700209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474636962192973827",
  "text" : "RT @DanGraur: @ENCODE_NIH will try to kick Graur in the balls. Graur in unafraid. ENCODE has never been able to locate \u201Cjunk.\"\nhttp:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ENCODE Project",
        "screen_name" : "ENCODE_NIH",
        "indices" : [ 0, 11 ],
        "id_str" : "543700209",
        "id" : 543700209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/C2mw7qSS73",
        "expanded_url" : "http:\/\/www.theallium.com\/biology\/spirit-fairness-dan-graur-agrees-kick-balls-encode-scientist\/",
        "display_url" : "theallium.com\/biology\/spirit\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 29.7048844118, -95.4095246658 ]
    },
    "id_str" : "474531912460292097",
    "in_reply_to_user_id" : 543700209,
    "text" : "@ENCODE_NIH will try to kick Graur in the balls. Graur in unafraid. ENCODE has never been able to locate \u201Cjunk.\"\nhttp:\/\/t.co\/C2mw7qSS73",
    "id" : 474531912460292097,
    "created_at" : "2014-06-05 12:43:18 +0000",
    "in_reply_to_screen_name" : "ENCODE_NIH",
    "in_reply_to_user_id_str" : "543700209",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 474636962192973827,
  "created_at" : "2014-06-05 19:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474573390872076288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474617370376695808",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC bayesian ease of mind ;)",
  "id" : 474617370376695808,
  "in_reply_to_status_id" : 474573390872076288,
  "created_at" : "2014-06-05 18:22:53 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overlyhonestmethods",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474616017709453312",
  "text" : "\u00ABDespite knowing better, we performed a b2go analysis, as we really wanted to show some colorful but useless graphs.\u00BB #overlyhonestmethods",
  "id" : 474616017709453312,
  "created_at" : "2014-06-05 18:17:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 44, 53 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474539344590811136",
  "text" : "After about 2 years of regularly wearing my @figshare t-shirt I finally also registered an account with them. m)",
  "id" : 474539344590811136,
  "created_at" : "2014-06-05 13:12:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474538288007905280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474538651272347648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and slowly making you lose all social media skills?",
  "id" : 474538651272347648,
  "in_reply_to_status_id" : 474538288007905280,
  "created_at" : "2014-06-05 13:10:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474536354949640193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474537962223710208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot at least you\u2019re working hard on getting there. ;)",
  "id" : 474537962223710208,
  "in_reply_to_status_id" : 474536354949640193,
  "created_at" : "2014-06-05 13:07:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/xEJsektrib",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=1777",
      "display_url" : "smbc-comics.com\/?id=1777"
    } ]
  },
  "in_reply_to_status_id_str" : "474533468081496065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474535251742818304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/xEJsektrib",
  "id" : 474535251742818304,
  "in_reply_to_status_id" : 474533468081496065,
  "created_at" : "2014-06-05 12:56:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474522140491141121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474531742901350400",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC safe travels, don\u2019t die \u2013 even if that would fit the event.",
  "id" : 474531742901350400,
  "in_reply_to_status_id" : 474522140491141121,
  "created_at" : "2014-06-05 12:42:38 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474518959778459648",
  "text" : "\u00ABUnd was ist mit den Katzen wenn du weg bist?\u00BB\u2013\u00ABErst k\u00FCmmert sich eine Freundin, dann meine Freundin und dann meine Verlobte.\u00BB\u2013\u00ABCome again?\u00BB",
  "id" : 474518959778459648,
  "created_at" : "2014-06-05 11:51:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IAD8m7RVt1",
      "expanded_url" : "http:\/\/instagram.com\/p\/o20i8xhwkW\/",
      "display_url" : "instagram.com\/p\/o20i8xhwkW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "474475952026955776",
  "text" : "Getting some biology to the bioinformaticians. Left: Rattus norvegicus, right: Sciurus vulgaris @\u2026 http:\/\/t.co\/IAD8m7RVt1",
  "id" : 474475952026955776,
  "created_at" : "2014-06-05 09:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Vaught \u2697\uD83D\uDD14",
      "screen_name" : "biochembelle",
      "indices" : [ 3, 16 ],
      "id_str" : "79489732",
      "id" : 79489732
    }, {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 35, 47 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ODRzLRgfCT",
      "expanded_url" : "http:\/\/j.mp\/1kDk07h",
      "display_url" : "j.mp\/1kDk07h"
    } ]
  },
  "geo" : { },
  "id_str" : "474442304309436416",
  "text" : "RT @biochembelle: Thoughtful... MT @brainpicker: How to criticize w kindness - 4 steps to arguing intelligently http:\/\/t.co\/ODRzLRgfCT http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Popova",
        "screen_name" : "brainpicker",
        "indices" : [ 17, 29 ],
        "id_str" : "9207632",
        "id" : 9207632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brainpicker\/status\/474330796502040576\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PSx1nvJPXQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpUpWJkIEAAgyyG.jpg",
        "id_str" : "474330796258758656",
        "id" : 474330796258758656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpUpWJkIEAAgyyG.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        } ],
        "display_url" : "pic.twitter.com\/PSx1nvJPXQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ODRzLRgfCT",
        "expanded_url" : "http:\/\/j.mp\/1kDk07h",
        "display_url" : "j.mp\/1kDk07h"
      } ]
    },
    "geo" : { },
    "id_str" : "474338706804211712",
    "text" : "Thoughtful... MT @brainpicker: How to criticize w kindness - 4 steps to arguing intelligently http:\/\/t.co\/ODRzLRgfCT http:\/\/t.co\/PSx1nvJPXQ",
    "id" : 474338706804211712,
    "created_at" : "2014-06-04 23:55:35 +0000",
    "user" : {
      "name" : "Melissa Vaught \u2697\uD83D\uDD14",
      "screen_name" : "biochembelle",
      "protected" : false,
      "id_str" : "79489732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897064571663527937\/u_84bKod_normal.jpg",
      "id" : 79489732,
      "verified" : false
    }
  },
  "id" : 474442304309436416,
  "created_at" : "2014-06-05 06:47:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lPoI9hAcDL",
      "expanded_url" : "http:\/\/jasonya.com\/wp\/dealing-with-academic-rejection",
      "display_url" : "jasonya.com\/wp\/dealing-wit\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096750167, 8.2829093747 ]
  },
  "id_str" : "474328429987635201",
  "text" : "Fitting for today's news on my end as well: \u00ABIf you\u2019re not failing, you\u2019re not doing it right.\u00BB http:\/\/t.co\/lPoI9hAcDL",
  "id" : 474328429987635201,
  "created_at" : "2014-06-04 23:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/awDsrsZ0nl",
      "expanded_url" : "http:\/\/www.vice.com\/read\/coming-on-camera-beautiful-agonys-orgasmic-porn",
      "display_url" : "vice.com\/read\/coming-on\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096758114, 8.2830554829 ]
  },
  "id_str" : "474324825385996289",
  "text" : "Oh wow, Beautiful Agony is turning 10 this year! http:\/\/t.co\/awDsrsZ0nl",
  "id" : 474324825385996289,
  "created_at" : "2014-06-04 23:00:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096758114, 8.2830554829 ]
  },
  "id_str" : "474271998664011776",
  "text" : "\u00ABI guess I will just try random sampling of past world cup games for the prediction game.\u00BB \u2013 \u00ABGood idea, I might train some HMMs!\u00BB",
  "id" : 474271998664011776,
  "created_at" : "2014-06-04 19:30:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474188013782986752",
  "text" : "\u00ABAn esteemed and highly respected member of a profession renowned for its beards, bad hygiene and shut-ins.\u00BB Not all scientists are like me!",
  "id" : 474188013782986752,
  "created_at" : "2014-06-04 13:56:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/0tzV5Pq8xC",
      "expanded_url" : "http:\/\/bit.ly\/1uhjNt5",
      "display_url" : "bit.ly\/1uhjNt5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474187718516572160",
  "text" : "\u00ABA world without MDMA is a world I don't want to live in\u00BB http:\/\/t.co\/0tzV5Pq8xC",
  "id" : 474187718516572160,
  "created_at" : "2014-06-04 13:55:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474166723713982464",
  "text" : "\u00ABIch lese die Update Notes vom Goatse Simulator. Uh, that came out wrong.\u00BB \u2013 \u00ABAdded: Third Hand. Removed: Third Hand.\u00BB",
  "id" : 474166723713982464,
  "created_at" : "2014-06-04 12:32:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aUDgFyjRdh",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=y-q6N3XuDz8",
      "display_url" : "youtube.com\/watch?v=y-q6N3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172337653, 8.627550659 ]
  },
  "id_str" : "474146911830941696",
  "text" : "\u00ABWe were just talking about the 'watermelon headshot' video. Do you know the English term for 'schadenfreude'?\u00BB http:\/\/t.co\/aUDgFyjRdh",
  "id" : 474146911830941696,
  "created_at" : "2014-06-04 11:13:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/474109092496424960\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/CtjbbQB8VO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpRftSSIcAAG_A1.png",
      "id_str" : "474109092387385344",
      "id" : 474109092387385344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpRftSSIcAAG_A1.png",
      "sizes" : [ {
        "h" : 108,
        "resize" : "crop",
        "w" : 108
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CtjbbQB8VO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474039545986441216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474109092496424960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you\u2019re to blame for that ;) http:\/\/t.co\/CtjbbQB8VO",
  "id" : 474109092496424960,
  "in_reply_to_status_id" : 474039545986441216,
  "created_at" : "2014-06-04 08:43:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/474099305926914048\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/EyRvDj8s5e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpRWznUIUAAnbLa.jpg",
      "id_str" : "474099305507475456",
      "id" : 474099305507475456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpRWznUIUAAnbLa.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/EyRvDj8s5e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474097333081497601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723652006, 8.6274671527 ]
  },
  "id_str" : "474099305926914048",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC works for me ;) http:\/\/t.co\/EyRvDj8s5e",
  "id" : 474099305926914048,
  "in_reply_to_status_id" : 474097333081497601,
  "created_at" : "2014-06-04 08:04:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474096372720095232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "474096622713196544",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you call it pedagogical intervention, I call it selection pressure. ;)",
  "id" : 474096622713196544,
  "in_reply_to_status_id" : 474096372720095232,
  "created_at" : "2014-06-04 07:53:37 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 25, 32 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "openFDA",
      "screen_name" : "openFDA",
      "indices" : [ 33, 41 ],
      "id_str" : "2227519598",
      "id" : 2227519598
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 42, 54 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474078897441501184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415247, 8.6274562698 ]
  },
  "id_str" : "474093517762228224",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn @HHSGov @openFDA @helgerausch we should do a sticker swap ;)",
  "id" : 474093517762228224,
  "in_reply_to_status_id" : 474078897441501184,
  "created_at" : "2014-06-04 07:41:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473939309263736832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096741045, 8.2830416173 ]
  },
  "id_str" : "473995390648188931",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC those can just get kicked out?",
  "id" : 473995390648188931,
  "in_reply_to_status_id" : 473939309263736832,
  "created_at" : "2014-06-04 01:11:22 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473937842763091968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619458, 8.2829981801 ]
  },
  "id_str" : "473938234523648001",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC do not care about those who need to be treated like children and focus energy on those who are invested by themselves.",
  "id" : 473938234523648001,
  "in_reply_to_status_id" : 473937842763091968,
  "created_at" : "2014-06-03 21:24:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473912357245444097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096152956, 8.2829418965 ]
  },
  "id_str" : "473913074278100992",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC natural selection? After all they are adults and presumably chose to study because they want to learn smthng.",
  "id" : 473913074278100992,
  "in_reply_to_status_id" : 473912357245444097,
  "created_at" : "2014-06-03 19:44:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473571769031622657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723463663, 8.6275209066 ]
  },
  "id_str" : "473911431386386432",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC isn't the saying 'treat them like children and they'll act as such'?",
  "id" : 473911431386386432,
  "in_reply_to_status_id" : 473571769031622657,
  "created_at" : "2014-06-03 19:37:44 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 73, 80 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009598973, 8.2828896678 ]
  },
  "id_str" : "473884528994713600",
  "text" : "\u00ABGib mir dein kleines G\u00FCrkchen ganz aufreizend in den Mund.\u00BB \u2014 \u00ABPorn f\u00FCr @lsanoj!\u00BB",
  "id" : 473884528994713600,
  "created_at" : "2014-06-03 17:50:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473796604148088832",
  "text" : "\u00ABNiemand nimmt mich ernst!\u00BB \u2013 \u00ABDas stimmt doch gar nicht, ich nehme dich ernst.\u00BB \u2013 \u00ABDu nimmst mich hart, das ist ein Unterschied\u2026\u00BB",
  "id" : 473796604148088832,
  "created_at" : "2014-06-03 12:01:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/3va3wkIsOv",
      "expanded_url" : "http:\/\/instagram.com\/p\/owIfz0BwhP\/",
      "display_url" : "instagram.com\/p\/owIfz0BwhP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "473534661487259648",
  "text" : "dinner @ Goethe-Universit\u00E4t Frankfurt, Campus Riedberg http:\/\/t.co\/3va3wkIsOv",
  "id" : 473534661487259648,
  "created_at" : "2014-06-02 18:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8OMagyeQ4q",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/18404243-good-manners-for-nice-people-who-sometimes-say-f-ck",
      "display_url" : "goodreads.com\/book\/show\/1840\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473520826386747393",
  "text" : "\u00ABHey, ich hab gerade ein Buch f\u00FCr dich gefunden: \u2018Good Manners for Nice People Who Sometimes Say Fuck\u2019.\u00BB https:\/\/t.co\/8OMagyeQ4q",
  "id" : 473520826386747393,
  "created_at" : "2014-06-02 17:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473450995901800448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473451467505156096",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus how would I know, f\u00FCr mich ist es einer. Gibt aber die Leute die nur Tierschutz als einen moralischen Grund annehmen.",
  "id" : 473451467505156096,
  "in_reply_to_status_id" : 473450995901800448,
  "created_at" : "2014-06-02 13:10:00 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473449473193291776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473450567436865537",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus naja, eng umfasst k\u00F6nnte w\u00E4re ggf. nur \u201Coh, die armen Tiere die so leiden, yadda yadda yadda\u201D.",
  "id" : 473450567436865537,
  "in_reply_to_status_id" : 473449473193291776,
  "created_at" : "2014-06-02 13:06:26 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "473448064406274049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473449334894505984",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus o\/ wenn \u201CUmweltbelastung durch Wirbeltierhaltung\u201D zu moralischen Gr\u00FCnden z\u00E4hlt f\u00FCr dich.",
  "id" : 473449334894505984,
  "in_reply_to_status_id" : 473448064406274049,
  "created_at" : "2014-06-02 13:01:32 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473387000071204864",
  "text" : "blast2somewhat-educated-guesswork",
  "id" : 473387000071204864,
  "created_at" : "2014-06-02 08:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/hXd47rFwKE",
      "expanded_url" : "https:\/\/www.jacobinmag.com\/2014\/01\/in-the-name-of-love\/",
      "display_url" : "jacobinmag.com\/2014\/01\/in-the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230942, 8.6276019057 ]
  },
  "id_str" : "473377492485824512",
  "text" : "\u00AB\u2019Do What You Love\u2019 is, in fact, the most perfect ideological tool of capitalism\u00BB https:\/\/t.co\/hXd47rFwKE",
  "id" : 473377492485824512,
  "created_at" : "2014-06-02 08:16:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725797476, 8.6253557972 ]
  },
  "id_str" : "473371304377470976",
  "text" : "\u00ABentropy and optimism: the twin forces that make the universe go around\u00BB",
  "id" : 473371304377470976,
  "created_at" : "2014-06-02 07:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966226, 8.2830607714 ]
  },
  "id_str" : "473155558372311040",
  "text" : "If I had time for that I\u2019d do a correlation of \u201Ctime until SMBE starts\u201D and my daily step count\u2026",
  "id" : 473155558372311040,
  "created_at" : "2014-06-01 17:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1061477, 8.68884434 ]
  },
  "id_str" : "473137854751973376",
  "text" : "\u00ABBeim Marathon k\u00F6nntest du deinen Laptop vor dem Bauch tragen und dir eine Antenne auf den Kopf binden.\u00BB \u2014 \u00ABMy jobs are running as well!\u00BB",
  "id" : 473137854751973376,
  "created_at" : "2014-06-01 16:23:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723303192, 8.627637119 ]
  },
  "id_str" : "473114422693888001",
  "text" : "\u00ABIn der Chemie explodiert alles. In der Biologie stirbt alles.\u00BB",
  "id" : 473114422693888001,
  "created_at" : "2014-06-01 14:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096787047, 8.2831234485 ]
  },
  "id_str" : "472866321039097856",
  "text" : "Der Nachbar schl\u00E4ft zu 'Die 10 sch\u00F6nsten Verschw\u00F6rungstheorien' ein. Das erkl\u00E4rt einiges.",
  "id" : 472866321039097856,
  "created_at" : "2014-05-31 22:24:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]