Grailbird.data.tweets_2008_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873825031",
  "text" : "Cola ist ein 1A Reinigungsmittel: http:\/\/tinyurl.com\/59slde",
  "id" : 873825031,
  "created_at" : "2008-07-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871485079",
  "text" : "Mist, ich glaube mein 50mm hat seit kurzem mit Backfocusing zu k\u00E4mpfen...",
  "id" : 871485079,
  "created_at" : "2008-07-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869711368",
  "text" : "Oehm ja, wieder da. Feeds lesen, Fotos auf Platte laden, Fotos durchsehen. Zeug halt",
  "id" : 869711368,
  "created_at" : "2008-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869715960",
  "text" : "\u00DCber Bande\/Decke blitzen ist eine pfiffige Idee, aber doch nicht bei einem OPEN AIR!",
  "id" : 869715960,
  "created_at" : "2008-07-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857828564",
  "text" : "Einstellung mancher Pressefotografen: Alles != \"Die Fresse wegblitzen\" ist schon Kunst...",
  "id" : 857828564,
  "created_at" : "2008-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857871888",
  "text" : "Seit gestern Abend treibt mich der verdammte Flickr-Uploader in den Wahnsinn (\"Houston we got a problem\") Windows-Alternativen?",
  "id" : 857871888,
  "created_at" : "2008-07-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs",
      "indices" : [ 0, 13 ],
      "id_str" : "37921458",
      "id" : 37921458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857912494",
  "geo" : { },
  "id_str" : "857916038",
  "in_reply_to_user_id" : 15072786,
  "text" : "@Scienceblogs Sackgasse mit Aussicht auf Taxifahrer, aber Spa\u00DF dabei sagt der werdende Bachelor :)",
  "id" : 857916038,
  "in_reply_to_status_id" : 857912494,
  "created_at" : "2008-07-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857232424",
  "text" : "Pelicases sind cool. Au\u00DFen vollgespackt mit Sand? Egal. Einfach mit dem Gartenschlauch dr\u00FCber. Auspacken unn\u00F6tig",
  "id" : 857232424,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857265920",
  "text" : "so, Pelicase wieder trocken, darf wieder rein :)",
  "id" : 857265920,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857266125",
  "text" : "http:\/\/tinyurl.com\/5vtu7c man sieht auf welches objektiv die wahl gefallen ist ;)",
  "id" : 857266125,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857373817",
  "geo" : { },
  "id_str" : "857375051",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze Ne, aber unter Windows gehts mit dem Firefox 3",
  "id" : 857375051,
  "in_reply_to_status_id" : 857373817,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857144936",
  "text" : "Fotografen die sich nur durch ihre Ausr\u00FCstung profilieren machen mich immer wieder traurig...",
  "id" : 857144936,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857146690",
  "geo" : { },
  "id_str" : "857147652",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze Fast schon belustigend wird es dann wenn sie glauben das sie deshalb \"gut\" sind...",
  "id" : 857147652,
  "in_reply_to_status_id" : 857146690,
  "created_at" : "2008-07-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaputt",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "drunk",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856857235",
  "text" : "Puh, wieder da vom Emsboom Festival #kaputt #drunk",
  "id" : 856857235,
  "created_at" : "2008-07-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855496802",
  "text" : "Und wieder eine Klausur erledigt. Eine kommt noch",
  "id" : 855496802,
  "created_at" : "2008-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855543336",
  "text" : "http:\/\/tinyurl.com\/63cakv Da muss man einfach drauf aufmerksam machen. Auch wenns Werbung ist.",
  "id" : 855543336,
  "created_at" : "2008-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855558009",
  "geo" : { },
  "id_str" : "855560591",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog : Wer verzapft denn so etwas?",
  "id" : 855560591,
  "in_reply_to_status_id" : 855558009,
  "created_at" : "2008-07-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856078970",
  "text" : "OMG, Fisheye ist grossartig! :P",
  "id" : 856078970,
  "created_at" : "2008-07-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854877192",
  "text" : "Morgen gibts die n\u00E4chste Klausur. Und hoffentlich das neue Objektiv!",
  "id" : 854877192,
  "created_at" : "2008-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854899257",
  "text" : "Oha, Poker ist also nach Schach & Dame auch \"gel\u00F6st\": http:\/\/tinyurl.com\/6gjmb8",
  "id" : 854899257,
  "created_at" : "2008-07-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith",
      "screen_name" : "Sympatexter",
      "indices" : [ 0, 12 ],
      "id_str" : "6438252",
      "id" : 6438252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853928679",
  "geo" : { },
  "id_str" : "853929671",
  "in_reply_to_user_id" : 6438252,
  "text" : "@Sympatexter es kann nicht bl\u00F6der sein als Darwin im Original zu lesen :P",
  "id" : 853929671,
  "in_reply_to_status_id" : 853928679,
  "created_at" : "2008-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sympatexter",
  "in_reply_to_user_id_str" : "6438252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith",
      "screen_name" : "Sympatexter",
      "indices" : [ 0, 12 ],
      "id_str" : "6438252",
      "id" : 6438252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853940665",
  "geo" : { },
  "id_str" : "853965833",
  "in_reply_to_user_id" : 6438252,
  "text" : "@sympatexter immerhin nicht von 18xx sondern nur 19xx",
  "id" : 853965833,
  "in_reply_to_status_id" : 853940665,
  "created_at" : "2008-07-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Sympatexter",
  "in_reply_to_user_id_str" : "6438252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "852840494",
  "text" : "Versuche Python zu lernen.",
  "id" : 852840494,
  "created_at" : "2008-07-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "852148082",
  "text" : "Und auch die zweite Klausur geschafft!",
  "id" : 852148082,
  "created_at" : "2008-07-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "849972796",
  "text" : "So, erste Klausur \u00FCberlebt",
  "id" : 849972796,
  "created_at" : "2008-07-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847675554",
  "text" : "http:\/\/tinyurl.com\/5eh7cb Indeed, Wissenschaftler haben es immer schon gewusst",
  "id" : 847675554,
  "created_at" : "2008-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847724774",
  "geo" : { },
  "id_str" : "847729026",
  "in_reply_to_user_id" : 6085542,
  "text" : "@Rozana peinlich, mir ist das auch schon ein paar mal passiert und hab mich dann \u00FCber das nervige Clone-Tool von Lightroom beschwert :)",
  "id" : 847729026,
  "in_reply_to_status_id" : 847724774,
  "created_at" : "2008-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "847733423",
  "geo" : { },
  "id_str" : "847736543",
  "in_reply_to_user_id" : 6085542,
  "text" : "@rozana h\u00F6rt sich nach viel Stress an",
  "id" : 847736543,
  "in_reply_to_status_id" : 847733423,
  "created_at" : "2008-07-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847757466",
  "text" : "oha, das ist ja mal ein WW-Objektiv nach meinem Geschmack: http:\/\/tinyurl.com\/664han",
  "id" : 847757466,
  "created_at" : "2008-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "847906078",
  "text" : "Heute vor 150 Jahren gabs den ersten Aufschwung f\u00FCr die Erkl\u00E4rung der Evolution: http:\/\/tinyurl.com\/5elm22",
  "id" : 847906078,
  "created_at" : "2008-07-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]