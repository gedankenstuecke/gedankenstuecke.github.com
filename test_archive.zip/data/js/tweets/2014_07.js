Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "iceland",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/5Wazhb3UPz",
      "expanded_url" : "http:\/\/instagram.com\/p\/rIVX8tBwgZ\/",
      "display_url" : "instagram.com\/p\/rIVX8tBwgZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "494955076734435328",
  "text" : "Ice at J\u00F6kuls\u00E1rl\u00F3n #latergram #iceland http:\/\/t.co\/5Wazhb3UPz",
  "id" : 494955076734435328,
  "created_at" : "2014-07-31 21:17:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Zmg7wym1ya",
      "expanded_url" : "http:\/\/instagram.com\/p\/rIUxMthwvl\/",
      "display_url" : "instagram.com\/p\/rIUxMthwvl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "494953744707379200",
  "text" : "Roadside #latergram http:\/\/t.co\/Zmg7wym1ya",
  "id" : 494953744707379200,
  "created_at" : "2014-07-31 21:12:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.620444038, -19.9882218149 ]
  },
  "id_str" : "494950587587633153",
  "text" : "Just brushed my teeth in a waterfall that's powered by melting water of Eyjafjallaj\u00F6kull.",
  "id" : 494950587587633153,
  "created_at" : "2014-07-31 20:59:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9020338508, -20.3038805775 ]
  },
  "id_str" : "494857652531642368",
  "text" : "\u00ABHast du wirklich #yolo ins G\u00E4stebuch geschrieben?!\u00BB \u2014 \u00ABJa, wieso?\u00BB \u2014 \u00ABDas war von dem Friedhof\u2026\u00BB",
  "id" : 494857652531642368,
  "created_at" : "2014-07-31 14:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9789309346, -16.8532424226 ]
  },
  "id_str" : "494776652455739392",
  "text" : "One nice thing learned from this trip: the lack of a day\/night circle shows that my circadian rhythm really defaults to 5h sleep per 'night'",
  "id" : 494776652455739392,
  "created_at" : "2014-07-31 09:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/QmwxRhprA6",
      "expanded_url" : "http:\/\/instagram.com\/p\/rGzgE0hwjY\/",
      "display_url" : "instagram.com\/p\/rGzgE0hwjY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "494739850722312192",
  "text" : "ready for the next leg of the journey http:\/\/t.co\/QmwxRhprA6",
  "id" : 494739850722312192,
  "created_at" : "2014-07-31 07:02:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/OvPsnpWWup",
      "expanded_url" : "http:\/\/instagram.com\/p\/rFn4ifBwoB\/",
      "display_url" : "instagram.com\/p\/rFn4ifBwoB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.978995115, -16.852935985 ]
  },
  "id_str" : "494573567288557568",
  "text" : "Setting foot on Europe's largest glacier @ Vatnaj\u00F6kull http:\/\/t.co\/OvPsnpWWup",
  "id" : 494573567288557568,
  "created_at" : "2014-07-30 20:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 10, 19 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494561112323796992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9784815163, -16.8535174336 ]
  },
  "id_str" : "494561390926266368",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @thorgnyr sure, you would be insane to go naked with those temperatures!",
  "id" : 494561390926266368,
  "in_reply_to_status_id" : 494561112323796992,
  "created_at" : "2014-07-30 19:13:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494557371625390081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9788991598, -16.8530637503 ]
  },
  "id_str" : "494557675360124928",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr I know, it's probably just around the 4\u00B0C, but the photo (and probably your look when you saw it) were worth all the pain. :p",
  "id" : 494557675360124928,
  "in_reply_to_status_id" : 494557371625390081,
  "created_at" : "2014-07-30 18:58:32 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494556679527469056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9789177741, -16.8531684188 ]
  },
  "id_str" : "494557001842950144",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr It's not as cold as it looks like! (ok, it is just as cold\u2026)",
  "id" : 494557001842950144,
  "in_reply_to_status_id" : 494556679527469056,
  "created_at" : "2014-07-30 18:55:52 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 81, 90 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/NOob9sPPQV",
      "expanded_url" : "http:\/\/instagram.com\/p\/rFf3zxhwps\/",
      "display_url" : "instagram.com\/p\/rFf3zxhwps\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.97889916, -16.85306375 ]
  },
  "id_str" : "494556050503528449",
  "text" : "Going to J\u00F6kuls\u00E1rl\u00F3n in order to make up for missing a swim in the Atlantic with @thorgnyr http:\/\/t.co\/NOob9sPPQV",
  "id" : 494556050503528449,
  "created_at" : "2014-07-30 18:52:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494420667513962496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.2603104444, -15.205241809 ]
  },
  "id_str" : "494424043073060864",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ja, kommt hin. War f\u00FCr hiking in den Bergen hier auf jeden Fall prima.",
  "id" : 494424043073060864,
  "in_reply_to_status_id" : 494420667513962496,
  "created_at" : "2014-07-30 10:07:32 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/K4c5SuTrrZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/rEe4HqBwnR\/",
      "display_url" : "instagram.com\/p\/rEe4HqBwnR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.048497977, -16.179408984 ]
  },
  "id_str" : "494413023252320256",
  "text" : "tangled up in blue #iceland @ J\u00F6kuls\u00E1rl\u00F3n http:\/\/t.co\/K4c5SuTrrZ",
  "id" : 494413023252320256,
  "created_at" : "2014-07-30 09:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494255421704515584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.2587798661, -15.2053880134 ]
  },
  "id_str" : "494411991575175171",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther it's okay. My 2nd speeding ticket in 10 years. It's like getting my first cease &amp; desist after 15 years of file sharing. ;)",
  "id" : 494411991575175171,
  "in_reply_to_status_id" : 494255421704515584,
  "created_at" : "2014-07-30 09:19:39 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494264245530656768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.2587842685, -15.2054106759 ]
  },
  "id_str" : "494411622841323520",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU welches Modell es ist \u00FCberfragt mich gerade. Eines der wasserabweisenden Wintermod. Nach 1 1\/2 Wochen Island gut zufrieden.",
  "id" : 494411622841323520,
  "in_reply_to_status_id" : 494264245530656768,
  "created_at" : "2014-07-30 09:18:11 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipster",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "yolo",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "iceland",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/0LCUfwXSNF",
      "expanded_url" : "http:\/\/instagram.com\/p\/rDWaEiBwgu\/",
      "display_url" : "instagram.com\/p\/rDWaEiBwgu\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.254694785, -15.208792357 ]
  },
  "id_str" : "494253662253121536",
  "text" : "Foodporn #hipster #yolo #iceland @ Hofn, Iceland http:\/\/t.co\/0LCUfwXSNF",
  "id" : 494253662253121536,
  "created_at" : "2014-07-29 22:50:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.2588075408, -15.2054317864 ]
  },
  "id_str" : "494242802210209792",
  "text" : "Achievement: my driving skills lead the traffic cops to the believe that I'm a local. Also, TIL: 30 km\/h over the speed limit costs 50k ISK.",
  "id" : 494242802210209792,
  "created_at" : "2014-07-29 22:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.4179157578, -19.0015209373 ]
  },
  "id_str" : "494172399802523648",
  "text" : "\u00ABDo you smell that? Is that the poisonous gas?!\u00BB \u2014 \u00ABHow would I know whether that's your smell or a side effect of the volcano?\u00BB",
  "id" : 494172399802523648,
  "created_at" : "2014-07-29 17:27:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "494140631237668864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.4180548974, -19.0013977233 ]
  },
  "id_str" : "494172147657748480",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther get well soon!",
  "id" : 494172147657748480,
  "in_reply_to_status_id" : 494140631237668864,
  "created_at" : "2014-07-29 17:26:35 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417546399, -21.9357281324 ]
  },
  "id_str" : "494109265528119296",
  "text" : "\u00ABOh, don\u2019t go hiking there. The poisonous gases around the area might kill you otherwise.\u00BB #iceland",
  "id" : 494109265528119296,
  "created_at" : "2014-07-29 13:16:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex von Tunzelmann",
      "screen_name" : "alexvtunzelmann",
      "indices" : [ 3, 19 ],
      "id_str" : "115941509",
      "id" : 115941509
    }, {
      "name" : "Dean Burnett",
      "screen_name" : "garwboy",
      "indices" : [ 35, 43 ],
      "id_str" : "20474878",
      "id" : 20474878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/alexvtunzelmann\/status\/494019244427067392\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/r5mPsr00Zk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btsb4muCUAE4ls8.jpg",
      "id_str" : "494019243407462401",
      "id" : 494019243407462401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btsb4muCUAE4ls8.jpg",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/r5mPsr00Zk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VDQwodBolV",
      "expanded_url" : "https:\/\/twitter.com\/richarddawkins\/status\/494012678432894976",
      "display_url" : "twitter.com\/richarddawkins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494031567862661120",
  "text" : "RT @alexvtunzelmann: I see we need @garwboy's Richard Dawkins flowchart again: https:\/\/t.co\/VDQwodBolV http:\/\/t.co\/r5mPsr00Zk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dean Burnett",
        "screen_name" : "garwboy",
        "indices" : [ 14, 22 ],
        "id_str" : "20474878",
        "id" : 20474878
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alexvtunzelmann\/status\/494019244427067392\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/r5mPsr00Zk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Btsb4muCUAE4ls8.jpg",
        "id_str" : "494019243407462401",
        "id" : 494019243407462401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btsb4muCUAE4ls8.jpg",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/r5mPsr00Zk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/VDQwodBolV",
        "expanded_url" : "https:\/\/twitter.com\/richarddawkins\/status\/494012678432894976",
        "display_url" : "twitter.com\/richarddawkins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494019244427067392",
    "text" : "I see we need @garwboy's Richard Dawkins flowchart again: https:\/\/t.co\/VDQwodBolV http:\/\/t.co\/r5mPsr00Zk",
    "id" : 494019244427067392,
    "created_at" : "2014-07-29 07:19:00 +0000",
    "user" : {
      "name" : "Alex von Tunzelmann",
      "screen_name" : "alexvtunzelmann",
      "protected" : false,
      "id_str" : "115941509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642639115167604736\/wPaZXy2p_normal.jpg",
      "id" : 115941509,
      "verified" : true
    }
  },
  "id" : 494031567862661120,
  "created_at" : "2014-07-29 08:07:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417081028, -21.935543263 ]
  },
  "id_str" : "494026843784482817",
  "text" : "Plan for the rest of the week so far: tour the south until Friday afternoon, spend the weekend at the Innip\u00FAkinn festival.",
  "id" : 494026843784482817,
  "created_at" : "2014-07-29 07:49:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493938876331728897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417008335, -21.9355365322 ]
  },
  "id_str" : "494001054414274560",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther the things you do to visit dear friends. But I'm not too nervous about it. Why can't you travel atm?",
  "id" : 494001054414274560,
  "in_reply_to_status_id" : 493938876331728897,
  "created_at" : "2014-07-29 06:06:44 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493928932983328768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417066845, -21.9355294903 ]
  },
  "id_str" : "493937115454251009",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther Israel is on my travel schedule for next month. But yes, I will watch out in both cases. :)",
  "id" : 493937115454251009,
  "in_reply_to_status_id" : 493928932983328768,
  "created_at" : "2014-07-29 01:52:39 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493927297783586817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417015366, -21.9354963095 ]
  },
  "id_str" : "493928514878734336",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther then I'm not sure on whether it's safer or just a different kind of dangerous. ;)",
  "id" : 493928514878734336,
  "in_reply_to_status_id" : 493927297783586817,
  "created_at" : "2014-07-29 01:18:29 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493926756936470528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417016703, -21.9354959761 ]
  },
  "id_str" : "493926918220423168",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther where's \"here\"?",
  "id" : 493926918220423168,
  "in_reply_to_status_id" : 493926756936470528,
  "created_at" : "2014-07-29 01:12:08 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493924072015679488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417021352, -21.9354917355 ]
  },
  "id_str" : "493925818780102656",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther thanks, we will do our best to not get ourselves killed ;)",
  "id" : 493925818780102656,
  "in_reply_to_status_id" : 493924072015679488,
  "created_at" : "2014-07-29 01:07:46 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493911669332914179",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141726411, -21.9356167046 ]
  },
  "id_str" : "493921853749358592",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther thanks! we just booked another car to go out again until Friday. Will then go to a music festival in Reykjavik for the last days.",
  "id" : 493921853749358592,
  "in_reply_to_status_id" : 493911669332914179,
  "created_at" : "2014-07-29 00:52:01 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493864864772009986",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417046408, -21.9355140026 ]
  },
  "id_str" : "493905664985800704",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther I haven\u2019t found that possibility so far.",
  "id" : 493905664985800704,
  "in_reply_to_status_id" : 493864864772009986,
  "created_at" : "2014-07-28 23:47:41 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493873101240029184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417046408, -21.9355140026 ]
  },
  "id_str" : "493905607582552064",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err not yet :)",
  "id" : 493905607582552064,
  "in_reply_to_status_id" : 493873101240029184,
  "created_at" : "2014-07-28 23:47:27 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Heimann",
      "screen_name" : "ralfheimann",
      "indices" : [ 0, 12 ],
      "id_str" : "23431577",
      "id" : 23431577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493841430625132545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417075181, -21.9355466719 ]
  },
  "id_str" : "493841649920147456",
  "in_reply_to_user_id" : 23431577,
  "text" : "@ralfheimann der ist auch so auf der Hand liegend wie der Mensch auf der Luftmatratze.",
  "id" : 493841649920147456,
  "in_reply_to_status_id" : 493841430625132545,
  "created_at" : "2014-07-28 19:33:19 +0000",
  "in_reply_to_screen_name" : "ralfheimann",
  "in_reply_to_user_id_str" : "23431577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Heimann",
      "screen_name" : "ralfheimann",
      "indices" : [ 0, 12 ],
      "id_str" : "23431577",
      "id" : 23431577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493790338901745665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417046007, -21.9355088739 ]
  },
  "id_str" : "493841061786431488",
  "in_reply_to_user_id" : 23431577,
  "text" : "@ralfheimann ist die \u00DCberwasserkirche damit schon zur Unterwasserkirche geworden?",
  "id" : 493841061786431488,
  "in_reply_to_status_id" : 493790338901745665,
  "created_at" : "2014-07-28 19:30:58 +0000",
  "in_reply_to_screen_name" : "ralfheimann",
  "in_reply_to_user_id_str" : "23431577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141707396, -21.9355420117 ]
  },
  "id_str" : "493827300346306560",
  "text" : "\u00ABWould you like to go to the hot spring?\u00BB \u2013 \u00ABIf I had to choose I\u2019d rather go for the BFG. The \u201CBig Fuckin\u2019 Glacier\u201D.\u00BB",
  "id" : 493827300346306560,
  "created_at" : "2014-07-28 18:36:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reykjavik",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "iceland",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/wAq50tSKzt",
      "expanded_url" : "http:\/\/instagram.com\/p\/rATy74hwot\/",
      "display_url" : "instagram.com\/p\/rATy74hwot\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493825706246541312",
  "text" : "handshakes that survive decades #reykjavik #iceland http:\/\/t.co\/wAq50tSKzt",
  "id" : 493825706246541312,
  "created_at" : "2014-07-28 18:29:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/lUCTeO1YIT",
      "expanded_url" : "http:\/\/instagram.com\/p\/rATAj1hwnO\/",
      "display_url" : "instagram.com\/p\/rATAj1hwnO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493823974183538688",
  "text" : "Headstone from the 1800s in Reykjavik. http:\/\/t.co\/lUCTeO1YIT",
  "id" : 493823974183538688,
  "created_at" : "2014-07-28 18:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493816431965118464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141708009, -21.9355308672 ]
  },
  "id_str" : "493816590249787393",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot only because you\u2019re already having a hard time leaving the sleeping bag when you\u2019re awake.",
  "id" : 493816590249787393,
  "in_reply_to_status_id" : 493816431965118464,
  "created_at" : "2014-07-28 17:53:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493815182192549888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141708009, -21.9355308672 ]
  },
  "id_str" : "493816132395339777",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot because I\u2019m traveling with the Shore Lore all the time. Ever wondered why I get into all the adventures when you\u2019re still asleep?",
  "id" : 493816132395339777,
  "in_reply_to_status_id" : 493815182192549888,
  "created_at" : "2014-07-28 17:51:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493814542536036352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141708009, -21.9355308672 ]
  },
  "id_str" : "493815768719818752",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente gl\u00FCckwunsch!",
  "id" : 493815768719818752,
  "in_reply_to_status_id" : 493814542536036352,
  "created_at" : "2014-07-28 17:50:28 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/LbayOqQQwK",
      "expanded_url" : "http:\/\/instagram.com\/p\/rAM6rBhwsj\/",
      "display_url" : "instagram.com\/p\/rAM6rBhwsj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493810578578632706",
  "text" : "making puppy eyes after having bitten me. http:\/\/t.co\/LbayOqQQwK",
  "id" : 493810578578632706,
  "created_at" : "2014-07-28 17:29:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/LIfJjPl3M2",
      "expanded_url" : "http:\/\/instagram.com\/p\/rAKm6qhwny\/",
      "display_url" : "instagram.com\/p\/rAKm6qhwny\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493805501151715329",
  "text" : "Moo! http:\/\/t.co\/LIfJjPl3M2",
  "id" : 493805501151715329,
  "created_at" : "2014-07-28 17:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493782372870287360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417076093, -21.9355480359 ]
  },
  "id_str" : "493782493431345152",
  "in_reply_to_user_id" : 2524949447,
  "text" : "@Blunicorn wobei ich f\u00FCr den rotten shark glaube ich eine Ausnahme machen werde. ;)",
  "id" : 493782493431345152,
  "in_reply_to_status_id" : 493782372870287360,
  "created_at" : "2014-07-28 15:38:15 +0000",
  "in_reply_to_screen_name" : "Blunicorn",
  "in_reply_to_user_id_str" : "2524949447",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493782063464849408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417076093, -21.9355480359 ]
  },
  "id_str" : "493782223049728000",
  "in_reply_to_user_id" : 2524949447,
  "text" : "@Blunicorn Ich bin Vegetarier, das wird also nicht passieren :)",
  "id" : 493782223049728000,
  "in_reply_to_status_id" : 493782063464849408,
  "created_at" : "2014-07-28 15:37:10 +0000",
  "in_reply_to_screen_name" : "Blunicorn",
  "in_reply_to_user_id_str" : "2524949447",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493781536182128641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417076093, -21.9355480359 ]
  },
  "id_str" : "493781738704076800",
  "in_reply_to_user_id" : 2524949447,
  "text" : "@Blunicorn not yet, but those are birds and not mammals ;)",
  "id" : 493781738704076800,
  "in_reply_to_status_id" : 493781536182128641,
  "created_at" : "2014-07-28 15:35:15 +0000",
  "in_reply_to_screen_name" : "Blunicorn",
  "in_reply_to_user_id_str" : "2524949447",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417056618, -21.9355224603 ]
  },
  "id_str" : "493778664711266305",
  "text" : "Today: Bitten by a dog. If I keep up that speed I will have been bitten by every kind of mammal living in Iceland at the end of the week.",
  "id" : 493778664711266305,
  "created_at" : "2014-07-28 15:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eberon",
      "screen_name" : "Eberon",
      "indices" : [ 0, 7 ],
      "id_str" : "14286532",
      "id" : 14286532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493768663015903233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417068884, -21.9355453809 ]
  },
  "id_str" : "493768813734002690",
  "in_reply_to_user_id" : 14286532,
  "text" : "@Eberon that\u2019s what you get for trusting google translate ;) thanks!",
  "id" : 493768813734002690,
  "in_reply_to_status_id" : 493768663015903233,
  "created_at" : "2014-07-28 14:43:53 +0000",
  "in_reply_to_screen_name" : "Eberon",
  "in_reply_to_user_id_str" : "14286532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/tGcGtXx5SP",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_5npXhwrC\/",
      "display_url" : "instagram.com\/p\/q_5npXhwrC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493768143974567936",
  "text" : "\u00C9g f\u00E9ll \u00ED \u00E1st me\u00F0 \u00FEessum hundur http:\/\/t.co\/tGcGtXx5SP",
  "id" : 493768143974567936,
  "created_at" : "2014-07-28 14:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XCKboYkCa2",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_5Jf-hwqU\/",
      "display_url" : "instagram.com\/p\/q_5Jf-hwqU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493767106916515840",
  "text" : "not so frightened rabbit http:\/\/t.co\/XCKboYkCa2",
  "id" : 493767106916515840,
  "created_at" : "2014-07-28 14:37:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "indices" : [ 0, 9 ],
      "id_str" : "1565839604",
      "id" : 1565839604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493725535931883520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1254456156, -21.7842571344 ]
  },
  "id_str" : "493726523342749696",
  "in_reply_to_user_id" : 1565839604,
  "text" : "@ATJCagan the whole western fjords are really nice. Most of my pictures over the last week were taken there.",
  "id" : 493726523342749696,
  "in_reply_to_status_id" : 493725535931883520,
  "created_at" : "2014-07-28 11:55:50 +0000",
  "in_reply_to_screen_name" : "ATJCagan",
  "in_reply_to_user_id_str" : "1565839604",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/493714089664086016\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/NLXZE7M8Q3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtoGWTCIcAAk3ln.jpg",
      "id_str" : "493714089286594560",
      "id" : 493714089286594560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtoGWTCIcAAk3ln.jpg",
      "sizes" : [ {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NLXZE7M8Q3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493713227487137793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417063091, -21.9355263448 ]
  },
  "id_str" : "493714089664086016",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot she doesn\u2019t look to excited. http:\/\/t.co\/NLXZE7M8Q3",
  "id" : 493714089664086016,
  "in_reply_to_status_id" : 493713227487137793,
  "created_at" : "2014-07-28 11:06:26 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 15, 21 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493709756348248064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141723797, -21.9355838783 ]
  },
  "id_str" : "493713162932617216",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju shall @Lobot do a tasting for you? :p",
  "id" : 493713162932617216,
  "in_reply_to_status_id" : 493709756348248064,
  "created_at" : "2014-07-28 11:02:45 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Cagan",
      "screen_name" : "ATJCagan",
      "indices" : [ 0, 9 ],
      "id_str" : "1565839604",
      "id" : 1565839604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493710207730860033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141723797, -21.9355838783 ]
  },
  "id_str" : "493711360556277760",
  "in_reply_to_user_id" : 1565839604,
  "text" : "@ATJCagan the Dynjandi\/Fjallfoss waterfalls in the western fjords of Iceland. You can even set up camp right below it.",
  "id" : 493711360556277760,
  "in_reply_to_status_id" : 493710207730860033,
  "created_at" : "2014-07-28 10:55:35 +0000",
  "in_reply_to_screen_name" : "ATJCagan",
  "in_reply_to_user_id_str" : "1565839604",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/493709676400623616\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/8daTYbasMD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtoCVaHIQAEoW88.jpg",
      "id_str" : "493709675960221697",
      "id" : 493709675960221697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtoCVaHIQAEoW88.jpg",
      "sizes" : [ {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/8daTYbasMD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417527231, -21.935698081 ]
  },
  "id_str" : "493709676400623616",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju look what we found for you! http:\/\/t.co\/8daTYbasMD",
  "id" : 493709676400623616,
  "created_at" : "2014-07-28 10:48:54 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493706165046767616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417016666, -21.9355040137 ]
  },
  "id_str" : "493706667067199488",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err best of luck!",
  "id" : 493706667067199488,
  "in_reply_to_status_id" : 493706165046767616,
  "created_at" : "2014-07-28 10:36:56 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/PBFrJGR4qT",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_Vc1Nhwsz\/",
      "display_url" : "instagram.com\/p\/q_Vc1Nhwsz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493688607186513920",
  "text" : "Another benefit of getting up really early: you get to experience things like this truly alone.\u2026 http:\/\/t.co\/PBFrJGR4qT",
  "id" : 493688607186513920,
  "created_at" : "2014-07-28 09:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ExfSY3PHX2",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_QzHFhwnh\/",
      "display_url" : "instagram.com\/p\/q_QzHFhwnh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1466439, -21.9394 ]
  },
  "id_str" : "493678377513910273",
  "text" : "\u2026just in time for mass (it was an accident, really!) @ Reykjav\u00EDk Cathedral http:\/\/t.co\/ExfSY3PHX2",
  "id" : 493678377513910273,
  "created_at" : "2014-07-28 08:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/6sjMuouOnH",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_QaU5hwm3\/",
      "display_url" : "instagram.com\/p\/q_QaU5hwm3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1466439, -21.9394 ]
  },
  "id_str" : "493677524912992256",
  "text" : "Getting up early\u2026 @ Reykjav\u00EDk Cathedral http:\/\/t.co\/6sjMuouOnH",
  "id" : 493677524912992256,
  "created_at" : "2014-07-28 08:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/SHRd5fezws",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_P0BfBwmD\/",
      "display_url" : "instagram.com\/p\/q_P0BfBwmD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493676209574666240",
  "text" : "Bl\u00F8d Lykke http:\/\/t.co\/SHRd5fezws",
  "id" : 493676209574666240,
  "created_at" : "2014-07-28 08:35:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/wdOGoR5AIw",
      "expanded_url" : "http:\/\/instagram.com\/p\/q_Oq5Jhwkp\/",
      "display_url" : "instagram.com\/p\/q_Oq5Jhwkp\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.143174824, -21.926598618 ]
  },
  "id_str" : "493673696297771008",
  "text" : "Human strays get coffee from the windowsill, other animals porridge @ 101 Reykjavik http:\/\/t.co\/wdOGoR5AIw",
  "id" : 493673696297771008,
  "created_at" : "2014-07-28 08:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 10, 19 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493669052423081984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417025624, -21.9354640964 ]
  },
  "id_str" : "493669633921384448",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @thorgnyr the only person who\u2019s neither in the picture nor did take it. But I came in second iirc.",
  "id" : 493669633921384448,
  "in_reply_to_status_id" : 493669052423081984,
  "created_at" : "2014-07-28 08:09:47 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/uZ94lF9sin",
      "expanded_url" : "http:\/\/instagram.com\/p\/q-Y8fXhwvE\/",
      "display_url" : "instagram.com\/p\/q-Y8fXhwvE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493555553533460480",
  "text" : "Walking to Drangaj\u00F6kull #latergram http:\/\/t.co\/uZ94lF9sin",
  "id" : 493555553533460480,
  "created_at" : "2014-07-28 00:36:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493551906112172032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417137483, -21.9355419784 ]
  },
  "id_str" : "493552286141280256",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDCC9",
  "id" : 493552286141280256,
  "in_reply_to_status_id" : 493551906112172032,
  "created_at" : "2014-07-28 00:23:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417137483, -21.9355419784 ]
  },
  "id_str" : "493551257463037952",
  "text" : "Keine Emoji G\u00FCrkchen. Ich prangere hart.",
  "id" : 493551257463037952,
  "created_at" : "2014-07-28 00:19:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493550068230656001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417137483, -21.9355419784 ]
  },
  "id_str" : "493551098813485056",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot \uD83C\uDF5D\uD83C\uDF5C\uD83C\uDF6B",
  "id" : 493551098813485056,
  "in_reply_to_status_id" : 493550068230656001,
  "created_at" : "2014-07-28 00:18:46 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 56, 62 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493548932866138112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141702723, -21.9354627911 ]
  },
  "id_str" : "493549334244651008",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj being a biologist I already have an excuse, but @Lobot is still looking for a justification.",
  "id" : 493549334244651008,
  "in_reply_to_status_id" : 493548932866138112,
  "created_at" : "2014-07-28 00:11:45 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417109171, -21.9356183474 ]
  },
  "id_str" : "493547742426591232",
  "text" : "\u00ABThat it becomes socially accepted to talk about poop at the dinner table is the reason I want children.\u00BB",
  "id" : 493547742426591232,
  "created_at" : "2014-07-28 00:05:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 71, 80 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 101, 110 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thorgnyr\/status\/493526976603631616\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Kl7b9foT00",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtlcKEyCUAAfFrv.jpg",
      "id_str" : "493526962325835776",
      "id" : 493526962325835776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtlcKEyCUAAfFrv.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/Kl7b9foT00"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417100138, -21.9355535078 ]
  },
  "id_str" : "493528230725709824",
  "text" : "This is my 'being strategic'-face when I've no idea what I'm doing. RT @thorgnyr: Growl! The hatred! @Senficon http:\/\/t.co\/Kl7b9foT00",
  "id" : 493528230725709824,
  "created_at" : "2014-07-27 22:47:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493489514950963200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417711782, -21.935665249 ]
  },
  "id_str" : "493489926068248576",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr you make it sound like a Star Wars-quote: \u201Cuse the condom, luke!\u201D",
  "id" : 493489926068248576,
  "in_reply_to_status_id" : 493489514950963200,
  "created_at" : "2014-07-27 20:15:41 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417069848, -21.935530314 ]
  },
  "id_str" : "493472373908447233",
  "text" : "\u00ABOffenbach, Ukraine, Tel Aviv. Na du hast dir ja was vorgenommen f\u00FCr den August.\u00BB",
  "id" : 493472373908447233,
  "created_at" : "2014-07-27 19:05:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/jgLCdnrNhO",
      "expanded_url" : "http:\/\/instagram.com\/p\/q9vdu-hwhZ\/",
      "display_url" : "instagram.com\/p\/q9vdu-hwhZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.147467935, -21.93806434 ]
  },
  "id_str" : "493464337336795136",
  "text" : "IN THE NAME OF PROGRESS @ City Center, Reykjavik, Iceland http:\/\/t.co\/jgLCdnrNhO",
  "id" : 493464337336795136,
  "created_at" : "2014-07-27 18:34:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493450666330054656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1443135627, -21.9335153042 ]
  },
  "id_str" : "493452364138164224",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr I didn't ask for it being native. I just said there are bats in Iceland (occasionally).",
  "id" : 493452364138164224,
  "in_reply_to_status_id" : 493450666330054656,
  "created_at" : "2014-07-27 17:46:26 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 8, 17 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/L3pOtcECTw",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC2873759\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417082526, -21.9355445064 ]
  },
  "id_str" : "493437602008408065",
  "text" : "I guess @thorgnyr and I will have to continue the discussion on whether there are bats in Iceland or not. http:\/\/t.co\/L3pOtcECTw",
  "id" : 493437602008408065,
  "created_at" : "2014-07-27 16:47:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/7rnaPSRdo0",
      "expanded_url" : "http:\/\/instagram.com\/p\/q9ho6mhwlo\/",
      "display_url" : "instagram.com\/p\/q9ho6mhwlo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1333, -21.9333 ]
  },
  "id_str" : "493433936714813440",
  "text" : "the anarchists guide to slowing down traffic @ Reykjav\u00EDk, Iceland http:\/\/t.co\/7rnaPSRdo0",
  "id" : 493433936714813440,
  "created_at" : "2014-07-27 16:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/uY3Ca0Tzoq",
      "expanded_url" : "http:\/\/instagram.com\/p\/q9gtkphwj2\/",
      "display_url" : "instagram.com\/p\/q9gtkphwj2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493431895896891392",
  "text" : "F\u00FCsseln http:\/\/t.co\/uY3Ca0Tzoq",
  "id" : 493431895896891392,
  "created_at" : "2014-07-27 16:25:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/FieuKywGHl",
      "expanded_url" : "http:\/\/instagram.com\/p\/q9U2EUhwsE\/",
      "display_url" : "instagram.com\/p\/q9U2EUhwsE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.142772253, -21.932398778 ]
  },
  "id_str" : "493405799608483840",
  "text" : "selling coffee from the windowsill @ Puffin Coffee http:\/\/t.co\/FieuKywGHl",
  "id" : 493405799608483840,
  "created_at" : "2014-07-27 14:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417056718, -21.9355108651 ]
  },
  "id_str" : "493345413932793857",
  "text" : "Traveling with more batteries and charging cables than socks. That\u2019s why I have wet feet but can tweet about it.",
  "id" : 493345413932793857,
  "created_at" : "2014-07-27 10:41:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/xEGA258GN8",
      "expanded_url" : "http:\/\/instagram.com\/p\/q8x7l5hwhN\/",
      "display_url" : "instagram.com\/p\/q8x7l5hwhN\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.148145755, -21.941286377 ]
  },
  "id_str" : "493329023263838208",
  "text" : "After day 7 on gravel roads @ Reykjavik Harbour http:\/\/t.co\/xEGA258GN8",
  "id" : 493329023263838208,
  "created_at" : "2014-07-27 09:36:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/qfJBbYhzCJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/q75Okdhwl9\/",
      "display_url" : "instagram.com\/p\/q75Okdhwl9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493204330892505088",
  "text" : "\u00DEingvallavatn http:\/\/t.co\/qfJBbYhzCJ",
  "id" : 493204330892505088,
  "created_at" : "2014-07-27 01:20:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493129782406955008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417053225, -21.9354833585 ]
  },
  "id_str" : "493129944181243904",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr cool, great, then we will probably be around as well.",
  "id" : 493129944181243904,
  "in_reply_to_status_id" : 493129782406955008,
  "created_at" : "2014-07-26 20:25:15 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/pWObTJCvyJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/q7SVU1BwgT\/",
      "display_url" : "instagram.com\/p\/q7SVU1BwgT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493118801295462400",
  "text" : "Standard tourist trap #2: Gullfoss http:\/\/t.co\/pWObTJCvyJ",
  "id" : 493118801295462400,
  "created_at" : "2014-07-26 19:40:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/hKGA7JTVFx",
      "expanded_url" : "http:\/\/instagram.com\/p\/q7Rt9NhwvN\/",
      "display_url" : "instagram.com\/p\/q7Rt9NhwvN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493117449386991616",
  "text" : "Standard tourist trap #1: Geysir http:\/\/t.co\/hKGA7JTVFx",
  "id" : 493117449386991616,
  "created_at" : "2014-07-26 19:35:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/cikRTquQ6F",
      "expanded_url" : "http:\/\/instagram.com\/p\/q7RYv9hwuv\/",
      "display_url" : "instagram.com\/p\/q7RYv9hwuv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493116720970604546",
  "text" : "Also at the roadside, just next to the crosses. http:\/\/t.co\/cikRTquQ6F",
  "id" : 493116720970604546,
  "created_at" : "2014-07-26 19:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Kp5eJ2VYAU",
      "expanded_url" : "http:\/\/instagram.com\/p\/q7RFSChwuM\/",
      "display_url" : "instagram.com\/p\/q7RFSChwuM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "493116052046237697",
  "text" : "Next to the road on the way back to Reykjavik http:\/\/t.co\/Kp5eJ2VYAU",
  "id" : 493116052046237697,
  "created_at" : "2014-07-26 19:30:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493115067853205504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417438654, -21.9357042193 ]
  },
  "id_str" : "493115231305203712",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr yeah, we saw that you were here shortly. You will be back late in the evening?",
  "id" : 493115231305203712,
  "in_reply_to_status_id" : 493115067853205504,
  "created_at" : "2014-07-26 19:26:47 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 97, 106 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417081861, -21.935498477 ]
  },
  "id_str" : "493112966192308225",
  "text" : "And made it back to Reykjavik. Even though I was allowed to drive the fun backcountry roads. \/cc @thorgnyr",
  "id" : 493112966192308225,
  "created_at" : "2014-07-26 19:17:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.3254647202, -20.1294784575 ]
  },
  "id_str" : "493077215836659712",
  "text" : "\u00ABIch dachte es w\u00E4re Vulkanalarm. Aber es hat nur jemand geg\u00E4hnt.\u00BB",
  "id" : 493077215836659712,
  "created_at" : "2014-07-26 16:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 9, 18 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 19, 25 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 26, 34 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493010517850869760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.2111481447, -21.2599058915 ]
  },
  "id_str" : "493020329795919874",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @Ragetina @Lobot @rantleb whatever, den Teil der Convo kann ich nicht lesen. K\u00F6nnen wir das auf einem anderen Kanal machen?",
  "id" : 493020329795919874,
  "in_reply_to_status_id" : 493010517850869760,
  "created_at" : "2014-07-26 13:09:41 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 16, 25 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 26, 34 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "493001548478578688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.5413219469, -21.908831257 ]
  },
  "id_str" : "493002511780163584",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @Lobot @Ragetina @rantleb wenn das besorgen bis zum 04. warten kann ja, sonst halt nein.",
  "id" : 493002511780163584,
  "in_reply_to_status_id" : 493001548478578688,
  "created_at" : "2014-07-26 11:58:53 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492982202775633920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.5410377707, -21.9089133244 ]
  },
  "id_str" : "492995554277093376",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 don't you see the large collection of trees in the background? For Iceland that's huge!",
  "id" : 492995554277093376,
  "in_reply_to_status_id" : 492982202775633920,
  "created_at" : "2014-07-26 11:31:14 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tRXFIFpiYo",
      "expanded_url" : "http:\/\/instagram.com\/p\/q6PiymhwkG\/",
      "display_url" : "instagram.com\/p\/q6PiymhwkG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492971930312388608",
  "text" : "Camping next to one of Iceland's many famous forests. http:\/\/t.co\/tRXFIFpiYo",
  "id" : 492971930312388608,
  "created_at" : "2014-07-26 09:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Istar Nil 0x47617921",
      "screen_name" : "istar_nil",
      "indices" : [ 0, 10 ],
      "id_str" : "314234855",
      "id" : 314234855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492834126483816450",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.2464219335, -21.8000384031 ]
  },
  "id_str" : "492963669366808576",
  "in_reply_to_user_id" : 314234855,
  "text" : "@istar_nil oh, thanks a lot :)",
  "id" : 492963669366808576,
  "in_reply_to_status_id" : 492834126483816450,
  "created_at" : "2014-07-26 09:24:32 +0000",
  "in_reply_to_screen_name" : "istar_nil",
  "in_reply_to_user_id_str" : "314234855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/iW6mO0h0Ab",
      "expanded_url" : "http:\/\/instagram.com\/p\/q5L06shwhw\/",
      "display_url" : "instagram.com\/p\/q5L06shwhw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492823018511806464",
  "text" : "Next humans: 50+ km away http:\/\/t.co\/iW6mO0h0Ab",
  "id" : 492823018511806464,
  "created_at" : "2014-07-26 00:05:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/i7lGOjs9O7",
      "expanded_url" : "http:\/\/instagram.com\/p\/q5AbhbhwvH\/",
      "display_url" : "instagram.com\/p\/q5AbhbhwvH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492797956886908929",
  "text" : "On the way to Drangaj\u00F6kull http:\/\/t.co\/i7lGOjs9O7",
  "id" : 492797956886908929,
  "created_at" : "2014-07-25 22:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Cl6pYknYSO",
      "expanded_url" : "http:\/\/instagram.com\/p\/q49lsjBwqt\/",
      "display_url" : "instagram.com\/p\/q49lsjBwqt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492791709496258560",
  "text" : "Drangaj\u00F6kull http:\/\/t.co\/Cl6pYknYSO",
  "id" : 492791709496258560,
  "created_at" : "2014-07-25 22:01:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Lorenz",
      "screen_name" : "mitZett",
      "indices" : [ 0, 8 ],
      "id_str" : "8517622",
      "id" : 8517622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492620586301284352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8427113295, -22.6748091169 ]
  },
  "id_str" : "492654210908160000",
  "in_reply_to_user_id" : 8517622,
  "text" : "@mitZett Iceland's west fjords.",
  "id" : 492654210908160000,
  "in_reply_to_status_id" : 492620586301284352,
  "created_at" : "2014-07-25 12:54:51 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/QzpsPfwtPt",
      "expanded_url" : "http:\/\/instagram.com\/p\/q3pg4ihwr2\/",
      "display_url" : "instagram.com\/p\/q3pg4ihwr2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492606826777542656",
  "text" : "Lost http:\/\/t.co\/QzpsPfwtPt",
  "id" : 492606826777542656,
  "created_at" : "2014-07-25 09:46:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492569104298287104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8435230568, -22.6780584573 ]
  },
  "id_str" : "492594567313883137",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk thanks, will do. Trying not to die on a glacier today. ;)",
  "id" : 492594567313883137,
  "in_reply_to_status_id" : 492569104298287104,
  "created_at" : "2014-07-25 08:57:51 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 38, 47 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492564974724599809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8433561301, -22.677087639 ]
  },
  "id_str" : "492568394202624000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer closer to Frankfurt and @Senficon and I are taking in more people.",
  "id" : 492568394202624000,
  "in_reply_to_status_id" : 492564974724599809,
  "created_at" : "2014-07-25 07:13:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/0QDN5U8Hjz",
      "expanded_url" : "http:\/\/instagram.com\/p\/q3X2UhhwuT\/",
      "display_url" : "instagram.com\/p\/q3X2UhhwuT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492567979918635008",
  "text" : "Cuddled a wild arctic fox: \u2714\uFE0FBitten by a wild, possibly rabid, arctic fox: \u2714\uFE0F http:\/\/t.co\/0QDN5U8Hjz",
  "id" : 492567979918635008,
  "created_at" : "2014-07-25 07:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8434059242, -22.6772212061 ]
  },
  "id_str" : "492564838527541248",
  "text" : "Doing the 'soon having a lease agreement for a new flat'-dance. Naked. In a hot spring.",
  "id" : 492564838527541248,
  "created_at" : "2014-07-25 06:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492560851640254464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.843333582, -22.6771458689 ]
  },
  "id_str" : "492563862508826625",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk touring western fjords &amp; Sn\u00E6fell. Visited the artic fox centre but this one was in the wild in wherever the geotag to this says. :)",
  "id" : 492563862508826625,
  "in_reply_to_status_id" : 492560851640254464,
  "created_at" : "2014-07-25 06:55:50 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9SNhvnT001",
      "expanded_url" : "http:\/\/instagram.com\/p\/q3Vd3Bhwso\/",
      "display_url" : "instagram.com\/p\/q3Vd3Bhwso\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492562741669158912",
  "text" : "The next generic Iceland photo. But they told me you are not allowed to leave Iceland without a puffin\u2026 http:\/\/t.co\/9SNhvnT001",
  "id" : 492562741669158912,
  "created_at" : "2014-07-25 06:51:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492560335107555328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8434971354, -22.6779330802 ]
  },
  "id_str" : "492560539487571968",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk yes, that's why I will miss your hack day. But send greetings to the rest of the team. :)",
  "id" : 492560539487571968,
  "in_reply_to_status_id" : 492560335107555328,
  "created_at" : "2014-07-25 06:42:38 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8420818067, -22.6753800083 ]
  },
  "id_str" : "492559866855444481",
  "text" : "\u00ABPlease put your shoes into your tent. Otherwise the baby arctic fox who is roaming the campground will steal them.\u00BB",
  "id" : 492559866855444481,
  "created_at" : "2014-07-25 06:39:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8420462255, -22.6754593849 ]
  },
  "id_str" : "492456365953396736",
  "text" : "\u00ABIst der dick! Tut das nicht weh?\u00BB \u2014 \u00ABDas h\u00F6re ich \u00F6fter, aber du redest von meinem Kn\u00F6chel, oder?\u00BB",
  "id" : 492456365953396736,
  "created_at" : "2014-07-24 23:48:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/HBitRhAz1P",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2ibdZBwip\/",
      "display_url" : "instagram.com\/p\/q2ibdZBwip\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492450509870354432",
  "text" : "Landlocked T[wo]o http:\/\/t.co\/HBitRhAz1P",
  "id" : 492450509870354432,
  "created_at" : "2014-07-24 23:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8436168414, -22.6783224083 ]
  },
  "id_str" : "492425556135514113",
  "text" : "\u00ABDas Internet in meiner hei\u00DFen Quelle geht nicht ordentlich. Ich kann so nicht arbeiten!\u00BB",
  "id" : 492425556135514113,
  "created_at" : "2014-07-24 21:46:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/L8u5Gu2gJK",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2VV-Yhwsr\/",
      "display_url" : "instagram.com\/p\/q2VV-Yhwsr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492421734776053761",
  "text" : "\u00ABWer fr\u00FCh genug aufsteht kann auch nackt in den Hot Spring!\u00BB http:\/\/t.co\/L8u5Gu2gJK",
  "id" : 492421734776053761,
  "created_at" : "2014-07-24 21:31:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/XpnJDxXtSa",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2UBPBhwqr\/",
      "display_url" : "instagram.com\/p\/q2UBPBhwqr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492418822414950400",
  "text" : "Ok, the flotsam was pretty cool as well (in the background, not foreground) http:\/\/t.co\/XpnJDxXtSa",
  "id" : 492418822414950400,
  "created_at" : "2014-07-24 21:19:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/jlYHtVsJWK",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2TK7ThwpF\/",
      "display_url" : "instagram.com\/p\/q2TK7ThwpF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492416955941662720",
  "text" : "Much more interesting than the flotsam at the same beach. http:\/\/t.co\/jlYHtVsJWK",
  "id" : 492416955941662720,
  "created_at" : "2014-07-24 21:12:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/GJtRtaxlmr",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2RH9IBwlk\/",
      "display_url" : "instagram.com\/p\/q2RH9IBwlk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492412456166113280",
  "text" : "On the road (or so it says) http:\/\/t.co\/GJtRtaxlmr",
  "id" : 492412456166113280,
  "created_at" : "2014-07-24 20:54:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/gQyQ8UcL93",
      "expanded_url" : "http:\/\/instagram.com\/p\/q2P77jBwjk\/",
      "display_url" : "instagram.com\/p\/q2P77jBwjk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492409844272340992",
  "text" : "Standing by the roadside http:\/\/t.co\/gQyQ8UcL93",
  "id" : 492409844272340992,
  "created_at" : "2014-07-24 20:43:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8420902724, -22.6753554493 ]
  },
  "id_str" : "492401413964976128",
  "text" : "\u00ABEin Hummus reicht f\u00FCr vier von diesen Kringeln. Das war schon immer so.\u00BB \u2014 \u00ABAh, das uralte Gesetz der Stra\u00DFe!\u00BB",
  "id" : 492401413964976128,
  "created_at" : "2014-07-24 20:10:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8433618488, -22.6771057246 ]
  },
  "id_str" : "492401141163245568",
  "text" : "\u00ABBis wir bei der hei\u00DFen Quelle sind dauert es noch ein bisschen, so in 2-3 Fjorden.\u00BB \u2014 \u00ABAh, das alte Rein-Raus-Spiel bis dahin.\u00BB",
  "id" : 492401141163245568,
  "created_at" : "2014-07-24 20:09:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/jgdiuIVhMa",
      "expanded_url" : "http:\/\/instagram.com\/p\/q193qYhwkc\/",
      "display_url" : "instagram.com\/p\/q193qYhwkc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492370115006976000",
  "text" : "Turtles all the way down http:\/\/t.co\/jgdiuIVhMa",
  "id" : 492370115006976000,
  "created_at" : "2014-07-24 18:05:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/RbfPIA79q9",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1ojhMBwgk\/",
      "display_url" : "instagram.com\/p\/q1ojhMBwgk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492323242427043841",
  "text" : "Landlocked http:\/\/t.co\/RbfPIA79q9",
  "id" : 492323242427043841,
  "created_at" : "2014-07-24 14:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 66.0744072078, -23.1235592813 ]
  },
  "id_str" : "492301614397812738",
  "text" : "For over a year I worked on non-biting midges and never met a single one. In Iceland chironomids are trying to crawl into my eyes and ears.",
  "id" : 492301614397812738,
  "created_at" : "2014-07-24 13:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bucketlist",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/TfqyAKF1Eo",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1RTqeBwiV\/",
      "display_url" : "instagram.com\/p\/q1RTqeBwiV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492272120328888320",
  "text" : "Scaling a glacier in Vibrams: \u2714\uFE0F #bucketlist http:\/\/t.co\/TfqyAKF1Eo",
  "id" : 492272120328888320,
  "created_at" : "2014-07-24 11:36:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492266176719126528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.87698353, -23.48984732 ]
  },
  "id_str" : "492269640278888448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot still preferable to being a pirate!",
  "id" : 492269640278888448,
  "in_reply_to_status_id" : 492266176719126528,
  "created_at" : "2014-07-24 11:26:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/zwnmrpxso3",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1PYXPhwgm\/",
      "display_url" : "instagram.com\/p\/q1PYXPhwgm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492267884454752256",
  "text" : "The things you find on Sn\u00E6fellsj\u00F6kull http:\/\/t.co\/zwnmrpxso3",
  "id" : 492267884454752256,
  "created_at" : "2014-07-24 11:19:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/8IAUi37rTW",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1OZN2Bwvz\/",
      "display_url" : "instagram.com\/p\/q1OZN2Bwvz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492265713751846912",
  "text" : "\u00ABAre you now happy that my driving teacher used to drive rallies?\u00BB http:\/\/t.co\/8IAUi37rTW",
  "id" : 492265713751846912,
  "created_at" : "2014-07-24 11:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/iTRwXs8uLm",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1M6t2BwuL\/",
      "display_url" : "instagram.com\/p\/q1M6t2BwuL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492262467092119553",
  "text" : "Cave exploration for beginners. http:\/\/t.co\/iTRwXs8uLm",
  "id" : 492262467092119553,
  "created_at" : "2014-07-24 10:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/EeCWyb56kp",
      "expanded_url" : "http:\/\/instagram.com\/p\/q1MPT8Bwtg\/",
      "display_url" : "instagram.com\/p\/q1MPT8Bwtg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492260976238919680",
  "text" : "Sn\u00E6fellsj\u00F6kull http:\/\/t.co\/EeCWyb56kp",
  "id" : 492260976238919680,
  "created_at" : "2014-07-24 10:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492234508209782784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.8769835308, -23.4898473413 ]
  },
  "id_str" : "492259602898378752",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a thanks. Will do. :)",
  "id" : 492259602898378752,
  "in_reply_to_status_id" : 492234508209782784,
  "created_at" : "2014-07-24 10:46:49 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492219126333849600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.7360104984, -23.2086226903 ]
  },
  "id_str" : "492226678337593344",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich na dann habe ich doch einen perfekten Grund.",
  "id" : 492226678337593344,
  "in_reply_to_status_id" : 492219126333849600,
  "created_at" : "2014-07-24 08:35:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.7360430621, -23.2082673814 ]
  },
  "id_str" : "492215006080286721",
  "text" : "\u00ABDu reist doch nur zum Ficken in Krisengebiete!\u00BB \u2014 \u00ABMan reiche mir meinen Blauhelm und meine Blausiegel!\u00BB",
  "id" : 492215006080286721,
  "created_at" : "2014-07-24 07:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/RQvJqP50CM",
      "expanded_url" : "http:\/\/instagram.com\/p\/q0tx_dBwjO\/",
      "display_url" : "instagram.com\/p\/q0tx_dBwjO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492193997268721664",
  "text" : "along the roadside http:\/\/t.co\/RQvJqP50CM",
  "id" : 492193997268721664,
  "created_at" : "2014-07-24 06:26:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/oLJnzn8Okj",
      "expanded_url" : "http:\/\/instagram.com\/p\/q0s1J6Bwig\/",
      "display_url" : "instagram.com\/p\/q0s1J6Bwig\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492191908089712640",
  "text" : "there are worse views to be have right from your tent http:\/\/t.co\/oLJnzn8Okj",
  "id" : 492191908089712640,
  "created_at" : "2014-07-24 06:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/JQKwz326v9",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzygswhwv-\/",
      "display_url" : "instagram.com\/p\/qzygswhwv-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.736530605, -23.208973642 ]
  },
  "id_str" : "492063662207553536",
  "text" : "Day 3 on gravel roads. @ Dynjandi http:\/\/t.co\/JQKwz326v9",
  "id" : 492063662207553536,
  "created_at" : "2014-07-23 21:48:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/9GgUN1Nqrt",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzlqR5hwqI\/",
      "display_url" : "instagram.com\/p\/qzlqR5hwqI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "492035404711747585",
  "text" : "1am at around 65\u00B0N http:\/\/t.co\/9GgUN1Nqrt",
  "id" : 492035404711747585,
  "created_at" : "2014-07-23 19:55:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stream-Caf\u00E9",
      "screen_name" : "l1vestream",
      "indices" : [ 0, 11 ],
      "id_str" : "3398451658",
      "id" : 3398451658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492027903505625088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.7361220616, -23.2084014081 ]
  },
  "id_str" : "492030426564001792",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@l1vestream ich sag mal zaghaft ja, schreib mir mal eine Mail damit ich nach dem 04.08. reinschaue und dran denke.",
  "id" : 492030426564001792,
  "in_reply_to_status_id" : 492027903505625088,
  "created_at" : "2014-07-23 19:36:09 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stream-Caf\u00E9",
      "screen_name" : "l1vestream",
      "indices" : [ 0, 11 ],
      "id_str" : "3398451658",
      "id" : 3398451658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492024277374619648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.7357263938, -23.2076275908 ]
  },
  "id_str" : "492027695471931392",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@l1vestream Kalender sagt Zeit habe ich. Umfang und um was soll es gehen?",
  "id" : 492027695471931392,
  "in_reply_to_status_id" : 492024277374619648,
  "created_at" : "2014-07-23 19:25:18 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 7, 20 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.6863758414, -23.5971000221 ]
  },
  "id_str" : "491981189797138432",
  "text" : "Thanks @SvavarKnutur, for all the nice recommendations of what to visit in Iceland!",
  "id" : 491981189797138432,
  "created_at" : "2014-07-23 16:20:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/BTna4BCpvk",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzFEIcBwiZ\/",
      "display_url" : "instagram.com\/p\/qzFEIcBwiZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491963724014841856",
  "text" : "Somewhere on Sn\u00E6fellsnes II http:\/\/t.co\/BTna4BCpvk",
  "id" : 491963724014841856,
  "created_at" : "2014-07-23 15:11:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/NNJ2dBZyh7",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzEhT-Bwhc\/",
      "display_url" : "instagram.com\/p\/qzEhT-Bwhc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491962526914326528",
  "text" : "Somewhere on Sn\u00E6fellsnes http:\/\/t.co\/NNJ2dBZyh7",
  "id" : 491962526914326528,
  "created_at" : "2014-07-23 15:06:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9TdkWXMwlh",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzDbC6Bwv-\/",
      "display_url" : "instagram.com\/p\/qzDbC6Bwv-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491960113037852672",
  "text" : "\u00ABNa, ist dir der Ring auf der falschen Seite des Vulkans runtergefallen?\u00BB http:\/\/t.co\/9TdkWXMwlh",
  "id" : 491960113037852672,
  "created_at" : "2014-07-23 14:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/iCQDZptoQm",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzC-FIhwvN\/",
      "display_url" : "instagram.com\/p\/qzC-FIhwvN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491959118245011456",
  "text" : "\u00ABHier ist es so sch\u00F6n, ich muss gleich kotzen!\u00BB http:\/\/t.co\/iCQDZptoQm",
  "id" : 491959118245011456,
  "created_at" : "2014-07-23 14:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arewedoingthisright",
      "indices" : [ 43, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491556127059238912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.59672875, -23.9902984 ]
  },
  "id_str" : "491956335798681601",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr that\u2019s why we don\u2019t follow them! #arewedoingthisright?",
  "id" : 491956335798681601,
  "in_reply_to_status_id" : 491556127059238912,
  "created_at" : "2014-07-23 14:41:45 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/8xjsDGhfDQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/qzAFFshwqY\/",
      "display_url" : "instagram.com\/p\/qzAFFshwqY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491952761442168832",
  "text" : "Hiking with a biologist may take slightly longer as you have to stop every few meters to look at dirt.\u2026 http:\/\/t.co\/8xjsDGhfDQ",
  "id" : 491952761442168832,
  "created_at" : "2014-07-23 14:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/KGc3CUb7dO",
      "expanded_url" : "http:\/\/instagram.com\/p\/qy_hVYhwpf\/",
      "display_url" : "instagram.com\/p\/qy_hVYhwpf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491951532632711168",
  "text" : "If all you have are volcanos everything looks like it needs more molten lava. http:\/\/t.co\/KGc3CUb7dO",
  "id" : 491951532632711168,
  "created_at" : "2014-07-23 14:22:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/D3o4tSgwUC",
      "expanded_url" : "http:\/\/instagram.com\/p\/qy9Qorhwlt\/",
      "display_url" : "instagram.com\/p\/qy9Qorhwlt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491946561736175616",
  "text" : "Near Eldborg #latergram http:\/\/t.co\/D3o4tSgwUC",
  "id" : 491946561736175616,
  "created_at" : "2014-07-23 14:02:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/BuPH4a9eA9",
      "expanded_url" : "http:\/\/instagram.com\/p\/qyYt5YhwtT\/",
      "display_url" : "instagram.com\/p\/qyYt5YhwtT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491866203216822272",
  "text" : "Akrafjall #latergram http:\/\/t.co\/BuPH4a9eA9",
  "id" : 491866203216822272,
  "created_at" : "2014-07-23 08:43:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491833283345657856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.5769208447, -23.1732903701 ]
  },
  "id_str" : "491834072898211840",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon if it was for a inn, right now I'm on a campground where the next human settlement is 120+ km in either direction. ;)",
  "id" : 491834072898211840,
  "in_reply_to_status_id" : 491833283345657856,
  "created_at" : "2014-07-23 06:35:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/XF2QtxBVXu",
      "expanded_url" : "http:\/\/instagram.com\/p\/qyJ-o-hwhO\/",
      "display_url" : "instagram.com\/p\/qyJ-o-hwhO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491833792202801152",
  "text" : "Not what I expected when they told me about all the colorful rocks. #latergram http:\/\/t.co\/XF2QtxBVXu",
  "id" : 491833792202801152,
  "created_at" : "2014-07-23 06:34:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "491829937268334592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.5768482993, -23.1733777933 ]
  },
  "id_str" : "491830431541895168",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon won't work. We're a two days car ride over gravel roads away from there :p",
  "id" : 491830431541895168,
  "in_reply_to_status_id" : 491829937268334592,
  "created_at" : "2014-07-23 06:21:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 26, 35 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/OBYqW3ldFb",
      "expanded_url" : "http:\/\/instagram.com\/p\/qyIBaeBwvF\/",
      "display_url" : "instagram.com\/p\/qyIBaeBwvF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.5768482993, -23.1733777933 ]
  },
  "id_str" : "491829607260504064",
  "text" : "May we move here instead, @Senficon http:\/\/t.co\/OBYqW3ldFb #latergram",
  "id" : 491829607260504064,
  "created_at" : "2014-07-23 06:18:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 65.5768534123, -23.1735259854 ]
  },
  "id_str" : "491707619057618944",
  "text" : "After nearly 10 years in academia I had to travel close to 3000 km to an island in the middle of the Atlantic to have my first Ramen.",
  "id" : 491707619057618944,
  "created_at" : "2014-07-22 22:13:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/vVKkWLpRH5",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Longwave_radio_mast_Hellissandur",
      "display_url" : "en.wikipedia.org\/wiki\/Longwave_\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.9113777839, -23.889945522 ]
  },
  "id_str" : "491354747983912960",
  "text" : "Tonight we will wear tinfoil hats and sleep under this thing http:\/\/t.co\/vVKkWLpRH5",
  "id" : 491354747983912960,
  "created_at" : "2014-07-21 22:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417117081, -21.9355184429 ]
  },
  "id_str" : "490850480835538944",
  "text" : "\u00ABKann es sein das wir beim Eis essen \u00E4hnliche Ger\u00E4usche machen wie beim Sex?\u00BB \u2014 \u00AB'Oh Gott, ja', 'Gib es mir tiefer' und 'Du tropfst'?\u00BB",
  "id" : 490850480835538944,
  "created_at" : "2014-07-20 13:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490784203588796416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417149812, -21.9355350662 ]
  },
  "id_str" : "490787215300386816",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot surprise!",
  "id" : 490787215300386816,
  "in_reply_to_status_id" : 490784203588796416,
  "created_at" : "2014-07-20 09:16:05 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/fm8jCn0SSl",
      "expanded_url" : "http:\/\/www.theawl.com\/2014\/05\/the-life-and-times-of-%C2%AF_%E3%83%84_%C2%AF",
      "display_url" : "theawl.com\/2014\/05\/the-li\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.141712, -21.935529 ]
  },
  "id_str" : "490773643547672576",
  "text" : "The Life and Times of \u00AF\\_(\u30C4)_\/\u00AF http:\/\/t.co\/fm8jCn0SSl",
  "id" : 490773643547672576,
  "created_at" : "2014-07-20 08:22:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 3, 14 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/bUAZMdHJlj",
      "expanded_url" : "http:\/\/dlvr.it\/6N2WGK",
      "display_url" : "dlvr.it\/6N2WGK"
    } ]
  },
  "geo" : { },
  "id_str" : "490772331850387456",
  "text" : "RT @TimHarford: This would be a regrettable tattoo http:\/\/t.co\/bUAZMdHJlj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/bUAZMdHJlj",
        "expanded_url" : "http:\/\/dlvr.it\/6N2WGK",
        "display_url" : "dlvr.it\/6N2WGK"
      } ]
    },
    "geo" : { },
    "id_str" : "490770726975057921",
    "text" : "This would be a regrettable tattoo http:\/\/t.co\/bUAZMdHJlj",
    "id" : 490770726975057921,
    "created_at" : "2014-07-20 08:10:34 +0000",
    "user" : {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "protected" : false,
      "id_str" : "32493647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1338890256\/Harford_Cropped_normal.JPG",
      "id" : 32493647,
      "verified" : true
    }
  },
  "id" : 490772331850387456,
  "created_at" : "2014-07-20 08:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1457487587, -21.9191569823 ]
  },
  "id_str" : "490615808159416320",
  "text" : "\u00ABVoll geil das Ding, ist das Lava?!\u00BB \u2014 \u00ABVoll Lava wie du abgehst!\u00BB",
  "id" : 490615808159416320,
  "created_at" : "2014-07-19 21:54:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/NKo0VZxQdc",
      "expanded_url" : "http:\/\/instagram.com\/p\/qpKcbfBws4\/",
      "display_url" : "instagram.com\/p\/qpKcbfBws4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.143218767, -21.91562108 ]
  },
  "id_str" : "490568179416985600",
  "text" : "Phallic Travel Bar @ The Icelandic Phallological Museum http:\/\/t.co\/NKo0VZxQdc",
  "id" : 490568179416985600,
  "created_at" : "2014-07-19 18:45:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417187354, -21.9355811674 ]
  },
  "id_str" : "490544440378146819",
  "text" : "\u00ABDu hast recht, die Isl\u00E4nder furzen wirklich ungeniert in der \u00D6ffentlichkeit.\u00BB \u2013 \u00ABDas war ich\u2026\u00BB",
  "id" : 490544440378146819,
  "created_at" : "2014-07-19 17:11:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 33, 39 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/QbaFV1n5nu",
      "expanded_url" : "http:\/\/instagram.com\/p\/qo8cfzhwiu\/",
      "display_url" : "instagram.com\/p\/qo8cfzhwiu\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417153741, -21.9355842555 ]
  },
  "id_str" : "490537926036443136",
  "text" : "Noch keinen Tag in Reykjavik und @Lobot hat schon wen zum Kuscheln gefunden. http:\/\/t.co\/QbaFV1n5nu",
  "id" : 490537926036443136,
  "created_at" : "2014-07-19 16:45:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/CBv89L4eLc",
      "expanded_url" : "http:\/\/instagram.com\/p\/qox3AWBwvj\/",
      "display_url" : "instagram.com\/p\/qox3AWBwvj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.143218767, -21.91562108 ]
  },
  "id_str" : "490514117686341632",
  "text" : "Let me sing you the song of my people @ The Icelandic Phallological Museum http:\/\/t.co\/CBv89L4eLc",
  "id" : 490514117686341632,
  "created_at" : "2014-07-19 15:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/9m4k8HyG2Y",
      "expanded_url" : "http:\/\/instagram.com\/p\/qnZIDchwkq\/",
      "display_url" : "instagram.com\/p\/qnZIDchwkq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "490318988770295809",
  "text" : "Northbound #latergram http:\/\/t.co\/9m4k8HyG2Y",
  "id" : 490318988770295809,
  "created_at" : "2014-07-19 02:15:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bucketlist",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490227295618367488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417399922, -21.9356633069 ]
  },
  "id_str" : "490317600644419585",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr made it safe and sound, found the key. #bucketlist",
  "id" : 490317600644419585,
  "in_reply_to_status_id" : 490227295618367488,
  "created_at" : "2014-07-19 02:10:00 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0507866292, 8.5865322737 ]
  },
  "id_str" : "490221270001516544",
  "text" : "\u00ABIch hab gar keine Angst mehr vor dem Fliegen. Seit ich wei\u00DF das es im Flugzeug was zu essen gibt!\u00BB",
  "id" : 490221270001516544,
  "created_at" : "2014-07-18 19:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/RZqLAu9iPt",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/92148044780",
      "display_url" : "chapmangamo.tumblr.com\/post\/921480447\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.143485, 8.581806 ]
  },
  "id_str" : "490205888490524672",
  "text" : "uhm\u2026 http:\/\/t.co\/RZqLAu9iPt",
  "id" : 490205888490524672,
  "created_at" : "2014-07-18 18:46:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390964, 8.2829709413 ]
  },
  "id_str" : "490179569585238016",
  "text" : "\u00ABViel Spass beim spielen.\u00BB \u2014 \u00ABErstmal spiele ich WhatsApp gegen meine Mutter.\u00BB",
  "id" : 490179569585238016,
  "created_at" : "2014-07-18 17:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490116895673417728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096422978, 8.282763595 ]
  },
  "id_str" : "490126089428434944",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus I guess you could get some evidence if both ancient and modern things were comparable.",
  "id" : 490126089428434944,
  "in_reply_to_status_id" : 490116895673417728,
  "created_at" : "2014-07-18 13:29:00 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490115929364496385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096742981, 8.2830965316 ]
  },
  "id_str" : "490116190065664000",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus all ancient risky behaviours have some kind of potential payoff, none of the modern risky behaviours do\u2026",
  "id" : 490116190065664000,
  "in_reply_to_status_id" : 490115929364496385,
  "created_at" : "2014-07-18 12:49:40 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/8kHCvGc7lc",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2014\/07\/mens-sex-appeal-boosted-by-taking-risks.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+(BPS+Research+Digest",
      "display_url" : "bps-research-digest.blogspot.de\/2014\/07\/mens-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009655, 8.283866 ]
  },
  "id_str" : "490115069716733953",
  "text" : "\u00ABMen's sex appeal boosted by taking risks like cave man\u00BB Getting wrong conclusions by comparing incomparable things\u2026 http:\/\/t.co\/8kHCvGc7lc)",
  "id" : 490115069716733953,
  "created_at" : "2014-07-18 12:45:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490104275700170752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096562021, 8.2829730535 ]
  },
  "id_str" : "490109886026760192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer awesome, thanks a lot!",
  "id" : 490109886026760192,
  "in_reply_to_status_id" : 490104275700170752,
  "created_at" : "2014-07-18 12:24:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490086965631782912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095577428, 8.2829911433 ]
  },
  "id_str" : "490087101736955904",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj danke :*",
  "id" : 490087101736955904,
  "in_reply_to_status_id" : 490086965631782912,
  "created_at" : "2014-07-18 10:54:05 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490086607979282433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095577428, 8.2829911433 ]
  },
  "id_str" : "490086761369182208",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ja, nach dem Urlaub mal in Ruhe schauen.",
  "id" : 490086761369182208,
  "in_reply_to_status_id" : 490086607979282433,
  "created_at" : "2014-07-18 10:52:43 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490085703075000320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095577428, 8.2829911433 ]
  },
  "id_str" : "490086582771523584",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj aber ist auch ziemlich wumpe, auf dem Ding liegen eigentlich keine Daten von Wert die nicht irgendwo in der Cloud sind.",
  "id" : 490086582771523584,
  "in_reply_to_status_id" : 490085703075000320,
  "created_at" : "2014-07-18 10:52:01 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490085703075000320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095577428, 8.2829911433 ]
  },
  "id_str" : "490086372225871872",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj manchmal bootet sie sogar noch ein bisschen, l\u00E4sst mich aber nicht mehr einloggen. Mal sehen ob noch ein Backup geht.",
  "id" : 490086372225871872,
  "in_reply_to_status_id" : 490085703075000320,
  "created_at" : "2014-07-18 10:51:11 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094535249, 8.2829251327 ]
  },
  "id_str" : "490078960492216320",
  "text" : "What a nice day for a failing HDD\u2026",
  "id" : 490078960492216320,
  "created_at" : "2014-07-18 10:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 18, 29 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490040465849585664",
  "text" : "RT @helgerausch: .@openSNPorg is now in the EU lobby register, \"to make transparent that we're lacking all funds to do serious lobbying\" (@\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 1, 12 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 121, 137 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490039909164789760",
    "text" : ".@openSNPorg is now in the EU lobby register, \"to make transparent that we're lacking all funds to do serious lobbying\" (@gedankenstuecke)",
    "id" : 490039909164789760,
    "created_at" : "2014-07-18 07:46:33 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 490040465849585664,
  "created_at" : "2014-07-18 07:48:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490029235688316928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097030126, 8.2830003006 ]
  },
  "id_str" : "490029339766161408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ok :D",
  "id" : 490029339766161408,
  "in_reply_to_status_id" : 490029235688316928,
  "created_at" : "2014-07-18 07:04:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490028869961781249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096579176, 8.2831149828 ]
  },
  "id_str" : "490029190616719360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so sending you the credentials will help or not?",
  "id" : 490029190616719360,
  "in_reply_to_status_id" : 490028869961781249,
  "created_at" : "2014-07-18 07:03:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490028516604260352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096796686, 8.2830109634 ]
  },
  "id_str" : "490029075789283328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I will leave for 2 weeks of vacation this evening and would love to not give support from the Icelandic wilderness. ;)",
  "id" : 490029075789283328,
  "in_reply_to_status_id" : 490028516604260352,
  "created_at" : "2014-07-18 07:03:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490028516604260352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096796686, 8.2830109634 ]
  },
  "id_str" : "490028627955032065",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer are you just missing the login details?",
  "id" : 490028627955032065,
  "in_reply_to_status_id" : 490028516604260352,
  "created_at" : "2014-07-18 07:01:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490027909961097216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096228376, 8.2829053971 ]
  },
  "id_str" : "490028403706576896",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer by the way: do you by now have access to the info-address again?",
  "id" : 490028403706576896,
  "in_reply_to_status_id" : 490027909961097216,
  "created_at" : "2014-07-18 07:00:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "490023840626401281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096228376, 8.2829053971 ]
  },
  "id_str" : "490027817170911232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer probably lots of bacterial sequences? :3",
  "id" : 490027817170911232,
  "in_reply_to_status_id" : 490023840626401281,
  "created_at" : "2014-07-18 06:58:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723412608, 8.6275743288 ]
  },
  "id_str" : "489795665506369537",
  "text" : "\u00ABAber die armen Albino-Tiere werden doch immer zu erst gefressen!\u00BB \u2013 \u00ABDeshalb hab ich schnell ganz viele Fotos gemacht!\u00BB",
  "id" : 489795665506369537,
  "created_at" : "2014-07-17 15:36:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723266613, 8.6275523395 ]
  },
  "id_str" : "489776455942168576",
  "text" : "\u00ABHow can someone laugh that much while reading a book on biostatistics?!\u00BB I\u2019m not slacking off, I\u2019m educating myself!",
  "id" : 489776455942168576,
  "created_at" : "2014-07-17 14:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1733696156, 8.632007929 ]
  },
  "id_str" : "489716570776948736",
  "text" : "\u00ABMeine damalige-noch-nicht-jetzt-nicht-mehr-Frau.\u00BB",
  "id" : 489716570776948736,
  "created_at" : "2014-07-17 10:21:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/D0HjOVmYuc",
      "expanded_url" : "http:\/\/ec.europa.eu\/research\/consultations\/science-2.0\/consultation_en.htm",
      "display_url" : "ec.europa.eu\/research\/consu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489693261641285632",
  "text" : "Just submitted the joint openSNP entry for the consultation on Science 2.0\/Open Science by the European Commission: http:\/\/t.co\/D0HjOVmYuc",
  "id" : 489693261641285632,
  "created_at" : "2014-07-17 08:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489663547966644225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1048522287, 8.6571940885 ]
  },
  "id_str" : "489663953770151936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, so much fun to come from that. :3",
  "id" : 489663953770151936,
  "in_reply_to_status_id" : 489663547966644225,
  "created_at" : "2014-07-17 06:52:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 54, 67 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/YU9nhhn7Hj",
      "expanded_url" : "http:\/\/feeds.arstechnica.com\/~r\/arstechnica\/science\/~3\/KRPRYOzuhQQ\/",
      "display_url" : "feeds.arstechnica.com\/~r\/arstechnica\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.094906, 8.595666 ]
  },
  "id_str" : "489661960179683328",
  "text" : "Darwin\u2019s complete Galapagos library posted online \/cc @PhilippBayer  http:\/\/t.co\/YU9nhhn7Hj",
  "id" : 489661960179683328,
  "created_at" : "2014-07-17 06:44:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Mf2wUpEc4A",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/07\/14\/jealous_of_what_solving_polyamorys_jealousy_problem\/",
      "display_url" : "salon.com\/2014\/07\/14\/jea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14348539, 8.58180568 ]
  },
  "id_str" : "489659084069933056",
  "text" : "Polyamory &amp; Transitivity: \u00ABThe common denominator is social rather than personal responsibility\u00BB http:\/\/t.co\/Mf2wUpEc4A",
  "id" : 489659084069933056,
  "created_at" : "2014-07-17 06:33:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7KQw7Lk2si",
      "expanded_url" : "http:\/\/goo.gl\/NKgbx7",
      "display_url" : "goo.gl\/NKgbx7"
    } ]
  },
  "geo" : { },
  "id_str" : "489511501850357760",
  "text" : "RT @openculture: Honor\u00E9 de Balzac Writes About \u201CThe Pleasures and Pains of Coffee\u201D &amp; His Epic Coffee Addiction http:\/\/t.co\/7KQw7Lk2si http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/489487811138289664\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/Z5eidF3SgI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BssCkfwCUAA1u46.jpg",
        "id_str" : "489487810521354240",
        "id" : 489487810521354240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BssCkfwCUAA1u46.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/Z5eidF3SgI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/7KQw7Lk2si",
        "expanded_url" : "http:\/\/goo.gl\/NKgbx7",
        "display_url" : "goo.gl\/NKgbx7"
      } ]
    },
    "geo" : { },
    "id_str" : "489487811138289664",
    "text" : "Honor\u00E9 de Balzac Writes About \u201CThe Pleasures and Pains of Coffee\u201D &amp; His Epic Coffee Addiction http:\/\/t.co\/7KQw7Lk2si http:\/\/t.co\/Z5eidF3SgI",
    "id" : 489487811138289664,
    "created_at" : "2014-07-16 19:12:43 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851645340830715904\/jrs1gcNM_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 489511501850357760,
  "created_at" : "2014-07-16 20:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 3, 14 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/z2Fou7S15c",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0102172",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489465940892205057",
  "text" : "RT @carlzimmer: A new survey in PLoS ONE documents sexual harassment and assault in field-based sciences: http:\/\/t.co\/z2Fou7S15c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/z2Fou7S15c",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0102172",
        "display_url" : "plosone.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489464600794890240",
    "text" : "A new survey in PLoS ONE documents sexual harassment and assault in field-based sciences: http:\/\/t.co\/z2Fou7S15c",
    "id" : 489464600794890240,
    "created_at" : "2014-07-16 17:40:29 +0000",
    "user" : {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "protected" : false,
      "id_str" : "14085070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916034313069715457\/url2G14j_normal.jpg",
      "id" : 14085070,
      "verified" : true
    }
  },
  "id" : 489465940892205057,
  "created_at" : "2014-07-16 17:45:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/9alMcmsODq",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/QgE24DTuRjA\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489461112879210496",
  "text" : "All of a sudden I feel so vanilla  http:\/\/t.co\/9alMcmsODq",
  "id" : 489461112879210496,
  "created_at" : "2014-07-16 17:26:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/tQI7eK5wWP",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/_nARLIjX4YA\/info%3Adoi%2F10.1371%2Fjournal.pone.0101798",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172294, 8.627535 ]
  },
  "id_str" : "489460354154790912",
  "text" : "\u00ABDepending on a priori assumptions, Germany could accommodate between 154 and 1769 wolf packs.\u00BB http:\/\/t.co\/tQI7eK5wWP",
  "id" : 489460354154790912,
  "created_at" : "2014-07-16 17:23:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723234359, 8.6275811728 ]
  },
  "id_str" : "489412703581392897",
  "text" : "Love \u201CIntuitive Biostatistics\u201D: \u00ABThe true value either lies within the 95% CI you calculated or it doesn\u2019t. There is no way for you to know\u00BB",
  "id" : 489412703581392897,
  "created_at" : "2014-07-16 14:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/DWf318v000",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/_1lIPgYeKm3o\/THzi-ZHF4qI\/AAAAAAAAAfA\/rlnrTawhJts\/s1600\/%EC%82%AC%EC%A7%84+252.jpg",
      "display_url" : "1.bp.blogspot.com\/_1lIPgYeKm3o\/T\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "489408209493704704",
  "geo" : { },
  "id_str" : "489409339414044672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot maybe I'll go for http:\/\/t.co\/DWf318v000 instead",
  "id" : 489409339414044672,
  "in_reply_to_status_id" : 489408209493704704,
  "created_at" : "2014-07-16 14:00:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723335116, 8.6275353885 ]
  },
  "id_str" : "489408893064589312",
  "text" : "Chapter Summary:\n* Probability is a confusing topic.",
  "id" : 489408893064589312,
  "created_at" : "2014-07-16 13:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489396130565087232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1981167062, 8.580803585 ]
  },
  "id_str" : "489406964984999936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so this is how I will row to work soon?",
  "id" : 489406964984999936,
  "in_reply_to_status_id" : 489396130565087232,
  "created_at" : "2014-07-16 13:51:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AIHh6yciu1",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/world-views\/is-the-most-rational-choice-the-random-one\/",
      "display_url" : "aeon.co\/magazine\/world\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489385387417403392",
  "text" : "an ode to random choice: \u00ABsometimes the most rational choice is a random stab in the dark\u00BB http:\/\/t.co\/AIHh6yciu1",
  "id" : 489385387417403392,
  "created_at" : "2014-07-16 12:25:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/EJbcD9DGBc",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/real-vegan-cheese#activity",
      "display_url" : "indiegogo.com\/projects\/real-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14348539, 8.58180568 ]
  },
  "id_str" : "489375383293530113",
  "text" : "Real Vegan Narwhal Cheese, that\u2019s a worthy stretch goal! https:\/\/t.co\/EJbcD9DGBc",
  "id" : 489375383293530113,
  "created_at" : "2014-07-16 11:45:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oxNK3wsSpT",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/07\/15\/dozens-of-giant-snails-seized.html",
      "display_url" : "boingboing.net\/2014\/07\/15\/doz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489326388349267968",
  "text" : "\u00ABThey are \"routinely confiscated\" in the U.S., where they are sold as pets. The snails are also said to be delicious\u00BB http:\/\/t.co\/oxNK3wsSpT",
  "id" : 489326388349267968,
  "created_at" : "2014-07-16 08:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/NVN5Z7PclH",
      "expanded_url" : "http:\/\/gawker.com\/who-you-love-is-a-political-choice-1596978900",
      "display_url" : "gawker.com\/who-you-love-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489324813014810624",
  "text" : "Who You Love Is a Political Choice http:\/\/t.co\/NVN5Z7PclH",
  "id" : 489324813014810624,
  "created_at" : "2014-07-16 08:25:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.20010413, 8.58076713 ]
  },
  "id_str" : "489313949889069056",
  "text" : "Fax-Versuch #3. Wenn das auch nicht klappt schicke ich berittene Boten los\u2026",
  "id" : 489313949889069056,
  "created_at" : "2014-07-16 07:41:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489300100896669696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723502046, 8.6275298551 ]
  },
  "id_str" : "489304977756930049",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache interesting genomic findings usually are interesting until you start to look more closely.",
  "id" : 489304977756930049,
  "in_reply_to_status_id" : 489300100896669696,
  "created_at" : "2014-07-16 07:06:12 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/OLYz4QZFxL",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/early\/2014\/07\/10\/1400825111",
      "display_url" : "pnas.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489298269143855104",
  "text" : "Is there already a blogpost explaining why this is probably just some population structure issue\/statistical fluke? http:\/\/t.co\/OLYz4QZFxL",
  "id" : 489298269143855104,
  "created_at" : "2014-07-16 06:39:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/TVdkS2M4jG",
      "expanded_url" : "http:\/\/qntm.org\/gay",
      "display_url" : "qntm.org\/gay"
    } ]
  },
  "geo" : { },
  "id_str" : "489289614734413824",
  "text" : "RT @PhilippBayer: Highly amusing: 'Gay marriage: the database engineering perspective' http:\/\/t.co\/TVdkS2M4jG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/TVdkS2M4jG",
        "expanded_url" : "http:\/\/qntm.org\/gay",
        "display_url" : "qntm.org\/gay"
      } ]
    },
    "geo" : { },
    "id_str" : "489205685825970177",
    "text" : "Highly amusing: 'Gay marriage: the database engineering perspective' http:\/\/t.co\/TVdkS2M4jG",
    "id" : 489205685825970177,
    "created_at" : "2014-07-16 00:31:39 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 489289614734413824,
  "created_at" : "2014-07-16 06:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/LycAfTnuZt",
      "expanded_url" : "https:\/\/medium.com\/the-physics-arxiv-blog\/data-mining-reveals-how-human-language-is-biased-towards-happiness-773df682c4a7",
      "display_url" : "medium.com\/the-physics-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489194624720723968",
  "text" : "Human Language Is Biased Towards Happiness, Say Computational Linguists https:\/\/t.co\/LycAfTnuZt",
  "id" : 489194624720723968,
  "created_at" : "2014-07-15 23:47:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096199071, 8.2829812673 ]
  },
  "id_str" : "489146353558499328",
  "text" : "\u00ABWie gemein, dich evolutionary dead end zu nennen. Ich hingegen habe die Ausbildung um das zu d\u00FCrfen.\u00BB \u2014 \u00ABUnd die Ausr\u00FCstung es zu \u00E4ndern.\u00BB",
  "id" : 489146353558499328,
  "created_at" : "2014-07-15 20:35:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/x0gsk6I1zY",
      "expanded_url" : "http:\/\/www.anglizismen.info\/wordpress\/",
      "display_url" : "anglizismen.info\/wordpress\/"
    } ]
  },
  "geo" : { },
  "id_str" : "489044837480824832",
  "text" : "RT @Lobot: Bitte helft mir, Dr. rofl zu werden! (Oder macht es f\u00FCr die lulz. YOLO!) http:\/\/t.co\/x0gsk6I1zY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/x0gsk6I1zY",
        "expanded_url" : "http:\/\/www.anglizismen.info\/wordpress\/",
        "display_url" : "anglizismen.info\/wordpress\/"
      } ]
    },
    "geo" : { },
    "id_str" : "489039002159575040",
    "text" : "Bitte helft mir, Dr. rofl zu werden! (Oder macht es f\u00FCr die lulz. YOLO!) http:\/\/t.co\/x0gsk6I1zY",
    "id" : 489039002159575040,
    "created_at" : "2014-07-15 13:29:18 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 489044837480824832,
  "created_at" : "2014-07-15 13:52:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489043340613398529",
  "text" : "\u00ABSure, you can try to do that in Perl. But I would bet not even Larry Wall could predict what will happen.\u00BB",
  "id" : 489043340613398529,
  "created_at" : "2014-07-15 13:46:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723300447, 8.6275051043 ]
  },
  "id_str" : "488956312282497024",
  "text" : "\u00ABDein Kopfkino ist USK18, wegen der Gewalt.\u00BB \u2014 \u00ABGenau, und alles andere ist USK6 oder USK12.\u00BB",
  "id" : 488956312282497024,
  "created_at" : "2014-07-15 08:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17376064, 8.62957594 ]
  },
  "id_str" : "488942479434334208",
  "text" : "\u00ABDas Auto wackelt. War das Wind, Erdbeben, Vulkanausbruch?!\u00BB \u2013 \u00ABDas war ich\u2026\u00BB \u2013 \u00ABHast du gefurzt?!\u00BB",
  "id" : 488942479434334208,
  "created_at" : "2014-07-15 07:05:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488827658243817472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17376064, 8.62957594 ]
  },
  "id_str" : "488942179952652288",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, thanks, I will manage somehow :)",
  "id" : 488942179952652288,
  "in_reply_to_status_id" : 488827658243817472,
  "created_at" : "2014-07-15 07:04:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 17, 24 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 25, 33 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488771137133096960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096118358, 8.2828820383 ]
  },
  "id_str" : "488771678483542016",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot @TnaKng @branleb on the positive side of things: at least I can see my desk at work again!",
  "id" : 488771678483542016,
  "in_reply_to_status_id" : 488771137133096960,
  "created_at" : "2014-07-14 19:47:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 17, 24 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 25, 33 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488771137133096960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00883979, 8.2835296 ]
  },
  "id_str" : "488771569062526976",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot @TnaKng @branleb we\u2019ll see. I will send it to them via fax tomorrow morning and hope for the best.",
  "id" : 488771569062526976,
  "in_reply_to_status_id" : 488771137133096960,
  "created_at" : "2014-07-14 19:46:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 104, 113 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 114, 120 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 121, 128 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 129, 137 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00883979, 8.2835296 ]
  },
  "id_str" : "488769452671250432",
  "text" : "Turned over my work desk at least 3 times to find a damn form. It was on my desk at home all along\u2026 \/cc @Senficon @Lobot @TnaKng @branleb",
  "id" : 488769452671250432,
  "created_at" : "2014-07-14 19:38:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488565060722491392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1480921127, 8.6662101445 ]
  },
  "id_str" : "488565288737439744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nur +15 min, you will be fine, nichts systemisches so far.",
  "id" : 488565288737439744,
  "in_reply_to_status_id" : 488565060722491392,
  "created_at" : "2014-07-14 06:06:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0061276805, 8.2716227423 ]
  },
  "id_str" : "488563347408031744",
  "text" : "What we've got here is failure to commuter train\u2026",
  "id" : 488563347408031744,
  "created_at" : "2014-07-14 05:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/h9lHiI80SC",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=1qOPFhM8cPM",
      "display_url" : "youtube.com\/watch?v=1qOPFh\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044549423, 8.3025422651 ]
  },
  "id_str" : "488552705754157057",
  "text" : "Ein Volk suhlt sich in schwarz\/rot\/gold und br\u00FCllt dabei hurra\u2026 http:\/\/t.co\/h9lHiI80SC",
  "id" : 488552705754157057,
  "created_at" : "2014-07-14 05:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097189604, 8.2830547566 ]
  },
  "id_str" : "488447767015342080",
  "text" : "The one advice that 'Fluent in 3 Months' doesn't give: accidentally switch the language of your OS instead of adding a keyboard. \u05D0\u05D5\u05E3",
  "id" : 488447767015342080,
  "created_at" : "2014-07-13 22:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097382422, 8.2830764509 ]
  },
  "id_str" : "488380728347201536",
  "text" : "Im Bus gerade sa\u00DFen Menschen mit schwarz\/rot\/gold-Armbinde. Die heben den rechten Arm bestimmt auch nur um den Torwart zu imitieren\u2026",
  "id" : 488380728347201536,
  "created_at" : "2014-07-13 17:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 53, 60 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/dexmXWeT1S",
      "expanded_url" : "http:\/\/instagram.com\/p\/qZnI8Yhwse\/",
      "display_url" : "instagram.com\/p\/qZnI8Yhwse\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097819698, 8.283034265 ]
  },
  "id_str" : "488379690647048192",
  "text" : "my bearded hipster outfit is now complete, thanks to @TnaKng and her mustache cardigan http:\/\/t.co\/dexmXWeT1S",
  "id" : 488379690647048192,
  "created_at" : "2014-07-13 17:49:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/HB6PeOTbHP",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0098876",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488093303867711488",
  "text" : "Collective Philanthropy: Describing and Modeling the Ecology of Giving http:\/\/t.co\/HB6PeOTbHP",
  "id" : 488093303867711488,
  "created_at" : "2014-07-12 22:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488065745180696577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097021911, 8.2830442426 ]
  },
  "id_str" : "488069447396392960",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich 'If we gift them with a past, we create a cushion or a pillow for their emotions, and consequently, we can control them better.'",
  "id" : 488069447396392960,
  "in_reply_to_status_id" : 488065745180696577,
  "created_at" : "2014-07-12 21:16:38 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488059666606596096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096717634, 8.2831114949 ]
  },
  "id_str" : "488062261073039361",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das w\u00E4re auch mein Vorschlag. Oder Doppelblind die Reihenfolge ziehen lassen.",
  "id" : 488062261073039361,
  "in_reply_to_status_id" : 488059666606596096,
  "created_at" : "2014-07-12 20:48:05 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488057947575304193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096955907, 8.2830554626 ]
  },
  "id_str" : "488058280460427265",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wir schauen also beide Versionen an einem Abend? :p",
  "id" : 488058280460427265,
  "in_reply_to_status_id" : 488057947575304193,
  "created_at" : "2014-07-12 20:32:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488056860579475456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096955907, 8.2830554626 ]
  },
  "id_str" : "488056992049934337",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich nein, die Gnade der sp\u00E4ten Geburt hat mich davor bewahrt. Bei dir hat sie nicht geholfen?",
  "id" : 488056992049934337,
  "in_reply_to_status_id" : 488056860579475456,
  "created_at" : "2014-07-12 20:27:09 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488055691744399361",
  "geo" : { },
  "id_str" : "488055899093995520",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Wir sollten ihn uns wohl mal zusammen ansehen :)",
  "id" : 488055899093995520,
  "in_reply_to_status_id" : 488055691744399361,
  "created_at" : "2014-07-12 20:22:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/SoW7xLSmqc",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=1085",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488054700332548097",
  "text" : "too bad she won't live http:\/\/t.co\/SoW7xLSmqc",
  "id" : 488054700332548097,
  "created_at" : "2014-07-12 20:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 61, 74 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/vITHaHm6a7",
      "expanded_url" : "http:\/\/elitedaily.com\/life\/culture\/date-reader-readers-best-people-fall-love-scientifically-proven\/662017\/",
      "display_url" : "elitedaily.com\/life\/culture\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488049876610338820",
  "text" : "Did I ever tell you that I read like 100 books per year? \/cc @PhilippBayer http:\/\/t.co\/vITHaHm6a7",
  "id" : 488049876610338820,
  "created_at" : "2014-07-12 19:58:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/5ydsLolLP2",
      "expanded_url" : "http:\/\/evolang.the-comic.org\/comics\/pl\/427134",
      "display_url" : "evolang.the-comic.org\/comics\/pl\/4271\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.995949, 8.292798 ]
  },
  "id_str" : "487988358833266688",
  "text" : "A Ban on Evolutionary Linguistics http:\/\/t.co\/5ydsLolLP2",
  "id" : 487988358833266688,
  "created_at" : "2014-07-12 15:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xkQLsCpiFC",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/real-vegan-cheese",
      "display_url" : "indiegogo.com\/projects\/real-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.992591, 8.29242 ]
  },
  "id_str" : "487973369812639744",
  "text" : "Nice, the Real Vegan Cheese has hit the funding goal! https:\/\/t.co\/xkQLsCpiFC",
  "id" : 487973369812639744,
  "created_at" : "2014-07-12 14:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 38, 47 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/487947437676724224\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/TIo9XdnQHH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsWJm-CIAAAfIov.jpg",
      "id_str" : "487947437219512320",
      "id" : 487947437219512320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsWJm-CIAAAfIov.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1529
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 896
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1529
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 508
      } ],
      "display_url" : "pic.twitter.com\/TIo9XdnQHH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096736763, 8.2830165451 ]
  },
  "id_str" : "487947437676724224",
  "text" : "The biggest benefit of the new job of @Senficon. http:\/\/t.co\/TIo9XdnQHH",
  "id" : 487947437676724224,
  "created_at" : "2014-07-12 13:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Jan Schnorrenberg",
      "screen_name" : "spektrallinie",
      "indices" : [ 10, 24 ],
      "id_str" : "40870544",
      "id" : 40870544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487874830726094848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096913794, 8.2830953146 ]
  },
  "id_str" : "487898343834931200",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @spektrallinie das Tool nennt sich Promethease und man kann es umsonst verwenden afaik.",
  "id" : 487898343834931200,
  "in_reply_to_status_id" : 487874830726094848,
  "created_at" : "2014-07-12 09:56:44 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Jan Schnorrenberg",
      "screen_name" : "spektrallinie",
      "indices" : [ 10, 24 ],
      "id_str" : "40870544",
      "id" : 40870544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487874830726094848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096910261, 8.2830607519 ]
  },
  "id_str" : "487897817634320384",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @spektrallinie Anbieter die auch den Gentest machen nein. Aber die SNPedia bietet eine medizinische Auswertung von 23andme Daten.",
  "id" : 487897817634320384,
  "in_reply_to_status_id" : 487874830726094848,
  "created_at" : "2014-07-12 09:54:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/FDyKk8qigX",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/06\/30\/one-lichen-species-is-actually-126-and-probably-more\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/06\/30\/one\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487606482914267136",
  "text" : "One Lichen Species Is Actually 126, And Probably More http:\/\/t.co\/FDyKk8qigX",
  "id" : 487606482914267136,
  "created_at" : "2014-07-11 14:36:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kingsley Shacklebolt",
      "screen_name" : "Sankore_Texte",
      "indices" : [ 0, 14 ],
      "id_str" : "168846668",
      "id" : 168846668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487600391505608704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723194957, 8.6275308797 ]
  },
  "id_str" : "487605983930515456",
  "in_reply_to_user_id" : 168846668,
  "text" : "@Sankore_Texte ich glaube ich muss sogar \u00FCber 2 Br\u00FCcken, immerhin keine 7.",
  "id" : 487605983930515456,
  "in_reply_to_status_id" : 487600391505608704,
  "created_at" : "2014-07-11 14:35:00 +0000",
  "in_reply_to_screen_name" : "Sankore_Texte",
  "in_reply_to_user_id_str" : "168846668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/sGCNefMT9L",
      "expanded_url" : "http:\/\/cdn.smosh.com\/sites\/default\/files\/ftpuploads\/bloguploads\/1213\/hobbit-meme-no-shoes.jpg",
      "display_url" : "cdn.smosh.com\/sites\/default\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487601523032346626",
  "geo" : { },
  "id_str" : "487603000815681537",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/sGCNefMT9L",
  "id" : 487603000815681537,
  "in_reply_to_status_id" : 487601523032346626,
  "created_at" : "2014-07-11 14:23:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487599313603010561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723179054, 8.6276047136 ]
  },
  "id_str" : "487600633651159040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot fine with me, horny hobbit.",
  "id" : 487600633651159040,
  "in_reply_to_status_id" : 487599313603010561,
  "created_at" : "2014-07-11 14:13:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723140513, 8.6275979108 ]
  },
  "id_str" : "487593851495153664",
  "text" : "My team captain just baptized me for the relay marathon. Apparently my new name is \u201CBlazing Gandalf of Team Random Walk\u201D.",
  "id" : 487593851495153664,
  "created_at" : "2014-07-11 13:46:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 22, 27 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487547129359912960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723415904, 8.627579928 ]
  },
  "id_str" : "487548660818124801",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you and @li5a are giving the best advice, I should combine that.",
  "id" : 487548660818124801,
  "in_reply_to_status_id" : 487547129359912960,
  "created_at" : "2014-07-11 10:47:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723750648, 8.6274973322 ]
  },
  "id_str" : "487536336040370176",
  "text" : "Just-in-time compilation: less than 72 hours before I have to co-teach a course on Perl &amp; I just wrote my first line of Perl ever.",
  "id" : 487536336040370176,
  "created_at" : "2014-07-11 09:58:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/9C1Sh3i0T2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=z_lwocmL9dQ",
      "display_url" : "youtube.com\/watch?v=z_lwoc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487177321993236480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723231167, 8.6275633722 ]
  },
  "id_str" : "487179656035332096",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot http:\/\/t.co\/9C1Sh3i0T2",
  "id" : 487179656035332096,
  "in_reply_to_status_id" : 487177321993236480,
  "created_at" : "2014-07-10 10:20:56 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/o1tdcXazCO",
      "expanded_url" : "http:\/\/grapevine.is\/news\/2014\/07\/10\/seriously-stay-away-from-katla\/",
      "display_url" : "grapevine.is\/news\/2014\/07\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487174205491146752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723231167, 8.6275633722 ]
  },
  "id_str" : "487175012236140544",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot but rising h2s levels sound like so much fun! http:\/\/t.co\/o1tdcXazCO",
  "id" : 487175012236140544,
  "in_reply_to_status_id" : 487174205491146752,
  "created_at" : "2014-07-10 10:02:28 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487167112855965697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723231167, 8.6275633722 ]
  },
  "id_str" : "487173414592184320",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot we\u2019re already hoping for a volcano eruption for the time we\u2019re there, so we can stay a bit longer.",
  "id" : 487173414592184320,
  "in_reply_to_status_id" : 487167112855965697,
  "created_at" : "2014-07-10 09:56:07 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]