Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 54, 67 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/2OyWod7qyX",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0115892",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550415886071644161",
  "text" : "Machine Learning for Biomedical Literature Triage \/cc @PhilippBayer http:\/\/t.co\/2OyWod7qyX",
  "id" : 550415886071644161,
  "created_at" : "2014-12-31 22:19:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550415024230244356",
  "geo" : { },
  "id_str" : "550415184532365314",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot was man f\u00FCr eine Handvoll Favs nicht alles auf sich nimmt.",
  "id" : 550415184532365314,
  "in_reply_to_status_id" : 550415024230244356,
  "created_at" : "2014-12-31 22:16:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902355825849 ]
  },
  "id_str" : "550412640783433729",
  "text" : "\u00ABFindest du dass unsere Beziehung langweilig geworden ist?\u00BB \u2014 \u00ABNein, wir streiten doch noch wie am ersten Tag. \u00BB",
  "id" : 550412640783433729,
  "created_at" : "2014-12-31 22:06:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 57, 71 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/d1BMfn7yXu",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2014\/12\/30\/ripping-apart-that-terrible-atlantic-piece-on-open-access\/",
      "display_url" : "biomickwatson.wordpress.com\/2014\/12\/30\/rip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550290742749691904",
  "text" : "\u00ABadapt or die. Your choice.\u00BB On Scientific publishing by @BioMickWatson https:\/\/t.co\/d1BMfn7yXu",
  "id" : 550290742749691904,
  "created_at" : "2014-12-31 14:01:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/zawSkYyhWX",
      "expanded_url" : "http:\/\/priceonomics.com\/the-man-who-invented-scotch-tape\/",
      "display_url" : "priceonomics.com\/the-man-who-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550286165849686016",
  "text" : "The Man Who Invented Scotch Tape http:\/\/t.co\/zawSkYyhWX",
  "id" : 550286165849686016,
  "created_at" : "2014-12-31 13:43:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/iwIQrWtfrR",
      "expanded_url" : "http:\/\/ifixit.org\/blog\/6882\/why-i-drilled-holes-in-my-macbook-pro-and-put-it-in-the-oven\/",
      "display_url" : "ifixit.org\/blog\/6882\/why-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550282909169745921",
  "text" : "drilling speed holes into your notebook will probably be a thing soon. http:\/\/t.co\/iwIQrWtfrR",
  "id" : 550282909169745921,
  "created_at" : "2014-12-31 13:30:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707023, 8.75990295410177 ]
  },
  "id_str" : "550250793811836928",
  "text" : "\u00ABIch meine, schon Backrezepte k\u00F6nnen schief gehen weil deine Eier zu klein sind.\u00BB",
  "id" : 550250793811836928,
  "created_at" : "2014-12-31 11:23:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/fDU3KTFmoU",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/30\/wheeled-dolphin-looks-like.html",
      "display_url" : "boingboing.net\/2014\/12\/30\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550239427008937984",
  "text" : "i guess i can call myself a marine biologist now. http:\/\/t.co\/fDU3KTFmoU",
  "id" : 550239427008937984,
  "created_at" : "2014-12-31 10:37:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550238658876690432",
  "text" : "linking to the sciam blogs reminds me: is there a list of links to the new homes of the blogs that moved?",
  "id" : 550238658876690432,
  "created_at" : "2014-12-31 10:34:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/CQqiWtRVW8",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/symbiartic\/2014\/12\/30\/pinch-of-pigment-the-vegan-black\/",
      "display_url" : "blogs.scientificamerican.com\/symbiartic\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550238264310124544",
  "text" : "in search for vegan black paint http:\/\/t.co\/CQqiWtRVW8",
  "id" : 550238264310124544,
  "created_at" : "2014-12-31 10:33:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/BiA3EbNo6K",
      "expanded_url" : "https:\/\/medium.com\/vantage\/a-childhood-ritual-transforms-roadkill-into-art-ccaa6f67299c",
      "display_url" : "medium.com\/vantage\/a-chil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550236806823034881",
  "text" : "A Childhood Ritual Transforms Roadkill Into Art https:\/\/t.co\/BiA3EbNo6K",
  "id" : 550236806823034881,
  "created_at" : "2014-12-31 10:27:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/N7wqMG2CeS",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/30\/a-mail-kimp-song-you-c.html",
      "display_url" : "boingboing.net\/2014\/12\/30\/a-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550235750181404674",
  "text" : "the Mail... Kimp?-song http:\/\/t.co\/N7wqMG2CeS",
  "id" : 550235750181404674,
  "created_at" : "2014-12-31 10:23:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 0, 10 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550074945917571072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707018, 8.75316513947477 ]
  },
  "id_str" : "550093274237898752",
  "in_reply_to_user_id" : 267256091,
  "text" : "@_inundata 5. Find the first copy 6. Compare notes with yourself.",
  "id" : 550093274237898752,
  "in_reply_to_status_id" : 550074945917571072,
  "created_at" : "2014-12-31 00:57:11 +0000",
  "in_reply_to_screen_name" : "_inundata",
  "in_reply_to_user_id_str" : "267256091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/gOB8cPtd4J",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/anthropology-in-practice\/2014\/12\/30\/our-public-affair-with-food-porn\/",
      "display_url" : "blogs.scientificamerican.com\/anthropology-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550012168998248449",
  "text" : "Our public affair with food porn http:\/\/t.co\/gOB8cPtd4J",
  "id" : 550012168998248449,
  "created_at" : "2014-12-30 19:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHelix Staff",
      "screen_name" : "OpenHelix",
      "indices" : [ 0, 10 ],
      "id_str" : "41592143",
      "id" : 41592143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549970209055203328",
  "geo" : { },
  "id_str" : "549970855376465920",
  "in_reply_to_user_id" : 41592143,
  "text" : "@OpenHelix thanks for that! :)",
  "id" : 549970855376465920,
  "in_reply_to_status_id" : 549970209055203328,
  "created_at" : "2014-12-30 16:50:44 +0000",
  "in_reply_to_screen_name" : "OpenHelix",
  "in_reply_to_user_id_str" : "41592143",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/CTA29qRIQn",
      "expanded_url" : "http:\/\/www.strangeanimals.info\/2014\/12\/penis-primary-sexual-organ-that-male.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "strangeanimals.info\/2014\/12\/penis-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549860426390192128",
  "text" : "8 Weird Animal Penises http:\/\/t.co\/CTA29qRIQn",
  "id" : 549860426390192128,
  "created_at" : "2014-12-30 09:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/U4zCMMH1mt",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/61",
      "display_url" : "existentialcomics.com\/comic\/61"
    } ]
  },
  "geo" : { },
  "id_str" : "549859898813874176",
  "text" : "Happiness http:\/\/t.co\/U4zCMMH1mt",
  "id" : 549859898813874176,
  "created_at" : "2014-12-30 09:29:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "indices" : [ 3, 15 ],
      "id_str" : "15859033",
      "id" : 15859033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549854437712625664",
  "text" : "RT @ivanoransky: How Trustworthy Is Published Science? \"the more recent emphasis on exact replication of experiments may be misguided\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2mCwWJEn6a",
        "expanded_url" : "http:\/\/www.psmag.com\/navigation\/books-and-culture\/trustworthy-published-science-97180\/",
        "display_url" : "psmag.com\/navigation\/boo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549702633871908864",
    "text" : "How Trustworthy Is Published Science? \"the more recent emphasis on exact replication of experiments may be misguided\" http:\/\/t.co\/2mCwWJEn6a",
    "id" : 549702633871908864,
    "created_at" : "2014-12-29 23:04:55 +0000",
    "user" : {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "protected" : false,
      "id_str" : "15859033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1485171512\/bearcubtwitter_normal.jpg",
      "id" : 15859033,
      "verified" : false
    }
  },
  "id" : 549854437712625664,
  "created_at" : "2014-12-30 09:08:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 3, 11 ],
      "id_str" : "32865583",
      "id" : 32865583
    }, {
      "name" : "Laurie Penny",
      "screen_name" : "PennyRed",
      "indices" : [ 14, 23 ],
      "id_str" : "19530289",
      "id" : 19530289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/ODwuF1BDNU",
      "expanded_url" : "http:\/\/www.newstatesman.com\/laurie-penny\/on-nerd-entitlement-rebel-alliance-empire",
      "display_url" : "newstatesman.com\/laurie-penny\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549660827931115520",
  "text" : "RT @raichoo: .@PennyRed nails it. Again. http:\/\/t.co\/ODwuF1BDNU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurie Penny",
        "screen_name" : "PennyRed",
        "indices" : [ 1, 10 ],
        "id_str" : "19530289",
        "id" : 19530289
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/ODwuF1BDNU",
        "expanded_url" : "http:\/\/www.newstatesman.com\/laurie-penny\/on-nerd-entitlement-rebel-alliance-empire",
        "display_url" : "newstatesman.com\/laurie-penny\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549625227022725120",
    "text" : ".@PennyRed nails it. Again. http:\/\/t.co\/ODwuF1BDNU",
    "id" : 549625227022725120,
    "created_at" : "2014-12-29 17:57:20 +0000",
    "user" : {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "protected" : false,
      "id_str" : "32865583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227439864\/Foto_am_30-06-2010_um_16.53__2_normal.jpg",
      "id" : 32865583,
      "verified" : false
    }
  },
  "id" : 549660827931115520,
  "created_at" : "2014-12-29 20:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    }, {
      "name" : "Small Pond Science",
      "screen_name" : "SmallPondSci",
      "indices" : [ 24, 37 ],
      "id_str" : "2904630494",
      "id" : 2904630494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pgIBRJMhs0",
      "expanded_url" : "http:\/\/smallpondscience.com\/2014\/12\/29\/dead-grandmothers-no-more-the-equal-accommodation-classroom\/",
      "display_url" : "smallpondscience.com\/2014\/12\/29\/dea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549627362221236226",
  "text" : "RT @hormiga: My post in @SmallPondSci is about policies that fix Dead Grandmother Syndrome and excuses of all sorts. http:\/\/t.co\/pgIBRJMhs0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Small Pond Science",
        "screen_name" : "SmallPondSci",
        "indices" : [ 11, 24 ],
        "id_str" : "2904630494",
        "id" : 2904630494
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/pgIBRJMhs0",
        "expanded_url" : "http:\/\/smallpondscience.com\/2014\/12\/29\/dead-grandmothers-no-more-the-equal-accommodation-classroom\/",
        "display_url" : "smallpondscience.com\/2014\/12\/29\/dea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549606132709601280",
    "text" : "My post in @SmallPondSci is about policies that fix Dead Grandmother Syndrome and excuses of all sorts. http:\/\/t.co\/pgIBRJMhs0",
    "id" : 549606132709601280,
    "created_at" : "2014-12-29 16:41:27 +0000",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 549627362221236226,
  "created_at" : "2014-12-29 18:05:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 3, 16 ],
      "id_str" : "314758565",
      "id" : 314758565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549605178471907328",
  "text" : "RT @joe_pickrell: \"we need a statistical method called the Thin Mint, since this popular girl scout cookie is, ummmm...\" http:\/\/t.co\/Mm3UH5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Mm3UH5atF8",
        "expanded_url" : "http:\/\/andrewgelman.com\/2014\/12\/29\/statistical-methods-pocket-tools\/",
        "display_url" : "andrewgelman.com\/2014\/12\/29\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549574308209901569",
    "text" : "\"we need a statistical method called the Thin Mint, since this popular girl scout cookie is, ummmm...\" http:\/\/t.co\/Mm3UH5atF8",
    "id" : 549574308209901569,
    "created_at" : "2014-12-29 14:35:00 +0000",
    "user" : {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "protected" : false,
      "id_str" : "314758565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923000443105611776\/g88uZpgr_normal.jpg",
      "id" : 314758565,
      "verified" : false
    }
  },
  "id" : 549605178471907328,
  "created_at" : "2014-12-29 16:37:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113984491485, 8.753264234722549 ]
  },
  "id_str" : "549561927635316736",
  "text" : "\u00ABWow, das Halva ist ja hochenergetisch.\u00BB \u2014 \u00ABWar, jetzt ist mein B\u00E4uchlein hochenergetisch.\u00BB",
  "id" : 549561927635316736,
  "created_at" : "2014-12-29 13:45:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Fb2I9ZQ842",
      "expanded_url" : "http:\/\/loonylabs.org\/2014\/12\/28\/peer-review\/",
      "display_url" : "loonylabs.org\/2014\/12\/28\/pee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549533582059130881",
  "text" : "One more on the effectiveness of peer review: http:\/\/t.co\/Fb2I9ZQ842",
  "id" : 549533582059130881,
  "created_at" : "2014-12-29 11:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549532410556461056",
  "text" : "btw: if the new yorker gives you their paywall just throw the link into instapaper\u2026",
  "id" : 549532410556461056,
  "created_at" : "2014-12-29 11:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/FdMa4vvo5D",
      "expanded_url" : "http:\/\/www.newyorker.com\/business\/currency\/airlines-want-you-to-suffer",
      "display_url" : "newyorker.com\/business\/curre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549531620613824512",
  "text" : "Why Airlines Want to Make You Suffer http:\/\/t.co\/FdMa4vvo5D",
  "id" : 549531620613824512,
  "created_at" : "2014-12-29 11:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "indices" : [ 3, 14 ],
      "id_str" : "707463510",
      "id" : 707463510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549514618918666240",
  "text" : "RT @JTasioulas: Incidental findings in genomic research - what do people expect? What is there a duty to do? 2 different Qs http:\/\/t.co\/5Z6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/5Z68AKAWK7",
        "expanded_url" : "http:\/\/www.thelancet.com\/journals\/lancet\/article\/PIIS0140-6736%2814%2962119-X\/fulltext",
        "display_url" : "thelancet.com\/journals\/lance\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549471585560981504",
    "text" : "Incidental findings in genomic research - what do people expect? What is there a duty to do? 2 different Qs http:\/\/t.co\/5Z68AKAWK7",
    "id" : 549471585560981504,
    "created_at" : "2014-12-29 07:46:49 +0000",
    "user" : {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "protected" : false,
      "id_str" : "707463510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926487720448237568\/J0yl5rZm_normal.jpg",
      "id" : 707463510,
      "verified" : true
    }
  },
  "id" : 549514618918666240,
  "created_at" : "2014-12-29 10:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 3, 18 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549484740932542464",
  "text" : "RT @andreasklinger: \"Raiders of the lost bark\" - Indiana Jones with puppies and nazi kittens\u2026 obviously. Perfect to start a monday :) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BVzWSXDQee",
        "expanded_url" : "http:\/\/io9.com\/somebody-remade-raiders-of-the-lost-ark-with-a-dog-and-1675864262",
        "display_url" : "io9.com\/somebody-remad\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549480144570949633",
    "text" : "\"Raiders of the lost bark\" - Indiana Jones with puppies and nazi kittens\u2026 obviously. Perfect to start a monday :) http:\/\/t.co\/BVzWSXDQee",
    "id" : 549480144570949633,
    "created_at" : "2014-12-29 08:20:49 +0000",
    "user" : {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "protected" : false,
      "id_str" : "14946149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458856003732140032\/EN5TET65_normal.jpeg",
      "id" : 14946149,
      "verified" : true
    }
  },
  "id" : 549484740932542464,
  "created_at" : "2014-12-29 08:39:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/x5EP6z4Ixz",
      "expanded_url" : "http:\/\/www.meteoweb.eu\/2014\/12\/etna-eruzione-neve\/368775\/",
      "display_url" : "meteoweb.eu\/2014\/12\/etna-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549373822789779457",
  "text" : "Missed it: Etna erupted just a couple of hours ago http:\/\/t.co\/x5EP6z4Ixz",
  "id" : 549373822789779457,
  "created_at" : "2014-12-29 01:18:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Eg1VA4QvvT",
      "expanded_url" : "http:\/\/www.rollingstone.com\/movies\/features\/untold-story-of-national-lampoons-christmas-vacation-20141222",
      "display_url" : "rollingstone.com\/movies\/feature\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549371856277757952",
  "text" : "\u2018National Lampoon's Christmas Vacation\u2019 turned 25 this year\u2026 http:\/\/t.co\/Eg1VA4QvvT",
  "id" : 549371856277757952,
  "created_at" : "2014-12-29 01:10:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/jVloUIGxTZ",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/120629\/how-world-was-won-peter-conrad-review",
      "display_url" : "newrepublic.com\/article\/120629\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549367448282353664",
  "text" : "How The World Fell in Love with America http:\/\/t.co\/jVloUIGxTZ",
  "id" : 549367448282353664,
  "created_at" : "2014-12-29 00:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xRG3SR3qF6",
      "expanded_url" : "http:\/\/mrtz.org\/blog\/the-nips-experiment\/",
      "display_url" : "mrtz.org\/blog\/the-nips-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549365581888368640",
  "text" : "On peer review: \u00ABComputer science conference acceptances seem to be more random than we had previously realized.\u00BB http:\/\/t.co\/xRG3SR3qF6",
  "id" : 549365581888368640,
  "created_at" : "2014-12-29 00:45:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "indices" : [ 3, 10 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cdixon\/status\/549279458012975105\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/OY4W9DbDE5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B59uwaqIAAERbsF.png",
      "id_str" : "549279457631272961",
      "id" : 549279457631272961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B59uwaqIAAERbsF.png",
      "sizes" : [ {
        "h" : 414,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/OY4W9DbDE5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/gHJyJW6gMD",
      "expanded_url" : "https:\/\/github.com\/Dobiasd\/articles\/blob\/master\/programming_language_learning_curves.md",
      "display_url" : "github.com\/Dobiasd\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549364267083137024",
  "text" : "RT @cdixon: \"Learning curves for different programming languages\" https:\/\/t.co\/gHJyJW6gMD http:\/\/t.co\/OY4W9DbDE5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cdixon\/status\/549279458012975105\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/OY4W9DbDE5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B59uwaqIAAERbsF.png",
        "id_str" : "549279457631272961",
        "id" : 549279457631272961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B59uwaqIAAERbsF.png",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/OY4W9DbDE5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/gHJyJW6gMD",
        "expanded_url" : "https:\/\/github.com\/Dobiasd\/articles\/blob\/master\/programming_language_learning_curves.md",
        "display_url" : "github.com\/Dobiasd\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "549279458012975105",
    "text" : "\"Learning curves for different programming languages\" https:\/\/t.co\/gHJyJW6gMD http:\/\/t.co\/OY4W9DbDE5",
    "id" : 549279458012975105,
    "created_at" : "2014-12-28 19:03:22 +0000",
    "user" : {
      "name" : "Chris Dixon",
      "screen_name" : "cdixon",
      "protected" : false,
      "id_str" : "2529971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683496924104658944\/8Oa5XAso_normal.png",
      "id" : 2529971,
      "verified" : true
    }
  },
  "id" : 549364267083137024,
  "created_at" : "2014-12-29 00:40:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/r5wvEGf6G2",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/5\/13\/5711098\/science-says-the-five-second-rule-isnt-such-a-bad-idea",
      "display_url" : "vox.com\/2014\/5\/13\/5711\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11005573541455, 8.685664426584138 ]
  },
  "id_str" : "549216251713945600",
  "text" : "The 5 Second rule: \u00ABThis isn\u2019t exactly license to go around eating off the floor. But when you get caught doing so\u2026\u00BB http:\/\/t.co\/r5wvEGf6G2",
  "id" : 549216251713945600,
  "created_at" : "2014-12-28 14:52:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/csWlQzVM3S",
      "expanded_url" : "http:\/\/instagram.com\/p\/xJ2tLehwpR\/",
      "display_url" : "instagram.com\/p\/xJ2tLehwpR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "549212307083898881",
  "text" : "Ganz Gans http:\/\/t.co\/csWlQzVM3S",
  "id" : 549212307083898881,
  "created_at" : "2014-12-28 14:36:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/8sYa13Axp5",
      "expanded_url" : "https:\/\/medium.com\/starts-with-a-bang\/fixing-occams-razor-fc610ca13136",
      "display_url" : "medium.com\/starts-with-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549157142847315969",
  "text" : "Fixing Occam\u2019s Razor https:\/\/t.co\/8sYa13Axp5",
  "id" : 549157142847315969,
  "created_at" : "2014-12-28 10:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ZPLQqgjlgZ",
      "expanded_url" : "http:\/\/meyerweb.com\/eric\/thoughts\/2014\/12\/24\/inadvertent-algorithmic-cruelty\/",
      "display_url" : "meyerweb.com\/eric\/thoughts\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549156865813528577",
  "text" : "Inadvertent Algorithmic Cruelty http:\/\/t.co\/ZPLQqgjlgZ",
  "id" : 549156865813528577,
  "created_at" : "2014-12-28 10:56:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/CUodEjzlFR",
      "expanded_url" : "https:\/\/www.bostonglobe.com\/lifestyle\/style\/2014\/12\/26\/1Says1bHlR7GBsCy9QAwbJ\/story.html",
      "display_url" : "bostonglobe.com\/lifestyle\/styl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549156277839220736",
  "text" : "Dungeons &amp; Dragons strikes back https:\/\/t.co\/CUodEjzlFR",
  "id" : 549156277839220736,
  "created_at" : "2014-12-28 10:53:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/c3c6oz6Pyq",
      "expanded_url" : "http:\/\/www.evanmiller.org\/the-software-scientist.html",
      "display_url" : "evanmiller.org\/the-software-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "549155828486668288",
  "text" : "The Software Scientist http:\/\/t.co\/c3c6oz6Pyq",
  "id" : 549155828486668288,
  "created_at" : "2014-12-28 10:52:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/wHXVXwvGZO",
      "expanded_url" : "http:\/\/instagram.com\/p\/xH14DiBwkP\/",
      "display_url" : "instagram.com\/p\/xH14DiBwkP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "548929005962141696",
  "text" : "Schneemann Offenbach-style http:\/\/t.co\/wHXVXwvGZO",
  "id" : 548929005962141696,
  "created_at" : "2014-12-27 19:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/cPsjIJWCXS",
      "expanded_url" : "http:\/\/instagram.com\/p\/xFhZF-BwvK\/",
      "display_url" : "instagram.com\/p\/xFhZF-BwvK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "548602487293616129",
  "text" : "Dagegen! http:\/\/t.co\/cPsjIJWCXS",
  "id" : 548602487293616129,
  "created_at" : "2014-12-26 22:13:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.22039982191922, 8.902998650050115 ]
  },
  "id_str" : "548552617593700352",
  "text" : "\u00ABAls ich Magen-Darm hatte gab es das auch. Spritzgeb\u00E4ck und Spr\u00FChdurchfall.\u00BB",
  "id" : 548552617593700352,
  "created_at" : "2014-12-26 18:55:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.758925851202306 ]
  },
  "id_str" : "548501663963959297",
  "text" : "\u00ABDu wirst nicht f\u00FCr immer alleine sein. Bald sind die Tierheime voller Hunde. Und zu deinem Gl\u00FCck m\u00FCssen nur die einen Wesentest machen.\u00BB",
  "id" : 548501663963959297,
  "created_at" : "2014-12-26 15:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11228657924423, 8.752304292169262 ]
  },
  "id_str" : "548501043672522753",
  "text" : "\u00AB8. Mai? War das nicht Hitlers Geburtstag?\u00BB",
  "id" : 548501043672522753,
  "created_at" : "2014-12-26 15:30:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Alice Robb",
      "screen_name" : "alicelrobb",
      "indices" : [ 89, 100 ],
      "id_str" : "1254670346",
      "id" : 1254670346
    }, {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 105, 116 ],
      "id_str" : "44903491",
      "id" : 44903491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548422841189036032",
  "text" : "RT @mbeisen: The weird world of #openaccess journalism. My thoughts on recent stories by @alicelrobb and @roseveleth - http:\/\/t.co\/KuB9SM6e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alice Robb",
        "screen_name" : "alicelrobb",
        "indices" : [ 76, 87 ],
        "id_str" : "1254670346",
        "id" : 1254670346
      }, {
        "name" : "Rose Eveleth \u25B7\u25B7",
        "screen_name" : "roseveleth",
        "indices" : [ 92, 103 ],
        "id_str" : "44903491",
        "id" : 44903491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 19, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/KuB9SM6e3T",
        "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1673",
        "display_url" : "michaeleisen.org\/blog\/?p=1673"
      } ]
    },
    "geo" : { },
    "id_str" : "548360334478540801",
    "text" : "The weird world of #openaccess journalism. My thoughts on recent stories by @alicelrobb and @roseveleth - http:\/\/t.co\/KuB9SM6e3T",
    "id" : 548360334478540801,
    "created_at" : "2014-12-26 06:11:06 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 548422841189036032,
  "created_at" : "2014-12-26 10:19:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "548072748510355457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62345372501986, 7.199631796675447 ]
  },
  "id_str" : "548077590511382528",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Nutz den Jedi-Mind-Trick: \u2018Dies sind nicht die Venen die sie suchen\u2019",
  "id" : 548077590511382528,
  "in_reply_to_status_id" : 548072748510355457,
  "created_at" : "2014-12-25 11:27:35 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Tasioulas",
      "screen_name" : "JTasioulas",
      "indices" : [ 0, 11 ],
      "id_str" : "707463510",
      "id" : 707463510
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 12, 23 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 24, 32 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "548070750448807936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6234667106144, 7.19959309167299 ]
  },
  "id_str" : "548072506192838656",
  "in_reply_to_user_id" : 707463510,
  "text" : "@JTasioulas @EffyVayena @mbeisen given the turnaround at some journals I wouldn\u2019t be surprised if some 19th C horses are still on their way.",
  "id" : 548072506192838656,
  "in_reply_to_status_id" : 548070750448807936,
  "created_at" : "2014-12-25 11:07:22 +0000",
  "in_reply_to_screen_name" : "JTasioulas",
  "in_reply_to_user_id_str" : "707463510",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "548018469447680000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62325443441046, 7.199314483163715 ]
  },
  "id_str" : "548053528057749504",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog treffen sie die Venen so gut wie ihre Kollegen das mit Lasergewehren k\u00F6nnen?",
  "id" : 548053528057749504,
  "in_reply_to_status_id" : 548018469447680000,
  "created_at" : "2014-12-25 09:51:58 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6234354055339, 7.199738009573281 ]
  },
  "id_str" : "548050350339792898",
  "text" : "Indiana Jones - J\u00E4ger des verlorenen Wasserdrucks.",
  "id" : 548050350339792898,
  "created_at" : "2014-12-25 09:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62356381486543, 7.199760298047407 ]
  },
  "id_str" : "547923759769059329",
  "text" : "Seit langem das erste Mal an Heiligabend nicht near-blackout drunk und direkt aufs Maul fliegen. Weil der Zeh in der Zehensocke festh\u00E4ngt\u2026",
  "id" : 547923759769059329,
  "created_at" : "2014-12-25 01:16:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61252684693996, 7.195315155587563 ]
  },
  "id_str" : "547870738959462400",
  "text" : "\u00ABWenn mein Ex-Mann kommt dann sieht er mal gewaltfreie Kommunikation!\u00BB \u2014 \u00ABVerpr\u00FCgelst du ihn mit dem Gesamtwerk von Marshall Rosenberg?\u00BB",
  "id" : 547870738959462400,
  "created_at" : "2014-12-24 21:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/1J8UsEgJVM",
      "expanded_url" : "http:\/\/instagram.com\/p\/qo8cfzhwiu\/",
      "display_url" : "instagram.com\/p\/qo8cfzhwiu\/"
    } ]
  },
  "in_reply_to_status_id_str" : "547855882961575936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61269045903419, 7.195272245887649 ]
  },
  "id_str" : "547857383889076224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ja, nat\u00FCrlich. Alle schmutzigen Details aus unserem Schlafzimmer, inkl. http:\/\/t.co\/1J8UsEgJVM",
  "id" : 547857383889076224,
  "in_reply_to_status_id" : 547855882961575936,
  "created_at" : "2014-12-24 20:52:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6234431978857, 7.199731742210169 ]
  },
  "id_str" : "547847748503232514",
  "text" : "Den Kindern erkl\u00E4rt was f\u00FCr Sextoys sie in meinem Instagram-Stream gesehen haben. \u2714\uFE0F",
  "id" : 547847748503232514,
  "created_at" : "2014-12-24 20:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62343397725277, 7.199712799114441 ]
  },
  "id_str" : "547828071576117248",
  "text" : "Heiligabend. Die Zeit in der die Familie zusammenkommt um zu diskutieren wessen F\u00FCrze am meisten stinken.",
  "id" : 547828071576117248,
  "created_at" : "2014-12-24 18:56:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547764214996430850",
  "text" : "\u00ABOh, du r\u00E4umst zu Weihnachten dein Zimmer auf?\u00BB \u2013 \u00ABJa. Habt ihr schon mal verschimmelte Gummib\u00E4ren gesehen? Nein? Wollt ihr mal?\u00BB",
  "id" : 547764214996430850,
  "created_at" : "2014-12-24 14:42:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/X3vkYITxOI",
      "expanded_url" : "http:\/\/i.imgur.com\/XpemDHR.gif",
      "display_url" : "i.imgur.com\/XpemDHR.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "547761324185616384",
  "text" : "my experience with ggplot2 today: http:\/\/t.co\/X3vkYITxOI",
  "id" : 547761324185616384,
  "created_at" : "2014-12-24 14:30:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/6o39DceAGt",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/datalab\/whats-the-most-common-street-name-in-america\/",
      "display_url" : "fivethirtyeight.com\/datalab\/whats-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547756862599602176",
  "text" : "What\u2019s The Most Common Street Name In America? http:\/\/t.co\/6o39DceAGt",
  "id" : 547756862599602176,
  "created_at" : "2014-12-24 14:13:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/QyfkkuPDU3",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/12\/free-access-to-science-research-doesnt-benefit-everyone\/383875\/?single_page=true",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547747670811742208",
  "text" : "\u00ABFree Access to Science Research Doesn't Benefit Everyone\u00BB Doing the right thing is hard sometimes? Who knew\u2026 http:\/\/t.co\/QyfkkuPDU3",
  "id" : 547747670811742208,
  "created_at" : "2014-12-24 13:36:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/DC8tjbKX20",
      "expanded_url" : "http:\/\/www.thisiscolossal.com\/2014\/12\/photographer-spends-20-years-documenting-how-we-all-dress-exactly-alike\/",
      "display_url" : "thisiscolossal.com\/2014\/12\/photog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547746635150004225",
  "text" : "You're ALL individuals http:\/\/t.co\/DC8tjbKX20",
  "id" : 547746635150004225,
  "created_at" : "2014-12-24 13:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "547735063648305152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62342015665096, 7.205577655552756 ]
  },
  "id_str" : "547736120784871424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot what\u2019s the IF of those?",
  "id" : 547736120784871424,
  "in_reply_to_status_id" : 547735063648305152,
  "created_at" : "2014-12-24 12:50:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/pdoN9Y2z0E",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/DkS_ZcMGRjk\/info%3Adoi%2F10.1371%2Fjournal.pone.0115427",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62345, 7.19974 ]
  },
  "id_str" : "547717946630737921",
  "text" : "Drinking Songs: Alcohol Effects on Learned Song of Zebra Finches http:\/\/t.co\/pdoN9Y2z0E",
  "id" : 547717946630737921,
  "created_at" : "2014-12-24 11:38:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiglitzerfee\uD83D\uDC19",
      "screen_name" : "Molossoidea",
      "indices" : [ 0, 12 ],
      "id_str" : "1874599292",
      "id" : 1874599292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "547715580175073280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62339703109026, 7.1996177707514 ]
  },
  "id_str" : "547716004433113088",
  "in_reply_to_user_id" : 1874599292,
  "text" : "@Molossoidea danke :)",
  "id" : 547716004433113088,
  "in_reply_to_status_id" : 547715580175073280,
  "created_at" : "2014-12-24 11:30:46 +0000",
  "in_reply_to_screen_name" : "Molossoidea",
  "in_reply_to_user_id_str" : "1874599292",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/JgHOkxBiRV",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/106004983729",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/106004983\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547715473031561216",
  "text" : "Happened twice to me in the last 24h\u2026 http:\/\/t.co\/JgHOkxBiRV",
  "id" : 547715473031561216,
  "created_at" : "2014-12-24 11:28:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62343004457052, 7.199583515555498 ]
  },
  "id_str" : "547694300826722304",
  "text" : "\u00ABDu bekommst doch jetzt nicht etwa Torschlusspanik so kurz vor 30?\u00BB \u2014 \u00ABIch wei\u00DF ja nicht mal zu welchem der Tore ich Rennen sollte!\u00BB",
  "id" : 547694300826722304,
  "created_at" : "2014-12-24 10:04:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62350561923889, 7.199531131522737 ]
  },
  "id_str" : "547506078276419585",
  "text" : "\u00ABUnd wof\u00FCr brauchen wir den Kompass?\u00BB \u2014 \u00ABDamit ihr euch problemlos von der Gruppe weg in den Wald verziehen k\u00F6nnt um zu v\u00F6geln.\u00BB",
  "id" : 547506078276419585,
  "created_at" : "2014-12-23 21:36:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62340726479621, 7.199720467486807 ]
  },
  "id_str" : "547504595728343040",
  "text" : "\u00ABUnd was machst du wenn du Durchfall hast beim wandern?!\u00BB \u2014 \u00ABMama anrufen!\u00BB",
  "id" : 547504595728343040,
  "created_at" : "2014-12-23 21:30:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 68, 74 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/547341714164547584\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/kNXAoGQDPT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5iMYtPIMAARQbP.jpg",
      "id_str" : "547341710813310976",
      "id" : 547341710813310976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5iMYtPIMAARQbP.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1535,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2447,
        "resize" : "fit",
        "w" : 3264
      } ],
      "display_url" : "pic.twitter.com\/kNXAoGQDPT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067134139793, 8.759903981676048 ]
  },
  "id_str" : "547341714164547584",
  "text" : "Da ist man nur mal 2 Stunden weg um zu telefonieren und schon klebt @Lobot einem sowas auf den Rechner. http:\/\/t.co\/kNXAoGQDPT",
  "id" : 547341714164547584,
  "created_at" : "2014-12-23 10:43:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BiK-F",
      "screen_name" : "bik_f_",
      "indices" : [ 0, 7 ],
      "id_str" : "2849770550",
      "id" : 2849770550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "547030982545920000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17655890802137, 8.617448440365038 ]
  },
  "id_str" : "547034949921280000",
  "in_reply_to_user_id" : 2849770550,
  "text" : "@bik_f_ congratulations!",
  "id" : 547034949921280000,
  "in_reply_to_status_id" : 547030982545920000,
  "created_at" : "2014-12-22 14:24:30 +0000",
  "in_reply_to_screen_name" : "bik_f_",
  "in_reply_to_user_id_str" : "2849770550",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236118016809, 8.627503346776068 ]
  },
  "id_str" : "546994353512939520",
  "text" : "\u00ABMan merkt schon das die Uni die Heizung runtergefahren hat.\u00BB \u2014 \u00ABJa, sollen wir mal eben unsere Schreibtische in den Serverraum tragen?\u00BB",
  "id" : 546994353512939520,
  "created_at" : "2014-12-22 11:43:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546730285149462529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11967950404987, 8.645225913494004 ]
  },
  "id_str" : "546732149576323073",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport thanks for doing a great job.",
  "id" : 546732149576323073,
  "in_reply_to_status_id" : 546730285149462529,
  "created_at" : "2014-12-21 18:21:16 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546658431160320000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707029, 8.759902954101559 ]
  },
  "id_str" : "546658589805654017",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me Magneten gelesen und war verwundert.",
  "id" : 546658589805654017,
  "in_reply_to_status_id" : 546658431160320000,
  "created_at" : "2014-12-21 13:28:58 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546631686516396032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11077131787808, 8.757321568912538 ]
  },
  "id_str" : "546633078949822465",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, skeptical but I think with good reasons for being skeptical and not just outright doomish.",
  "id" : 546633078949822465,
  "in_reply_to_status_id" : 546631686516396032,
  "created_at" : "2014-12-21 11:47:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199707434, 8.759902962586212 ]
  },
  "id_str" : "546632843880071168",
  "text" : "\u00ABGepunktet finde ich das schlimmste Muster \u00FCberhaupt. Also abgesehen von Hakenkreuzen vielleicht.\u00BB",
  "id" : 546632843880071168,
  "created_at" : "2014-12-21 11:46:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/o20uPsanap",
      "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/12\/553\/abstract",
      "display_url" : "genomebiology.com\/2014\/15\/12\/553\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546603012844969984",
  "text" : "RT @lpachter: Evaluating the quality of an RNA-Seq assembly http:\/\/t.co\/o20uPsanap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/o20uPsanap",
        "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/12\/553\/abstract",
        "display_url" : "genomebiology.com\/2014\/15\/12\/553\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "546491977252884480",
    "text" : "Evaluating the quality of an RNA-Seq assembly http:\/\/t.co\/o20uPsanap",
    "id" : 546491977252884480,
    "created_at" : "2014-12-21 02:26:55 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 546603012844969984,
  "created_at" : "2014-12-21 09:48:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 96, 109 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/kv7ajDfUql",
      "expanded_url" : "http:\/\/thepointmag.com\/2014\/examined-life\/genetic-self",
      "display_url" : "thepointmag.com\/2014\/examined-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546601122610561025",
  "text" : "The Genetic Self: \u00ABThis brave new world need only be dystopian if we surrender our agency.\u00BB \/cc @PhilippBayer http:\/\/t.co\/kv7ajDfUql",
  "id" : 546601122610561025,
  "created_at" : "2014-12-21 09:40:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 0, 11 ],
      "id_str" : "8991502",
      "id" : 8991502
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 58, 65 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546453091747647488",
  "geo" : { },
  "id_str" : "546598672717606912",
  "in_reply_to_user_id" : 8991502,
  "text" : "@die_krabbe yup, i\u2019ve been collecting data with different @fitbit devices since ~ May 2012 and it\u2019s fun.",
  "id" : 546598672717606912,
  "in_reply_to_status_id" : 546453091747647488,
  "created_at" : "2014-12-21 09:30:53 +0000",
  "in_reply_to_screen_name" : "die_krabbe",
  "in_reply_to_user_id_str" : "8991502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "546477520007475200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11701175980809, 8.752825636263283 ]
  },
  "id_str" : "546595715267710977",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport thanks, will do :-)",
  "id" : 546595715267710977,
  "in_reply_to_status_id" : 546477520007475200,
  "created_at" : "2014-12-21 09:19:08 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/5BAKoS9NWk",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/12\/20\/ethics-joke-science\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A%20ResearchBloggingPsychologyEnglish%20%28Research%20Blogging%20-%20English%20-%20Psychology%29#.VJaPq4AN8",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546595255215476736",
  "text" : "The Ethics of Joke Science http:\/\/t.co\/5BAKoS9NWk",
  "id" : 546595255215476736,
  "created_at" : "2014-12-21 09:17:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/N89KoPvtv4",
      "expanded_url" : "http:\/\/fitbit.expertproductinquiry.com\/Force.aspx",
      "display_url" : "fitbit.expertproductinquiry.com\/Force.aspx"
    } ]
  },
  "in_reply_to_status_id_str" : "546459143138443265",
  "geo" : { },
  "id_str" : "546471246477934592",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport http:\/\/t.co\/N89KoPvtv4 works for me, but as I\u2019m living in neither the US nor Canada, but in Germany I can\u2019t use the form.",
  "id" : 546471246477934592,
  "in_reply_to_status_id" : 546459143138443265,
  "created_at" : "2014-12-21 01:04:32 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/D6MPvDJww4",
      "expanded_url" : "https:\/\/www.fitbit.com\/forcesupport\/refund",
      "display_url" : "fitbit.com\/forcesupport\/r\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "546459143138443265",
  "geo" : { },
  "id_str" : "546470750790885376",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport for me the refund-link (https:\/\/t.co\/D6MPvDJww4) only points to a blank white page.",
  "id" : 546470750790885376,
  "in_reply_to_status_id" : 546459143138443265,
  "created_at" : "2014-12-21 01:02:34 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5OsBWPAGfx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=vIUyyQkL1hw",
      "display_url" : "youtube.com\/watch?v=vIUyyQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546337093979750402",
  "text" : "Watching lava tongues. Maybe now is the time to figure out whether I\u2019m currently inscribed for geology or geography\u2026 https:\/\/t.co\/5OsBWPAGfx",
  "id" : 546337093979750402,
  "created_at" : "2014-12-20 16:11:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/blExgAVcg1",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1772",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546335424822931456",
  "text" : "funny cause it\u2019s true\u2026 http:\/\/t.co\/blExgAVcg1",
  "id" : 546335424822931456,
  "created_at" : "2014-12-20 16:04:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 9, 16 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/546313902146195456\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/4zP1l9MQmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5TlmUcCMAASXZk.png",
      "id_str" : "546313901302755328",
      "id" : 546313901302755328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5TlmUcCMAASXZk.png",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 910
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 910
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 910
      } ],
      "display_url" : "pic.twitter.com\/4zP1l9MQmE"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546313902146195456",
  "text" : "What the @fitbit Force tracked in total before breaking #quantifiedself http:\/\/t.co\/4zP1l9MQmE",
  "id" : 546313902146195456,
  "created_at" : "2014-12-20 14:39:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 26, 33 ],
      "id_str" : "17424053",
      "id" : 17424053
    }, {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 76, 90 ],
      "id_str" : "476258341",
      "id" : 476258341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/546312079620444160\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VfvW8TWbjY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Tj8R5IAAEJJJu.jpg",
      "id_str" : "546312079553331201",
      "id" : 546312079553331201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Tj8R5IAAEJJJu.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 741
      } ],
      "display_url" : "pic.twitter.com\/VfvW8TWbjY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546312079620444160",
  "text" : "Today the wristband of my @fitbit Force died, after using it since ~ March. @fitbitsupport http:\/\/t.co\/VfvW8TWbjY",
  "id" : 546312079620444160,
  "created_at" : "2014-12-20 14:32:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/UlWJYvi2Me",
      "expanded_url" : "http:\/\/instagram.com\/p\/w1KE1NBwge\/",
      "display_url" : "instagram.com\/p\/w1KE1NBwge\/"
    } ]
  },
  "geo" : { },
  "id_str" : "546299413585743872",
  "text" : "\u00ABIch versuche deinen Twitter-Avatar reverse zu reenacten.\u00BB http:\/\/t.co\/UlWJYvi2Me",
  "id" : 546299413585743872,
  "created_at" : "2014-12-20 13:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/17x0MNsU0X",
      "expanded_url" : "http:\/\/instagram.com\/p\/w1IsxpBwuR\/",
      "display_url" : "instagram.com\/p\/w1IsxpBwuR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "546296388905353217",
  "text" : "Oh well, in that case I will just call it a day and quit my PhD. http:\/\/t.co\/17x0MNsU0X",
  "id" : 546296388905353217,
  "created_at" : "2014-12-20 13:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066657357809, 8.759901543108608 ]
  },
  "id_str" : "546290221885972480",
  "text" : "\u00ABWenn ich es gleich krachen h\u00F6re dann leiste ich erste Hilfe. Erste Hilfe und zweites Fr\u00FChst\u00FCck.\u00BB",
  "id" : 546290221885972480,
  "created_at" : "2014-12-20 13:05:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "indices" : [ 3, 18 ],
      "id_str" : "15677536",
      "id" : 15677536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/1TZIwCCbuU",
      "expanded_url" : "http:\/\/repository.upenn.edu\/cgi\/viewcontent.cgi?article=1816&context=pwpl",
      "display_url" : "repository.upenn.edu\/cgi\/viewconten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545891461464862720",
  "text" : "RT @replicatedtypo: Vowel change across Noam Chomsky's lifespan: http:\/\/t.co\/1TZIwCCbuU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/1TZIwCCbuU",
        "expanded_url" : "http:\/\/repository.upenn.edu\/cgi\/viewcontent.cgi?article=1816&context=pwpl",
        "display_url" : "repository.upenn.edu\/cgi\/viewconten\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545888827278393345",
    "text" : "Vowel change across Noam Chomsky's lifespan: http:\/\/t.co\/1TZIwCCbuU",
    "id" : 545888827278393345,
    "created_at" : "2014-12-19 10:30:13 +0000",
    "user" : {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "protected" : false,
      "id_str" : "15677536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781432695838609409\/W-qS38wx_normal.jpg",
      "id" : 15677536,
      "verified" : false
    }
  },
  "id" : 545891461464862720,
  "created_at" : "2014-12-19 10:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/OsWK6IyErX",
      "expanded_url" : "http:\/\/kwerfeldein.de\/2014\/12\/19\/die-abenteuer-von-wolfgang-dem-wolfshund\/",
      "display_url" : "kwerfeldein.de\/2014\/12\/19\/die\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545862141132406784",
  "text" : "Die Abenteuer von Wolfgang dem Wolfshund http:\/\/t.co\/OsWK6IyErX",
  "id" : 545862141132406784,
  "created_at" : "2014-12-19 08:44:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/kMXl3g29KM",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/122\/",
      "display_url" : "what-if.xkcd.com\/122\/"
    } ]
  },
  "geo" : { },
  "id_str" : "545861423948390401",
  "text" : "What if I made a lava lamp out of real lava? http:\/\/t.co\/kMXl3g29KM",
  "id" : 545861423948390401,
  "created_at" : "2014-12-19 08:41:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "99pi",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/TMfDExCl1H",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/octothorpe\/",
      "display_url" : "99percentinvisible.org\/episode\/octoth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545860092844056576",
  "text" : "On the origin of Lattenzaun #99pi http:\/\/t.co\/TMfDExCl1H",
  "id" : 545860092844056576,
  "created_at" : "2014-12-19 08:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/aT7RFe7BAO",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/18\/lifehacks-for-sociopaths.html",
      "display_url" : "boingboing.net\/2014\/12\/18\/lif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545857038442840064",
  "text" : "Lifehacks for\u00A0sociopaths http:\/\/t.co\/aT7RFe7BAO",
  "id" : 545857038442840064,
  "created_at" : "2014-12-19 08:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Primitives Element",
      "screen_name" : "drseilzug",
      "indices" : [ 0, 10 ],
      "id_str" : "243633845",
      "id" : 243633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545734377901395968",
  "geo" : { },
  "id_str" : "545735226555908097",
  "in_reply_to_user_id" : 243633845,
  "text" : "@drseilzug \u201CUnd dann sind meine Augen so gro\u00DF geworden!\u201D",
  "id" : 545735226555908097,
  "in_reply_to_status_id" : 545734377901395968,
  "created_at" : "2014-12-19 00:19:51 +0000",
  "in_reply_to_screen_name" : "drseilzug",
  "in_reply_to_user_id_str" : "243633845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZZxjSZaGRP",
      "expanded_url" : "http:\/\/instagram.com\/p\/wxI1bChwm-\/",
      "display_url" : "instagram.com\/p\/wxI1bChwm-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "545733734767816704",
  "text" : "\u00ABKlar habe ich Verwendung f\u00FCr mein Schrottwichtelgeschenk. Ich h\u00E4ng es ans Bett, damit ich meine\u2026 http:\/\/t.co\/ZZxjSZaGRP",
  "id" : 545733734767816704,
  "created_at" : "2014-12-19 00:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545676957804134400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1770995501, 8.4044818747 ]
  },
  "id_str" : "545679340672151553",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das erkl\u00E4rt so viel(e Kilogramm!).",
  "id" : 545679340672151553,
  "in_reply_to_status_id" : 545676957804134400,
  "created_at" : "2014-12-18 20:37:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723891132, 8.6275402551 ]
  },
  "id_str" : "545606640486338560",
  "text" : "\u00ABIch lese die ganze Zeit \u2018Stoffwechselgeschenke\u2019 statt \u2018Schrottwichtelgeschenke\u2019\u2026\u00BB \u2014 \u00ABM\u00F6chtest du was von meinen Stoffwechselendgeschenken?\u00BB",
  "id" : 545606640486338560,
  "created_at" : "2014-12-18 15:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uLSr2pOW7w",
      "expanded_url" : "https:\/\/github.com\/reidpr\/quac",
      "display_url" : "github.com\/reidpr\/quac"
    } ]
  },
  "geo" : { },
  "id_str" : "545589418783178753",
  "text" : "\u00ABQUAC (\"quantitative analysis of chatter\" or any related acronym you like)\u00BB https:\/\/t.co\/uLSr2pOW7w",
  "id" : 545589418783178753,
  "created_at" : "2014-12-18 14:40:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/s2cQ4t95jE",
      "expanded_url" : "http:\/\/blogs.plos.org\/dnascience\/2014\/12\/18\/use-genetic-code-passwords\/",
      "display_url" : "blogs.plos.org\/dnascience\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545580336869298176",
  "text" : "Such a clever idea to get hackers interested in developing new algorithms for bioinformatics. http:\/\/t.co\/s2cQ4t95jE",
  "id" : 545580336869298176,
  "created_at" : "2014-12-18 14:04:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 0, 7 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545575050926370816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233284491108, 8.627568433041539 ]
  },
  "id_str" : "545577565063487488",
  "in_reply_to_user_id" : 9793782,
  "text" : "@compay thanks for all the work you put &amp; are putting into it. :-)",
  "id" : 545577565063487488,
  "in_reply_to_status_id" : 545575050926370816,
  "created_at" : "2014-12-18 13:53:22 +0000",
  "in_reply_to_screen_name" : "compay",
  "in_reply_to_user_id_str" : "9793782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545558905490014208",
  "text" : "Erst greift mich das Reinigungspersonal versehentlich mit einem M\u00FClleimer an, dann schl\u00E4gt mir ein Kollege eine T\u00FCr ins Gesicht. Not my day",
  "id" : 545558905490014208,
  "created_at" : "2014-12-18 12:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/wpRLdRB5fJ",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/12\/fantastically-wrong-thing-evolution-darwin-really-screwed\/",
      "display_url" : "wired.com\/2014\/12\/fantas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545548673657368576",
  "text" : "\u00ABBeing wildly wrong is perfectly healthy in science\u00BB http:\/\/t.co\/wpRLdRB5fJ",
  "id" : 545548673657368576,
  "created_at" : "2014-12-18 11:58:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 3, 14 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545543951730868224",
  "text" : "RT @NatureNews: UK academics awoke this morning to documents that determine future of university deps in the coming yrs http:\/\/t.co\/J0XVDH6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "REF2014",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/J0XVDH6IWm",
        "expanded_url" : "http:\/\/ow.ly\/G5y26",
        "display_url" : "ow.ly\/G5y26"
      } ]
    },
    "geo" : { },
    "id_str" : "545484461161590784",
    "text" : "UK academics awoke this morning to documents that determine future of university deps in the coming yrs http:\/\/t.co\/J0XVDH6IWm #REF2014",
    "id" : 545484461161590784,
    "created_at" : "2014-12-18 07:43:24 +0000",
    "user" : {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "protected" : false,
      "id_str" : "15862891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1158019862\/nature-header.ed_normal.png",
      "id" : 15862891,
      "verified" : true
    }
  },
  "id" : 545543951730868224,
  "created_at" : "2014-12-18 11:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172367854, 8.6275273454 ]
  },
  "id_str" : "545535858892611584",
  "text" : "\u00ABWeihnachten mit der \u00FCberalterten Familie feiern\u2026 Auch Krankheits-Quartett genannt.\u00BB",
  "id" : 545535858892611584,
  "created_at" : "2014-12-18 11:07:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17624526754969, 8.625080706559704 ]
  },
  "id_str" : "545526559713808385",
  "text" : "\u00ABDie Leute aus Bad Vilbel. Die Offenbacher des Wetterau-Kreises\u2026\u00BB",
  "id" : 545526559713808385,
  "created_at" : "2014-12-18 10:30:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/sTtadDqtkQ",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/17\/mormons-secret-temple-garme.html",
      "display_url" : "boingboing.net\/2014\/12\/17\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545522204994437120",
  "text" : "Mormon's Secret: temple garments for\u00A0gentiles http:\/\/t.co\/sTtadDqtkQ",
  "id" : 545522204994437120,
  "created_at" : "2014-12-18 10:13:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/dSAEI7uEiz",
      "expanded_url" : "http:\/\/www.homolog.us\/blogs\/ncrna\/2014\/12\/17\/evolution-of-genome-size-scientific-and-religious-analysis\/",
      "display_url" : "homolog.us\/blogs\/ncrna\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545517293951012864",
  "text" : "Evolution of Genome Size \u2013 Scientific and Religious Analysis http:\/\/t.co\/dSAEI7uEiz",
  "id" : 545517293951012864,
  "created_at" : "2014-12-18 09:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/sK4P4k2eLK",
      "expanded_url" : "http:\/\/www.kern-photo.com\/2014\/12\/burning-man-2014-pt-7-couples-in-love\/",
      "display_url" : "kern-photo.com\/2014\/12\/burnin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545514114844725249",
  "text" : "Burning Man 2014: Couples in Love http:\/\/t.co\/sK4P4k2eLK",
  "id" : 545514114844725249,
  "created_at" : "2014-12-18 09:41:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/eD1602GkvR",
      "expanded_url" : "http:\/\/www.genomicron.evolverzone.com\/2014\/12\/genome-sequence-paper-title-generator\/",
      "display_url" : "genomicron.evolverzone.com\/2014\/12\/genome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545512460695113728",
  "text" : "Genome Sequence Paper Title Generator http:\/\/t.co\/eD1602GkvR",
  "id" : 545512460695113728,
  "created_at" : "2014-12-18 09:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 3, 18 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Anthony Fejes",
      "screen_name" : "apfejes",
      "indices" : [ 87, 95 ],
      "id_str" : "59855448",
      "id" : 59855448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/NmQ7uYyBo7",
      "expanded_url" : "http:\/\/blog.fejes.ca\/?p=2484",
      "display_url" : "blog.fejes.ca\/?p=2484"
    } ]
  },
  "geo" : { },
  "id_str" : "545493224824266752",
  "text" : "RT @torstenseemann: The thrill and skill of writing a good bioinformatics pipeline, by @apfejes  http:\/\/t.co\/NmQ7uYyBo7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Fejes",
        "screen_name" : "apfejes",
        "indices" : [ 67, 75 ],
        "id_str" : "59855448",
        "id" : 59855448
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/NmQ7uYyBo7",
        "expanded_url" : "http:\/\/blog.fejes.ca\/?p=2484",
        "display_url" : "blog.fejes.ca\/?p=2484"
      } ]
    },
    "geo" : { },
    "id_str" : "544007336482701312",
    "text" : "The thrill and skill of writing a good bioinformatics pipeline, by @apfejes  http:\/\/t.co\/NmQ7uYyBo7",
    "id" : 544007336482701312,
    "created_at" : "2014-12-14 05:53:50 +0000",
    "user" : {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "protected" : false,
      "id_str" : "42558652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720526185361510400\/dA-svJxC_normal.jpg",
      "id" : 42558652,
      "verified" : false
    }
  },
  "id" : 545493224824266752,
  "created_at" : "2014-12-18 08:18:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 81, 97 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hdUhcZWusD",
      "expanded_url" : "http:\/\/www.nature.com\/news\/parasite-test-shows-where-validation-studies-can-go-wrong-1.16527",
      "display_url" : "nature.com\/news\/parasite-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545475610999803904",
  "text" : "RT @PhilippBayer: First report from Reproducibility Initiative - great work! cc  @gedankenstuecke http:\/\/t.co\/hdUhcZWusD Paper: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 63, 79 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/hdUhcZWusD",
        "expanded_url" : "http:\/\/www.nature.com\/news\/parasite-test-shows-where-validation-studies-can-go-wrong-1.16527",
        "display_url" : "nature.com\/news\/parasite-\u2026"
      }, {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Zdt43VY0Nt",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0114614",
        "display_url" : "plosone.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545356787008815105",
    "text" : "First report from Reproducibility Initiative - great work! cc  @gedankenstuecke http:\/\/t.co\/hdUhcZWusD Paper: http:\/\/t.co\/Zdt43VY0Nt",
    "id" : 545356787008815105,
    "created_at" : "2014-12-17 23:16:04 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 545475610999803904,
  "created_at" : "2014-12-18 07:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Elizabeth Iorns",
      "screen_name" : "elizabethiorns",
      "indices" : [ 26, 41 ],
      "id_str" : "262130711",
      "id" : 262130711
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 42, 49 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545356787008815105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7521563995 ]
  },
  "id_str" : "545475606448992256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice, grats @elizabethiorns @mrgunn!",
  "id" : 545475606448992256,
  "in_reply_to_status_id" : 545356787008815105,
  "created_at" : "2014-12-18 07:08:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/VAhI4NB6pt",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/browbeat\/2014\/12\/17\/funny_or_die_serial_parody_video_a_fictional_sarah_koenig_is_pretty_stressed.html",
      "display_url" : "slate.com\/blogs\/browbeat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599000002, 8.759902099999964 ]
  },
  "id_str" : "545320530996633600",
  "text" : "This week on Serial: http:\/\/t.co\/VAhI4NB6pt",
  "id" : 545320530996633600,
  "created_at" : "2014-12-17 20:52:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Buck",
      "screen_name" : "StuartBuck1",
      "indices" : [ 3, 15 ],
      "id_str" : "315161528",
      "id" : 315161528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/A6L3SGB701",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/12\/scientists-have-a-sharing-problem\/383061\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545317919006416897",
  "text" : "RT @StuartBuck1: Scientists Have a Sharing Problem http:\/\/t.co\/A6L3SGB701",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/A6L3SGB701",
        "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/12\/scientists-have-a-sharing-problem\/383061\/",
        "display_url" : "theatlantic.com\/health\/archive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545316250193100800",
    "text" : "Scientists Have a Sharing Problem http:\/\/t.co\/A6L3SGB701",
    "id" : 545316250193100800,
    "created_at" : "2014-12-17 20:35:00 +0000",
    "user" : {
      "name" : "Stuart Buck",
      "screen_name" : "StuartBuck1",
      "protected" : false,
      "id_str" : "315161528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551910749858041857\/3CdfH-wZ_normal.jpeg",
      "id" : 315161528,
      "verified" : false
    }
  },
  "id" : 545317919006416897,
  "created_at" : "2014-12-17 20:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173528481, 8.6288857207 ]
  },
  "id_str" : "545250709470740480",
  "text" : "\u00ABAndere Tiere bellen und fauchen. Du r\u00FClpst halt wenn du Angst hast.\u00BB",
  "id" : 545250709470740480,
  "created_at" : "2014-12-17 16:14:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545247163312513028",
  "text" : "\u00ABWhops, Ich muss mal ganz dringend nach Hause. Ich hab vergessen das meine Frau Geburtstag hat. Zum Gl\u00FCck hat Facebook mich dran erinnert.\u00BB",
  "id" : 545247163312513028,
  "created_at" : "2014-12-17 16:00:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16624707546664, 8.62668086869426 ]
  },
  "id_str" : "545208990293319680",
  "text" : "I could have lived with the blackout killing all my jobs &amp; the WiFi connectivity. But not with the ggplot2 documentation being down\u2026",
  "id" : 545208990293319680,
  "created_at" : "2014-12-17 13:28:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/noku5Ej6hp",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/Kdpzkbtvt2U\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545208352960438272",
  "text" : "Kill em all http:\/\/t.co\/noku5Ej6hp",
  "id" : 545208352960438272,
  "created_at" : "2014-12-17 13:26:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/hus0UKOCkL",
      "expanded_url" : "http:\/\/www.theguardian.com\/music\/2014\/dec\/16\/joe-strummer-has-deep-sea-snail-named-after-him?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/music\/2014\/dec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545208082893377536",
  "text" : "Joe Strummer has deep sea snail named after him http:\/\/t.co\/hus0UKOCkL",
  "id" : 545208082893377536,
  "created_at" : "2014-12-17 13:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xGw9KwDM8c",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1002023?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosbiology%2FNewArticles+%28PLOS+Biology+-+New+Articles%29",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545207682454798336",
  "text" : "Coevolution Drives the Emergence of Complex Traits and Promotes Evolvability http:\/\/t.co\/xGw9KwDM8c",
  "id" : 545207682454798336,
  "created_at" : "2014-12-17 13:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16728432613654, 8.618083562353805 ]
  },
  "id_str" : "545125683262140416",
  "text" : "\u00ABAuf Star Trek-Conventions f\u00FChlt man sich selbst als Star Wars-Fan seltsam. Das sind alles so Nerds.\u00BB",
  "id" : 545125683262140416,
  "created_at" : "2014-12-17 07:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723937173, 8.6275422658 ]
  },
  "id_str" : "545122737468235776",
  "text" : "\u00ABWieso habt ihr ein 28 Jahre altes, originalverpacktes Folienschweissger\u00E4t!?\u00BB \u2014 \u00ABHochzeitsgeschenk\u2026\u00BB",
  "id" : 545122737468235776,
  "created_at" : "2014-12-17 07:46:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Cunningham",
      "screen_name" : "erinmcunningham",
      "indices" : [ 3, 19 ],
      "id_str" : "198381553",
      "id" : 198381553
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/erinmcunningham\/status\/544927260470702080\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/qsndPmPNZz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4_4c-KIMAAoFbF.jpg",
      "id_str" : "544927256540622848",
      "id" : 544927256540622848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4_4c-KIMAAoFbF.jpg",
      "sizes" : [ {
        "h" : 468,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/qsndPmPNZz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/fSXMhOkOsV",
      "expanded_url" : "http:\/\/bit.ly\/1GMsnnP",
      "display_url" : "bit.ly\/1GMsnnP"
    } ]
  },
  "geo" : { },
  "id_str" : "544949900929425409",
  "text" : "RT @erinmcunningham: Stop Mixing Up Islamic Flags: A Guide for Lazy Journalists http:\/\/t.co\/fSXMhOkOsV http:\/\/t.co\/qsndPmPNZz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/erinmcunningham\/status\/544927260470702080\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/qsndPmPNZz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4_4c-KIMAAoFbF.jpg",
        "id_str" : "544927256540622848",
        "id" : 544927256540622848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4_4c-KIMAAoFbF.jpg",
        "sizes" : [ {
          "h" : 468,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/qsndPmPNZz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/fSXMhOkOsV",
        "expanded_url" : "http:\/\/bit.ly\/1GMsnnP",
        "display_url" : "bit.ly\/1GMsnnP"
      } ]
    },
    "geo" : { },
    "id_str" : "544927260470702080",
    "text" : "Stop Mixing Up Islamic Flags: A Guide for Lazy Journalists http:\/\/t.co\/fSXMhOkOsV http:\/\/t.co\/qsndPmPNZz",
    "id" : 544927260470702080,
    "created_at" : "2014-12-16 18:49:17 +0000",
    "user" : {
      "name" : "Erin Cunningham",
      "screen_name" : "erinmcunningham",
      "protected" : false,
      "id_str" : "198381553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872843156693204992\/no0peju1_normal.jpg",
      "id" : 198381553,
      "verified" : true
    }
  },
  "id" : 544949900929425409,
  "created_at" : "2014-12-16 20:19:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 67, 77 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Maria Konnikova",
      "screen_name" : "mkonnikova",
      "indices" : [ 126, 137 ],
      "id_str" : "358566293",
      "id" : 358566293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jnejUFhIea",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/medical_examiner\/2014\/12\/skipping_as_an_adult_great_exercise_and_a_lot_of_fun_for_grown_ups_and_kids.html",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659900111, 8.759902099978195 ]
  },
  "id_str" : "544948975867273216",
  "text" : "Waiting for the follow-up piece: \u00ABHow does my Fitbit track it?\u00BB RT @edyong209: Slate, never change. http:\/\/t.co\/jnejUFhIea HT @mkonnikova",
  "id" : 544948975867273216,
  "created_at" : "2014-12-16 20:15:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OurAnnualYear",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/R8KA1OvIJQ",
      "expanded_url" : "http:\/\/onion.com\/1GJS60b",
      "display_url" : "onion.com\/1GJS60b"
    } ]
  },
  "geo" : { },
  "id_str" : "544884300303572992",
  "text" : "RT @TheOnion: New Study Finds Only 88% Of Guitar Center Customers Become Famous Musicians http:\/\/t.co\/R8KA1OvIJQ #OurAnnualYear http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheOnion\/status\/544877151552430080\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/0WzItuncSS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B48WESTCUAA2GLl.jpg",
        "id_str" : "544678342822088704",
        "id" : 544678342822088704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B48WESTCUAA2GLl.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1133,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1133,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/0WzItuncSS"
      } ],
      "hashtags" : [ {
        "text" : "OurAnnualYear",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/R8KA1OvIJQ",
        "expanded_url" : "http:\/\/onion.com\/1GJS60b",
        "display_url" : "onion.com\/1GJS60b"
      } ]
    },
    "geo" : { },
    "id_str" : "544877151552430080",
    "text" : "New Study Finds Only 88% Of Guitar Center Customers Become Famous Musicians http:\/\/t.co\/R8KA1OvIJQ #OurAnnualYear http:\/\/t.co\/0WzItuncSS",
    "id" : 544877151552430080,
    "created_at" : "2014-12-16 15:30:10 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875392068125769732\/yrN-1k0Y_normal.jpg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 544884300303572992,
  "created_at" : "2014-12-16 15:58:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/86gGrvsiD5",
      "expanded_url" : "http:\/\/wir-schicken-wen.tumblr.com\/post\/105351840727\/schlechte-nachrichten-aus-dem-ruhrgebiet",
      "display_url" : "wir-schicken-wen.tumblr.com\/post\/105351840\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544860627572101121",
  "text" : "Wer dachte der Verkehr um Frankfurt rum sei schon gef\u00E4hrlich: http:\/\/t.co\/86gGrvsiD5",
  "id" : 544860627572101121,
  "created_at" : "2014-12-16 14:24:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/sRCH0I5yu0",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/59",
      "display_url" : "existentialcomics.com\/comic\/59"
    } ]
  },
  "geo" : { },
  "id_str" : "544795394233077760",
  "text" : "dreams of god, dreams of mind, dreams of monads intertwined. http:\/\/t.co\/sRCH0I5yu0",
  "id" : 544795394233077760,
  "created_at" : "2014-12-16 10:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/bQ7XAB4cUg",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/15\/gif-panda-dodges-laser-blasts.html",
      "display_url" : "boingboing.net\/2014\/12\/15\/gif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544794584111656960",
  "text" : "no wonder Pandas are going extinct http:\/\/t.co\/bQ7XAB4cUg",
  "id" : 544794584111656960,
  "created_at" : "2014-12-16 10:02:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abe Stein",
      "screen_name" : "abestein",
      "indices" : [ 3, 12 ],
      "id_str" : "68407182",
      "id" : 68407182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544781610085023744",
  "text" : "RT @abestein: Franz wrote the carol Silent Night. Hans took over the Nakatomi Plaza building. The Grubers: Christmas legends. http:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abestein\/status\/544702174094434304\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/C8YshWIdi9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B48rvOAIEAAqKaQ.jpg",
        "id_str" : "544702170147590144",
        "id" : 544702170147590144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B48rvOAIEAAqKaQ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/C8YshWIdi9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544702174094434304",
    "text" : "Franz wrote the carol Silent Night. Hans took over the Nakatomi Plaza building. The Grubers: Christmas legends. http:\/\/t.co\/C8YshWIdi9",
    "id" : 544702174094434304,
    "created_at" : "2014-12-16 03:54:53 +0000",
    "user" : {
      "name" : "Abe Stein",
      "screen_name" : "abestein",
      "protected" : false,
      "id_str" : "68407182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734021553025880064\/mw5ilXQL_normal.jpg",
      "id" : 68407182,
      "verified" : false
    }
  },
  "id" : 544781610085023744,
  "created_at" : "2014-12-16 09:10:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Grus",
      "screen_name" : "joelgrus",
      "indices" : [ 3, 12 ],
      "id_str" : "14092380",
      "id" : 14092380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lWxFXhdyWc",
      "expanded_url" : "http:\/\/notesonliberty.com\/2014\/12\/14\/questions-about-r\/#comment-26252",
      "display_url" : "notesonliberty.com\/2014\/12\/14\/que\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544778764362973185",
  "text" : "RT @joelgrus: \"Can someone help me understand the basics of R?\"\n\"The statistics software? Just read Mises instead!\" \nhttp:\/\/t.co\/lWxFXhdyWc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/lWxFXhdyWc",
        "expanded_url" : "http:\/\/notesonliberty.com\/2014\/12\/14\/questions-about-r\/#comment-26252",
        "display_url" : "notesonliberty.com\/2014\/12\/14\/que\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544655762459357186",
    "text" : "\"Can someone help me understand the basics of R?\"\n\"The statistics software? Just read Mises instead!\" \nhttp:\/\/t.co\/lWxFXhdyWc",
    "id" : 544655762459357186,
    "created_at" : "2014-12-16 00:50:27 +0000",
    "user" : {
      "name" : "Joel Grus",
      "screen_name" : "joelgrus",
      "protected" : false,
      "id_str" : "14092380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/899037185965346816\/sVS6ub55_normal.jpg",
      "id" : 14092380,
      "verified" : false
    }
  },
  "id" : 544778764362973185,
  "created_at" : "2014-12-16 08:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7598099395 ]
  },
  "id_str" : "544639005066018816",
  "text" : "\u00ABDer Kater k\u00E4mpft mit einem Gummiband.\u00BB \u2014 \u00ABUnd das Gummiband gewinnt\u2026\u00BB",
  "id" : 544639005066018816,
  "created_at" : "2014-12-15 23:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pittenauer",
      "screen_name" : "map",
      "indices" : [ 0, 4 ],
      "id_str" : "6256252",
      "id" : 6256252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/sUif6yseH1",
      "expanded_url" : "http:\/\/www.theshiznit.co.uk\/media\/2013\/December\/KEVINGIF.gif",
      "display_url" : "theshiznit.co.uk\/media\/2013\/Dec\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "544535375122006016",
  "geo" : { },
  "id_str" : "544537383677353984",
  "in_reply_to_user_id" : 6256252,
  "text" : "@map http:\/\/t.co\/sUif6yseH1",
  "id" : 544537383677353984,
  "in_reply_to_status_id" : 544535375122006016,
  "created_at" : "2014-12-15 17:00:03 +0000",
  "in_reply_to_screen_name" : "map",
  "in_reply_to_user_id_str" : "6256252",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723309723, 8.6275891814 ]
  },
  "id_str" : "544502759714983937",
  "text" : "\u00ABIch sag euch was. Bereitet niemals eine Pr\u00E4sentation unter Rest-Narkose vor!\u00BB",
  "id" : 544502759714983937,
  "created_at" : "2014-12-15 14:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/LTBwDcx0mh",
      "expanded_url" : "http:\/\/11011110.livejournal.com\/157570.html",
      "display_url" : "11011110.livejournal.com\/157570.html"
    } ]
  },
  "geo" : { },
  "id_str" : "544486601074933760",
  "text" : "TIL about Christmas cactus graphs http:\/\/t.co\/LTBwDcx0mh",
  "id" : 544486601074933760,
  "created_at" : "2014-12-15 13:38:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 10, 21 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544468884095766528",
  "geo" : { },
  "id_str" : "544469080389214209",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @spreeblick Das hoffe ich doch, alleine um dich im passenden Outfit zu sehen :)",
  "id" : 544469080389214209,
  "in_reply_to_status_id" : 544468884095766528,
  "created_at" : "2014-12-15 12:28:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 6, 15 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 101, 112 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/yAh1ZeeiAU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=GmWmSdJbFbs",
      "display_url" : "youtube.com\/watch?v=GmWmSd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544466892489248768",
  "text" : "Okay, @JP_Stich, I guess we have to improve our takes on cover versions. https:\/\/t.co\/yAh1ZeeiAU \/HT @spreeblick",
  "id" : 544466892489248768,
  "created_at" : "2014-12-15 12:19:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/jIUTQdxW8n",
      "expanded_url" : "https:\/\/medium.com\/@caseyjohnston\/the-okcupid-question-youre-answering-wrong-b3b502925697",
      "display_url" : "medium.com\/@caseyjohnston\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544463273190768641",
  "text" : "The OKCupid Question You\u2019re Answering Wrong https:\/\/t.co\/jIUTQdxW8n",
  "id" : 544463273190768641,
  "created_at" : "2014-12-15 12:05:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544462579511607296",
  "text" : "\u00ABKannst du meinen Rechner gerade mal anschauen? Ich glaube er hat Angst vor dir und macht wenn du zusiehst was ich will.\u00BB",
  "id" : 544462579511607296,
  "created_at" : "2014-12-15 12:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/WHrWG1u1II",
      "expanded_url" : "http:\/\/instagram.com\/p\/vvRYMMBwj_\/",
      "display_url" : "instagram.com\/p\/vvRYMMBwj_\/"
    } ]
  },
  "in_reply_to_status_id_str" : "544452477664645120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723534147, 8.6275533915 ]
  },
  "id_str" : "544453696604876800",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot worst loot ever. http:\/\/t.co\/WHrWG1u1II",
  "id" : 544453696604876800,
  "in_reply_to_status_id" : 544452477664645120,
  "created_at" : "2014-12-15 11:27:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/i7jcMxQrMP",
      "expanded_url" : "https:\/\/medium.com\/human-parts\/why-a-dutch-mugger-stole-my-breakfast-80bc73730677",
      "display_url" : "medium.com\/human-parts\/wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544449604528668675",
  "text" : "Why a Dutch Mugger Stole My Breakfast https:\/\/t.co\/i7jcMxQrMP",
  "id" : 544449604528668675,
  "created_at" : "2014-12-15 11:11:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544440904040611840",
  "geo" : { },
  "id_str" : "544441102338912256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer rough night, eh?",
  "id" : 544441102338912256,
  "in_reply_to_status_id" : 544440904040611840,
  "created_at" : "2014-12-15 10:37:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/0vbEWlJVCy",
      "expanded_url" : "http:\/\/i.imgur.com\/3DSmlpY.gif",
      "display_url" : "i.imgur.com\/3DSmlpY.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "544439459169992704",
  "text" : "status: http:\/\/t.co\/0vbEWlJVCy",
  "id" : 544439459169992704,
  "created_at" : "2014-12-15 10:30:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/TEDuruDidK",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/12\/12\/7377541\/maps-that-never-happened",
      "display_url" : "vox.com\/2014\/12\/12\/737\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544431401949745152",
  "text" : "20 maps that never happened http:\/\/t.co\/TEDuruDidK",
  "id" : 544431401949745152,
  "created_at" : "2014-12-15 09:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723328868, 8.6275889338 ]
  },
  "id_str" : "544423558341222400",
  "text" : "\u00ABamplified fragments are typically sequenced using the Roche 454 Genome Sequencer.\u00BB Go home textbook, you are outdated.",
  "id" : 544423558341222400,
  "created_at" : "2014-12-15 09:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544419279735910400",
  "geo" : { },
  "id_str" : "544419580094185472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u00ABThe R language documentation rolls its eyes, sighs, pushes up its glasses, and stops just short of telling you not to look.\u00BB",
  "id" : 544419580094185472,
  "in_reply_to_status_id" : 544419279735910400,
  "created_at" : "2014-12-15 09:11:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544419279735910400",
  "geo" : { },
  "id_str" : "544419394286542848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u00AB\"Generally,\" they add, with a straight face, \"[modifying your input file with Perl] is very simple.\" Snort. Ahem.\u00BB :D",
  "id" : 544419394286542848,
  "in_reply_to_status_id" : 544419279735910400,
  "created_at" : "2014-12-15 09:11:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Krystal Evans",
      "screen_name" : "dr_krystal",
      "indices" : [ 3, 14 ],
      "id_str" : "256424454",
      "id" : 256424454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544418151115792385",
  "text" : "RT @dr_krystal: Vale Prof Don Metcalf. Inspirational scientist &amp; mentor. Enormous contribution to research &amp; improving patients lives http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/s6KEiHyeL3",
        "expanded_url" : "http:\/\/vcwww-prod.wehi.edu.au\/about\/history\/tribute-professor-donald-metcalf",
        "display_url" : "vcwww-prod.wehi.edu.au\/about\/history\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544379535316111361",
    "text" : "Vale Prof Don Metcalf. Inspirational scientist &amp; mentor. Enormous contribution to research &amp; improving patients lives http:\/\/t.co\/s6KEiHyeL3",
    "id" : 544379535316111361,
    "created_at" : "2014-12-15 06:32:49 +0000",
    "user" : {
      "name" : "Dr Krystal Evans",
      "screen_name" : "dr_krystal",
      "protected" : false,
      "id_str" : "256424454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2357394884\/vvvqas0qpwqzkcmwtzvz_normal.jpeg",
      "id" : 256424454,
      "verified" : false
    }
  },
  "id" : 544418151115792385,
  "created_at" : "2014-12-15 09:06:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544411649218998273",
  "geo" : { },
  "id_str" : "544412056678842368",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich but tbh: when toying around w\/ the R shell I do just the same because I\u2019m too lazy for writing it out.",
  "id" : 544412056678842368,
  "in_reply_to_status_id" : 544411649218998273,
  "created_at" : "2014-12-15 08:42:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544411649218998273",
  "geo" : { },
  "id_str" : "544411860653850624",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \u00ABT and F are just variables with default values. Set T &lt;- F and source their code and laugh as it burns.\u00BB",
  "id" : 544411860653850624,
  "in_reply_to_status_id" : 544411649218998273,
  "created_at" : "2014-12-15 08:41:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544411086997700608",
  "text" : "\u00ABDo not use T and F for TRUE and FALSE. You will see people doing it but they're assholes and not your friend\u00BB",
  "id" : 544411086997700608,
  "created_at" : "2014-12-15 08:38:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZmVyulgz8m",
      "expanded_url" : "http:\/\/tim-smith.us\/arrgh\/index.html",
      "display_url" : "tim-smith.us\/arrgh\/index.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544409517992476674",
  "text" : "\u00ABR is a shockingly dreadful language for an exceptionally useful data analysis environment.\u00BB a angry guide to R: http:\/\/t.co\/ZmVyulgz8m",
  "id" : 544409517992476674,
  "created_at" : "2014-12-15 08:31:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/43S8ByypTK",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2014\/12\/22\/torture-truth?mbid=rss",
      "display_url" : "newyorker.com\/magazine\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544408339858595840",
  "text" : "Torture and the Truth http:\/\/t.co\/43S8ByypTK",
  "id" : 544408339858595840,
  "created_at" : "2014-12-15 08:27:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Lingenh\u00F6hl",
      "screen_name" : "lingenhoehl",
      "indices" : [ 0, 12 ],
      "id_str" : "202098194",
      "id" : 202098194
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 13, 20 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/M9CnGVuCv6",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Maisbeulenbrand",
      "display_url" : "de.wikipedia.org\/wiki\/Maisbeule\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "544404969554989056",
  "geo" : { },
  "id_str" : "544405398850371584",
  "in_reply_to_user_id" : 202098194,
  "text" : "@lingenhoehl @Evo2Me bekanntes Beispiel http:\/\/t.co\/M9CnGVuCv6",
  "id" : 544405398850371584,
  "in_reply_to_status_id" : 544404969554989056,
  "created_at" : "2014-12-15 08:15:36 +0000",
  "in_reply_to_screen_name" : "lingenhoehl",
  "in_reply_to_user_id_str" : "202098194",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "Daniel Lingenh\u00F6hl",
      "screen_name" : "lingenhoehl",
      "indices" : [ 8, 20 ],
      "id_str" : "202098194",
      "id" : 202098194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "544404370952318976",
  "geo" : { },
  "id_str" : "544404855184711681",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @lingenhoehl nicht nur, auch viral, bakteriell &amp; vor allem durch Pilze.",
  "id" : 544404855184711681,
  "in_reply_to_status_id" : 544404370952318976,
  "created_at" : "2014-12-15 08:13:26 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/t0Sllshk87",
      "expanded_url" : "http:\/\/www.genomicron.evolverzone.com\/2014\/12\/clearly-the-purpose-of-genome-sequencing-is-to-provide-insights\/?utm_source=twitterfeed&utm_medium=twitter&utm_campaign=Feed%3A+Genomicron+%28Genomicron%29",
      "display_url" : "genomicron.evolverzone.com\/2014\/12\/clearl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544401910204493824",
  "text" : "What genome sequencing is for. http:\/\/t.co\/t0Sllshk87",
  "id" : 544401910204493824,
  "created_at" : "2014-12-15 08:01:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "544232438512500736",
  "text" : "\u00ABIch wei\u00DF nicht ob ich mich weiter von dir rasieren lassen will. Bei der rabiaten \u2018Blut &amp; Hoden\u2019-Politik die du dabei an den Tag legst\u2026\u00BB",
  "id" : 544232438512500736,
  "created_at" : "2014-12-14 20:48:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/bJp5swJl4V",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/14\/the-kinky-coloring-book-vol-3.html",
      "display_url" : "boingboing.net\/2014\/12\/14\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "544177578039603200",
  "text" : "That would make a nice addition to my Human Evolution Coloring Book: The Kinky Coloring Book http:\/\/t.co\/bJp5swJl4V",
  "id" : 544177578039603200,
  "created_at" : "2014-12-14 17:10:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1161037562, 8.7419428444 ]
  },
  "id_str" : "544068720285732864",
  "text" : "\u00ABIch bin fett geworden.\u00BB \u2014 \u00ABDann mache ich uns mal einen kalorienarmen Kaffee zum Fr\u00FChst\u00FCck. Und willst du dazu Schokokuchen?\u00BB",
  "id" : 544068720285732864,
  "created_at" : "2014-12-14 09:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143674831, 8.7501988841 ]
  },
  "id_str" : "543916169460453376",
  "text" : "\u00ABRede mit einem Tierarzt, ehe du versuchst die Analdr\u00FCsen selbst auszudr\u00FCcken\u00BB Der Disclaimer h\u00E4tte besser vor dem 7-Step-How-To gestanden.",
  "id" : 543916169460453376,
  "created_at" : "2014-12-13 23:51:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/rzvv4vLRXZ",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/13\/house-of-lords-demands-its-own.html",
      "display_url" : "boingboing.net\/2014\/12\/13\/hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543873767500677120",
  "text" : "Sounds like a typical British headline to me http:\/\/t.co\/rzvv4vLRXZ",
  "id" : 543873767500677120,
  "created_at" : "2014-12-13 21:03:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/yVlbBf0Mrr",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/105089921170\/when-my-pi-compliments-me",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/105089921\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543872708417970176",
  "text" : "it\u2019s the little things http:\/\/t.co\/yVlbBf0Mrr",
  "id" : 543872708417970176,
  "created_at" : "2014-12-13 20:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Sch\u00E4fer",
      "screen_name" : "slowbiex",
      "indices" : [ 0, 9 ],
      "id_str" : "314720283",
      "id" : 314720283
    }, {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 10, 21 ],
      "id_str" : "8991502",
      "id" : 8991502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543756306986061825",
  "geo" : { },
  "id_str" : "543773981686652928",
  "in_reply_to_user_id" : 314720283,
  "text" : "@slowbiex @die_krabbe Danke, dann ist es vielleicht nicht was ich suche. :)",
  "id" : 543773981686652928,
  "in_reply_to_status_id" : 543756306986061825,
  "created_at" : "2014-12-13 14:26:34 +0000",
  "in_reply_to_screen_name" : "slowbiex",
  "in_reply_to_user_id_str" : "314720283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543744727372529664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1117359419, 8.7558599639 ]
  },
  "id_str" : "543744990493822977",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat sehr sch\u00F6n :)",
  "id" : 543744990493822977,
  "in_reply_to_status_id" : 543744727372529664,
  "created_at" : "2014-12-13 12:31:22 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543744641137672192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1117359419, 8.7558599639 ]
  },
  "id_str" : "543744937825935363",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ne, sollte kein Problem sein. K\u00F6nnen dann zusammen die S-Bahn nehmen. :)",
  "id" : 543744937825935363,
  "in_reply_to_status_id" : 543744641137672192,
  "created_at" : "2014-12-13 12:31:10 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543744391832408064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1117234234, 8.7559075339 ]
  },
  "id_str" : "543744549072691200",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat perfekt. Willst du FFM Hbf abgeholt werden?",
  "id" : 543744549072691200,
  "in_reply_to_status_id" : 543744391832408064,
  "created_at" : "2014-12-13 12:29:37 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543743139996270592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106719971, 8.759902954 ]
  },
  "id_str" : "543744266057814017",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat super. Ich freu mich drauf. :)",
  "id" : 543744266057814017,
  "in_reply_to_status_id" : 543743139996270592,
  "created_at" : "2014-12-13 12:28:29 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543742633106219008",
  "geo" : { },
  "id_str" : "543743008282517505",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat muss Montag &amp; Dienstag arbeiten. Aber Montag Nachmittag &amp; Abend k\u00F6nnte ich.",
  "id" : 543743008282517505,
  "in_reply_to_status_id" : 543742633106219008,
  "created_at" : "2014-12-13 12:23:30 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543741566347907072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106720005, 8.7599027162 ]
  },
  "id_str" : "543742525379719169",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat okay :) wann geht es weiter nach Offenbach? ;)",
  "id" : 543742525379719169,
  "in_reply_to_status_id" : 543741566347907072,
  "created_at" : "2014-12-13 12:21:34 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543742398522994688",
  "text" : "\u00ABHat er die ganze Zeit zugeschaut?\u00BB \u2014 \u00ABJa, jetzt neu: \u2018Kleiner Eisb\u00E4r, nimm mich\u2019 und \u2018Der kleine Eisb\u00E4r und die Darmsp\u00FClung\u2019.\u00BB",
  "id" : 543742398522994688,
  "created_at" : "2014-12-13 12:21:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543725112374358016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106739019, 8.7597705657 ]
  },
  "id_str" : "543741450627063810",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat schon wieder die letzte? Gab es das nicht schon mindestens 2x? ;)",
  "id" : 543741450627063810,
  "in_reply_to_status_id" : 543725112374358016,
  "created_at" : "2014-12-13 12:17:18 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/rpb4QA1G6v",
      "expanded_url" : "http:\/\/instagram.com\/p\/wixlsoBwkI\/",
      "display_url" : "instagram.com\/p\/wixlsoBwkI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "543712291796312065",
  "text" : "\u00ABIch wei\u00DF auch gar nicht wieso ich Fl\u00F6he hab.\u00BB http:\/\/t.co\/rpb4QA1G6v",
  "id" : 543712291796312065,
  "created_at" : "2014-12-13 10:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antje Findeklee (Unkraut vergeht nicht)",
      "screen_name" : "tre_bol",
      "indices" : [ 0, 8 ],
      "id_str" : "80123679",
      "id" : 80123679
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 9, 19 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543710138130243584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1155163177, 8.7504672141 ]
  },
  "id_str" : "543710681275834369",
  "in_reply_to_user_id" : 80123679,
  "text" : "@tre_bol @Fischblog nein, nicht nur bei denen. Ihr seid das letzte deutschsprachige Medium was noch in meinem Feedreader ist. :)",
  "id" : 543710681275834369,
  "in_reply_to_status_id" : 543710138130243584,
  "created_at" : "2014-12-13 10:15:02 +0000",
  "in_reply_to_screen_name" : "tre_bol",
  "in_reply_to_user_id_str" : "80123679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1181030283, 8.7515869143 ]
  },
  "id_str" : "543704419700051968",
  "text" : "Hey Lazyweb, irgendwelche Empfehlungen f\u00FCr Ultraschallreiniger zum Brillen und\/oder Sextoys s\u00E4ubern?",
  "id" : 543704419700051968,
  "created_at" : "2014-12-13 09:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 68, 78 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543703299481153536",
  "text" : "\u00ABIch lese Spektrum, es geht bergab mit mir!\u00BB \u2013 \u00ABAch, solange es von @fischblog ist hast du meine Absolution.\u00BB",
  "id" : 543703299481153536,
  "created_at" : "2014-12-13 09:45:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/wEIIFTieWp",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/05\/10\/the-lurker-how-a-virus-hid-in-our-genome-for-six-million-years\/",
      "display_url" : "phenomena.nationalgeographic.com\/2013\/05\/10\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543700603617423360",
  "text" : "The Lurker: How A Virus Hid In Our Genome For Six Million Years http:\/\/t.co\/wEIIFTieWp",
  "id" : 543700603617423360,
  "created_at" : "2014-12-13 09:35:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543471396970852353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1181030283, 8.7515869143 ]
  },
  "id_str" : "543699295627919360",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat party on!",
  "id" : 543699295627919360,
  "in_reply_to_status_id" : 543471396970852353,
  "created_at" : "2014-12-13 09:29:48 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "indices" : [ 3, 11 ],
      "id_str" : "304067888",
      "id" : 304067888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/U8eqgbUN46",
      "expanded_url" : "http:\/\/www.theguardian.com\/music\/2012\/dec\/06\/fairytale-new-york-pogues-christmas-anthem",
      "display_url" : "theguardian.com\/music\/2012\/dec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543690707291357184",
  "text" : "RT @ag_dubs: the story of The Pogues' xmas anthem: \"Fairytale of New York\" http:\/\/t.co\/U8eqgbUN46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/U8eqgbUN46",
        "expanded_url" : "http:\/\/www.theguardian.com\/music\/2012\/dec\/06\/fairytale-new-york-pogues-christmas-anthem",
        "display_url" : "theguardian.com\/music\/2012\/dec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "543387234440069120",
    "text" : "the story of The Pogues' xmas anthem: \"Fairytale of New York\" http:\/\/t.co\/U8eqgbUN46",
    "id" : 543387234440069120,
    "created_at" : "2014-12-12 12:49:46 +0000",
    "user" : {
      "name" : "ashley williams",
      "screen_name" : "ag_dubs",
      "protected" : false,
      "id_str" : "304067888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848921638649425925\/VThQjEEL_normal.jpg",
      "id" : 304067888,
      "verified" : false
    }
  },
  "id" : 543690707291357184,
  "created_at" : "2014-12-13 08:55:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Pearson\uD83D\uDC1C\uD83D\uDC1B",
      "screen_name" : "bug_gwen",
      "indices" : [ 3, 12 ],
      "id_str" : "19563103",
      "id" : 19563103
    }, {
      "name" : "Paul Fairie",
      "screen_name" : "paulisci",
      "indices" : [ 49, 58 ],
      "id_str" : "98487877",
      "id" : 98487877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bug_gwen\/status\/543410479549677568\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/tYBqANWEfq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4qU85HCAAEugak.jpg",
      "id_str" : "543410478894940161",
      "id" : 543410478894940161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4qU85HCAAEugak.jpg",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/tYBqANWEfq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543415976591917056",
  "text" : "RT @bug_gwen: A public service announcement from @paulisci about talking to grad students over the holidays. http:\/\/t.co\/tYBqANWEfq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Fairie",
        "screen_name" : "paulisci",
        "indices" : [ 35, 44 ],
        "id_str" : "98487877",
        "id" : 98487877
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bug_gwen\/status\/543410479549677568\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/tYBqANWEfq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4qU85HCAAEugak.jpg",
        "id_str" : "543410478894940161",
        "id" : 543410478894940161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4qU85HCAAEugak.jpg",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/tYBqANWEfq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543410479549677568",
    "text" : "A public service announcement from @paulisci about talking to grad students over the holidays. http:\/\/t.co\/tYBqANWEfq",
    "id" : 543410479549677568,
    "created_at" : "2014-12-12 14:22:09 +0000",
    "user" : {
      "name" : "Gwen Pearson\uD83D\uDC1C\uD83D\uDC1B",
      "screen_name" : "bug_gwen",
      "protected" : false,
      "id_str" : "19563103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842443534779207681\/BFGaXLCD_normal.jpg",
      "id" : 19563103,
      "verified" : true
    }
  },
  "id" : 543415976591917056,
  "created_at" : "2014-12-12 14:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2g2IqVDv8O",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0111913",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543415247596703744",
  "text" : "Plastic Pollution in the World's Oceans: More than 5 Trillion Plastic Pieces Weighing over 250,000 Tons Afloat at Sea http:\/\/t.co\/2g2IqVDv8O",
  "id" : 543415247596703744,
  "created_at" : "2014-12-12 14:41:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/bADtmSDzzN",
      "expanded_url" : "http:\/\/thump.vice.com\/en_uk\/words\/we-spoke-to-an-academic-whos-spent-25-years-researching-drugs-in-clubs",
      "display_url" : "thump.vice.com\/en_uk\/words\/we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543391077966032896",
  "text" : "We Spoke to an Academic Who's Spent 25 Years Researching Drugs in Clubs http:\/\/t.co\/bADtmSDzzN",
  "id" : 543391077966032896,
  "created_at" : "2014-12-12 13:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/543383441325441024\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/6GRx92fp6z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4p8Wv8IUAEju_c.jpg",
      "id_str" : "543383435319201793",
      "id" : 543383435319201793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4p8Wv8IUAEju_c.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/6GRx92fp6z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236391604603, 8.627523201460784 ]
  },
  "id_str" : "543383441325441024",
  "text" : "\u00ABEin schlauer Mann hat mal gesagt\u2026\u00BB \u2014 \u00ABFinger weg von meiner Tastatur!\u00BB http:\/\/t.co\/6GRx92fp6z",
  "id" : 543383441325441024,
  "created_at" : "2014-12-12 12:34:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543365974209339392",
  "geo" : { },
  "id_str" : "543375379126554624",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich i shouldn\u2019t have clicked. When Sorrow Sang The Bard\u2019s Song From The Other Side.",
  "id" : 543375379126554624,
  "in_reply_to_status_id" : 543365974209339392,
  "created_at" : "2014-12-12 12:02:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543360596956442624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17264043968544, 8.6275312311049 ]
  },
  "id_str" : "543362093991604224",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wir sollten mal ein mash-up aufnehmen. :)",
  "id" : 543362093991604224,
  "in_reply_to_status_id" : 543360596956442624,
  "created_at" : "2014-12-12 11:09:53 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543359314673803264",
  "geo" : { },
  "id_str" : "543359686226247681",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich a night beyond the red opera?",
  "id" : 543359686226247681,
  "in_reply_to_status_id" : 543359314673803264,
  "created_at" : "2014-12-12 11:00:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "torturereport",
      "indices" : [ 7, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qu2rbTDDGH",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/12\/10\/opinion\/the-torture-report-reminds-us-of-what-america-was.html?_r=2&referrer=",
      "display_url" : "mobile.nytimes.com\/2014\/12\/10\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543350121300520960",
  "text" : "On the #torturereport \u00ABThe students will come to know that this country isn\u2019t always something to be proud of.\u00BB http:\/\/t.co\/qu2rbTDDGH",
  "id" : 543350121300520960,
  "created_at" : "2014-12-12 10:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciFund",
      "indices" : [ 3, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gnk9x4DbOF",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0110329",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543347647655186432",
  "text" : "On #SciFund: To Crowdfund Research, Scientists Must Build an Audience for Their Work http:\/\/t.co\/gnk9x4DbOF",
  "id" : 543347647655186432,
  "created_at" : "2014-12-12 10:12:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qhab21tFiU",
      "expanded_url" : "http:\/\/blogs.plos.org\/paleo\/2014\/12\/10\/aquilops-hello\/",
      "display_url" : "blogs.plos.org\/paleo\/2014\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543344980044292096",
  "text" : "\u00ABthis animal had a funky bump on the front of its face. No idea what it was for, but it sure was cool.\u00BB http:\/\/t.co\/qhab21tFiU",
  "id" : 543344980044292096,
  "created_at" : "2014-12-12 10:01:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/qn2i7qeKiz",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0114876",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543343493561987072",
  "text" : "Statistical Reporting Errors and Collaboration on Statistical Analyses in Psychological Science http:\/\/t.co\/qn2i7qeKiz",
  "id" : 543343493561987072,
  "created_at" : "2014-12-12 09:55:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Deacon",
      "screen_name" : "MichaelPDeacon",
      "indices" : [ 3, 18 ],
      "id_str" : "506486097",
      "id" : 506486097
    }, {
      "name" : "Times Diary",
      "screen_name" : "TimesDiary",
      "indices" : [ 53, 64 ],
      "id_str" : "1482087114",
      "id" : 1482087114
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MichaelPDeacon\/status\/543326987461607424\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/sfgzs7JWKM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4pJAgWIUAEZb7p.jpg",
      "id_str" : "543326978083147777",
      "id" : 543326978083147777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4pJAgWIUAEZb7p.jpg",
      "sizes" : [ {
        "h" : 285,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/sfgzs7JWKM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543334272766345216",
  "text" : "RT @MichaelPDeacon: \"Looks a bit Ukip.\" From today's @TimesDiary http:\/\/t.co\/sfgzs7JWKM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Times Diary",
        "screen_name" : "TimesDiary",
        "indices" : [ 33, 44 ],
        "id_str" : "1482087114",
        "id" : 1482087114
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MichaelPDeacon\/status\/543326987461607424\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/sfgzs7JWKM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4pJAgWIUAEZb7p.jpg",
        "id_str" : "543326978083147777",
        "id" : 543326978083147777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4pJAgWIUAEZb7p.jpg",
        "sizes" : [ {
          "h" : 285,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 932
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 932
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 932
        } ],
        "display_url" : "pic.twitter.com\/sfgzs7JWKM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543326987461607424",
    "text" : "\"Looks a bit Ukip.\" From today's @TimesDiary http:\/\/t.co\/sfgzs7JWKM",
    "id" : 543326987461607424,
    "created_at" : "2014-12-12 08:50:22 +0000",
    "user" : {
      "name" : "Michael Deacon",
      "screen_name" : "MichaelPDeacon",
      "protected" : false,
      "id_str" : "506486097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658404648626339840\/bznQiT5w_normal.jpg",
      "id" : 506486097,
      "verified" : true
    }
  },
  "id" : 543334272766345216,
  "created_at" : "2014-12-12 09:19:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/23dNT9txhg",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/11\/extrapolating-the-backgrounds.html",
      "display_url" : "boingboing.net\/2014\/12\/11\/ext\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543334091048099840",
  "text" : "Extrapolating the backgrounds of famous art with machine\u00A0learning http:\/\/t.co\/23dNT9txhg",
  "id" : 543334091048099840,
  "created_at" : "2014-12-12 09:18:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/l0IjBtGU9b",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003955#s6",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543333552486883328",
  "text" : "\u201CBioinformatics: Introduction and Methods,\u201D a Bilingual MOOC as a New Example for Global Bioinformatics Education http:\/\/t.co\/l0IjBtGU9b",
  "id" : 543333552486883328,
  "created_at" : "2014-12-12 09:16:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543329339816017921",
  "text" : "\u00ABWie lief das Paper schreiben?\u00BB \u2013 \u00ABNicht so, ich bin dann doch lieber ins Theater gegangen.\u00BB",
  "id" : 543329339816017921,
  "created_at" : "2014-12-12 08:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 133, 143 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/5j61Zg3h6K",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/349\/bmj.g7073",
      "display_url" : "bmj.com\/content\/349\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543325702490443776",
  "text" : "Are \u201Carmchair socialists\u201D still sitting? Cross sectional study of polit. affiliation &amp; phys. activity http:\/\/t.co\/5j61Zg3h6K \/HT @edyong209",
  "id" : 543325702490443776,
  "created_at" : "2014-12-12 08:45:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edin \u0160a\u0161i\u0107",
      "screen_name" : "EdinSasic",
      "indices" : [ 26, 36 ],
      "id_str" : "909779684031893504",
      "id" : 909779684031893504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2Iu9X4UFYT",
      "expanded_url" : "http:\/\/readgenome.limequery.com\/index.php\/237524\/lang-en",
      "display_url" : "readgenome.limequery.com\/index.php\/2375\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543324013423263745",
  "text" : "There\u2019s a short survey by @EdinSasic on \"Health Literacy in the Era of Personal Genomics\" that you might want to do http:\/\/t.co\/2Iu9X4UFYT\u201D",
  "id" : 543324013423263745,
  "created_at" : "2014-12-12 08:38:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/JqSk0LlcUW",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3570",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543322069258498048",
  "text" : "I imagine microbiologists have this talk in their heads all day http:\/\/t.co\/JqSk0LlcUW",
  "id" : 543322069258498048,
  "created_at" : "2014-12-12 08:30:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/xZREgmCsoN",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/11\/anatomical-cookie-cutters.html",
      "display_url" : "boingboing.net\/2014\/12\/11\/ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "543319601371947008",
  "text" : "3D-printed anatomical cookie cutters http:\/\/t.co\/xZREgmCsoN",
  "id" : 543319601371947008,
  "created_at" : "2014-12-12 08:21:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/92dBAi9bVO",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/15\/227",
      "display_url" : "biomedcentral.com\/1471-2105\/15\/2\u2026"
    }, {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/sROeCGIKCs",
      "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/3\/R46",
      "display_url" : "genomebiology.com\/2014\/15\/3\/R46"
    } ]
  },
  "geo" : { },
  "id_str" : "543317685611008000",
  "text" : "Kraken: http:\/\/t.co\/92dBAi9bVO or http:\/\/t.co\/sROeCGIKCs",
  "id" : 543317685611008000,
  "created_at" : "2014-12-12 08:13:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Braatz",
      "screen_name" : "HeptaSean",
      "indices" : [ 0, 10 ],
      "id_str" : "50096711",
      "id" : 50096711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543308592393490432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11100782982678, 8.688307112753572 ]
  },
  "id_str" : "543314989734699008",
  "in_reply_to_user_id" : 50096711,
  "text" : "@HeptaSean Im Gegenteil, das war super zum geweckt werden. Ist ja so selten jemanden zu treffen f\u00FCr den Feyerabend nicht nur post-5pm ist.",
  "id" : 543314989734699008,
  "in_reply_to_status_id" : 543308592393490432,
  "created_at" : "2014-12-12 08:02:42 +0000",
  "in_reply_to_screen_name" : "HeptaSean",
  "in_reply_to_user_id_str" : "50096711",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edin \u0160a\u0161i\u0107",
      "screen_name" : "EdinSasic",
      "indices" : [ 0, 10 ],
      "id_str" : "909779684031893504",
      "id" : 909779684031893504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11100785286723, 8.6883068479008 ]
  },
  "id_str" : "543308349488762880",
  "text" : "@EdinSasic thanks, will have a look.",
  "id" : 543308349488762880,
  "created_at" : "2014-12-12 07:36:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11101809359016, 8.688218101784003 ]
  },
  "id_str" : "543308288969179136",
  "text" : "\u00ABSch\u00F6n dich in der Bahn zu treffen. Du siehst total m\u00FCde aus. Magst du mit mir \u00FCber Feyerabend und Popper reden?\u00BB",
  "id" : 543308288969179136,
  "created_at" : "2014-12-12 07:36:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543136123007283200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11069102990125, 8.759158164487578 ]
  },
  "id_str" : "543140379147894784",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente vielen Dank, aber ich glaube das ist zu viel des Lobes.",
  "id" : 543140379147894784,
  "in_reply_to_status_id" : 543136123007283200,
  "created_at" : "2014-12-11 20:28:52 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "543077056339517440",
  "geo" : { },
  "id_str" : "543089313228267520",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy sweet!",
  "id" : 543089313228267520,
  "in_reply_to_status_id" : 543077056339517440,
  "created_at" : "2014-12-11 17:05:57 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542765753062408193",
  "geo" : { },
  "id_str" : "542766883515416578",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot \u00ABa steady stream of low-budget, cash-cows which may prove to be the only truly immortal thing about this series\u00BB",
  "id" : 542766883515416578,
  "in_reply_to_status_id" : 542765753062408193,
  "created_at" : "2014-12-10 19:44:43 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542764915740913665",
  "geo" : { },
  "id_str" : "542765602579165184",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot \u2018the original theatrical edition has become considered 2 be one of the worst films ever released.\u2019 Quiz: 2, 3, 4 oder 5?",
  "id" : 542765602579165184,
  "in_reply_to_status_id" : 542764915740913665,
  "created_at" : "2014-12-10 19:39:38 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542764915740913665",
  "geo" : { },
  "id_str" : "542765283484897280",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot Das Sch\u00F6nste war die \u201Ccritical reception\u201D von Highlander 2-4 zu lesen.",
  "id" : 542765283484897280,
  "in_reply_to_status_id" : 542764915740913665,
  "created_at" : "2014-12-10 19:38:22 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542742123637125121",
  "geo" : { },
  "id_str" : "542764519286898688",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot danke, unter Umst\u00E4nden habe ich gerade 1h lang die Wikipedia zu Highlander gelesen.",
  "id" : 542764519286898688,
  "in_reply_to_status_id" : 542742123637125121,
  "created_at" : "2014-12-10 19:35:20 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542731257348915200",
  "geo" : { },
  "id_str" : "542758465379508224",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown late to the party, but: congrats!",
  "id" : 542758465379508224,
  "in_reply_to_status_id" : 542731257348915200,
  "created_at" : "2014-12-10 19:11:16 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/uyleDFVpIM",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/-a1VI0rQg1ak\/UX5fWRwwdxI\/AAAAAAAAgKA\/jSJL3DqnzkI\/s640\/Highlander+the+Series+-+Unholy+Alliance+Pt+2+22.jpg",
      "display_url" : "1.bp.blogspot.com\/-a1VI0rQg1ak\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "542742186455228416",
  "geo" : { },
  "id_str" : "542742552026566657",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Lobot http:\/\/t.co\/uyleDFVpIM",
  "id" : 542742552026566657,
  "in_reply_to_status_id" : 542742186455228416,
  "created_at" : "2014-12-10 18:08:02 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/I13o55LCSY",
      "expanded_url" : "http:\/\/webspace.webring.com\/people\/xh\/highland17\/images\/darius01.jpg",
      "display_url" : "webspace.webring.com\/people\/xh\/high\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "542741349800226817",
  "geo" : { },
  "id_str" : "542741782820569089",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Uh oh, @lobot stehen gerade vor der letzten Episode von Season 1. http:\/\/t.co\/I13o55LCSY",
  "id" : 542741782820569089,
  "in_reply_to_status_id" : 542741349800226817,
  "created_at" : "2014-12-10 18:04:59 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/hKvR1JRt3k",
      "expanded_url" : "http:\/\/instagram.com\/p\/wbnG3IBwnZ\/",
      "display_url" : "instagram.com\/p\/wbnG3IBwnZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "542704080892600322",
  "text" : "made it from anger over the gone espresso machine to bargaining really quickly. http:\/\/t.co\/hKvR1JRt3k",
  "id" : 542704080892600322,
  "created_at" : "2014-12-10 15:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542666405225971712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237692149186, 8.62754473782489 ]
  },
  "id_str" : "542666921163100160",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce I agree. It makes it looks like it\u2019s somehow equal which it obviously isn\u2019t.",
  "id" : 542666921163100160,
  "in_reply_to_status_id" : 542666405225971712,
  "created_at" : "2014-12-10 13:07:30 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542665147203190784",
  "geo" : { },
  "id_str" : "542665903767560192",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce right, that too.",
  "id" : 542665903767560192,
  "in_reply_to_status_id" : 542665147203190784,
  "created_at" : "2014-12-10 13:03:28 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542663957203664896",
  "geo" : { },
  "id_str" : "542664438374215680",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce love how they call it an \u201CEnhanced PDF\u201D. As if breaking usability and compatibility would be a huge service for the reader.",
  "id" : 542664438374215680,
  "in_reply_to_status_id" : 542663957203664896,
  "created_at" : "2014-12-10 12:57:38 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 3, 8 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/klmr\/status\/542658785580707840\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/HwsqwB4Smv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4fpSjAIcAArUTe.png",
      "id_str" : "542658784964145152",
      "id" : 542658784964145152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4fpSjAIcAArUTe.png",
      "sizes" : [ {
        "h" : 647,
        "resize" : "fit",
        "w" : 1027
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 1027
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 1027
      } ],
      "display_url" : "pic.twitter.com\/HwsqwB4Smv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542660179918323712",
  "text" : "RT @klmr: New scientific journal: BuzzFeed Science (impact factor: 43). http:\/\/t.co\/HwsqwB4Smv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/klmr\/status\/542658785580707840\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/HwsqwB4Smv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4fpSjAIcAArUTe.png",
        "id_str" : "542658784964145152",
        "id" : 542658784964145152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4fpSjAIcAArUTe.png",
        "sizes" : [ {
          "h" : 647,
          "resize" : "fit",
          "w" : 1027
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 1027
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 1027
        } ],
        "display_url" : "pic.twitter.com\/HwsqwB4Smv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542658785580707840",
    "text" : "New scientific journal: BuzzFeed Science (impact factor: 43). http:\/\/t.co\/HwsqwB4Smv",
    "id" : 542658785580707840,
    "created_at" : "2014-12-10 12:35:11 +0000",
    "user" : {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "protected" : false,
      "id_str" : "773450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2617576817\/4n2x4ln6fqopk944375r_normal.jpeg",
      "id" : 773450,
      "verified" : false
    }
  },
  "id" : 542660179918323712,
  "created_at" : "2014-12-10 12:40:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 78, 84 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/o1oe4vFOeD",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0113536",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542659946186555393",
  "text" : "When Do Natural Language Metaphors Influence Reasoning? A Follow-Up Study \/cc @Lobot http:\/\/t.co\/o1oe4vFOeD",
  "id" : 542659946186555393,
  "created_at" : "2014-12-10 12:39:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 69, 82 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/bm42C4tvet",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1002014",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542658309351022592",
  "text" : "Which Codon Synonym Is Best? It May Depend on What's on the Menu \/cc @PhilippBayer http:\/\/t.co\/bm42C4tvet",
  "id" : 542658309351022592,
  "created_at" : "2014-12-10 12:33:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qaZCRuUAa6",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/dfeb4fb3742f63ef8db6821a9a145a66\/tumblr_mv49xxej3c1rq9nqbo1_500.gif",
      "display_url" : "31.media.tumblr.com\/dfeb4fb3742f63\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542656856104370176",
  "text" : "\u00ABSure, we will survive without the espresso machine until next week.\u00BB How it looks like 5 minutes after it\u2019s gone: http:\/\/t.co\/qaZCRuUAa6",
  "id" : 542656856104370176,
  "created_at" : "2014-12-10 12:27:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/hA27hb86Xc",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Nkkx_0nJ1sY",
      "display_url" : "youtube.com\/watch?v=Nkkx_0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542632133999988736",
  "text" : "A Drone In Iceland https:\/\/t.co\/hA27hb86Xc",
  "id" : 542632133999988736,
  "created_at" : "2014-12-10 10:49:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 7, 19 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/3C21D2rJcq",
      "expanded_url" : "http:\/\/locatemyname.com\/density-map\/Schnagel.jpg",
      "display_url" : "locatemyname.com\/density-map\/Sc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "542622433212366848",
  "geo" : { },
  "id_str" : "542628885142462464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @helgerausch this map thinks otherwise http:\/\/t.co\/3C21D2rJcq",
  "id" : 542628885142462464,
  "in_reply_to_status_id" : 542622433212366848,
  "created_at" : "2014-12-10 10:36:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542615802718212098",
  "geo" : { },
  "id_str" : "542615960528879616",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach science has failed us!",
  "id" : 542615960528879616,
  "in_reply_to_status_id" : 542615802718212098,
  "created_at" : "2014-12-10 09:45:00 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542612970048856064",
  "geo" : { },
  "id_str" : "542614778334957568",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach und ich deshalb jetzt auch, na danke!",
  "id" : 542614778334957568,
  "in_reply_to_status_id" : 542612970048856064,
  "created_at" : "2014-12-10 09:40:19 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239441702845, 8.627527814483887 ]
  },
  "id_str" : "542612666871971840",
  "text" : "\u00ABIst das Zeug da drau\u00DFen Schnee oder Hagel?\u00BB \u2014 \u00ABIch w\u00FCrde sagen beides. Ich nenne es Schnagel.\u00BB",
  "id" : 542612666871971840,
  "created_at" : "2014-12-10 09:31:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPAdes assembler",
      "screen_name" : "spadesassembler",
      "indices" : [ 19, 35 ],
      "id_str" : "569820386",
      "id" : 569820386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9ktIlP76HT",
      "expanded_url" : "http:\/\/spades.bioinf.spbau.ru\/changelog.html",
      "display_url" : "spades.bioinf.spbau.ru\/changelog.html"
    } ]
  },
  "geo" : { },
  "id_str" : "542607417255923712",
  "text" : "Wow, the people of @spadesassembler really rock: SPAdes 3.5 is out http:\/\/t.co\/9ktIlP76HT",
  "id" : 542607417255923712,
  "created_at" : "2014-12-10 09:11:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Janet D. Stemwedel",
      "screen_name" : "docfreeride",
      "indices" : [ 24, 36 ],
      "id_str" : "17175139",
      "id" : 17175139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5Wx0CP2YGc",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/doing-good-science\/2014\/12\/06\/twenty-five-years-later\/?WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "blogs.scientificamerican.com\/doing-good-sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542596967885729793",
  "text" : "RT @phylogenomics: From @docfreeride: 25 years ago 14 women were \"murdered for being women\" at \u00C9cole Polytechnique http:\/\/t.co\/5Wx0CP2YGc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Janet D. Stemwedel",
        "screen_name" : "docfreeride",
        "indices" : [ 5, 17 ],
        "id_str" : "17175139",
        "id" : 17175139
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/5Wx0CP2YGc",
        "expanded_url" : "http:\/\/blogs.scientificamerican.com\/doing-good-science\/2014\/12\/06\/twenty-five-years-later\/?WT.mc_id=SA_sharetool_Twitter",
        "display_url" : "blogs.scientificamerican.com\/doing-good-sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542588756973195264",
    "text" : "From @docfreeride: 25 years ago 14 women were \"murdered for being women\" at \u00C9cole Polytechnique http:\/\/t.co\/5Wx0CP2YGc",
    "id" : 542588756973195264,
    "created_at" : "2014-12-10 07:56:55 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 542596967885729793,
  "created_at" : "2014-12-10 08:29:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542537794019917824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1109120747, 8.75197132 ]
  },
  "id_str" : "542579890084921344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx",
  "id" : 542579890084921344,
  "in_reply_to_status_id" : 542537794019917824,
  "created_at" : "2014-12-10 07:21:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542446819360243713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402447246957, 8.753295494251654 ]
  },
  "id_str" : "542449323544285184",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU heretic! ;)",
  "id" : 542449323544285184,
  "in_reply_to_status_id" : 542446819360243713,
  "created_at" : "2014-12-09 22:42:51 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/542425598044278784\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/3icORbEoKF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cVNDRCAAEG9fT.jpg",
      "id_str" : "542425594080657409",
      "id" : 542425594080657409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cVNDRCAAEG9fT.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/3icORbEoKF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542425598044278784",
  "text" : "Ready for evangelizing. http:\/\/t.co\/3icORbEoKF",
  "id" : 542425598044278784,
  "created_at" : "2014-12-09 21:08:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542421701678465024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067561776261, 8.759862662030919 ]
  },
  "id_str" : "542422624081432576",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn also to the guy feeding her please. :p",
  "id" : 542422624081432576,
  "in_reply_to_status_id" : 542421701678465024,
  "created_at" : "2014-12-09 20:56:45 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542404836835065857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.751931868280437 ]
  },
  "id_str" : "542421408513392642",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn send my greetings!",
  "id" : 542421408513392642,
  "in_reply_to_status_id" : 542404836835065857,
  "created_at" : "2014-12-09 20:51:56 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.752148984926752 ]
  },
  "id_str" : "542421020611592192",
  "text" : "\u00ABDass ich dir das Ohrl\u00E4ppchen abgebissen habe war keine Tat der Wut sondern eine der Lust!\u00BB \u2014 \u00ABJa, Lust mir das Ohrl\u00E4ppchen abzubei\u00DFen\u2026\u00BB",
  "id" : 542421020611592192,
  "created_at" : "2014-12-09 20:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.752896362408082 ]
  },
  "id_str" : "542420752079671296",
  "text" : "\u00ABIch hab heut Nacht getr\u00E4umt ich h\u00E4tte dir ein Ohrl\u00E4ppchen abgebissen!\u00BB \u2014 \u00ABAlles klar, Mike Tyson.\u00BB",
  "id" : 542420752079671296,
  "created_at" : "2014-12-09 20:49:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542387939771031554",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11535464538397, 8.750378368607844 ]
  },
  "id_str" : "542394016386392067",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy sure, betray the shell, that's fine. In that case you can always go for libre\/open office I\u2019d guess. ;-)",
  "id" : 542394016386392067,
  "in_reply_to_status_id" : 542387939771031554,
  "created_at" : "2014-12-09 19:03:05 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/HrfnAT1zJB",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/mind-guest-blog\/2014\/12\/09\/calling-it-sex-when-they-mean-love\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/mind-guest-blo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542387258515804160",
  "text" : "Calling It Sex When They Mean Love http:\/\/t.co\/HrfnAT1zJB",
  "id" : 542387258515804160,
  "created_at" : "2014-12-09 18:36:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/kENpEfv4Iz",
      "expanded_url" : "https:\/\/csvkit.readthedocs.org\/en\/latest\/",
      "display_url" : "csvkit.readthedocs.org\/en\/latest\/"
    } ]
  },
  "in_reply_to_status_id_str" : "542336076900478977",
  "geo" : { },
  "id_str" : "542336696474697728",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy what about? https:\/\/t.co\/kENpEfv4Iz :p",
  "id" : 542336696474697728,
  "in_reply_to_status_id" : 542336076900478977,
  "created_at" : "2014-12-09 15:15:19 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239585637953, 8.627547433243103 ]
  },
  "id_str" : "542333215173013505",
  "text" : "\u00ABOh, ich dachte du w\u00E4rest schon Postdoc.\u00BB \u2014 \u00ABWeil ich so allwissend bin?\u00BB \u2014 \u00ABNein, weil du so alt und verzweifelt aussiehst.\u00BB",
  "id" : 542333215173013505,
  "created_at" : "2014-12-09 15:01:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230706976115, 8.627431800299066 ]
  },
  "id_str" : "542324818214133761",
  "text" : "\u00ABSprich bitte in ganzen S\u00E4tzen.\u00BB \u2014 \u00ABAlter, das Hipster-Wort des Jahres ist auch kein ganzer Satz!\u00BB",
  "id" : 542324818214133761,
  "created_at" : "2014-12-09 14:28:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238990621185, 8.627470807103107 ]
  },
  "id_str" : "542306774901338112",
  "text" : "\u00ABIch gebe wegen Datenschutz mein Geschlecht &amp; Alter beim Evaluationsbogen nicht an!\u00BB \u2014 \u00ABDu bist also der eine Bogen ohne die beiden Infos.\u00BB",
  "id" : 542306774901338112,
  "created_at" : "2014-12-09 13:16:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/AnyiJRWAAu",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1768",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542268925594304512",
  "text" : "+1 on wisdom http:\/\/t.co\/AnyiJRWAAu",
  "id" : 542268925594304512,
  "created_at" : "2014-12-09 10:46:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542257649459671040",
  "text" : "\u00ABYou usually see lots of expression in brain &amp; testis.\u00BB \u2013 \u00ABI\u2019m sure you can be pretty expressive with both.\u00BB",
  "id" : 542257649459671040,
  "created_at" : "2014-12-09 10:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 108, 115 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542253125139447808",
  "geo" : { },
  "id_str" : "542253930781356032",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju a nice start though. Don\u2019t know any comparable studies on the microbial assemblages in food. Maybe @uBiome\u2019s crowd can follow up.",
  "id" : 542253930781356032,
  "in_reply_to_status_id" : 542253125139447808,
  "created_at" : "2014-12-09 09:46:26 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/3YYnGl4Zfg",
      "expanded_url" : "https:\/\/peerj.com\/articles\/659\/",
      "display_url" : "peerj.com\/articles\/659\/"
    } ]
  },
  "geo" : { },
  "id_str" : "542251995881824256",
  "text" : "The microbes we eat: abundance and taxonomy of microbes consumed in a day\u2019s worth of meals for three diet types https:\/\/t.co\/3YYnGl4Zfg",
  "id" : 542251995881824256,
  "created_at" : "2014-12-09 09:38:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/akbWyLrb29",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi%2F10.1371%2Fjournal.pone.0114253?utm_content=buffer4b849&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542247569678954496",
  "text" : "PERGA: A Paired-End Read Guided De Novo Assembler for Extending Contigs Using SVM and Look Ahead Approach http:\/\/t.co\/akbWyLrb29",
  "id" : 542247569678954496,
  "created_at" : "2014-12-09 09:21:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/O6xxNsNJsV",
      "expanded_url" : "http:\/\/proof.nationalgeographic.com\/2014\/12\/04\/the-magic-starts-here-kenjis-workshop-of-camera-wizardry\/",
      "display_url" : "proof.nationalgeographic.com\/2014\/12\/04\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542245152577056768",
  "text" : "Kenji\u2019s Workshop of Camera Wizardry http:\/\/t.co\/O6xxNsNJsV",
  "id" : 542245152577056768,
  "created_at" : "2014-12-09 09:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/PNcWMzmUbR",
      "expanded_url" : "http:\/\/mindhacks.com\/2014\/12\/08\/you-wont-find-the-data-in-my-pants\/",
      "display_url" : "mindhacks.com\/2014\/12\/08\/you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542242205470322688",
  "text" : "\u00ABYou won\u2019t find the data in my pants\u00BB How the sex lives of sex researchers were used to discredit their work. http:\/\/t.co\/PNcWMzmUbR",
  "id" : 542242205470322688,
  "created_at" : "2014-12-09 08:59:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/uaEXuZSoOW",
      "expanded_url" : "http:\/\/ncase.me\/polygons\/",
      "display_url" : "ncase.me\/polygons\/"
    } ]
  },
  "geo" : { },
  "id_str" : "542240757273600000",
  "text" : "\u00ABIn a world where bias ever existed, being unbiased isn't enough!\u00BB a playable post on the shape of society http:\/\/t.co\/uaEXuZSoOW",
  "id" : 542240757273600000,
  "created_at" : "2014-12-09 08:54:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/QoMzY1Eaox",
      "expanded_url" : "https:\/\/github.com\/ged-lab\/khmer\/releases\/tag\/v1.2",
      "display_url" : "github.com\/ged-lab\/khmer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542236090506440704",
  "text" : "Nice, v1.2 of khmer is now available! https:\/\/t.co\/QoMzY1Eaox",
  "id" : 542236090506440704,
  "created_at" : "2014-12-09 08:35:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language on the Move",
      "screen_name" : "Lg_on_the_Move",
      "indices" : [ 3, 18 ],
      "id_str" : "78578223",
      "id" : 78578223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Language",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "yallaCSU",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542235314740555776",
  "text" : "RT @Lg_on_the_Move: #Language ideological farce in Germany. #yallaCSU debate shows a mature multilingual &amp; mutlicultural society http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Language",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "yallaCSU",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/UaUtf4kHla",
        "expanded_url" : "http:\/\/ow.ly\/FAc0x",
        "display_url" : "ow.ly\/FAc0x"
      } ]
    },
    "geo" : { },
    "id_str" : "542207948723064833",
    "text" : "#Language ideological farce in Germany. #yallaCSU debate shows a mature multilingual &amp; mutlicultural society http:\/\/t.co\/UaUtf4kHla",
    "id" : 542207948723064833,
    "created_at" : "2014-12-09 06:43:43 +0000",
    "user" : {
      "name" : "Language on the Move",
      "screen_name" : "Lg_on_the_Move",
      "protected" : false,
      "id_str" : "78578223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673175205\/LotmLogoForEmily_normal.jpg",
      "id" : 78578223,
      "verified" : false
    }
  },
  "id" : 542235314740555776,
  "created_at" : "2014-12-09 08:32:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542230925250404352",
  "geo" : { },
  "id_str" : "542231014119325697",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, to Frankfurt. :-)",
  "id" : 542231014119325697,
  "in_reply_to_status_id" : 542230925250404352,
  "created_at" : "2014-12-09 08:15:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542224376801005569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234899526024, 8.627562634623622 ]
  },
  "id_str" : "542224713595252736",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so, when will you come for a visit? ;)",
  "id" : 542224713595252736,
  "in_reply_to_status_id" : 542224376801005569,
  "created_at" : "2014-12-09 07:50:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542189739156447232",
  "geo" : { },
  "id_str" : "542220725072195584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you\u2019re back in .de now? :)",
  "id" : 542220725072195584,
  "in_reply_to_status_id" : 542189739156447232,
  "created_at" : "2014-12-09 07:34:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/542086634918137856\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Wu6Gh5RYwF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4Xg6--CIAUDk4z.png",
      "id_str" : "542086634108231685",
      "id" : 542086634108231685,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4Xg6--CIAUDk4z.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/Wu6Gh5RYwF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542086348237447169",
  "geo" : { },
  "id_str" : "542086634918137856",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also not the kind of distribution I would have expected. http:\/\/t.co\/Wu6Gh5RYwF",
  "id" : 542086634918137856,
  "in_reply_to_status_id" : 542086348237447169,
  "created_at" : "2014-12-08 22:41:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542086348237447169",
  "text" : "people on openSNP who rated their sex drive as \u201Chigh\u201D also say their handwriting\/motorskills are \u201Cexcellent\u201D. maybe ppl are liars.",
  "id" : 542086348237447169,
  "created_at" : "2014-12-08 22:40:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542081491241795584",
  "text" : "According to the openSNP database: users who aren\u2019t a duck never had a heart attack.",
  "id" : 542081491241795584,
  "created_at" : "2014-12-08 22:21:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/bgzUH0v3ov",
      "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/266",
      "display_url" : "opensnp.org\/phenotypes\/266"
    } ]
  },
  "geo" : { },
  "id_str" : "542080980228788224",
  "text" : "\u00ABWhat is your variation at phenotype \u2018Am I a duck??\u2019\u00BB Maybe openSNP is trying to figure out something else. https:\/\/t.co\/bgzUH0v3ov",
  "id" : 542080980228788224,
  "created_at" : "2014-12-08 22:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542080546458054656",
  "text" : "\u00ABwhat sexual type(s) do you fantasize about when masturbating?\u00BB openSNP \u2018phenotypes\u2019, are they testing whether I'm a replicant or a lesbian?",
  "id" : 542080546458054656,
  "created_at" : "2014-12-08 22:17:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bolser",
      "screen_name" : "danbolser",
      "indices" : [ 0, 10 ],
      "id_str" : "16325864",
      "id" : 16325864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541264203651506176",
  "geo" : { },
  "id_str" : "542071439772626944",
  "in_reply_to_user_id" : 16325864,
  "text" : "@danbolser oh wow, I hadn\u2019t seen that one before. Well played!",
  "id" : 542071439772626944,
  "in_reply_to_status_id" : 541264203651506176,
  "created_at" : "2014-12-08 21:41:17 +0000",
  "in_reply_to_screen_name" : "danbolser",
  "in_reply_to_user_id_str" : "16325864",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "542029747388436480",
  "geo" : { },
  "id_str" : "542054570000920576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer all the best for the two of you! :)",
  "id" : 542054570000920576,
  "in_reply_to_status_id" : 542029747388436480,
  "created_at" : "2014-12-08 20:34:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541973571724406785",
  "geo" : { },
  "id_str" : "541974163377106944",
  "in_reply_to_user_id" : 14286491,
  "text" : "Next up npg will announce \u201CRailCube\u201D. Just board this cube that moves on railway tracks to visit the author to ask about his or hers paper.",
  "id" : 541974163377106944,
  "in_reply_to_status_id" : 541973571724406785,
  "created_at" : "2014-12-08 15:14:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/465R9HGg8z",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/12\/08\/nature-to-provide-open-access-to-articles-using-noat-technology\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/12\/08\/nat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723163764, 8.6275809462 ]
  },
  "id_str" : "541973571724406785",
  "text" : "I didn\u2019t know Nature was extending its portfolio. After ReadCube there\u2019s the ReadOutLoudCube! http:\/\/t.co\/465R9HGg8z",
  "id" : 541973571724406785,
  "created_at" : "2014-12-08 15:12:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541963331423449089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722983837, 8.6273292673 ]
  },
  "id_str" : "541965309293641728",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest ja, mache eigentlich nicht ich, aber ab und zu Vertretung.",
  "id" : 541965309293641728,
  "in_reply_to_status_id" : 541963331423449089,
  "created_at" : "2014-12-08 14:39:33 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 8, 15 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541960657739202560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723067834, 8.6274323853 ]
  },
  "id_str" : "541961650858131456",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest @lsanoj im 2. Semester sehen wir uns dann vermutlich.",
  "id" : 541961650858131456,
  "in_reply_to_status_id" : 541960657739202560,
  "created_at" : "2014-12-08 14:25:01 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/8LB6DANVMF",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/life\/family\/2014\/12\/linda_tirado_on_the_realities_of_living_in_bootstrap_america_daily_annoyances.html?wpsrc=sh_all_dt_tw_top",
      "display_url" : "slate.com\/articles\/life\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724494971, 8.6273898883 ]
  },
  "id_str" : "541934038182006784",
  "text" : "Saving money costs money. Period. http:\/\/t.co\/8LB6DANVMF",
  "id" : 541934038182006784,
  "created_at" : "2014-12-08 12:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541903599228698624",
  "text" : "\u2018Scientific Reasoning: The Bayesian Approach\u2019 quickly goes over Popper, Feyerabend &amp; Lakatos before dumping prob. calculus onto the reader.",
  "id" : 541903599228698624,
  "created_at" : "2014-12-08 10:34:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541896484103655424",
  "text" : "\u00ABA word to the wise, that is, to those who have at some point consulted textbooks of probability, elementary or advanced.\u00BB",
  "id" : 541896484103655424,
  "created_at" : "2014-12-08 10:06:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 85, 97 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/VVPjeZRD8V",
      "expanded_url" : "http:\/\/blog.lostpropertyhq.com\/postgres-full-text-search-is-good-enough\/",
      "display_url" : "blog.lostpropertyhq.com\/postgres-full-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541888355869655040",
  "text" : "PostgreSQL full-text search is Good Enough. http:\/\/t.co\/VVPjeZRD8V \/cc @PhilippBayer @helgerausch",
  "id" : 541888355869655040,
  "created_at" : "2014-12-08 09:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/6wAUoutKVX",
      "expanded_url" : "http:\/\/loonylabs.org\/2014\/12\/07\/left-handed-earnings\/",
      "display_url" : "loonylabs.org\/2014\/12\/07\/lef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541871763777667072",
  "text" : "\u00ABLefties exhibit economically and statistically significant human capital deficits relative to righties\u00BB http:\/\/t.co\/6wAUoutKVX",
  "id" : 541871763777667072,
  "created_at" : "2014-12-08 08:27:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541869574040616960",
  "geo" : { },
  "id_str" : "541870623761653760",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule falls mein Arbeitskreis eine Sitcom machen sollte w\u00FCrde ich B.A.S.H. als Namen vorschlagen.",
  "id" : 541870623761653760,
  "in_reply_to_status_id" : 541869574040616960,
  "created_at" : "2014-12-08 08:23:18 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723331781, 8.6275867118 ]
  },
  "id_str" : "541869392955723777",
  "text" : "\u00ABWas hab ich gerade gemacht?\u00BB \u2014 \u00ABS\u00FC\u00DFstoff in die Milch geworfen. Aber bitte frag mich nicht wieso.\u00BB",
  "id" : 541869392955723777,
  "created_at" : "2014-12-08 08:18:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NNpCsEmIi9",
      "expanded_url" : "http:\/\/oglaf.com\/dont\/",
      "display_url" : "oglaf.com\/dont\/"
    } ]
  },
  "geo" : { },
  "id_str" : "541864737555099648",
  "text" : "\u00ABwe support harm minimisation for face-sitting. Make free snorkels available.\u00BB http:\/\/t.co\/NNpCsEmIi9",
  "id" : 541864737555099648,
  "created_at" : "2014-12-08 07:59:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/K7hCoN8cUo",
      "expanded_url" : "http:\/\/pgbovine.net\/programmers-talking-to-beginners.htm",
      "display_url" : "pgbovine.net\/programmers-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541863423110553600",
  "text" : "Programmers: Please don't ever say this to beginners ... http:\/\/t.co\/K7hCoN8cUo",
  "id" : 541863423110553600,
  "created_at" : "2014-12-08 07:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ZDPlKsThr3",
      "expanded_url" : "http:\/\/www.oleksyk.com\/why-there-cant-be-a-perfect-human-from-puerto-rico-or-anywhere-else\/",
      "display_url" : "oleksyk.com\/why-there-cant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541861951371243520",
  "text" : "\u00ABThere are many reasons why perfect humans cannot exist, neither in Puerto Rico or anywhere else.\u00BB http:\/\/t.co\/ZDPlKsThr3",
  "id" : 541861951371243520,
  "created_at" : "2014-12-08 07:48:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110680331, 8.7598479197 ]
  },
  "id_str" : "541674318569431041",
  "text" : "\u00ABIch komm gleich r\u00FCber ins Bett, zum L\u00F6cher stopfen. Also, in Klamotten!\u00BB \u2014 \u00ABAch, meinetwegen kannst du dabei auch Klamotten tragen.\u00BB",
  "id" : 541674318569431041,
  "created_at" : "2014-12-07 19:23:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 3, 15 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541654990352556032",
  "text" : "RT @3rdreviewer: \"All finished genomes are alike; each draft genome is crappy in its own way.\"\n--L. Tolstoy @shoutybrown @PeroMHC @BioMickW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dennis Moore",
        "screen_name" : "peromhc",
        "indices" : [ 104, 112 ],
        "id_str" : "4302347242",
        "id" : 4302347242
      }, {
        "name" : "Mick Watson",
        "screen_name" : "BioMickWatson",
        "indices" : [ 113, 127 ],
        "id_str" : "228586748",
        "id" : 228586748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "541400375837077504",
    "text" : "\"All finished genomes are alike; each draft genome is crappy in its own way.\"\n--L. Tolstoy @shoutybrown @PeroMHC @BioMickWatson",
    "id" : 541400375837077504,
    "created_at" : "2014-12-07 01:14:42 +0000",
    "user" : {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "protected" : false,
      "id_str" : "2678236062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492467467474583552\/eZiwdLds_normal.png",
      "id" : 2678236062,
      "verified" : false
    }
  },
  "id" : 541654990352556032,
  "created_at" : "2014-12-07 18:06:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wanderlust",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021096 ]
  },
  "id_str" : "541634749077671937",
  "text" : "\u00ABIt\u2019s the unpredictable incidents between official events that add up to a life, the incalculable that gives it value.\u00BB #wanderlust",
  "id" : 541634749077671937,
  "created_at" : "2014-12-07 16:46:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541590277820268544",
  "geo" : { },
  "id_str" : "541590698274078720",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Das hab ich schon, damit bin ich durch die ersten 4 Semester gekommen!",
  "id" : 541590698274078720,
  "in_reply_to_status_id" : 541590277820268544,
  "created_at" : "2014-12-07 13:50:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/SiDktedprM",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/grrlscientist\/2013\/dec\/24\/grrlscientist-mistletoe-kissing-myths",
      "display_url" : "theguardian.com\/science\/grrlsc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541583774409310208",
  "text" : "Why do we kiss under the mistletoe? http:\/\/t.co\/SiDktedprM",
  "id" : 541583774409310208,
  "created_at" : "2014-12-07 13:23:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/LxHHq0JBVS",
      "expanded_url" : "http:\/\/www.toysrus.com\/graphics\/product_images\/pTRU1-2789219dt.jpg",
      "display_url" : "toysrus.com\/graphics\/produ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "541581271626182656",
  "geo" : { },
  "id_str" : "541581656055107584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Zu Weihnachten schenke ich dir einfach eins, damit du dich wieder zuhause f\u00FChlst. http:\/\/t.co\/LxHHq0JBVS",
  "id" : 541581656055107584,
  "in_reply_to_status_id" : 541581271626182656,
  "created_at" : "2014-12-07 13:15:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143357344, 8.753456343 ]
  },
  "id_str" : "541561221556998145",
  "text" : "\u00ABDu Arme, hast immer nur Skills gelernt die danach ausgestorben sind! Handw\u00E4sche, Journalismus, \u2026\u00BB",
  "id" : 541561221556998145,
  "created_at" : "2014-12-07 11:53:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/S3WrXzbaYo",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=cLGUFaizAHs",
      "display_url" : "youtube.com\/watch?v=cLGUFa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "541531183008718848",
  "text" : "All About That Paste: \u00ABNever dip a carrot or tortilla. Hummus is like Katniss: it needs pita.\u00BB https:\/\/t.co\/S3WrXzbaYo",
  "id" : 541531183008718848,
  "created_at" : "2014-12-07 09:54:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiglitzerfee\uD83D\uDC19",
      "screen_name" : "Molossoidea",
      "indices" : [ 0, 12 ],
      "id_str" : "1874599292",
      "id" : 1874599292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541359773929992193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1089912679, 8.4535361937 ]
  },
  "id_str" : "541399077939056640",
  "in_reply_to_user_id" : 1874599292,
  "text" : "@Molossoidea oh, das nenne ich mal ein Kompliment. :)",
  "id" : 541399077939056640,
  "in_reply_to_status_id" : 541359773929992193,
  "created_at" : "2014-12-07 01:09:33 +0000",
  "in_reply_to_screen_name" : "Molossoidea",
  "in_reply_to_user_id_str" : "1874599292",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/H2IrCZpjD7",
      "expanded_url" : "http:\/\/online.wsj.com\/articles\/photos-destruction-in-kobani-1417658520",
      "display_url" : "online.wsj.com\/articles\/photo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113978, 8.753369 ]
  },
  "id_str" : "541277921378594816",
  "text" : "Destruction in Kobani http:\/\/t.co\/H2IrCZpjD7",
  "id" : 541277921378594816,
  "created_at" : "2014-12-06 17:08:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 3, 11 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Oatmeal\/status\/540933280028459008\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/eA2OD8Yp2t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4HH84SIIAAMmUA.png",
      "id_str" : "540933278975664128",
      "id" : 540933278975664128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4HH84SIIAAMmUA.png",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/eA2OD8Yp2t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/osx2bjhm1I",
      "expanded_url" : "http:\/\/theoatmeal.com\/blog\/jibbers_crabst",
      "display_url" : "theoatmeal.com\/blog\/jibbers_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "541275830534807553",
  "text" : "RT @Oatmeal: NEW: I do not believe in Charles Darwin's theory of natural selection http:\/\/t.co\/osx2bjhm1I http:\/\/t.co\/eA2OD8Yp2t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Oatmeal\/status\/540933280028459008\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/eA2OD8Yp2t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4HH84SIIAAMmUA.png",
        "id_str" : "540933278975664128",
        "id" : 540933278975664128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4HH84SIIAAMmUA.png",
        "sizes" : [ {
          "h" : 290,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/eA2OD8Yp2t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/osx2bjhm1I",
        "expanded_url" : "http:\/\/theoatmeal.com\/blog\/jibbers_crabst",
        "display_url" : "theoatmeal.com\/blog\/jibbers_c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540933280028459008",
    "text" : "NEW: I do not believe in Charles Darwin's theory of natural selection http:\/\/t.co\/osx2bjhm1I http:\/\/t.co\/eA2OD8Yp2t",
    "id" : 540933280028459008,
    "created_at" : "2014-12-05 18:18:38 +0000",
    "user" : {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "protected" : false,
      "id_str" : "4519121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793613884053532674\/teYItBjT_normal.jpg",
      "id" : 4519121,
      "verified" : true
    }
  },
  "id" : 541275830534807553,
  "created_at" : "2014-12-06 16:59:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "541265888427917313",
  "geo" : { },
  "id_str" : "541266045429088256",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj nicht mehr lang und ich komm r\u00FCber auf deine dunkle Seite!",
  "id" : 541266045429088256,
  "in_reply_to_status_id" : 541265888427917313,
  "created_at" : "2014-12-06 16:20:56 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1122581727, 8.756438055 ]
  },
  "id_str" : "541265426811195392",
  "text" : "Weltuntergang: Wildfremde Menschen, die meine Haarfarbe positiv kommentieren wollen, siezen mich jetzt.",
  "id" : 541265426811195392,
  "created_at" : "2014-12-06 16:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "541197608103186432",
  "text" : "\u00ABDer Shemale-Account des Tierheims wurde gehackt?!\u00BB \u2014 \u00ABGMail!\u00BB",
  "id" : 541197608103186432,
  "created_at" : "2014-12-06 11:48:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/VTDQL0jaAE",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/12\/05\/cat-loves-slayer.html",
      "display_url" : "boingboing.net\/2014\/12\/05\/cat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540983455241502720",
  "text" : "Looks like he wants to do a cover: \u2018Dogs Hate Us All\u2019 http:\/\/t.co\/VTDQL0jaAE",
  "id" : 540983455241502720,
  "created_at" : "2014-12-05 21:38:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 3, 16 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/RtSHjeX0xO",
      "expanded_url" : "http:\/\/buff.ly\/1FTKkQX",
      "display_url" : "buff.ly\/1FTKkQX"
    } ]
  },
  "geo" : { },
  "id_str" : "540918317859753984",
  "text" : "RT @assemblathon: 3 word summary of new PLOS Computational Biology paper: genome assemblies suck http:\/\/t.co\/RtSHjeX0xO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/RtSHjeX0xO",
        "expanded_url" : "http:\/\/buff.ly\/1FTKkQX",
        "display_url" : "buff.ly\/1FTKkQX"
      } ]
    },
    "geo" : { },
    "id_str" : "540913531919794177",
    "text" : "3 word summary of new PLOS Computational Biology paper: genome assemblies suck http:\/\/t.co\/RtSHjeX0xO",
    "id" : 540913531919794177,
    "created_at" : "2014-12-05 17:00:10 +0000",
    "user" : {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "protected" : false,
      "id_str" : "216793572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458989689794355202\/qgt5fqB4_normal.jpeg",
      "id" : 216793572,
      "verified" : false
    }
  },
  "id" : 540918317859753984,
  "created_at" : "2014-12-05 17:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540890977679187968",
  "geo" : { },
  "id_str" : "540891059380047873",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher thanks a lot. :-)",
  "id" : 540891059380047873,
  "in_reply_to_status_id" : 540890977679187968,
  "created_at" : "2014-12-05 15:30:52 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540888523008925696",
  "text" : "Reading an obscure Swedish mycology journal which you can only access by manually manipulating their URLs\u2026",
  "id" : 540888523008925696,
  "created_at" : "2014-12-05 15:20:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540884850589589504",
  "geo" : { },
  "id_str" : "540885539080380416",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon danke f\u00FCrs nachschauen :-)",
  "id" : 540885539080380416,
  "in_reply_to_status_id" : 540884850589589504,
  "created_at" : "2014-12-05 15:08:56 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lambert Heller \uD83E\uDD14",
      "screen_name" : "Lambo",
      "indices" : [ 129, 135 ],
      "id_str" : "284553",
      "id" : 284553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/pduHBexcsz",
      "expanded_url" : "https:\/\/themanual.org\/read\/issues\/4\/paul-ford\/article",
      "display_url" : "themanual.org\/read\/issues\/4\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540859378652696576",
  "text" : "\u00ABFor a fan of file formats, it is a golden age.\u00BB Though it could be about bioinformatics, it isn\u2019t! https:\/\/t.co\/pduHBexcsz \/via @Lambo",
  "id" : 540859378652696576,
  "created_at" : "2014-12-05 13:24:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/klFh1vz9eS",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003998",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540807967143374848",
  "text" : "News at 11 (at least in CET): Extensive Error in the Number of Genes Inferred from Draft Genome Assemblies http:\/\/t.co\/klFh1vz9eS",
  "id" : 540807967143374848,
  "created_at" : "2014-12-05 10:00:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/v4LapWeOsW",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003954",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540800752726589440",
  "text" : "Ten Simple Rules for Finishing Your PhD http:\/\/t.co\/v4LapWeOsW",
  "id" : 540800752726589440,
  "created_at" : "2014-12-05 09:32:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "guan",
      "screen_name" : "guan",
      "indices" : [ 3, 8 ],
      "id_str" : "6631",
      "id" : 6631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/guan\/status\/540645070450728960\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WpjMtag1oT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4DB068IAAA2rB0.jpg",
      "id_str" : "540645070203256832",
      "id" : 540645070203256832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4DB068IAAA2rB0.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/WpjMtag1oT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540783112306049024",
  "text" : "RT @guan: SCIENCE http:\/\/t.co\/WpjMtag1oT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/guan\/status\/540645070450728960\/photo\/1",
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/WpjMtag1oT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4DB068IAAA2rB0.jpg",
        "id_str" : "540645070203256832",
        "id" : 540645070203256832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4DB068IAAA2rB0.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 994
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 994
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 994
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/WpjMtag1oT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540645070450728960",
    "text" : "SCIENCE http:\/\/t.co\/WpjMtag1oT",
    "id" : 540645070450728960,
    "created_at" : "2014-12-04 23:13:24 +0000",
    "user" : {
      "name" : "guan",
      "screen_name" : "guan",
      "protected" : false,
      "id_str" : "6631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490519101865881600\/WbTVPIp-_normal.jpeg",
      "id" : 6631,
      "verified" : false
    }
  },
  "id" : 540783112306049024,
  "created_at" : "2014-12-05 08:21:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "indices" : [ 3, 12 ],
      "id_str" : "8779352",
      "id" : 8779352
    }, {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 54, 69 ],
      "id_str" : "14126701",
      "id" : 14126701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540603755470024704",
  "text" : "RT @sjackman: Fantastic slides! How'd you draw t'art? @bioinformatics Slides on ranking genomes assemblers with Docker containers. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Barton",
        "screen_name" : "bioinformatics",
        "indices" : [ 40, 55 ],
        "id_str" : "14126701",
        "id" : 14126701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/CXhrbYayIU",
        "expanded_url" : "https:\/\/speakerdeck.com\/michaelbarton\/ranking-genome-assemblers-with-docker-containers-dockercon-eu-2014",
        "display_url" : "speakerdeck.com\/michaelbarton\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "540509644628971521",
    "geo" : { },
    "id_str" : "540602230903029760",
    "in_reply_to_user_id" : 14126701,
    "text" : "Fantastic slides! How'd you draw t'art? @bioinformatics Slides on ranking genomes assemblers with Docker containers. https:\/\/t.co\/CXhrbYayIU",
    "id" : 540602230903029760,
    "in_reply_to_status_id" : 540509644628971521,
    "created_at" : "2014-12-04 20:23:10 +0000",
    "in_reply_to_screen_name" : "bioinformatics",
    "in_reply_to_user_id_str" : "14126701",
    "user" : {
      "name" : "Shaun Jackman",
      "screen_name" : "sjackman",
      "protected" : false,
      "id_str" : "8779352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751888643460063232\/MfIOaNw2_normal.jpg",
      "id" : 8779352,
      "verified" : false
    }
  },
  "id" : 540603755470024704,
  "created_at" : "2014-12-04 20:29:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juergen Fesslmeier",
      "screen_name" : "chinshr",
      "indices" : [ 3, 11 ],
      "id_str" : "6513002",
      "id" : 6513002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540586814567112705",
  "text" : "RT @chinshr: Multi- language keyboard+auto correct drives polyglot people crazy: word scramble..at least it should remember language contex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.5982788066, -122.3856388127 ]
    },
    "id_str" : "540549172596719616",
    "text" : "Multi- language keyboard+auto correct drives polyglot people crazy: word scramble..at least it should remember language context consistently",
    "id" : 540549172596719616,
    "created_at" : "2014-12-04 16:52:20 +0000",
    "user" : {
      "name" : "Juergen Fesslmeier",
      "screen_name" : "chinshr",
      "protected" : false,
      "id_str" : "6513002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3528909495\/379186a350cda9aafad6fde86825d389_normal.png",
      "id" : 6513002,
      "verified" : false
    }
  },
  "id" : 540586814567112705,
  "created_at" : "2014-12-04 19:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Q39oiGMrb7",
      "expanded_url" : "http:\/\/instagram.com\/p\/wMTKIEhwpi\/",
      "display_url" : "instagram.com\/p\/wMTKIEhwpi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "540549149976821761",
  "text" : "Academics are not easily disoriented in the real world. That's why we need to draw down where we\u2026 http:\/\/t.co\/Q39oiGMrb7",
  "id" : 540549149976821761,
  "created_at" : "2014-12-04 16:52:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237986262276, 8.627558960896238 ]
  },
  "id_str" : "540539607822381056",
  "text" : "Habemus Dremel \\o\/ (now for a dremelfuge)",
  "id" : 540539607822381056,
  "created_at" : "2014-12-04 16:14:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540472762759139328",
  "text" : "Lichen bioterrorists: \u00ABthe project was delayed as a result of genomic DNA being confiscated by US authorities as a bioterrorist threat\u00BB",
  "id" : 540472762759139328,
  "created_at" : "2014-12-04 11:48:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540459790380437504",
  "geo" : { },
  "id_str" : "540459875319685120",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot immer nur der Nase nach.",
  "id" : 540459875319685120,
  "in_reply_to_status_id" : 540459790380437504,
  "created_at" : "2014-12-04 10:57:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540459812036046848",
  "text" : "TIL: there are zero publications containing \u201Cfartobiome\u201D. I might have found a badomics research niche.",
  "id" : 540459812036046848,
  "created_at" : "2014-12-04 10:57:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540458123350523904",
  "geo" : { },
  "id_str" : "540459118855987200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich \u201Cflatus microbiome\u201D -&gt; 717 hits on google scholar.",
  "id" : 540459118855987200,
  "in_reply_to_status_id" : 540458123350523904,
  "created_at" : "2014-12-04 10:54:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723631407, 8.6275418433 ]
  },
  "id_str" : "540457737759756288",
  "text" : "\u00ABDuring a recent experiment by the ESA, lichen astronauts were placed on board a rocket and launched into space.\u00BB",
  "id" : 540457737759756288,
  "created_at" : "2014-12-04 10:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540456526818070528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235448252563, 8.62753115803695 ]
  },
  "id_str" : "540456906415173632",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot meine Daten verrauchen zu W\u00E4rme in den Erfassungsger\u00E4ten!",
  "id" : 540456906415173632,
  "in_reply_to_status_id" : 540456526818070528,
  "created_at" : "2014-12-04 10:45:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172346752, 8.6275695386 ]
  },
  "id_str" : "540456190883667969",
  "text" : "There are people studying the coolest shit: \u00ABViable fungal and algal cells were shown to be found in fecal pellets of lichenivorous slugs.\u00BB",
  "id" : 540456190883667969,
  "created_at" : "2014-12-04 10:42:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540454750551310336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234675198584, 8.627569538616559 ]
  },
  "id_str" : "540455805460697088",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das tue ich ja schon, nur halt im Serverraum. :3",
  "id" : 540455805460697088,
  "in_reply_to_status_id" : 540454750551310336,
  "created_at" : "2014-12-04 10:41:19 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238021603913, 8.627542495028338 ]
  },
  "id_str" : "540454279497388032",
  "text" : "\u00ABWir k\u00F6nnten Heizstrahler auf die Dachterrasse stellen!\u00BB\u2014\u00ABJetzt wei\u00DF ich auch wieso wir nicht ans Institut f\u00FCr \u00D6kologie angeschlossen sind.\u00BB",
  "id" : 540454279497388032,
  "created_at" : "2014-12-04 10:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ngq1j299MZ",
      "expanded_url" : "http:\/\/www.theallium.com\/science-life\/grad-student-has-recurring-sex-dream-involving-centrifuge\/",
      "display_url" : "theallium.com\/science-life\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540444318193184768",
  "text" : "\u00ABits not natural to be sexually attracted to a piece of lab equipment, no matter how erotic its behavior is, is it?\u00BB http:\/\/t.co\/ngq1j299MZ",
  "id" : 540444318193184768,
  "created_at" : "2014-12-04 09:55:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "Peter Murray-Rust",
      "screen_name" : "petermurrayrust",
      "indices" : [ 13, 29 ],
      "id_str" : "25676709",
      "id" : 25676709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/QflDmP10dF",
      "expanded_url" : "http:\/\/blogs.ch.cam.ac.uk\/pmr\/2014\/12\/03\/natures-fauxpen-access-leaves-me-very-sad-and-very-angry\/",
      "display_url" : "blogs.ch.cam.ac.uk\/pmr\/2014\/12\/03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540425441405063168",
  "text" : "RT @brembs: .@petermurrayrust Nature's fauxpen access leaves me very sad and very angry. http:\/\/t.co\/QflDmP10dF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Murray-Rust",
        "screen_name" : "petermurrayrust",
        "indices" : [ 1, 17 ],
        "id_str" : "25676709",
        "id" : 25676709
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/QflDmP10dF",
        "expanded_url" : "http:\/\/blogs.ch.cam.ac.uk\/pmr\/2014\/12\/03\/natures-fauxpen-access-leaves-me-very-sad-and-very-angry\/",
        "display_url" : "blogs.ch.cam.ac.uk\/pmr\/2014\/12\/03\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540423175059042305",
    "text" : ".@petermurrayrust Nature's fauxpen access leaves me very sad and very angry. http:\/\/t.co\/QflDmP10dF",
    "id" : 540423175059042305,
    "created_at" : "2014-12-04 08:31:40 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 540425441405063168,
  "created_at" : "2014-12-04 08:40:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cguQD0VQ8j",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2013\/08\/06\/bioinformatics-is-not-something-you-are-taught-its-a-way-of-life\/",
      "display_url" : "biomickwatson.wordpress.com\/2013\/08\/06\/bio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540421373970358272",
  "text" : "Why I\u2019m usually unprepared for bioinformatics courses I give: so the participants and I have to google together. https:\/\/t.co\/cguQD0VQ8j",
  "id" : 540421373970358272,
  "created_at" : "2014-12-04 08:24:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540280993861865472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.75936323 ]
  },
  "id_str" : "540283052245917698",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC how about both? After all, science does have a tradition of self-experimentation.",
  "id" : 540283052245917698,
  "in_reply_to_status_id" : 540280993861865472,
  "created_at" : "2014-12-03 23:14:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540156338102603776",
  "geo" : { },
  "id_str" : "540156648606957570",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown but yes, it would reduce the confusion by a good margin :-)",
  "id" : 540156648606957570,
  "in_reply_to_status_id" : 540156338102603776,
  "created_at" : "2014-12-03 14:52:35 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540156338102603776",
  "geo" : { },
  "id_str" : "540156576599121920",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown I think the part I quoted would still sound like they would be somewhat directly connected.",
  "id" : 540156576599121920,
  "in_reply_to_status_id" : 540156338102603776,
  "created_at" : "2014-12-03 14:52:18 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540152005659197441",
  "geo" : { },
  "id_str" : "540156071864958977",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown thanks, in that case I didn\u2019t miss any obvious connection of the diginorm-k and the assembly-k. :-)",
  "id" : 540156071864958977,
  "in_reply_to_status_id" : 540152005659197441,
  "created_at" : "2014-12-03 14:50:17 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540150931724455936",
  "geo" : { },
  "id_str" : "540151846351147008",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown \u201C[\u2026] digital normalization may be removing 26-mers\u201D. [2\/2]",
  "id" : 540151846351147008,
  "in_reply_to_status_id" : 540150931724455936,
  "created_at" : "2014-12-03 14:33:30 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540150931724455936",
  "geo" : { },
  "id_str" : "540151797101637632",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown thanks, just wondered due to \u201CTrinity only permits k=26 for assembly, while normalization was performed\nat k=20;[\u2026]\u201D [1\/2]",
  "id" : 540151797101637632,
  "in_reply_to_status_id" : 540150931724455936,
  "created_at" : "2014-12-03 14:33:18 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Zh93ixq3wY",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1203.4802",
      "display_url" : "arxiv.org\/abs\/1203.4802"
    } ]
  },
  "in_reply_to_status_id_str" : "540144094597885953",
  "geo" : { },
  "id_str" : "540149711848882177",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown oh btw re: http:\/\/t.co\/Zh93ixq3wY. did you try whether using a diginorm-k=26 improves trinity-results?",
  "id" : 540149711848882177,
  "in_reply_to_status_id" : 540144094597885953,
  "created_at" : "2014-12-03 14:25:01 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540144094597885953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236121376028, 8.627545457714083 ]
  },
  "id_str" : "540145230499291136",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown I\u2019m not sure how much useful input I can add. But I\u2019m willing to give it a try.",
  "id" : 540145230499291136,
  "in_reply_to_status_id" : 540144094597885953,
  "created_at" : "2014-12-03 14:07:13 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540137930640359425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723486349, 8.6275476057 ]
  },
  "id_str" : "540138148307931136",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown \u201Con\u201D, have now discussed normalization, error correction and partitioning. :-)",
  "id" : 540138148307931136,
  "in_reply_to_status_id" : 540137930640359425,
  "created_at" : "2014-12-03 13:39:04 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 68, 80 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540133035526864897",
  "text" : "\u00ABAnother paper on khmer? Maybe we should rename our journal club to @ctitusbrown reading group.\u00BB",
  "id" : 540133035526864897,
  "created_at" : "2014-12-03 13:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241153152162, 8.627476614511203 ]
  },
  "id_str" : "540113401377464320",
  "text" : "\u00ABDa ist fast keine Butter in dem Kuchen. Nur im Boden um die Butterkekse zusammenzuhalten!\u00BB",
  "id" : 540113401377464320,
  "created_at" : "2014-12-03 12:00:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/smabMUUFnX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5ffZgq3yvB0",
      "display_url" : "youtube.com\/watch?v=5ffZgq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539903159670685696",
  "text" : "Beta as Fuck https:\/\/t.co\/smabMUUFnX",
  "id" : 539903159670685696,
  "created_at" : "2014-12-02 22:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 8, 17 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NRrIUIEPR9",
      "expanded_url" : "http:\/\/del-fi.org\/post\/104125242971\/natures-shareware-moment",
      "display_url" : "del-fi.org\/post\/104125242\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "539838236760473600",
  "geo" : { },
  "id_str" : "539839047989211137",
  "in_reply_to_user_id" : 14286491,
  "text" : "I guess @wilbanks said it all, wrt to this: \u00ABIt\u2019s a canonization of a system that privileges the wealthy academic.\u00BB http:\/\/t.co\/NRrIUIEPR9",
  "id" : 539839047989211137,
  "in_reply_to_status_id" : 539838236760473600,
  "created_at" : "2014-12-02 17:50:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/idOysKavn7",
      "expanded_url" : "http:\/\/www.nature.com\/news\/nature-makes-all-articles-free-to-view-1.16460",
      "display_url" : "nature.com\/news\/nature-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539838236760473600",
  "text" : "Oh Nature, I still prefer \u2018using clumsy, time-consuming practices\u2019, if it means I can do wtf I like\u2026 http:\/\/t.co\/idOysKavn7",
  "id" : 539838236760473600,
  "created_at" : "2014-12-02 17:47:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/kVqBPWgglX",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/languages-adapt-to-their-contextual-niche-winters-kirby-smith-2014\/10010.html",
      "display_url" : "replicatedtypo.com\/languages-adap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539832764774612992",
  "text" : "Languages adapt to their contextual niche http:\/\/t.co\/kVqBPWgglX",
  "id" : 539832764774612992,
  "created_at" : "2014-12-02 17:25:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/OBSpoM1Y7z",
      "expanded_url" : "http:\/\/musicfordeckchairs.wordpress.com\/2014\/12\/02\/wider-lessons\/",
      "display_url" : "musicfordeckchairs.wordpress.com\/2014\/12\/02\/wid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539705936672489472",
  "text" : "\u00ABThey will give you their health, their family time, [\u2026], their creativity, their sleep\u00BB http:\/\/t.co\/OBSpoM1Y7z",
  "id" : 539705936672489472,
  "created_at" : "2014-12-02 09:01:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539686612234694656",
  "text" : "Wondered whether somebody already investigated a certain problem. A quick Google search only finds my own research. Guess that\u2019s a \u201Cno\u201D.",
  "id" : 539686612234694656,
  "created_at" : "2014-12-02 07:44:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 3, 14 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PwzfoIEL4V",
      "expanded_url" : "http:\/\/biologydirect.com\/content\/10\/1\/25\/abstract",
      "display_url" : "biologydirect.com\/content\/10\/1\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539522223120601088",
  "text" : "RT @KlassenLab: A rebuttal of the paper linking the microbiome to religious practices http:\/\/t.co\/PwzfoIEL4V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/PwzfoIEL4V",
        "expanded_url" : "http:\/\/biologydirect.com\/content\/10\/1\/25\/abstract",
        "display_url" : "biologydirect.com\/content\/10\/1\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "539478181053755392",
    "text" : "A rebuttal of the paper linking the microbiome to religious practices http:\/\/t.co\/PwzfoIEL4V",
    "id" : 539478181053755392,
    "created_at" : "2014-12-01 17:56:36 +0000",
    "user" : {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "protected" : false,
      "id_str" : "1421096077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3646045844\/592d1e7e3213d41bfa24aa3e75c27aa7_normal.jpeg",
      "id" : 1421096077,
      "verified" : false
    }
  },
  "id" : 539522223120601088,
  "created_at" : "2014-12-01 20:51:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/8AZ6UR7t3o",
      "expanded_url" : "http:\/\/www.27bslash6.com\/interviews.html",
      "display_url" : "27bslash6.com\/interviews.html"
    } ]
  },
  "geo" : { },
  "id_str" : "539521149286498305",
  "text" : "\u00ABWorking in the design &amp; advertising industry is most like being\u2026\u00BB http:\/\/t.co\/8AZ6UR7t3o",
  "id" : 539521149286498305,
  "created_at" : "2014-12-01 20:47:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/X3roe9F257",
      "expanded_url" : "http:\/\/medicalxpress.com\/news\/2014-12-jane-austen-evolutionary-psychologist.html",
      "display_url" : "medicalxpress.com\/news\/2014-12-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539519780693499904",
  "text" : "I wonder why no one takes evolutionary psychologists seriously. Oh wait, I don\u2019t\u2026 http:\/\/t.co\/X3roe9F257",
  "id" : 539519780693499904,
  "created_at" : "2014-12-01 20:41:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539516734060109824",
  "geo" : { },
  "id_str" : "539517672833421312",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC care for a collaboration?",
  "id" : 539517672833421312,
  "in_reply_to_status_id" : 539516734060109824,
  "created_at" : "2014-12-01 20:33:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Wild",
      "screen_name" : "Myrmecos",
      "indices" : [ 3, 12 ],
      "id_str" : "166022406",
      "id" : 166022406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539516626828529664",
  "text" : "RT @Myrmecos: If scientists were as passionate about lichens and snails as they are about impact factors, academia would be a much nicer pl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539490267334983681",
    "text" : "If scientists were as passionate about lichens and snails as they are about impact factors, academia would be a much nicer place.",
    "id" : 539490267334983681,
    "created_at" : "2014-12-01 18:44:37 +0000",
    "user" : {
      "name" : "Alex Wild",
      "screen_name" : "Myrmecos",
      "protected" : false,
      "id_str" : "166022406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842404580818268162\/GXj_mKrC_normal.jpg",
      "id" : 166022406,
      "verified" : false
    }
  },
  "id" : 539516626828529664,
  "created_at" : "2014-12-01 20:29:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539504301157392385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1074345364, 8.7721773237 ]
  },
  "id_str" : "539507781938995200",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC though to be fair: my n is so small it would never get published.",
  "id" : 539507781938995200,
  "in_reply_to_status_id" : 539504301157392385,
  "created_at" : "2014-12-01 19:54:13 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "539485657174147073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106886477, 8.7598396817 ]
  },
  "id_str" : "539487174706884608",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC experience tells: it can be both.",
  "id" : 539487174706884608,
  "in_reply_to_status_id" : 539485657174147073,
  "created_at" : "2014-12-01 18:32:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/stU4Lj65tX",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/12\/01\/90-of-researchers-sequencing-things-because-they-cant-think-of-anything-else-to-do\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/12\/01\/90-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723453038, 8.6275305457 ]
  },
  "id_str" : "539458060742590465",
  "text" : "didn\u2019t read,have assemblies to run \u00ABgenomics researchers are sequencing because they exist in an intellectual vacuum\u00BB http:\/\/t.co\/stU4Lj65tX",
  "id" : 539458060742590465,
  "created_at" : "2014-12-01 16:36:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dxvHtgbToz",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/dec\/01\/dna-james-watson-scientist-selling-nobel-prize-medal?CMP=twt_gu",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539418078594220033",
  "text" : "On Watson: \u00ABIt turns out that just like DNA, people are messy, complex and sometimes full of hideous errors.\u00BB http:\/\/t.co\/dxvHtgbToz",
  "id" : 539418078594220033,
  "created_at" : "2014-12-01 13:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]