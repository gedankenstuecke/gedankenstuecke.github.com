Grailbird.data.tweets_2017_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yad Vashem",
      "screen_name" : "yadvashem",
      "indices" : [ 3, 13 ],
      "id_str" : "33189473",
      "id" : 33189473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OnThisDay",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914170407011459073",
  "text" : "RT @yadvashem: Velvele Valentin Pinkert \nOne of the 33,771 victims of the massacre at Babi Yar #OnThisDay 29-30 September 1941 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yadvashem\/status\/913769195007102976\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/chzKVFyhZu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DK5cPUyWkAIT9Hv.jpg",
        "id_str" : "913769192750485506",
        "id" : 913769192750485506,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DK5cPUyWkAIT9Hv.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 534
        } ],
        "display_url" : "pic.twitter.com\/chzKVFyhZu"
      } ],
      "hashtags" : [ {
        "text" : "OnThisDay",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/G2sC98ZWZu",
        "expanded_url" : "http:\/\/ow.ly\/rJhG30exofG",
        "display_url" : "ow.ly\/rJhG30exofG"
      } ]
    },
    "geo" : { },
    "id_str" : "913769195007102976",
    "text" : "Velvele Valentin Pinkert \nOne of the 33,771 victims of the massacre at Babi Yar #OnThisDay 29-30 September 1941 https:\/\/t.co\/G2sC98ZWZu https:\/\/t.co\/chzKVFyhZu",
    "id" : 913769195007102976,
    "created_at" : "2017-09-29 14:15:27 +0000",
    "user" : {
      "name" : "Yad Vashem",
      "screen_name" : "yadvashem",
      "protected" : false,
      "id_str" : "33189473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709345162577760256\/MVyrKSI9_normal.jpg",
      "id" : 33189473,
      "verified" : true
    }
  },
  "id" : 914170407011459073,
  "created_at" : "2017-09-30 16:49:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 3, 13 ],
      "id_str" : "16486812",
      "id" : 16486812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914092061539827712",
  "text" : "RT @DoctorZen: Important. \"Problem with criticizing (science) in the abstract is that no-one ever thinks criticism is about them.\" https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/5z6miDV2RV",
        "expanded_url" : "https:\/\/medium.com\/@jamesheathers\/why-we-find-and-expose-bad-science-e47387a0e333",
        "display_url" : "medium.com\/@jamesheathers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "913866444533792769",
    "text" : "Important. \"Problem with criticizing (science) in the abstract is that no-one ever thinks criticism is about them.\" https:\/\/t.co\/5z6miDV2RV",
    "id" : 913866444533792769,
    "created_at" : "2017-09-29 20:41:53 +0000",
    "user" : {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "protected" : false,
      "id_str" : "16486812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821882802064867329\/7dtVmJ-0_normal.jpg",
      "id" : 16486812,
      "verified" : false
    }
  },
  "id" : 914092061539827712,
  "created_at" : "2017-09-30 11:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/6OspbJRxLT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZqaT-qlK1I\/",
      "display_url" : "instagram.com\/p\/BZqaT-qlK1I\/"
    } ]
  },
  "geo" : { },
  "id_str" : "914082186747420672",
  "text" : "Someone is having a slow breakfast too. \uD83E\uDD5E \uD83D\uDD77 https:\/\/t.co\/6OspbJRxLT",
  "id" : 914082186747420672,
  "created_at" : "2017-09-30 10:59:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sid Rao",
      "screen_name" : "sidnext2none",
      "indices" : [ 0, 13 ],
      "id_str" : "357642770",
      "id" : 357642770
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913872827148881920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404023832137, 8.753363039507127 ]
  },
  "id_str" : "913881770235514880",
  "in_reply_to_user_id" : 357642770,
  "text" : "@sidnext2none @OpenHumansOrg Okay, looking forward to it!",
  "id" : 913881770235514880,
  "in_reply_to_status_id" : 913872827148881920,
  "created_at" : "2017-09-29 21:42:47 +0000",
  "in_reply_to_screen_name" : "sidnext2none",
  "in_reply_to_user_id_str" : "357642770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sid Rao",
      "screen_name" : "sidnext2none",
      "indices" : [ 0, 13 ],
      "id_str" : "357642770",
      "id" : 357642770
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913864344303267840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388641749583, 8.753305464713513 ]
  },
  "id_str" : "913864506429800449",
  "in_reply_to_user_id" : 357642770,
  "text" : "@sidnext2none @OpenHumansOrg Thanks, will you be at Mozfest? :)",
  "id" : 913864506429800449,
  "in_reply_to_status_id" : 913864344303267840,
  "created_at" : "2017-09-29 20:34:11 +0000",
  "in_reply_to_screen_name" : "sidnext2none",
  "in_reply_to_user_id_str" : "357642770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "indices" : [ 0, 14 ],
      "id_str" : "841811845811974146",
      "id" : 841811845811974146
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 15, 29 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913854533733945347",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388641749583, 8.753305464713513 ]
  },
  "id_str" : "913864450075185152",
  "in_reply_to_user_id" : 841811845811974146,
  "text" : "@methodpodcast @OpenHumansOrg Thanks! \uD83D\uDE0D",
  "id" : 913864450075185152,
  "in_reply_to_status_id" : 913854533733945347,
  "created_at" : "2017-09-29 20:33:58 +0000",
  "in_reply_to_screen_name" : "methodpodcast",
  "in_reply_to_user_id_str" : "841811845811974146",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913748424964628480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240980885819, 8.627451793972929 ]
  },
  "id_str" : "913781256587968513",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err All the best!",
  "id" : 913781256587968513,
  "in_reply_to_status_id" : 913748424964628480,
  "created_at" : "2017-09-29 15:03:23 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913663824019972096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236344055289, 8.62748446875124 ]
  },
  "id_str" : "913704074234810368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I have an account. But I Open Steam so rarely that every time I do it updates everything. Which takes so long that the time for play is over",
  "id" : 913704074234810368,
  "in_reply_to_status_id" : 913663824019972096,
  "created_at" : "2017-09-29 09:56:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar18",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "913661715019190272",
  "text" : "RT @LGBTSTEM: You know what's really exciting? #LGBTSTEMinar18 And now we know when it is! 12th Jan in York. Registration soon, but get it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar18",
        "indices" : [ 33, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "910799079692750848",
    "text" : "You know what's really exciting? #LGBTSTEMinar18 And now we know when it is! 12th Jan in York. Registration soon, but get it in your diary!",
    "id" : 910799079692750848,
    "created_at" : "2017-09-21 09:33:17 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 913661715019190272,
  "created_at" : "2017-09-29 07:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913643586570170368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723920228427, 8.627465274192977 ]
  },
  "id_str" : "913661422197977088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I think my summed up time with Fallout 1\/2 could easily be another PhD writeup plus significant parts of the research needed \uD83D\uDE02",
  "id" : 913661422197977088,
  "in_reply_to_status_id" : 913643586570170368,
  "created_at" : "2017-09-29 07:07:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913603860962336769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402508850764, 8.753388960789517 ]
  },
  "id_str" : "913641773964161024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer But that\u2019s just writing up a phd, it doesn\u2019t include doing the research for it :)",
  "id" : 913641773964161024,
  "in_reply_to_status_id" : 913603860962336769,
  "created_at" : "2017-09-29 05:49:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    }, {
      "name" : "Chris Mungall",
      "screen_name" : "chrismungall",
      "indices" : [ 12, 25 ],
      "id_str" : "19600791",
      "id" : 19600791
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 26, 40 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913419317659656192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233645712568, 8.627518940567983 ]
  },
  "id_str" : "913419982712791041",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris @chrismungall @OpenHumansOrg Yes, we\u2019ll be somewhat neighbors soon! :)",
  "id" : 913419982712791041,
  "in_reply_to_status_id" : 913419317659656192,
  "created_at" : "2017-09-28 15:07:49 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 3, 12 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 90, 101 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/gpHYrvV6mT",
      "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
      "display_url" : "crowdai.org\/challenges\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913353272462897152",
  "text" : "RT @crowd_ai: Just a few more hours to go on the genetic height prediction challenge with @openSNPorg! https:\/\/t.co\/gpHYrvV6mT https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 76, 87 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crowd_ai\/status\/913345393978744833\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/r6xtaCv2GZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DKzaw0pWkAAC40E.jpg",
        "id_str" : "913345356750032896",
        "id" : 913345356750032896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKzaw0pWkAAC40E.jpg",
        "sizes" : [ {
          "h" : 503,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 624,
          "resize" : "fit",
          "w" : 1488
        }, {
          "h" : 624,
          "resize" : "fit",
          "w" : 1488
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/r6xtaCv2GZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/gpHYrvV6mT",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
        "display_url" : "crowdai.org\/challenges\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "913345393978744833",
    "text" : "Just a few more hours to go on the genetic height prediction challenge with @openSNPorg! https:\/\/t.co\/gpHYrvV6mT https:\/\/t.co\/r6xtaCv2GZ",
    "id" : 913345393978744833,
    "created_at" : "2017-09-28 10:11:25 +0000",
    "user" : {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "protected" : false,
      "id_str" : "706885331224813568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710716318849363968\/JG-XbwBL_normal.jpg",
      "id" : 706885331224813568,
      "verified" : false
    }
  },
  "id" : 913353272462897152,
  "created_at" : "2017-09-28 10:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 0, 12 ],
      "id_str" : "19183987",
      "id" : 19183987
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 13, 27 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913332022566883329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246762228219, 8.627144522011989 ]
  },
  "id_str" : "913332556375953408",
  "in_reply_to_user_id" : 19183987,
  "text" : "@DrCarpineti @OpenHumansOrg Thanks!",
  "id" : 913332556375953408,
  "in_reply_to_status_id" : 913332022566883329,
  "created_at" : "2017-09-28 09:20:24 +0000",
  "in_reply_to_screen_name" : "DrCarpineti",
  "in_reply_to_user_id_str" : "19183987",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913330292160630785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229965841506, 8.627539898113605 ]
  },
  "id_str" : "913331606529638401",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber @OpenHumansOrg Thanks! \uD83C\uDF89",
  "id" : 913331606529638401,
  "in_reply_to_status_id" : 913330292160630785,
  "created_at" : "2017-09-28 09:16:38 +0000",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913330361366609920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229965841506, 8.627539898113605 ]
  },
  "id_str" : "913331574619410433",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia Thanks \uD83D\uDE0D",
  "id" : 913331574619410433,
  "in_reply_to_status_id" : 913330361366609920,
  "created_at" : "2017-09-28 09:16:30 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 60, 74 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/28B2vIrsSl",
      "expanded_url" : "http:\/\/ruleofthirds.de\/joining-open-humans\/",
      "display_url" : "ruleofthirds.de\/joining-open-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913329806200180737",
  "text" : "RT @gedankenstuecke: I got a new calling: I will be joining @OpenHumansOrg in November as Director of Research! https:\/\/t.co\/28B2vIrsSl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 39, 53 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/28B2vIrsSl",
        "expanded_url" : "http:\/\/ruleofthirds.de\/joining-open-humans\/",
        "display_url" : "ruleofthirds.de\/joining-open-h\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11409251959306, 8.753375023349811 ]
    },
    "id_str" : "913093228592844800",
    "text" : "I got a new calling: I will be joining @OpenHumansOrg in November as Director of Research! https:\/\/t.co\/28B2vIrsSl",
    "id" : 913093228592844800,
    "created_at" : "2017-09-27 17:29:24 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 913329806200180737,
  "created_at" : "2017-09-28 09:09:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913313429598781441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233135158727, 8.627531589776703 ]
  },
  "id_str" : "913314281395032064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s not 12h straight :P",
  "id" : 913314281395032064,
  "in_reply_to_status_id" : 913313429598781441,
  "created_at" : "2017-09-28 08:07:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913313429598781441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233135158727, 8.627531589776703 ]
  },
  "id_str" : "913314236864040960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, in a given 24h period. E.g. might include working from home for some hours, which will be 10pm-1am or so.",
  "id" : 913314236864040960,
  "in_reply_to_status_id" : 913313429598781441,
  "created_at" : "2017-09-28 08:07:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/913311344677588992\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jfPDt7n3Nu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DKy70pWW0AAK-F0.jpg",
      "id_str" : "913311337576583168",
      "id" : 913311337576583168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKy70pWW0AAK-F0.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 909
      } ],
      "display_url" : "pic.twitter.com\/jfPDt7n3Nu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913298996399030272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233939315577, 8.627539626488733 ]
  },
  "id_str" : "913311344677588992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer here you go for the daily plots control period vs thesis writing period. Horizontal bars are the mean. https:\/\/t.co\/jfPDt7n3Nu",
  "id" : 913311344677588992,
  "in_reply_to_status_id" : 913298996399030272,
  "created_at" : "2017-09-28 07:56:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913294727931293696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11462063533264, 8.750179102652472 ]
  },
  "id_str" : "913296582786895872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Ideally you\u2019d do some multiple 2 month windows to see how much it deviates as there\u2019s no typical pattern I guess.",
  "id" : 913296582786895872,
  "in_reply_to_status_id" : 913294727931293696,
  "created_at" : "2017-09-28 06:57:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913294727931293696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11440136474567, 8.75211389736156 ]
  },
  "id_str" : "913296030506082305",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Yeah, that was just my super lazy way of establishing a baseline.",
  "id" : 913296030506082305,
  "in_reply_to_status_id" : 913294727931293696,
  "created_at" : "2017-09-28 06:55:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913290762258919424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411142143051, 8.75333435325003 ]
  },
  "id_str" : "913294392470929408",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack Thanks! \uD83C\uDF89",
  "id" : 913294392470929408,
  "in_reply_to_status_id" : 913290762258919424,
  "created_at" : "2017-09-28 06:48:46 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913290754209890305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411142143051, 8.75333435325003 ]
  },
  "id_str" : "913294319720812544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer The first graph in the post gives the cumulative sums for a \u201Cregular\u201D 2 month window, the second one for the write up-window.",
  "id" : 913294319720812544,
  "in_reply_to_status_id" : 913290754209890305,
  "created_at" : "2017-09-28 06:48:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913290754209890305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411142143051, 8.75333435325003 ]
  },
  "id_str" : "913293824004444160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer It\u2019s 500 of \u2018productive\u2019 plus \u2018very productive\u2019, but this then also includes some non-thesis related work for the PhD, i.e. regular work",
  "id" : 913293824004444160,
  "in_reply_to_status_id" : 913290754209890305,
  "created_at" : "2017-09-28 06:46:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Mungall",
      "screen_name" : "chrismungall",
      "indices" : [ 0, 13 ],
      "id_str" : "19600791",
      "id" : 19600791
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913246267416838144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412078295731, 8.753332395259003 ]
  },
  "id_str" : "913289716417613824",
  "in_reply_to_user_id" : 19600791,
  "text" : "@chrismungall @OpenHumansOrg Thank you so much for taking me in! And I can\u2019t wait to join you in Berkeley!",
  "id" : 913289716417613824,
  "in_reply_to_status_id" : 913246267416838144,
  "created_at" : "2017-09-28 06:30:11 +0000",
  "in_reply_to_screen_name" : "chrismungall",
  "in_reply_to_user_id_str" : "19600791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 15, 29 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 83, 92 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913264896523071488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412078295731, 8.753332395259003 ]
  },
  "id_str" : "913289507327311872",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe @OpenHumansOrg Me too, there should be some great opportunities for @crowd_ai!",
  "id" : 913289507327311872,
  "in_reply_to_status_id" : 913264896523071488,
  "created_at" : "2017-09-28 06:29:21 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913288235844956160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412078295731, 8.753332395259003 ]
  },
  "id_str" : "913289389832380417",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Well, the sum for writing is in there, isn\u2019t it? But I can make some plots for the daily hours of writing :)",
  "id" : 913289389832380417,
  "in_reply_to_status_id" : 913288235844956160,
  "created_at" : "2017-09-28 06:28:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913223108311445504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411386202786, 8.753334973736429 ]
  },
  "id_str" : "913288923685715968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @OpenHumansOrg Thanks! \uD83C\uDF7A\uD83C\uDF7E\uD83C\uDF89",
  "id" : 913288923685715968,
  "in_reply_to_status_id" : 913223108311445504,
  "created_at" : "2017-09-28 06:27:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Kumar Jaiswal",
      "screen_name" : "AMIT_GKP",
      "indices" : [ 0, 9 ],
      "id_str" : "162353278",
      "id" : 162353278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913205926378778624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411386202786, 8.753334973736429 ]
  },
  "id_str" : "913288304107323392",
  "in_reply_to_user_id" : 162353278,
  "text" : "@AMIT_GKP Thanks!",
  "id" : 913288304107323392,
  "in_reply_to_status_id" : 913205926378778624,
  "created_at" : "2017-09-28 06:24:34 +0000",
  "in_reply_to_screen_name" : "AMIT_GKP",
  "in_reply_to_user_id_str" : "162353278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913199466911551488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411386202786, 8.753334973736429 ]
  },
  "id_str" : "913288222389735424",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw Thanks, we have to celebrate in London! \uD83C\uDF7B",
  "id" : 913288222389735424,
  "in_reply_to_status_id" : 913199466911551488,
  "created_at" : "2017-09-28 06:24:14 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913193477646647297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411386202786, 8.753334973736429 ]
  },
  "id_str" : "913287950431080448",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds Yes! More reasons to visit for you!",
  "id" : 913287950431080448,
  "in_reply_to_status_id" : 913193477646647297,
  "created_at" : "2017-09-28 06:23:10 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Landrain",
      "screen_name" : "Tholand_",
      "indices" : [ 0, 9 ],
      "id_str" : "62024265",
      "id" : 62024265
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913189893215543297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411386202786, 8.753334973736429 ]
  },
  "id_str" : "913287830964785153",
  "in_reply_to_user_id" : 62024265,
  "text" : "@Tholand_ @OpenHumansOrg Thanks Thomas!",
  "id" : 913287830964785153,
  "in_reply_to_status_id" : 913189893215543297,
  "created_at" : "2017-09-28 06:22:41 +0000",
  "in_reply_to_screen_name" : "Tholand_",
  "in_reply_to_user_id_str" : "62024265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 3, 12 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    }, {
      "name" : "OpenSNP",
      "screen_name" : "OpenSNP",
      "indices" : [ 40, 48 ],
      "id_str" : "186279960",
      "id" : 186279960
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/crowd_ai\/status\/912935898643386369\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/BW1ACm7l61",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DKtl5-hXoAAYN9n.jpg",
      "id_str" : "912935396182564864",
      "id" : 912935396182564864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKtl5-hXoAAYN9n.jpg",
      "sizes" : [ {
        "h" : 348,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/BW1ACm7l61"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/gpHYrvV6mT",
      "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
      "display_url" : "crowdai.org\/challenges\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913187669500469248",
  "text" : "RT @crowd_ai: 34 hours to go before the @openSNP challenge on crowdAI ends! https:\/\/t.co\/gpHYrvV6mT https:\/\/t.co\/BW1ACm7l61",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenSNP",
        "screen_name" : "OpenSNP",
        "indices" : [ 26, 34 ],
        "id_str" : "186279960",
        "id" : 186279960
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crowd_ai\/status\/912935898643386369\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/BW1ACm7l61",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DKtl5-hXoAAYN9n.jpg",
        "id_str" : "912935396182564864",
        "id" : 912935396182564864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKtl5-hXoAAYN9n.jpg",
        "sizes" : [ {
          "h" : 348,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/BW1ACm7l61"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/gpHYrvV6mT",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
        "display_url" : "crowdai.org\/challenges\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "912935898643386369",
    "text" : "34 hours to go before the @openSNP challenge on crowdAI ends! https:\/\/t.co\/gpHYrvV6mT https:\/\/t.co\/BW1ACm7l61",
    "id" : 912935898643386369,
    "created_at" : "2017-09-27 07:04:14 +0000",
    "user" : {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "protected" : false,
      "id_str" : "706885331224813568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710716318849363968\/JG-XbwBL_normal.jpg",
      "id" : 706885331224813568,
      "verified" : false
    }
  },
  "id" : 913187669500469248,
  "created_at" : "2017-09-27 23:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 11, 25 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 63, 75 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913183339179155456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381324452794, 8.753250977012636 ]
  },
  "id_str" : "913186537340325888",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @OpenHumansOrg Which hopefully will be published in @GigaScience \uD83D\uDE09",
  "id" : 913186537340325888,
  "in_reply_to_status_id" : 913183339179155456,
  "created_at" : "2017-09-27 23:40:11 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Demetris Terlikas",
      "screen_name" : "demasterlikas",
      "indices" : [ 0, 14 ],
      "id_str" : "97819211",
      "id" : 97819211
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 15, 29 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913169908946685953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411936009436, 8.753337301668145 ]
  },
  "id_str" : "913183208950452226",
  "in_reply_to_user_id" : 97819211,
  "text" : "@demasterlikas @OpenHumansOrg Thanks! :)",
  "id" : 913183208950452226,
  "in_reply_to_status_id" : 913169908946685953,
  "created_at" : "2017-09-27 23:26:57 +0000",
  "in_reply_to_screen_name" : "demasterlikas",
  "in_reply_to_user_id_str" : "97819211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913167454486110208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404266248896, 8.753360041792833 ]
  },
  "id_str" : "913183208958808065",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin Thanks! A perfect merging of my research interests :)",
  "id" : 913183208958808065,
  "in_reply_to_status_id" : 913167454486110208,
  "created_at" : "2017-09-27 23:26:57 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913164972540268544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404266248896, 8.753360041792833 ]
  },
  "id_str" : "913182892490141696",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @OpenHumansOrg Thanks! :)",
  "id" : 913182892490141696,
  "in_reply_to_status_id" : 913164972540268544,
  "created_at" : "2017-09-27 23:25:42 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913164972540268544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412203625358, 8.753335618005572 ]
  },
  "id_str" : "913165717964541953",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @OpenHumansOrg Thanks!",
  "id" : 913165717964541953,
  "in_reply_to_status_id" : 913164972540268544,
  "created_at" : "2017-09-27 22:17:27 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913161235977375745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412308263684, 8.753333612619302 ]
  },
  "id_str" : "913161890259488768",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @OpenHumansOrg Thanks! \uD83D\uDE0A\uD83C\uDF8A",
  "id" : 913161890259488768,
  "in_reply_to_status_id" : 913161235977375745,
  "created_at" : "2017-09-27 22:02:15 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913149904318550020",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412507102425, 8.753332554344002 ]
  },
  "id_str" : "913159164058316801",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @OpenHumansOrg \uD83D\uDC96\uD83C\uDF89",
  "id" : 913159164058316801,
  "in_reply_to_status_id" : 913149904318550020,
  "created_at" : "2017-09-27 21:51:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shuttleworth",
      "screen_name" : "ShuttleworthFdn",
      "indices" : [ 3, 19 ],
      "id_str" : "2665573442",
      "id" : 2665573442
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 22, 36 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 46, 62 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5XBLV6lnXt",
      "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/09\/27\/announcing-bastian-joining-open-humans\/",
      "display_url" : "blog.openhumans.org\/2017\/09\/27\/ann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913159103605862402",
  "text" : "RT @ShuttleworthFdn: .@OpenHumansOrg welcomes @gedankenstuecke as new Director of Research. Exciting collaboration. https:\/\/t.co\/5XBLV6lnXt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 1, 15 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 25, 41 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/5XBLV6lnXt",
        "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/09\/27\/announcing-bastian-joining-open-humans\/",
        "display_url" : "blog.openhumans.org\/2017\/09\/27\/ann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "913152721485799424",
    "text" : ".@OpenHumansOrg welcomes @gedankenstuecke as new Director of Research. Exciting collaboration. https:\/\/t.co\/5XBLV6lnXt",
    "id" : 913152721485799424,
    "created_at" : "2017-09-27 21:25:49 +0000",
    "user" : {
      "name" : "Shuttleworth",
      "screen_name" : "ShuttleworthFdn",
      "protected" : false,
      "id_str" : "2665573442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491208138163380226\/33vvQcHw_normal.png",
      "id" : 2665573442,
      "verified" : true
    }
  },
  "id" : 913159103605862402,
  "created_at" : "2017-09-27 21:51:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913151324459499521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412438724555, 8.753332764040877 ]
  },
  "id_str" : "913159076623929344",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi @OpenHumansOrg thanks, looking forward to tell you all about it at Mozfest! :)",
  "id" : 913159076623929344,
  "in_reply_to_status_id" : 913151324459499521,
  "created_at" : "2017-09-27 21:51:04 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 15, 29 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913145405004754945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412308436632, 8.753333231281655 ]
  },
  "id_str" : "913149899843268609",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n @OpenHumansOrg Will do next time we meet!\uD83D\uDE0A",
  "id" : 913149899843268609,
  "in_reply_to_status_id" : 913145405004754945,
  "created_at" : "2017-09-27 21:14:36 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/hwvJJSeXNZ",
      "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/913142866276261888",
      "display_url" : "twitter.com\/madprime\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "913144819035381767",
  "text" : "If you happen to know some Rails &amp; OAuth: We're having a project idea for connecting openSNP w\/ OH and would love someone to run with it. https:\/\/t.co\/hwvJJSeXNZ",
  "id" : 913144819035381767,
  "created_at" : "2017-09-27 20:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913142027864469505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11417100744735, 8.753299154861516 ]
  },
  "id_str" : "913142454697828353",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr I will give you a call if I ever need someone to play me on TV! \uD83D\uDE02",
  "id" : 913142454697828353,
  "in_reply_to_status_id" : 913142027864469505,
  "created_at" : "2017-09-27 20:45:01 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 30, 46 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 52, 66 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 80, 91 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "913141271363022850",
  "text" : "RT @madprime: Honored to have @gedankenstuecke join @OpenHumansOrg! His work w\/ @openSNPorg &amp; #openscience is an inspiration \uD83D\uDE0A https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 16, 32 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 38, 52 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 66, 77 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 84, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/UHAUW9LEsg",
        "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/09\/27\/announcing-bastian-joining-open-humans\/",
        "display_url" : "blog.openhumans.org\/2017\/09\/27\/ann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "913093243780206592",
    "text" : "Honored to have @gedankenstuecke join @OpenHumansOrg! His work w\/ @openSNPorg &amp; #openscience is an inspiration \uD83D\uDE0A https:\/\/t.co\/UHAUW9LEsg",
    "id" : 913093243780206592,
    "created_at" : "2017-09-27 17:29:28 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 913141271363022850,
  "created_at" : "2017-09-27 20:40:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913135201081085952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414629909898, 8.753322976062826 ]
  },
  "id_str" : "913135338423554051",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena We\u2019ve all been waiting for this. \uD83D\uDE02",
  "id" : 913135338423554051,
  "in_reply_to_status_id" : 913135201081085952,
  "created_at" : "2017-09-27 20:16:44 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 0, 10 ],
      "id_str" : "248717660",
      "id" : 248717660
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 11, 25 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913133487066173441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411712370055, 8.753338084751817 ]
  },
  "id_str" : "913133689239982081",
  "in_reply_to_user_id" : 248717660,
  "text" : "@operkovic @OpenHumansOrg thanks you Olga! I\u2019m thrilled about the new tasks ahead :)",
  "id" : 913133689239982081,
  "in_reply_to_status_id" : 913133487066173441,
  "created_at" : "2017-09-27 20:10:11 +0000",
  "in_reply_to_screen_name" : "operkovic",
  "in_reply_to_user_id_str" : "248717660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 9, 23 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913127750298476549",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141238344978, 8.753310178916015 ]
  },
  "id_str" : "913128617617575936",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @OpenHumansOrg Thank you! \uD83D\uDC96",
  "id" : 913128617617575936,
  "in_reply_to_status_id" : 913127750298476549,
  "created_at" : "2017-09-27 19:50:02 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 17, 31 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913128421617688581",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141238344978, 8.753310178916015 ]
  },
  "id_str" : "913128567998943234",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @OpenHumansOrg At Mozfest for sure! Still need to sort out logistics for opencon with the upcoming move.",
  "id" : 913128567998943234,
  "in_reply_to_status_id" : 913128421617688581,
  "created_at" : "2017-09-27 19:49:50 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 12, 26 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913127276006457344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140382836719, 8.753360614407006 ]
  },
  "id_str" : "913127657927270400",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @OpenHumansOrg Thanks!",
  "id" : 913127657927270400,
  "in_reply_to_status_id" : 913127276006457344,
  "created_at" : "2017-09-27 19:46:13 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913125902522953728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140382836719, 8.753360614407006 ]
  },
  "id_str" : "913127594144432128",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb \uD83D\uDC85\uD83D\uDC84\uD83D\uDE02",
  "id" : 913127594144432128,
  "in_reply_to_status_id" : 913125902522953728,
  "created_at" : "2017-09-27 19:45:58 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 17, 31 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913123700941004801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140515682067, 8.753270305537615 ]
  },
  "id_str" : "913124372830879746",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @OpenHumansOrg Thanks, we need to celebrate next time we meet! \uD83C\uDF89\uD83C\uDF7E",
  "id" : 913124372830879746,
  "in_reply_to_status_id" : 913123700941004801,
  "created_at" : "2017-09-27 19:33:10 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 12, 26 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913122158406234112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11413390295128, 8.753308658438547 ]
  },
  "id_str" : "913122582576148480",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @OpenHumansOrg Thanks, I will reach out to you regarding some collaborations that are on my mind! :)",
  "id" : 913122582576148480,
  "in_reply_to_status_id" : 913122158406234112,
  "created_at" : "2017-09-27 19:26:03 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913117511595560960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412692000572, 8.753322187274883 ]
  },
  "id_str" : "913121582763200512",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @OpenHumansOrg Thank you so much! \uD83C\uDF89",
  "id" : 913121582763200512,
  "in_reply_to_status_id" : 913117511595560960,
  "created_at" : "2017-09-27 19:22:04 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913112784610701313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406905574493, 8.753355077205292 ]
  },
  "id_str" : "913114186963701760",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @OpenHumansOrg Thank you so much! \uD83C\uDF8A",
  "id" : 913114186963701760,
  "in_reply_to_status_id" : 913112784610701313,
  "created_at" : "2017-09-27 18:52:41 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ludmila Carone",
      "screen_name" : "Exotides",
      "indices" : [ 0, 9 ],
      "id_str" : "78689305",
      "id" : 78689305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913113788949434420",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406905574493, 8.753355077205292 ]
  },
  "id_str" : "913114101529923585",
  "in_reply_to_user_id" : 78689305,
  "text" : "@Exotides Yes, especially if its places that are also in the middle of nowhere so that traveling there alone is ridiculously expensive.",
  "id" : 913114101529923585,
  "in_reply_to_status_id" : 913113788949434420,
  "created_at" : "2017-09-27 18:52:21 +0000",
  "in_reply_to_screen_name" : "Exotides",
  "in_reply_to_user_id_str" : "78689305",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913109204382081025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11261550542014, 8.755198656122491 ]
  },
  "id_str" : "913111432417423361",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Thanks, this will make visits to Portland much easier \uD83D\uDE02",
  "id" : 913111432417423361,
  "in_reply_to_status_id" : 913109204382081025,
  "created_at" : "2017-09-27 18:41:44 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/1vshzGMkWt",
      "expanded_url" : "https:\/\/twitter.com\/hollybik\/status\/913097093165678593",
      "display_url" : "twitter.com\/hollybik\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1129517750997, 8.7543664579204 ]
  },
  "id_str" : "913110092026978315",
  "text" : "This thread, so much. Don\u2019t know how often I had to beg friends and family for some money because I had to wait to be reimbursed by my uni. https:\/\/t.co\/1vshzGMkWt",
  "id" : 913110092026978315,
  "created_at" : "2017-09-27 18:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 0, 16 ],
      "id_str" : "15150655",
      "id" : 15150655
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 17, 31 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913108000453402628",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404113880521, 8.753363659429255 ]
  },
  "id_str" : "913108668664750081",
  "in_reply_to_user_id" : 15150655,
  "text" : "@konradfoerstner @OpenHumansOrg thanks! \uD83C\uDF7B",
  "id" : 913108668664750081,
  "in_reply_to_status_id" : 913108000453402628,
  "created_at" : "2017-09-27 18:30:46 +0000",
  "in_reply_to_screen_name" : "konradfoerstner",
  "in_reply_to_user_id_str" : "15150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913106246764515328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409115429411, 8.753384496624266 ]
  },
  "id_str" : "913106471432474629",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt @OpenHumansOrg thanks! \uD83C\uDF7E",
  "id" : 913106471432474629,
  "in_reply_to_status_id" : 913106246764515328,
  "created_at" : "2017-09-27 18:22:02 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 11, 25 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913106016501411840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409115429411, 8.753384496624266 ]
  },
  "id_str" : "913106396174061568",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience @OpenHumansOrg thanks! \uD83C\uDF89",
  "id" : 913106396174061568,
  "in_reply_to_status_id" : 913106016501411840,
  "created_at" : "2017-09-27 18:21:44 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913104021979725824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412328915006, 8.753334617720888 ]
  },
  "id_str" : "913104508066156544",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez And I might get a chance to finally see more from LA than LAX and the Bradbury Building. \uD83D\uDE02",
  "id" : 913104508066156544,
  "in_reply_to_status_id" : 913104021979725824,
  "created_at" : "2017-09-27 18:14:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 10, 24 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 25, 34 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913102600437874688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409181658587, 8.75334661406583 ]
  },
  "id_str" : "913103211346763781",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @OpenHumansOrg @madprime Thanks And I hope that you &amp; I will finally have more chances to meet rather than only running into each other every few years! \uD83D\uDE02",
  "id" : 913103211346763781,
  "in_reply_to_status_id" : 913102600437874688,
  "created_at" : "2017-09-27 18:09:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 12, 21 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 22, 36 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 37, 48 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913097748022427653",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141207882584, 8.753336483825386 ]
  },
  "id_str" : "913100454380412936",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy @madprime @OpenHumansOrg @openSNPorg thanks, without all data-sharers like you it wouldn\u2019t be possible!",
  "id" : 913100454380412936,
  "in_reply_to_status_id" : 913097748022427653,
  "created_at" : "2017-09-27 17:58:07 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernhard Mittermaier",
      "screen_name" : "BMittermaier",
      "indices" : [ 0, 13 ],
      "id_str" : "152791124",
      "id" : 152791124
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 14, 28 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913094968994144259",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11413096801479, 8.75333339507013 ]
  },
  "id_str" : "913097164137668611",
  "in_reply_to_user_id" : 152791124,
  "text" : "@BMittermaier @OpenHumansOrg Thanks! \uD83D\uDE0A",
  "id" : 913097164137668611,
  "in_reply_to_status_id" : 913094968994144259,
  "created_at" : "2017-09-27 17:45:03 +0000",
  "in_reply_to_screen_name" : "BMittermaier",
  "in_reply_to_user_id_str" : "152791124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ismail Khoffi",
      "screen_name" : "KreuzUQuer",
      "indices" : [ 0, 11 ],
      "id_str" : "1285546765",
      "id" : 1285546765
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 12, 26 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 70, 79 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "913093861668540417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412490400231, 8.753311205974496 ]
  },
  "id_str" : "913094248878272513",
  "in_reply_to_user_id" : 1285546765,
  "text" : "@KreuzUQuer @OpenHumansOrg Thanks! I\u2019m really looking forward to join @madprime in building something great \u263A\uFE0F",
  "id" : 913094248878272513,
  "in_reply_to_status_id" : 913093861668540417,
  "created_at" : "2017-09-27 17:33:28 +0000",
  "in_reply_to_screen_name" : "KreuzUQuer",
  "in_reply_to_user_id_str" : "1285546765",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 39, 53 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/28B2vIrsSl",
      "expanded_url" : "http:\/\/ruleofthirds.de\/joining-open-humans\/",
      "display_url" : "ruleofthirds.de\/joining-open-h\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409251959306, 8.753375023349811 ]
  },
  "id_str" : "913093228592844800",
  "text" : "I got a new calling: I will be joining @OpenHumansOrg in November as Director of Research! https:\/\/t.co\/28B2vIrsSl",
  "id" : 913093228592844800,
  "created_at" : "2017-09-27 17:29:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GenderAvenger",
      "screen_name" : "GenderAvenger",
      "indices" : [ 3, 17 ],
      "id_str" : "1538818580",
      "id" : 1538818580
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 29, 45 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenderAvenger",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/WYHr7DUWLE",
      "expanded_url" : "http:\/\/genderavenger.com\/the-pledge",
      "display_url" : "genderavenger.com\/the-pledge"
    } ]
  },
  "geo" : { },
  "id_str" : "913045574261313538",
  "text" : "RT @GenderAvenger: Thanks to @gedankenstuecke for supporting inclusion and signing the #GenderAvenger pledge! https:\/\/t.co\/WYHr7DUWLE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 10, 26 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GenderAvenger",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/WYHr7DUWLE",
        "expanded_url" : "http:\/\/genderavenger.com\/the-pledge",
        "display_url" : "genderavenger.com\/the-pledge"
      } ]
    },
    "geo" : { },
    "id_str" : "913026758999408640",
    "text" : "Thanks to @gedankenstuecke for supporting inclusion and signing the #GenderAvenger pledge! https:\/\/t.co\/WYHr7DUWLE",
    "id" : 913026758999408640,
    "created_at" : "2017-09-27 13:05:17 +0000",
    "user" : {
      "name" : "GenderAvenger",
      "screen_name" : "GenderAvenger",
      "protected" : false,
      "id_str" : "1538818580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846536908666650624\/R-MZtF-U_normal.jpg",
      "id" : 1538818580,
      "verified" : false
    }
  },
  "id" : 913045574261313538,
  "created_at" : "2017-09-27 14:20:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AwnrNpc3Gl",
      "expanded_url" : "https:\/\/github.com\/apriha\/lineage",
      "display_url" : "github.com\/apriha\/lineage"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234770766309, 8.62751073724101 ]
  },
  "id_str" : "913005896057442304",
  "text" : "A python module for genetic genealogy based on direct-to-consumer testing data. Uses openSNP examples as in the docs https:\/\/t.co\/AwnrNpc3Gl",
  "id" : 913005896057442304,
  "created_at" : "2017-09-27 11:42:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/fS63D4p6R5",
      "expanded_url" : "https:\/\/phylogenomics.blogspot.de\/2017\/09\/nature-publishing-group-continues-to.html?spref=tw",
      "display_url" : "phylogenomics.blogspot.de\/2017\/09\/nature\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231299406837, 8.627546208237161 ]
  },
  "id_str" : "912948958686846976",
  "text" : "Nature keeps charging for access to genome papers, despite grandiose claims to the contrary. https:\/\/t.co\/fS63D4p6R5",
  "id" : 912948958686846976,
  "created_at" : "2017-09-27 07:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912928758071480320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410393422945, 8.753344782955145 ]
  },
  "id_str" : "912930366826143744",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 They keep the 140 character limit. But \u201AI\u2018s aren\u2019t counted any longer. Should fix it. \uD83D\uDE02",
  "id" : 912930366826143744,
  "in_reply_to_status_id" : 912928758071480320,
  "created_at" : "2017-09-27 06:42:15 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912805547384217600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411543594588, 8.753334318101667 ]
  },
  "id_str" : "912805833993531392",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Yeah, there are some super weird ones. \uD83D\uDE02",
  "id" : 912805833993531392,
  "in_reply_to_status_id" : 912805547384217600,
  "created_at" : "2017-09-26 22:27:24 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912804052202917888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11413184700277, 8.753331877494064 ]
  },
  "id_str" : "912804430667534336",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab 280 characters: declare war to twice as many countries in a single tweet.",
  "id" : 912804430667534336,
  "in_reply_to_status_id" : 912804052202917888,
  "created_at" : "2017-09-26 22:21:50 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912802455079047168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11411194996668, 8.753339185642195 ]
  },
  "id_str" : "912802697253986304",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab that made my day! \uD83D\uDE02",
  "id" : 912802697253986304,
  "in_reply_to_status_id" : 912802455079047168,
  "created_at" : "2017-09-26 22:14:56 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/XCxfrsGNiX",
      "expanded_url" : "https:\/\/twitter.com\/Twitter\/status\/912783930431905797",
      "display_url" : "twitter.com\/Twitter\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141046466328, 8.753343368525842 ]
  },
  "id_str" : "912801981294612480",
  "text" : "Awesome, German Twitter users will soon have 2,800 characters to get around the sprachbedingte Zeichenvollstopfproblematik. https:\/\/t.co\/XCxfrsGNiX",
  "id" : 912801981294612480,
  "created_at" : "2017-09-26 22:12:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 3, 11 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WytkSFoZz5",
      "expanded_url" : "https:\/\/twitter.com\/realscientists\/status\/912315504488013829",
      "display_url" : "twitter.com\/realscientists\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "912662048542248961",
  "text" : "RT @cbahlai: A big serving of truth for supervisors of international students and postdocs. https:\/\/t.co\/WytkSFoZz5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/WytkSFoZz5",
        "expanded_url" : "https:\/\/twitter.com\/realscientists\/status\/912315504488013829",
        "display_url" : "twitter.com\/realscientists\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "912322138874531841",
    "text" : "A big serving of truth for supervisors of international students and postdocs. https:\/\/t.co\/WytkSFoZz5",
    "id" : 912322138874531841,
    "created_at" : "2017-09-25 14:25:22 +0000",
    "user" : {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "protected" : false,
      "id_str" : "958649520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705843854973530112\/S992pAjY_normal.jpg",
      "id" : 958649520,
      "verified" : false
    }
  },
  "id" : 912662048542248961,
  "created_at" : "2017-09-26 12:56:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912445552482226176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238440982035, 8.627479755160524 ]
  },
  "id_str" : "912582287623155712",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen *blush*",
  "id" : 912582287623155712,
  "in_reply_to_status_id" : 912445552482226176,
  "created_at" : "2017-09-26 07:39:06 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912434274451820544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11383537673402, 8.753363639124439 ]
  },
  "id_str" : "912441320542752769",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Oh, You\u2019re so Kind. \uD83D\uDE0D",
  "id" : 912441320542752769,
  "in_reply_to_status_id" : 912434274451820544,
  "created_at" : "2017-09-25 22:18:57 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Tim Blais",
      "screen_name" : "acapellascience",
      "indices" : [ 10, 26 ],
      "id_str" : "780993961",
      "id" : 780993961
    }, {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 27, 34 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912414991336210437",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141172556372, 8.753336825368534 ]
  },
  "id_str" : "912432109301764096",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @acapellascience @EvoMRI Thanks! \uD83D\uDE0D",
  "id" : 912432109301764096,
  "in_reply_to_status_id" : 912414991336210437,
  "created_at" : "2017-09-25 21:42:21 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Blais",
      "screen_name" : "acapellascience",
      "indices" : [ 3, 19 ],
      "id_str" : "780993961",
      "id" : 780993961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/5WZfESYXIJ",
      "expanded_url" : "https:\/\/youtu.be\/ydqReeTV_vk",
      "display_url" : "youtu.be\/ydqReeTV_vk"
    } ]
  },
  "geo" : { },
  "id_str" : "912432051793559553",
  "text" : "RT @acapellascience: This is how we go from single cells to people.. to that sweet sweet Despacito beat. https:\/\/t.co\/5WZfESYXIJ https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/acapellascience\/status\/911680859144642561\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/9CJ89xoKZp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DKbw6BXV4AADvLv.jpg",
        "id_str" : "911680854178521088",
        "id" : 911680854178521088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKbw6BXV4AADvLv.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/9CJ89xoKZp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/5WZfESYXIJ",
        "expanded_url" : "https:\/\/youtu.be\/ydqReeTV_vk",
        "display_url" : "youtu.be\/ydqReeTV_vk"
      } ]
    },
    "geo" : { },
    "id_str" : "911680859144642561",
    "text" : "This is how we go from single cells to people.. to that sweet sweet Despacito beat. https:\/\/t.co\/5WZfESYXIJ https:\/\/t.co\/9CJ89xoKZp",
    "id" : 911680859144642561,
    "created_at" : "2017-09-23 19:57:09 +0000",
    "user" : {
      "name" : "Tim Blais",
      "screen_name" : "acapellascience",
      "protected" : false,
      "id_str" : "780993961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836785051039842304\/itOAA1h3_normal.jpg",
      "id" : 780993961,
      "verified" : false
    }
  },
  "id" : 912432051793559553,
  "created_at" : "2017-09-25 21:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rainer Melzer",
      "screen_name" : "UCDflowerpower",
      "indices" : [ 0, 15 ],
      "id_str" : "19333674",
      "id" : 19333674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911934696459788289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392711899164, 8.753105849895729 ]
  },
  "id_str" : "911935767802519553",
  "in_reply_to_user_id" : 19333674,
  "text" : "@UCDflowerpower That\u2019s why I voted, to minimize the number of Nazis ending up in parliament. But not because I actually believe in any party\u2019s platform.",
  "id" : 911935767802519553,
  "in_reply_to_status_id" : 911934696459788289,
  "created_at" : "2017-09-24 12:50:04 +0000",
  "in_reply_to_screen_name" : "UCDflowerpower",
  "in_reply_to_user_id_str" : "19333674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 0, 13 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911913301491163137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404836504457, 8.753416317778697 ]
  },
  "id_str" : "911913565182943232",
  "in_reply_to_user_id" : 1337118332,
  "text" : "@schwessinger When I was on ballot myself. \uD83D\uDE02",
  "id" : 911913565182943232,
  "in_reply_to_status_id" : 911913301491163137,
  "created_at" : "2017-09-24 11:21:51 +0000",
  "in_reply_to_screen_name" : "schwessinger",
  "in_reply_to_user_id_str" : "1337118332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10834627001314, 8.744791678553417 ]
  },
  "id_str" : "911893344762175488",
  "text" : "I think I wasn\u2019t as unexcited to vote in a federal election since I nearly threw up in the voting booth thanks to a hangover.",
  "id" : 911893344762175488,
  "created_at" : "2017-09-24 10:01:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cathryn Lewis",
      "screen_name" : "cathrynlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "119867076",
      "id" : 119867076
    }, {
      "name" : "Julia Schnabel",
      "screen_name" : "ja_schnabel",
      "indices" : [ 123, 135 ],
      "id_str" : "3447868277",
      "id" : 3447868277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911857295809802240",
  "text" : "RT @cathrynlewis: Great list of all those gender-bias-in-academia studies that you read once and can never find again. (HT @ja_schnabel) ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julia Schnabel",
        "screen_name" : "ja_schnabel",
        "indices" : [ 105, 117 ],
        "id_str" : "3447868277",
        "id" : 3447868277
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/qOoN29epyy",
        "expanded_url" : "https:\/\/twitter.com\/curtrice\/status\/911569125310451713",
        "display_url" : "twitter.com\/curtrice\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "911845004288647168",
    "text" : "Great list of all those gender-bias-in-academia studies that you read once and can never find again. (HT @ja_schnabel) https:\/\/t.co\/qOoN29epyy",
    "id" : 911845004288647168,
    "created_at" : "2017-09-24 06:49:24 +0000",
    "user" : {
      "name" : "Cathryn Lewis",
      "screen_name" : "cathrynlewis",
      "protected" : false,
      "id_str" : "119867076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722886932649222144\/IGN4MFvx_normal.jpg",
      "id" : 119867076,
      "verified" : false
    }
  },
  "id" : 911857295809802240,
  "created_at" : "2017-09-24 07:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelazeem\uD83C\uDF39",
      "screen_name" : "AElhabyan",
      "indices" : [ 0, 10 ],
      "id_str" : "4251126076",
      "id" : 4251126076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911574969712246784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403707313512, 8.753361824780999 ]
  },
  "id_str" : "911576285511606274",
  "in_reply_to_user_id" : 4251126076,
  "text" : "@AElhabyan Thanks!",
  "id" : 911576285511606274,
  "in_reply_to_status_id" : 911574969712246784,
  "created_at" : "2017-09-23 13:01:37 +0000",
  "in_reply_to_screen_name" : "AElhabyan",
  "in_reply_to_user_id_str" : "4251126076",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Edwards",
      "screen_name" : "AlisonAEdwards",
      "indices" : [ 3, 18 ],
      "id_str" : "2777090310",
      "id" : 2777090310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/KDCjx7xCf1",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/910619529151156224",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "911574067555307520",
  "text" : "RT @AlisonAEdwards: An intriguing reflection on PhD thesis writing. https:\/\/t.co\/KDCjx7xCf1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/KDCjx7xCf1",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/910619529151156224",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "911475408104718336",
    "text" : "An intriguing reflection on PhD thesis writing. https:\/\/t.co\/KDCjx7xCf1",
    "id" : 911475408104718336,
    "created_at" : "2017-09-23 06:20:46 +0000",
    "user" : {
      "name" : "Alison Edwards",
      "screen_name" : "AlisonAEdwards",
      "protected" : false,
      "id_str" : "2777090310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594984318558216192\/vJ3sGEHR_normal.jpg",
      "id" : 2777090310,
      "verified" : false
    }
  },
  "id" : 911574067555307520,
  "created_at" : "2017-09-23 12:52:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Edwards",
      "screen_name" : "AlisonAEdwards",
      "indices" : [ 0, 15 ],
      "id_str" : "2777090310",
      "id" : 2777090310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911475408104718336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410391483189, 8.75333715281287 ]
  },
  "id_str" : "911574062274621440",
  "in_reply_to_user_id" : 2777090310,
  "text" : "@AlisonAEdwards Thanks :)",
  "id" : 911574062274621440,
  "in_reply_to_status_id" : 911475408104718336,
  "created_at" : "2017-09-23 12:52:47 +0000",
  "in_reply_to_screen_name" : "AlisonAEdwards",
  "in_reply_to_user_id_str" : "2777090310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911256074573008897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238609413344, 8.62748612440942 ]
  },
  "id_str" : "911256264134610944",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb Das in der Regel schon, aber dann wird halt nur gesagt \u201Ewir haben X getestet und war significant\u201C, w\u00E4hrend tests A-W verschwiegen werden\u2026",
  "id" : 911256264134610944,
  "in_reply_to_status_id" : 911256074573008897,
  "created_at" : "2017-09-22 15:49:58 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911254998973022208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234247471267, 8.62749956840423 ]
  },
  "id_str" : "911255555074924544",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb Ist leider auch nicht so selten das nur die Tests genannt werden die signifikant waren ohne zu erw\u00E4hnen was man sonst so gemacht hat.",
  "id" : 911255555074924544,
  "in_reply_to_status_id" : 911254998973022208,
  "created_at" : "2017-09-22 15:47:09 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911204252231626752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234158086266, 8.627512116343206 ]
  },
  "id_str" : "911209428808077312",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg If they\u2019d increase their power they\u2019ll get \u201Estatistically significant, but economically insignificant results.\u201C Effect size matters :D",
  "id" : 911209428808077312,
  "in_reply_to_status_id" : 911204252231626752,
  "created_at" : "2017-09-22 12:43:51 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911204252231626752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234158086266, 8.627512116343206 ]
  },
  "id_str" : "911209319848464384",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg understanding statistical power isn\u2019t everyone\u2019s strong suite it seems.",
  "id" : 911209319848464384,
  "in_reply_to_status_id" : 911204252231626752,
  "created_at" : "2017-09-22 12:43:25 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "European Commission",
      "screen_name" : "EU_Commission",
      "indices" : [ 23, 37 ],
      "id_str" : "157981564",
      "id" : 157981564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "copyright",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Sxshdxy3KZ",
      "expanded_url" : "https:\/\/juliareda.eu\/2017\/09\/secret-copyright-infringement-study\/",
      "display_url" : "juliareda.eu\/2017\/09\/secret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "911201553570295808",
  "text" : "RT @Senficon: What the @EU_Commission found out about #copyright infringement but \u2018forgot\u2019 to tell us https:\/\/t.co\/Sxshdxy3KZ https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "European Commission",
        "screen_name" : "EU_Commission",
        "indices" : [ 9, 23 ],
        "id_str" : "157981564",
        "id" : 157981564
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/910483224731820033\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Vk4Q74k1Hv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DKKvqPsWAAABLuN.png",
        "id_str" : "910483214984151040",
        "id" : 910483214984151040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DKKvqPsWAAABLuN.png",
        "sizes" : [ {
          "h" : 752,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/Vk4Q74k1Hv"
      } ],
      "hashtags" : [ {
        "text" : "copyright",
        "indices" : [ 40, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Sxshdxy3KZ",
        "expanded_url" : "https:\/\/juliareda.eu\/2017\/09\/secret-copyright-infringement-study\/",
        "display_url" : "juliareda.eu\/2017\/09\/secret\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "910483224731820033",
    "text" : "What the @EU_Commission found out about #copyright infringement but \u2018forgot\u2019 to tell us https:\/\/t.co\/Sxshdxy3KZ https:\/\/t.co\/Vk4Q74k1Hv",
    "id" : 910483224731820033,
    "created_at" : "2017-09-20 12:38:11 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 911201553570295808,
  "created_at" : "2017-09-22 12:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911200091167391744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238963595661, 8.627472722359704 ]
  },
  "id_str" : "911201408266928130",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Hahaha, das ist ja geil \uD83D\uDE02\uD83D\uDE02",
  "id" : 911201408266928130,
  "in_reply_to_status_id" : 911200091167391744,
  "created_at" : "2017-09-22 12:11:59 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911199130579603456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233791215925, 8.62750844503088 ]
  },
  "id_str" : "911199931318390785",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg um welche Ergebnisse gehts? Nicht das es f\u00FCr den File drawer effect eine gro\u00DFe Rolle spielt :D",
  "id" : 911199931318390785,
  "in_reply_to_status_id" : 911199130579603456,
  "created_at" : "2017-09-22 12:06:07 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    }, {
      "name" : "Adrian Altenhoff",
      "screen_name" : "AdrianAltenhoff",
      "indices" : [ 11, 27 ],
      "id_str" : "945855703",
      "id" : 945855703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911197884925833218",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233896804776, 8.627507926290454 ]
  },
  "id_str" : "911199759532257280",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz @AdrianAltenhoff guess line 40 in `lib\/Platforms` should not be `elif getenv('SGE_ROOT')&lt;&gt;\u2019` but rather `SGE_TASK_ID` or `JOB_ID` to avoid the issue.",
  "id" : 911199759532257280,
  "in_reply_to_status_id" : 911197884925833218,
  "created_at" : "2017-09-22 12:05:26 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    }, {
      "name" : "Adrian Altenhoff",
      "screen_name" : "AdrianAltenhoff",
      "indices" : [ 11, 27 ],
      "id_str" : "945855703",
      "id" : 945855703
    }, {
      "name" : "SPAdes assembler",
      "screen_name" : "spadesassembler",
      "indices" : [ 79, 95 ],
      "id_str" : "569820386",
      "id" : 569820386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911197884925833218",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723310158549, 8.627521029488847 ]
  },
  "id_str" : "911198428843134977",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz @AdrianAltenhoff Thanks! And it would be great if it was on GitHub! @spadesassembler made the switch a while back to facilitate community bug reports.",
  "id" : 911198428843134977,
  "in_reply_to_status_id" : 911197884925833218,
  "created_at" : "2017-09-22 12:00:09 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911196253941374976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238784838546, 8.627486770623936 ]
  },
  "id_str" : "911197223677038592",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz In that case OMA says there\u2019s nothing to do, despite $SLURM_ARRAY_TASK_ID being present, making debugging really hard \uD83D\uDE02 2\/2",
  "id" : 911197223677038592,
  "in_reply_to_status_id" : 911196253941374976,
  "created_at" : "2017-09-22 11:55:22 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911196253941374976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233556811304, 8.62754515421438 ]
  },
  "id_str" : "911196896923877378",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz I spent the morning trying to figure out why OMA wouldn\u2019t run on our Slurm. Issue was that $SGE_ROOT was still set from old setup. 1\/x",
  "id" : 911196896923877378,
  "in_reply_to_status_id" : 911196253941374976,
  "created_at" : "2017-09-22 11:54:04 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911196253941374976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233556811304, 8.62754515421438 ]
  },
  "id_str" : "911196533932126208",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz Not necessarily contribute at lareg, but would be great to see which bugs are already known and which ones not. :)",
  "id" : 911196533932126208,
  "in_reply_to_status_id" : 911196253941374976,
  "created_at" : "2017-09-22 11:52:37 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 0, 10 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232940980621, 8.627525387253094 ]
  },
  "id_str" : "911195398110359552",
  "in_reply_to_user_id" : 274388734,
  "text" : "@cdessimoz I was wondering, is the OMA standalone somewhere on GitHub? :)",
  "id" : 911195398110359552,
  "created_at" : "2017-09-22 11:48:06 +0000",
  "in_reply_to_screen_name" : "cdessimoz",
  "in_reply_to_user_id_str" : "274388734",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911104980374966272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397175111748, 8.753268705820386 ]
  },
  "id_str" : "911119798599340032",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Danke!",
  "id" : 911119798599340032,
  "in_reply_to_status_id" : 911104980374966272,
  "created_at" : "2017-09-22 06:47:42 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Lorenz K. Adlung on\/off Berg",
      "screen_name" : "LorenzAdlung",
      "indices" : [ 0, 13 ],
      "id_str" : "1623124639",
      "id" : 1623124639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910972210717888514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403949674691, 8.753357706934699 ]
  },
  "id_str" : "910973321726107650",
  "in_reply_to_user_id" : 1623124639,
  "text" : "@LorenzAdlung thanks! :)",
  "id" : 910973321726107650,
  "in_reply_to_status_id" : 910972210717888514,
  "created_at" : "2017-09-21 21:05:39 +0000",
  "in_reply_to_screen_name" : "LorenzAdlung",
  "in_reply_to_user_id_str" : "1623124639",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liane G. Benning",
      "screen_name" : "LianeGBenning",
      "indices" : [ 0, 14 ],
      "id_str" : "274870271",
      "id" : 274870271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910958153151414278",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412202735124, 8.753331657753147 ]
  },
  "id_str" : "910971482121101312",
  "in_reply_to_user_id" : 274870271,
  "text" : "@LianeGBenning Thanks! :)",
  "id" : 910971482121101312,
  "in_reply_to_status_id" : 910958153151414278,
  "created_at" : "2017-09-21 20:58:21 +0000",
  "in_reply_to_screen_name" : "LianeGBenning",
  "in_reply_to_user_id_str" : "274870271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910950164906610693",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403641924022, 8.753354301904299 ]
  },
  "id_str" : "910954711444058113",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd @NazeefaFatima Thanks! :)",
  "id" : 910954711444058113,
  "in_reply_to_status_id" : 910950164906610693,
  "created_at" : "2017-09-21 19:51:42 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owlice",
      "screen_name" : "owlice",
      "indices" : [ 0, 7 ],
      "id_str" : "1757362856",
      "id" : 1757362856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910917388220141568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235451663128, 8.62750530593622 ]
  },
  "id_str" : "910918541880291328",
  "in_reply_to_user_id" : 1757362856,
  "text" : "@owlice thanks! :)",
  "id" : 910918541880291328,
  "in_reply_to_status_id" : 910917388220141568,
  "created_at" : "2017-09-21 17:27:59 +0000",
  "in_reply_to_screen_name" : "owlice",
  "in_reply_to_user_id_str" : "1757362856",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 0, 15 ],
      "id_str" : "841497890",
      "id" : 841497890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910860436228202496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233482406834, 8.62753104177564 ]
  },
  "id_str" : "910868214468538369",
  "in_reply_to_user_id" : 841497890,
  "text" : "@JonathanSobel1 thanks!",
  "id" : 910868214468538369,
  "in_reply_to_status_id" : 910860436228202496,
  "created_at" : "2017-09-21 14:08:00 +0000",
  "in_reply_to_screen_name" : "JonathanSobel1",
  "in_reply_to_user_id_str" : "841497890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910833551565828096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239742674265, 8.627441937266244 ]
  },
  "id_str" : "910853106002534401",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience Thanks. Will soon have time to answer your email, as soon as I make it through the backlog \uD83D\uDE02",
  "id" : 910853106002534401,
  "in_reply_to_status_id" : 910833551565828096,
  "created_at" : "2017-09-21 13:07:57 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahmed Khalil",
      "screen_name" : "AhmedAAKhalil",
      "indices" : [ 0, 14 ],
      "id_str" : "399677490",
      "id" : 399677490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910768804585771008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225835819486, 8.62753062216718 ]
  },
  "id_str" : "910837401764945921",
  "in_reply_to_user_id" : 399677490,
  "text" : "@AhmedAAKhalil Good luck!",
  "id" : 910837401764945921,
  "in_reply_to_status_id" : 910768804585771008,
  "created_at" : "2017-09-21 12:05:33 +0000",
  "in_reply_to_screen_name" : "AhmedAAKhalil",
  "in_reply_to_user_id_str" : "399677490",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 10, 23 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910809558473478144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234758457004, 8.627520301583996 ]
  },
  "id_str" : "910814213907664896",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt @RaoOfPhysics Thanks! \uD83D\uDC96",
  "id" : 910814213907664896,
  "in_reply_to_status_id" : 910809558473478144,
  "created_at" : "2017-09-21 10:33:25 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910800395487891457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230041034263, 8.627545369489463 ]
  },
  "id_str" : "910800425552695296",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski Thanks!",
  "id" : 910800425552695296,
  "in_reply_to_status_id" : 910800395487891457,
  "created_at" : "2017-09-21 09:38:37 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910800327972151301",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230041034263, 8.627545369489463 ]
  },
  "id_str" : "910800362700967937",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp thanks! :)",
  "id" : 910800362700967937,
  "in_reply_to_status_id" : 910800327972151301,
  "created_at" : "2017-09-21 09:38:22 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Ie8GfscYOj",
      "expanded_url" : "http:\/\/ruleofthirds.de\/writing-up-a-phd\/",
      "display_url" : "ruleofthirds.de\/writing-up-a-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "910799543574417408",
  "text" : "RT @gedankenstuecke: I submitted my PhD thesis today. \uD83C\uDF89 To celebrate it I studied my own writing behavior. https:\/\/t.co\/Ie8GfscYOj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Ie8GfscYOj",
        "expanded_url" : "http:\/\/ruleofthirds.de\/writing-up-a-phd\/",
        "display_url" : "ruleofthirds.de\/writing-up-a-p\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11403905809582, 8.75335897543058 ]
    },
    "id_str" : "910619529151156224",
    "text" : "I submitted my PhD thesis today. \uD83C\uDF89 To celebrate it I studied my own writing behavior. https:\/\/t.co\/Ie8GfscYOj",
    "id" : 910619529151156224,
    "created_at" : "2017-09-20 21:39:48 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 910799543574417408,
  "created_at" : "2017-09-21 09:35:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910778922232680448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232708758079, 8.627524055916236 ]
  },
  "id_str" : "910779614036942848",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Vielen Dank!",
  "id" : 910779614036942848,
  "in_reply_to_status_id" : 910778922232680448,
  "created_at" : "2017-09-21 08:15:56 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910767449863319552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232708758079, 8.627524055916236 ]
  },
  "id_str" : "910779518071267331",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman now I\u2019ll finally be able to join our gatherings on Tuesdays!",
  "id" : 910779518071267331,
  "in_reply_to_status_id" : 910767449863319552,
  "created_at" : "2017-09-21 08:15:33 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910767065920937985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233750582725, 8.627513984275225 ]
  },
  "id_str" : "910778766586204161",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Thanks! And always thinking about the next step. Still would like to see all the open science things transformed into a PhD \uD83D\uDE02",
  "id" : 910778766586204161,
  "in_reply_to_status_id" : 910767065920937985,
  "created_at" : "2017-09-21 08:12:34 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910759391976095744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233750582725, 8.627513984275225 ]
  },
  "id_str" : "910778627553361920",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Thanks! I spared you the proof reading this time. \uD83D\uDE09",
  "id" : 910778627553361920,
  "in_reply_to_status_id" : 910759391976095744,
  "created_at" : "2017-09-21 08:12:00 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 0, 10 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910751631029018625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233750582725, 8.627513984275225 ]
  },
  "id_str" : "910778516400197632",
  "in_reply_to_user_id" : 4841450680,
  "text" : "@robinnkok Thanks! \u263A\uFE0F",
  "id" : 910778516400197632,
  "in_reply_to_status_id" : 910751631029018625,
  "created_at" : "2017-09-21 08:11:34 +0000",
  "in_reply_to_screen_name" : "robinnkok",
  "in_reply_to_user_id_str" : "4841450680",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910751019981778944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233750582725, 8.627513984275225 ]
  },
  "id_str" : "910778472758415360",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Danke! \uD83D\uDE18",
  "id" : 910778472758415360,
  "in_reply_to_status_id" : 910751019981778944,
  "created_at" : "2017-09-21 08:11:24 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/5SH4XSQlx6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/910619529151156224",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "910750501469343744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232612139954, 8.627528030013217 ]
  },
  "id_str" : "910757285663780865",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman Thanks, I hadn\u2019t! I was too busy with this! https:\/\/t.co\/5SH4XSQlx6 \uD83D\uDE02",
  "id" : 910757285663780865,
  "in_reply_to_status_id" : 910750501469343744,
  "created_at" : "2017-09-21 06:47:12 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie van Buggenum",
      "screen_name" : "sciencyjessie",
      "indices" : [ 0, 14 ],
      "id_str" : "790522807742586880",
      "id" : 790522807742586880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910745355544875008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403943113206, 8.753361186866993 ]
  },
  "id_str" : "910746336869437440",
  "in_reply_to_user_id" : 790522807742586880,
  "text" : "@sciencyjessie Oh, that\u2019s great to hear. \uD83D\uDC4D All the best for writing up and all the other little things to pop up last minute!\u263A\uFE0F\uD83D\uDE4F",
  "id" : 910746336869437440,
  "in_reply_to_status_id" : 910745355544875008,
  "created_at" : "2017-09-21 06:03:42 +0000",
  "in_reply_to_screen_name" : "sciencyjessie",
  "in_reply_to_user_id_str" : "790522807742586880",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 0, 16 ],
      "id_str" : "25774136",
      "id" : 25774136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910720443358732288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392967145265, 8.753211707820501 ]
  },
  "id_str" : "910738242974240768",
  "in_reply_to_user_id" : 25774136,
  "text" : "@Mikey_Whitehead Thanks! I\u2019ll try as soon as possible :)",
  "id" : 910738242974240768,
  "in_reply_to_status_id" : 910720443358732288,
  "created_at" : "2017-09-21 05:31:32 +0000",
  "in_reply_to_screen_name" : "Mikey_Whitehead",
  "in_reply_to_user_id_str" : "25774136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910689617233375232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392967145265, 8.753211707820501 ]
  },
  "id_str" : "910737873049137152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Thanks, now I can finally become a useful member of the openSNP team again. \uD83D\uDE02",
  "id" : 910737873049137152,
  "in_reply_to_status_id" : 910689617233375232,
  "created_at" : "2017-09-21 05:30:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910687225523957760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392967145265, 8.753211707820501 ]
  },
  "id_str" : "910737638809899010",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD Unfortunately there\u2019s no time for that right now, but I\u2019ll make sure to take some time off later this year :)",
  "id" : 910737638809899010,
  "in_reply_to_status_id" : 910687225523957760,
  "created_at" : "2017-09-21 05:29:08 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Stroehlein",
      "screen_name" : "stroehli",
      "indices" : [ 0, 9 ],
      "id_str" : "831094674",
      "id" : 831094674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910663605023993859",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392967145265, 8.753211707820501 ]
  },
  "id_str" : "910737388766470144",
  "in_reply_to_user_id" : 831094674,
  "text" : "@stroehli Danke \u263A\uFE0F",
  "id" : 910737388766470144,
  "in_reply_to_status_id" : 910663605023993859,
  "created_at" : "2017-09-21 05:28:08 +0000",
  "in_reply_to_screen_name" : "stroehli",
  "in_reply_to_user_id_str" : "831094674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olga Perkovic",
      "screen_name" : "operkovic",
      "indices" : [ 0, 10 ],
      "id_str" : "248717660",
      "id" : 248717660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910643417700499457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403277369543, 8.753356033666561 ]
  },
  "id_str" : "910644208586887168",
  "in_reply_to_user_id" : 248717660,
  "text" : "@operkovic Thanks!",
  "id" : 910644208586887168,
  "in_reply_to_status_id" : 910643417700499457,
  "created_at" : "2017-09-20 23:17:52 +0000",
  "in_reply_to_screen_name" : "operkovic",
  "in_reply_to_user_id_str" : "248717660",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910643313077882883",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403277369543, 8.753356033666561 ]
  },
  "id_str" : "910644155357040640",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner There\u2019s always some data that waits to be looked at :)",
  "id" : 910644155357040640,
  "in_reply_to_status_id" : 910643313077882883,
  "created_at" : "2017-09-20 23:17:40 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910636426663989248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403350949308, 8.753357240814067 ]
  },
  "id_str" : "910639416028344320",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 Danke! \uD83C\uDF89",
  "id" : 910639416028344320,
  "in_reply_to_status_id" : 910636426663989248,
  "created_at" : "2017-09-20 22:58:50 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910636773293817856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403350949308, 8.753357240814067 ]
  },
  "id_str" : "910639380628492288",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD Thanks! \u263A\uFE0F",
  "id" : 910639380628492288,
  "in_reply_to_status_id" : 910636773293817856,
  "created_at" : "2017-09-20 22:58:41 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910629158413201408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382726185467, 8.753306579921796 ]
  },
  "id_str" : "910629408284790784",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez The draw back of Sci-Hub: you don\u2019t have to walk over to the library any more. \uD83D\uDE02",
  "id" : 910629408284790784,
  "in_reply_to_status_id" : 910629158413201408,
  "created_at" : "2017-09-20 22:19:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910628448787251200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905833768, 8.753358975538715 ]
  },
  "id_str" : "910628799372546048",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yeah, I\u2019ll pull that data out as well and look into it. I guess my step count went down to something like 3.5-4k\/day.",
  "id" : 910628799372546048,
  "in_reply_to_status_id" : 910628448787251200,
  "created_at" : "2017-09-20 22:16:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910627921525579777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905833768, 8.753358975538715 ]
  },
  "id_str" : "910628133631594496",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks. Wondering: Did you do some QS around your thesis? :)",
  "id" : 910628133631594496,
  "in_reply_to_status_id" : 910627921525579777,
  "created_at" : "2017-09-20 22:14:00 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910626058277441541",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403916230802, 8.753359166179678 ]
  },
  "id_str" : "910626828565581824",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb barely, but it somehow worked out \uD83D\uDE0A",
  "id" : 910626828565581824,
  "in_reply_to_status_id" : 910626058277441541,
  "created_at" : "2017-09-20 22:08:49 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/YENLwEmndL",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/3oEduXcQeQCX3vwxxK\/giphy.gif",
      "display_url" : "media3.giphy.com\/media\/3oEduXcQ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "910625989331423232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403809945299, 8.753357217318579 ]
  },
  "id_str" : "910626688773607424",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb my kind of fun. https:\/\/t.co\/YENLwEmndL",
  "id" : 910626688773607424,
  "in_reply_to_status_id" : 910625989331423232,
  "created_at" : "2017-09-20 22:08:15 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910622992295759872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905465401, 8.753358968650534 ]
  },
  "id_str" : "910625867415552000",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin thanks! \uD83D\uDE0A",
  "id" : 910625867415552000,
  "in_reply_to_status_id" : 910622992295759872,
  "created_at" : "2017-09-20 22:05:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910623994688262144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905465401, 8.753358968650534 ]
  },
  "id_str" : "910625808242413568",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog thanks!",
  "id" : 910625808242413568,
  "in_reply_to_status_id" : 910623994688262144,
  "created_at" : "2017-09-20 22:04:45 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 0, 14 ],
      "id_str" : "130490305",
      "id" : 130490305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910624756000546817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905465401, 8.753358968650534 ]
  },
  "id_str" : "910625732690366465",
  "in_reply_to_user_id" : 130490305,
  "text" : "@rachaelevelyn thanks, next time we can have a meeting that\u2019s a bit less stressed on my side. \uD83D\uDE09",
  "id" : 910625732690366465,
  "in_reply_to_status_id" : 910624756000546817,
  "created_at" : "2017-09-20 22:04:27 +0000",
  "in_reply_to_screen_name" : "rachaelevelyn",
  "in_reply_to_user_id_str" : "130490305",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910622322524131328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905832174, 8.753358975510285 ]
  },
  "id_str" : "910623096780017664",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock I manually classified #BOSC2017 as \u201Every productive\u201C so I could justify my going to Prague \uD83D\uDE09",
  "id" : 910623096780017664,
  "in_reply_to_status_id" : 910622322524131328,
  "created_at" : "2017-09-20 21:53:59 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910622690268127238",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905832174, 8.753358975510285 ]
  },
  "id_str" : "910622909001093120",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest Thanks \uD83D\uDE0A I spent half a day fiddling around with R to do those plots, that\u2019s a good way to clear my mind. \uD83D\uDE02",
  "id" : 910622909001093120,
  "in_reply_to_status_id" : 910622690268127238,
  "created_at" : "2017-09-20 21:53:14 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910620831998529537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140391627163, 8.753359166918036 ]
  },
  "id_str" : "910621877776809984",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock Thanks! Now I will come out of the hiding and be available again for all things BOSC. :)",
  "id" : 910621877776809984,
  "in_reply_to_status_id" : 910620831998529537,
  "created_at" : "2017-09-20 21:49:08 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0CB8\u0CAE\u0CB0\u0CCD\u0CA5 \u0C86\u0CB0\u0CCD\u0CAF",
      "screen_name" : "SamarthArya",
      "indices" : [ 0, 12 ],
      "id_str" : "83054101",
      "id" : 83054101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910621181270794240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140391627163, 8.753359166918036 ]
  },
  "id_str" : "910621724445732865",
  "in_reply_to_user_id" : 83054101,
  "text" : "@SamarthArya thanks!",
  "id" : 910621724445732865,
  "in_reply_to_status_id" : 910621181270794240,
  "created_at" : "2017-09-20 21:48:32 +0000",
  "in_reply_to_screen_name" : "SamarthArya",
  "in_reply_to_user_id_str" : "83054101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Ie8GfscYOj",
      "expanded_url" : "http:\/\/ruleofthirds.de\/writing-up-a-phd\/",
      "display_url" : "ruleofthirds.de\/writing-up-a-p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403905809582, 8.75335897543058 ]
  },
  "id_str" : "910619529151156224",
  "text" : "I submitted my PhD thesis today. \uD83C\uDF89 To celebrate it I studied my own writing behavior. https:\/\/t.co\/Ie8GfscYOj",
  "id" : 910619529151156224,
  "created_at" : "2017-09-20 21:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Gaston",
      "screen_name" : "nicgaston",
      "indices" : [ 3, 13 ],
      "id_str" : "263048486",
      "id" : 263048486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninstem",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "909404426724659200",
  "text" : "RT @nicgaston: Oh my god \uD83D\uDE31\uD83D\uDE2D\n\"He gave me a new vacuum cleaner to soften the blow...\"\n(&amp; that isn't even the best bit \uD83D\uDE02)\n#womeninstem\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninstem",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/uG7mYrRQra",
        "expanded_url" : "http:\/\/m.huffpost.com\/uk\/entry\/17908074",
        "display_url" : "m.huffpost.com\/uk\/entry\/17908\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "909346871654588416",
    "text" : "Oh my god \uD83D\uDE31\uD83D\uDE2D\n\"He gave me a new vacuum cleaner to soften the blow...\"\n(&amp; that isn't even the best bit \uD83D\uDE02)\n#womeninstem\nhttps:\/\/t.co\/uG7mYrRQra",
    "id" : 909346871654588416,
    "created_at" : "2017-09-17 09:22:43 +0000",
    "user" : {
      "name" : "Nicola Gaston",
      "screen_name" : "nicgaston",
      "protected" : false,
      "id_str" : "263048486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864021205849853952\/SadlJ4Sb_normal.jpg",
      "id" : 263048486,
      "verified" : false
    }
  },
  "id" : 909404426724659200,
  "created_at" : "2017-09-17 13:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 3, 16 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Scholarly Commons",
      "screen_name" : "ScholrlyCommons",
      "indices" : [ 75, 91 ],
      "id_str" : "856957674793033728",
      "id" : 856957674793033728
    }, {
      "name" : "Force11.org",
      "screen_name" : "force11rescomm",
      "indices" : [ 99, 114 ],
      "id_str" : "720754110",
      "id" : 720754110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908710984776372225",
  "text" : "RT @jeroenbosman: Can we define the scholarly commons? New preprint on the @ScholrlyCommons by the @force11rescomm SCWG working group https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scholarly Commons",
        "screen_name" : "ScholrlyCommons",
        "indices" : [ 57, 73 ],
        "id_str" : "856957674793033728",
        "id" : 856957674793033728
      }, {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 81, 96 ],
        "id_str" : "720754110",
        "id" : 720754110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/908701917701918720\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/ZCra8HwXSf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJxbVWhXUAAAgn8.png",
        "id_str" : "908701647202897920",
        "id" : 908701647202897920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJxbVWhXUAAAgn8.png",
        "sizes" : [ {
          "h" : 952,
          "resize" : "fit",
          "w" : 1664
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 1664
        } ],
        "display_url" : "pic.twitter.com\/ZCra8HwXSf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/JGvjIPRvRq",
        "expanded_url" : "https:\/\/osf.io\/6c2xt",
        "display_url" : "osf.io\/6c2xt"
      } ]
    },
    "geo" : { },
    "id_str" : "908701917701918720",
    "text" : "Can we define the scholarly commons? New preprint on the @ScholrlyCommons by the @force11rescomm SCWG working group https:\/\/t.co\/JGvjIPRvRq https:\/\/t.co\/ZCra8HwXSf",
    "id" : 908701917701918720,
    "created_at" : "2017-09-15 14:39:54 +0000",
    "user" : {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "protected" : false,
      "id_str" : "9104202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853627325715558401\/_66XunIl_normal.jpg",
      "id" : 9104202,
      "verified" : false
    }
  },
  "id" : 908710984776372225,
  "created_at" : "2017-09-15 15:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Nicholls",
      "screen_name" : "samstudio8",
      "indices" : [ 0, 11 ],
      "id_str" : "40444555",
      "id" : 40444555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/zaZi0nSGNa",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/908680447806312448",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "908687556396580864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234476194489, 8.627525948657276 ]
  },
  "id_str" : "908689356650696704",
  "in_reply_to_user_id" : 40444555,
  "text" : "@samstudio8 absolutely, c.f. https:\/\/t.co\/zaZi0nSGNa :D",
  "id" : 908689356650696704,
  "in_reply_to_status_id" : 908687556396580864,
  "created_at" : "2017-09-15 13:49:59 +0000",
  "in_reply_to_screen_name" : "samstudio8",
  "in_reply_to_user_id_str" : "40444555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 19, 32 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908684130518491136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235419660319, 8.627525490115662 ]
  },
  "id_str" : "908686721730179072",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps I\u2019m sure @RaoOfPhysics can provide a fun one. His German translation for the LHC is just hilariously good :)",
  "id" : 908686721730179072,
  "in_reply_to_status_id" : 908684130518491136,
  "created_at" : "2017-09-15 13:39:31 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 9, 24 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908680753889861632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231732399233, 8.627531848334307 ]
  },
  "id_str" : "908685178532442112",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @TheLabAndField I\u2019m trying :)",
  "id" : 908685178532442112,
  "in_reply_to_status_id" : 908680753889861632,
  "created_at" : "2017-09-15 13:33:23 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 9, 24 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908680300741431296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233041778086, 8.627522145813149 ]
  },
  "id_str" : "908680447806312448",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @TheLabAndField just try saying Genomassemblierungsmethoden 10x in a row.",
  "id" : 908680447806312448,
  "in_reply_to_status_id" : 908680300741431296,
  "created_at" : "2017-09-15 13:14:35 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/uNRvXu12gq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ghRKZRcxeI4",
      "display_url" : "youtube.com\/watch?v=ghRKZR\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "908669719082872832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233002767652, 8.627521092924956 ]
  },
  "id_str" : "908671347643092992",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField no, the language isn\u2019t totally famous for that. https:\/\/t.co\/uNRvXu12gq \uD83D\uDE02",
  "id" : 908671347643092992,
  "in_reply_to_status_id" : 908669719082872832,
  "created_at" : "2017-09-15 12:38:26 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234764475332, 8.627511298826038 ]
  },
  "id_str" : "908669180517519363",
  "text" : "Barely managed to summarize my thesis in English on 1 1\/2 pages. Now I also have to do a 2 page summary in German. How should that work?!",
  "id" : 908669180517519363,
  "created_at" : "2017-09-15 12:29:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908480517145874432",
  "text" : "RT @TheLabAndField: I\u2019m going house hunting this weekend, so here\u2019s a story a day early! It\u2019s been 12 years (well, -1 day) since I came out\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEM",
        "indices" : [ 120, 129 ]
      }, {
        "text" : "QueerSTEM",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "908424953204264963",
    "text" : "I\u2019m going house hunting this weekend, so here\u2019s a story a day early! It\u2019s been 12 years (well, -1 day) since I came out #LGBTSTEM #QueerSTEM",
    "id" : 908424953204264963,
    "created_at" : "2017-09-14 20:19:21 +0000",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 908480517145874432,
  "created_at" : "2017-09-15 00:00:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 16, 32 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 33, 38 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908374386385793025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235817109697, 8.627485648692481 ]
  },
  "id_str" : "908375513894457345",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @cshperspectives @klmr I regularly see users wishing for better HTML pages, but then most people on publisher side don\u2019t listen unless it makes them more money.",
  "id" : 908375513894457345,
  "in_reply_to_status_id" : 908374386385793025,
  "created_at" : "2017-09-14 17:02:53 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 16, 32 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 33, 38 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908373271774711808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233258846928, 8.627531138015792 ]
  },
  "id_str" : "908373770066432001",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @cshperspectives @klmr (I mean, of course the vast majority of comm. publishers has zero interest in serving the people who\u2019re reading what they publish)",
  "id" : 908373770066432001,
  "in_reply_to_status_id" : 908373271774711808,
  "created_at" : "2017-09-14 16:55:58 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 16, 32 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 33, 38 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908373271774711808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233258846928, 8.627531138015792 ]
  },
  "id_str" : "908373519611912192",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @cshperspectives @klmr ok, let\u2019s say that no user who\u2019s calling for better HTML says that PDFs should vanish?",
  "id" : 908373519611912192,
  "in_reply_to_status_id" : 908373271774711808,
  "created_at" : "2017-09-14 16:54:58 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthi Landau",
      "screen_name" : "ruthi_landau",
      "indices" : [ 0, 13 ],
      "id_str" : "700473181308481536",
      "id" : 700473181308481536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908371427405033472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18389233999999, 8.615399519999999 ]
  },
  "id_str" : "908371594510311424",
  "in_reply_to_user_id" : 700473181308481536,
  "text" : "@ruthi_landau It\u2019s the same tired look of having written for 40 days straight. \uD83D\uDE02",
  "id" : 908371594510311424,
  "in_reply_to_status_id" : 908371427405033472,
  "created_at" : "2017-09-14 16:47:19 +0000",
  "in_reply_to_screen_name" : "ruthi_landau",
  "in_reply_to_user_id_str" : "700473181308481536",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruthi Landau",
      "screen_name" : "ruthi_landau",
      "indices" : [ 0, 13 ],
      "id_str" : "700473181308481536",
      "id" : 700473181308481536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908370901053448192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18389233999999, 8.615399519999999 ]
  },
  "id_str" : "908371293250170880",
  "in_reply_to_user_id" : 700473181308481536,
  "text" : "@ruthi_landau I cheated by doing both on the same day. \uD83D\uDE09",
  "id" : 908371293250170880,
  "in_reply_to_status_id" : 908370901053448192,
  "created_at" : "2017-09-14 16:46:07 +0000",
  "in_reply_to_screen_name" : "ruthi_landau",
  "in_reply_to_user_id_str" : "700473181308481536",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908363181558464512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235916578227, 8.62749276683538 ]
  },
  "id_str" : "908363321304342530",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya Thanks! It\u2019s certainly better than my perl skills!",
  "id" : 908363321304342530,
  "in_reply_to_status_id" : 908363181558464512,
  "created_at" : "2017-09-14 16:14:27 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908361146390007812",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231538478897, 8.627531367728617 ]
  },
  "id_str" : "908362547501391872",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya \u05DB\u05DB\u05D4 \u05DB\u05DB\u05D4, \u05D0\u05E0\u05D9 \u05E2\u05D3\u05D9\u05D9\u05DF \u05DC\u05D5\u05DE\u05D3. \ne.g. totally sucking at it. but maybe g translate doesn\u2019t suck. \uD83D\uDE09",
  "id" : 908362547501391872,
  "in_reply_to_status_id" : 908361146390007812,
  "created_at" : "2017-09-14 16:11:22 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908361098096672769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237575476415, 8.627489445772122 ]
  },
  "id_str" : "908361368260268032",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya \u05EA\u05D5\u05D3\u05D4!",
  "id" : 908361368260268032,
  "in_reply_to_status_id" : 908361098096672769,
  "created_at" : "2017-09-14 16:06:41 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908356379672547334",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233341753355, 8.627524523227153 ]
  },
  "id_str" : "908359511899037697",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya is there a non-paywalled preprint? \uD83D\uDE09",
  "id" : 908359511899037697,
  "in_reply_to_status_id" : 908356379672547334,
  "created_at" : "2017-09-14 15:59:18 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 16, 21 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 22, 38 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/CKYLSok8Cf",
      "expanded_url" : "https:\/\/elifesciences.org\/articles\/25783",
      "display_url" : "elifesciences.org\/articles\/25783"
    } ]
  },
  "in_reply_to_status_id_str" : "908355564849303554",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233671311003, 8.627531304253422 ]
  },
  "id_str" : "908355846329061379",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @klmr @cshperspectives e.g. https:\/\/t.co\/CKYLSok8Cf you can choose to get figures (+ their data) or the references right next to the text w\/o losing focus.",
  "id" : 908355846329061379,
  "in_reply_to_status_id" : 908355564849303554,
  "created_at" : "2017-09-14 15:44:44 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 16, 32 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 33, 38 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908355423006314498",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233671311003, 8.627531304253422 ]
  },
  "id_str" : "908355633757478913",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @cshperspectives @klmr yep, and I don\u2019t want to take away your PDF. I just wish the HTML would make use of what the web can deliver these days.",
  "id" : 908355633757478913,
  "in_reply_to_status_id" : 908355423006314498,
  "created_at" : "2017-09-14 15:43:54 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 0, 16 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 17, 32 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 33, 38 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908353574765252608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723195204858, 8.627528986289581 ]
  },
  "id_str" : "908354073715511297",
  "in_reply_to_user_id" : 21242028,
  "text" : "@cshperspectives @michaelhoffman @klmr in some sense that\u2019s where we already are w\/ (whatever) HTML + PDF.",
  "id" : 908354073715511297,
  "in_reply_to_status_id" : 908353574765252608,
  "created_at" : "2017-09-14 15:37:42 +0000",
  "in_reply_to_screen_name" : "cshperspectives",
  "in_reply_to_user_id_str" : "21242028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 16, 21 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 22, 38 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908352393154351104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232593304121, 8.627537194843 ]
  },
  "id_str" : "908353195960913921",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @klmr @cshperspectives or quickly checking references w\/o losing the focus of where you\u2019ve been.",
  "id" : 908353195960913921,
  "in_reply_to_status_id" : 908352393154351104,
  "created_at" : "2017-09-14 15:34:12 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 16, 21 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 22, 38 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908352393154351104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232593304121, 8.627537194843 ]
  },
  "id_str" : "908353032131371010",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @klmr @cshperspectives I don\u2019t agree, elife\u2019s side-by-side feature for reading + viewing figures alone is so much better than scrolling through a PDF all the time.",
  "id" : 908353032131371010,
  "in_reply_to_status_id" : 908352393154351104,
  "created_at" : "2017-09-14 15:33:33 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 16, 21 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 22, 38 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908351960063119366",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235686003603, 8.62750183510223 ]
  },
  "id_str" : "908352215592697856",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @klmr @cshperspectives I don\u2019t care much about videos in publications either tbh, but interactive graphs are definitely a big big plus if you move away from PDF.",
  "id" : 908352215592697856,
  "in_reply_to_status_id" : 908351960063119366,
  "created_at" : "2017-09-14 15:30:19 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 16, 21 ],
      "id_str" : "773450",
      "id" : 773450
    }, {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 22, 38 ],
      "id_str" : "21242028",
      "id" : 21242028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "908350281372631040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233759441913, 8.627530441066291 ]
  },
  "id_str" : "908351333610266624",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @klmr @cshperspectives How many videos did you watch inside a PDF? \uD83D\uDE09",
  "id" : 908351333610266624,
  "in_reply_to_status_id" : 908350281372631040,
  "created_at" : "2017-09-14 15:26:48 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/T8is5i3y33",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901365456505884672",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908050990426980353",
  "text" : "Second draft: doesn't look so bad. \uD83D\uDE02 https:\/\/t.co\/T8is5i3y33",
  "id" : 908050990426980353,
  "created_at" : "2017-09-13 19:33:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BauhiniaGenome",
      "screen_name" : "BauhiniaGenome",
      "indices" : [ 3, 18 ],
      "id_str" : "3589537993",
      "id" : 3589537993
    }, {
      "name" : "Protocols.io",
      "screen_name" : "ProtocolsIO",
      "indices" : [ 44, 56 ],
      "id_str" : "2694150236",
      "id" : 2694150236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ZcbS86c1Ss",
      "expanded_url" : "https:\/\/www.protocols.io\/groups\/bauhinia-genome",
      "display_url" : "protocols.io\/groups\/bauhini\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "908027938741870592",
  "text" : "RT @BauhiniaGenome: Great suggestion to use @ProtocolsIO. Every community genome project should try it https:\/\/t.co\/ZcbS86c1Ss https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Protocols.io",
        "screen_name" : "ProtocolsIO",
        "indices" : [ 24, 36 ],
        "id_str" : "2694150236",
        "id" : 2694150236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ZcbS86c1Ss",
        "expanded_url" : "https:\/\/www.protocols.io\/groups\/bauhinia-genome",
        "display_url" : "protocols.io\/groups\/bauhini\u2026"
      }, {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/1TeI66Nnw1",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/907915703767982080",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "907930078469701632",
    "text" : "Great suggestion to use @ProtocolsIO. Every community genome project should try it https:\/\/t.co\/ZcbS86c1Ss https:\/\/t.co\/1TeI66Nnw1",
    "id" : 907930078469701632,
    "created_at" : "2017-09-13 11:32:53 +0000",
    "user" : {
      "name" : "BauhiniaGenome",
      "screen_name" : "BauhiniaGenome",
      "protected" : false,
      "id_str" : "3589537993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657829089554911232\/JdV4jgzR_normal.png",
      "id" : 3589537993,
      "verified" : false
    }
  },
  "id" : 908027938741870592,
  "created_at" : "2017-09-13 18:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232805348925, 8.627522790746928 ]
  },
  "id_str" : "907969911267438592",
  "text" : "Sci-Hub captcha of the day: \u201Eethics\u201C \uD83D\uDE02",
  "id" : 907969911267438592,
  "created_at" : "2017-09-13 14:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 10, 19 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 20, 35 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "hal",
      "screen_name" : "halhod",
      "indices" : [ 36, 43 ],
      "id_str" : "194122373",
      "id" : 194122373
    }, {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 44, 59 ],
      "id_str" : "16045268",
      "id" : 16045268
    }, {
      "name" : "Michael Zimmer",
      "screen_name" : "michaelzimmer",
      "indices" : [ 60, 74 ],
      "id_str" : "6168682",
      "id" : 6168682
    }, {
      "name" : "CenterForOpenScience",
      "screen_name" : "OSFramework",
      "indices" : [ 85, 97 ],
      "id_str" : "404946566",
      "id" : 404946566
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 98, 107 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907948540193902592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723365914198, 8.627508502009734 ]
  },
  "id_str" : "907950495234437120",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @podehaye @EmilyGorcenski @halhod @insidehighered @michaelzimmer @kopshtik @OSFramework @madprime aggregated search data is much more anonymous than portrait pictures (unless Venter predicted the latter).",
  "id" : 907950495234437120,
  "in_reply_to_status_id" : 907948540193902592,
  "created_at" : "2017-09-13 12:54:01 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "hal",
      "screen_name" : "halhod",
      "indices" : [ 10, 17 ],
      "id_str" : "194122373",
      "id" : 194122373
    }, {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 28, 43 ],
      "id_str" : "16045268",
      "id" : 16045268
    }, {
      "name" : "Michael Zimmer",
      "screen_name" : "michaelzimmer",
      "indices" : [ 44, 58 ],
      "id_str" : "6168682",
      "id" : 6168682
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 59, 74 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907934557915238400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223678999596, 8.627481451266098 ]
  },
  "id_str" : "907937635276083200",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @halhod @kopshtik @insidehighered @michaelzimmer @EmilyGorcenski Fully agree.",
  "id" : 907937635276083200,
  "in_reply_to_status_id" : 907934557915238400,
  "created_at" : "2017-09-13 12:02:55 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hal",
      "screen_name" : "halhod",
      "indices" : [ 0, 7 ],
      "id_str" : "194122373",
      "id" : 194122373
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 8, 17 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 18, 33 ],
      "id_str" : "16045268",
      "id" : 16045268
    }, {
      "name" : "Michael Zimmer",
      "screen_name" : "michaelzimmer",
      "indices" : [ 34, 48 ],
      "id_str" : "6168682",
      "id" : 6168682
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 49, 64 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "CenterForOpenScience",
      "screen_name" : "OSFramework",
      "indices" : [ 75, 87 ],
      "id_str" : "404946566",
      "id" : 404946566
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 88, 97 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 98, 107 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907929700173041664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229677891291, 8.627540535937744 ]
  },
  "id_str" : "907929969497649152",
  "in_reply_to_user_id" : 194122373,
  "text" : "@halhod @podehaye @insidehighered @michaelzimmer @EmilyGorcenski @kopshtik @OSFramework @madprime @erlichya \u2018uploading a photo to the internet \u201Cinherently\u201D means that it will be used for something\u2019 Is Nimmer arguing that piracy is no big deal?",
  "id" : 907929969497649152,
  "in_reply_to_status_id" : 907929700173041664,
  "created_at" : "2017-09-13 11:32:27 +0000",
  "in_reply_to_screen_name" : "halhod",
  "in_reply_to_user_id_str" : "194122373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 0, 12 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "907923174960107520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229677891291, 8.627540535937744 ]
  },
  "id_str" : "907928397459976192",
  "in_reply_to_user_id" : 3295237359,
  "text" : "@beerdecoded hope you folks find it useful!",
  "id" : 907928397459976192,
  "in_reply_to_status_id" : 907923174960107520,
  "created_at" : "2017-09-13 11:26:13 +0000",
  "in_reply_to_screen_name" : "beerdecoded",
  "in_reply_to_user_id_str" : "3295237359",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 75, 90 ],
      "id_str" : "841497890",
      "id" : 841497890
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 95, 101 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Gianpaolo Rando",
      "screen_name" : "gianpaolo_rando",
      "indices" : [ 102, 118 ],
      "id_str" : "845091326",
      "id" : 845091326
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/wWbQc5Vzz7",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1676\/v1",
      "display_url" : "f1000research.com\/articles\/6-167\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235687583503, 8.627495995457997 ]
  },
  "id_str" : "907915703767982080",
  "text" : "Enjoyed reading &amp; reviewing the BeerDeCoded paper by #BOSC2017 speaker @JonathanSobel1 and @heluc @gianpaolo_rando. https:\/\/t.co\/wWbQc5Vzz7",
  "id" : 907915703767982080,
  "created_at" : "2017-09-13 10:35:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 10, 18 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 19, 25 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 26, 37 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 38, 48 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 49, 64 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "indices" : [ 65, 77 ],
      "id_str" : "20542737",
      "id" : 20542737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10601996312152, 8.744700001172012 ]
  },
  "id_str" : "906966235631452161",
  "text" : "@kopshtik @o_guest @mcknw @RaeKnowler @Hao_and_Y @EmilyGorcenski @vaughanbell I hadn\u2019t seen those updates to the notes\u2026 :\/",
  "id" : 906966235631452161,
  "created_at" : "2017-09-10 19:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 3, 12 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 57, 68 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906883309065703425",
  "text" : "RT @crowd_ai: 500 submissions and 18 days to go with the @openSNPorg height prediction challenge! Winner invited to present work at @applie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 43, 54 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Applied ML Days",
        "screen_name" : "appliedmldays",
        "indices" : [ 118, 132 ],
        "id_str" : "763052115392593920",
        "id" : 763052115392593920
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crowd_ai\/status\/906856490144858113\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/urFGwzmahY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJXM9j0WAAAlRLM.jpg",
        "id_str" : "906856257943896064",
        "id" : 906856257943896064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJXM9j0WAAAlRLM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 486
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 788
        } ],
        "display_url" : "pic.twitter.com\/urFGwzmahY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "906856490144858113",
    "text" : "500 submissions and 18 days to go with the @openSNPorg height prediction challenge! Winner invited to present work at @appliedmldays https:\/\/t.co\/urFGwzmahY",
    "id" : 906856490144858113,
    "created_at" : "2017-09-10 12:26:50 +0000",
    "user" : {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "protected" : false,
      "id_str" : "706885331224813568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710716318849363968\/JG-XbwBL_normal.jpg",
      "id" : 706885331224813568,
      "verified" : false
    }
  },
  "id" : 906883309065703425,
  "created_at" : "2017-09-10 14:13:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47732109066786, -1.902523518021114 ]
  },
  "id_str" : "906641282646278144",
  "text" : "Having to dance to super weird Greek pop songs? \u2714\uFE0F\uD83D\uDE44\uD83D\uDE02",
  "id" : 906641282646278144,
  "created_at" : "2017-09-09 22:11:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Hall-Lew",
      "screen_name" : "dialect",
      "indices" : [ 3, 11 ],
      "id_str" : "2184621",
      "id" : 2184621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ZeG0GihpaM",
      "expanded_url" : "https:\/\/vocalised.wordpress.com\/2017\/09\/09\/academics-we-need-to-talk-because-i-am-sick-and-tired-of-this\/",
      "display_url" : "vocalised.wordpress.com\/2017\/09\/09\/aca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906568000198856705",
  "text" : "RT @dialect: Academics, we need to talk, because I am sick and tired of\u00A0this. https:\/\/t.co\/ZeG0GihpaM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/ZeG0GihpaM",
        "expanded_url" : "https:\/\/vocalised.wordpress.com\/2017\/09\/09\/academics-we-need-to-talk-because-i-am-sick-and-tired-of-this\/",
        "display_url" : "vocalised.wordpress.com\/2017\/09\/09\/aca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "906458239813988354",
    "text" : "Academics, we need to talk, because I am sick and tired of\u00A0this. https:\/\/t.co\/ZeG0GihpaM",
    "id" : 906458239813988354,
    "created_at" : "2017-09-09 10:04:20 +0000",
    "user" : {
      "name" : "Lauren Hall-Lew",
      "screen_name" : "dialect",
      "protected" : false,
      "id_str" : "2184621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905079767598292992\/bWfjwhZE_normal.jpg",
      "id" : 2184621,
      "verified" : false
    }
  },
  "id" : 906568000198856705,
  "created_at" : "2017-09-09 17:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ZhhOnrlYoA",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BY04VhmlK18\/",
      "display_url" : "instagram.com\/p\/BY04VhmlK18\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47495398066, -1.9068386439181 ]
  },
  "id_str" : "906548392058384384",
  "text" : "\u2795 @ Marco Pierre White Steakhouse Bar and Grill Birmingham https:\/\/t.co\/ZhhOnrlYoA",
  "id" : 906548392058384384,
  "created_at" : "2017-09-09 16:02:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/9GZvGYTl5b",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BY0nESIlTTJ\/",
      "display_url" : "instagram.com\/p\/BY0nESIlTTJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.4667, -1.91667 ]
  },
  "id_str" : "906510408902742016",
  "text" : "\uD83D\uDE43 @ Birmingham, United Kingdom https:\/\/t.co\/9GZvGYTl5b",
  "id" : 906510408902742016,
  "created_at" : "2017-09-09 13:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/pZoTR4tlng",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BY0TnULl958\/",
      "display_url" : "instagram.com\/p\/BY0TnULl958\/"
    } ]
  },
  "geo" : { },
  "id_str" : "906467893272920064",
  "text" : "Getting all glittered up for the next wedding \uD83E\uDD84 https:\/\/t.co\/pZoTR4tlng",
  "id" : 906467893272920064,
  "created_at" : "2017-09-09 10:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/906452985441603584\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/mgtBZBSpEr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJReL0LX0AAcGJr.jpg",
      "id_str" : "906452982086225920",
      "id" : 906452982086225920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJReL0LX0AAcGJr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/mgtBZBSpEr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906452985441603584",
  "text" : "A \uD83D\uDC3B inspired by the recent Ghostbusters reboot. \uD83D\uDC7B https:\/\/t.co\/mgtBZBSpEr",
  "id" : 906452985441603584,
  "created_at" : "2017-09-09 09:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Village Inn",
      "screen_name" : "VillageBrum",
      "indices" : [ 56, 68 ],
      "id_str" : "102527818",
      "id" : 102527818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/iwGCZJScea",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/1uEspDuEE9E",
      "display_url" : "swarmapp.com\/c\/1uEspDuEE9E"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47250690536674, -1.8946539822385682 ]
  },
  "id_str" : "906289718974976001",
  "text" : "Fitting to the days discussions. \uD83D\uDE02 (@ The Village Inn - @villagebrum in Birmingham, West Mids.) https:\/\/t.co\/iwGCZJScea",
  "id" : 906289718974976001,
  "created_at" : "2017-09-08 22:54:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Exocortical",
      "screen_name" : "sir_deenicus",
      "indices" : [ 0, 13 ],
      "id_str" : "61322055",
      "id" : 61322055
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 14, 22 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 23, 32 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906276672730791936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47730375623804, -1.902578531396689 ]
  },
  "id_str" : "906280744733073409",
  "in_reply_to_user_id" : 61322055,
  "text" : "@sir_deenicus @o_guest @BodenLab They don\u2019t gave a single image and ask \u201Cgay or straight?\u201D but gave one each and asked \u201Cwhich is which?\u201D",
  "id" : 906280744733073409,
  "in_reply_to_status_id" : 906276672730791936,
  "created_at" : "2017-09-08 22:19:02 +0000",
  "in_reply_to_screen_name" : "sir_deenicus",
  "in_reply_to_user_id_str" : "61322055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Ian Ramjohn",
      "screen_name" : "iramjohn",
      "indices" : [ 9, 18 ],
      "id_str" : "14580192",
      "id" : 14580192
    }, {
      "name" : "Calling Bullshit",
      "screen_name" : "callin_bull",
      "indices" : [ 19, 31 ],
      "id_str" : "763156668699975680",
      "id" : 763156668699975680
    }, {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 32, 41 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906273102010703872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47730960145246, -1.902560926868328 ]
  },
  "id_str" : "906274981692276736",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @iramjohn @callin_bull @BodenLab \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 here! \uD83D\uDC96",
  "id" : 906274981692276736,
  "in_reply_to_status_id" : 906273102010703872,
  "created_at" : "2017-09-08 21:56:08 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Exocortical",
      "screen_name" : "sir_deenicus",
      "indices" : [ 9, 22 ],
      "id_str" : "61322055",
      "id" : 61322055
    }, {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 23, 32 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906270701413392386",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47729513131296, -1.902529277685852 ]
  },
  "id_str" : "906274900163391491",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @sir_deenicus @BodenLab And then made to decide which of two pictures was which, right? So even easier in a way?",
  "id" : 906274900163391491,
  "in_reply_to_status_id" : 906270701413392386,
  "created_at" : "2017-09-08 21:55:48 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Ian Ramjohn",
      "screen_name" : "iramjohn",
      "indices" : [ 9, 18 ],
      "id_str" : "14580192",
      "id" : 14580192
    }, {
      "name" : "Calling Bullshit",
      "screen_name" : "callin_bull",
      "indices" : [ 19, 31 ],
      "id_str" : "763156668699975680",
      "id" : 763156668699975680
    }, {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 32, 41 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906272499708637185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47730724756794, -1.902577805217737 ]
  },
  "id_str" : "906272631502057472",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @iramjohn @callin_bull @BodenLab Are we doing a \uD83C\uDF08 headcount now? \uD83D\uDE09",
  "id" : 906272631502057472,
  "in_reply_to_status_id" : 906272499708637185,
  "created_at" : "2017-09-08 21:46:47 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madhusudan Katti \uD83E\uDD89",
      "screen_name" : "leafwarbler",
      "indices" : [ 0, 12 ],
      "id_str" : "14145626",
      "id" : 14145626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906269589536993280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47730267820626, -1.902533591743774 ]
  },
  "id_str" : "906270082636107776",
  "in_reply_to_user_id" : 14145626,
  "text" : "@leafwarbler Yes",
  "id" : 906270082636107776,
  "in_reply_to_status_id" : 906269589536993280,
  "created_at" : "2017-09-08 21:36:40 +0000",
  "in_reply_to_screen_name" : "leafwarbler",
  "in_reply_to_user_id_str" : "14145626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906266457029435392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47735196662894, -1.902565206522336 ]
  },
  "id_str" : "906268574213439489",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I\u2019ve seen weirder things, so might be some board that exempted it. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 906268574213439489,
  "in_reply_to_status_id" : 906266457029435392,
  "created_at" : "2017-09-08 21:30:40 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906263876551012355",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47690507031511, -1.901581215759891 ]
  },
  "id_str" : "906264148853624832",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye They don\u2019t even say it was Stanford. So who knows who approved this.",
  "id" : 906264148853624832,
  "in_reply_to_status_id" : 906263876551012355,
  "created_at" : "2017-09-08 21:13:05 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906262397316468737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47690268680283, -1.901631447151573 ]
  },
  "id_str" : "906263410849062913",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye So there\u2019s someone who\u2019s at least by name responsible and you know whom to turn to.",
  "id" : 906263410849062913,
  "in_reply_to_status_id" : 906262397316468737,
  "created_at" : "2017-09-08 21:10:09 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Q5LVb8VkLp",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906262397316468737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47692958266344, -1.901492689965223 ]
  },
  "id_str" : "906263314887528451",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye Usually you have to give which review board approved or exempt your study. C.f. https:\/\/t.co\/Q5LVb8VkLp",
  "id" : 906263314887528451,
  "in_reply_to_status_id" : 906262397316468737,
  "created_at" : "2017-09-08 21:09:46 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906259189672103937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47694032237172, -1.901448865764005 ]
  },
  "id_str" : "906260630390398983",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye \u201CYes it was\u201D also strikes me as a kind of insufficient documentation of the approval\u2026",
  "id" : 906260630390398983,
  "in_reply_to_status_id" : 906259189672103937,
  "created_at" : "2017-09-08 20:59:06 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres",
      "screen_name" : "Daedalus6",
      "indices" : [ 0, 10 ],
      "id_str" : "25987903",
      "id" : 25987903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/89oQ221v5l",
      "expanded_url" : "https:\/\/twitter.com\/fre8de8rike\/status\/906245591881146370",
      "display_url" : "twitter.com\/fre8de8rike\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906234369525899266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47693246277006, -1.901503841480234 ]
  },
  "id_str" : "906254876862283776",
  "in_reply_to_user_id" : 25987903,
  "text" : "@Daedalus6 Because of this https:\/\/t.co\/89oQ221v5l",
  "id" : 906254876862283776,
  "in_reply_to_status_id" : 906234369525899266,
  "created_at" : "2017-09-08 20:36:14 +0000",
  "in_reply_to_screen_name" : "Daedalus6",
  "in_reply_to_user_id_str" : "25987903",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906252642954948609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47691393989502, -1.901606329735638 ]
  },
  "id_str" : "906254755546193920",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye Their paper didn\u2019t mention it with a single word if I didn\u2019t totally fail searching for it.",
  "id" : 906254755546193920,
  "in_reply_to_status_id" : 906252642954948609,
  "created_at" : "2017-09-08 20:35:45 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 104, 120 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ABujDjZa3h",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2017\/09\/08\/craig-venter-uses-millions-of-genomes-to-predict-sunrise\/",
      "display_url" : "thescienceweb.wordpress.com\/2017\/09\/08\/cra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906230333246509056",
  "text" : "RT @TheScienceWeb: Craig Venter uses millions of genomes to predict sunrise https:\/\/t.co\/ABujDjZa3h via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 85, 101 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ABujDjZa3h",
        "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2017\/09\/08\/craig-venter-uses-millions-of-genomes-to-predict-sunrise\/",
        "display_url" : "thescienceweb.wordpress.com\/2017\/09\/08\/cra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "906225223497867264",
    "text" : "Craig Venter uses millions of genomes to predict sunrise https:\/\/t.co\/ABujDjZa3h via @wordpressdotcom",
    "id" : 906225223497867264,
    "created_at" : "2017-09-08 18:38:24 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 906230333246509056,
  "created_at" : "2017-09-08 18:58:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/Ht1S7yY829",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYynfWQls6Z\/",
      "display_url" : "instagram.com\/p\/BYynfWQls6Z\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.4798, -1.9085 ]
  },
  "id_str" : "906230162118901760",
  "text" : "Not exactly quatrefoils @ Library of Birmingham https:\/\/t.co\/Ht1S7yY829",
  "id" : 906230162118901760,
  "created_at" : "2017-09-08 18:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 0, 6 ],
      "id_str" : "15276911",
      "id" : 15276911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906140724420366336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47693303662817, -1.901517470023015 ]
  },
  "id_str" : "906222127791173632",
  "in_reply_to_user_id" : 15276911,
  "text" : "@iddux They just all wait to be linked into one big genome-to-face-to-sexual-preference-to-marmite-preference cluster fuck.",
  "id" : 906222127791173632,
  "in_reply_to_status_id" : 906140724420366336,
  "created_at" : "2017-09-08 18:26:06 +0000",
  "in_reply_to_screen_name" : "iddux",
  "in_reply_to_user_id_str" : "15276911",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906218878082179073",
  "text" : "RT @gedankenstuecke: Predicting sexuality with face recognition. No ethical approval, no consent of the users whose faces were used? https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/R8wZFwf5to",
        "expanded_url" : "https:\/\/osf.io\/zn79k\/",
        "display_url" : "osf.io\/zn79k\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.54277370341971, -0.06904431294628117 ]
    },
    "id_str" : "906056044228616192",
    "text" : "Predicting sexuality with face recognition. No ethical approval, no consent of the users whose faces were used? https:\/\/t.co\/R8wZFwf5to",
    "id" : 906056044228616192,
    "created_at" : "2017-09-08 07:26:09 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 906218878082179073,
  "created_at" : "2017-09-08 18:13:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/57zcm92fzP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYycli-FBf9\/",
      "display_url" : "instagram.com\/p\/BYycli-FBf9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.478770638002, -1.9105792169842 ]
  },
  "id_str" : "906206129180614657",
  "text" : "Space age-y @ The ICC https:\/\/t.co\/57zcm92fzP",
  "id" : 906206129180614657,
  "created_at" : "2017-09-08 17:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906205476945321986",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47693650787654, -1.901502481283636 ]
  },
  "id_str" : "906206093659049984",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Ha, passed you on the train from London today! Here for a wedding. What brings you to Coventry?",
  "id" : 906206093659049984,
  "in_reply_to_status_id" : 906205476945321986,
  "created_at" : "2017-09-08 17:22:23 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906205031149469697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47693962294954, -1.901473966849456 ]
  },
  "id_str" : "906205998737739777",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski Yep, but that fits the Vulcan image, doesn\u2019t it?",
  "id" : 906205998737739777,
  "in_reply_to_status_id" : 906205031149469697,
  "created_at" : "2017-09-08 17:22:01 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 0, 13 ],
      "id_str" : "252204344",
      "id" : 252204344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905849776314478593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47690831706784, -1.901555434281868 ]
  },
  "id_str" : "906204455531667456",
  "in_reply_to_user_id" : 252204344,
  "text" : "@jessicapolka Uh, I need those new ones \uD83D\uDE0D",
  "id" : 906204455531667456,
  "in_reply_to_status_id" : 905849776314478593,
  "created_at" : "2017-09-08 17:15:53 +0000",
  "in_reply_to_screen_name" : "jessicapolka",
  "in_reply_to_user_id_str" : "252204344",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/906204212396253184\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/MBwz3qE0o9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DJN76olXcAAN9Nj.jpg",
      "id_str" : "906204197288374272",
      "id" : 906204197288374272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJN76olXcAAN9Nj.jpg",
      "sizes" : [ {
        "h" : 891,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/MBwz3qE0o9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47690450893582, -1.901595324057977 ]
  },
  "id_str" : "906204212396253184",
  "text" : "I have no idea why these Vulcan-\uD83D\uDC3B hybrids are around in Birmingham, but I like them. \uD83D\uDD96 https:\/\/t.co\/MBwz3qE0o9",
  "id" : 906204212396253184,
  "created_at" : "2017-09-08 17:14:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/aSyi7s6sPp",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYyULTSlANj\/",
      "display_url" : "instagram.com\/p\/BYyULTSlANj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.477388, -1.9082519 ]
  },
  "id_str" : "906187415035011072",
  "text" : "\uD83D\uDEE5 @ The Canal House https:\/\/t.co\/aSyi7s6sPp",
  "id" : 906187415035011072,
  "created_at" : "2017-09-08 16:08:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906170232540205057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47838681600821, -1.911667027106694 ]
  },
  "id_str" : "906172727085629440",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist Sure, but that\u2019s not what they try to sell. \uD83D\uDE09",
  "id" : 906172727085629440,
  "in_reply_to_status_id" : 906170232540205057,
  "created_at" : "2017-09-08 15:09:48 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906165797718040577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47839214296441, -1.911777807363361 ]
  },
  "id_str" : "906167753039634435",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist I disagree. As long as it\u2019s at this state they haven\u2019t shown anything of use.",
  "id" : 906167753039634435,
  "in_reply_to_status_id" : 906165797718040577,
  "created_at" : "2017-09-08 14:50:02 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/e28tRKIWIw",
      "expanded_url" : "https:\/\/twitter.com\/piper_jason\/status\/905843890627936257",
      "display_url" : "twitter.com\/piper_jason\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906158177150013440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47753328764502, -1.910208998357769 ]
  },
  "id_str" : "906160791770079233",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist Look at https:\/\/t.co\/e28tRKIWIw the facial reconstruction is dubious at best.",
  "id" : 906160791770079233,
  "in_reply_to_status_id" : 906158177150013440,
  "created_at" : "2017-09-08 14:22:23 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.4769926537317, -1.901473794134242 ]
  },
  "id_str" : "906152403040337920",
  "text" : "Hello Birmingham! \uD83D\uDC4B",
  "id" : 906152403040337920,
  "created_at" : "2017-09-08 13:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906145226842136581",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47662609928109, -1.901030084951178 ]
  },
  "id_str" : "906149203616915456",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist And the database fallacy is the biggest issue as it\u2019s untrue ground conditions. Totally overblown claims.",
  "id" : 906149203616915456,
  "in_reply_to_status_id" : 906145226842136581,
  "created_at" : "2017-09-08 13:36:20 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906145226842136581",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.47731543413788, -1.904342966810869 ]
  },
  "id_str" : "906149075153772544",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist Pretty much so. They can\u2019t actually use the whole genome data effectively but rather ancestry plus biological sex.",
  "id" : 906149075153772544,
  "in_reply_to_status_id" : 906145226842136581,
  "created_at" : "2017-09-08 13:35:49 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 17, 25 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 26, 36 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906116592911749120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.91728176652539, -0.6752503546741592 ]
  },
  "id_str" : "906121713380978688",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @o_guest @AidanBudd Thanks!",
  "id" : 906121713380978688,
  "in_reply_to_status_id" : 906116592911749120,
  "created_at" : "2017-09-08 11:47:06 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 10, 18 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Joshua Skewes",
      "screen_name" : "JCSkewesDK",
      "indices" : [ 19, 30 ],
      "id_str" : "2437947289",
      "id" : 2437947289
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 31, 46 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 47, 53 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 54, 64 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.56586638920011, -0.3060209533573736 ]
  },
  "id_str" : "906115789819916288",
  "text" : "@kopshtik @o_guest @JCSkewesDK @EmilyGorcenski @mcknw @Hao_and_Y You got mine! :)",
  "id" : 906115789819916288,
  "created_at" : "2017-09-08 11:23:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 9, 19 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 46, 62 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906114847925993472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.56586638920011, -0.3060209533573736 ]
  },
  "id_str" : "906115768269639680",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @AidanBudd Thanks! Let\u2019s see whether @pathogenomenick has some\nDinner recommendations for Birmingham \uD83D\uDE02",
  "id" : 906115768269639680,
  "in_reply_to_status_id" : 906114847925993472,
  "created_at" : "2017-09-08 11:23:28 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael J. Kane",
      "screen_name" : "Kane_WMC_Lab",
      "indices" : [ 0, 13 ],
      "id_str" : "357674307",
      "id" : 357674307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906113503504818176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54310826645904, -0.2808110849521591 ]
  },
  "id_str" : "906115559246495744",
  "in_reply_to_user_id" : 357674307,
  "text" : "@Kane_WMC_Lab Even if that is true, these people do not consent for the re-use of the data for research purposes.",
  "id" : 906115559246495744,
  "in_reply_to_status_id" : 906113503504818176,
  "created_at" : "2017-09-08 11:22:38 +0000",
  "in_reply_to_screen_name" : "Kane_WMC_Lab",
  "in_reply_to_user_id_str" : "357674307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Joshua Skewes",
      "screen_name" : "JCSkewesDK",
      "indices" : [ 9, 20 ],
      "id_str" : "2437947289",
      "id" : 2437947289
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 21, 36 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 47, 53 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 54, 64 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906107225281880065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52768169022956, -0.1330527228259419 ]
  },
  "id_str" : "906108377499041793",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @JCSkewesDK @EmilyGorcenski @kopshtik @mcknw @Hao_and_Y Someone should do the lead and write stuff up. But I\u2019m about to leave London to travel to Birmingham.",
  "id" : 906108377499041793,
  "in_reply_to_status_id" : 906107225281880065,
  "created_at" : "2017-09-08 10:54:06 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai",
      "screen_name" : "kai_wanders",
      "indices" : [ 0, 12 ],
      "id_str" : "773167879",
      "id" : 773167879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906105370199945216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52765396932877, -0.1329734946208509 ]
  },
  "id_str" : "906106589945491456",
  "in_reply_to_user_id" : 773167879,
  "text" : "@kai_wanders Even if their science was good that issue would remain.",
  "id" : 906106589945491456,
  "in_reply_to_status_id" : 906105370199945216,
  "created_at" : "2017-09-08 10:47:00 +0000",
  "in_reply_to_screen_name" : "kai_wanders",
  "in_reply_to_user_id_str" : "773167879",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai",
      "screen_name" : "kai_wanders",
      "indices" : [ 0, 12 ],
      "id_str" : "773167879",
      "id" : 773167879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906105370199945216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52762358072093, -0.1330932972655712 ]
  },
  "id_str" : "906106511109345280",
  "in_reply_to_user_id" : 773167879,
  "text" : "@kai_wanders Of course that\u2019s all BS as well. But I don\u2019t even care so much about that part as opposed to the unethical practice shown here.",
  "id" : 906106511109345280,
  "in_reply_to_status_id" : 906105370199945216,
  "created_at" : "2017-09-08 10:46:41 +0000",
  "in_reply_to_screen_name" : "kai_wanders",
  "in_reply_to_user_id_str" : "773167879",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906089079581925376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5408929460546, -0.0714899708024064 ]
  },
  "id_str" : "906094777866878979",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Nevermind, the heading of the preprint says it\u2019s reviewed and will appear in some journal.",
  "id" : 906094777866878979,
  "in_reply_to_status_id" : 906089079581925376,
  "created_at" : "2017-09-08 10:00:04 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906089079581925376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54082682760775, -0.07145577752289796 ]
  },
  "id_str" : "906093724782010369",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Was there any? I\u2019ve only found the pre-print on OSF.",
  "id" : 906093724782010369,
  "in_reply_to_status_id" : 906089079581925376,
  "created_at" : "2017-09-08 09:55:53 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Skewes",
      "screen_name" : "JCSkewesDK",
      "indices" : [ 0, 11 ],
      "id_str" : "2437947289",
      "id" : 2437947289
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 12, 20 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 21, 36 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 47, 53 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 54, 64 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906091646944776192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54084929972041, -0.07137176441884992 ]
  },
  "id_str" : "906092024046157825",
  "in_reply_to_user_id" : 2437947289,
  "text" : "@JCSkewesDK @o_guest @EmilyGorcenski @kopshtik @mcknw @Hao_and_Y There\u2019s probably a reason why the paper doesn\u2019t say anything about IRB approval. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 906092024046157825,
  "in_reply_to_status_id" : 906091646944776192,
  "created_at" : "2017-09-08 09:49:07 +0000",
  "in_reply_to_screen_name" : "JCSkewesDK",
  "in_reply_to_user_id_str" : "2437947289",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James O'Malley",
      "screen_name" : "Psythor",
      "indices" : [ 3, 11 ],
      "id_str" : "629133",
      "id" : 629133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VdBlgAmDxp",
      "expanded_url" : "http:\/\/www.gizmodo.co.uk\/2017\/09\/london-underground-wifi-tracking-heres-everything-we-learned-from-tfls-official-report\/",
      "display_url" : "gizmodo.co.uk\/2017\/09\/london\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "906087543661355009",
  "text" : "RT @Psythor: NEW FROM ME: London Underground Wifi Tracking: Here\u2019s Everything We Learned From TfL\u2019s Official Report https:\/\/t.co\/VdBlgAmDxp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Psythor\/status\/906028245560172546\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/Tx1YWw1kpB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJLb4IjVoAE3IEa.jpg",
        "id_str" : "906028232469749761",
        "id" : 906028232469749761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJLb4IjVoAE3IEa.jpg",
        "sizes" : [ {
          "h" : 197,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/Tx1YWw1kpB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/VdBlgAmDxp",
        "expanded_url" : "http:\/\/www.gizmodo.co.uk\/2017\/09\/london-underground-wifi-tracking-heres-everything-we-learned-from-tfls-official-report\/",
        "display_url" : "gizmodo.co.uk\/2017\/09\/london\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "906028245560172546",
    "text" : "NEW FROM ME: London Underground Wifi Tracking: Here\u2019s Everything We Learned From TfL\u2019s Official Report https:\/\/t.co\/VdBlgAmDxp https:\/\/t.co\/Tx1YWw1kpB",
    "id" : 906028245560172546,
    "created_at" : "2017-09-08 05:35:41 +0000",
    "user" : {
      "name" : "James O'Malley",
      "screen_name" : "Psythor",
      "protected" : false,
      "id_str" : "629133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568745955562778624\/xawiEt8-_normal.jpeg",
      "id" : 629133,
      "verified" : true
    }
  },
  "id" : 906087543661355009,
  "created_at" : "2017-09-08 09:31:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandro Blasimme",
      "screen_name" : "a_blasimme",
      "indices" : [ 0, 11 ],
      "id_str" : "51029208",
      "id" : 51029208
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 12, 25 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/tLohHUu1uC",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2017\/09\/06\/185330",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906074869267345409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54080833301566, -0.0715251502387869 ]
  },
  "id_str" : "906080863665913856",
  "in_reply_to_user_id" : 51029208,
  "text" : "@a_blasimme @TheEconomist Alas, they don\u2019t do that at all. See https:\/\/t.co\/tLohHUu1uC",
  "id" : 906080863665913856,
  "in_reply_to_status_id" : 906074869267345409,
  "created_at" : "2017-09-08 09:04:46 +0000",
  "in_reply_to_screen_name" : "a_blasimme",
  "in_reply_to_user_id_str" : "51029208",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 3, 13 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "906071681768312832",
  "text" : "RT @SCEdmunds: Make a career selling proprietary genomics data, engineer flawed study to undermine data sharing, exploit PNAS flawed review\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/muFFRz304T",
        "expanded_url" : "https:\/\/twitter.com\/piper_jason\/status\/905138459249000448",
        "display_url" : "twitter.com\/piper_jason\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "905741121359192064",
    "text" : "Make a career selling proprietary genomics data, engineer flawed study to undermine data sharing, exploit PNAS flawed review to publish. \uD83D\uDE21 https:\/\/t.co\/muFFRz304T",
    "id" : 905741121359192064,
    "created_at" : "2017-09-07 10:34:45 +0000",
    "user" : {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "protected" : false,
      "id_str" : "176024190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1098248807\/chess_normal.JPG",
      "id" : 176024190,
      "verified" : false
    }
  },
  "id" : 906071681768312832,
  "created_at" : "2017-09-08 08:28:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 10, 18 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 19, 30 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 31, 37 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 38, 48 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 49, 64 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54052959294201, -0.07151431404060825 ]
  },
  "id_str" : "906071611136233472",
  "text" : "@kopshtik @o_guest @RaeKnowler @mcknw @Hao_and_Y @EmilyGorcenski Absolutely! \uD83D\uDC96",
  "id" : 906071611136233472,
  "created_at" : "2017-09-08 08:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 10, 21 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 22, 30 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 31, 37 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 38, 48 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 49, 64 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54068411332698, -0.0711450912059016 ]
  },
  "id_str" : "906070454049308672",
  "text" : "@kopshtik @RaeKnowler @o_guest @mcknw @Hao_and_Y @EmilyGorcenski Aye, I actually kind of expected the data to come from the illegal OkCupid scraping.",
  "id" : 906070454049308672,
  "created_at" : "2017-09-08 08:23:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 19, 25 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 26, 36 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906068148356567040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.540840100545, -0.07136436179286927 ]
  },
  "id_str" : "906068456449220608",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @kopshtik @mcknw @Hao_and_Y \uD83D\uDC4D",
  "id" : 906068456449220608,
  "in_reply_to_status_id" : 906068148356567040,
  "created_at" : "2017-09-08 08:15:28 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TM",
      "screen_name" : "mcknw",
      "indices" : [ 0, 6 ],
      "id_str" : "14137635",
      "id" : 14137635
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 7, 17 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906063160783679488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.540840100545, -0.07136436179286927 ]
  },
  "id_str" : "906068035148140544",
  "in_reply_to_user_id" : 14137635,
  "text" : "@mcknw @Hao_and_Y @kopshtik Volunteer, i.e. Use Facebook without knowingly signing up for some 3rd Reich style experiments",
  "id" : 906068035148140544,
  "in_reply_to_status_id" : 906063160783679488,
  "created_at" : "2017-09-08 08:13:48 +0000",
  "in_reply_to_screen_name" : "mcknw",
  "in_reply_to_user_id_str" : "14137635",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906062772156452864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.540840100545, -0.07136436179286927 ]
  },
  "id_str" : "906067728729088000",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Do you know any org that was contacted?",
  "id" : 906067728729088000,
  "in_reply_to_status_id" : 906062772156452864,
  "created_at" : "2017-09-08 08:12:35 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maciej Kosi\u0142o \u2615\uD83C\uDFC4",
      "screen_name" : "M_Kosilo",
      "indices" : [ 0, 9 ],
      "id_str" : "589032635",
      "id" : 589032635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906062527439798272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54095510025652, -0.07126780226833306 ]
  },
  "id_str" : "906067588245057536",
  "in_reply_to_user_id" : 589032635,
  "text" : "@M_Kosilo Because many data sciency people don\u2019t care much about the ethics of science :\/",
  "id" : 906067588245057536,
  "in_reply_to_status_id" : 906062527439798272,
  "created_at" : "2017-09-08 08:12:01 +0000",
  "in_reply_to_screen_name" : "M_Kosilo",
  "in_reply_to_user_id_str" : "589032635",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maciej Kosi\u0142o \u2615\uD83C\uDFC4",
      "screen_name" : "M_Kosilo",
      "indices" : [ 0, 9 ],
      "id_str" : "589032635",
      "id" : 589032635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906060531576041472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54276994258872, -0.06904965822230494 ]
  },
  "id_str" : "906061041301368832",
  "in_reply_to_user_id" : 589032635,
  "text" : "@M_Kosilo Nope, the paper mentions consent twice. To basically say how their method can be used without people\u2019s consent. The irony.",
  "id" : 906061041301368832,
  "in_reply_to_status_id" : 906060531576041472,
  "created_at" : "2017-09-08 07:46:00 +0000",
  "in_reply_to_screen_name" : "M_Kosilo",
  "in_reply_to_user_id_str" : "589032635",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906059852937666561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54136448158243, -0.07047207853966128 ]
  },
  "id_str" : "906060570918621184",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Yeah, but they claim 90-ish if they have multiple pictures",
  "id" : 906060570918621184,
  "in_reply_to_status_id" : 906059852937666561,
  "created_at" : "2017-09-08 07:44:08 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/KCodFoZcCQ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/906056044228616192",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906056044228616192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5402901219684, -0.07143351249403454 ]
  },
  "id_str" : "906059167806476288",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThe results reported in this paper were shared, in advance, with several leading international LGBTQ organizations\u00BB That told you to stop? https:\/\/t.co\/KCodFoZcCQ",
  "id" : 906059167806476288,
  "in_reply_to_status_id" : 906056044228616192,
  "created_at" : "2017-09-08 07:38:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906056922511679488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54079341334434, -0.07131851278252091 ]
  },
  "id_str" : "906057655780868096",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @kopshtik I heard 3D printed pink triangles might be *the* upcoming fad\u2026",
  "id" : 906057655780868096,
  "in_reply_to_status_id" : 906056922511679488,
  "created_at" : "2017-09-08 07:32:33 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53778120880158, -0.07060286588973422 ]
  },
  "id_str" : "906056841771315202",
  "text" : "@kopshtik To me this explains that the authors are fuckin immoral and dangerous assholes.",
  "id" : 906056841771315202,
  "created_at" : "2017-09-08 07:29:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/KCodFoZcCQ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/906056044228616192",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "906056044228616192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53778120880158, -0.07060286588973422 ]
  },
  "id_str" : "906056198495010817",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also, this is totally not like the Nazi skeleton studies to figure out facial features of Jewish people\u2026 https:\/\/t.co\/KCodFoZcCQ",
  "id" : 906056198495010817,
  "in_reply_to_status_id" : 906056044228616192,
  "created_at" : "2017-09-08 07:26:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/R8wZFwf5to",
      "expanded_url" : "https:\/\/osf.io\/zn79k\/",
      "display_url" : "osf.io\/zn79k\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54277370341971, -0.06904431294628117 ]
  },
  "id_str" : "906056044228616192",
  "text" : "Predicting sexuality with face recognition. No ethical approval, no consent of the users whose faces were used? https:\/\/t.co\/R8wZFwf5to",
  "id" : 906056044228616192,
  "created_at" : "2017-09-08 07:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. J. Craig Venter",
      "screen_name" : "JCVenter",
      "indices" : [ 4, 13 ],
      "id_str" : "56564230",
      "id" : 56564230
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 73, 82 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/9FABujVyKQ",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2017\/09\/07\/185330",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54071154786754, -0.07143496998132104 ]
  },
  "id_str" : "905837550375403520",
  "text" : "Can @JCVenter predict your face &amp; height from your genome? Nope. And @erlichya tells you why. https:\/\/t.co\/9FABujVyKQ",
  "id" : 905837550375403520,
  "created_at" : "2017-09-07 16:57:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/rpEzZyINtC",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYvhpWuFBBx\/",
      "display_url" : "instagram.com\/p\/BYvhpWuFBBx\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5406165, -0.0763249 ]
  },
  "id_str" : "905794812607123457",
  "text" : "\uD83C\uDF44 @ The Fox https:\/\/t.co\/rpEzZyINtC",
  "id" : 905794812607123457,
  "created_at" : "2017-09-07 14:08:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905787182081753088",
  "text" : "RT @Senficon: Planned extra copyright for news sites \u201Cposes a threat to an informed society\u201D, warns broad pro-science coalition: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/905782732218916864\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/rpXbEMgBXB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJH7Q3oXYAAxM7T.jpg",
        "id_str" : "905781267307913216",
        "id" : 905781267307913216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJH7Q3oXYAAxM7T.jpg",
        "sizes" : [ {
          "h" : 348,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 1580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 1580
        } ],
        "display_url" : "pic.twitter.com\/rpXbEMgBXB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/18wcgwnQol",
        "expanded_url" : "http:\/\/www.scienceeurope.org\/wp-content\/uploads\/2017\/09\/Joint-Open-Letter-Copyright-Reform-Sep-2017.pdf",
        "display_url" : "scienceeurope.org\/wp-content\/upl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "905782732218916864",
    "text" : "Planned extra copyright for news sites \u201Cposes a threat to an informed society\u201D, warns broad pro-science coalition: https:\/\/t.co\/18wcgwnQol https:\/\/t.co\/rpXbEMgBXB",
    "id" : 905782732218916864,
    "created_at" : "2017-09-07 13:20:06 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 905787182081753088,
  "created_at" : "2017-09-07 13:37:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ZBWBV4AKhD",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/905385137302536193",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54347163385687, -0.07220787620524027 ]
  },
  "id_str" : "905575429305761793",
  "text" : "Published without even naming the author(s)\u2026 If only there were people studying history and social science\u2026 \uD83D\uDDDE\uD83D\uDDD1 https:\/\/t.co\/ZBWBV4AKhD",
  "id" : 905575429305761793,
  "created_at" : "2017-09-06 23:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54161605523111, -0.07169561460620881 ]
  },
  "id_str" : "905496410291830785",
  "text" : "The physical proximity of Gay\u2019s the Word and Judd Books doesn\u2019t help. *schlepping home 6 more books to read*",
  "id" : 905496410291830785,
  "created_at" : "2017-09-06 18:22:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52400467848735, -0.1331206460534452 ]
  },
  "id_str" : "905394010151378944",
  "text" : "Visiting the auto icon of Jeremy Bentham \u2714\uFE0F",
  "id" : 905394010151378944,
  "created_at" : "2017-09-06 11:35:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "905345567135432705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5407934778243, -0.0714789388620904 ]
  },
  "id_str" : "905358604844269568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer uh, thanks!",
  "id" : 905358604844269568,
  "in_reply_to_status_id" : 905345567135432705,
  "created_at" : "2017-09-06 09:14:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "7841792",
      "id" : 7841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "905179242341834753",
  "text" : "RT @SteveMcLaugh: Alexandra Elbakyan just blocked all of Russia from accessing Sci-Hub. Here's the message that pops up: original &amp; transla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SteveMcLaugh\/status\/905081868478971908\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MbeUjjCY8Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DI9-4bKVAAEiF7n.jpg",
        "id_str" : "905081557953609729",
        "id" : 905081557953609729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI9-4bKVAAEiF7n.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 578
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 578
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 578
        } ],
        "display_url" : "pic.twitter.com\/MbeUjjCY8Q"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SteveMcLaugh\/status\/905081868478971908\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MbeUjjCY8Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DI9-5lRV4AAfu3N.jpg",
        "id_str" : "905081577847250944",
        "id" : 905081577847250944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI9-5lRV4AAfu3N.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 572
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 572
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 572
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 572
        } ],
        "display_url" : "pic.twitter.com\/MbeUjjCY8Q"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SteveMcLaugh\/status\/905081868478971908\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MbeUjjCY8Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DI9-6hpV4AAr8S7.jpg",
        "id_str" : "905081594054041600",
        "id" : 905081594054041600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI9-6hpV4AAr8S7.jpg",
        "sizes" : [ {
          "h" : 753,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 523
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/MbeUjjCY8Q"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SteveMcLaugh\/status\/905081868478971908\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/MbeUjjCY8Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DI9-7SHVwAAuaHU.jpg",
        "id_str" : "905081607064764416",
        "id" : 905081607064764416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DI9-7SHVwAAuaHU.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 571
        } ],
        "display_url" : "pic.twitter.com\/MbeUjjCY8Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "905081868478971908",
    "text" : "Alexandra Elbakyan just blocked all of Russia from accessing Sci-Hub. Here's the message that pops up: original &amp; translated by Google. https:\/\/t.co\/MbeUjjCY8Q",
    "id" : 905081868478971908,
    "created_at" : "2017-09-05 14:55:07 +0000",
    "user" : {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "protected" : false,
      "id_str" : "7841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776533899555909633\/MvNi9Ve5_normal.jpg",
      "id" : 7841792,
      "verified" : false
    }
  },
  "id" : 905179242341834753,
  "created_at" : "2017-09-05 21:22:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/lRhHw1jH21",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYrEoCYFh-9\/",
      "display_url" : "instagram.com\/p\/BYrEoCYFh-9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "905168043470446593",
  "text" : "A doomed gallery with a touch of class? Count me in! https:\/\/t.co\/lRhHw1jH21",
  "id" : 905168043470446593,
  "created_at" : "2017-09-05 20:37:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 9, 19 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 20, 33 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Paolo Manghi",
      "screen_name" : "paolomanghi",
      "indices" : [ 34, 46 ],
      "id_str" : "25665283",
      "id" : 25665283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904808205074747392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54084965660184, -0.07149667659213037 ]
  },
  "id_str" : "904810573539545088",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @oaDOI_org @Mcarthur_Joe @paolomanghi Awesome, thanks!",
  "id" : 904810573539545088,
  "in_reply_to_status_id" : 904808205074747392,
  "created_at" : "2017-09-04 20:57:05 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 9, 19 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 20, 33 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/On09Ng8Okh",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/904733848063406080",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "904806486525792257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53730503297283, -0.07589838335115906 ]
  },
  "id_str" : "904806822401511429",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @oaDOI_org @Mcarthur_Joe Thanks! I\u2019m largely interested in doi\/pmid, related to https:\/\/t.co\/On09Ng8Okh",
  "id" : 904806822401511429,
  "in_reply_to_status_id" : 904806486525792257,
  "created_at" : "2017-09-04 20:42:11 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 9, 19 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 20, 33 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904799010401210372",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53731646240148, -0.07591968497653986 ]
  },
  "id_str" : "904803980559122435",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @oaDOI_org @Mcarthur_Joe Cool, thanks! Put in paper DOI, get linked data back?",
  "id" : 904803980559122435,
  "in_reply_to_status_id" : 904799010401210372,
  "created_at" : "2017-09-04 20:30:54 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 20, 30 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 123, 136 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53731517423976, -0.0759345646545251 ]
  },
  "id_str" : "904798626437881857",
  "text" : "Does anyone know an @oaDOI_org equivalent to check for whether the data associated with a paper is publicly available? \/cc @Mcarthur_Joe",
  "id" : 904798626437881857,
  "created_at" : "2017-09-04 20:09:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904744661507608577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54749554121079, -0.09753878228375458 ]
  },
  "id_str" : "904744842823131137",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 Access to what exactly?",
  "id" : 904744842823131137,
  "in_reply_to_status_id" : 904744661507608577,
  "created_at" : "2017-09-04 16:35:54 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 124, 134 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52006508286263, -0.1339443216284036 ]
  },
  "id_str" : "904733848063406080",
  "text" : "As the Telegram bot isn\u2019t working: Say I have ~500 PMIDs I want to get from Sci-Hub, what\u2019s the best way to fetch them? \/cc @blahah404",
  "id" : 904733848063406080,
  "created_at" : "2017-09-04 15:52:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54067364420855, -0.07145498900166421 ]
  },
  "id_str" : "904484053948264448",
  "text" : "\u00ABThis day shall forever be remembered as \u2018the day that French cuisine made me eat a whole cauliflower\u2019.\u00BB",
  "id" : 904484053948264448,
  "created_at" : "2017-09-03 23:19:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/PGgxZtLFuh",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/904366870437953536",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "904366870437953536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54085412495532, -0.07142185679416184 ]
  },
  "id_str" : "904483752214192128",
  "in_reply_to_user_id" : 14286491,
  "text" : "So far you\u2019re not helping Internet. This poll needs some more votes to settle the matter. https:\/\/t.co\/PGgxZtLFuh",
  "id" : 904483752214192128,
  "in_reply_to_status_id" : 904366870437953536,
  "created_at" : "2017-09-03 23:18:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/p6bWopmudL",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BYllQA5lo00\/",
      "display_url" : "instagram.com\/p\/BYllQA5lo00\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.534050529069, -0.056169559428894 ]
  },
  "id_str" : "904395374281895936",
  "text" : "The big fat \uD83C\uDDEC\uD83C\uDDF7\/\uD83C\uDDE8\uD83C\uDDF3 wedding! \uD83C\uDF89 \u2705 @ Bistrotheque https:\/\/t.co\/p6bWopmudL",
  "id" : 904395374281895936,
  "created_at" : "2017-09-03 17:27:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904367903847309312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53409082447321, -0.0563578214496899 ]
  },
  "id_str" : "904369808636043264",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate Wait for the paper that has \u201COrder of authorship was determined by a twitter poll\u201D in it. \uD83D\uDE09",
  "id" : 904369808636043264,
  "in_reply_to_status_id" : 904367903847309312,
  "created_at" : "2017-09-03 15:45:39 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904367722116603905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53411047726705, -0.05610622795954817 ]
  },
  "id_str" : "904368008851841025",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 \uD83D\uDC96",
  "id" : 904368008851841025,
  "in_reply_to_status_id" : 904367722116603905,
  "created_at" : "2017-09-03 15:38:30 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "904366870437953536",
  "text" : "Place card-inspired question: Which paper would you cite more \nA) Greshake Tzovaras, Tzovara Greshake\nB) Tzovara Greshake, Greshake Tzovaras",
  "id" : 904366870437953536,
  "created_at" : "2017-09-03 15:33:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Odell",
      "screen_name" : "the_jennitaur",
      "indices" : [ 3, 17 ],
      "id_str" : "145749531",
      "id" : 145749531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "904251819530092544",
  "text" : "RT @the_jennitaur: in case you like rabbit holes, here's my report on the notorious \"free watch,\" produced for the museum of capitalism htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/the_jennitaur\/status\/903707076089700352\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/QgPLc8HGeT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DIqcug7UEAAzewl.jpg",
        "id_str" : "903706998167834624",
        "id" : 903706998167834624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIqcug7UEAAzewl.jpg",
        "sizes" : [ {
          "h" : 671,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1066,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QgPLc8HGeT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Lw7C2MY1hJ",
        "expanded_url" : "http:\/\/www.jennyodell.com\/museumofcapitalism_freewatch.pdf",
        "display_url" : "jennyodell.com\/museumofcapita\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "903707076089700352",
    "text" : "in case you like rabbit holes, here's my report on the notorious \"free watch,\" produced for the museum of capitalism https:\/\/t.co\/Lw7C2MY1hJ https:\/\/t.co\/QgPLc8HGeT",
    "id" : 903707076089700352,
    "created_at" : "2017-09-01 19:52:11 +0000",
    "user" : {
      "name" : "Jenny Odell",
      "screen_name" : "the_jennitaur",
      "protected" : false,
      "id_str" : "145749531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923002070495412225\/90AG05_O_normal.jpg",
      "id" : 145749531,
      "verified" : false
    }
  },
  "id" : 904251819530092544,
  "created_at" : "2017-09-03 07:56:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904055483874635776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54086146621707, -0.07142173409678132 ]
  },
  "id_str" : "904241843025653760",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue Haven\u2019t replied. But as the paper looks relevant I\u2019ll say yes \u263A\uFE0F",
  "id" : 904241843025653760,
  "in_reply_to_status_id" : 904055483874635776,
  "created_at" : "2017-09-03 07:17:10 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    }, {
      "name" : "Arnold Sommerfeld",
      "screen_name" : "poilkjh3",
      "indices" : [ 10, 19 ],
      "id_str" : "780051839093989378",
      "id" : 780051839093989378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904061315513233408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5406299147735, -0.0716261587758074 ]
  },
  "id_str" : "904091436810952704",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay @poilkjh3 Danke!",
  "id" : 904091436810952704,
  "in_reply_to_status_id" : 904061315513233408,
  "created_at" : "2017-09-02 21:19:30 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    }, {
      "name" : "Arnold Sommerfeld",
      "screen_name" : "poilkjh3",
      "indices" : [ 10, 19 ],
      "id_str" : "780051839093989378",
      "id" : 780051839093989378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904055328530149377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5407393146785, -0.07150363257665766 ]
  },
  "id_str" : "904056289407496192",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay @poilkjh3 Aye",
  "id" : 904056289407496192,
  "in_reply_to_status_id" : 904055328530149377,
  "created_at" : "2017-09-02 18:59:50 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arnold Sommerfeld",
      "screen_name" : "poilkjh3",
      "indices" : [ 0, 9 ],
      "id_str" : "780051839093989378",
      "id" : 780051839093989378
    }, {
      "name" : "Twitter Deutschland",
      "screen_name" : "TwitterDE",
      "indices" : [ 61, 71 ],
      "id_str" : "95255169",
      "id" : 95255169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904035140963377153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54078877997988, -0.07148933547381284 ]
  },
  "id_str" : "904055007867277315",
  "in_reply_to_user_id" : 780051839093989378,
  "text" : "@poilkjh3 Yep, voller Name ist nun \u2018Greshake Tzovaras\u2019, aber @TwitterDE l\u00E4sst mich den Namen hier nicht wechseln.",
  "id" : 904055007867277315,
  "in_reply_to_status_id" : 904035140963377153,
  "created_at" : "2017-09-02 18:54:45 +0000",
  "in_reply_to_screen_name" : "poilkjh3",
  "in_reply_to_user_id_str" : "780051839093989378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.540784276129, -0.07159776313080532 ]
  },
  "id_str" : "904034322960744448",
  "text" : "~2 months since my name change &amp; \uD83D\uDCE7 to me are now addressed to \u2018Prof Tzovaras\u2019 instead \u2018Dr Greshake\u2019, inviting me to review for \uD83C\uDDEC\uD83C\uDDF7 journals \uD83D\uDE02",
  "id" : 904034322960744448,
  "created_at" : "2017-09-02 17:32:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/syLziukDqs",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/8514676",
      "display_url" : "goodreads.com\/book\/show\/8514\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "904026075763703808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54085437152947, -0.07134799168754324 ]
  },
  "id_str" : "904027519015321600",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd Here\u2019s a link to it: https:\/\/t.co\/syLziukDqs",
  "id" : 904027519015321600,
  "in_reply_to_status_id" : 904026075763703808,
  "created_at" : "2017-09-02 17:05:31 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "JONATHAN KEMP",
      "screen_name" : "JonathanMKemp",
      "indices" : [ 109, 123 ],
      "id_str" : "249190827",
      "id" : 249190827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "904026075763703808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54075544816195, -0.0716035036083031 ]
  },
  "id_str" : "904027324282175490",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd Thanks for the recommendations! I\u2019m really happy to visit every single time. To return the favor: @JonathanMKemp\u2019s London Triptych is great!",
  "id" : 904027324282175490,
  "in_reply_to_status_id" : 904026075763703808,
  "created_at" : "2017-09-02 17:04:44 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/KEUgRocCeS",
      "expanded_url" : "http:\/\/www.wienerlibrary.co.uk\/science-and-suffering",
      "display_url" : "wienerlibrary.co.uk\/science-and-su\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "904024411912773634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.54058690269029, -0.0716342439435989 ]
  },
  "id_str" : "904024832190361602",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd Thanks, will check those out. I also want to find time for this one! https:\/\/t.co\/KEUgRocCeS",
  "id" : 904024832190361602,
  "in_reply_to_status_id" : 904024411912773634,
  "created_at" : "2017-09-02 16:54:50 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903960347324887041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52303382277915, -0.09972395051373276 ]
  },
  "id_str" : "903961016899436544",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab I\u2019ve spent a good time writing things in London and it\u2019s always a pleasure.",
  "id" : 903961016899436544,
  "in_reply_to_status_id" : 903960347324887041,
  "created_at" : "2017-09-02 12:41:15 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903959161452584960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.52065771312802, -0.1167399454982172 ]
  },
  "id_str" : "903959429237886976",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab It\u2019s been 5 1\/2 months for me. Will have a week of thesis writing from here :)",
  "id" : 903959429237886976,
  "in_reply_to_status_id" : 903959161452584960,
  "created_at" : "2017-09-02 12:34:57 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51721699078225, -0.1202323446278654 ]
  },
  "id_str" : "903957544888139776",
  "text" : "Hey London, it\u2019s so nice to be back. \uD83C\uDF89",
  "id" : 903957544888139776,
  "created_at" : "2017-09-02 12:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seshupik flekh'es",
      "screen_name" : "FrauFledermaus",
      "indices" : [ 0, 15 ],
      "id_str" : "41335337",
      "id" : 41335337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903897463240761344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05273967422159, 8.588843448649357 ]
  },
  "id_str" : "903902935876325376",
  "in_reply_to_user_id" : 41335337,
  "text" : "@FrauFledermaus yep, tut man.",
  "id" : 903902935876325376,
  "in_reply_to_status_id" : 903897463240761344,
  "created_at" : "2017-09-02 08:50:28 +0000",
  "in_reply_to_screen_name" : "FrauFledermaus",
  "in_reply_to_user_id_str" : "41335337",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "903902543360741378",
  "text" : "RT @ctitusbrown: tl; dr? Can you add just one genome to your ref database, or one read to your analysis, without redoing entire analysis? h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/9tHpFR3SXp",
        "expanded_url" : "https:\/\/twitter.com\/ctitusbrown\/status\/903604114529042433",
        "display_url" : "twitter.com\/ctitusbrown\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "903604433820426242",
    "text" : "tl; dr? Can you add just one genome to your ref database, or one read to your analysis, without redoing entire analysis? https:\/\/t.co\/9tHpFR3SXp",
    "id" : 903604433820426242,
    "created_at" : "2017-09-01 13:04:19 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 903902543360741378,
  "created_at" : "2017-09-02 08:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly OBrien Burford",
      "screen_name" : "obrienwrite",
      "indices" : [ 0, 12 ],
      "id_str" : "248919613",
      "id" : 248919613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903690190081757184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140394328657, 8.75337323633307 ]
  },
  "id_str" : "903736852607356928",
  "in_reply_to_user_id" : 248919613,
  "text" : "@obrienwrite Thanks so much for that!",
  "id" : 903736852607356928,
  "in_reply_to_status_id" : 903690190081757184,
  "created_at" : "2017-09-01 21:50:30 +0000",
  "in_reply_to_screen_name" : "obrienwrite",
  "in_reply_to_user_id_str" : "248919613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 14, 19 ],
      "id_str" : "15234407",
      "id" : 15234407
    }, {
      "name" : "CMS Experiment CERN",
      "screen_name" : "CMSexperiment",
      "indices" : [ 20, 34 ],
      "id_str" : "91143053",
      "id" : 91143053
    }, {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 35, 42 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903665871775784960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232752955123, 8.62752881098693 ]
  },
  "id_str" : "903666029460692992",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @CERN @CMSexperiment @reddit That\u2019s totally what I hoped for! \uD83D\uDC96",
  "id" : 903666029460692992,
  "in_reply_to_status_id" : 903665871775784960,
  "created_at" : "2017-09-01 17:09:05 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 14, 19 ],
      "id_str" : "15234407",
      "id" : 15234407
    }, {
      "name" : "CMS Experiment CERN",
      "screen_name" : "CMSexperiment",
      "indices" : [ 20, 34 ],
      "id_str" : "91143053",
      "id" : 91143053
    }, {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 35, 42 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903660051365339136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233250033683, 8.62752080419477 ]
  },
  "id_str" : "903660517889335296",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @CERN @CMSexperiment @reddit Wait, in which category do I fall? \uD83D\uDE02",
  "id" : 903660517889335296,
  "in_reply_to_status_id" : 903660051365339136,
  "created_at" : "2017-09-01 16:47:11 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "CERN",
      "screen_name" : "CERN",
      "indices" : [ 14, 19 ],
      "id_str" : "15234407",
      "id" : 15234407
    }, {
      "name" : "CMS Experiment CERN",
      "screen_name" : "CMSexperiment",
      "indices" : [ 20, 34 ],
      "id_str" : "91143053",
      "id" : 91143053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903658624672825344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233250033683, 8.62752080419477 ]
  },
  "id_str" : "903660380152631296",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @CERN @CMSexperiment \uD83D\uDE0D",
  "id" : 903660380152631296,
  "in_reply_to_status_id" : 903658624672825344,
  "created_at" : "2017-09-01 16:46:38 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]